/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.impl;

import com.google.inject.Inject;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealProcessFactory;
import curam.appeal.sl.entity.intf.AppealProcess;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct1;
import curam.appeal.sl.entity.struct.AppealProcessKeyDetails;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.ProductStartDateActiveDetails;
import curam.appeal.sl.fact.AppealableCaseTypeAppealProcessFactory;
import curam.appeal.sl.fact.IntegratedCaseAppealProcessFactory;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.fact.ProductAppealProcessFactory;
import curam.appeal.sl.struct.AppealCaseIDCaseID;
import curam.appeal.sl.struct.AppealObjectActiveCaseInd;
import curam.appeal.sl.struct.IssueAppealProcessKey;
import curam.appeal.sl.struct.OrderedAppealStage;
import curam.appeal.sl.struct.OrderedAppealStageList;
import curam.appeal.sl.struct.ProductAppealProcessID;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.codetable.impl.APPEALTYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import java.util.ArrayList;
import java.util.Map;

/**
 * Default implementation of the {@linkplain Appeals} interface.
 */
public class AppealCaseImpl implements Appeals {

  @Inject
  private Map<CASETYPECODEEntry, AppealableCaseType> appealableCaseTypeMap;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  public AppealCaseImpl() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   * 
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public APPEALTYPEEntry getNextStageForCaseType(final long caseID)
    throws AppException, InformationalException {

    // Details to return
    String nextAppealStage = new String();

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseID;
    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);
    // END, CR00303986

    final AppealCaseIDCaseID appealCaseIDCaseID = new AppealCaseIDCaseID();

    appealCaseIDCaseID.caseID = caseID;

    // Get the next appeal stage
    // BEGIN, CR00303986, SG
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      nextAppealStage =
        IssueAppealProcessFactory.newInstance().getCurrentAppealStageDetails(
          appealCaseIDCaseID).appealTypeCode;
    } else if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
      nextAppealStage =
        IntegratedCaseAppealProcessFactory.newInstance()
          .getCurrentAppealStageDetails(appealCaseIDCaseID).appealTypeCode;
    } else if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
      // END, CR00303986
      nextAppealStage =
        ProductAppealProcessFactory.newInstance()
          .getCurrentAppealStageDetails(appealCaseIDCaseID).appealTypeCode;
    } // Check If the case has implemented the Appealable Interface.
    else {
      final AppealableCaseType appealableCaseType =
        appealableCaseTypeMap.get(CASETYPECODEEntry
          .get(caseTypeCode.caseTypeCode));

      if (appealableCaseType != null) {
        nextAppealStage =
          AppealableCaseTypeAppealProcessFactory.newInstance()
            .getCurrentAppealStageDetails(appealCaseIDCaseID).appealTypeCode;
      }
    }

    return APPEALTYPEEntry.get(nextAppealStage);
  }

  /**
   * {@inheritDoc}
   * 
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ArrayList<APPEALTYPEEntry>
    listAllStagesForCaseType(final long caseID) throws AppException,
      InformationalException {

    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();
    long appealProcessID = 0;
    OrderedAppealStageList stageList = new OrderedAppealStageList();

    // Read the case header
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(caseID);

    // Get the appeal stages configured for this case type
    if (caseHeader.getCaseType().equals(CASETYPECODEEntry.PRODUCTDELIVERY)) {
      // END, CR00303986

      final ProductStartDateActiveDetails productStartDateActiveDetails =
        new ProductStartDateActiveDetails();

      productStartDateActiveDetails.productID = caseHeader.getID();
      productStartDateActiveDetails.recordStatus = RECORDSTATUS.NORMAL;
      productStartDateActiveDetails.startDate = Date.getCurrentDate();
      final curam.appeal.sl.entity.struct.ProductAppealProcessID readProcessIDByProductAndStartDate =
        curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance()
          .readProcessIDByProductAndStartDate(productStartDateActiveDetails);
      final ProductAppealProcessID productAppealProcessID =
        new ProductAppealProcessID();

      productAppealProcessID.productAppealProcessID =
        readProcessIDByProductAndStartDate.productAppealProcessID;
      stageList =
        ProductAppealProcessFactory.newInstance().listOrderedActiveStages(
          productAppealProcessID);
    } else {

      final AppealProcessKeyDetails appealProcessKeyDetails =
        new AppealProcessKeyDetails();

      appealProcessKeyDetails.startDate = Date.getCurrentDate();
      appealProcessKeyDetails.caseTypeID = caseHeader.getID();
      appealProcessKeyDetails.caseType = caseHeader.getCaseType().getCode();
      appealProcessKeyDetails.recordStatus = RECORDSTATUS.NORMAL;
      appealProcessID =
        appealProcessObj
          .readProcessIDByCaseTypeStartDateAndStatus(appealProcessKeyDetails).appealProcessID;

      final IssueAppealProcessKey issueAppealProcessKey =
        new IssueAppealProcessKey();

      issueAppealProcessKey.appealProcessID = appealProcessID;
      stageList =
        AppealableCaseTypeAppealProcessFactory.newInstance()
          .listOrderedActiveStages(issueAppealProcessKey);
    }

    // Create the return list
    final ArrayList<APPEALTYPEEntry> stageTypeList =
      new ArrayList<APPEALTYPEEntry>();

    for (final OrderedAppealStage stageDetails : stageList.orderedAppealStage) {
      stageTypeList.add(APPEALTYPEEntry.get(stageDetails.appealTypeCode));
    }

    return stageTypeList;
  }

  /**
   * {@inheritDoc}
   * 
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public boolean isObjectValidForStage(
    final APPEALOBJECTTYPEEntry objectType, final long objectID,
    final APPEALTYPEEntry appealStageType, final long caseID)
    throws AppException, InformationalException {

    boolean validForStage = false;

    // Appeal Object business manipulation object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealObjectKeyStruct1 appealObjectKey =
      new AppealObjectKeyStruct1();
    AppealObjectActiveCaseInd isObjectActiveOnAppealCase =
      new AppealObjectActiveCaseInd();

    appealObjectKey.objectID = objectID;
    appealObjectKey.objectType = objectType.getCode();

    isObjectActiveOnAppealCase =
      appealObj.isObjectOnActiveAppealsCase(appealObjectKey);

    if (getNextStageForCaseType(caseID).equals(appealStageType)
      && !isObjectActiveOnAppealCase.result) {
      validForStage = true;
    }
    return validForStage;
  }

  /**
   * {@inheritDoc}
   * 
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public APPEALTYPEEntry
    getCurrentStageForAppealCase(final long appealCaseID)
      throws AppException, InformationalException {

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = appealCaseID;
    final AppealTypeDetails appealTypeDetails =
      AppealFactory.newInstance().readAppealTypeByCase(appealCaseIDKey);

    return APPEALTYPEEntry.get(appealTypeDetails.appealTypeCode);
  }

}
