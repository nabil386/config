/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.impl;

import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;
import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.onlineappealrequest.impl.OnlineAppealRequestStatus;

;

public class AppealsModule extends AbstractModule {

  @Override
  protected void configure() {

    //
    // Bind the implementation of the Appeals interface
    //
    bind(Appeals.class).to(AppealCaseImpl.class);

    //
    // Create the instance of map binder interface for Appeal Object interface
    //
    final MapBinder<APPEALOBJECTTYPEEntry, Appealable> mapbinder =
      MapBinder.newMapBinder(binder(), APPEALOBJECTTYPEEntry.class,
        Appealable.class);

    // bind the product delivery appeal object type
    final Appealable productDeliveryAppeal = new ProductDeliveryAppeal();

    mapbinder.addBinding(APPEALOBJECTTYPEEntry.PRODUCTDELIVERY).toInstance(
      productDeliveryAppeal);

    // Issue
    final Appealable issueAppeal = new IssueAppeal();

    mapbinder.addBinding(APPEALOBJECTTYPEEntry.ISSUE).toInstance(issueAppeal);

    // IC
    final Appealable integratedCaseAppeal = new IntegratedCaseAppeal();

    mapbinder.addBinding(APPEALOBJECTTYPEEntry.INTEGRATEDCASE).toInstance(
      integratedCaseAppeal);

    // BEGIN, CR00425681, DG
    final Appealable determinationCaseAppeal = new DeterminationAppeal();

    mapbinder.addBinding(APPEALOBJECTTYPEEntry.DETERMINATION).toInstance(
      determinationCaseAppeal);

    // END, CR00425681
    //
    // Create the instance of map binder interface for Appeal Object interface
    //
    final MapBinder<CASETYPECODEEntry, AppealableCaseType> mapbinder1 =
      MapBinder.newMapBinder(binder(), CASETYPECODEEntry.class,
        AppealableCaseType.class);

    // BEGIN, CR00431372, SD
    final AppealableCaseType determinationAppealCaseType =
      new DeterminationAppealCaseType();

    mapbinder1.addBinding(CASETYPECODEEntry.PRODUCTDELIVERY).toInstance(
      determinationAppealCaseType);
    // END, CR00431372

    // BEGIN, CR00430554, DG
    // Bind the implementation of the OnlineAppealRequestStatus interface
    bind(OnlineAppealRequestStatus.class).to(
      OnlineAppealRequestStatusImpl.class);
    // END, CR00430554

    // BEGIN, CR00434578, SD
    bind(DeterminationAppealUtil.class).to(DeterminationAppealUtilImpl.class);
    // END, CR00434578
  }

}
