/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.event.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.impl.SearchController;
import curam.core.intf.SynchronizeEvents;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This event handler listens for events that occur to the Appeal
 * entity and informs the search service of changes which may affect it.
 */
public final class AppealSearchHandler implements EventFilter, EventHandler {

  // ___________________________________________________________________________
  /**
   * Returns true if the event is one of the appeal events
   * 
   * @param event The details of the event.
   * 
   * @return boolean if an only if the event is interesting to the search
   * service
   */
  @Override
  public boolean accept(final Event event) throws AppException,
    InformationalException {

    if (event.eventKey.eventClass
      .equals(GeneralAppealConstants.kEventClassAppeal)) {
      if (event.eventKey.eventType
        .equals(GeneralAppealConstants.kEventTypeInsert)) {
        return true;
      }
    }
    return false;
  }

  // ___________________________________________________________________________
  /**
   * Informs the search service of the change to the Appeal.
   * 
   * @param event The details of the event.
   */
  @Override
  public void eventRaised(final Event event) throws AppException,
    InformationalException {

    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    if (synchronizeEventsObj.isOnlineSynchronizationEnabled()) {

      final SearchController searchControllerObj = new SearchController();
      final Appeal appealObj = AppealFactory.newInstance();
      final AppealKey appealKey = new AppealKey();
      AppealDtls appealDtls;

      appealKey.appealID = event.primaryEventData;
      appealDtls = appealObj.read(appealKey);

      // If this is an insert then call the search controller insert
      // otherwise call the update
      if (event.eventKey.eventType
        .equals(GeneralAppealConstants.kEventTypeInsert)) {

        searchControllerObj.insert(appealDtls, Appeal.class.getSimpleName());

      }
    }

  }

}
