/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingActivityLinkFactory;
import curam.appeal.sl.entity.fact.HearingParticipationFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.fact.HearingServiceSupplierFactory;
import curam.appeal.sl.entity.fact.HearingTranscriptionRequestFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.fact.HearingWitnessFactory;
import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.Appellant;
import curam.appeal.sl.entity.intf.HearingActivityLink;
import curam.appeal.sl.entity.intf.HearingParticipation;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.intf.HearingServiceSupplier;
import curam.appeal.sl.entity.intf.HearingTranscriptionRequest;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.intf.HearingWitness;
import curam.appeal.sl.entity.intf.ThirdParty;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.AppellantKey;
import curam.appeal.sl.entity.struct.AppellantKeyList;
import curam.appeal.sl.entity.struct.HearingActivityLinkDtls;
import curam.appeal.sl.entity.struct.HearingAttendeeKey;
import curam.appeal.sl.entity.struct.HearingAttendeeUserNameDetails;
import curam.appeal.sl.entity.struct.HearingAttendeeUserNameDetailsList;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingCaseUserDtlsList;
import curam.appeal.sl.entity.struct.HearingCaseUserNameDtls;
import curam.appeal.sl.entity.struct.HearingDateAndType;
import curam.appeal.sl.entity.struct.HearingDetails;
import curam.appeal.sl.entity.struct.HearingDetailsList;
import curam.appeal.sl.entity.struct.HearingDtls;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantRoleTypeKey;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingIDUserStatusTypeKey;
import curam.appeal.sl.entity.struct.HearingInterpreterNameParticipantDetails;
import curam.appeal.sl.entity.struct.HearingInterpreterNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingInterpreterNameUserRoleDetails;
import curam.appeal.sl.entity.struct.HearingInterpreterNameUserRoleDetailsList;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingModifyValidateDetails;
import curam.appeal.sl.entity.struct.HearingParticipantKey;
import curam.appeal.sl.entity.struct.HearingParticipatedCodeAndVersionNoDetails;
import curam.appeal.sl.entity.struct.HearingParticipatedDetails;
import curam.appeal.sl.entity.struct.HearingParticipationAndStatus;
import curam.appeal.sl.entity.struct.HearingParticipationDetails;
import curam.appeal.sl.entity.struct.HearingParticipationKey;
import curam.appeal.sl.entity.struct.HearingPostponeTimeStatusModifyDetails;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDKey;
import curam.appeal.sl.entity.struct.HearingRepresentativeNameParticipantDetails;
import curam.appeal.sl.entity.struct.HearingRepresentativeNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingSSLinkAndTypeDetailsList;
import curam.appeal.sl.entity.struct.HearingSSParticipationAndCommentDetails;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingServiceSupplierIDKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterHearingKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierStatusKey;
import curam.appeal.sl.entity.struct.HearingStatusDateDetails;
import curam.appeal.sl.entity.struct.HearingStatusDateTypeDetails;
import curam.appeal.sl.entity.struct.HearingTimeStatusModifyDetails;
import curam.appeal.sl.entity.struct.HearingTranscriptionByStatusKey;
import curam.appeal.sl.entity.struct.HearingUserAttendeeActivityDetails;
import curam.appeal.sl.entity.struct.HearingUserFullDetails;
import curam.appeal.sl.entity.struct.HearingUserRoleDtls;
import curam.appeal.sl.entity.struct.HearingUserRoleIDKey;
import curam.appeal.sl.entity.struct.HearingUserRoleIDKeyList;
import curam.appeal.sl.entity.struct.HearingUserRoleKey;
import curam.appeal.sl.entity.struct.HearingUserRoleParticipatedDetails;
import curam.appeal.sl.entity.struct.HearingUserRoleStatusKey;
import curam.appeal.sl.entity.struct.HearingWitnessIDKey;
import curam.appeal.sl.entity.struct.HearingWitnessNameAndParticipantDetails;
import curam.appeal.sl.entity.struct.HearingWitnessNameAndParticipantDetailsList;
import curam.appeal.sl.entity.struct.OwnerNameAndFullName;
import curam.appeal.sl.entity.struct.ParticipatedCodeDetails;
import curam.appeal.sl.entity.struct.ParticipatedCodeDetailsHR;
import curam.appeal.sl.entity.struct.ReadHearingRepresentativeDetailsList;
import curam.appeal.sl.entity.struct.ReadHearingWitnessDetailsList;
import curam.appeal.sl.entity.struct.ReadLocationType;
import curam.appeal.sl.entity.struct.ReadParticipatedCodeKeys;
import curam.appeal.sl.entity.struct.SupplierHearingIDAndTypeKey;
import curam.appeal.sl.entity.struct.ThirdPartyDtls;
import curam.appeal.sl.entity.struct.ThirdPartyKey;
import curam.appeal.sl.entity.struct.ThirdPartyKeyList;
import curam.appeal.sl.entity.struct.TranscriptionRequestIDKey;
import curam.appeal.sl.entity.struct.TranscriptionRequestIDKeyList;
import curam.appeal.sl.entity.struct.UpdateNonParticipationDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationKey;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingScheduleFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AdjournHearingDetails;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealDeadlineDateDetails;
import curam.appeal.sl.struct.CaseIDDeadlineDate;
import curam.appeal.sl.struct.CompleteHearingDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.DeskHearingSummaryDetails;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingAttendance;
import curam.appeal.sl.struct.HearingAttendanceDetails;
import curam.appeal.sl.struct.HearingCaseHearingDetails;
import curam.appeal.sl.struct.HearingCaseHearingDetailsList;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingDateAndStatus;
import curam.appeal.sl.struct.HearingDurationDetails;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingModifyDetails;
import curam.appeal.sl.struct.HearingParticipantDetails;
import curam.appeal.sl.struct.HearingParticipantDetailsList;
import curam.appeal.sl.struct.HearingParticipantPhoneNumber;
import curam.appeal.sl.struct.HearingParticipantPhoneNumberList;
import curam.appeal.sl.struct.HearingParticipatedDetailsList;
import curam.appeal.sl.struct.HearingReviewSummaryDetails;
import curam.appeal.sl.struct.HearingSummaryDetails;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.HearingUserDetails;
import curam.appeal.sl.struct.HearingUserFullDetailsList;
import curam.appeal.sl.struct.HearingUserTypeKey;
import curam.appeal.sl.struct.IsSufficientTimeForCorrespondence;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.ACTIVITYPRIORITY;
import curam.codetable.ACTIVITYTIMESTATUS;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.APPEALDIFFICULTY;
import curam.codetable.APPEALSUPPLIERTYPE;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGACTIVITYTYPE;
import curam.codetable.HEARINGATTENDANCE;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseTransactionLogFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.LocationFactory;
import curam.core.fact.MaintainActivityFactory;
import curam.core.fact.MaintainConcernRolePhoneFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.Address;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseTransactionLog;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainActivity;
import curam.core.intf.MaintainConcernRolePhone;
import curam.core.intf.Notification;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.fact.ExternalPartyOfficeFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.CaseParticipantRole_eoTypeCode;
import curam.core.sl.entity.struct.CaseUserRoleDtls;
import curam.core.sl.entity.struct.CaseUserRoleKey;
import curam.core.sl.entity.struct.ExternalPartyOfficeDtls;
import curam.core.sl.entity.struct.ExternalPartyOfficeKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.SearchByUserTypeCaseStatusDetails;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.AddressKey;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTransactionLogDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.core.struct.LocationKeyStruct;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainActivityKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadMultiByConcernRoleIDPhoneResult;
import curam.core.struct.UserAddressDetailsList;
import curam.core.struct.UsersKey;
import curam.message.BPOHEARING;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Service layer methods for the hearing functionality.
 */
public abstract class Hearing extends curam.appeal.sl.base.Hearing {

  // This constant defines the ID of the organization.
  protected static final int kOrganizationID = 1;

  // Typical length of the hearing (in hours)
  protected static final int kHearingLength = 2;

  // A constant for the zero date created by the time only widget
  // which is date 1970-01-01 rather than the normal zero date.
  protected static final DateTime kZeroEPOCDate = new DateTime(0);

  // ___________________________________________________________________________
  /**
   * Clones the representatives from a previous hearing for the case.
   * 
   * @param key
   * Previous Hearing identifier
   * @param dtls
   * Hearing identifier
   */
  @Override
  protected void cloneRepresentatives(final HearingKey key,
    final HearingKey dtls) throws AppException, InformationalException {

    // Hearing Representative object and manipulation variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    ReadHearingRepresentativeDetailsList readHearingRepresentativeDetailsList;
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();

    // variables for clone
    final HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new HearingRepresentativeIDKey();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    // read all representatives for the hearing
    readHearingRepresentativeDetailsList =
      hearingRepresentativeObj.searchActiveByHearingID(hearingIDStatusKeyHR);

    hearingKey.hearingID = dtls.hearingKey.hearingID;

    for (int i = 0; i < readHearingRepresentativeDetailsList.dtls.size(); i++) {

      hearingRepresentativeIDKey.hearingRepresentativeID =
        readHearingRepresentativeDetailsList.dtls.item(i).hearingRepresentativeID;

      // clone
      hearingRepresentativeObj.clone(hearingRepresentativeIDKey, hearingKey);
    }

  }

  // ___________________________________________________________________________
  /**
   * Clones the active attendees from a previous hearing for the case.
   * 
   * @param key
   * Previous Hearing identifier
   * @param dtls
   * Hearing identifier
   */
  @Override
  protected void cloneServiceSuppliers(final HearingKey key,
    final HearingKey dtls) throws AppException, InformationalException {

    // Hearing Service Supplier object and manipulation variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierStatusKey hearingServiceSupplierStatusKey =
      new HearingServiceSupplierStatusKey();
    HearingSSLinkAndTypeDetailsList hearingSSLinkAndTypeDetailsList;

    // Key and details for clone
    final HearingServiceSupplierIDKey hearingServiceSupplierIDKey =
      new HearingServiceSupplierIDKey();
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    hearingServiceSupplierStatusKey.hearingID = key.hearingKey.hearingID;
    hearingServiceSupplierStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Search for all service suppliers for the hearing
    hearingSSLinkAndTypeDetailsList =
      hearingServiceSupplierObj
        .searchByHearingIDAndStatus(hearingServiceSupplierStatusKey);

    // Clone all service suppliers found
    for (int i = 0; i < hearingSSLinkAndTypeDetailsList.dtls.size(); i++) {

      hearingServiceSupplierIDKey.hearingServiceSupplierID =
        hearingSSLinkAndTypeDetailsList.dtls.item(i).hearingServiceSupplierID;

      hearingKeyDetails.hearingID = dtls.hearingKey.hearingID;

      hearingServiceSupplierObj.clone(hearingServiceSupplierIDKey,
        hearingKeyDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Clones the witnesses from a previous hearing for the case.
   * 
   * @param key
   * Previous Hearing identifier
   * @param dtls
   * Hearing identifier
   */
  @Override
  protected void cloneWitnesses(final HearingKey key, final HearingKey dtls)
    throws AppException, InformationalException {

    // HearingWitness manipulation variables
    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    ReadHearingWitnessDetailsList readHearingWitnessDetailsList;
    final HearingIDStatusKeyHW hearingIDStatusKeyHW =
      new HearingIDStatusKeyHW();

    // Key and details for clone
    final HearingWitnessIDKey hearingWitnessIDKey = new HearingWitnessIDKey();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingIDStatusKeyHW.hearingID = key.hearingKey.hearingID;

    hearingIDStatusKeyHW.recordStatus = RECORDSTATUS.NORMAL;

    // read hearing witnesses
    readHearingWitnessDetailsList =
      hearingWitnessObj.searchActiveByHearingID(hearingIDStatusKeyHW);

    hearingKey.hearingID = dtls.hearingKey.hearingID;

    for (int i = 0; i < readHearingWitnessDetailsList.dtls.size(); i++) {

      hearingWitnessIDKey.hearingWitnessID =
        readHearingWitnessDetailsList.dtls.item(i).hearingWitnessID;

      hearingWitnessObj.clone(hearingWitnessIDKey, hearingKey);

    }

  }

  // ___________________________________________________________________________
  /**
   * Clones the active attendees from a previous hearing for the case.
   * 
   * @param key
   * Previous Hearing identifier
   * @param dtls
   * Hearing identifier
   */
  @Override
  protected void cloneAttendees(final HearingKey key, final HearingKey dtls)
    throws AppException, InformationalException {

    // Hearing User Role object and manipulation variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingAttendeeKey hearingAttendeeKey = new HearingAttendeeKey();
    HearingUserRoleIDKeyList hearingUserRoleIDKeyList;

    // Key and details for clone
    final HearingUserRoleKey hearingUserRoleKey = new HearingUserRoleKey();
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    hearingAttendeeKey.excludeTypeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    hearingAttendeeKey.hearingID = key.hearingKey.hearingID;
    hearingAttendeeKey.recordStatus = RECORDSTATUS.NORMAL;

    // Search for all attendees for the hearing
    hearingUserRoleIDKeyList =
      hearingUserRoleObj.searchActiveAttendeesByHearingID(hearingAttendeeKey);

    // Clone all attendees found
    for (int i = 0; i < hearingUserRoleIDKeyList.dtls.size(); i++) {

      hearingUserRoleKey.hearingUserRoleID =
        hearingUserRoleIDKeyList.dtls.item(i).hearingUserRoleID;

      hearingKeyDetails.hearingID = dtls.hearingKey.hearingID;

      hearingUserRoleObj.clone(hearingUserRoleKey, hearingKeyDetails);

    }
  }

  // ___________________________________________________________________________
  /**
   * Clones transcription requests from a previous hearing for the case.
   * 
   * @param key
   * Previous Hearing identifier
   * @param dtls
   * Hearing identifier
   */
  @Override
  protected void cloneTranscriptionRequest(final HearingKey key,
    final HearingKey dtls) throws AppException, InformationalException {

    // Hearing Transcription Request object and manipulation variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionByStatusKey hearingTranscriptionByStatusKey =
      new HearingTranscriptionByStatusKey();
    TranscriptionRequestIDKeyList transcriptionRequestIDKeyList;
    final TranscriptionRequestIDKey transcriptionRequestIDKey =
      new TranscriptionRequestIDKey();

    // Details for clone
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    hearingTranscriptionByStatusKey.hearingID = key.hearingKey.hearingID;
    hearingTranscriptionByStatusKey.recordStatusCode = RECORDSTATUS.NORMAL;

    // Search for the hearing transcription requests for the hearing
    transcriptionRequestIDKeyList =
      hearingTranscriptionRequestObj
        .searchActiveByHearingID(hearingTranscriptionByStatusKey);

    // Clone requests found
    for (int i = 0; i < transcriptionRequestIDKeyList.dtls.size(); i++) {

      transcriptionRequestIDKey.hearingTranscriptionRequestID =
        transcriptionRequestIDKeyList.dtls.item(i).hearingTranscriptionRequestID;
      hearingKeyDetails.hearingID = dtls.hearingKey.hearingID;

      hearingTranscriptionRequestObj.clone(transcriptionRequestIDKey,
        hearingKeyDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Determines whether or not there is sufficient time before the scheduled
   * hearing date to sent correspondence.
   * 
   * @param dtls
   * Hearing scheduled date and time
   */
  @Override
  public IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondence(
    final HearingTimeDetails dtls) throws AppException,
    InformationalException {

    // Correspondence lead time
    int correspondenceLeadTime;

    // Hearing notification time
    int hearingNotificationTime;

    // Value to be returned
    final IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondence =
      new IsSufficientTimeForCorrespondence();

    // Get the value of the Correspondence Lead Time environment variable
    final String correspondenceLeadTimeString =
      Configuration.getProperty(EnvVars.ENV_CORRESPONDENCE_LEAD_TIME);

    // If it's not set, use the default
    if (correspondenceLeadTimeString == null) {
      correspondenceLeadTime = EnvVars.ENV_CORRESPONDENCE_LEAD_TIME_DEFAULT;
    } else {
      correspondenceLeadTime = Integer.parseInt(correspondenceLeadTimeString);
    }

    // Get the value of the Hearing Notification Time environment variable
    final String hearingNotificationTimeString =
      Configuration.getProperty(EnvVars.ENV_HEARING_NOTIFICATION_TIME);

    // If it's not set, use the default
    if (hearingNotificationTimeString == null) {
      hearingNotificationTime = EnvVars.ENV_HEARING_NOTIFICATION_TIME_DEFAULT;
    } else {
      hearingNotificationTime =
        Integer.parseInt(hearingNotificationTimeString);
    }

    // Scheduled hearing date
    final Date scheduledDate = new Date(dtls.scheduledDateTime);

    // Is there sufficient time for correspondence to be sent?
    if (!Date.getCurrentDate()
      .addDays(correspondenceLeadTime + hearingNotificationTime)
      .after(scheduledDate)) {
      isSufficientTimeForCorrespondence.isSufficientTime = true;
    } else {
      isSufficientTimeForCorrespondence.isSufficientTime = false;
    }

    return isSufficientTimeForCorrespondence;

  }

  // ___________________________________________________________________________
  /**
   * Method to list the hearings for a hearing case
   * 
   * @param key
   * The hearing case ID
   * 
   * @return the list of hearing details
   */
  @Override
  public HearingCaseHearingDetailsList listForHearingCase(
    final HearingCaseID key) throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingDetailsList hearingDetailsList;
    HearingDetails hearingDetails;
    HearingCaseHearingDetails hearingCaseHearingDetails;

    // HearingUserRole object
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingUserFullDetailsList hearingUserFullDetailsList;

    // Return structure
    final HearingCaseHearingDetailsList hearingCaseHearingDetailsList =
      new HearingCaseHearingDetailsList();

    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

    // BEGIN, CR00118832, RKi
    ReadLocationType readLocationType = new ReadLocationType();
    final curam.appeal.sl.entity.struct.HearingUserTypeKey hearingUserTypekey =
      new curam.appeal.sl.entity.struct.HearingUserTypeKey();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    // END, CR00118832

    // BEGIN, CR00131857, RKi
    // Hearing Participation Object
    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();

    // END, CR00131857

    // Retrieve hearing list
    hearingDetailsList = hearingObj.searchHearingsByCaseID(key.hearingCaseID);

    // Retrieve hearing official for each hearing
    for (int i = 0; i < hearingDetailsList.dtls.size(); i++) {

      // Combine results
      hearingCaseHearingDetails = new HearingCaseHearingDetails();

      hearingDetails = hearingDetailsList.dtls.item(i);
      // Read hearing official
      hearingUserTypekey.hearingID = hearingDetails.hearingID;
      // BEGIN, CR00118832, RKi
      // retrieve the location type(external or internal) to read the hearing
      // official
      hearingKey.hearingID = hearingDetailsList.dtls.item(i).hearingID;
      readLocationType = hearingObj.readLocationTypeByHearingID(hearingKey);
      if (readLocationType.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {

        hearingIDStatusKeyHR.hearingID = hearingKey.hearingID;
        hearingIDStatusKeyHR.participantType =
          CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
        hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
        // read the external hearing official
        // BEGIN, CR00131857, RKi
        final curam.appeal.sl.entity.struct.HearingParticipatedDetailsList hearingParticipatedDetailsList =
          hearingParticipationObj
            .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

        hearingCaseHearingDetails.userFullname =
          hearingParticipatedDetailsList.dtls.item(0).fullName;
        hearingCaseHearingDetails.userName =
          hearingParticipatedDetailsList.dtls.item(0).fullName;
        hearingCaseHearingDetails.officialConcernRoleID =
          hearingParticipatedDetailsList.dtls.item(0).participantRoleID;
        // END, CR00131857
      } else { // END, CR00118832
        hearingUserTypekey.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

        // Should return one hearing official
        hearingUserFullDetailsList =
          hearingUserRoleObj.searchAllByHearingIDAndType(hearingUserTypekey);

        for (int j = 0; j < hearingUserFullDetailsList.dtls.size(); j++) {

          // BEGIN, CR00053295, RKi
          final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

          orgObjectLinkKey.orgObjectLinkID =
            hearingUserFullDetailsList.dtls.item(j).orgObjectLinkID;
          final curam.core.sl.intf.CaseUserRole caseUserRole =
            curam.core.sl.fact.CaseUserRoleFactory.newInstance();

          caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
          hearingUserFullDetailsList.dtls.item(j).fullName =
            caseOwnerDetails.userFullName;
          hearingCaseHearingDetails.userFullname =
            hearingUserFullDetailsList.dtls.item(0).fullName;
          hearingCaseHearingDetails.userName = caseOwnerDetails.userName;
          // END, CR00053295
        }
      }
      hearingCaseHearingDetails.assign(hearingDetails);

      hearingCaseHearingDetailsList.HearingCaseHearingDetails
        .addRef(hearingCaseHearingDetails);

    }

    // Return details
    return hearingCaseHearingDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Invites a user to the hearing
   * 
   * @param dtls
   * The details of the user to be invited
   */
  @Override
  public void inviteUser(final HearingUserDetails dtls) throws AppException,
    InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Read hearing status and case ID
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseStatusDtls.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateInviteUser(dtls);

    createUser(dtls);

    notify(dtls);

  }

  // ___________________________________________________________________________
  /**
   * Associates a user with a hearing
   * 
   * @param dtls
   * The details of the user
   */
  @Override
  protected void createUser(final HearingUserDetails dtls)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    HearingScheduleDate hearingScheduleDate;

    // CaseUserRole objects
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final SearchByUserTypeCaseStatusDetails searchByUserTypeCaseStatusDetails =
      new SearchByUserTypeCaseStatusDetails();
    CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    final CaseUserRoleDtls caseUserRoleDtls = new CaseUserRoleDtls();
    long lCaseUserRole = 0; // holds case user role ID

    // MaintainActivity objects
    final MaintainActivity maintainActivityObj =
      MaintainActivityFactory.newInstance();
    final MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    MaintainActivityKey maintainActivityKey;

    // HearingUserRole objects
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingUserRoleDtls hearingUserRoleDtls = new HearingUserRoleDtls();

    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj =
      UniqueIDFactory.newInstance();

    // HearingActivityLink object and structs
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityLinkDtls hearingActivityLinkDtls =
      new HearingActivityLinkDtls();
    final HearingUserAttendeeActivityDetails hearingUserAttendeeActivityDetails =
      new HearingUserAttendeeActivityDetails();
    Count count;

    // Read hearing case ID
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Check if user is already associated with the case
    searchByUserTypeCaseStatusDetails.userName = dtls.userName;
    searchByUserTypeCaseStatusDetails.typeCode = dtls.typeCode;
    searchByUserTypeCaseStatusDetails.caseID = hearingCaseID.caseID;
    searchByUserTypeCaseStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
    // BEGIN, CR00091335, RKi
    try {
      caseUserRoleKey =
        caseUserRoleObj
          .searchByUserTypeCaseAndStatus(searchByUserTypeCaseStatusDetails);
    } catch (final RecordNotFoundException re) {// check if the users already
                                                // exists
      // in the OrgObjectLink
      // entity. If the user already exits in the entity the
      // CaseUserRoleID is assigned in the else condition and if
      // the user does not exist, first inserts a record in the
      // OrgObjectLink entity and the id is used to insert a
      // record in CaseUserRole entity where the CaseUserRoleID
      // is used for further processing.
    }
    if (caseUserRoleKey.caseUserRoleID == 0) {

      // OrgObjectLink variables
      OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
      final OrgObjectLink orgObjectLinkObj =
        OrgObjectLinkFactory.newInstance();

      // inserts the user into OrgObjectLink only if the user
      // does not already exist
      orgObjectLinkDtls.userName = dtls.userName;
      orgObjectLinkDtls.orgObjectType = ORGOBJECTTYPE.USER;

      // BEGIN, CR00090114, RKi
      // OrgObjectLink variables
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = dtls.userName;
      try {
        orgObjectLinkDtls = orgObjectLinkObj.readByUsername(usersKey);
      } catch (final RecordNotFoundException re) {
        orgObjectLinkDtls.orgObjectLinkID = 0;
      }
      if (orgObjectLinkDtls.orgObjectLinkID == 0) {
        orgObjectLinkObj.insert(orgObjectLinkDtls);
      }
      // END, CR00090114
      caseUserRoleDtls.orgObjectLinkID = orgObjectLinkDtls.orgObjectLinkID;

      // Insert the case user role record
      caseUserRoleDtls.caseID = hearingCaseID.caseID;
      caseUserRoleDtls.caseUserRoleID = uniqueIDObj.getNextID();
      caseUserRoleDtls.fromDate = Date.getCurrentDate();
      caseUserRoleDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
      caseUserRoleDtls.typeCode = dtls.typeCode;
      // END, CR00091335
      // BEGIN, CR00071911, RKi
      caseUserRoleObj.insert(caseUserRoleDtls);
      lCaseUserRole = caseUserRoleDtls.caseUserRoleID;
    } else {
      // should only return one active record
      lCaseUserRole = caseUserRoleKey.caseUserRoleID;
      // END, CR00071911
    }
    // Count the activities associated with type, user and hearing.
    hearingUserAttendeeActivityDetails.hearingID = dtls.hearingID;
    hearingUserAttendeeActivityDetails.userName = dtls.userName;
    hearingUserAttendeeActivityDetails.typeCode = HEARINGACTIVITYTYPE.HEARING;

    count =
      hearingActivityLinkObj
        .countActiveActivityByTypeHearingIDAndUser(hearingUserAttendeeActivityDetails);

    if (count.numberOfRecords <= 0) {

      // Obtain scheduled date and time for the hearing
      hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);

      // Create the new activity
      maintainActivityDetails.activityID = uniqueIDObj.getNextID();
      maintainActivityDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
      maintainActivityDetails.caseID = hearingCaseID.caseID;
      maintainActivityDetails.priorityCode = ACTIVITYPRIORITY.DEFAULTCODE;
      maintainActivityDetails.recordStatusCode = RECORDSTATUS.DEFAULTCODE;
      maintainActivityDetails.startDateTime =
        hearingScheduleDate.scheduledDateTime;
      maintainActivityDetails.endDateTime =
        maintainActivityDetails.startDateTime.addTime(kHearingLength, 0, 0);
      maintainActivityDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;
      maintainActivityDetails.subject =
        BPOHEARING.INF_HEARING_ACTIVITY_SUBJECT.getMessageText();
      maintainActivityDetails.userName = dtls.userName;
      maintainActivityKey =
        maintainActivityObj.createActivity(maintainActivityDetails);

      hearingActivityLinkDtls.activityID = maintainActivityKey.activityID;
      hearingActivityLinkDtls.hearingID = dtls.hearingID;
      hearingActivityLinkDtls.typeCode = HEARINGACTIVITYTYPE.HEARING;
      hearingActivityLinkObj.insert(hearingActivityLinkDtls);

    }

    hearingUserRoleDtls.caseUserRoleID = lCaseUserRole;
    hearingUserRoleDtls.hearingID = dtls.hearingID;
    hearingUserRoleDtls.hearingUserRoleID = uniqueIDObj.getNextID();
    hearingUserRoleDtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;
    hearingUserRoleObj.insert(hearingUserRoleDtls);
  }

  // ___________________________________________________________________________
  /**
   * Sends notification inviting user to attend the hearing.
   * 
   * @param dtls
   * The details of the user
   */
  @Override
  protected void notify(final HearingUserDetails dtls) throws AppException,
    InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // Notification objects
    final Notification notificationObj = NotificationFactory.newInstance();

    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Read hearing case ID
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Set Notification details
    standardManualTaskDtls.dtls.concerningDtls.caseID = hearingCaseID.caseID;

    standardManualTaskDtls.dtls.taskDtls.comments =
      GeneralAppealConstants.kSpace;
    standardManualTaskDtls.dtls.taskDtls.subject =
      BPOHEARING.INF_HEARING_NOTIFICATION_SUBJECT.getMessageText();

    standardManualTaskDtls.dtls.assignDtls.assignmentID = dtls.userName;
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
      curam.appeal.sl.impl.Appeal.kAppealNotificationTask;

    // Create notification
    notificationObj.createWorkAllocationNotification(standardManualTaskDtls);

  }

  // ___________________________________________________________________________
  /**
   * Validates user details before associating them with a hearing
   * 
   * @param dtls
   * The details of the user
   */
  @Override
  protected void validateInviteUser(final HearingUserDetails dtls)
    throws AppException, InformationalException {

    // Users objects
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Users objects
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingIDUserStatusTypeKey hearingIDUserStatusTypeKey =
      new HearingIDUserStatusTypeKey();

    // Count variable
    Count count;

    // Check for valid user.
    try {
      usersKey.userName = dtls.userName;
      usersObj.readUserFullname(usersKey);
    } catch (final RecordNotFoundException e) {
      throw new AppException(BPOHEARING.ERR_USERNAME_INVALID);
    }

    // Check for user already associated with case
    hearingIDUserStatusTypeKey.hearingID = dtls.hearingID;
    hearingIDUserStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDUserStatusTypeKey.typeCode = dtls.typeCode;
    hearingIDUserStatusTypeKey.userName = dtls.userName;
    count =
      hearingUserRoleObj
        .countActiveByHearingIDTypeAndUser(hearingIDUserStatusTypeKey);

    // Check that the user does not already have this role
    if (count.numberOfRecords > 0) {

      throw new AppException(BPOHEARING.ERR_USERNAME_EXISTS);
    }

  }

  // ___________________________________________________________________________
  /**
   * Lists details about all users of the given type for the hearing.
   * 
   * @param key
   * The hearing ID
   * 
   * @return the list of user details associated with the hearing
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public HearingUserFullDetailsList listUsers(final HearingUserTypeKey key)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // HearingUserRole objects
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingUserTypeKey hearingUserTypeKey;

    // Return structure
    final HearingUserFullDetailsList hearingUserFullDetailsList =
      new HearingUserFullDetailsList();

    // Read hearing case ID
    hearingKey.hearingID = key.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // CaseUserRole Objects
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Is a type specified
    if (key.typeCode.length() != 0) {

      // Retrieve hearing user list using type
      hearingUserTypeKey =
        new curam.appeal.sl.entity.struct.HearingUserTypeKey();
      hearingUserTypeKey.hearingID = key.hearingID;
      hearingUserTypeKey.typeCode = key.typeCode;
      // BEGIN, CR00394743, JAF
      hearingUserFullDetailsList.list.dtls
        .addAll(hearingUserRoleObj
          .searchAllWithVersionNumbersByHearingIDAndType(hearingUserTypeKey).dtls);
      // END, CR00394743, JAF

      // BEGIN, CR00053295, RKi
      for (int i = 0; i < hearingUserFullDetailsList.list.dtls.size(); i++) {

        orgObjectLinkKey.orgObjectLinkID =
          hearingUserFullDetailsList.list.dtls.item(i).orgObjectLinkID;
        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        hearingUserFullDetailsList.list.dtls.item(i).fullName =
          caseOwnerDetails.userFullName;
        hearingUserFullDetailsList.list.dtls.item(i).userName =
          caseOwnerDetails.userName;
      }
      // END, CR00053295

    } else {

      // Retrieve hearing user list
      // BEGIN, CR00394743, JAF
      hearingUserFullDetailsList.list.dtls.addAll(hearingUserRoleObj
        .searchAllWithVersionNumbersByHearingID(hearingKey).dtls);
      // END, CR00394743, JAF

      // HearingServiceSupplier objects
      final HearingServiceSupplier hearingServiceSupplierObj =
        HearingServiceSupplierFactory.newInstance();
      final SupplierHearingIDAndTypeKey supplierHearingIDAndTypeKey =
        new SupplierHearingIDAndTypeKey();

      // Retrieve all service supplier users related to the hearing
      supplierHearingIDAndTypeKey.hearingID = key.hearingID;
      supplierHearingIDAndTypeKey.supplierType = APPEALSUPPLIERTYPE.USER;
      // BEGIN, CR00394743, JAF
      hearingUserFullDetailsList.list.dtls
        .addAll(hearingServiceSupplierObj
          .searchUserDetailsWithVersionNumbersByHearingID(supplierHearingIDAndTypeKey).dtls);
      // END, CR00394743, JAF

      // BEGIN, CR00053295, RKi
      for (int i = 0; i < hearingUserFullDetailsList.list.dtls.size(); i++) {

        orgObjectLinkKey.orgObjectLinkID =
          hearingUserFullDetailsList.list.dtls.item(i).orgObjectLinkID;

        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        hearingUserFullDetailsList.list.dtls.item(i).fullName =
          caseOwnerDetails.userFullName;
        hearingUserFullDetailsList.list.dtls.item(i).userName =
          caseOwnerDetails.userName;
      }
      // END, CR00053295
    }
    return hearingUserFullDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Validates the details are correct before completing a hearing.
   * 
   * @param dtls
   * Complete hearing details
   */
  @Override
  protected void validateComplete(final CompleteHearingDetails dtls)
    throws AppException, InformationalException {

    // Hearing entity variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingStatusDateDetails hearingStatusDateDetails;

    HearingDateAndType hearingDateAndType = new HearingDateAndType();

    hearingKey.hearingID = dtls.completeHearing.hearingID;

    // read hearing status
    hearingStatusDateDetails =
      hearingObj.readScheduledDateAndStatus(hearingKey);

    final InformationalManager informationalManager =
      new InformationalManager();

    // BEGIN, CR00267707, CSH
    if (!(hearingStatusDateDetails.statusCode.equals(HEARINGSTATUS.SCHEDULED) || hearingStatusDateDetails.statusCode
      .equals(HEARINGSTATUS.RESCHEDULED))) {

      throw new AppException(BPOHEARING.ERR_HEARING_STATUS);

    }
    // END, CR00267707

    hearingDateAndType = hearingObj.readScheduledDateAndType(hearingKey);

    // Only Validate Time attribute when hearing type is not a Desk-Based
    // Hearing
    if (!HEARINGTYPE.DESK.equals(hearingDateAndType.typeCode)) {

      // hearing can only be completed on or after the scheduled date
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        hearingStatusDateDetails.scheduledDateTime,
        TransactionInfo.getUserTimeZone())).after(Date.getCurrentDate())) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_COMPLETE_DATE), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);

      }
      boolean emptyDate = false;

      // Validate that an actual start time has been entered, i.e. non 00:00
      // time
      if (dtls.completeHearing.actualStartTime.equals(kZeroEPOCDate)
        || dtls.completeHearing.actualStartTime.isZero()) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_START_TIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
        emptyDate = true;
      }

      // Validate that an actual end date has been entered, i.e. non 00:00 time
      if (dtls.completeHearing.actualEndTime.equals(kZeroEPOCDate)
        || dtls.completeHearing.actualEndTime.isZero()) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_END_TIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
        emptyDate = true;
      }

      // Validate that the actual start time is before the actual end time
      if (!dtls.completeHearing.actualStartTime
        .before(dtls.completeHearing.actualEndTime) && !emptyDate) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_START_TIME_BEFORE_END_TIME),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }
      // END, CR00269419.
    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /*
   * This method validates the details being modified
   * 
   * @param details The details being modified
   */
  @Override
  protected void validateModify(final HearingModifyDetails details)
    throws AppException, InformationalException {

    // Hearing object and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingModifyValidateDetails hearingModifyValidateDetails;

    // Set the key to read the hearing details
    hearingKey.hearingID = details.hearingModifyDetails.hearingID;
    hearingModifyValidateDetails =
      hearingObj.readDetailsForModifyValidation(hearingKey);

    final InformationalManager informationalManager =
      new InformationalManager();

    if (hearingModifyValidateDetails.statusCode
      .equals(curam.codetable.HEARINGSTATUS.ADJOURNED)
      || hearingModifyValidateDetails.statusCode
        .equals(curam.codetable.HEARINGSTATUS.COMPLETED)) {

      // Validate that an actual start time has been entered, i.e.
      // non 00:00 time
      if (details.hearingModifyDetails.actualStartTime.equals(kZeroEPOCDate)
        || details.hearingModifyDetails.actualStartTime.isZero()) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_START_TIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }

      // Validate that an actual end date has been entered, i.e.
      // non 00:00 time
      if (details.hearingModifyDetails.actualEndTime.equals(kZeroEPOCDate)
        || details.hearingModifyDetails.actualEndTime.isZero()) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_END_TIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }

      // Validate that the actual start time is before the actual end time
      if (!details.hearingModifyDetails.actualStartTime
        .before(details.hearingModifyDetails.actualEndTime)) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_START_TIME_BEFORE_END_TIME),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
      informationalManager.failOperation();

    } else {

      if (!hearingModifyValidateDetails.actualStartTime
        .equals(details.hearingModifyDetails.actualStartTime)) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_FV_STARTTIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);

      }

      if (!hearingModifyValidateDetails.actualEndTime
        .equals(details.hearingModifyDetails.actualEndTime)) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_FV_ENDTIME), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);

      }
    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /*
   * This method returns the details of a hearing for modification
   * 
   * key Identifies the hearing
   */
  @Override
  public HearingModifyDetails getDetailsForModify(final HearingKey key)
    throws AppException, InformationalException {

    // Return details
    final HearingModifyDetails hearingModifyDetailsRet =
      new HearingModifyDetails();

    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingModifyDetails hearingModifyDetails;

    hearingKey.hearingID = key.hearingKey.hearingID;
    hearingModifyDetails = hearingObj.readDetailsForModify(hearingKey);

    // Assign the details
    hearingModifyDetailsRet.hearingModifyDetails.assign(hearingModifyDetails);

    // Return the details
    return hearingModifyDetailsRet;
  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for a hearing review hearing
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingReviewSummaryDetails getReviewSummaryDetails(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final HearingReviewSummaryDetails hearingReviewSummaryDetailsRet =
      new HearingReviewSummaryDetails();

    // HearingUserTypeKey object
    final HearingUserTypeKey hearingUserTypeKey = new HearingUserTypeKey();

    // HearingUserFullDetailsList object
    HearingUserFullDetailsList hearingUserFullDetailsList =
      new HearingUserFullDetailsList();
    HearingUserFullDetails hearingUserFullDetails;

    // HearingCaseUserNameDtls object
    HearingCaseUserNameDtls hearingCaseUserNameDtls;

    // Hearing entity objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingReviewSummaryDetails hearingReviewSummaryDetails;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = getCase(key).hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // get the summary details
    hearingReviewSummaryDetails =
      hearingObj.readReviewSummaryDetails(key.hearingKey);

    hearingReviewSummaryDetailsRet.assign(hearingReviewSummaryDetails);

    // Convert date times to dates
    if (!hearingReviewSummaryDetails.scheduledDateTime.isZero()) {
      hearingReviewSummaryDetailsRet.scheduledDate =
        new Date(hearingReviewSummaryDetails.scheduledDateTime.getCalendar());
    }
    if (!hearingReviewSummaryDetails.postponeDate.isZero()) {
      hearingReviewSummaryDetailsRet.postponedDate =
        new Date(hearingReviewSummaryDetails.postponeDate.getCalendar());
    }

    // format start time
    if (!hearingReviewSummaryDetails.actualStartTime.isZero()) {

      hearingReviewSummaryDetailsRet.actualFormattedStartTime =
        hearingReviewSummaryDetails.actualStartTime.toString();
    }
    // format end time
    if (!hearingReviewSummaryDetails.actualEndTime.isZero()) {

      hearingReviewSummaryDetailsRet.actualFormattedEndTime =
        hearingReviewSummaryDetails.actualEndTime.toString();
    }

    // get the reviewer list
    hearingUserTypeKey.hearingID = key.hearingKey.hearingID;
    hearingUserTypeKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
    hearingUserFullDetailsList = listUsers(hearingUserTypeKey);

    for (int i = 0; i < hearingUserFullDetailsList.list.dtls.size(); i++) {

      hearingUserFullDetails = hearingUserFullDetailsList.list.dtls.item(i);

      // Add reviewer to return struct
      hearingCaseUserNameDtls = new HearingCaseUserNameDtls();
      hearingCaseUserNameDtls.fullName = hearingUserFullDetails.fullName;
      hearingCaseUserNameDtls.userName = hearingUserFullDetails.userName;

      hearingReviewSummaryDetailsRet.hearingReviewerList
        .addRef(hearingCaseUserNameDtls);
    }

    return hearingReviewSummaryDetailsRet;
  }

  // ___________________________________________________________________________
  /*
   * Lists the hearing home page details for a hearing
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return the home page details
   */
  @Override
  public HearingSummaryDetails getSummaryDetails(final HearingKey key)
    throws AppException, InformationalException {

    // Return details
    final HearingSummaryDetails hearingSummaryDetailsRet =
      new HearingSummaryDetails();

    // Hearing entity object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    // Address object
    final Address addressObj = AddressFactory.newInstance();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = getCase(key).hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    final HearingParticipantKey hearingParticipantKey =
      new HearingParticipantKey();

    curam.appeal.sl.entity.struct.HearingSummaryDetails hearingSummaryDetails =
      new curam.appeal.sl.entity.struct.HearingSummaryDetails();

    hearingParticipantKey.hearingID = key.hearingKey.hearingID;

    // BEGIN, CR00118193, RKi
    final curam.core.sl.entity.intf.ExternalPartyOffice externalPartyOffice =
      ExternalPartyOfficeFactory.newInstance();
    ExternalPartyOfficeDtls externalPartyOfficeDtls =
      new ExternalPartyOfficeDtls();
    final ExternalPartyOfficeKey externalPartyOfficeKey =
      new ExternalPartyOfficeKey();
    final Address address = AddressFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingKey.hearingID = key.hearingKey.hearingID;
    final HearingDtls hearingDtls = hearingObj.read(hearingKey);

    // get the summary details
    if (!hearingDtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      hearingSummaryDetails =
        hearingObj.readSummaryDetails(hearingParticipantKey);
    }

    // BEGIN, CR00123228, RKi
    hearingSummaryDetailsRet.locationType = hearingDtls.locationType;
    // END, CR00123228
    // get the address details - check the type to determine what address
    // to read
    // variable to hold returned address
    OtherAddressData otherAddressData = new OtherAddressData();

    if (hearingDtls.typeCode.equals(HEARINGTYPE.LOCATION)) {
      if (hearingDtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
        externalPartyOfficeKey.externalPartyOfficeID =
          hearingDtls.externalOfficeID;
        final AddressKey addressKey = new AddressKey();

        externalPartyOfficeDtls =
          externalPartyOffice.read(externalPartyOfficeKey);
        addressKey.addressID = externalPartyOfficeDtls.primaryAddressID;
        otherAddressData = address.readAddressData(addressKey);
        if (!hearingDtls.actualStartTime.equals(DateTime.kZeroDateTime)) {
          hearingSummaryDetailsRet.actualFormattedStartTime =
            hearingDtls.actualStartTime.toString();
        }
        if (!hearingDtls.actualEndTime.equals(DateTime.kZeroDateTime)) {
          hearingSummaryDetailsRet.actualFormattedEndTime =
            hearingDtls.actualEndTime.toString();
        }
        hearingSummaryDetailsRet.comments = hearingDtls.comments;
        hearingSummaryDetailsRet.versionNo = hearingDtls.versionNo;
        hearingSummaryDetailsRet.typeCode = hearingDtls.typeCode;
        hearingSummaryDetailsRet.scheduledDateTime =
          hearingDtls.scheduledDateTime;
        hearingSummaryDetailsRet.statusCode = hearingDtls.statusCode;
        hearingSummaryDetailsRet.postponeDate = hearingDtls.postponeDate;
        hearingSummaryDetailsRet.postponeReasonCode =
          hearingDtls.postponeReasonCode;
        hearingSummaryDetailsRet.postponeReasonText =
          hearingDtls.postponeReasonText;
        hearingSummaryDetailsRet.noticeDate = hearingDtls.noticeDate;
        hearingSummaryDetailsRet.referenceNumber =
          hearingDtls.referenceNumber;
        // BEGIN, CR00123104, RKi
        hearingSummaryDetailsRet.locationName = externalPartyOfficeDtls.name;
        // END, CR00123104
      } else { // END, CR00118193
        final curam.core.intf.Location locationObj =
          LocationFactory.newInstance();
        final LocationKeyStruct locationKeyStruct = new LocationKeyStruct();

        locationKeyStruct.locationID = hearingSummaryDetails.locationID;

        final UserAddressDetailsList userAddressDetailsList =
          locationObj.searchLocationAddress(locationKeyStruct);

        // There should always be 1 address only
        if (!userAddressDetailsList.dtls.isEmpty()) {
          otherAddressData.addressData =
            userAddressDetailsList.dtls.item(0).addressData;
        }
      }

    } else if (hearingDtls.typeCode.equals(HEARINGTYPE.HOME)) {

      // Variables to read the Address
      final AddressKey addressKey = new AddressKey();

      addressKey.addressID = hearingSummaryDetails.addressID;
      otherAddressData.addressData =
        addressObj.readAddressData(addressKey).addressData;

    } else {

      // Variables to read the Address of the Organization
      final Organisation organisationObj = OrganisationFactory.newInstance();
      final OrganisationKey organisationKey = new OrganisationKey();

      organisationKey.organisationID = kOrganizationID;

      otherAddressData.addressData =
        organisationObj.readOrganisationAddress(organisationKey).addressData;
    }

    if (!hearingDtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      // format start time
      if (!hearingSummaryDetails.actualStartTime.isZero()) {

        // BEGIN, CR00095666, RKi
        hearingSummaryDetails.actualStartTime.getCalendar().setTimeZone(
          TransactionInfo.getServerTimeZone());
        hearingSummaryDetails.actualStartTime =
          TimeZoneUtility.getTimeZoneAdjustedDateTime(
            hearingSummaryDetails.actualStartTime,
            TransactionInfo.getUserTimeZone());
        // END, CR00095666
        hearingSummaryDetailsRet.actualFormattedStartTime =
          hearingSummaryDetails.actualStartTime.toString();
      }

      // format end time
      if (!hearingSummaryDetails.actualEndTime.isZero()) {

        // BEGIN, CR00095666, RKi
        hearingSummaryDetails.actualEndTime.getCalendar().setTimeZone(
          TransactionInfo.getServerTimeZone());
        hearingSummaryDetails.actualEndTime =
          TimeZoneUtility.getTimeZoneAdjustedDateTime(
            hearingSummaryDetails.actualEndTime,
            TransactionInfo.getUserTimeZone());
        // END, CR00095666

        hearingSummaryDetailsRet.actualFormattedEndTime =
          hearingSummaryDetails.actualEndTime.toString();
      }
    }

    // convert the data to a format for viewing
    addressObj.getAddressStrings(otherAddressData);

    hearingSummaryDetails.locationName = otherAddressData.addressData;
    // BEGIN, CR00118193, RKi
    if (hearingDtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      final HearingIDCaseParticipantRoleTypeKey caseParticipantRoleTypeKey =
        new HearingIDCaseParticipantRoleTypeKey();

      caseParticipantRoleTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      caseParticipantRoleTypeKey.hearingID = hearingKey.hearingID;
      final ConcernRoleNameDetails concernRoleNameDetails =
        hearingObj
          .readOfficialNameByHearingIDTypeCode(caseParticipantRoleTypeKey);

      hearingSummaryDetailsRet.userName =
        concernRoleNameDetails.concernRoleName;
      hearingSummaryDetailsRet.fullName =
        concernRoleNameDetails.concernRoleName; // END, CR00118193
      // BEGIN, CR00124801, RKi
      // assigning the concern role identifier in case of external user
      // so that it can be used in the resolve page and direct to the external
      // user home page.
      final HearingParticipation hearingParticipation =
        HearingParticipationFactory.newInstance();
      final HearingIDStatusKeyHR hearingIDStatusKeyHR =
        new HearingIDStatusKeyHR();

      hearingIDStatusKeyHR.hearingID = hearingKey.hearingID;
      hearingIDStatusKeyHR.participantType =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
      final curam.appeal.sl.entity.struct.HearingParticipatedDetailsList hearingParticipatedDetailsList =
        hearingParticipation
          .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

      // END, CR00131857
      hearingSummaryDetailsRet.caseUserRoleID =
        hearingParticipatedDetailsList.dtls.item(0).participantRoleID;
      // END, CR00124801
    } else {
      // BEGIN, CR00053295, RKi
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();

      final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
      CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

      caseUserRoleKey.caseUserRoleID = hearingSummaryDetails.caseUserRoleID;
      // BEGIN, CR00133013, RKi
      hearingSummaryDetails.caseUserRoleID = 0;
      // END, CR00133013
      final CaseUserRoleDtls caseUserRoleDtls =
        caseUserRoleObj.read(caseUserRoleKey);

      orgObjectLinkKey.orgObjectLinkID = caseUserRoleDtls.orgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      hearingSummaryDetails.userName = caseOwnerDetails.userName;
      hearingSummaryDetails.fullName = caseOwnerDetails.userFullName;
      hearingSummaryDetailsRet.assign(hearingSummaryDetails);
    }
    // END, CR00053295

    return hearingSummaryDetailsRet;

  }

  // ___________________________________________________________________________
  /*
   * This method modifies a hearing
   * 
   * @param details Identifies the hearing
   */
  @Override
  public void modify(final HearingModifyDetails details) throws AppException,
    InformationalException {

    // Hearing business objects
    final HearingModifyDetails hearingModifyDetails_bo =
      new HearingModifyDetails();

    // Hearing entity objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final curam.appeal.sl.entity.struct.HearingModifyDetails hearingModifyDetails =
      new curam.appeal.sl.entity.struct.HearingModifyDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();
    final HearingKey hearingKey_security = new HearingKey();

    // Validate security for reading an appeal case
    hearingKey_security.hearingKey.hearingID =
      details.hearingModifyDetails.hearingID;
    validateSecurityKey.caseID =
      getCase(hearingKey_security).hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    hearingModifyDetails_bo.hearingModifyDetails.actualEndTime =
      details.hearingModifyDetails.actualEndTime;
    hearingModifyDetails_bo.hearingModifyDetails.actualStartTime =
      details.hearingModifyDetails.actualStartTime;
    hearingModifyDetails_bo.hearingModifyDetails.comments =
      details.hearingModifyDetails.comments;
    hearingModifyDetails_bo.hearingModifyDetails.hearingID =
      details.hearingModifyDetails.hearingID;
    hearingModifyDetails_bo.hearingModifyDetails.versionNo =
      details.hearingModifyDetails.versionNo;

    // Validate the details
    validateModify(hearingModifyDetails_bo);

    hearingKey.hearingID = details.hearingModifyDetails.hearingID;

    hearingModifyDetails.actualEndTime =
      details.hearingModifyDetails.actualEndTime;
    hearingModifyDetails.actualStartTime =
      details.hearingModifyDetails.actualStartTime;
    hearingModifyDetails.comments = details.hearingModifyDetails.comments;
    hearingModifyDetails.hearingID = details.hearingModifyDetails.hearingID;
    hearingModifyDetails.versionNo = details.hearingModifyDetails.versionNo;

    // BEGIN, CR00125204, RKi
    // the start time and end time are appended with the date and time
    final Calendar startTime =
      details.hearingModifyDetails.actualStartTime.getCalendar();

    startTime.set(Calendar.HOUR, startTime.get(Calendar.HOUR));
    startTime.set(Calendar.MINUTE, startTime.get(Calendar.MINUTE));
    startTime.set(Calendar.SECOND, startTime.get(Calendar.SECOND));
    startTime.set(Calendar.YEAR, DateTime.getCurrentDateTime().getCalendar()
      .get(Calendar.YEAR));
    startTime.set(Calendar.MONTH, DateTime.getCurrentDateTime().getCalendar()
      .get(Calendar.MONTH));
    startTime.set(Calendar.DAY_OF_MONTH, DateTime.getCurrentDateTime()
      .getCalendar().get(Calendar.DAY_OF_MONTH));

    startTime.setTimeZone(TransactionInfo.getUserTimeZone());
    hearingModifyDetails.actualStartTime = new DateTime(startTime);

    final Calendar endTime =
      details.hearingModifyDetails.actualEndTime.getCalendar();

    endTime.set(Calendar.HOUR, endTime.get(Calendar.HOUR));
    endTime.set(Calendar.MINUTE, endTime.get(Calendar.MINUTE));
    endTime.set(Calendar.SECOND, endTime.get(Calendar.SECOND));
    endTime.set(Calendar.YEAR, DateTime.getCurrentDateTime().getCalendar()
      .get(Calendar.YEAR));
    endTime.set(Calendar.MONTH, DateTime.getCurrentDateTime().getCalendar()
      .get(Calendar.MONTH));
    endTime.set(Calendar.DAY_OF_MONTH, DateTime.getCurrentDateTime()
      .getCalendar().get(Calendar.DAY_OF_MONTH));

    endTime.setTimeZone(TransactionInfo.getUserTimeZone());
    hearingModifyDetails.actualEndTime = new DateTime(endTime);
    // END, CR00125204
    // Modify the hearing
    hearingObj.modify(hearingKey, hearingModifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates the events and tasks needed to complete a hearing.
   * 
   * @param dtls
   * Complete hearing details
   */
  @Override
  protected void
    createCompleteEventAndTask(final CompleteHearingDetails dtls)
      throws AppException, InformationalException {

    // Hearing entity variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // HearingUserRole variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    HearingCaseUserDtlsList hearingCaseUserDtlsList;
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();

    // CaseUserRole variables
    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // CaseEvent variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // UniqueID generation
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Current Date
    final Date currentDate = Date.getCurrentDate();

    hearingKey.hearingID = dtls.completeHearing.hearingID;

    // read caseID
    hearingCaseID = hearingObj.readCase(hearingKey);

    // assign values to closure record (case event)
    // Begin CR00117296 LP
    // Events raised are same for both Appeals and LA
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = hearingCaseID.caseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;

    caseEventDtls.relatedID = dtls.completeHearing.hearingID;

    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.eventTypeCode =
      curam.codetable.CASEEVENTTYPE.HEARINGREVIEWCOMPLETED;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // save CaseEvent to database
    caseEventObj.insert(caseEventDtls);

    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Tasks
                                                                          // are
                                                                          // to
                                                                          // be
                                                                          // created
                                                                          // for
                                                                          // LA
    } else {
      // Appeal entity variables
      final curam.appeal.sl.entity.intf.Appeal appealObj =
        curam.appeal.sl.entity.fact.AppealFactory.newInstance();
      final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

      // Appeals
      AppealTypeDetails appealTypeDetails;

      appealCaseIDKey.caseID = hearingCaseID.caseID;
      // read appeal type
      appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);
      if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        hearingUserRoleStatusKey.hearingID = dtls.completeHearing.hearingID;
        hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
      } else if (appealTypeDetails.appealTypeCode
        .equals(APPEALTYPE.HEARINGREVIEW)) {
        hearingUserRoleStatusKey.hearingID = dtls.completeHearing.hearingID;
        hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.REVIEWER;

      } else {
        throw new AppException(
          curam.message.BPOHEARING.ERR_COMPLETE_HEARING_TYPE);
      }

      // search for reviewers
      hearingCaseUserDtlsList =
        hearingUserRoleObj
          .searchActiveByHearingIDAndRoletype(hearingUserRoleStatusKey);

      for (int i = 0; i < hearingCaseUserDtlsList.dtls.size(); i++) {

        // BEGIN, CR00053295, RKi
        orgObjectLinkKey.orgObjectLinkID =
          hearingCaseUserDtlsList.dtls.item(i).orgObjectLinkID;
        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        // END, CR00053295
        // Create a task

        // Set the reason for the task
        standardManualTaskDtls.dtls.taskDtls.comments =
          curam.message.BPOHEARING.INF_HEARING_REVIEW_COMPLETED_COMMENTS
            .getMessageText();

        // Set the subject for the task to Hearing completed
        standardManualTaskDtls.dtls.taskDtls.subject =
          curam.message.BPOHEARING.INF_HEARING_REVIEW_COMPLETED_SUBJECT
            .getMessageText();

        // Set the priority for the task
        standardManualTaskDtls.dtls.taskDtls.priority =
          curam.codetable.TASKPRIORITY.NORMAL;

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          hearingCaseID.caseID;
        standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
          curam.appeal.sl.impl.Appeal.kAppealStandardTask;

        // Assign task
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userName;

        standardManualTaskDtls.dtls.assignDtls.assignType =
          curam.codetable.TARGETITEMTYPE.USER;

        standardManualTaskDtls.dtls.taskDtls.status =
          curam.codetable.TASKSTATUS.DEFAULTCODE;

        // create the task
        workAllocationTaskObj.createManualTask(standardManualTaskDtls);

      }
    }
    // End CR00117296 LP
  }

  // ___________________________________________________________________________
  /**
   * Completes a hearing.
   * 
   * @param details
   * Complete hearing details
   * @param appealType
   * Hearing appeal type code
   */
  @Override
  public void complete(final CompleteHearingDetails details,
    final HearingAppealTypeCode appealType) throws AppException,
    InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    final HearingAttendance hearingAttendance = new HearingAttendance();
    final HearingTimeStatusModifyDetails hearingTimeStatusModifyDetails =
      new HearingTimeStatusModifyDetails();

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionByStatusKey hearingTranscriptionByStatusKey =
      new HearingTranscriptionByStatusKey();
    TranscriptionRequestIDKeyList transcriptionRequestIDKeyList;

    // Work Flow event object
    final Event closeTaskEvent = new Event();

    hearingKey.hearingID = details.completeHearing.hearingID;

    // read caseID
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // validate complete
    validateComplete(details);

    hearingAttendance.hearingAttendanceDetailsList
      .assign(details.hearingAttendanceDetailsList);

    hearingAttendance.hearingVersion.hearingID =
      details.completeHearing.hearingID;
    hearingAttendance.hearingVersion.versionNo =
      details.completeHearing.versionNo;

    // update attendance details
    if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      updateAttendance(hearingAttendance);
    }

    hearingKey.hearingID = details.completeHearing.hearingID;
    hearingTimeStatusModifyDetails.actualStartTime =
      details.completeHearing.actualStartTime;
    hearingTimeStatusModifyDetails.actualEndTime =
      details.completeHearing.actualEndTime;
    hearingTimeStatusModifyDetails.statusCode = HEARINGSTATUS.COMPLETED;
    hearingTimeStatusModifyDetails.versionNo =
      details.completeHearing.versionNo;

    // modify hearing time and status details
    hearingObj.modifyStatusAndTimeDetails(hearingKey,
      hearingTimeStatusModifyDetails);

    hearingTranscriptionByStatusKey.hearingID =
      details.completeHearing.hearingID;
    hearingTranscriptionByStatusKey.recordStatusCode = RECORDSTATUS.NORMAL;

    // read transcription requests
    transcriptionRequestIDKeyList =
      hearingTranscriptionRequestObj
        .searchActiveByHearingID(hearingTranscriptionByStatusKey);

    if (transcriptionRequestIDKeyList.dtls.size() > 0) {
      // if hearing transcription is requested case owner must be notified to
      // send a copy of the transcription to the requester

      // Case Header variables
      final OwnerNameAndFullName ownerNameAndFullName =
        new OwnerNameAndFullName();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // Notification object and manipulation variables
      final Notification notificationObj = NotificationFactory.newInstance();

      final StandardManualTaskDtls standardManualTaskDtls =
        new StandardManualTaskDtls();

      caseHeaderKey.caseID = hearingCaseID.caseID;

      // read case owner
      // BEGIN, CR00053295, RKi
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();
      CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

      caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
      ownerNameAndFullName.userName = caseOwnerDetails.userFullName;
      // END, CR00053295

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID =
        hearingCaseID.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        BPOHEARING.INF_HEARING_TRANSCRIPTION_REASON.getMessageText();
      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOHEARING.INF_HEARING_TRANSCRIPTION_SUBJECT.getMessageText();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        ownerNameAndFullName.userName;

      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
        curam.appeal.sl.impl.Appeal.kAppealNotificationTask;

      // Create notification
      notificationObj
        .createWorkAllocationNotification(standardManualTaskDtls);

    }

    // BEGIN, CR00115728, RKi
    createCompleteEventAndTask(details);
    // END, CR00115728
    // Raise work flow event to close the complete hearing task
    closeTaskEvent.eventKey.eventClass =
      curam.appeal.sl.impl.Appeal.kEventClass;
    closeTaskEvent.eventKey.eventType =
      curam.appeal.sl.impl.Appeal.kAppealCloseCompleteHearingTask;
    closeTaskEvent.primaryEventData = details.completeHearing.hearingID;

    EventService.raiseEvent(closeTaskEvent);

    // BEGIN, CR00323206, KRK
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    appealCaseKey.caseID = hearingCaseID.caseID;

    final CaseIDDeadlineDate caseIDDeadlineDate = new CaseIDDeadlineDate();

    caseIDDeadlineDate.deadlineDate =
      appealObj.calculateDeadlineDate(appealCaseKey).date;
    caseIDDeadlineDate.caseID = hearingCaseID.caseID;

    appealObj.createDeadlineTask(caseIDDeadlineDate);
    // END, CR00323206

    // BEGIN, CR CR00049931, NSP
    if (hearingCaseID.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingCaseID.caseID;
      if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_COMPLETED;
      } else if (appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_REVIEW_COMPLETED;
      }

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = hearingCaseID.caseID;
      curam.core.sl.struct.ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new curam.core.sl.struct.ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog caseTransactionLogObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls transactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911

      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {
            transactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            transactionDtls.userName = systemUser.getUserDetails().userName;
            if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_CASE_CREATED;
            }
            if (appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED;
            }
            transactionDtls.caseID = details.completeHearing.hearingID;
            caseTransactionLogObj.insert(transactionDtls);
          }
        }
      }
    }
    // END, CR CR00049931
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of user attendees and their recorded participation for a
   * hearing.
   * 
   * @param key
   * Hearing unique identifier
   * @return List of hearing attendees
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public HearingAttendance listAttendance(final HearingKey key)
    throws AppException, InformationalException {

    // to be returned
    final HearingAttendance hearingAttendance = new HearingAttendance();
    HearingAttendanceDetails hearingAttendanceDetails;

    // Hearing entity variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // Hearing Service Supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
      new HearingServiceSupplierInterpreterHearingKey();
    HearingInterpreterNameUserRoleDetailsList hearingInterpreterNameUserRoleDetailsList;
    HearingAttendeeUserNameDetailsList hearingAttendeeUserNameDetailsList;

    // HearingUserRole variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();

    // Active Attendee variables
    final HearingAttendeeKey hearingAttendeeKey = new HearingAttendeeKey();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Read hearing caseID
    hearingKey.hearingID = key.hearingKey.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    hearingServiceSupplierInterpreterHearingKey.hearingID =
      key.hearingKey.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    // Search for internal interpreters
    hearingServiceSupplierInterpreterHearingKey.hearingID =
      key.hearingKey.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEUSERROLETYPE.INTERPRETER;

    hearingInterpreterNameUserRoleDetailsList =
      hearingServiceSupplierObj
        .searchActiveInterpreterNameAndCaseUserRoleByHearingID(hearingServiceSupplierInterpreterHearingKey);

    // BEGIN, CR00246931, GP
    for (final HearingInterpreterNameUserRoleDetails hearingInterpreterNameUserRoleDetails : hearingInterpreterNameUserRoleDetailsList.dtls
      .items()) {

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        hearingInterpreterNameUserRoleDetails.orgObjectLinkID;
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      hearingInterpreterNameUserRoleDetails.fullName =
        caseOwnerDetails.userFullName;
      // END, CR00053295

      hearingAttendanceDetails = new HearingAttendanceDetails();

      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingInterpreterNameUserRoleDetails.versionNo;
      hearingAttendanceDetails.hearingAttendanceKey =
        hearingInterpreterNameUserRoleDetails.hearingServiceSupplierID;
      hearingAttendanceDetails.attendanceCode =
        HEARINGATTENDANCE.INTERNAL_INTERPRETER;
      hearingAttendanceDetails.displayName =
        hearingInterpreterNameUserRoleDetails.fullName;

      hearingAttendanceDetails.userName = caseOwnerDetails.userName;
      hearingAttendanceDetails.participatedCode =
        hearingInterpreterNameUserRoleDetails.participatedCode;

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);

    }

    // Search active attendee names.
    hearingAttendeeKey.excludeTypeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    hearingAttendeeKey.recordStatus = RECORDSTATUS.NORMAL;
    hearingAttendeeKey.hearingID = key.hearingKey.hearingID;

    hearingAttendeeUserNameDetailsList =
      hearingUserRoleObj
        .searchActiveAttendeeNamesByHearingID(hearingAttendeeKey);

    for (final HearingAttendeeUserNameDetails hearingAttendeeUserNameDetails : hearingAttendeeUserNameDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        hearingAttendeeUserNameDetails.orgObjectLinkID;
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      hearingAttendeeUserNameDetails.fullName = caseOwnerDetails.userFullName;
      // END, CR00053295

      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingAttendeeUserNameDetails.versionNo;
      hearingAttendanceDetails.hearingAttendanceKey =
        hearingAttendeeUserNameDetails.hearingUserRoleID;
      hearingAttendanceDetails.attendanceCode =
        hearingAttendeeUserNameDetails.typeCode;
      hearingAttendanceDetails.userName = caseOwnerDetails.userName;
      hearingAttendanceDetails.displayName =
        hearingAttendeeUserNameDetails.fullName;
      hearingAttendanceDetails.participatedCode =
        hearingAttendeeUserNameDetails.participatedCode;

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);

    }
    return hearingAttendance;

  }

  /**
   * Returns the list of Participant attendees and their recorded participation
   * for a hearing.
   * 
   * @param key contains hearing key.
   * @return List of hearing attendees.
   * 
   * @throws InformationalException Generic exception signature.
   * @throws AppException Generic exception signature.
   */
  @Override
  public HearingAttendance listParticipantAttendance(final HearingKey key)
    throws AppException, InformationalException {

    final HearingAttendance hearingAttendance = new HearingAttendance();
    HearingAttendanceDetails hearingAttendanceDetails;

    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    HearingParticipatedCodeAndVersionNoDetails hearingParticipatedCodeAndVersionNoDetails;

    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeNameParticipantDetailsList hearingRepresentativeNameParticipantDetailsList;

    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    final HearingIDStatusKeyHW hearingIDStatusKeyHW =
      new HearingIDStatusKeyHW();
    HearingWitnessNameAndParticipantDetailsList hearingWitnessNameAndParticipantDetailsList;

    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
      new HearingServiceSupplierInterpreterHearingKey();
    HearingInterpreterNameParticipantDetailsList hearingInterpreterNameParticipantDetailsList;

    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Read hearing caseID.
    hearingKey.hearingID = key.hearingKey.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Validate security for maintaining an appeal case.
    validateSecurityKey.caseID = hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read hearing version number and participated codes.
    hearingParticipatedCodeAndVersionNoDetails =
      hearingObj.readParticipatedAndVersionNoDetails(hearingKey);

    hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    // Search for representatives.
    hearingRepresentativeNameParticipantDetailsList =
      hearingRepresentativeObj
        .searchActiveHearingRepNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHR);

    for (final HearingRepresentativeNameParticipantDetails hearingRepNameDetails : hearingRepresentativeNameParticipantDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();

      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingRepNameDetails.versionNo;
      hearingAttendanceDetails.hearingAttendanceKey =
        hearingRepNameDetails.hearingRepresentativeID;
      hearingAttendanceDetails.attendanceCode =
        HEARINGATTENDANCE.HEARING_REPRESENTATIVE;
      hearingAttendanceDetails.caseParticipantRoleID =
        hearingRepNameDetails.caseParticipantRoleID;
      hearingAttendanceDetails.displayName = hearingRepNameDetails.fullName;
      hearingAttendanceDetails.participatedCode =
        hearingRepNameDetails.participatedCode;

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);

    }

    hearingIDStatusKeyHW.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHW.recordStatus = RECORDSTATUS.NORMAL;

    // Search for witnesses.
    hearingWitnessNameAndParticipantDetailsList =
      hearingWitnessObj
        .searchActiveHearingWitnessNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHW);

    for (final HearingWitnessNameAndParticipantDetails hearingWitnessNameAndParticipantDetails : hearingWitnessNameAndParticipantDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();
      hearingAttendanceDetails.hearingAttendanceKey =
        hearingWitnessNameAndParticipantDetails.hearingWitnessID;
      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingWitnessNameAndParticipantDetails.versionNo;
      hearingAttendanceDetails.attendanceCode = HEARINGATTENDANCE.WITNESS;
      hearingAttendanceDetails.caseParticipantRoleID =
        hearingWitnessNameAndParticipantDetails.caseParticipantRoleID;
      hearingAttendanceDetails.displayName =
        hearingWitnessNameAndParticipantDetails.fullName;

      hearingAttendanceDetails.participatedCode =
        hearingWitnessNameAndParticipantDetails.participatedCode;

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);
    }

    hearingServiceSupplierInterpreterHearingKey.hearingID =
      key.hearingKey.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    // Search for external interpreters.
    hearingInterpreterNameParticipantDetailsList =
      hearingServiceSupplierObj
        .searchActiveInterpreterNameAndCaseParticipantByHearingID(hearingServiceSupplierInterpreterHearingKey);

    for (final HearingInterpreterNameParticipantDetails hearingInterpreterNameParticipantDetails : hearingInterpreterNameParticipantDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();
      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingInterpreterNameParticipantDetails.versionNo;
      hearingAttendanceDetails.hearingAttendanceKey =
        hearingInterpreterNameParticipantDetails.hearingServiceSupplierID;
      hearingAttendanceDetails.attendanceCode =
        HEARINGATTENDANCE.EXTERNAL_INTERPRETER;

      hearingAttendanceDetails.caseParticipantRoleID =
        hearingInterpreterNameParticipantDetails.caseParticipantRoleID;
      hearingAttendanceDetails.displayName =
        hearingInterpreterNameParticipantDetails.fullName;
      hearingAttendanceDetails.participatedCode =
        hearingInterpreterNameParticipantDetails.participatedCode;

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);
    }

    caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    // Search for third party.
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // List of active Third Parties CaseParticipantRoleId.
    final List<Long> activeCaseParticipantRoleList = new ArrayList<Long>();
    final ThirdParty thirdPartyObj = ThirdPartyFactory.newInstance();

    // List of active Third Parties for the Hearing.
    final ThirdPartyKeyList thirdPartyKeyList =
      thirdPartyObj.searchThirdPartyByHearingID(hearingKey);

    for (final ThirdPartyKey thirdPartyKey : thirdPartyKeyList.dtls.items()) {

      final ThirdPartyDtls thirdPartyDtls = thirdPartyObj.read(thirdPartyKey);

      if (thirdPartyDtls.attendanceRequired) {
        activeCaseParticipantRoleList.add(new Long(
          thirdPartyDtls.caseParticipantRoleID));
      }
    }

    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    final ReadParticipatedCodeKeys readParticipatedCodeKeys =
      new ReadParticipatedCodeKeys();

    readParticipatedCodeKeys.hearingID = key.hearingKey.hearingID;

    for (final CaseParticipantRoleNameDetails caseParticipantRoleNameDetails : caseParticipantRoleNameDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();
      hearingAttendanceDetails.hearingAttendanceKey =
        key.hearingKey.hearingID;
      hearingAttendanceDetails.attendanceCode = HEARINGATTENDANCE.THIRDPARTY;

      hearingAttendanceDetails.caseParticipantRoleID =
        caseParticipantRoleNameDetails.caseParticipantRoleID;
      hearingAttendanceDetails.displayName =
        caseParticipantRoleNameDetails.concernRoleName;

      hearingAttendanceDetails.hearingAttendanceKey =
        key.hearingKey.hearingID;
      try {
        readParticipatedCodeKeys.caseParticipantRoleID =
          hearingAttendanceDetails.caseParticipantRoleID;
        hearingAttendanceDetails.participatedCode =
          hearingParticipationObj
            .readParticipatedCodeByCaseParticipantRoleID(readParticipatedCodeKeys).participatedCode;

      } catch (final RecordNotFoundException e) {
        hearingAttendanceDetails.participatedCode =
          HEARINGPARTICIPATION.NOTHELD;
      }

      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingParticipatedCodeAndVersionNoDetails.versionNo;

      // Only if the ThirdParty is active, add to the attendee list.
      if (activeCaseParticipantRoleList.contains(new Long(
        hearingAttendanceDetails.caseParticipantRoleID))) {

        // Add to the list.
        hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
          .addRef(hearingAttendanceDetails);
      }

    }

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

      hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
      hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
      hearingIDStatusKeyHR.participantType =
        CASEPARTICIPANTROLETYPE.RESPONDENT;

      final HearingParticipation hearingParticipantObj =
        HearingParticipationFactory.newInstance();

      // Search for legal case Participants and respondents.
      final HearingParticipatedDetailsList detailsList =
        new HearingParticipatedDetailsList();

      detailsList.dtls.assign(hearingParticipantObj
        .searchHearingParticipantsByHearingID(hearingIDStatusKeyHR));

      // Get legalCase participants and assign it to return object.
      for (final HearingParticipatedDetails hearingParticipatedDetails : detailsList.dtls.dtls
        .items()) {

        hearingAttendanceDetails = new HearingAttendanceDetails();

        if (hearingParticipatedDetails.participantType
          .equals(CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL)) {
          continue;
        }

        hearingAttendanceDetails.hearingAttendanceVersionNo =
          hearingParticipatedDetails.versionNo;
        hearingAttendanceDetails.hearingAttendanceKey =
          hearingParticipatedDetails.hearingParticipationID;
        if (hearingParticipatedDetails.participantType
          .equals(CASEPARTICIPANTROLETYPE.RESPONDENT)) {

          hearingAttendanceDetails.attendanceCode =
            HEARINGATTENDANCE.RESPONDENT;
        } else if (hearingParticipatedDetails.participantType
          .equals(CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT)) {

          hearingAttendanceDetails.attendanceCode =
            HEARINGATTENDANCE.LALEGALPARTICIPANT;
        } else {
          continue;
        }

        hearingAttendanceDetails.displayName =
          hearingParticipatedDetails.fullName;
        hearingAttendanceDetails.participatedCode =
          hearingParticipatedDetails.participatedCode;
        hearingAttendanceDetails.caseParticipantRoleID =
          hearingParticipatedDetails.caseParticipantRoleID;
        hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
          .addRef(hearingAttendanceDetails);
      }

      caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;

      // Search for respondent.
      caseParticipantRoleNameDetailsList =
        caseParticipantRole_eoObj
          .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      for (final CaseParticipantRoleNameDetails caseParticipantRoleNameDetails : caseParticipantRoleNameDetailsList.dtls
        .items()) {

        hearingAttendanceDetails = new HearingAttendanceDetails();

        hearingAttendanceDetails.hearingAttendanceVersionNo =
          hearingParticipatedCodeAndVersionNoDetails.versionNo;
        hearingAttendanceDetails.hearingAttendanceKey =
          key.hearingKey.hearingID;
        hearingAttendanceDetails.attendanceCode =
          HEARINGATTENDANCE.LALEGALPARTICIPANT;
        hearingAttendanceDetails.caseParticipantRoleID =
          caseParticipantRoleNameDetails.caseParticipantRoleID;
        hearingAttendanceDetails.displayName =
          caseParticipantRoleNameDetails.concernRoleName;

        try {

          readParticipatedCodeKeys.caseParticipantRoleID =
            hearingAttendanceDetails.caseParticipantRoleID;
          hearingParticipationObj
            .readParticipatedCodeByCaseParticipantRoleID(readParticipatedCodeKeys);

          // If the record is present then we would have got it from the
          // previous read itself. So skip this record.
          continue;

        } catch (final Exception e) {
          hearingAttendanceDetails.participatedCode =
            HEARINGPARTICIPATION.NOTHELD;
        }

        // Add to the list.
        hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
          .addRef(hearingAttendanceDetails);
      }

    } else {
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
      caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;

      // Search for appellant.
      caseParticipantRoleNameDetailsList =
        caseParticipantRole_eoObj
          .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      readParticipatedCodeKeys.hearingID = key.hearingKey.hearingID;

      for (final CaseParticipantRoleNameDetails caseParticipantRoleNameDetails : caseParticipantRoleNameDetailsList.dtls
        .items()) {

        hearingAttendanceDetails = new HearingAttendanceDetails();
        hearingAttendanceDetails.hearingAttendanceVersionNo =
          hearingParticipatedCodeAndVersionNoDetails.versionNo;

        readParticipatedCodeKeys.caseParticipantRoleID =
          caseParticipantRoleNameDetails.caseParticipantRoleID;

        hearingAttendanceDetails.hearingAttendanceKey =
          key.hearingKey.hearingID;
        hearingAttendanceDetails.attendanceCode = HEARINGATTENDANCE.APPELLANT;
        hearingAttendanceDetails.caseParticipantRoleID =
          caseParticipantRoleNameDetails.caseParticipantRoleID;
        hearingAttendanceDetails.displayName =
          caseParticipantRoleNameDetails.concernRoleName;

        try {

          readParticipatedCodeKeys.caseParticipantRoleID =
            hearingAttendanceDetails.caseParticipantRoleID;
          hearingAttendanceDetails.participatedCode =
            hearingParticipationObj
              .readParticipatedCodeByCaseParticipantRoleID(readParticipatedCodeKeys).participatedCode;
        } catch (final Exception e) {
          hearingAttendanceDetails.participatedCode =
            HEARINGPARTICIPATION.NOTHELD;
        }

        // Add to the list.
        hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
          .addRef(hearingAttendanceDetails);

      }
    }
    caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // Search for respondent.
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (final CaseParticipantRoleNameDetails caseParticipantRoleNameDetails : caseParticipantRoleNameDetailsList.dtls
      .items()) {

      hearingAttendanceDetails = new HearingAttendanceDetails();

      hearingAttendanceDetails.hearingAttendanceVersionNo =
        hearingParticipatedCodeAndVersionNoDetails.versionNo;
      hearingAttendanceDetails.hearingAttendanceKey =
        key.hearingKey.hearingID;
      hearingAttendanceDetails.attendanceCode = HEARINGATTENDANCE.RESPONDENT;
      hearingAttendanceDetails.caseParticipantRoleID =
        caseParticipantRoleNameDetails.caseParticipantRoleID;
      hearingAttendanceDetails.displayName =
        caseParticipantRoleNameDetails.concernRoleName;

      try {
        readParticipatedCodeKeys.caseParticipantRoleID =
          hearingAttendanceDetails.caseParticipantRoleID;
        hearingAttendanceDetails.participatedCode =
          hearingParticipationObj
            .readParticipatedCodeByCaseParticipantRoleID(readParticipatedCodeKeys).participatedCode;

      } catch (final Exception e) {
        hearingAttendanceDetails.participatedCode =
          HEARINGPARTICIPATION.NOTHELD;
      }

      // Add to the list.
      hearingAttendance.hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);

    }
    return hearingAttendance;
  }

  // END, CR00246931

  /**
   * Updates the status of all attendees of a hearing. Takes the list of
   * attendees as input.
   * 
   * @param dtls
   * Hearing attendance details
   */
  @Override
  protected void updateAttendance(final HearingAttendance dtls)
    throws AppException, InformationalException {

    // Hearing Representative variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new HearingRepresentativeIDKey();
    final ParticipatedCodeDetailsHR participatedCodeDetailsHR =
      new ParticipatedCodeDetailsHR();

    // Hearing Witness variables
    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    final HearingWitnessIDKey hearingWitnessIDKey = new HearingWitnessIDKey();
    final ParticipatedCodeDetails participatedCodeDetails =
      new ParticipatedCodeDetails();

    // Hearing Service Supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierIDKey hearingServiceSupplierIDKey =
      new HearingServiceSupplierIDKey();
    final HearingSSParticipationAndCommentDetails hearingSSParticipationAndCommentDetails =
      new HearingSSParticipationAndCommentDetails();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final HearingParticipationDetails hearingParticipationDetails =
      new HearingParticipationDetails();

    // HearingUserRole variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingUserRoleIDKey hearingUserRoleIDKey =
      new HearingUserRoleIDKey();
    final HearingUserRoleParticipatedDetails hearingUserRoleParticipatedDetails =
      new HearingUserRoleParticipatedDetails();

    // Variables for updating the participation code for all no shows
    final UpdateNonParticipationKey updateNonParticipationKey =
      new UpdateNonParticipationKey();
    final UpdateNonParticipationDetails updateNonParticipationDetails =
      new UpdateNonParticipationDetails();
    final HearingParticipationAndStatus hearingParticipationAndStatus =
      new HearingParticipationAndStatus();

    Count count;

    curam.appeal.sl.entity.struct.HearingParticipatedDetailsList hearingParticipatedDetailsList =
      new curam.appeal.sl.entity.struct.HearingParticipatedDetailsList();

    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    final HearingParticipationKey hearingParticipationKey =
      new HearingParticipationKey();
    final ReadParticipatedCodeKeys readParticipatedCodeKeys =
      new ReadParticipatedCodeKeys();

    // START, CR00132731, LP
    readParticipatedCodeKeys.hearingID = dtls.hearingVersion.hearingID;
    hearingKey.hearingID = dtls.hearingVersion.hearingID;

    for (int i = 0; i < dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
      .size(); i++) {
      // END, CR CR00020935
      if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).attendanceCode
        .equals(HEARINGATTENDANCE.HEARING_REPRESENTATIVE)) {

        hearingRepresentativeIDKey.hearingRepresentativeID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;
        participatedCodeDetailsHR.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;
        participatedCodeDetailsHR.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;

        // modify hearing representative participated code
        hearingRepresentativeObj.modifyParticipatedCode(
          hearingRepresentativeIDKey, participatedCodeDetailsHR);

      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.WITNESS)) {

        hearingWitnessIDKey.hearingWitnessID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;
        participatedCodeDetails.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;
        participatedCodeDetails.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;

        // modify participated code for the witness
        hearingWitnessObj.modifyParticipatedCode(hearingWitnessIDKey,
          participatedCodeDetails);

        // BEGIN, CR00177498, PM
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.LALEGALPARTICIPANT)) {

        hearingParticipationKey.hearingParticipationID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;
        participatedCodeDetails.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;
        participatedCodeDetails.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;

        // modify participated code for the witness
        hearingParticipationObj.modifyParticipatedCode(
          hearingParticipationKey, participatedCodeDetails);

        // modify hearing third party participated code
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.THIRDPARTY)) {

        final HearingIDStatusKeyHR hearingIDStatusKeyHR =
          new HearingIDStatusKeyHR();

        hearingIDStatusKeyHR.hearingID = dtls.hearingVersion.hearingID;
        hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
        hearingIDStatusKeyHR.participantType =
          CASEPARTICIPANTROLETYPE.THIRDPARTY;
        hearingParticipatedDetailsList =
          hearingParticipationObj
            .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

        for (final HearingParticipatedDetails hearingParticipatedDetails : hearingParticipatedDetailsList.dtls
          .items()) {

          if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
            .item(i).caseParticipantRoleID == hearingParticipatedDetails.caseParticipantRoleID) {

            participatedCodeDetails.participatedCode =
              HEARINGPARTICIPATION.PARTICIPATED;
            participatedCodeDetails.versionNo =
              hearingParticipatedDetails.versionNo;
            hearingParticipationKey.hearingParticipationID =
              hearingParticipatedDetails.hearingParticipationID;

            // modify participated code for the third party
            hearingParticipationObj.modifyParticipatedCode(
              hearingParticipationKey, participatedCodeDetails);
          }
        }
        // modify hearing appellant participated code
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.APPELLANT)) {

        final HearingIDStatusKeyHR hearingIDStatusKeyHR =
          new HearingIDStatusKeyHR();

        hearingIDStatusKeyHR.hearingID = dtls.hearingVersion.hearingID;
        hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

        hearingIDStatusKeyHR.participantType =
          CASEPARTICIPANTROLETYPE.APPELLANT;

        hearingParticipatedDetailsList =
          hearingParticipationObj
            .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

        for (final HearingParticipatedDetails hearingParticipatedDetails : hearingParticipatedDetailsList.dtls
          .items()) {

          if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
            .item(i).caseParticipantRoleID == hearingParticipatedDetails.caseParticipantRoleID) {

            participatedCodeDetails.participatedCode =
              HEARINGPARTICIPATION.PARTICIPATED;
            participatedCodeDetails.versionNo =
              hearingParticipatedDetails.versionNo;
            hearingParticipationKey.hearingParticipationID =
              hearingParticipatedDetails.hearingParticipationID;

            // modify participated code for the appellant
            hearingParticipationObj.modifyParticipatedCode(
              hearingParticipationKey, participatedCodeDetails);
          }
        }
        // END, CR00177498
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.RESPONDENT)) {// Do
                                                                       // nothing.
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode
        .equals(HEARINGATTENDANCE.INTERNAL_INTERPRETER)) {

        hearingServiceSupplierIDKey.hearingServiceSupplierID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;
        hearingSSParticipationAndCommentDetails.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;
        hearingSSParticipationAndCommentDetails.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;

        // modify participated code for the service supplier
        hearingServiceSupplierObj.modifyParticipatedCodeAndComment(
          hearingServiceSupplierIDKey,
          hearingSSParticipationAndCommentDetails);
        // BEGIN, CR00115728, RKi
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode.equals(HEARINGATTENDANCE.LALEGALPARTICIPANT)) {// DO
                                                                               // nothing.
                                                                               // Legal
                                                                               // Participants
                                                                               // don't
                                                                               // have
                                                                               // hearing
                                                                               // specific
        // entities
        // END, CR00115728D
      } else if (dtls.hearingAttendanceDetailsList.hearingAttendanceDetails
        .item(i).attendanceCode
        .equals(HEARINGATTENDANCE.EXTERNAL_INTERPRETER)) {

        hearingServiceSupplierIDKey.hearingServiceSupplierID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;
        hearingSSParticipationAndCommentDetails.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;
        hearingSSParticipationAndCommentDetails.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;

        // modify participated code for the service supplier
        hearingServiceSupplierObj.modifyParticipatedCodeAndComment(
          hearingServiceSupplierIDKey,
          hearingSSParticipationAndCommentDetails);

      } else {

        hearingUserRoleIDKey.hearingUserRoleID =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceKey;

        hearingUserRoleParticipatedDetails.participatedCode =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).participatedCode;
        hearingUserRoleParticipatedDetails.versionNo =
          dtls.hearingAttendanceDetailsList.hearingAttendanceDetails.item(i).hearingAttendanceVersionNo;

        try {
          // modify participated code for case worker
          hearingUserRoleObj.modifyParticipatedCode(hearingUserRoleIDKey,
            hearingUserRoleParticipatedDetails);
        } catch (final curam.util.exception.RecordNotFoundException e) {

          throw new AppException(
            curam.message.BPOHEARING.ERR_HEARINGATTENDANCE_TYPE_INVALID);
        }
      }
    }

    // Update the participation of all remaining hearing participants and
    // users
    // to no-show. To do this first determine if there are any active
    // records
    // with a participation of 'not held'; if there are then all records
    // with
    // a 'not held' participation code are updated to 'no show'.
    // ( Note that it is not possible to use the modify SQL to update all
    // such records without first checking to see if there are any records
    // to
    // update as DB2 handles the a record not found differently to
    // Oracle )
    // BEGIN, CR00177498, PM
    // update the not participated third party members to no held status.
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();

    hearingIDStatusKeyHR.hearingID = dtls.hearingVersion.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDStatusKeyHR.participantType = CASEPARTICIPANTROLETYPE.THIRDPARTY;

    hearingParticipatedDetailsList =
      hearingParticipationObj
        .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

    for (final HearingParticipatedDetails hearingParticipatedDetails : hearingParticipatedDetailsList.dtls
      .items()) {

      if (hearingParticipatedDetails.participatedCode
        .equals(HEARINGPARTICIPATION.NOTHELD)) {

        hearingParticipationKey.hearingParticipationID =
          hearingParticipatedDetails.hearingParticipationID;

        participatedCodeDetails.versionNo =
          hearingParticipatedDetails.versionNo;
        participatedCodeDetails.participatedCode =
          HEARINGPARTICIPATION.NOSHOW;

        hearingParticipationObj.modifyParticipatedCode(
          hearingParticipationKey, participatedCodeDetails);
      }
    }

    // update the not participated appellants to no held status.
    hearingIDStatusKeyHR.hearingID = dtls.hearingVersion.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDStatusKeyHR.participantType = CASEPARTICIPANTROLETYPE.APPELLANT;

    hearingParticipatedDetailsList =
      hearingParticipationObj
        .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

    for (final HearingParticipatedDetails hearingParticipatedDetails : hearingParticipatedDetailsList.dtls
      .items()) {

      if (hearingParticipatedDetails.participatedCode
        .equals(HEARINGPARTICIPATION.NOTHELD)) {

        hearingParticipationKey.hearingParticipationID =
          hearingParticipatedDetails.hearingParticipationID;
        participatedCodeDetails.versionNo =
          hearingParticipatedDetails.versionNo;
        participatedCodeDetails.participatedCode =
          HEARINGPARTICIPATION.NOSHOW;
        hearingParticipationObj.modifyParticipatedCode(
          hearingParticipationKey, participatedCodeDetails);
      }
    }

    // update the not participated legal participants to no held status.
    hearingIDStatusKeyHR.hearingID = dtls.hearingVersion.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDStatusKeyHR.participantType =
      CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;

    hearingParticipatedDetailsList =
      hearingParticipationObj
        .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

    for (final HearingParticipatedDetails hearingParticipatedDetails : hearingParticipatedDetailsList.dtls
      .items()) {

      if (hearingParticipatedDetails.participatedCode
        .equals(HEARINGPARTICIPATION.NOTHELD)) {

        hearingParticipationKey.hearingParticipationID =
          hearingParticipatedDetails.hearingParticipationID;
        participatedCodeDetails.versionNo =
          hearingParticipatedDetails.versionNo;
        participatedCodeDetails.participatedCode =
          HEARINGPARTICIPATION.NOSHOW;
        hearingParticipationObj.modifyParticipatedCode(
          hearingParticipationKey, participatedCodeDetails);
      }
    }
    // END, CR00177498

    hearingParticipationAndStatus.hearingID = dtls.hearingVersion.hearingID;
    hearingParticipationAndStatus.participatedCode =
      HEARINGPARTICIPATION.NOTHELD;
    updateNonParticipationKey.hearingID = dtls.hearingVersion.hearingID;

    // Update the remaining hearing representative participation to no-show.
    count =
      hearingRepresentativeObj
        .countActiveByHearingAndParticipation(hearingParticipationAndStatus);
    if (count.numberOfRecords > 0) {
      hearingRepresentativeObj.updateNonParticipation(
        updateNonParticipationKey, updateNonParticipationDetails);
    }

    // Update the remaining hearing witness participation to no-show
    count =
      hearingWitnessObj
        .countActiveByHearingAndParticipation(hearingParticipationAndStatus);
    if (count.numberOfRecords > 0) {
      hearingWitnessObj.updateNonParticipation(updateNonParticipationKey,
        updateNonParticipationDetails);
    }

    // Determine if there are any active participant or user service
    // suppliers
    // for hearing; if there are any then update all hearing service
    // suppliers
    // whose participation is not held to no show
    count =
      hearingServiceSupplierObj
        .countActiveParticipantByHearingParticipation(hearingParticipationAndStatus);
    if (count.numberOfRecords == 0) {
      count =
        hearingServiceSupplierObj
          .countActiveUserByHearingParticipation(hearingParticipationAndStatus);
    }
    if (count.numberOfRecords > 0) {
      hearingServiceSupplierObj.updateNonParticipation(
        updateNonParticipationKey, updateNonParticipationDetails);
    }

    // Update the remaining hearing user role participation to no-show
    count =
      hearingUserRoleObj
        .countActiveByHearingAndParticipation(hearingParticipationAndStatus);
    if (count.numberOfRecords > 0) {
      hearingUserRoleObj.updateNonParticipation(updateNonParticipationKey,
        updateNonParticipationDetails);
    }

    // we don't modify the respondent code at the moment, so just leave it
    // at
    // the default for now
    hearingParticipationDetails.respondentParticipatedCode =
      HEARINGPARTICIPATION.DEFAULTCODE;

    hearingObj.modifyParticipatedCodes(hearingKey,
      hearingParticipationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Adjourns a hearing.
   * 
   * @param details
   * Adjourn hearing details
   * @param appealType
   * AppealTypeCode
   */
  @Override
  public void adjourn(final AdjournHearingDetails details,
    final HearingAppealTypeCode appealType) throws AppException,
    InformationalException {

    // Hearing Schedule Variables
    final DeadlineDate scheduleDeadlineDate = new DeadlineDate();
    final AppealCaseID appealCaseID = new AppealCaseID();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    HearingStatusDateTypeDetails hearingStatusDateTypeDetails;
    final HearingDateAndStatus hearingDateAndStatus =
      new HearingDateAndStatus();
    final HearingAttendance hearingAttendance = new HearingAttendance();
    final HearingPostponeTimeStatusModifyDetails hearingPostponeTimeStatusModifyDetails =
      new HearingPostponeTimeStatusModifyDetails();

    // Case Header manipulation variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionByStatusKey hearingTranscriptionByStatusKey =
      new HearingTranscriptionByStatusKey();
    TranscriptionRequestIDKeyList transcriptionRequestIDKeyList;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Read hearing caseID
    hearingKey.hearingID = details.adjournHearingDetails.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// LA
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // Curam
                                                                          // V
                                                                          // Next
    } else {
      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.caseID;
      validateSecurityKey.type =
        curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // read hearing status and scheduled date
    hearingStatusDateTypeDetails =
      hearingObj.readStatusAndDateAndType(hearingKey);

    hearingDateAndStatus.scheduledDateTime =
      hearingStatusDateTypeDetails.scheduledDateTime;
    hearingDateAndStatus.statusCode = hearingStatusDateTypeDetails.statusCode;

    // validate adjourn
    validateAdjourn(details, hearingDateAndStatus);

    hearingAttendance.hearingAttendanceDetailsList
      .assign(details.hearingAttendanceDetailsList);

    // update attendance details

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)
      || appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      hearingAttendance.hearingVersion.hearingID =
        details.adjournHearingDetails.hearingID;
      hearingAttendance.hearingVersion.versionNo =
        details.adjournHearingDetails.versionNo;

      updateAttendance(hearingAttendance);
    }

    // set the postpone details and modify
    hearingPostponeTimeStatusModifyDetails
      .assign(details.adjournHearingDetails);

    hearingPostponeTimeStatusModifyDetails.postponeDate =
      DateTime.getCurrentDateTime();

    hearingPostponeTimeStatusModifyDetails.statusCode =
      HEARINGSTATUS.ADJOURNED;

    hearingPostponeTimeStatusModifyDetails.versionNo =
      details.adjournHearingDetails.versionNo;

    hearingPostponeTimeStatusModifyDetails.postponeDate.getCalendar()
      .setTimeZone(TransactionInfo.getUserTimeZone());

    hearingObj.modifyPostponeAndTimeAndStatusDetails(hearingKey,
      hearingPostponeTimeStatusModifyDetails);

    // read the case owner's ID (task will be assigned to them)
    caseHeaderKey.caseID = hearingCaseID.caseID;
    // BEGIN, CR00053295, RKi
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

    caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
    // END, CR00053295

    appealCaseID.caseID = hearingCaseID.caseID;
    // BEGIN, CR00115728, RKi
    HearingScheduleFactory.newInstance().createScheduleHearingTask(
      appealCaseID);
    // END, CR00115728

    // create adjourn event
    createAdjournEvent(details, appealType);

    // BEGIN, CR00286983, MC
    hearingTranscriptionByStatusKey.hearingID = hearingKey.hearingID;
    // END, CR00286983

    // read transcription requests
    transcriptionRequestIDKeyList =
      hearingTranscriptionRequestObj
        .searchActiveByHearingID(hearingTranscriptionByStatusKey);

    if (transcriptionRequestIDKeyList.dtls.size() > 0) {
      // if hearing transcription is requested case owner must be notified to
      // send a copy of the transcription to the requester
      final SystemUser systemUser = SystemUserFactory.newInstance();

      if (!caseOwnerDetails.userName
        .equals(systemUser.getUserDetails().userName)) {

        // Notification object and manipulation variables
        final Notification notificationObj =
          NotificationFactory.newInstance();

        final StandardManualTaskDtls standardManualTaskDtls =
          new StandardManualTaskDtls();

        // Set Notification details
        standardManualTaskDtls.dtls.concerningDtls.caseID =
          hearingCaseID.caseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          BPOHEARING.INF_ADJOURN_HEARING_TRANSCRIPTION_REASON
            .getMessageText();
        standardManualTaskDtls.dtls.taskDtls.subject =
          BPOHEARING.INF_ADJOURN_HEARING_TRANSCRIPTION_SUBJECT
            .getMessageText();
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userFullName;
        standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
          curam.appeal.sl.impl.Appeal.kAppealScheduleHearingTask;

        // BEGIN, CR00286983, MC
        // Add Schedule deadline date
        final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

        appealCaseIDKey.caseID = hearingCaseID.caseID;

        final AppealDeadlineDateDetails appealDeadlineDateDetails =
          new AppealDeadlineDateDetails();

        appealDeadlineDateDetails.caseID = hearingCaseID.caseID;
        appealDeadlineDateDetails.appealType = appealType.appealTypeCode;
        appealDeadlineDateDetails.receivedDate =
          AppealFactory.newInstance().readByCase(appealCaseIDKey).receivedDate;

        standardManualTaskDtls.dtls.taskDtls.deadlineTime =
          curam.appeal.sl.fact.AppealFactory.newInstance().getDeadlineDate(
            appealDeadlineDateDetails).date.getDateTime();
        // END, CR00286983
        // END, HARP, 44569

        // Create notification
        notificationObj
          .createWorkAllocationNotification(standardManualTaskDtls);
      }

    }

    // BEGIN, CR00021655, RKi
    // sends the notices to the appellants about the adjournment of the case.

    final Appellant appellant = AppellantFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearing =
      new curam.appeal.sl.entity.struct.HearingKey();
    AppellantDtls appellantDtls;

    hearing.hearingID = details.adjournHearingDetails.hearingID;
    AppellantKeyList appellantKeyList = new AppellantKeyList();

    appellantKeyList = appellant.searchAppellantByHearingID(hearing);
    final AppellantKey appellantKey = new AppellantKey();
    CaseParticipantRole_boKey caseParticipantRole_boKey =
      new CaseParticipantRole_boKey();

    for (int i = 0; i < appellantKeyList.dtls.size(); i++) {
      // BEGIN, CR00094944, RKi
      appellantKey.appellantID = appellantKeyList.dtls.item(i).appellantID;
      appellantDtls = appellant.read(appellantKey);
      if (!appellantDtls.appellantTypeCode.equals(APPELLANTTYPE.ORGANIZATION)) {
        caseParticipantRole_boKey =
          appellant.readCaseParticipantRoleIDByAppellantID(appellantKey);
        createAdjournmentNotice(caseParticipantRole_boKey);
      }
      // END, CR00094944
    }
    // END, CR00021655

    // BEGIN, CR00022957, RR
    // sends the notices to the third parties about the adjournment of the case.

    final ThirdParty thirdParty = ThirdPartyFactory.newInstance();

    hearing.hearingID = details.adjournHearingDetails.hearingID;

    ThirdPartyKeyList thirdPartyKeyList = new ThirdPartyKeyList();

    thirdPartyKeyList = thirdParty.searchThirdPartyByHearingID(hearing);

    final ThirdPartyKey thirdPartyKey = new ThirdPartyKey();

    caseParticipantRole_boKey = new CaseParticipantRole_boKey();
    for (int i = 0; i < thirdPartyKeyList.dtls.size(); i++) {
      thirdPartyKey.thirdPartyID =
        thirdPartyKeyList.dtls.item(i).thirdPartyID;
      caseParticipantRole_boKey =
        thirdParty.readCaseParticipantRoleIDByThirdPartyID(thirdPartyKey);
      createAdjournmentNotice(caseParticipantRole_boKey);
    }
    // END, CR00022957

    // Read the CaseParticipants of type equivalent to the On Behalf of code
    // of the witness
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    caseParticipantRoleCaseAndTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;
    caseParticipantRoleCaseAndTypeKey.caseID = appealCaseID.caseID;
    final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      CaseParticipantRoleFactory.newInstance()
        .searchActiveRoleAndNameByCaseAndType(
          caseParticipantRoleCaseAndTypeKey);
    final int size = caseParticipantRoleNameDetailsList.dtls.size();

    for (int i = 0; i < size; i++) {
      caseParticipantRole_boKey.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      createAdjournmentNotice(caseParticipantRole_boKey);
    }

    // BEGIN, CR CR00049931, NSP
    if (hearingCaseID.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingCaseID.caseID;

      if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_ADJOURNED;
      } else if (appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_REVIEW_ADJOURNED;
      }

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = hearingCaseID.caseID;
      curam.core.sl.struct.ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new curam.core.sl.struct.ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog caseTransactionLogObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls transactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911

      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {
            transactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            transactionDtls.userName = systemUser.getUserDetails().userName;
            if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_CASE_CREATED;
            }
            if (appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED;
            }
            transactionDtls.caseID = details.adjournHearingDetails.hearingID;
            caseTransactionLogObj.insert(transactionDtls);
          }
        }
      }

    }
    // END, CR CR00049931
  }

  // ___________________________________________________________________________
  /**
   * Creates events for a hearing adjournment
   * 
   * @param details
   * Adjourn hearing details
   * @param appealType
   * AppealTypeCode
   */
  @Override
  public void createAdjournEvent(final AdjournHearingDetails details,
    final HearingAppealTypeCode appealType) throws AppException,
    InformationalException {

    // CaseEvent variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // UniqueID generation
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Hearing entity
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingKey.hearingID = details.adjournHearingDetails.hearingID;

    // read hearing caseID
    final curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      hearingObj.readCase(hearingKey);

    // Current Date
    final Date currentDate = Date.getCurrentDate();

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    // Begin CR00117296 LP
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      caseEventDtls.eventTypeCode =
        curam.codetable.CASEEVENTTYPE.HEARINGADJOURNED;
    }
    // End CR00117296 LP
    if (appealType.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      caseEventDtls.eventTypeCode =
        curam.codetable.CASEEVENTTYPE.HEARINGADJOURNED;

    } else if (appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      caseEventDtls.eventTypeCode =
        curam.codetable.CASEEVENTTYPE.HEARINGREVIEWADJOURNED;

    }

    // assign values to case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();

    caseEventDtls.caseID = hearingCaseID.caseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.relatedID = details.adjournHearingDetails.hearingID;

    // save CaseEvent to database
    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Validates an adjournment.
   * 
   * @param details
   * Adjourn hearing details
   * @param status
   * Hearing status code and scheduled date
   */
  @Override
  public void validateAdjourn(final AdjournHearingDetails details,
    final HearingDateAndStatus status) throws AppException,
    InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // hearing must be scheduled
    if (!status.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_ADJOURN_HEARING_STATUS), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // hearing can only be adjourned on or after the scheduled date
    if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
      status.scheduledDateTime, TransactionInfo.getUserTimeZone()))
      .after(Date.getCurrentDate())) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_FV_ADJOURN_DATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // actual start date and time must be specified
    if (details.adjournHearingDetails.actualStartTime.equals(kZeroEPOCDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_FV_ADJOURN_ACTUAL_START_DATE_TIME),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // actual end date and time must be specified
    if (details.adjournHearingDetails.actualEndTime.equals(kZeroEPOCDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_FV_ADJOURN_ACTUAL_END_DATE_TIME), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Validate that the actual start time is before the actual end time
    if (!details.adjournHearingDetails.actualStartTime
      .before(details.adjournHearingDetails.actualEndTime)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_ADJOURN_START_TIME_BEFORE_END_TIME),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // reason code must be specified
    if (details.adjournHearingDetails.reasonCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_FV_ADJOURN_REASON_CODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * This method returns the case identifier for a hearing
   * 
   * @param key
   * The hearingID to get the case identifier for
   * @return The caseID for the hearing
   */
  @Override
  public HearingCaseID getCase(final HearingKey key) throws AppException,
    InformationalException {

    // Hearing entity object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    // Hearing case identifier business object
    final HearingCaseID hearingCaseIDbo = new HearingCaseID();

    // Read for the hearing case
    hearingCaseIDbo.hearingCaseID.assign(hearingObj.readCase(key.hearingKey));

    return hearingCaseIDbo;

  }

  // ___________________________________________________________________________
  /**
   * Clones the hearing details from one hearing for another hearing.
   * 
   * @param key
   * The hearing being cloned
   * @param dtls
   * The hearing whose details are being created from the cloned
   * hearing
   * @param appealType
   * The type of appeal case that the hearing is associated with
   */
  @Override
  public void cloneHearing(final HearingKey key, final HearingKey dtls,
    final HearingAppealTypeCode appealType) throws AppException,
    InformationalException {

    // clone representatives
    cloneRepresentatives(key, dtls);

    // clone transcription request
    cloneTranscriptionRequest(key, dtls);

    // attendees and witnesses don't exist for appeals of type HEARINGREVIEW
    // BEGIN, 32118, SM
    if (!appealType.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
      // clone attendees
      cloneAttendees(key, dtls);

      // clone witnesses
      cloneWitnesses(key, dtls);

      // clone service suppliers
      cloneServiceSuppliers(key, dtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Determines the duration of a hearing, in minutes and in work units.
   * 
   * @param key
   * Unique internal reference number of the appeal case
   * 
   * @return The number of work units required, and the expected duration
   */
  @Override
  public HearingDurationDetails getDuration(final AppealCaseIDKey key)
    throws AppException, InformationalException {

    // Duration object
    final HearingDurationDetails hearingDurationDetails =
      new HearingDurationDetails();

    // Appeal objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    String difficultyCode;

    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // As of now, using lower appeals difficulty.
      // Low difficulty
      final String lowDifficultyDurationString =
        Configuration.getProperty(EnvVars.ENV_LEGALACTION_HEARING_DURATION);

      // If duration is not set, use the default

      if (lowDifficultyDurationString == null) {

        hearingDurationDetails.duration =
          EnvVars.ENV_LEGALACTION_HEARING_DURATION_DEFAULT;

      } else {

        hearingDurationDetails.duration =
          Integer.parseInt(lowDifficultyDurationString);

      }

      // If work units is not set, use the default
      final String lowDifficultyWorkUnitsString =
        Configuration.getProperty(EnvVars.ENV_LEGALACTION_HEARING_WORK_UNITS);

      if (lowDifficultyWorkUnitsString == null) {

        hearingDurationDetails.numberOfWorkUnits =
          EnvVars.ENV_LEGALACTION_HEARING_WORK_UNITS_DEFAULT;

      } else {

        hearingDurationDetails.numberOfWorkUnits =
          Integer.parseInt(lowDifficultyWorkUnitsString);

      }

    } // End CR00117296 LP
    else {
      // Get the appeal difficulty
      difficultyCode = appealObj.readDifficultyByCase(key).difficultyCode;

      // Set duration and work units based on difficulty
      if (difficultyCode.equals(APPEALDIFFICULTY.HIGH)) {

        final String highDifficultyDurationString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_HIGH_DIFFICULTY_DURATION);

        // If duration is not set, use the default
        if (highDifficultyDurationString == null) {

          hearingDurationDetails.duration =
            EnvVars.ENV_APPEAL_HIGH_DIFFICULTY_DURATION_DEFAULT;

        } else {

          hearingDurationDetails.duration =
            Integer.parseInt(highDifficultyDurationString);

        }

        // If work units is not set, use the default
        final String highDifficultyWorkUnitsString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_HIGH_DIFFICULTY_WORK_UNITS);

        if (highDifficultyWorkUnitsString == null) {

          hearingDurationDetails.numberOfWorkUnits =
            EnvVars.ENV_APPEAL_HIGH_DIFFICULTY_WORK_UNITS_DEFAULT;

        } else {

          hearingDurationDetails.numberOfWorkUnits =
            Integer.parseInt(highDifficultyWorkUnitsString);

        }

      } else if (difficultyCode.equals(APPEALDIFFICULTY.NORMAL)) {

        final String normalDifficultyDurationString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_MEDIUM_DIFFICULTY_DURATION);

        // If duration is not set, use the default
        if (normalDifficultyDurationString == null) {

          hearingDurationDetails.duration =
            EnvVars.ENV_APPEAL_MEDIUM_DIFFICULTY_DURATION_DEFAULT;

        } else {

          hearingDurationDetails.duration =
            Integer.parseInt(normalDifficultyDurationString);

        }

        final String normalDifficultyWorkUnitsString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_MEDIUM_DIFFICULTY_WORK_UNITS);

        // If work units is not set, use the default
        if (normalDifficultyWorkUnitsString == null) {

          hearingDurationDetails.numberOfWorkUnits =
            EnvVars.ENV_APPEAL_MEDIUM_DIFFICULTY_WORK_UNITS_DEFAULT;

        } else {

          hearingDurationDetails.numberOfWorkUnits =
            Integer.parseInt(normalDifficultyWorkUnitsString);

        }

      } else {

        // Low difficulty
        final String lowDifficultyDurationString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_LOW_DIFFICULTY_DURATION);

        // If duration is not set, use the default

        if (lowDifficultyDurationString == null) {

          hearingDurationDetails.duration =
            EnvVars.ENV_APPEAL_LOW_DIFFICULTY_DURATION_DEFAULT;

        } else {

          hearingDurationDetails.duration =
            Integer.parseInt(lowDifficultyDurationString);

        }

        // If work units is not set, use the default
        final String lowDifficultyWorkUnitsString =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_LOW_DIFFICULTY_WORK_UNITS);

        if (lowDifficultyWorkUnitsString == null) {

          hearingDurationDetails.numberOfWorkUnits =
            EnvVars.ENV_APPEAL_LOW_DIFFICULTY_WORK_UNITS_DEFAULT;

        } else {

          hearingDurationDetails.numberOfWorkUnits =
            Integer.parseInt(lowDifficultyWorkUnitsString);

        }

      }
    }

    // Return duration details
    return hearingDurationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists the active participants for a hearing
   * 
   * @param key
   * Unique internal reference number of the hearing
   * @return The list of active hearing participants and their participant type
   */
  @Override
  public HearingParticipantDetailsList listActiveHearingParticipants(
    final HearingKey key) throws AppException, InformationalException {

    // Hearing Participant variables
    final HearingParticipantDetailsList hearingParticipantDetailsList =
      new HearingParticipantDetailsList();
    HearingParticipantDetails hearingParticipantDetails =
      new HearingParticipantDetails();

    // Hearing entity variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // Hearing Representative variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeNameParticipantDetailsList hearingRepresentativeNameParticipantDetailsList;

    // Hearing Witness variables
    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    final HearingIDStatusKeyHW hearingIDStatusKeyHW =
      new HearingIDStatusKeyHW();
    HearingWitnessNameAndParticipantDetailsList hearingWitnessNameAndParticipantDetailsList;

    // Hearing Service Supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
      new HearingServiceSupplierInterpreterHearingKey();
    HearingInterpreterNameParticipantDetailsList hearingInterpreterNameParticipantDetailsList;

    // CaseParticipantRole variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoTypeCode caseParticipantRole_eoTypeCode;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    hearingKey.hearingID = key.hearingKey.hearingID;

    // read hearing caseID
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // search for representatives and add participating ones to list
    hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    hearingRepresentativeNameParticipantDetailsList =
      hearingRepresentativeObj
        .searchActiveHearingRepNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHR);

    int i;

    for (i = 0; i < hearingRepresentativeNameParticipantDetailsList.dtls
      .size(); i++) {

      hearingParticipantDetails = new HearingParticipantDetails();

      hearingParticipantDetails.concernRoleName =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).fullName;
      hearingParticipantDetails.caseParticipantRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipantDetails.concernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // Get the case participant role type
      caseParticipantRoleKey.caseParticipantRoleID =
        hearingParticipantDetails.caseParticipantRoleID;
      caseParticipantRole_eoTypeCode =
        caseParticipantRole_eoObj.readTypeCode(caseParticipantRoleKey);
      hearingParticipantDetails.caseParticipantRoleType =
        caseParticipantRole_eoTypeCode.typeCode;

      // add to the list
      hearingParticipantDetailsList.hearingParticipantDetails
        .addRef(hearingParticipantDetails);
    }

    // search for witnesses and add participating ones to list
    hearingIDStatusKeyHW.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHW.recordStatus = RECORDSTATUS.NORMAL;

    hearingWitnessNameAndParticipantDetailsList =
      hearingWitnessObj
        .searchActiveHearingWitnessNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHW);

    for (i = 0; i < hearingWitnessNameAndParticipantDetailsList.dtls.size(); i++) {

      hearingParticipantDetails = new HearingParticipantDetails();

      hearingParticipantDetails.caseParticipantRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipantDetails.concernRoleName =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).fullName;
      hearingParticipantDetails.concernRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).participantRoleID;
      // Get the case participant role type
      caseParticipantRoleKey.caseParticipantRoleID =
        hearingParticipantDetails.caseParticipantRoleID;
      caseParticipantRole_eoTypeCode =
        caseParticipantRole_eoObj.readTypeCode(caseParticipantRoleKey);
      hearingParticipantDetails.caseParticipantRoleType =
        caseParticipantRole_eoTypeCode.typeCode;

      // add to the list
      hearingParticipantDetailsList.hearingParticipantDetails
        .addRef(hearingParticipantDetails);
    }

    // search for service suppliers - hearing interpreters
    hearingServiceSupplierInterpreterHearingKey.hearingID =
      key.hearingKey.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    hearingInterpreterNameParticipantDetailsList =
      hearingServiceSupplierObj
        .searchActiveInterpreterNameAndCaseParticipantByHearingID(hearingServiceSupplierInterpreterHearingKey);

    for (i = 0; i < hearingInterpreterNameParticipantDetailsList.dtls.size(); i++) {

      hearingParticipantDetails = new HearingParticipantDetails();

      hearingParticipantDetails.caseParticipantRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipantDetails.concernRoleName =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).fullName;
      hearingParticipantDetails.concernRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // Get the case participant role type
      caseParticipantRoleKey.caseParticipantRoleID =
        hearingParticipantDetails.caseParticipantRoleID;
      caseParticipantRole_eoTypeCode =
        caseParticipantRole_eoObj.readTypeCode(caseParticipantRoleKey);
      hearingParticipantDetails.caseParticipantRoleType =
        caseParticipantRole_eoTypeCode.typeCode;

      // add to the list
      hearingParticipantDetailsList.hearingParticipantDetails
        .addRef(hearingParticipantDetails);

    }
    // BEGIN, CR00117296, LP
    // search for third parties and add participating ones to list
    caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;
    final ArrayList<String> hearingRoleTypeList = new ArrayList<String>();

    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.THIRDPARTY);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.APPELLANT);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.LEGALPETITIONER);
    // search for appellants and add participating ones to list
    for (int j = 0; j < hearingRoleTypeList.size(); j++) {
      caseParticipantRoleCaseAndTypeKey.typeCode = hearingRoleTypeList.get(j);
      caseParticipantRoleNameDetailsList =
        caseParticipantRole_eoObj
          .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      for (i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

        hearingParticipantDetails = new HearingParticipantDetails();

        hearingParticipantDetails.caseParticipantRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
        hearingParticipantDetails.concernRoleName =
          caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;
        hearingParticipantDetails.concernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        hearingParticipantDetails.caseParticipantRoleType =
          caseParticipantRoleCaseAndTypeKey.typeCode;

        // add to the list
        hearingParticipantDetailsList.hearingParticipantDetails
          .addRef(hearingParticipantDetails);

      }
    }
    // End CR00117296 LP
    // return the full list of active participants for the hearing
    return hearingParticipantDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists the phone numbers for a particular participant
   * 
   * @param key
   * concern Role ID and case participant role id of the participant
   * and the hearing ID
   * @return The list of phone numbers for the participant
   */
  @Override
  public HearingParticipantPhoneNumberList listParticipantPhoneNumbers(
    final curam.appeal.sl.struct.HearingParticipantKey key)
    throws AppException, InformationalException {

    final HearingParticipantPhoneNumberList hearingParticipantPhoneNumberList =
      new HearingParticipantPhoneNumberList();

    // Phone number maintenance object
    final MaintainConcernRolePhone maintainConcernRolePhoneObj =
      MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey =
      new MaintainPhoneNumberKey();
    ReadMultiByConcernRoleIDPhoneResult readMultiByConcernRoleIDPhoneResult =
      new ReadMultiByConcernRoleIDPhoneResult();
    HearingParticipantPhoneNumber hearingParticipantPhoneNumber;

    // Read list of phone numbers
    maintainPhoneNumberKey.concernRoleID = key.concernRoleID;

    readMultiByConcernRoleIDPhoneResult =
      maintainConcernRolePhoneObj
        .readmultiByConcernRole(maintainPhoneNumberKey);

    // Iterate through returned phone number details
    for (int i = 0; i < readMultiByConcernRoleIDPhoneResult.details.dtls
      .size(); i++) {

      hearingParticipantPhoneNumber = new HearingParticipantPhoneNumber();

      hearingParticipantPhoneNumber.areaCode =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).phoneAreaCode;
      hearingParticipantPhoneNumber.countryCode =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).phoneCountryCode;
      hearingParticipantPhoneNumber.extension =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).phoneExtension;
      hearingParticipantPhoneNumber.phoneNumber =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).phoneNumber;
      hearingParticipantPhoneNumber.phoneNumberID =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).phoneNumberID;
      hearingParticipantPhoneNumber.concernRolePhoneNumberID =
        readMultiByConcernRoleIDPhoneResult.details.dtls.item(i).concernRolePhoneNumberID;

      // add to the list
      hearingParticipantPhoneNumberList.hearingParticipantPhoneNumber
        .addRef(hearingParticipantPhoneNumber);
    }

    hearingParticipantPhoneNumberList.hearingID = key.hearingID;
    hearingParticipantPhoneNumberList.caseParticipantRoleID =
      key.caseParticipantRoleID;

    return hearingParticipantPhoneNumberList;
  }

  // ___________________________________________________________________________
  /*
   * Gets the summary details for a Desk-Based hearing.
   * 
   * @param key contains the ID of the hearing to display
   * 
   * @return Desk Hearing summary details.
   */
  @Override
  public DeskHearingSummaryDetails getDeskHearingSummaryDetails(
    final HearingKey key) throws AppException, InformationalException {

    // Return details
    final DeskHearingSummaryDetails deskHearingSummaryDetailsReturn =
      new DeskHearingSummaryDetails();

    // Hearing entity & structs
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    final HearingParticipantKey hearingParticipantKey =
      new HearingParticipantKey();

    hearingParticipantKey.hearingID = key.hearingKey.hearingID;

    // get the summary details
    deskHearingSummaryDetailsReturn.deskHearingSummaryDetails =
      hearingObj.readDeskHearingSummaryDetails(hearingParticipantKey);

    // BEGIN, CR00079950, RKi
    // Required Objects
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // assign the orgObjectLinkID to retrieve the user name
    orgObjectLinkKey.orgObjectLinkID =
      deskHearingSummaryDetailsReturn.deskHearingSummaryDetails.orgObjectLinkID;

    // retrieves the username through orgObjectLinkID
    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

    // assign to the return struct
    deskHearingSummaryDetailsReturn.deskHearingSummaryDetails.userName =
      caseOwnerDetails.userName;
    deskHearingSummaryDetailsReturn.deskHearingSummaryDetails.fullName =
      caseOwnerDetails.userFullName;
    // END, CR00079950,

    return deskHearingSummaryDetailsReturn;
  }

  // ___________________________________________________________________________
  /**
   * Creates attendance cancellation notice.
   * 
   * @param key
   * identifies appellant
   */
  @Override
  public void createAttendanceCancellationNotice(final AppellantKey key)
    throws AppException, InformationalException {

    // Appellant variables
    final Appellant appellant = AppellantFactory.newInstance();
    AppellantDtls appellantDtls;

    appellantDtls = appellant.read(key);

    final CaseParticipantRole_boKey caseParticipantRole_boKey =
      new CaseParticipantRole_boKey();

    caseParticipantRole_boKey.caseParticipantRoleID =
      appellantDtls.caseParticipantRoleID;

    sendAttendanceCancellationNotice(caseParticipantRole_boKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates hearing adjournment notice for an appellant.
   * 
   * @param key
   * identifies case participant role
   */
  @Override
  public void createAdjournmentNotice(final CaseParticipantRole_boKey key)
    throws AppException, InformationalException {

    // CaseParticipantRole object and manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // search for appellant (there can only be one)
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    final CaseParticipantRole_eoFullDetails details =
      caseParticipantRole_eoObj.readFullDetails(caseParticipantRoleKey);

    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.communicationDate =
      curam.util.type.Date.getCurrentDate();

    communicationDetails.correspondentConcernRoleID =
      details.participantRoleID;

    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == details.participantRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766

    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;

    // Add subject title to communication
    communicationDetails.subjectText = "";

    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.correspondentName = details.name;

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.HEARINGADJOURNMENTNOTICE;

    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);

    proFormaCommDetails.correspondentConcernRoleID =
      details.participantRoleID;
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;

    concernRoleKey.concernRoleID = details.participantRoleID;

    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

    proFormaCommDetails.caseID = details.caseID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // set primary key of the data set to the appellant
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      key.caseParticipantRoleID;

    // Set document code and type
    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.HEARINGADJOURNMENTNOTICE;
    generateDocumentDetails.dtls.dataSetType =
      DATASETTYPE.HEARING_ADJOURNMENT_NOTICE;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // BEGIN, CR CR00022957, RR
  // Making the method more generic to be used by both Appellant and ThirdParty

  // ___________________________________________________________________________
  /**
   * Sends attendance cancellation notice to the specified Case Participant.
   * 
   * @param key
   * identifies case participant role
   */
  @Override
  public void sendAttendanceCancellationNotice(
    final CaseParticipantRole_boKey key) throws AppException,
    InformationalException {

    // InformationalManager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // CaseParticipantRole object and manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;

    CaseParticipantRoleDtls caseParticipantRoleDtls;

    caseParticipantRoleDtls =
      caseParticipantRole_eoObj.read(caseParticipantRoleKey);

    caseParticipantRoleCaseAndTypeKey.caseID = caseParticipantRoleDtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    generateDocumentDetails.dtls.dataSetType =
      DATASETTYPE.HEARING_ATTENDANCE_CANCELLATION_NOTICE;

    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.ATTENDANCECANCELLATIONNOTICE;

    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.communicationDate =
      curam.util.type.Date.getCurrentDate();

    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;
    communicationDetails.subjectText =
      BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    // BEGIN, CR CR00069434, NSP
    communicationDetails.correspondentConcernRoleID =
      caseParticipantRoleDtls.participantRoleID;

    // Create the communication
    concernRoleKey.concernRoleID = caseParticipantRoleDtls.participantRoleID;

    communicationDetails.correspondentName =
      concernRoleObj.read(concernRoleKey).concernRoleName;
    // END, CR CR00069434
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseParticipantRoleDtls.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      generateDocumentDetails.dtls.documentIDCode;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    proFormaCommDetails.caseID = caseParticipantRoleDtls.caseID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // BEGIN, CR CR00069434, NSP
    // Set data set key
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      caseParticipantRoleDtls.caseParticipantRoleID;
    // END, CR CR00069434

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187

    // Throw exceptions for any validation errors found
    informationalManager.failOperation();
  }

  // Begin CR00117296 LP
  // ___________________________________________________________________________
  /**
   * List the active participants in the hearing, for which there can be
   * representatives or witness. These include THIRDPARTY, APPELLANT,
   * LEGALPARTICIPANT, LEGALPETITIONER and LEGALRESPONDENT.
   * 
   * @param key Hearing Key
   * @return List of HearingParticipantDetails
   */
  @Override
  public HearingParticipantDetailsList listActiveOnBehalfOfParticipants(
    final HearingKey key) throws AppException, InformationalException {

    // Hearing Participant variables
    final HearingParticipantDetailsList hearingParticipantDetailsList =
      new HearingParticipantDetailsList();
    HearingParticipantDetails hearingParticipantDetails =
      new HearingParticipantDetails();

    // Hearing entity variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // CaseParticipantRole variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    hearingKey.hearingID = key.hearingKey.hearingID;

    // read hearing caseID
    hearingCaseID = hearingObj.readCase(hearingKey);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate appeal case security
      validateSecurityKey.caseID = hearingCaseID.caseID;
      validateSecurityKey.type =
        curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    int i;

    // search for third parties and add participating ones to list
    caseParticipantRoleCaseAndTypeKey.caseID = hearingCaseID.caseID;
    final ArrayList<String> hearingRoleTypeList = new ArrayList<String>();

    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.THIRDPARTY);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.APPELLANT);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT);
    hearingRoleTypeList.add(CASEPARTICIPANTROLETYPE.LEGALPETITIONER);
    // search for appellants and add participating ones to list
    for (int j = 0; j < hearingRoleTypeList.size(); j++) {
      caseParticipantRoleCaseAndTypeKey.typeCode = hearingRoleTypeList.get(j);
      caseParticipantRoleNameDetailsList =
        caseParticipantRole_eoObj
          .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      for (i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

        hearingParticipantDetails = new HearingParticipantDetails();

        hearingParticipantDetails.caseParticipantRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
        hearingParticipantDetails.concernRoleName =
          caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;
        hearingParticipantDetails.concernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        hearingParticipantDetails.caseParticipantRoleType =
          caseParticipantRoleCaseAndTypeKey.typeCode;

        // add to the list
        hearingParticipantDetailsList.hearingParticipantDetails
          .addRef(hearingParticipantDetails);

      }
    }

    // return the full list of active participants for the hearing
    return hearingParticipantDetailsList;
  }
  // End CR00117296 LP

}
