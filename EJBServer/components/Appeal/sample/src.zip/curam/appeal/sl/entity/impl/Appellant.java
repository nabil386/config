/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.AppellantKey;
import curam.appeal.sl.entity.struct.CancelAppellantDetails;
import curam.appeal.sl.entity.struct.CaseParticipantRoleIDAndIndicatorDetails;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionStatusDetails;
import curam.appeal.sl.entity.struct.HearingScheduleDetails;
import curam.appeal.sl.entity.struct.ReceiptIndicatorDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASESTATUS;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the Appellant
 * entity layer.
 */
public abstract class Appellant extends curam.appeal.sl.entity.base.Appellant {

  /**
   * Validates the Appellant Details for insert
   * 
   * @param details
   * Appellant details
   */
  @Override
  protected void preinsert(final AppellantDtls details) throws AppException,
    InformationalException {

    validateDetails(details);
    validateInsert(details);

  }

  /**
   * Validates the Appellant Details
   * 
   * @param details
   * Appellant details
   */
  public void validateDetails(final AppellantDtls details)
    throws AppException, InformationalException {

    // Received date must not be later than today

    if (Date.getCurrentDate().before(details.receivedDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_DATE_LATER_THAN_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Validates the Appellant Details
   * 
   * @param details
   * Appellant details
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void validateModify(final AppellantKey key,
    final AppellantDtls details) throws AppException, InformationalException {

    // Check Decision Status
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealKey appealKey = new AppealKey();
    AppealDtls appealDtls;

    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails =
      new HearingDecisionStatusDetails();

    appealKey.appealID = details.appealID;
    appealDtls = appealObj.read(appealKey);

    hearingDecisionCaseKey.caseID = appealDtls.caseID;

    try {

      hearingDecisionStatusDetails =
        hearingDecisionObj.readStatusByCase(hearingDecisionCaseKey);

      if (hearingDecisionStatusDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.APPROVED)
        || hearingDecisionStatusDetails.decisionStatus
          .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              curam.message.ENTAPPELLANT.ERR_DECISION_EXISTS_FOR_APPEAL_CASE_APPELLANT_DETAILS_CANNOT_BE_MODIFIED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    } catch (final RecordNotFoundException ex) {// do Nothing
    }

    // If case is closed
    // Get the appeal case start date from case header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = appealDtls.caseID;

    // BEGIN, CR00303986, SG
    final CaseStatusCode caseStatusCode =
      caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CLOSED_APPELLANT_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // BEGIN, CR00303986, SG
    if (caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {
      // END, CR00303986

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CANCELLED_APPELLANT_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * validate entity data for insert operation
   * 
   * @param dtls the details to validate
   */
  public void validateInsert(final AppellantDtls details)
    throws AppException, InformationalException {

    // Check Decision Status
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealKey appealKey = new AppealKey();
    AppealDtls appealDtls;

    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails =
      new HearingDecisionStatusDetails();

    appealKey.appealID = details.appealID;
    appealDtls = appealObj.read(appealKey);

    hearingDecisionCaseKey.caseID = appealDtls.caseID;
    try {

      hearingDecisionStatusDetails =
        hearingDecisionObj.readStatusByCase(hearingDecisionCaseKey);

      if (hearingDecisionStatusDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.APPROVED)
        || hearingDecisionStatusDetails.decisionStatus
          .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              curam.message.ENTAPPELLANT.ERR_APPEAL_DECISION_EXISTS_APPELLANT_CANNOT_BE_ADDED_TO_APPEAL_CASE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    } catch (final RecordNotFoundException ex) {// do nothing
    }

    // If case is closed
    // Get the appeal case start date from case header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = appealDtls.caseID;

    // BEGIN, CR00303986, SG
    final CaseStatusCode caseStatusCode =
      caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      // END, CR00303986

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CLOSED_APPELLANT_CANNOT_BE_ADDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // BEGIN, CR00303986, SG
    if (caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {
      // END, CR00303986

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CANCELLED_APPELLANT_CANNOT_BE_ADDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Get the value of the Correspondence Lead Time environment variable
    final String correspondenceLeadTimeString =
      curam.util.resources.Configuration
        .getProperty(EnvVars.ENV_CORRESPONDENCE_LEAD_TIME);

    final Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingScheduleDetails hearingScheduleDetails;

    // BEGIN, CR00021436, RKi
    final HearingCaseStatusDtls hearingCaseStatusDtls =
      new HearingCaseStatusDtls();

    hearingCaseStatusDtls.caseID = appealDtls.caseID;
    hearingCaseStatusDtls.statusCode = HEARINGSTATUS.SCHEDULED;
    // END, CR00021436

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    try {
      // BEGIN, CR00021436, RKi
      hearingScheduleDetails =
        hearingObj.readScheduledDateTimeByCase(hearingCaseStatusDtls);
      // END, CR00021436

      final curam.util.type.Date scheduleDate =
        new Date(hearingScheduleDetails.scheduledDateTime);
      final int n = Integer.parseInt(correspondenceLeadTimeString);

      if (Date.getCurrentDate().addDays(n).after(scheduleDate)) {

        final AppException appException =
          new AppException(
            curam.message.ENTAPPELLANT.INF_INSUFFICIENT_TIME_CORRESPONDENCE_RELATED_TO_HEARING);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(appException, "",
            InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // informationalManager.failOperation();
    } catch (final RecordNotFoundException ex) {// do nothing
    }
  }

  /**
   * Validates the Appellant Details for Cancel
   * 
   * @param details
   * Appellant details
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void validateCancel(final AppellantKey key,
    final CancelAppellantDetails details) throws AppException,
    InformationalException {

    // Check Decision Status
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealKey appealKey = new AppealKey();
    AppealDtls appealDtls;

    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();
    AppellantDtls appellantDtls;

    appellantDtls = appellantObj.read(key);

    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails =
      new HearingDecisionStatusDetails();

    appealKey.appealID = appellantDtls.appealID;
    appealDtls = appealObj.read(appealKey);

    hearingDecisionCaseKey.caseID = appealDtls.caseID;

    try {

      hearingDecisionStatusDetails =
        hearingDecisionObj.readStatusByCase(hearingDecisionCaseKey);

      if (hearingDecisionStatusDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.APPROVED)
        || hearingDecisionStatusDetails.decisionStatus
          .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              curam.message.ENTAPPELLANT.ERR_DECISION_EXISTS_FOR_APPELLANTS_CASE_APPELLANT_CANNOT_BE_REMOVED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    } // BEGIN, CR00279140, AC
    catch (final RecordNotFoundException e) {// do nothing
      // END, CR00279140
    }

    // If case is closed
    // Get the appeal case start date from case header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = appealDtls.caseID;

    // BEGIN, CR00303986, SG
    final CaseStatusCode caseStatusCode =
      caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CLOSED_APPELLANT_CANNOT_BE_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // BEGIN, CR00303986, SG
    if (caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {
      // END, CR00303986

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_APPEAL_CASE_CANCELLED_APPELLANT_CANNOT_BE_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // If this is last appellant for the Appeal case do not remove him
    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();
    Count count;

    appealIDAndDateDetails.appealID = appellantDtls.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    count =
      appellantObj.countActiveAppellantsByAppealID(appealIDAndDateDetails);

    if (count.numberOfRecords == 1) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.ENTAPPELLANT.ERR_LAST_APPELLANT_ON_APPEAL_CASE_PARTICIPANT_CANNOT_BE_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // BEGIN, CR00303458, GP
  /**
   * Updates the ReceiptNoticeIndicator for the given CaseParticipantRoleID.
   * 
   * @param caseParticipantRoleIDAndIndicatorDetails
   * Contains the CaseParticipantRoleID and Indicator Details.
   * 
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public
    void
    modifyReceiptNoticeIndicator(
      final CaseParticipantRoleIDAndIndicatorDetails caseParticipantRoleIDAndIndicatorDetails)
      throws AppException, InformationalException {

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    final ReceiptIndicatorDetails receiptIndicatorDetails =
      new ReceiptIndicatorDetails();

    caseParticipantRoleKey.caseParticipantRoleID =
      caseParticipantRoleIDAndIndicatorDetails.caseParticipantRoleID;

    final AppellantKey appellantKey =
      readAppellantIDByCaseParticipantRoleID(caseParticipantRoleKey);

    receiptIndicatorDetails.receiptNoticeIndicator =
      caseParticipantRoleIDAndIndicatorDetails.receiptIndicator;

    modifyReceiptNoticeIndicator(appellantKey, receiptIndicatorDetails);

  }

  // END, CR00303458

  /**
   * Validates the Appellant Details to remove
   * 
   * @param details
   * Appellant details
   */
  @Override
  protected void precancelAppellant(final AppellantKey key,
    final CancelAppellantDetails details) throws AppException,
    InformationalException {

    validateCancel(key, details);

  }

  /**
   * Validates the Appellant Details to modify
   * 
   * @param details
   * Appellant details
   */
  @Override
  protected void
    premodify(final AppellantKey key, final AppellantDtls details)
      throws AppException, InformationalException {

    validateDetails(details);
    validateModify(key, details);

  }

}
