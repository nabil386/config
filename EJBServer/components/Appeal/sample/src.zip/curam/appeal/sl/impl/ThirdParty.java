/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.facade.struct.AppealListMemberDetails;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.HearingScheduleNoticeDetails;
import curam.appeal.sl.entity.struct.ThirdPartyDtls;
import curam.appeal.sl.entity.struct.ThirdPartyKey;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.struct.AddThirdPartyDetails;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealParticipantRoleTypeCode;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.ListThirdPartyDetailsList;
import curam.appeal.sl.struct.RemoveThirdPartyDetails;
import curam.appeal.sl.struct.UpdateThirdPartyDetails;
import curam.appeal.sl.struct.ViewThirdPartyDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.pdt.struct.InformationalMessage;
import curam.core.facade.pdt.struct.InformationalMessageList;
import curam.core.facade.struct.RepresentativeID;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.intf.AddressData;
import curam.core.intf.ConcernRole;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CancelCaseParticipantRoleDetails;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.CuramInd;
import curam.core.struct.ElementDetails;
import curam.core.struct.OtherAddressData;
import curam.message.BPOHEARINGCASE;
import curam.message.BPOTHIRDPARTY;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * Service Layer interface for ThirdParty. This class provides APIS to insert,
 * modify, delete and list Third Party details.
 * 
 */
public abstract class ThirdParty extends curam.appeal.sl.base.ThirdParty {

  // ___________________________________________________________________________
  /**
   * This method creates a Third Party for an appeal case.
   * 
   * @param details Contains the details of a Third Party.
   * 
   * @return List of Informational messages.
   */
  @Override
  public InformationalMessageList createThirdParty(
    final AddThirdPartyDetails details) throws AppException,
    InformationalException {

    // Pre validate insert
    validateInsert(details);

    // Third Party Object
    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    ThirdPartyDtls thirdPartyDtls = new ThirdPartyDtls();

    thirdPartyDtls = details.createThirdPartyDtls;

    // appeal entity variables

    final Appeal appeal = AppealFactory.newInstance();

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = details.caseID;

    details.createThirdPartyDtls.appealID =
      appeal.readAppealIDByCase(appealCaseIDKey).appealID;

    // informational message list
    final InformationalMessageList informationalMessageList =
      new InformationalMessageList();
    final InformationalManager informationalManager =
      new InformationalManager();
    final InformationalMessage informationalMessage =
      new InformationalMessage();
    String[] warnings;

    details.createThirdPartyDtls.fromDate = Date.getCurrentDate();

    // BEGIN, CR00096787, RKi
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID =
      details.createThirdPartyDtls.caseParticipantRoleID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd =
      clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      throw new AppException(
        curam.message.BPOAPPEALCLIENTMERGE.ERR_CREATE_APPEAL_CASE_DUPLICATE_THIRDPARTY);
    }
    // END, CR00096787

    if (details.thirdPartyName != null
      && details.thirdPartyName.trim().length() > 0) {
      // create a representative

      // Representative maintenance object
      final Representative representativeObj =
        RepresentativeFactory.newInstance();

      // Struct passed to Representative::registerRepresentative
      final RepresentativeRegistrationDetails representativeRegistrationDetails =
        new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName =
        details.thirdPartyName;

      // addressData object
      final AddressData addressDataObj = AddressDataFactory.newInstance();

      // if no address is passed in
      if (details.addressData.length() == 0) {

        // returns the address layout based on the locale of the system.
        representativeRegistrationDetails.representativeRegistrationDetails.addressData =
          addressDataObj.getAddressDataForLocale().addressData;

      } else {

        representativeRegistrationDetails.representativeRegistrationDetails.addressData =
          details.addressData;
      }
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode =
        details.phoneAreaCode;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber =
        details.phoneNumber;

      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate =
        curam.util.type.Date.getCurrentDate();

      representativeRegistrationDetails.representativeRegistrationDetails.sensitivity =
        SENSITIVITY.DEFAULTCODE;

      // Call registerRepresentative
      representativeObj
        .registerRepresentative(representativeRegistrationDetails);

      final RepresentativeID representativeID = new RepresentativeID();

      representativeID.representativeID =
        representativeRegistrationDetails.representativeDtls.concernRoleID;

      // create case participant role ThirdParty
      // Case Participant Role manipulation variables
      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();

      final CaseParticipantRoleDtls caseParticipantRoleDtls =
        new CaseParticipantRoleDtls();

      final AppealKey key = new AppealKey();

      key.appealID = details.createThirdPartyDtls.appealID;

      caseParticipantRoleDtls.participantRoleID =
        representativeID.representativeID;

      caseParticipantRoleDtls.caseID = details.caseID;
      caseParticipantRoleDtls.typeCode = CASEPARTICIPANTROLETYPE.THIRDPARTY;
      caseParticipantRoleDtls.fromDate =
        details.createThirdPartyDtls.fromDate;
      caseParticipantRoleDtls.participantRoleID =
        representativeID.representativeID;

      caseParticipantRoleObj.insert(caseParticipantRoleDtls);

      details.createThirdPartyDtls.caseParticipantRoleID =
        caseParticipantRoleDtls.caseParticipantRoleID;

      // Set Third Party type as Representative
      thirdPartyDtls.thirdPartyType =
        curam.codetable.THIRDPARTYTYPE.REPRESENTATIVE;

      thirdPartyDtls.caseParticipantRoleID =
        details.createThirdPartyDtls.caseParticipantRoleID;
    } else {
      // create case participant role ThirdParty
      // Case Participant Role manipulation variables
      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();

      final CaseParticipantRoleDtls caseParticipantRoleDtls =
        new CaseParticipantRoleDtls();

      final AppealKey key = new AppealKey();

      key.appealID = details.createThirdPartyDtls.appealID;

      caseParticipantRoleDtls.participantRoleID =
        details.createThirdPartyDtls.caseParticipantRoleID;
      caseParticipantRoleDtls.caseID = details.caseID;
      caseParticipantRoleDtls.typeCode = CASEPARTICIPANTROLETYPE.THIRDPARTY;
      caseParticipantRoleDtls.fromDate =
        details.createThirdPartyDtls.fromDate;

      caseParticipantRoleObj.insert(caseParticipantRoleDtls);

      details.createThirdPartyDtls.caseParticipantRoleID =
        caseParticipantRoleDtls.caseParticipantRoleID;

      thirdPartyDtls.thirdPartyType =
        details.createThirdPartyDtls.thirdPartyType;

      thirdPartyDtls.caseParticipantRoleID =
        details.createThirdPartyDtls.caseParticipantRoleID;
    }
    // create ThirdParty

    thirdPartyDtls.appealID = details.createThirdPartyDtls.appealID;
    thirdPartyDtls.fromDate = details.createThirdPartyDtls.fromDate;
    thirdPartyObj.insert(thirdPartyDtls);

    warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      informationalMessage.message = warnings[i];
      informationalMessageList.dtls.addRef(informationalMessage);
    }

    // BEGIN, CR CR00077640, NSP
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();

    caseAndStatusKey.caseID = details.caseID;
    caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;
    final int hearingsCount =
      hearingObj.countScheduledDateByCaseAndStatus(caseAndStatusKey).numberOfRecords;

    if (hearingsCount > 0) {
      // send notice to the Third party added, who is required to attend a
      // hearing
      if (details.createThirdPartyDtls.attendanceRequired) {
        createReceiptNoticeForThirdAprty(details.createThirdPartyDtls);
      }
    }
    // END, CR CR00077640

    return informationalMessageList;
  }

  // ___________________________________________________________________________
  /**
   * This method modify the Third Party details.
   * 
   * @param details Contains the details of the Third Party to be modified.
   */
  @Override
  public void updateThirdParty(final UpdateThirdPartyDetails details)
    throws AppException, InformationalException {

    // Third Party Object
    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    final curam.appeal.sl.entity.struct.ThirdPartyKey thirdPartyKey =
      new curam.appeal.sl.entity.struct.ThirdPartyKey();

    thirdPartyKey.thirdPartyID = details.updateThirdPartyDtls.thirdPartyID;

    // Update Third Party details
    thirdPartyObj.modify(thirdPartyKey, details.updateThirdPartyDtls);
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the details of the Third Party.
   * 
   * @param key identifies the Third Party.
   * 
   * @return details of the Third Party.
   */
  @Override
  public ViewThirdPartyDetails readThirdParty(final ThirdPartyKey key)
    throws AppException, InformationalException {

    // Third Party Object
    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    final ViewThirdPartyDetails viewThirdPartyDetails =
      new ViewThirdPartyDetails();

    viewThirdPartyDetails.readThirdPartyDtls = thirdPartyObj.read(key);

    // Read Third Party details
    return viewThirdPartyDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method removes the third party from an appeal case. If the appeal case
   * has hearing scheduled, then a notice is sent to the third party informing
   * him that he need not attend the hearing.
   * 
   * @param details Contains the details of the Third Party to be canceled.
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void cancelThirdParty(final RemoveThirdPartyDetails details)
    throws AppException, InformationalException {

    // Third Party Object
    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    // assign the third party id
    final ThirdPartyKey thirdPartyKey = new ThirdPartyKey();

    thirdPartyKey.thirdPartyID = details.removeDtls.thirdPartyID;
    details.removeDtls.toDate = Date.getCurrentDate();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.CaseIDScheduled caseIDScheduled =
      new curam.appeal.sl.entity.struct.CaseIDScheduled();
    HearingScheduleNoticeDetails hearingScheduleNoticeDetails;

    // Remove case participant role for this case
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    final CancelCaseParticipantRoleDetails cancelCaseParticipantRoleDetails =
      new CancelCaseParticipantRoleDetails();

    caseParticipantRoleKey.caseParticipantRoleID =
      thirdPartyObj.read(thirdPartyKey).caseParticipantRoleID;

    cancelCaseParticipantRoleDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelCaseParticipantRoleDetails.versionNo =
      caseParticipantRoleObj.read(caseParticipantRoleKey).versionNo;

    caseParticipantRoleObj.modifyRecordStatus(caseParticipantRoleKey,
      cancelCaseParticipantRoleDetails);

    // cancel the Third Party.
    thirdPartyObj.cancelThirdParty(thirdPartyKey, details.removeDtls);

    final curam.appeal.sl.intf.Hearing hearing =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // View Third Party details
    final ThirdPartyDtls thirdPartyDtls = thirdPartyObj.read(thirdPartyKey);

    caseParticipantRoleKey.caseParticipantRoleID =
      thirdPartyDtls.caseParticipantRoleID;

    CaseParticipantRoleDtls caseParticipantRoleDtls;

    caseParticipantRoleDtls =
      caseParticipantRoleObj.read(caseParticipantRoleKey);

    // Read hearing details
    caseIDScheduled.caseID = caseParticipantRoleDtls.caseID;

    final CaseParticipantRole_boKey caseParticipantRole_boKey =
      new CaseParticipantRole_boKey();

    caseParticipantRole_boKey.caseParticipantRoleID =
      thirdPartyDtls.caseParticipantRoleID;

    try {

      hearingScheduleNoticeDetails =
        hearingObj.readLatestScheduleNoticeDetailsByCase(caseIDScheduled);

      // send hearing attendance cancellation notice
      hearing.sendAttendanceCancellationNotice(caseParticipantRole_boKey);
    } catch (final RecordNotFoundException ex) {// No hearing scheduled
    }

  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the list of Third Parties.
   * 
   * @param key identifies the Appeal Case.
   * 
   * @return list of Third Party details
   */
  @Override
  public ListThirdPartyDetailsList listThirdParties(final AppealKey key)
    throws AppException, InformationalException {

    // Return List
    final ListThirdPartyDetailsList listThirdPartyDetailsList =
      new ListThirdPartyDetailsList();

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // Third Party Object
    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    // appeal variables
    final curam.appeal.sl.intf.Appeal appeal =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // retrieve the details
    listThirdPartyDetailsList.listDtls =
      thirdPartyObj.searchThirdPartiesByAppealID(key);

    // read page context description
    appealCaseDetails.caseID = appealObj.read(key).caseID;

    listThirdPartyDetailsList.contextDescription =
      appeal.getContextDescription(appealCaseDetails);

    informationalManager.failOperation();

    return listThirdPartyDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method validates for inserting the Third Party for an appeal case.
   * 
   * @param details Contains the details of a Third Party.
   */
  // BEGIN, CR00177241, PM
  protected void validateInsert(final AddThirdPartyDetails details)
    throws AppException, InformationalException {

    // END, CR00177241

    // Only one Third Party can be entered. The user can either select a
    // registered
    // Third Party or enter an unregistered Third Party.
    if (details.createThirdPartyDtls.caseParticipantRoleID != 0
      && details.thirdPartyName.length() > 0) {
      throw new AppException(
        BPOTHIRDPARTY.ERR_ONLY_ONE_THIRD_PARTY_CAN_BE_ENTERED);
    }

    // ////////////////////
    // Address Validation
    // ////////////////////
    boolean addressEntered = false;

    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = details.addressData;

    // Address manipulation variables
    final curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();

    if (addressObj.getFirstLine(otherAddressData).addressElementString
      .length() > 0) {
      addressEntered = true;
    } else if (addressObj.getCity(otherAddressData).addressElementString
      .length() > 0) {
      addressEntered = true;
    } else if (addressObj.getState(otherAddressData).addressElementString
      .length() > 0) {
      addressEntered = true;
    }

    // declare list of <name><value> pairs
    AddressMapList addressMapList;

    final AddressMap addressMap = new AddressMap();
    ElementDetails elementDetails;

    // AddressData object, Address Line list structures
    final curam.core.intf.AddressData addressDataObj =
      curam.core.fact.AddressDataFactory.newInstance();

    addressMapList = addressDataObj.parseDataToMap(otherAddressData);

    // set AddressMap to Line 2
    addressMap.name = curam.codetable.ADDRESSELEMENTTYPE.LINE2;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > 0) {
      addressEntered = true;
    }

    // set AddressMap to Line 3
    addressMap.name = curam.codetable.ADDRESSELEMENTTYPE.LINE3;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > 0) {
      addressEntered = true;
    }

    // set AddressMap to Zip
    addressMap.name = curam.codetable.ADDRESSELEMENTTYPE.ZIP;

    elementDetails = addressDataObj.findElement(addressMapList, addressMap);

    if (elementDetails.elementValue.length() > 0) {
      addressEntered = true;
    }

    // If unregistered Third Party address or phone details are entered,
    // then Third Party's name must be entered
    if ((addressEntered || details.phoneAreaCode.length() > 0 || details.phoneNumber
      .length() > 0) && details.thirdPartyName.length() == 0) {

      throw new AppException(
        BPOTHIRDPARTY.ERR_FOR_UNREGISTERED_THIRD_PARTY_NAME_MUST_BE_ENTERED);
    }

    // If unregistered Third Party name is entered, then Third Party's address
    // must be entered.
    if (!addressEntered && details.thirdPartyName.length() > 0) {

      throw new AppException(
        BPOTHIRDPARTY.ERR_FOR_UNREGISTERED_THIRD_PARTY_ADDRESS_MUST_BE_ENTERED);
    }

    // ////////////////////

    // Appeal CaseID Object
    final curam.appeal.sl.struct.CaseIDDetails caseIDDetails =
      new curam.appeal.sl.struct.CaseIDDetails();

    caseIDDetails.caseID = details.caseID;

    // Return object containing participant details list
    final AppealListMemberDetails appealListMemberDetails =
      new AppealListMemberDetails();

    // Participant Role Type Code Object
    final AppealParticipantRoleTypeCode appealParticipantRoleTypeCode =
      new AppealParticipantRoleTypeCode();

    // Appeal service layer object
    final curam.appeal.sl.intf.Appeal appeal =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Set Participant type code to APPELLANT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // Invoke service layer search for a list of valid appellants
    appealListMemberDetails.appealParticipantDetailsList =
      appeal.listCaseParticipantsByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    if (appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
      .size() > 0) {

      for (int i = 0; i < appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
        .size(); i++) {

        // The Third Party cannot be the Appellant on the Case.
        if (appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
          .item(i).participantRoleID == details.createThirdPartyDtls.caseParticipantRoleID) {

          throw new AppException(
            BPOTHIRDPARTY.ERR_THIRD_PARTY_CANNOT_BE_APPELLANT);
        }
      }
    }

    // Set Participant type code to RESPONDENT
    appealParticipantRoleTypeCode.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // Invoke service layer search for a list of valid respondents
    appealListMemberDetails.appealParticipantDetailsList =
      appeal.listCaseParticipantsByParticipantRoleType(caseIDDetails,
        appealParticipantRoleTypeCode);

    if (appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
      .size() > 0) {

      for (int i = 0; i < appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
        .size(); i++) {

        // The Third Party cannot be the Respondent on the Case.
        if (appealListMemberDetails.appealParticipantDetailsList.appealParticipantDetails
          .item(i).participantRoleID == details.createThirdPartyDtls.caseParticipantRoleID) {

          throw new AppException(
            BPOTHIRDPARTY.ERR_THIRD_PARTY_CANNOT_BE_RESPONDENT);
        }
      }
    }
  }

  // BEGIN, CR CR00068753, NSP
  // _________________________________________________________________________
  /**
   * This method sends receipts to the given Third Party.
   * 
   * @param dtls of ThirdPaprtyDtls of Third Party
   */
  public void createReceiptNoticeForThirdAprty(final ThirdPartyDtls dtls)
    throws AppException, InformationalException {

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = dtls.caseParticipantRoleID;

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Get appeal case ID and participant role ID
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails =
      new CaseIDAndParticipantRoleIDDetails();

    caseIDAndParticipantRoleIDDetails =
      caseParticipantRoleObj
        .readCaseIDAndParticipantRoleIDDetails(caseParticipantRoleKey);

    concernRoleKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    communicationDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    communicationDetails.correspondentConcernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;
    communicationDetails.subjectText =
      BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.communicationDate = Date.getCurrentDate();
    communicationDetails.concernRoleID = concernRoleKey.concernRoleID;

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.APPEALSCHEDULELOCATIONTHIRDPARTY;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

    // BEGIN, CR00293187, CD
    // appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    generateDocumentDetails.dtls.dataSetPrimaryKey =
      dtls.caseParticipantRoleID;
    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.APPEALSCHEDULELOCATIONTHIRDPARTY;

    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }
  // END, CR CR00068753

}
