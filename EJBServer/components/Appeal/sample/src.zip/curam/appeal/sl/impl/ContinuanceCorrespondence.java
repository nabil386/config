/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingParticipationFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.fact.HearingServiceSupplierFactory;
import curam.appeal.sl.entity.fact.HearingWitnessFactory;
import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.HearingParticipation;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.intf.HearingServiceSupplier;
import curam.appeal.sl.entity.intf.HearingWitness;
import curam.appeal.sl.entity.intf.ThirdParty;
import curam.appeal.sl.entity.struct.HearingCaseID;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingInterpreterNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingParticipationDtls;
import curam.appeal.sl.entity.struct.HearingRepresentativeNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterHearingKey;
import curam.appeal.sl.entity.struct.HearingWitnessNameAndParticipantDetailsList;
import curam.appeal.sl.entity.struct.ThirdPartyDtls;
import curam.appeal.sl.entity.struct.ThirdPartyKeyList;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.struct.ContinuanceNoticeDetails;
import curam.appeal.sl.struct.ContinueHearingDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.HearingContinueTypeDetails;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.HearingTypeDetails;
import curam.appeal.sl.struct.IsSufficientTimeForCorrespondence;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOCONTINUANCECORRESPONDENCE;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.util.ArrayList;
import java.util.List;

/**
 * Maintains business process functionality for creating notices for continued
 * hearing or hearing reviews.
 */
public abstract class ContinuanceCorrespondence extends
  curam.appeal.sl.base.ContinuanceCorrespondence {

  // ___________________________________________________________________________
  /**
   * Creates an appellant continuance notice, appropriate to the type of
   * hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createAppellantHearingNotice(final HearingTypeDetails type,
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // search for appellant (there can only be one)
    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

        communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
        communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
        communicationDetails.communicationDate = Date.getCurrentDate();

        communicationDetails.correspondentConcernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        // BEGIN, CR00202766, MC
        // correspondentTypeCode is not a mandatory entity field only set it if
        // the
        // correspondence is going to the primary client
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = details.caseID;

        if (CaseHeaderFactory.newInstance().readParticipantRoleID(
          caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
          communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
        }
        // END, CR00202766
        communicationDetails.userName = TransactionInfo.getProgramUser();

        // Add subject title to communication
        communicationDetails.subjectText =
          BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
            .getMessageText();

        communicationDetails.communicationText =
          GeneralAppealConstants.kSpace;

        communicationDetails.correspondentName =
          caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

        // Create the communication
        final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
          new XSLTemplateIDCodeKey();

        xslTemplateIDCodeKey.templateIDCode =
          TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
        xslTemplateIDCodeKey.localeIdentifier =
          TransactionInfo.getProgramLocale();

        final XSLTemplateUtility xslTemplateUtilityObj =
          XSLTemplateUtilityFactory.newInstance();

        final XSLTemplateInstanceKey xslTemplateInstanceKey =
          xslTemplateUtilityObj
            .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

        proFormaCommDetails.assign(communicationDetails);

        proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
        proFormaCommDetails.proFormaVersionNo =
          xslTemplateInstanceKey.templateVersion;

        concernRoleKey.concernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        proFormaCommDetails.addressID =
          concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
        proFormaCommDetails.caseID = details.caseID;
        // BEGIN, CR00293187, CD
        generateDocumentDetails.communicationID =
          communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

        // set primary key of the data set to the appellant
        generateDocumentDetails.dtls.dataSetPrimaryKey =
          caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

        // Set document code and type
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUANCE_NOTICE;

        // Generate the document
        appealProFormaDocumentGenerationObj
          .createConcernRoleProFormaDoc(generateDocumentDetails);
        // END, CR00293187
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates an appellant continuance notice for a hearing.
   * 
   * @param details
   * Continuance notice details
   */
  @Override
  protected void createAppellantHearingReviewNotice(
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    final HearingTypeDetails hearingTypeDetails = new HearingTypeDetails();

    hearingTypeDetails.hearingTypeCode = APPEALTYPE.HEARINGREVIEW;
    createAppellantHearingNotice(hearingTypeDetails, details);

  }

  // ___________________________________________________________________________
  /**
   * Creates all interpreter continuance notices, appropriate to the type of
   * hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createInterpreterHearingNotices(
    final HearingTypeDetails type, final ContinuanceNoticeDetails details)
    throws AppException, InformationalException {

    // Hearing Service Supplier object and manipulation variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
      new HearingServiceSupplierInterpreterHearingKey();
    HearingInterpreterNameParticipantDetailsList hearingInterpreterNameParticipantDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    hearingServiceSupplierInterpreterHearingKey.hearingID = details.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    // Search for interpreters
    hearingInterpreterNameParticipantDetailsList =
      hearingServiceSupplierObj
        .searchActiveInterpreterNameAndCaseParticipantByHearingID(hearingServiceSupplierInterpreterHearingKey);

    for (int i = 0; i < hearingInterpreterNameParticipantDetailsList.dtls
      .size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName = TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).fullName;

      // create communication for interpreter
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      // BEGIN, CR00124669, RKi
      proFormaCommDetails.assign(communicationDetails);
      // END, CR00124669
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      concernRoleKey.concernRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).participantRoleID;

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = details.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CONTINUANCE_NOTICE;

      // Generate document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates all continuance notices, appropriate for the type of hearing, for a
   * hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  public InformationalMsgDtlsList createNotices(
    final HearingContinueTypeDetails type,
    final ContinueHearingDetails details) throws AppException,
    InformationalException {

    // Hearing business object manipulation variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondence;
    final HearingTimeDetails hearingTimeDetails = new HearingTimeDetails();

    // Hearing entity manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingKey hearingKey = new HearingKey();
    HearingScheduleDate hearingScheduleDate;

    // Continuance notice details
    final ContinuanceNoticeDetails continuanceNoticeDetails =
      new ContinuanceNoticeDetails();

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    hearingKey.hearingID = details.hearingID;

    // read scheduled date
    hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);

    // set hearing time details
    hearingTimeDetails.scheduledDateTime =
      hearingScheduleDate.scheduledDateTime;
    hearingTimeDetails.hearingID = details.hearingID;

    // is there time for correspondence
    isSufficientTimeForCorrespondence =
      hearing_boObj.isSufficientTimeForCorrespondence(hearingTimeDetails);

    if (!isSufficientTimeForCorrespondence.isSufficientTime) {

      final LocalisableString insufficientTime =
        new LocalisableString(
          BPOCONTINUANCECORRESPONDENCE.ERR_INSUFFICIENT_TIME);

      final InformationalManager informationalManager =
        new InformationalManager();

      informationalManager.addInformationalMsg(insufficientTime,
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);

      final String[] warnings =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls =
          new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

      }

    }

    // Hearing type details
    final HearingTypeDetails hearingTypeDetails = new HearingTypeDetails();

    hearingTypeDetails.hearingTypeCode = type.hearingTypeCode;
    continuanceNoticeDetails.hearingID = details.hearingID;
    continuanceNoticeDetails.hearingTypeCode = type.hearingTypeCode;

    // read caseID
    HearingCaseID hearingCaseID = hearingObj.readCase(hearingKey);

    continuanceNoticeDetails.caseID = hearingCaseID.caseID;

    // BEGIN, CR00115728, RKi
    // Identify the Hearing and the Hearing Case
    hearingKey.hearingID = details.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // Legal Action Security will be in V Next
      createAppellantHearingNotice(hearingTypeDetails,
        continuanceNoticeDetails);
      createInterpreterHearingNotices(hearingTypeDetails,
        continuanceNoticeDetails);
      createRepresentativeHearingNotices(hearingTypeDetails,
        continuanceNoticeDetails);
      createThirdPartyHearingNotice(hearingTypeDetails,
        continuanceNoticeDetails);
      createWitnessHearingNotices(hearingTypeDetails,
        continuanceNoticeDetails);
      // START CR00132747 LP
      createParticipantHearingNotices(hearingTypeDetails,
        continuanceNoticeDetails);
      // END CR00132747 LP
    } else {
      if (type.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        createAppellantHearingNotice(hearingTypeDetails,
          continuanceNoticeDetails);
        createInterpreterHearingNotices(hearingTypeDetails,
          continuanceNoticeDetails);
        createRepresentativeHearingNotices(hearingTypeDetails,
          continuanceNoticeDetails);
        createThirdPartyHearingNotice(hearingTypeDetails,
          continuanceNoticeDetails);
        createWitnessHearingNotices(hearingTypeDetails,
          continuanceNoticeDetails);
      } else if (type.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

        createAppellantHearingReviewNotice(continuanceNoticeDetails);
        createRepresentativeHearingReviewNotices(continuanceNoticeDetails);
        createThirdPartyHearingReviewNotice(continuanceNoticeDetails);
        createRespondentHearingReviewNotice(continuanceNoticeDetails);

      }
    }
    return informationalMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Creates all hearing representative continuance notices, appropriate for the
   * type of hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createRepresentativeHearingNotices(
    final HearingTypeDetails type, final ContinuanceNoticeDetails details)
    throws AppException, InformationalException {

    // Hearing Representative entity and manipulation variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeNameParticipantDetailsList hearingRepresentativeNameParticipantDetailsList;

    // Hearing Representative business object and manipulation variables
    hearingIDStatusKeyHR.hearingID = details.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // search for representatives
    hearingRepresentativeNameParticipantDetailsList =
      hearingRepresentativeObj
        .searchActiveHearingRepNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHR);

    for (int i = 0; i < hearingRepresentativeNameParticipantDetailsList.dtls
      .size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName = TransactionInfo.getProgramUser();

      communicationDetails.subjectText =
        BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
          .getMessageText();

      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).fullName;

      // create communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      proFormaCommDetails.assign(communicationDetails);

      // BEGIN, CR00096927, RKi
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      // END, CR00096927
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = details.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set document id and template type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CONTINUANCE_NOTICE;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a representative continuance notice for a hearing review.
   * 
   * @param details
   * Continuance notice details
   */
  @Override
  protected void createRepresentativeHearingReviewNotices(
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    final HearingTypeDetails hearingTypeDetails = new HearingTypeDetails();

    hearingTypeDetails.hearingTypeCode = APPEALTYPE.HEARINGREVIEW;
    createRepresentativeHearingNotices(hearingTypeDetails, details);

  }

  // ___________________________________________________________________________
  /**
   * Creates a respondent continuance notice for a hearing review.
   * 
   * @param details
   * Continuance notice details
   */
  @Override
  protected void createRespondentHearingReviewNotice(
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // search for respondent
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName = TransactionInfo.getProgramUser();

      communicationDetails.subjectText =
        BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
          .getMessageText();

      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;

      // create communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = details.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;

      // set document id and template type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CONTINUANCE_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a third party continuance notice, appropriate for the type of
   * hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  protected void createThirdPartyHearingNotice(
    @SuppressWarnings(GeneralAppealConstants.kUnused)
    final HearingTypeDetails type, final ContinuanceNoticeDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object and manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    // search for third party
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read Third Parties for which notice has to be sent
    final List thirdPartiesList = new ArrayList();

    // Hearing Service Layer Object
    final HearingKey hearingKey = new HearingKey();

    hearingKey.hearingID = details.hearingID;

    // ThirdParty Service Layer Object
    final ThirdParty thirdParty = ThirdPartyFactory.newInstance();

    // List of active Third Parties for the Hearing
    final ThirdPartyKeyList thirdPartyKeyList =
      thirdParty.searchThirdPartyByHearingID(hearingKey);

    for (int i = 0; i < thirdPartyKeyList.dtls.size(); i++) {
      final ThirdPartyDtls thirdPartyDtls =
        thirdParty.read(thirdPartyKeyList.dtls.item(i));

      // If attendance required, then only need to send the notice
      if (thirdPartyDtls.attendanceRequired) {
        thirdPartiesList.add(new Long(thirdPartyDtls.caseParticipantRoleID));
      }
    }

    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

        final Long caseParticipantRoleID =
          new Long(
            caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID);

        // If ThirdParty has attendance required then send notice
        if (thirdPartiesList.contains(caseParticipantRoleID)) {

          communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
          communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
          communicationDetails.communicationDate = Date.getCurrentDate();
          communicationDetails.correspondentConcernRoleID =
            caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
          // BEGIN, CR00202766, MC
          // correspondentTypeCode is not a mandatory entity field only set it
          // if the
          // correspondence is going to the primary client
          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = details.caseID;

          if (CaseHeaderFactory.newInstance().readParticipantRoleID(
            caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
            communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
          }
          // END, CR00202766
          communicationDetails.userName = TransactionInfo.getProgramUser();

          communicationDetails.subjectText =
            BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
              .getMessageText();

          communicationDetails.communicationText =
            GeneralAppealConstants.kSpace;

          communicationDetails.correspondentName =
            caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

          // create communication
          final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
            new XSLTemplateIDCodeKey();

          xslTemplateIDCodeKey.templateIDCode =
            TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
          xslTemplateIDCodeKey.localeIdentifier =
            TransactionInfo.getProgramLocale();

          final XSLTemplateUtility xslTemplateUtilityObj =
            XSLTemplateUtilityFactory.newInstance();

          final XSLTemplateInstanceKey xslTemplateInstanceKey =
            xslTemplateUtilityObj
              .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

          concernRoleKey.concernRoleID =
            caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
          proFormaCommDetails.assign(communicationDetails);

          // BEGIN, CR CR00067730, NSP
          proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
          proFormaCommDetails.proFormaVersionNo =
            xslTemplateInstanceKey.templateVersion;
          // END, CR CR00067730

          proFormaCommDetails.addressID =
            concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
          proFormaCommDetails.caseID = details.caseID;
          // BEGIN, CR00293187, CD
          generateDocumentDetails.communicationID =
            communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

          // Set data set key
          generateDocumentDetails.dtls.dataSetPrimaryKey =
            caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

          // set document id and template type
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
          generateDocumentDetails.dtls.dataSetType =
            DATASETTYPE.CONTINUANCE_NOTICE;

          // Generate the document
          appealProFormaDocumentGenerationObj
            .createConcernRoleProFormaDoc(generateDocumentDetails);
          // END, CR00293187
        }
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates third party hearing review notices.
   * 
   * @param details
   * Continuance notice details
   */
  @Override
  protected void createThirdPartyHearingReviewNotice(
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    final HearingTypeDetails hearingTypeDetails = new HearingTypeDetails();

    hearingTypeDetails.hearingTypeCode = APPEALTYPE.HEARINGREVIEW;
    createThirdPartyHearingNotice(hearingTypeDetails, details);

  }

  // ___________________________________________________________________________
  /**
   * Creates all witness continuance notices, appropriate for the type of
   * hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createWitnessHearingNotices(final HearingTypeDetails type,
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {

    // Hearing Witness entity and manipulation variables
    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    final HearingIDStatusKeyHW hearingIDStatusKeyHW =
      new HearingIDStatusKeyHW();
    HearingWitnessNameAndParticipantDetailsList hearingWitnessNameAndParticipantDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    hearingIDStatusKeyHW.hearingID = details.hearingID;
    hearingIDStatusKeyHW.recordStatus = RECORDSTATUS.NORMAL;

    // search for witnesses
    hearingWitnessNameAndParticipantDetailsList =
      hearingWitnessObj
        .searchActiveHearingWitnessNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHW);

    for (int i = 0; i < hearingWitnessNameAndParticipantDetailsList.dtls
      .size(); i++) {

      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName = TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).fullName;

      // create communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).participantRoleID;
      proFormaCommDetails.assign(communicationDetails);
      // BEING, CR00095673, RKi
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      // END, CR00095673
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = details.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // set document id and template type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CONTINUANCE_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // BEGIN CR00118512 LP
  // ___________________________________________________________________________
  /**
   * Creates all witness continuance notices, appropriate for the type of
   * hearing, for a hearing.
   * 
   * @param type
   * Hearing type code
   * @param details
   * Continuance notice details
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createParticipantHearingNotices(
    final HearingTypeDetails type, final ContinuanceNoticeDetails details)
    throws AppException, InformationalException {

    final curam.appeal.sl.struct.HearingKey slHearingKey =
      new curam.appeal.sl.struct.HearingKey();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    final HearingParticipationDtls hearingLegalParticipantDtls =
      new HearingParticipationDtls();
    // HearingLegalParticipant variables
    final HearingParticipation hearingLegalParticipantObj =
      HearingParticipationFactory.newInstance();
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Read the CaseID and search for participants
    slHearingKey.hearingKey.hearingID = details.hearingID;
    final curam.appeal.sl.struct.HearingCaseID hearingCaseID =
      HearingFactory.newInstance().getCase(slHearingKey);

    caseParticipantRoleCaseAndTypeKey.caseID =
      hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;
    final CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList =
      caseParticipantRole
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int i = 0; i < caseParticipantRoleIDDetailsList.dtls.size(); i++) {

      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName = TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOCONTINUANCECORRESPONDENCE.INF_HEARING_CONTINUED_SUBJECT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // create communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;

      communicationDetails.correspondentName =
        ConcernRoleFactory.newInstance().read(concernRoleKey).concernRoleName;

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = details.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleIDDetailsList.dtls.item(i).caseParticipantRoleID;

      // set document id and template type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCONTINUANCENOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CONTINUANCE_NOTICE;

      // Generate document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // END CR00118512 LP

  // ___________________________________________________________________________
  /**
   * Creates a respondent continuance notice for a hearing case.
   * 
   * @param details
   * Continuance notice details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createRespondentHearingCaseNotice(
    final ContinuanceNoticeDetails details) throws AppException,
    InformationalException {//

  }

}
