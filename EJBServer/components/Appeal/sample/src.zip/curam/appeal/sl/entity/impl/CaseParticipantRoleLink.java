/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.CaseParticipantRoleID;
import curam.appeal.sl.entity.struct.CaseParticipantRoleIDRelatedID;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDtlsStruct1;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkKey;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkKeyStruct1;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * An implementation to overwrite the 'CaseParticipantRoleLink' entity
 * operations.
 * This could also be used to provide implementation for
 * Pre-Data-Access/Post-Data-Access operations of 'CaseParticipantRoleLink'
 * entity.
 */
public abstract class CaseParticipantRoleLink extends
  curam.appeal.sl.entity.base.CaseParticipantRoleLink {

  /**
   * Updates the CaseParticipantRoleID for the given Related ID.
   * 
   * @param caseParticipantRoleIDRelatedID
   * Contains the CaseParticipantRoleID and Related ID Details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modifyCaseParticipantRoleIDByRelatedID(
    final CaseParticipantRoleIDRelatedID caseParticipantRoleIDRelatedID)
    throws AppException, InformationalException {

    final CaseParticipantRoleLinkKeyStruct1 caseParticipantRoleLinkStructKey =
      new CaseParticipantRoleLinkKeyStruct1();
    final CaseParticipantRoleLinkKey caseParticipantRoleLinkKey =
      new CaseParticipantRoleLinkKey();
    CaseParticipantRoleLinkDtlsStruct1 caseParticipantRoleLinkDtls =
      new CaseParticipantRoleLinkDtlsStruct1();

    final CaseParticipantRoleID caseParticipantRoleID =
      new CaseParticipantRoleID();

    caseParticipantRoleLinkStructKey.relatedID =
      caseParticipantRoleIDRelatedID.relatedID;

    caseParticipantRoleLinkDtls =
      readByRelatedID(caseParticipantRoleLinkStructKey);
    // BEGIN, CR00304047, GP
    caseParticipantRoleLinkKey.caseParticipantRoleLinkID =
      caseParticipantRoleLinkDtls.caseParticipantRoleLinkID;
    caseParticipantRoleID.caseParticipantRoleID =
      caseParticipantRoleIDRelatedID.caseParticipantRoleID;
    // END, CR00304047

    modifyCaseParticipantRoleIDByRelatedID(caseParticipantRoleLinkKey,
      caseParticipantRoleID);
  }

}
