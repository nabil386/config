/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.impl;

import curam.appeal.facade.struct.AttendeeTabList;
import curam.appeal.sl.struct.HearingAttendanceDetails;
import curam.appeal.sl.struct.HearingAttendanceDetailsList;
import curam.codetable.HEARINGPARTICIPATION;
import curam.core.impl.CuramConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.type.StringList;

/**
 * Utility class which contains functionality to parse hearing attendance
 * details.
 */
public abstract class HearingAttendanceParser extends
  curam.appeal.sl.base.HearingAttendanceParser {

  // ___________________________________________________________________________
  /**
   * Parses a delimited string containing multiple instances of attendance
   * information for a hearing into an object list.
   * 
   * @param details
   * attendee details delimited string
   * @return list of attendance information for a hearing
   */
  @Override
  public HearingAttendanceDetailsList parse(final AttendeeTabList details)
    throws AppException, InformationalException {

    // list to be returned
    final HearingAttendanceDetailsList hearingAttendanceDetailsList =
      new HearingAttendanceDetailsList();

    HearingAttendanceDetails hearingAttendanceDetails;

    // Hearing attendance string list
    StringList hearingAttendanceStringList;

    // Single attendant details
    StringList stringAttendantDetailsList;

    // convert tab delimited string to list of strings
    hearingAttendanceStringList =
      StringUtil.tabText2StringList(details.caseUserRoleTabList);

    int j;

    // iterate through the list
    for (int i = 0; i < hearingAttendanceStringList.size(); i++) {

      hearingAttendanceDetails = new HearingAttendanceDetails();

      // convert the string to the list of elements
      stringAttendantDetailsList =
        StringUtil
          .delimitedText2StringList(hearingAttendanceStringList.item(i),
            CuramConst.gkPipeDelimiterChar);

      // data format is:
      // caseParticipantRoleID|attendanceCode|hearingAttendanceKey|
      // hearingAttendanceVersionNo|userName|displayName

      // for each single element, depending on the position in the string,
      // set appropriate field
      for (j = 0; j < stringAttendantDetailsList.size(); j++) {

        switch (j) {

          case 0: {
            // set case participant role data
            hearingAttendanceDetails.caseParticipantRoleID =
              Long.parseLong(stringAttendantDetailsList.item(j));
            break;
          }

          case 1: {
            // set attendanceCode
            hearingAttendanceDetails.attendanceCode =
              stringAttendantDetailsList.item(j);
            break;
          }

          case 2: {
            // set hearingAttendanceKey
            hearingAttendanceDetails.hearingAttendanceKey =
              Long.parseLong(stringAttendantDetailsList.item(j));
            break;
          }

          case 3: {
            // set hearingAttendanceVersionNo
            hearingAttendanceDetails.hearingAttendanceVersionNo =
              Integer.parseInt(stringAttendantDetailsList.item(j));
            break;
          }

          case 4: {
            // set userName
            hearingAttendanceDetails.userName =
              stringAttendantDetailsList.item(j);
            break;
          }

          case 5: {
            // set displayName
            hearingAttendanceDetails.displayName =
              stringAttendantDetailsList.item(j);
            break;
          }

          default: {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager()
              .throwWithLookup(
                new AppException(
                  curam.message.BPOHEARINGATTENDANCEPARSER.ERR_INCORRECT_FORMAT),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          }

        }

      }

      // set participated code
      hearingAttendanceDetails.participatedCode =
        HEARINGPARTICIPATION.PARTICIPATED;

      // add to the list
      hearingAttendanceDetailsList.hearingAttendanceDetails
        .addRef(hearingAttendanceDetails);

    }

    return hearingAttendanceDetailsList;

  }

}
