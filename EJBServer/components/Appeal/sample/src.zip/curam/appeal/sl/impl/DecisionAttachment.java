/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */
package curam.appeal.sl.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.appeal.sl.entity.fact.HearingDecisionAttachmentLinkFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingDecisionAttachmentLink;
import curam.appeal.sl.entity.struct.AttachmentAndDecisionIDDetails;
import curam.appeal.sl.entity.struct.DecisionAttachmentLinkStatus;
import curam.appeal.sl.entity.struct.HearingDecisionAttachmentLinkDtls;
import curam.appeal.sl.entity.struct.HearingDecisionAttachmentLinkKey;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionDtls;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionStatusVersionDetails;
import curam.appeal.sl.entity.struct.HearingDecisionVersionDetails;
import curam.appeal.sl.entity.struct.ModifyDecisionStatusDetails;
import curam.appeal.sl.fact.AppealDecisionFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.intf.AppealDecision;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealDecisionAttachmentDetails;
import curam.appeal.sl.struct.AppealResolutionDetails;
import curam.appeal.sl.struct.AttachmentDateStatusAndTemplate;
import curam.appeal.sl.struct.AttachmentIDDetails;
import curam.appeal.sl.struct.CancelDecisionAttachmentDetails;
import curam.appeal.sl.struct.CreateDecisionAttachmentDetails;
import curam.appeal.sl.struct.CreateInternalAttachmentDetails;
import curam.appeal.sl.struct.DecisionAttachmentForModifyDetails;
import curam.appeal.sl.struct.DecisionAttachmentKey;
import curam.appeal.sl.struct.DecisionAttachmentSummaryDetails;
import curam.appeal.sl.struct.InternalAttachmentDetails;
import curam.appeal.sl.struct.ModifyDecisionAttachmentDetails;
import curam.appeal.sl.struct.ReadForDownloadDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.attachment.impl.Attachment;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.CASESTATUS;
import curam.codetable.DECISIONATTACHMENTTYPE;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.DocumentTemplateFactory;
import curam.core.sl.entity.intf.DocumentTemplate;
import curam.core.sl.entity.struct.DocumentTemplateDtls;
import curam.core.sl.entity.struct.DocumentTemplateKey;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.message.BPODECISIONATTACHMENT;
import curam.message.BPOHEARINGDECISIONATTACHMENTLINK;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.UniqueID;

/**
 * This process class creates and manages all decision attachments for an appeal
 * decision. Decision documents which are attached can be either external
 * documents or internally created word documents.
 */
public abstract class DecisionAttachment extends
  curam.appeal.sl.base.DecisionAttachment {

  // BEGIN, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;

  // BEGIN, CR00360398, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00360398

  // Add injection for using the new Attachment API
  public DecisionAttachment() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00226594

  // ___________________________________________________________________________
  /**
   * Validates the creation of a new decision attachment.
   * 
   * @param details
   * The decision attachment creation details
   */
  @Override
  protected void validateCreateExternal(
    final CreateDecisionAttachmentDetails details) throws AppException,
    InformationalException {

    // Variables for Case Header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseStatusCode caseStatusCode = new CaseStatusCode();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Validation Object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Read the status of the Case Header for the appeal case
    caseHeaderKey.caseID = details.appealCaseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);

    // Validate that the appeal case is active
    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XRV_MAINTAIN_ACTIVE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate that only one type of attachment is specified
    if ((details.createAttachmentDetails.fileLocation.length() > 0 || details.createAttachmentDetails.fileReference
      .length() > 0)
      && details.createAttachmentDetails.attachmentName.length() > 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_ATTACHMENT_TYPE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate that either both the document location and reference are
    // specified or else that an external attachment name is specified
    if (details.createAttachmentDetails.attachmentName.length() == 0
      && (details.createAttachmentDetails.fileReference.length() == 0
        && details.createAttachmentDetails.fileLocation.length() > 0 || details.createAttachmentDetails.fileLocation
        .length() == 0
        && details.createAttachmentDetails.fileReference.length() > 0)) {
      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_DOCUMENT_REFERENCE_LOCATION),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Validate that an external document is specified
    if (details.createAttachmentDetails.attachmentName.length() == 0
      && details.createAttachmentDetails.fileReference.length() == 0
      && details.createAttachmentDetails.fileLocation.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_EXTERNAL_DOCUMENT), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Report any validation failures
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Validates the creation of a new decision attachment.
   * 
   * @param details
   * The decision attachment creation details
   */
  @Override
  protected void validateCreateMSWord(
    final CreateInternalAttachmentDetails details) throws AppException,
    InformationalException {

    // Variables for Case Header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseStatusCode caseStatusCode = new CaseStatusCode();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Validation Object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Read the status of the Case Header for the appeal case
    caseHeaderKey.caseID = details.appealCaseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);

    // Validate that the appeal case is active
    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XRV_MAINTAIN_ACTIVE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate that only one type of attachment is specified
    if (details.documentTemplateIDPopup.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        curam.message.BPODECISIONATTACHMENT.ERR_FV_TEMPLATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Report any validation failures
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Creates the actual attachment for the decision attachment. Note that
   * decision attachments are not linked directly to the case using the standard
   * case attachment processing; instead these are managed separately using the
   * HearingDecisionAttachmentLink entity.
   * 
   * @param details
   * The details of the external document attachment.
   * @return The attachment ID details
   */
  @Override
  protected AttachmentIDDetails createAttachment(
    final AppealDecisionAttachmentDetails details) throws AppException,
    InformationalException {

    // Return Variable
    final AttachmentIDDetails attachmentIDDetails = new AttachmentIDDetails();

    // Variables for Attachment
    final AttachmentDtls attachmentDtls = new AttachmentDtls();

    // Determine if the contents of the attachment are included
    if (details.attachmentContents.length() > 0) {
      attachmentDtls.attachedFileInd = true;
    } else {
      attachmentDtls.attachedFileInd = false;
    }

    // Insert the Attachment
    attachmentDtls.attachmentContents = details.attachmentContents;
    attachmentDtls.attachmentName = details.attachmentName;
    attachmentDtls.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
    attachmentDtls.statusCode = RECORDSTATUS.NORMAL;
    attachmentDtls.fileLocation = details.fileLocation;
    attachmentDtls.fileReference = details.fileReference;
    attachmentDtls.documentType = DOCUMENTTYPE.DECISION;
    attachmentDtls.receiptDate = Date.getCurrentDate();
    attachmentObj.insert(attachmentDtls);

    // Return the new attachment ID
    attachmentIDDetails.attachmentID = attachmentDtls.attachmentID;

    return attachmentIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates the decision attachment details for modification. This applies
   * only to external documents which have been attached.
   * 
   * @param details
   * The external document attachment details being modified.
   */
  @Override
  protected void validateModifyExternal(
    final ModifyDecisionAttachmentDetails details) throws AppException,
    InformationalException {

    // Validation Object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Variables for HearingDecisionAttacmentLink entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();
    DecisionAttachmentLinkStatus decisionAttachmentLinkStatus;

    // Validate that only one type of attachment is specified
    if ((details.appealDecisionAttachmentDetails.fileLocation.length() > 0 || details.appealDecisionAttachmentDetails.fileReference
      .length() > 0)
      && details.appealDecisionAttachmentDetails.attachmentName.length() > 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_ATTACHMENT_TYPE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate that either both the document location and reference are
    // specified or else that an external attachment name is specified
    if (details.appealDecisionAttachmentDetails.attachmentName.length() == 0
      && (details.appealDecisionAttachmentDetails.fileReference.length() == 0
        && details.appealDecisionAttachmentDetails.fileLocation.length() > 0 || details.appealDecisionAttachmentDetails.fileLocation
        .length() == 0
        && details.appealDecisionAttachmentDetails.fileReference.length() > 0)) {
      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_DOCUMENT_REFERENCE_LOCATION),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Validate that an external document is specified
    if (details.appealDecisionAttachmentDetails.attachmentName.length() == 0
      && details.appealDecisionAttachmentDetails.fileReference.length() == 0
      && details.appealDecisionAttachmentDetails.fileLocation.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONATTACHMENT.ERR_XFV_EXTERNAL_DOCUMENT), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Get the status of the decision attachment link
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      details.attachmentLinkID;
    decisionAttachmentLinkStatus =
      hearingDecisionAttachmentLinkObj
        .readStatus(hearingDecisionAttachmentLinkKey);

    // Validate that the decision attachment link has not been canceled
    if (decisionAttachmentLinkStatus.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGDECISIONATTACHMENTLINK.ERR_HEARINGDECISIONATTACHMENTLINK_FV_STATUS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Report any validation failures
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Validates the cancellation of a decision attachment.
   * 
   * @param details
   * The decision attachment cancellation details.
   */
  @Override
  protected void
    validateCancel(final CancelDecisionAttachmentDetails details)
      throws AppException, InformationalException {

    // Validation Object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Variables for HearingDecisionAttacmentLink entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();
    DecisionAttachmentLinkStatus decisionAttachmentLinkStatus;

    // Get status of decision attachment link
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      details.attachmentLinkID;
    decisionAttachmentLinkStatus =
      hearingDecisionAttachmentLinkObj
        .readStatus(hearingDecisionAttachmentLinkKey);

    // Validate that the decision attachment has not been canceled
    if (decisionAttachmentLinkStatus.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGDECISIONATTACHMENTLINK.ERR_HEARINGDECISIONATTACHMENTLINK_FV_STATUS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Report any validation failures
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Creates an external appeal decision attachment. Either the contents of the
   * file are being attached or a reference to a hard copy of the file is being
   * attached.
   * 
   * @param details
   * The details of the externally created decision attachment
   */
  @Override
  public void createExternal(final CreateDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Decision Attachment, Service Layer variables
    final AppealDecisionAttachmentDetails appealDecisionAttachmentDetails =
      new AppealDecisionAttachmentDetails();
    AttachmentIDDetails attachmentIDDetails;

    // Hearing Decision, Entity Layer variables
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();

    // Hearing Decision Attachment Link, Entity Layer variables
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkDtls hearingDecisionAttachmentLinkDtls =
      new HearingDecisionAttachmentLinkDtls();

    // Local variable used to check if a decision already exists
    Count count;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = details.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kCreateSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the new decision attachment
    validateCreateExternal(details);

    // Get the Hearing Decision ID for the appeal case
    hearingDecisionCaseKey.caseID = details.appealCaseID;
    count = hearingDecisionObj.countIDByCase(hearingDecisionCaseKey);
    if (count.numberOfRecords == 1) {
      hearingDecisionKey =
        hearingDecisionObj.readIDByCase(hearingDecisionCaseKey);
      // If the decision does not yet exist then create a new decision
    } else if (count.numberOfRecords == 0) {

      // Local variables used to create new decision
      final HearingDecisionDtls hearingDecisionDtls =
        new HearingDecisionDtls();
      final AppealDecision appealDecisionObj =
        AppealDecisionFactory.newInstance();
      final AppealCaseKey appealCaseKey = new AppealCaseKey();
      AppealResolutionDetails appealResolutionDetails;

      // Calculate resolution based on appealed case resolutions
      appealCaseKey.caseID = details.appealCaseID;
      appealResolutionDetails =
        appealDecisionObj.calculateResolution(appealCaseKey);

      // Insert a hearing decision
      hearingDecisionDtls.caseID = details.appealCaseID;
      hearingDecisionDtls.decisionStatus = HEARINGDECISIONSTATUS.NOTSTARTED;
      hearingDecisionDtls.decisionDate = Date.getCurrentDate();
      hearingDecisionDtls.hearingDecisionID = UniqueID.nextUniqueID();
      hearingDecisionDtls.resolutionCode =
        appealResolutionDetails.resolutionCode;
      hearingDecisionObj.insert(hearingDecisionDtls);
      hearingDecisionKey.hearingDecisionID =
        hearingDecisionDtls.hearingDecisionID;
    }

    // BEGIN, CR00360398, CD
    // set up meta data for the attachment
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(details.appealCaseID));
    // END, CR00360398

    // Create the Attachment
    appealDecisionAttachmentDetails.attachmentContents =
      details.createAttachmentDetails.attachmentContents;
    appealDecisionAttachmentDetails.attachmentName =
      details.createAttachmentDetails.attachmentName;
    appealDecisionAttachmentDetails.fileLocation =
      details.createAttachmentDetails.fileLocation;
    appealDecisionAttachmentDetails.fileReference =
      details.createAttachmentDetails.fileReference;
    attachmentIDDetails = createAttachment(appealDecisionAttachmentDetails);

    // Insert a link from the decision attachment to the hearing decision
    hearingDecisionAttachmentLinkDtls.decisionAttachmentType =
      DECISIONATTACHMENTTYPE.EXTERNAL;
    hearingDecisionAttachmentLinkDtls.attachmentDate = Date.getCurrentDate();
    hearingDecisionAttachmentLinkDtls.attachmentID =
      attachmentIDDetails.attachmentID;
    hearingDecisionAttachmentLinkDtls.attachmentLinkID =
      UniqueID.nextUniqueID();
    hearingDecisionAttachmentLinkDtls.hearingDecisionID =
      hearingDecisionKey.hearingDecisionID;
    hearingDecisionAttachmentLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
    hearingDecisionAttachmentLinkObj
      .insert(hearingDecisionAttachmentLinkDtls);
  }

  /**
   * Creates an internally generated decision attachment.
   * 
   * An internal document is being attached when a valid template is provided;
   * in this instance no attachment details are provided but the attachment for
   * the internal document is created. The details of the document are then
   * created separately.
   * 
   * @param details
   * The decision attachment creation details.
   * 
   * @return The identifier for the hearing decision attachment.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public DecisionAttachmentKey createMSWord(
    final CreateInternalAttachmentDetails details) throws AppException,
    InformationalException {

    // Return variable
    final DecisionAttachmentKey decisionAttachmentKey =
      new DecisionAttachmentKey();

    // Decision Attachment, Service Layer variables
    final AppealDecisionAttachmentDetails appealDecisionAttachmentDetails =
      new AppealDecisionAttachmentDetails();
    AttachmentIDDetails attachmentIDDetails;

    // Hearing Decision, Entity Layer variables
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();

    new HearingDecisionCaseKey();
    HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();

    // Hearing Decision Attachment Link, Entity Layer variables
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkDtls hearingDecisionAttachmentLinkDtls =
      new HearingDecisionAttachmentLinkDtls();

    // Local variable used to check if a decision already exists
    Count count;

    // Validate the new decision attachment
    validateCreateMSWord(details);

    // Get the Hearing Decision ID for the appeal case
    hearingDecisionCaseKey.caseID = details.appealCaseID;
    count = hearingDecisionObj.countIDByCase(hearingDecisionCaseKey);
    if (count.numberOfRecords == 1) {
      hearingDecisionKey =
        hearingDecisionObj.readIDByCase(hearingDecisionCaseKey);
    } else if (count.numberOfRecords == 0) {
      // If the decision does not yet exist then create a new decision

      // Local variables used to create new decision
      final HearingDecisionDtls hearingDecisionDtls =
        new HearingDecisionDtls();
      final AppealDecision appealDecisionObj =
        AppealDecisionFactory.newInstance();
      final AppealCaseKey appealCaseKey = new AppealCaseKey();
      AppealResolutionDetails appealResolutionDetails;

      // Calculate resolution based on appealed case resolutions
      appealCaseKey.caseID = details.appealCaseID;
      appealResolutionDetails =
        appealDecisionObj.calculateResolution(appealCaseKey);

      // Insert a hearing decision
      hearingDecisionDtls.caseID = details.appealCaseID;
      hearingDecisionDtls.decisionStatus = HEARINGDECISIONSTATUS.NOTSTARTED;
      hearingDecisionDtls.decisionDate = Date.getCurrentDate();
      hearingDecisionDtls.hearingDecisionID = UniqueID.nextUniqueID();
      hearingDecisionDtls.resolutionCode =
        appealResolutionDetails.resolutionCode;
      hearingDecisionObj.insert(hearingDecisionDtls);
      hearingDecisionKey.hearingDecisionID =
        hearingDecisionDtls.hearingDecisionID;
    }

    // BEGIN, CR00246111, NS
    final DocumentTemplate documentTemplate =
      DocumentTemplateFactory.newInstance();
    final DocumentTemplateKey documentTemplateKey = new DocumentTemplateKey();

    documentTemplateKey.documentTemplateID = details.documentTemplateIDPopup;
    final DocumentTemplateDtls documentTemplateDtls =
      documentTemplate.read(documentTemplateKey);

    // Create the decision attachment.
    appealDecisionAttachmentDetails.attachmentContents =
      documentTemplateDtls.contents;

    final String delimiter =
      GeneralAppealConstants.kSlashDelimiter
        + GeneralAppealConstants.kDotDelimiter;
    final String[] temp = documentTemplateDtls.filename.split(delimiter);
    String kFileNameExtension = ExtensionConst.kFileNameExtension;

    kFileNameExtension =
      GeneralAppealConstants.kDotDelimiter + temp[temp.length - 1];
    appealDecisionAttachmentDetails.attachmentName =
      documentTemplateDtls.name.concat(kFileNameExtension);
    // END, CR00246111

    // BEGIN, CR00360398, CD
    // set up meta data for the attachment
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(details.appealCaseID));
    // END, CR00360398

    // Create the decision attachment
    attachmentIDDetails = createAttachment(appealDecisionAttachmentDetails);

    // Insert a link from the decision attachment to the hearing decision
    hearingDecisionAttachmentLinkDtls.decisionAttachmentType =
      DECISIONATTACHMENTTYPE.MSWORD;
    hearingDecisionAttachmentLinkDtls.attachmentID =
      attachmentIDDetails.attachmentID;
    hearingDecisionAttachmentLinkDtls.attachmentDate = Date.getCurrentDate();
    hearingDecisionAttachmentLinkDtls.documentTemplateID =
      details.documentTemplateIDPopup;
    hearingDecisionAttachmentLinkDtls.attachmentLinkID =
      UniqueID.nextUniqueID();
    hearingDecisionAttachmentLinkDtls.hearingDecisionID =
      hearingDecisionKey.hearingDecisionID;
    hearingDecisionAttachmentLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
    hearingDecisionAttachmentLinkObj
      .insert(hearingDecisionAttachmentLinkDtls);
    decisionAttachmentKey.hearingDecisionAttachmentLinkKey.attachmentLinkID =
      hearingDecisionAttachmentLinkDtls.attachmentLinkID;

    return decisionAttachmentKey;

  }

  // ___________________________________________________________________________
  /**
   * Modifies an appeal decision attachment where an external document has been
   * attached.
   * 
   * @param details
   * The decision attachment details for modification
   */
  @Override
  public void modifyExternal(final ModifyDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Variables for Hearing Decision entity
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();

    // Variables for Hearing Decision Attachment Link entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    AttachmentAndDecisionIDDetails attachmentAndDecisionIDDetails;
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();

    // Variables for Attachment
    final AttachmentKey attachmentKey = new AttachmentKey();
    final AttachmentDtls attachmentDtls = new AttachmentDtls();

    // Validate that the attachment can be modified
    validateModifyExternal(details);

    // Get the attachment ID and decision ID for the attachment
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      details.attachmentLinkID;
    attachmentAndDecisionIDDetails =
      hearingDecisionAttachmentLinkObj
        .readAttachmentAndDecisionID(hearingDecisionAttachmentLinkKey);

    // Modify the attachment directly - there is no CaseAttachmentLink
    attachmentKey.attachmentID = attachmentAndDecisionIDDetails.attachmentID;

    // BEGIN, CR00226594, FM
    attachmentDtls.assign(details.appealDecisionAttachmentDetails);
    // END, CR00226594
    attachmentDtls.attachmentID = attachmentAndDecisionIDDetails.attachmentID;
    attachmentDtls.statusCode = RECORDSTATUS.NORMAL;
    attachmentDtls.versionNo = details.attachmentVersionNo;
    attachmentObj.modify(attachmentKey, attachmentDtls);

    // Reset the status of the HearingDecision
    hearingDecisionKey.hearingDecisionID =
      attachmentAndDecisionIDDetails.hearingDecisionID;
    hearingDecisionStatusVersionDetails.decisionStatus =
      HEARINGDECISIONSTATUS.INPROGRESS;
    hearingDecisionStatusVersionDetails.versionNo =
      details.hearingDecisionVersionNo;
    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);
  }

  // ___________________________________________________________________________
  /**
   * Returns the details, required for modification, for a decision attachment
   * where an external document has been attached.
   * 
   * @param key
   * The identifier for the decision attachment to read.
   * @return The details for the decision attachment to be modified.
   */
  @Override
  public DecisionAttachmentForModifyDetails readForModifyExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return variable
    final DecisionAttachmentForModifyDetails decisionAttachmentForModifyDetails =
      new DecisionAttachmentForModifyDetails();

    // Variables for HearingDecisionAttachmentLink entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();

    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      key.hearingDecisionAttachmentLinkKey.attachmentLinkID;
    decisionAttachmentForModifyDetails.decisionAttachmentForModifyDetails =
      hearingDecisionAttachmentLinkObj
        .readAttachmentForModify(hearingDecisionAttachmentLinkKey);

    return decisionAttachmentForModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of an internally created decision attachment Microsoft
   * Word
   * document.
   * 
   * @param details
   * The Microsoft Word document details.
   */
  @Override
  public void modifyMSWord(final InternalAttachmentDetails details)
    throws AppException, InformationalException {

    // Variables for Attachment
    AttachmentDtls attachmentDtls;
    final AttachmentKey attachmentKey = new AttachmentKey();

    // Variables for HearingDecision entity
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();
    HearingDecisionVersionDetails hearingDecisionVersionDetails;

    // Variables for HearingDecisionAttachmentLink entity
    AttachmentAndDecisionIDDetails attachmentAndDecisionIDDetails;
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();

    // Get the Attachment and Decision ID
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      details.attachmentLinkID;
    attachmentAndDecisionIDDetails =
      hearingDecisionAttachmentLinkObj
        .readAttachmentAndDecisionID(hearingDecisionAttachmentLinkKey);

    // Modify the attachment contents
    attachmentKey.attachmentID = attachmentAndDecisionIDDetails.attachmentID;
    attachmentDtls = attachmentObj.read(attachmentKey);
    attachmentDtls.attachmentContents = details.document;
    attachmentObj.modify(attachmentKey, attachmentDtls);

    // Modify the Hearing Decision status
    hearingDecisionKey.hearingDecisionID =
      attachmentAndDecisionIDDetails.hearingDecisionID;
    hearingDecisionVersionDetails =
      hearingDecisionObj.readVersion(hearingDecisionKey);
    hearingDecisionStatusVersionDetails.decisionStatus =
      HEARINGDECISIONSTATUS.INPROGRESS;
    hearingDecisionStatusVersionDetails.versionNo =
      hearingDecisionVersionDetails.versionNo;
    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);
  }

  // ___________________________________________________________________________
  /**
   * Cancels a decision attachment.
   * 
   * @param details
   * The details for canceling a decision attachment
   */
  @Override
  public void cancel(final CancelDecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // Hearing Decision Attachment Link, Entity layer variables
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();
    final ModifyDecisionStatusDetails modifyDecisionStatusDetails =
      new ModifyDecisionStatusDetails();

    // Validate the cancellation of the Attachment
    validateCancel(details);

    // Cancel the Attachment
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      details.attachmentLinkID;
    modifyDecisionStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
    modifyDecisionStatusDetails.versionNo = details.versionNo;
    hearingDecisionAttachmentLinkObj.modifyStatus(
      hearingDecisionAttachmentLinkKey, modifyDecisionStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a decision attachment where an external document was
   * attached.
   * 
   * @param key
   * The identifier for the decision attachment to read.
   * 
   * @return The details of the externally generated decision attachment.
   */
  @Override
  public DecisionAttachmentSummaryDetails readExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return variable
    final DecisionAttachmentSummaryDetails decisionAttachmentSummaryDetails =
      new DecisionAttachmentSummaryDetails();

    // Variables for HearingDecisionAttachmentLink entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();

    // Read the Attachment
    hearingDecisionAttachmentLinkKey.attachmentLinkID =
      key.hearingDecisionAttachmentLinkKey.attachmentLinkID;
    decisionAttachmentSummaryDetails.decisionAttachmentDetails =
      hearingDecisionAttachmentLinkObj
        .readAttachment(hearingDecisionAttachmentLinkKey);

    // Return the Attachment details
    return decisionAttachmentSummaryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a decision attachment where an internal document was
   * attached.
   * 
   * @param key
   * The identifier for the decision attachment to read.
   * 
   * @return The date, status and template ID of the internal attachment.
   */
  @Override
  public AttachmentDateStatusAndTemplate readDateStatusAndTemplate(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return variable
    final AttachmentDateStatusAndTemplate attachmentDateStatusAndTemplate =
      new AttachmentDateStatusAndTemplate();

    // Hearing Decision Attachment Link entity object
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();

    // Delegate to the entity object
    attachmentDateStatusAndTemplate.attachmentDateStatusAndTemplate =
      hearingDecisionAttachmentLinkObj
        .readDateStatusAndTemplate(key.hearingDecisionAttachmentLinkKey);

    return attachmentDateStatusAndTemplate;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of an attachment to be downloaded.
   * 
   * @param key
   * The identifier for the decision attachment to download.
   * 
   * @return The details of the decision attachment.
   */
  @Override
  public ReadForDownloadDetails readForDownload(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Return variable
    final ReadForDownloadDetails readForDownloadDetails =
      new ReadForDownloadDetails();

    // Hearing Decision Attachment Link entity object
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();

    // Delegate to the entity object
    readForDownloadDetails.readForDownloadDetails =
      hearingDecisionAttachmentLinkObj
        .readForDownload(key.hearingDecisionAttachmentLinkKey);

    return readForDownloadDetails;
  }
}
