/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.CaseParticipantRoleLinkFactory;
import curam.appeal.sl.entity.intf.CaseParticipantRoleLink;
import curam.appeal.sl.entity.struct.BehalfOfCodeHW;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDtls;
import curam.appeal.sl.struct.CaseParticipantRoleLinkDetailsList;
import curam.appeal.sl.struct.CaseParticipantRoleLinkKey;
import curam.appeal.sl.struct.CreateCaseParticipantRoleLinkDetails;
import curam.appeal.sl.struct.RelatedID;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.ONBEHALFOF;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.struct.CaseParticipantRoleTypeCode;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.StringList;

// Begin CR00117296 LP
/**
 * Maintains business process functionality Hearing Participation -
 * CaseParticipantRoleLink entity
 */
public abstract class HearingParticipation extends
  curam.appeal.sl.base.HearingParticipation {

  /**
   * Terminates the CaseParticipantionRoleLink based on the
   * CaseParticipantRoleLinkKey. The endDate is set to todays date and the
   * recordStatus is set to Canceled.
   * 
   * @param key - contains the CaseParticipantRoleLinkID
   * 
   * @throws InformationalException, AppException
   */
  @Override
  public void removeCaseParticipantRoleLink(
    final CaseParticipantRoleLinkKey key) throws AppException,
    InformationalException {

    final CaseParticipantRoleLink caseParticipantRoleLink =
      CaseParticipantRoleLinkFactory.newInstance();
    // reads the CaseParticipantRoleLinkDtls
    final CaseParticipantRoleLinkDtls caseParticipantRoleLinkDtls =
      caseParticipantRoleLink.read(key.key);

    caseParticipantRoleLinkDtls.endDate = new Date();
    caseParticipantRoleLinkDtls.recordStatus = RECORDSTATUS.CANCELLED;
    CaseParticipantRoleLinkFactory.newInstance().modify(key.key,
      caseParticipantRoleLinkDtls);
  }

  /**
   * Creates multiple CaseParticipantRoleLink entries with the given
   * CreateCaseParticipantRoleLinkDetails, for each CaseparticipantRoleID in
   * the string CaseparticipantRoleIDs. The relatedType is set to
   * REPRESENTATIVE
   * 
   * @param dtls - CreateCaseParticipantRoleLinkDetails contains the String of
   * CaseparticipantRoleIDs and other details.
   * 
   * @throws InformationalException, AppException
   */
  @Override
  public void createRepresentativeCaseParticipantRoleLinks(
    final CreateCaseParticipantRoleLinkDetails dtls) throws AppException,
    InformationalException {

    // create CaseParticipantRoleLink entries. For each hearing Participant
    // selected an entry is inserted.
    final CaseParticipantRoleLinkDtls caseParticipantRoleLinkDtls =
      new CaseParticipantRoleLinkDtls();

    // Get the list of CaseParticipantRoleID
    final StringList caseparticipantRoleIDList =
      curam.util.resources.StringUtil
        .tabText2StringList(dtls.caseParticipantRoleIDs);
    final CaseParticipantRoleLink caseParticipantRoleLink =
      CaseParticipantRoleLinkFactory.newInstance();

    for (int i = 0; i < caseparticipantRoleIDList.size(); i++) {
      // Get the caseParticipantRoleId of the Hearing Participants.
      caseParticipantRoleLinkDtls.caseParticipantRoleID =
        Long.parseLong(caseparticipantRoleIDList.item(i).trim());
      caseParticipantRoleLinkDtls.relatedID = dtls.relatedID;
      caseParticipantRoleLinkDtls.startDate = new Date();
      caseParticipantRoleLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

      caseParticipantRoleLink.insert(caseParticipantRoleLinkDtls);
    }
  }

  /**
   * Creates multiple CaseParticipantRoleLink entries with the given
   * CreateCaseParticipantRoleLinkDetails, for each CaseparticipantRoleID in
   * the string CaseparticipantRoleIDs. The relatedType is set to
   * WITNESS
   * 
   * @param dtls - CreateCaseParticipantRoleLinkDetails contains the String of
   * CaseparticipantRoleIDs and other details.
   * 
   * @throws InformationalException, AppException
   */
  @Override
  public void createWitnessCaseParticipantRoleLinks(
    final CreateCaseParticipantRoleLinkDetails dtls) throws AppException,
    InformationalException {

    // create CaseParticipantRoleLink entries. For each hearing Participant
    // selected
    // an entry is inserted
    final CaseParticipantRoleLinkDtls caseParticipantRoleLinkDtls =
      new CaseParticipantRoleLinkDtls();
    final StringList caseparticipantRoleIDList =
      curam.util.resources.StringUtil
        .tabText2StringList(dtls.caseParticipantRoleIDs);
    final CaseParticipantRoleLink caseParticipantRoleLink =
      CaseParticipantRoleLinkFactory.newInstance();

    for (int i = 0; i < caseparticipantRoleIDList.size(); i++) {
      // Get the caseParticipantRoleId of the Hearing Participants.
      caseParticipantRoleLinkDtls.caseParticipantRoleID =
        Long.parseLong(caseparticipantRoleIDList.item(i).trim());
      caseParticipantRoleLinkDtls.relatedID = dtls.relatedID;
      caseParticipantRoleLinkDtls.startDate = new Date();
      caseParticipantRoleLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
      caseParticipantRoleLink.insert(caseParticipantRoleLinkDtls);
    }

  }

  /**
   * Lists the CaseParticipantRoleLinkDetails for a given RelatedID. The
   * relatedID can be of witness or representative.
   * 
   * @param key - Contains the RelatedID
   * 
   * @return CaseParticipantRoleLinkDetailsList List of CaseParticipants
   * @throws InformationalException, AppException
   */
  @Override
  public CaseParticipantRoleLinkDetailsList
    listCaseParticipantLinkByRelatedID(final RelatedID key)
      throws AppException, InformationalException {

    final CaseParticipantRoleLink caseParticipantRoleLink =
      CaseParticipantRoleLinkFactory.newInstance();
    final CaseParticipantRoleLinkDetailsList caseParticipantRoleLinkDetailsList =
      new CaseParticipantRoleLinkDetailsList();

    key.key.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleLinkDetailsList.dtls =
      caseParticipantRoleLink.readParticipantDetailsByRelatedID(key.key);
    return caseParticipantRoleLinkDetailsList;
  }

  /**
   * List the CaseParticipants who are yet to be linked with the witness
   * 
   * @param key HearingWitnessIDKey contains the Witness ID.
   * @throws InformationalException, AppException
   */
  @Override
  public ViewCaseParticipantRoleDetailsList listUnlinkedParticipants(
    final RelatedID key) throws AppException, InformationalException {

    // Read the Linked CaseParticipant Details.
    final curam.appeal.sl.entity.struct.RelatedID relatedID =
      new curam.appeal.sl.entity.struct.RelatedID();

    relatedID.relatedID = key.key.relatedID;
    relatedID.recordStatus = RECORDSTATUS.NORMAL;
    final curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDetailsList existingCaseParticipantRoleLinkDetailsList =
      CaseParticipantRoleLinkFactory.newInstance()
        .readParticipantDetailsByRelatedID(relatedID);

    // Read the CaseParticipants Of the case
    final curam.core.sl.entity.struct.CaseParticipantRoleKey entity_caseParticipantRoleKey =
      new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    entity_caseParticipantRoleKey.caseParticipantRoleID = key.key.relatedID;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID =
      CaseParticipantRoleFactory.newInstance().read(
        entity_caseParticipantRoleKey).caseID;
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance()
        .viewCaseParticipantRoleList(viewCaseParticipantRole_boKey);

    // remove the CaseParticiapnts who are already linked.
    final int size = existingCaseParticipantRoleLinkDetailsList.dtls.size();

    for (int j = 0; j < viewCaseParticipantRoleDetailsList.dtls.size(); j++) {
      if (viewCaseParticipantRoleDetailsList.dtls.item(j).typeCode
        .equals(CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL)
        || viewCaseParticipantRoleDetailsList.dtls.item(j).typeCode
          .equals(CASEPARTICIPANTROLETYPE.HEARINGREPRESENTATIVE)
        || viewCaseParticipantRoleDetailsList.dtls.item(j).typeCode
          .equals(CASEPARTICIPANTROLETYPE.HEARINGWITNESS)) {
        viewCaseParticipantRoleDetailsList.dtls.remove(j);
        j--;
      } else {
        for (int i = 0; i < size; i++) {
          if (viewCaseParticipantRoleDetailsList.dtls.item(j).caseParticipantRoleID == existingCaseParticipantRoleLinkDetailsList.dtls
            .item(i).caseParticipantRoleID
            || viewCaseParticipantRoleDetailsList.dtls.item(j).typeCode
              .equals(CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL)) {
            viewCaseParticipantRoleDetailsList.dtls.remove(j);
            j--;
            break;
          }
        }
      }
    }

    return viewCaseParticipantRoleDetailsList;
  }

  /**
   * Determines the CaseParticipantRoleTypeCode for the given behalfOfCode
   * 
   * @param behalfOfCode - Contains the behalfOfCode
   * 
   * @return CaseParticipantRoleTypeCode - Contains the
   * caseParticipantRoleTypeCode
   */
  @Override
  public CaseParticipantRoleTypeCode getEquivalentCasepArticipantRole(
    final BehalfOfCodeHW behalfOfCode) {

    final CaseParticipantRoleTypeCode caseParticipantRoleTypeCode =
      new CaseParticipantRoleTypeCode();

    if (ONBEHALFOF.APPELLANT.equals(behalfOfCode.behalfOfCode)) {
      caseParticipantRoleTypeCode.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
    } else if (ONBEHALFOF.LEGALPARTICIPANT.equals(behalfOfCode.behalfOfCode)) {
      caseParticipantRoleTypeCode.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;
    } else if (ONBEHALFOF.RESPONDENT.equals(behalfOfCode.behalfOfCode)) {
      caseParticipantRoleTypeCode.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;
    } else if (ONBEHALFOF.THIRDPARTY.equals(behalfOfCode.behalfOfCode)) {
      caseParticipantRoleTypeCode.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.THIRDPARTY;
    }
    return caseParticipantRoleTypeCode;
  }

}
// End CR00117296 LP
