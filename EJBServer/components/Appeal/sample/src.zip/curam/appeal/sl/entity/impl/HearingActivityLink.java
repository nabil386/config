/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.HearingActivityLinkDtls;
import curam.appeal.sl.entity.struct.HearingUserAttendeeActivityDetails;
import curam.codetable.RECORDSTATUS;
import curam.message.BPOHEARINGUSERROLE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public abstract class HearingActivityLink extends
  curam.appeal.sl.entity.base.HearingActivityLink {

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Activity Link Details
   * 
   * @param dtls Hearing Activity Link details
   */
  @Override
  protected void validateInsert(final HearingActivityLinkDtls dtls)
    throws AppException, InformationalException {

    // Hearing ID must be specified
    if (dtls.hearingID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGUSERROLE.ERR_HEARINGUSERROLE_FV_HEARINGID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Activity ID must be specified
    if (dtls.activityID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGUSERROLE.ERR_HEARINGUSERROLE_FV_CASEUSERROLEID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Activity Link Details
   * 
   * @param details Hearing Activity Link details
   */
  @Override
  protected void preinsert(final HearingActivityLinkDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param details Hearing User Attendee Activity details
   */
  @Override
  protected void precountActiveActivityByTypeHearingIDAndUser(
    final HearingUserAttendeeActivityDetails details) throws AppException,
    InformationalException {

    details.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param details Hearing User Attendee Activity details
   */
  @Override
  protected void prereadActiveActivityByTypeHearingIDAndUser(
    final HearingUserAttendeeActivityDetails details) throws AppException,
    InformationalException {

    details.recordStatus = RECORDSTATUS.NORMAL;

  }
}
