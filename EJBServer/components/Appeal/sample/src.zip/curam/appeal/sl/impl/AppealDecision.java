/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */
package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealReadSummaryDetails;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionDtls;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionModifyCommentsDetails;
import curam.appeal.sl.entity.struct.HearingDecisionModifyDetails;
import curam.appeal.sl.entity.struct.HearingDecisionStatusDetails;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.ResolutionCodeDetailsList;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealDecisionCreateDetails;
import curam.appeal.sl.struct.AppealDecisionKey;
import curam.appeal.sl.struct.AppealDecisionModifyCommentsDetails;
import curam.appeal.sl.struct.AppealDecisionModifyDetails;
import curam.appeal.sl.struct.AppealDecisionSummaryDetails;
import curam.appeal.sl.struct.AppealResolutionDetails;
import curam.appeal.sl.struct.DecisionAttachmentDetails;
import curam.appeal.sl.struct.DecisionAttachmentResult;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALTYPE;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGSTATUS;
import curam.core.fact.CaseAttachmentLinkFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainAttachmentFactory;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.CaseAttachmentLink;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainAttachment;
import curam.core.sl.fact.CaseTransactionLogFactory;
import curam.core.sl.intf.CaseTransactionLog;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.struct.AttachmentIDAndAttachmentLinkIDStruct;
import curam.core.struct.CaseAttachmentLinkDtls;
import curam.core.struct.CaseAttachmentLinkKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.core.struct.CreateCaseAttachmentDetails;
import curam.core.struct.ModifyAttachmentDetails;
import curam.message.BPOAPPEALDECISION;
import curam.message.BPODECISION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the Appeal Decision
 * service layer.
 * 
 */
public abstract class AppealDecision extends
  curam.appeal.sl.base.AppealDecision {

  // ___________________________________________________________________________
  /**
   * Method to insert attachment on an Appeal Case
   * 
   * @param details Details of the attachment to be created.
   * 
   * @return Contains the caseAttachmentLinkID
   */
  @Override
  public DecisionAttachmentResult createAttachment(
    final DecisionAttachmentDetails details) throws AppException,
    InformationalException {

    // Return details
    final DecisionAttachmentResult decisionAttachmentResult =
      new DecisionAttachmentResult();

    // MaintainAttachment objects
    final MaintainAttachment maintainAttachmentObj =
      MaintainAttachmentFactory.newInstance();
    final CreateCaseAttachmentDetails createCaseAttachmentDetails =
      new CreateCaseAttachmentDetails();
    AttachmentIDAndAttachmentLinkIDStruct attachmentIDAndAttachmentLinkIDStruct;

    // Insert attachment
    createCaseAttachmentDetails.caseID = details.caseID;
    createCaseAttachmentDetails.description =
      BPODECISION.INF_DECISION_ATTACHMENTDESCRIPTION.getMessageText();
    createCaseAttachmentDetails.documentType = DOCUMENTTYPE.STATEMENT;
    createCaseAttachmentDetails.filelocation = details.fileLocation;
    createCaseAttachmentDetails.fileReference = details.fileReferenceNumber;
    createCaseAttachmentDetails.newCaseAttachmentContents =
      details.attachmentContents;
    createCaseAttachmentDetails.newCaseAttachmentName =
      details.attachmentName;
    createCaseAttachmentDetails.receiptDate = Date.getCurrentDate();
    attachmentIDAndAttachmentLinkIDStruct =
      maintainAttachmentObj
        .insertCaseAttachmentDetails(createCaseAttachmentDetails);

    decisionAttachmentResult.caseAttachmentLinkID =
      attachmentIDAndAttachmentLinkIDStruct.caseAttachmentLinkID;

    return decisionAttachmentResult;
  }

  // ___________________________________________________________________________
  /**
   * Operation to modify an Attachment.
   * 
   * @param details Modified attachment details.
   */
  @Override
  protected void modifyAttachment(final DecisionAttachmentDetails details)
    throws AppException, InformationalException {

    // CaseAttachmentLink variables
    final CaseAttachmentLink caseAttachmentLinkObj =
      CaseAttachmentLinkFactory.newInstance();
    final CaseAttachmentLinkKey caseAttachmentLinkKey =
      new CaseAttachmentLinkKey();
    CaseAttachmentLinkDtls caseAttachmentLinkDtls;

    // MaintainAttachment objects
    final MaintainAttachment maintainAttachmentObj =
      MaintainAttachmentFactory.newInstance();
    final ModifyAttachmentDetails modifyAttachmentDetails =
      new ModifyAttachmentDetails();

    // Read case attachment link details
    caseAttachmentLinkKey.caseAttachmentLinkID = details.caseAttachmentLinkID;
    caseAttachmentLinkDtls =
      caseAttachmentLinkObj.read(caseAttachmentLinkKey);

    // Update attachment
    modifyAttachmentDetails.attachmentContents = details.attachmentContents;
    modifyAttachmentDetails.attachmentDate = Date.getCurrentDate();
    modifyAttachmentDetails.attachmentID =
      caseAttachmentLinkDtls.attachmentID;
    modifyAttachmentDetails.attachmentName = details.attachmentName;
    modifyAttachmentDetails.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
    modifyAttachmentDetails.caseAttachmentLinkID =
      caseAttachmentLinkDtls.caseAttachmentLinkID;
    modifyAttachmentDetails.caseID = caseAttachmentLinkDtls.caseID;
    modifyAttachmentDetails.documentType = DOCUMENTTYPE.DECISION;
    modifyAttachmentDetails.fileLocation = details.fileLocation;
    modifyAttachmentDetails.fileReference = details.fileReferenceNumber;
    modifyAttachmentDetails.linkVersionNo = caseAttachmentLinkDtls.versionNo;
    modifyAttachmentDetails.receiptDate = Date.getCurrentDate();
    modifyAttachmentDetails.description =
      BPODECISION.INF_DECISION_ATTACHMENTDESCRIPTION.getMessageText();
    modifyAttachmentDetails.versionNo = details.attachmentVersion;

    maintainAttachmentObj.modifyCaseAttachment(modifyAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Calculates the overall resolution for an appeal case based on the
   * individual resolutions for each of the active appealed cases for the
   * appeal.
   * 
   * @param key The appeal caseID for which to calculate the resolution.
   * @return The overall appeal case resolution
   */
  @Override
  public AppealResolutionDetails calculateResolution(final AppealCaseKey key)
    throws AppException, InformationalException {

    // AppealRelationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    ResolutionCodeDetailsList resolutionCodeDetailsList;

    // Return struct
    final AppealResolutionDetails appealResolutionDetails =
      new AppealResolutionDetails();

    // Retrieve resolution code for each appealed case
    activeApprovedCaseKey.appealCaseID = key.caseID;
    resolutionCodeDetailsList =
      appealRelationshipObj
        .searchActiveResolutionByAppealCase(activeApprovedCaseKey);

    // Count objects
    int countaccepted = 0;
    int countrejected = 0;
    int countremanded = 0;

    // Calculate the total number of accepted, rejected and remanded resolutions
    for (int i = 0; i < resolutionCodeDetailsList.dtls.size(); i++) {

      if (resolutionCodeDetailsList.dtls.item(i).resolutionCode
        .equals(HEARINGDECISIONRESOLUTION.ACCEPTED)) {
        countaccepted++;
      } else if (resolutionCodeDetailsList.dtls.item(i).resolutionCode
        .equals(HEARINGDECISIONRESOLUTION.REJECTED)) {
        countrejected++;
      } else if (resolutionCodeDetailsList.dtls.item(i).resolutionCode
        .equals(HEARINGDECISIONRESOLUTION.REMANDED)) {
        countremanded++;
      }
    }

    // Check for combinations of appealed case resolutions
    if (countaccepted > 0 && countrejected == 0 && countremanded == 0) {

      // Set overall resolution to accepted
      appealResolutionDetails.resolutionCode = APPEALCASERESOLUTION.ACCEPTED;

    } else if (countaccepted > 0) {

      // Set overall resolution to accepted in part
      appealResolutionDetails.resolutionCode =
        APPEALCASERESOLUTION.ACCEPTEDINPART;

    } else if (countrejected > 0 && countaccepted == 0 && countremanded == 0) {

      // Set overall resolution to rejected
      appealResolutionDetails.resolutionCode = APPEALCASERESOLUTION.REJECTED;

    } else if (countremanded > 0 && countaccepted == 0 && countrejected == 0) {

      // Set overall resolution to remanded
      appealResolutionDetails.resolutionCode = APPEALCASERESOLUTION.REMANDED;

    } else {

      // Set overall resolution to not decided
      appealResolutionDetails.resolutionCode =
        APPEALCASERESOLUTION.NOTDECIDED;

    }

    return appealResolutionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates the creation of an appeal decision.
   * 
   * @param details The appeal decision creation details to validate.
   */
  @Override
  protected void validateCreate(final AppealDecisionCreateDetails details)
    throws AppException, InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    Count count;

    // CaseHeader object and struct
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingScheduleDate hearingScheduleDate;

    // HARP, BEGIN 47570, NL
    // Appeal Object
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // Check for existing decision
    hearingDecisionCaseKey.caseID = details.appealCaseID;
    count = hearingDecisionObj.countIDByCase(hearingDecisionCaseKey);

    // If decision exists, throw exception
    if (count.numberOfRecords > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DECISION_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Check for active case status
    caseHeaderKey.caseID = details.appealCaseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);
    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALDECISION.ERR_APPEALDECISION_FV_NOT_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Find the appeal type
    appealCaseIDKey.caseID = details.appealCaseID;
    appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

    // Check that the final hearing has been held only if not a judicial review
    if (!appealTypeDetails.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      caseAndStatusKey.caseID = details.appealCaseID;
      caseAndStatusKey.statusCode = HEARINGSTATUS.COMPLETED;
      try {

        hearingScheduleDate =
          hearingObj.readLatestScheduledDateByCaseAndStatus(caseAndStatusKey);

      } catch (final curam.util.exception.RecordNotFoundException e) {

        throw new AppException(
          BPOAPPEALDECISION.ERR_APPEALDECISION_FV_FINAL_HEARING_NOT_HELD);
      }

      // Check that decision date is specified
      if (details.decisionDate.isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_MISSING),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }

      // Check that the decision date is after the hearing date only if not a
      // judicial review
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        hearingScheduleDate.scheduledDateTime,
        TransactionInfo.getUserTimeZone())).after(details.decisionDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_TOO_EARLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates the modification of an appeal decision.
   * 
   * @param details The appeal decision modify details to validate.
   */
  @Override
  protected void validateModify(final AppealDecisionModifyDetails details)
    throws AppException, InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails;
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // CaseHeader object and struct
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingScheduleDate hearingScheduleDate;
    Count count;

    // HARP, BEGIN 47570, NL
    // Appeal Object
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // Check if status is submitted
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    hearingDecisionStatusDetails =
      hearingDecisionObj.readStatus(hearingDecisionKey);
    if (hearingDecisionStatusDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DECISION_SUBMITTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Find the appeal case id
    hearingDecisionCaseKey = hearingDecisionObj.readCase(hearingDecisionKey);

    // Check for active cases
    caseHeaderKey.caseID = hearingDecisionCaseKey.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);
    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALDECISION.ERR_APPEALDECISION_FV_NOT_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Find the appeal type
    appealCaseIDKey.caseID = hearingDecisionCaseKey.caseID;
    appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

    // Check that the final hearing has been held only if not a judicial review
    if (!appealTypeDetails.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      // Determine if there is a scheduled hearing for the appeal case
      caseAndStatusKey.caseID = hearingDecisionCaseKey.caseID;
      caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;
      count = hearingObj.countScheduledDateByCaseAndStatus(caseAndStatusKey);

      // Throw exception if there is still a scheduled hearing
      if (count.numberOfRecords > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_FINAL_HEARING_NOT_HELD),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Determine if there is a completed hearing for the appeal case
      caseAndStatusKey.statusCode = HEARINGSTATUS.COMPLETED;
      try {

        hearingScheduleDate =
          hearingObj.readLatestScheduledDateByCaseAndStatus(caseAndStatusKey);

      } catch (final curam.util.exception.RecordNotFoundException e) {

        throw new AppException(
          BPOAPPEALDECISION.ERR_APPEALDECISION_FV_FINAL_HEARING_NOT_HELD);
      }

      // Check that the decision date is after the hearing date
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        hearingScheduleDate.scheduledDateTime,
        TransactionInfo.getUserTimeZone()))
        .after(details.hearingDecisionModifyDetails.decisionDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_TOO_EARLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
    }
    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      // Check that decision date is after the receipt date of the case
      AppealReadSummaryDetails appealReadSummaryDtls;

      appealReadSummaryDtls = appealObj.readByCase(appealCaseIDKey);
      if (appealReadSummaryDtls.receivedDate
        .after(details.hearingDecisionModifyDetails.decisionDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_TOO_EARLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            3);
      }
    } else {

      // Determine if there is a completed hearing for the appeal case
      caseAndStatusKey.statusCode = HEARINGSTATUS.COMPLETED;
      try {

        hearingScheduleDate =
          hearingObj.readLatestScheduledDateByCaseAndStatus(caseAndStatusKey);

      } catch (final curam.util.exception.RecordNotFoundException e) {

        throw new AppException(
          BPOAPPEALDECISION.ERR_APPEALDECISION_FV_FINAL_HEARING_NOT_HELD);
      }

      // BEGIN, CR00126231, RKi
      // Check that the decision date is after the hearing date
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        hearingScheduleDate.scheduledDateTime,
        TransactionInfo.getUserTimeZone()))
        .after(details.hearingDecisionModifyDetails.decisionDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_TOO_EARLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            2);
      }
    }
    // END, CR00126231

    // Check that decision date is specified
    if (details.hearingDecisionModifyDetails.decisionDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_MISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Check that decision data is not future
    if (details.hearingDecisionModifyDetails.decisionDate.after(Date
      .getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALDECISION.ERR_APPEALDECISION_FV_DATE_FUTURE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates an appeal decision for an appeal case. Note that this does not
   * include any decision document details.
   * 
   * @param details The appeal decision creation details.
   * @return The identifier of the appeal decision.
   */
  @Override
  public AppealDecisionKey create(final AppealDecisionCreateDetails details)
    throws AppException, InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionDtls hearingDecisionDtls = new HearingDecisionDtls();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    AppealResolutionDetails appealResolutionDetails;

    // Return struct
    final AppealDecisionKey appealDecisionKey = new AppealDecisionKey();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = details.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate data
    validateCreate(details);

    // Calculate the resolution code
    appealCaseKey.caseID = details.appealCaseID;
    appealResolutionDetails = calculateResolution(appealCaseKey);
    hearingDecisionDtls.resolutionCode =
      appealResolutionDetails.resolutionCode;

    // Insert the changes
    hearingDecisionDtls.caseID = details.appealCaseID;
    hearingDecisionDtls.comments = details.comments;
    hearingDecisionDtls.decisionDate = details.decisionDate;
    hearingDecisionDtls.decisionStatus = HEARINGDECISIONSTATUS.INPROGRESS;
    hearingDecisionObj.insert(hearingDecisionDtls);

    // BEGIN, CR00268652, ZV
    appealDecisionKey.hearingDecisionID =
      hearingDecisionDtls.hearingDecisionID;
    // END, CR00268652

    return appealDecisionKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of an appeal decision. Note that this does not
   * include any decision document details.
   * 
   * @param details The appeal decision modify details.
   */
  @Override
  public void modify(final AppealDecisionModifyDetails details)
    throws AppException, InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionModifyDetails hearingDecisionModifyDetails =
      new HearingDecisionModifyDetails();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // Set the decision key
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;

    // Pass in the ID for the security check
    hearingDecisionCaseKey = hearingDecisionObj.readCase(hearingDecisionKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate data
    validateModify(details);

    // Modify details
    hearingDecisionModifyDetails = details.hearingDecisionModifyDetails;
    hearingDecisionModifyDetails.decisionStatus =
      HEARINGDECISIONSTATUS.INPROGRESS;
    hearingDecisionObj.modifyDateCommentsAndStatus(hearingDecisionKey,
      hearingDecisionModifyDetails);

    // BEGIN, CR00050118, RKi
    if (hearingDecisionCaseKey.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final CaseTransactionLog caseTransactionLog =
        CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingDecisionCaseKey.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.APPEALCASE_DECIDED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);
    }
    // END, CR00050118
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of an appeal decision. Note that this does not include
   * any details of the decision document(s) for the appeal decision.
   * 
   * @param key The identifier of the appeal decision to read.
   * @return The appeal decision details.
   */
  @Override
  public AppealDecisionSummaryDetails
    readSummary(final AppealDecisionKey key) throws AppException,
      InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // Return struct
    final AppealDecisionSummaryDetails appealDecisionSummaryDetails =
      new AppealDecisionSummaryDetails();

    // Set the decision key
    hearingDecisionKey.hearingDecisionID = key.hearingDecisionID;

    // Pass in the ID for the security check
    hearingDecisionCaseKey = hearingDecisionObj.readCase(hearingDecisionKey);

    // Appeal Security variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read for the summary details
    appealDecisionSummaryDetails.decisionOverallSummaryDetails =
      hearingDecisionObj.readOverallSummary(hearingDecisionKey);

    return appealDecisionSummaryDetails;
  }

  // BEGIN, CR00289874 , DK
  // ___________________________________________________________________________
  /**
   * Modifies the comments of an appeal decision. Note that this does not
   * include any decision document details.
   * 
   * @param details The appeal decision modify details.
   */
  @Override
  public void
    modifyComments(final AppealDecisionModifyCommentsDetails details)
      throws AppException, InformationalException {

    // HearingDecision object and struct
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionModifyCommentsDetails hearingDecisionModifyCommentsDetails =
      new HearingDecisionModifyCommentsDetails();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // Set the decision key
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;

    // Pass in the ID for the security check
    hearingDecisionCaseKey = hearingDecisionObj.readCase(hearingDecisionKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Modify details
    hearingDecisionModifyCommentsDetails = details.dtls;
    hearingDecisionObj.modifyComments(hearingDecisionKey,
      hearingDecisionModifyCommentsDetails);

    if (hearingDecisionCaseKey.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final CaseTransactionLog caseTransactionLog =
        CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingDecisionCaseKey.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.APPEALCASE_DECIDED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);
    }

  }
  // END, CR00289874 , DK
}
