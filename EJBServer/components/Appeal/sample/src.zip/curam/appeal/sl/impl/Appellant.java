/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingParticipationFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.struct.AppealCaseAndReceiptIndDetails;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealID;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealIDAndParticipantRoleDetails;
import curam.appeal.sl.entity.struct.AppealIDStatusCodeDetails;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppealedCaseDetailsList;
import curam.appeal.sl.entity.struct.AppellantConcernRoleIDDetailsList;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.AppellantKey;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDScheduled;
import curam.appeal.sl.entity.struct.CaseParticipantRoleIDAndIndicatorDetails;
import curam.appeal.sl.entity.struct.CaseParticipantRoleID_eoDetails;
import curam.appeal.sl.entity.struct.HearingAndStatusDetails;
import curam.appeal.sl.entity.struct.HearingCaseID;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingDetailsList;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingParticipationDtls;
import curam.appeal.sl.entity.struct.HearingScheduleDetails;
import curam.appeal.sl.entity.struct.ListAppellantDetails;
import curam.appeal.sl.fact.HearingCaseFactory;
import curam.appeal.sl.fact.HearingReviewFactory;
import curam.appeal.sl.fact.JudicialReviewFactory;
import curam.appeal.sl.intf.HearingCase;
import curam.appeal.sl.intf.HearingReview;
import curam.appeal.sl.intf.JudicialReview;
import curam.appeal.sl.struct.AddAppellantDetails;
import curam.appeal.sl.struct.AppealCaseDetails;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppellantHasAddedCaseIndicator;
import curam.appeal.sl.struct.AppellantIDAppealIDAndCaseIDDetails;
import curam.appeal.sl.struct.ListAppellantConcernRoleIDDetails;
import curam.appeal.sl.struct.ListAppellantDetailsList;
import curam.appeal.sl.struct.ListCaseParticipantRoleIDDetails;
import curam.appeal.sl.struct.RemoveAppellantDetails;
import curam.appeal.sl.struct.UpdateAppellantDetails;
import curam.appeal.sl.struct.ViewAppellantDetails;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.pdt.struct.InformationalMessage;
import curam.core.facade.pdt.struct.InformationalMessageList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.EnvVars;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CancelCaseParticipantRoleDetails;
import curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseIDParticipantIDAndTypeDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoModifyDetails;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseRelationshipRelatedCaseIDKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.Count;
import curam.core.struct.CuramInd;
import curam.core.struct.DateStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * Service Layer interface for an Appellant. This class provides APIS to insert,
 * modify and delete appellant details.
 * 
 */
public abstract class Appellant extends curam.appeal.sl.base.Appellant {

  protected final short kCaseParticipantRoleID = 0;

  // ___________________________________________________________________________
  /**
   * This method creates an Appellant for an appeal case. If hearing is
   * adjourned for the appeal case, then a notice is sent to the appellant.
   * 
   * @param details Contains the details of an Appellant.
   * 
   * @return list of Informational messages
   */
  @Override
  public InformationalMessageList createAppellant(
    final AddAppellantDetails details) throws AppException,
    InformationalException {

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    final curam.appeal.sl.intf.Hearing hearing =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    final Appeal appeal = AppealFactory.newInstance();

    // informational message list
    final InformationalMessageList informationalMessageList =
      new InformationalMessageList();
    InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();
    final InformationalMessage informationalMessage =
      new InformationalMessage();
    String[] warnings;

    details.createAppDtls.fromDate = Date.getCurrentDate();

    // create case participant role 'Appellant'.
    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();
    final CaseParticipantRole_boKey caseParticipantRoleKey =
      new CaseParticipantRole_boKey();

    final AppealKey key = new AppealKey();

    key.appealID = details.createAppDtls.appealID;

    final DateStruct dateStruct = new DateStruct();

    dateStruct.date = details.createAppDtls.receivedDate;

    // Validate if appellant has already added to the appeal case
    final Appeal appealObj = AppealFactory.newInstance();

    final AppealIDAndParticipantRoleDetails appealIDAndParticipantRoleDetails =
      new AppealIDAndParticipantRoleDetails();

    appealIDAndParticipantRoleDetails.appealID =
      details.createAppDtls.appealID;
    appealIDAndParticipantRoleDetails.date = details.createAppDtls.fromDate;
    appealIDAndParticipantRoleDetails.participantRoleID =
      details.createAppDtls.caseParticipantRoleID;
    appealIDAndParticipantRoleDetails.roleTypeCode =
      details.createAppDtls.appellantTypeCode;

    // BEGIN, CR00096787, RKi
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID =
      details.createAppDtls.caseParticipantRoleID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd =
      clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      throw new AppException(
        curam.message.BPOAPPEALCLIENTMERGE.ERR_CREATE_APPEAL_CASE_DUPLICATE_CLIENT);
    }
    // END, CR00096787

    if (!details.createAppDtls.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {

      Count count;

      count =
        appealObj
          .countActiveParticipantAppellantRole(appealIDAndParticipantRoleDetails);

      if (count.numberOfRecords > 0) {
        throw new AppException(
          curam.message.ENTAPPELLANT.ERR_PARTICIPANT_NAME_ALREADY_EXISTS);
      }

      validateDetails(key, dateStruct);

      caseParticipantRoleDtls.participantRoleID =
        details.createAppDtls.caseParticipantRoleID;
      caseParticipantRoleDtls.caseID = appeal.read(key).caseID;
      caseParticipantRoleDtls.typeCode =
        curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;
      caseParticipantRoleDtls.fromDate = details.createAppDtls.fromDate;
      // caseParticipantRoleDtls.toDate = caseHeaderDtls.endDate;

      caseParticipantRoleObj.insert(caseParticipantRoleDtls);

      details.createAppDtls.caseParticipantRoleID =
        caseParticipantRoleDtls.caseParticipantRoleID;
    }

    // Insert the Appellant details
    appellantObj.insert(details.createAppDtls);

    // BEGIN, CR CR00020935, RKi
    // Parameter Object to retrieve HearingID
    final AppealIDStatusCodeDetails appealIDStatusCodeDetails =
      new AppealIDStatusCodeDetails();
    // Return Object
    final HearingKey hearingKey = new HearingKey();

    // Get the HearingID from the Hearing by passing AppealID and status
    appealIDStatusCodeDetails.appealID = details.createAppDtls.appealID;
    appealIDStatusCodeDetails.statusCode = HEARINGSTATUS.SCHEDULED;

    // BEGIN, CR00131436, RKi
    if (!details.createAppDtls.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {

      try {
        hearingKey.hearingID =
          hearingObj.readHearingIDByAppealID(appealIDStatusCodeDetails).hearingID;

        // Hearing Participation Objects
        // BEGIN, CR00124792, RKi
        final curam.appeal.sl.entity.intf.HearingParticipation hearingParticipationObj =
          HearingParticipationFactory.newInstance();
        final HearingParticipationDtls hearingParticipationDtls =
          new HearingParticipationDtls();

        // assigning the values to insert into hearing participation
        hearingParticipationDtls.caseParticipantRoleID =
          caseParticipantRoleDtls.caseParticipantRoleID;
        hearingParticipationDtls.hearingID = hearingKey.hearingID;
        hearingParticipationDtls.participatedCode =
          HEARINGPARTICIPATION.NOTHELD;
        hearingParticipationDtls.caseID = caseParticipantRoleDtls.caseID;
        hearingParticipationObj.insert(hearingParticipationDtls);
        // END, CR00124792
        // END, CR CR00020935

        // check for time to send correspondence related to the hearing
        // Get the value of the Correspondence Lead Time environment variable
        final String correspondenceLeadTimeString =
          curam.util.resources.Configuration
            .getProperty(EnvVars.ENV_CORRESPONDENCE_LEAD_TIME);

        // BEGIN, CR00021436, RKi
        final HearingCaseStatusDtls hearingCaseStatusDtls =
          new HearingCaseStatusDtls();

        hearingCaseStatusDtls.caseID = appeal.read(key).caseID;
        hearingCaseStatusDtls.statusCode = HEARINGSTATUS.SCHEDULED;
        // END, CR00021436

        HearingScheduleDetails hearingScheduleDetails;

        // BEGIN, CR00021436, RKi
        hearingScheduleDetails =
          hearingObj.readScheduledDateTimeByCase(hearingCaseStatusDtls);
        // END, CR00021436

        final Date scheduleDate =
          new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
            hearingScheduleDetails.scheduledDateTime,
            TransactionInfo.getUserTimeZone()));
        final int n = Integer.parseInt(correspondenceLeadTimeString);

        if (Date.getCurrentDate().addDays(n).after(scheduleDate)) {

          final LocalisableString appException =
            new LocalisableString(
              curam.message.ENTAPPELLANT.INF_INSUFFICIENT_TIME_CORRESPONDENCE_RELATED_TO_HEARING);

          informationalManager = new InformationalManager();

          informationalManager.addInformationalMsg(appException, "",
            InformationalElement.InformationalType.kWarning);
        }

      } catch (final RecordNotFoundException ex) {// do nothing
      }
    }
    // END, CR00131436

    // BEGIN, CR00296191, MC
    // If an Appellant is added to an Appeal which has an Adjourned hearing on
    // it
    // send the adjournment notice to the new Appellant
    HearingDetailsList hearingDetailsList = new HearingDetailsList();
    final HearingCaseID hearingCaseID = new HearingCaseID();

    hearingCaseID.caseID = appeal.read(key).caseID;

    hearingDetailsList = hearingObj.searchHearingsByCaseID(hearingCaseID);

    // If there is a hearing recorded for this Appeal get the status details of
    // the latest one.
    if (hearingDetailsList.dtls.size() != 0) {

      HearingAndStatusDetails hearingAndStatusDetails =
        new HearingAndStatusDetails();

      hearingAndStatusDetails =
        hearingObj.readLatestHearingAndStatusByCase(hearingCaseID);

      if (hearingAndStatusDetails.statusCode.equals(HEARINGSTATUS.ADJOURNED)) {

        try {
          caseAndStatusKey.caseID = hearingCaseID.caseID;
          caseAndStatusKey.statusCode = HEARINGSTATUS.ADJOURNED;

          caseParticipantRoleKey.caseParticipantRoleID =
            details.createAppDtls.caseParticipantRoleID;
          hearing.createAdjournmentNotice(caseParticipantRoleKey);

        } catch (final RecordNotFoundException ex) {// do nothing
        }

        // send receipts
        // if receipt indicator is set, send the acknowledge receipt to
        // appellant
        if (details.createAppDtls.receiptNoticeIndicator
          && !details.createAppDtls.appellantTypeCode
            .equals(APPELLANTTYPE.ORGANIZATION)) {

          final ListCaseParticipantRoleIDDetails listDetails =
            new ListCaseParticipantRoleIDDetails();
          final CaseParticipantRoleID_eoDetails caseParticipantkey =
            new CaseParticipantRoleID_eoDetails();

          caseParticipantkey.caseParticipantRoleID =
            details.createAppDtls.caseParticipantRoleID;
          listDetails.listDtls.dtls.addRef(caseParticipantkey);

          createReceiptNoticeForAppellants(listDetails);
        }
      }
    }
    // END, CR00296191

    warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      informationalMessage.message = warnings[i];
      informationalMessageList.dtls.addRef(informationalMessage);
    }

    return informationalMessageList;
  }

  // ___________________________________________________________________________
  /**
   * This method validates appellant details for insertion/modification
   * 
   * @param appealKey identifies the appeal record
   * @param dateStruct date details
   */
  public void validateDetails(final AppealKey appealKey,
    final DateStruct dateStruct) throws AppException, InformationalException {

    // Get the appealCaseID from appeal
    final Appeal appealObj = AppealFactory.newInstance();
    AppealDtls appealDtls;

    appealDtls = appealObj.read(appealKey);

    // Get the appeal case start date from case header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = appealDtls.caseID;

    // BEGIN, CR00303986, SG
    final CaseStartDate caseStartDate =
      caseHeaderObj.readStartDate(caseHeaderKey);

    // Received date must not be earlier than the appeal start date
    if (dateStruct.date.before(caseStartDate.startDate)) {
      // END, CR00303986

      throw new AppException(
        curam.message.ENTAPPELLANT.ERR_APPEAL_RECEIVED_DATE_EARLIER_THAN_START_DATE);
    }

  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the list of Appellants.
   * 
   * @param key identifies the Appeal Case.
   * 
   * @return list of Appellants details
   */
  @Override
  public ListAppellantDetailsList listAppellants(final AppealKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00207557, AK
    final ListAppellantDetailsList orgAppellantDetailsList =
      new ListAppellantDetailsList();
    // END, CR00207557
    // Return List
    final ListAppellantDetailsList listAppellantDetailsList =
      new ListAppellantDetailsList();

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // appeal variables
    final curam.appeal.sl.intf.Appeal appeal =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseDetails appealCaseDetails = new AppealCaseDetails();

    // retrieve the details
    listAppellantDetailsList.listDtls =
      appellantObj.searchAppellantsByAppealID(key);
    // BEGIN, CR00207557, AK
    orgAppellantDetailsList.listDtls =
      appellantObj.searchOrganisationAppellantsByAppealID(key);
    for (final ListAppellantDetails dtls : orgAppellantDetailsList.listDtls.dtls
      .items()) {
      listAppellantDetailsList.listDtls.dtls.addRef(dtls);
    }
    // END, CR00207557
    // read page context description
    appealCaseDetails.caseID = appealObj.read(key).caseID;
    listAppellantDetailsList.contextDescription =
      appeal.getContextDescription(appealCaseDetails);

    informationalManager.failOperation();

    // return the list.
    return listAppellantDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the details of an Appellant.
   * 
   * @param key identifies the Appeal case.
   * 
   * @return details of an Appellant.
   */
  @Override
  public ViewAppellantDetails readAppellant(final AppellantKey key)
    throws AppException, InformationalException {

    // Return struct
    final ViewAppellantDetails viewAppellantDetails =
      new ViewAppellantDetails();

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // retrieve the details of an appellant
    viewAppellantDetails.readAppDtls = appellantObj.read(key);

    // Return the details.
    return viewAppellantDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method modify the Appellant details.
   * 
   * @param details Contains the details of an Appellant to be modified.
   */
  @Override
  public void updateAppellant(final UpdateAppellantDetails details)
    throws AppException, InformationalException {

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // assign the appellant id
    final AppellantKey appellantKey = new AppellantKey();

    appellantKey.appellantID = details.updateAppDtls.appellantID;

    final AppealKey key = new AppealKey();

    key.appealID = details.updateAppDtls.appealID;

    final DateStruct dateStruct = new DateStruct();

    dateStruct.date = details.updateAppDtls.receivedDate;

    validateDetails(key, dateStruct);

    // Modify the appellant details.
    appellantObj.modify(appellantKey, details.updateAppDtls);

  }

  // ___________________________________________________________________________
  /**
   * This method removes the appellant from an appeal case. If the appeal case
   * has hearing scheduled, then a notice is sent to the appellant informing
   * him that he need not attend the hearing.
   * 
   * @param details Contains the details of an Appellant to be canceled.
   */
  @Override
  public void cancelAppellant(final RemoveAppellantDetails details)
    throws AppException, InformationalException {

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // Hearing objects
    final CaseIDScheduled caseIDScheduled = new CaseIDScheduled();

    // Appellant objects
    AppellantDtls appellantDtls;
    Count count;

    // assign the appellant id
    final AppellantKey appellantKey = new AppellantKey();

    appellantKey.appellantID = details.removeDtls.appellantID;
    details.removeDtls.toDate = Date.getCurrentDate();

    // Remove case participant role for this case
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    final CancelCaseParticipantRoleDetails cancelCaseParticipantRoleDetails =
      new CancelCaseParticipantRoleDetails();

    // BEGIN, CR00076059, RKi
    count = appellantObj.countAppellantOfTypeOrganisation(appellantKey);
    if (count.numberOfRecords > 0) {
      // END, CR00076059
      // BEGIN, CR CR00068639, NSP
      appellantDtls = appellantObj.read(appellantKey);

      caseParticipantRoleKey.caseParticipantRoleID =
        appellantDtls.caseParticipantRoleID;

      final CaseParticipantRole_eoModifyDetails caseParticipantRole_eoModifyDtls =
        new CaseParticipantRole_eoModifyDetails();

      caseParticipantRole_eoModifyDtls.caseParticipantRoleID =
        appellantObj.read(appellantKey).caseParticipantRoleID;
      caseParticipantRole_eoModifyDtls.fromDate = appellantDtls.fromDate;
      caseParticipantRole_eoModifyDtls.toDate = Date.getCurrentDate();
      caseParticipantRole_eoModifyDtls.versionNo =
        caseParticipantRoleObj.read(caseParticipantRoleKey).versionNo;
      caseParticipantRoleObj.modifyCaseParticipantRole(
        caseParticipantRoleKey, caseParticipantRole_eoModifyDtls);
      // END, CR CR00068639

      caseParticipantRoleKey.caseParticipantRoleID =
        appellantObj.read(appellantKey).caseParticipantRoleID;
      cancelCaseParticipantRoleDetails.recordStatus = RECORDSTATUS.CANCELLED;
      cancelCaseParticipantRoleDetails.versionNo =
        caseParticipantRoleObj.read(caseParticipantRoleKey).versionNo;
      caseParticipantRoleObj.modifyRecordStatus(caseParticipantRoleKey,
        cancelCaseParticipantRoleDetails);
    }
    // cancel the Appellant.
    appellantObj.cancelAppellant(appellantKey, details.removeDtls);
    final curam.appeal.sl.intf.Hearing hearing =
      curam.appeal.sl.fact.HearingFactory.newInstance();

    // BEGIN, CR00076059, RKi
    if (count.numberOfRecords > 0) {
      // END, CR00076059
      CaseParticipantRoleDtls caseParticipantRoleDtls;

      caseParticipantRoleDtls =
        caseParticipantRoleObj.read(caseParticipantRoleKey);

      // Read hearing details
      caseIDScheduled.caseID = caseParticipantRoleDtls.caseID;
      try {

        // send hearing attendance cancellation notice
        hearing.createAttendanceCancellationNotice(appellantKey);
      } catch (final RecordNotFoundException ex) {// do nothing
      }
    }

  }

  // _________________________________________________________________________
  /**
   * This method reads the appeal ID for a specified appeal case ID
   * 
   * @param key identifies appeal case record
   * 
   * @return appeal key
   */

  @Override
  public AppealKey readAppealIDByCaseID(final AppealCaseKey key)
    throws AppException, InformationalException {

    // / Return object
    final AppealKey appealKey = new AppealKey();

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealID appealID = new AppealID();
    final Appeal appealObj = AppealFactory.newInstance();

    appealCaseIDKey.caseID = key.caseID;
    appealID = appealObj.readAppealIDByCase(appealCaseIDKey);

    appealKey.appealID = appealID.appealID;

    return appealKey;
  }

  // _________________________________________________________________________
  /**
   * Adding appellant from the appeal case which is added to the existing
   * appeal case
   * 
   * @param addAppealCaseKey identifies the appeal record from which appellants
   * are to be added
   * @param appealCaseKey identifies the appeal record to which appellants are
   * to be added
   */

  @Override
  public void addAppellantsFromAppealCase(
    final AppealCaseKey addAppealCaseKey, final AppealCaseKey appealCaseKey)
    throws AppException, InformationalException {

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    AppellantConcernRoleIDDetailsList appellantConcernRoleIDDetailsList;
    AppellantConcernRoleIDDetailsList addAppellantConcernRoleIDDetailsList;

    // appeal variables
    final Appeal appeal = AppealFactory.newInstance();

    final AppealKey appealKey = new AppealKey();
    final AppealKey addCaseAppealKey = new AppealKey();
    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // retrieve the appellants existing in the case to
    // which another case appellants are added.
    appealCaseIDKey.caseID = addAppealCaseKey.caseID;
    appealKey.appealID = appeal.readAppealIDByCase(appealCaseIDKey).appealID;

    appealIDAndDateDetails.appealID = appealKey.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    addAppellantConcernRoleIDDetailsList =
      appellantObj.searchActiveAppellantsByAppealID(appealIDAndDateDetails);

    // retrieve the appellants to be added from the case
    appealCaseIDKey.caseID = appealCaseKey.caseID;
    addCaseAppealKey.appealID =
      appeal.readAppealIDByCase(appealCaseIDKey).appealID;

    appealIDAndDateDetails.appealID = addCaseAppealKey.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    appellantConcernRoleIDDetailsList =
      appellantObj.searchActiveAppellantsByAppealID(appealIDAndDateDetails);

    final AppellantIDAppealIDAndCaseIDDetails appellantIDAppealIDAndCaseIDDetails =
      new AppellantIDAppealIDAndCaseIDDetails();

    for (int i = 0; i < appellantConcernRoleIDDetailsList.dtls.size(); i++) {

      boolean appellantFound = false;

      // BEGIN, CR00096787, RKi
      // Client merge manipulation variables
      final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

      // Set the key to be that of the primary client
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        appellantConcernRoleIDDetailsList.dtls.item(i).concernRoleID;

      // Check if the primary client has been marked as a duplicate
      final CuramInd curamInd =
        clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

      // If the primary client is a duplicate, continue with the next appellant
      // and do not add the duplicate client to the case being added.
      if (curamInd.statusInd) {

        continue;
      }
      // END, CR00096787

      for (int j = 0; j < addAppellantConcernRoleIDDetailsList.dtls.size(); j++) {

        if (appellantConcernRoleIDDetailsList.dtls.item(i).concernRoleID == addAppellantConcernRoleIDDetailsList.dtls
          .item(j).concernRoleID) {

          appellantFound = true;
          break;
        }
      }

      // Appellant does not have active role on this case, add appellant to a
      // case
      if (!appellantFound) {

        // Clone appellant record and add new appellant for this appeal case
        appellantIDAppealIDAndCaseIDDetails.appellantID =
          appellantConcernRoleIDDetailsList.dtls.item(i).appellantID;
        appellantIDAppealIDAndCaseIDDetails.caseID = addAppealCaseKey.caseID;
        appellantIDAppealIDAndCaseIDDetails.appealID = appealKey.appealID;

        cloneAppellantDetails(appellantIDAppealIDAndCaseIDDetails);
      }
    }

  }

  // _________________________________________________________________________
  /**
   * Clone appellant details from one appeal case to another appeal case.
   * 
   * @param details contains appellant details
   */
  @Override
  public void cloneAppellantDetails(
    final AppellantIDAppealIDAndCaseIDDetails details) throws AppException,
    InformationalException {

    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();
    AppellantDtls appellantDtls = new AppellantDtls();
    final AppellantKey appellantKey = new AppellantKey();

    appellantKey.appellantID = details.appellantID;

    appellantDtls = appellantObj.read(appellantKey);

    // Clone case participant role details
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID =
      appellantDtls.caseParticipantRoleID;

    caseParticipantRoleDtls =
      caseParticipantRole.read(caseParticipantRoleKey);

    caseParticipantRoleDtls.caseID = details.caseID;
    caseParticipantRoleDtls.caseParticipantRoleID = kCaseParticipantRoleID;

    caseParticipantRole.insert(caseParticipantRoleDtls);
    final CaseParticipantRoleIDAndIndicatorDetails caseParticipantRoleIDAndIndicatorDetails =
      new CaseParticipantRoleIDAndIndicatorDetails();

    // BEGIN, CR00021514, RKi
    // Clone Appellant information
    appellantDtls.appealID = details.appealID;
    // END, CR00021514
    appellantDtls.caseParticipantRoleID =
      caseParticipantRoleDtls.caseParticipantRoleID;

    appellantObj.insert(appellantDtls);

    // BEGIN, CR00021526, RKi
    caseParticipantRoleIDAndIndicatorDetails.caseParticipantRoleID =
      caseParticipantRoleDtls.caseParticipantRoleID;

    caseParticipantRoleIDAndIndicatorDetails.receiptIndicator = true;
    appellantObj
      .modifyReceiptNoticeIndicator(caseParticipantRoleIDAndIndicatorDetails);
    // END, CR00021526
  }

  // ___________________________________________________________________________
  /**
   * This operation gets the list of appellants for the appeal case
   * 
   * @param key identifies the appeal case ID
   * 
   * @return List of appellants details
   */
  @Override
  public ListAppellantConcernRoleIDDetails getAppellantDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Return List
    final ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
      new ListAppellantConcernRoleIDDetails();

    // Appellant Object
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();

    // appeal variables
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final Appeal appeal = AppealFactory.newInstance();

    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();
    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// No
                                                                          // Appellants
                                                                          // for
                                                                          // LA
    } else {
      // End CR00117296 LP
      appealCaseIDKey.caseID = key.caseID;
      appealIDAndDateDetails.appealID =
        appeal.readAppealIDByCase(appealCaseIDKey).appealID;
      appealIDAndDateDetails.date = Date.getCurrentDate();
      // retrieve the details
      listAppellantConcernRoleIDDetails.listDtls =
        appellantObj.searchActiveAppellantsByAppealID(appealIDAndDateDetails);
    }

    return listAppellantConcernRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation checks if the appellant has added case on the appeal case
   * 
   * @param key identifies the case participant
   * @return true if appellant has added case
   */
  @Override
  public AppellantHasAddedCaseIndicator appellantHasAddedCase(
    final CaseParticipantRole_boKey key) throws AppException,
    InformationalException {

    final AppellantHasAddedCaseIndicator hasAddedCase =
      new AppellantHasAddedCaseIndicator();

    // AppealRelationship entity and manipulation variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealedCaseDetailsList appealedCaseDetailsList;
    final AppealCaseID appealCaseID = new AppealCaseID();

    // CaseRelationship variables
    final CaseRelationshipRelatedCaseIDKey caseRelationshipRelatedCaseIDKey =
      new CaseRelationshipRelatedCaseIDKey();
    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantIDAndTypeDetails caseIDParticipantIDAndTypeDetails =
      new CaseIDParticipantIDAndTypeDetails();
    CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();

    final curam.core.intf.CaseRelationship caseRelationshipObj =
      curam.core.fact.CaseRelationshipFactory.newInstance();

    // Get case and participant details
    caseParticipantRole_eoKey.caseParticipantRoleID =
      key.caseParticipantRoleID;
    caseIDCaseRefAndParticipantRoleIDDetails =
      caseParticipantRole_eoObj
        .readCaseIDCaseRefAndParticipantRoleID(caseParticipantRole_eoKey);

    // check if the participant has any role on this case
    caseRelationshipRelatedCaseIDKey.relatedCaseID =
      caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    // Get the product delivery for the appeal case
    caseRelationshipDtlsList =
      caseRelationshipObj
        .searchByRelatedCaseID(caseRelationshipRelatedCaseIDKey);
    caseIDParticipantIDAndTypeDetails.participantRoleID =
      caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;
    caseIDParticipantIDAndTypeDetails.recordStatus = RECORDSTATUS.NORMAL;
    caseIDParticipantIDAndTypeDetails.typeCode =
      CASEPARTICIPANTROLETYPE.PRIMARY;
    if (caseRelationshipDtlsList.dtls.size() > 0) {
      caseIDParticipantIDAndTypeDetails.caseID =
        caseRelationshipDtlsList.dtls.item(0).caseID;
    }
    try {
      hasAddedCase.hasAddedCase = true;
      return hasAddedCase;

    } catch (final RecordNotFoundException ex) {// DO NOTHING
    }

    // List all the appealed cases associated with the appeal
    appealCaseID.appealCaseID =
      caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    appealedCaseDetailsList =
      appealRelationshipObj
        .searchAppealedCaseDetailsByAppealCase(appealCaseID);

    // loop through each appealed case and find product delivery case IDs
    for (int i = 0; i < appealedCaseDetailsList.dtls.size()
      && !hasAddedCase.hasAddedCase; i++) {

      caseRelationshipRelatedCaseIDKey.relatedCaseID =
        appealedCaseDetailsList.dtls.item(i).caseID;

      // Get the product delivery for the appeal case
      caseRelationshipDtlsList =
        caseRelationshipObj
          .searchByRelatedCaseID(caseRelationshipRelatedCaseIDKey);

      // find if the participant has primary client role on the PD
      for (int j = 0; j < caseRelationshipDtlsList.dtls.size(); j++) {
        caseIDParticipantIDAndTypeDetails.caseID =
          caseRelationshipDtlsList.dtls.item(0).caseID;
        try {
          hasAddedCase.hasAddedCase = true;
          break;
        } catch (final RecordNotFoundException ex) {// DO NOTHING
        }
      }
    }
    return hasAddedCase;
  }

  // BEGIN, CR00021348, RK
  // _________________________________________________________________________
  /**
   * This method acknowledges of the appeal case created to all the appellants
   * who have not received the receipt previously.
   * 
   * @param key
   * identifies appeal case
   */
  @Override
  public void acknowledgeReceipts(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Get the list of active appellant to whom the request receipt have not
    // sent.
    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();
    final AppealCaseAndReceiptIndDetails appealCaseAndReceiptIndDetails =
      new AppealCaseAndReceiptIndDetails();

    appealCaseAndReceiptIndDetails.appealCaseID = key.caseID;
    appealCaseAndReceiptIndDetails.receiptNoticeInd = false;

    final ListCaseParticipantRoleIDDetails casePartRoleDetailsList =
      new ListCaseParticipantRoleIDDetails();

    casePartRoleDetailsList.listDtls =
      appellantObj
        .searchCasePartRoleIDsByAppealCaseAndReceiptInd(appealCaseAndReceiptIndDetails);

    createReceiptNoticeForAppellants(casePartRoleDetailsList);
  }

  // END, CR00021348

  // BEGIN, CR00021348, RK
  // _________________________________________________________________________
  /**
   * This method sends receipts to all the given appellants.
   * 
   * @param listDetails list of caseparticipantroleID for the appellants
   */
  @Override
  public void createReceiptNoticeForAppellants(
    final ListCaseParticipantRoleIDDetails listDetails) throws AppException,
    InformationalException {

    // Appeal entity variables
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;
    CaseParticipantRoleKey caseParticipantRoleKey;
    CaseParticipantRoleID_eoDetails caseParticipantRoleIDDetails =
      new CaseParticipantRoleID_eoDetails();

    final curam.appeal.sl.entity.intf.Appellant appellantObj =
      AppellantFactory.newInstance();
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();

    // appeal case variables
    final HearingCase hearingCase = HearingCaseFactory.newInstance();
    final HearingReview hearingReview = HearingReviewFactory.newInstance();
    final JudicialReview judicialReview = JudicialReviewFactory.newInstance();

    // BEGIN, CR00078516, RKi
    if (listDetails.listDtls.dtls.size() > 0) {
      for (int i = 0; i < listDetails.listDtls.dtls.size(); i++) {

        caseParticipantRoleIDDetails = listDetails.listDtls.dtls.item(i);
        caseParticipantRoleKey = new CaseParticipantRoleKey();
        caseParticipantRoleKey.caseParticipantRoleID =
          caseParticipantRoleIDDetails.caseParticipantRoleID;
        appealCaseIDKey.caseID =
          caseParticipantRole.readCaseID(caseParticipantRoleKey).caseID;
        appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

        if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

          hearingCase.createReceiptNoticeForAppellant(caseParticipantRoleKey);
        } else if (appealTypeDetails.appealTypeCode
          .equals(APPEALTYPE.HEARINGREVIEW)) {

          hearingReview
            .createReceiptNoticeForAppellant(caseParticipantRoleKey);

        } else {
          judicialReview
            .createReceiptNoticeForAppellant(caseParticipantRoleKey);
        }

        // Update receipt indicator for that appellant

        final CaseParticipantRoleIDAndIndicatorDetails caseParticipantRoleIDAndIndicatorDetails =
          new CaseParticipantRoleIDAndIndicatorDetails();

        caseParticipantRoleIDAndIndicatorDetails.caseParticipantRoleID =
          caseParticipantRoleKey.caseParticipantRoleID;
        caseParticipantRoleIDAndIndicatorDetails.receiptIndicator = true;
        appellantObj
          .modifyReceiptNoticeIndicator(caseParticipantRoleIDAndIndicatorDetails);
      }
    }
    // END, CR00078516

  }
  // END, CR00021348

}
