/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2007-2008,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealReopenHistoryFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingParticipationFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingParticipation;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.struct.ActiveAppealCaseStatus;
import curam.appeal.sl.entity.struct.ActiveAppealedCaseDeadlineDetails;
import curam.appeal.sl.entity.struct.ActiveAppealedCaseDeadlineDetailsList;
import curam.appeal.sl.entity.struct.ActiveAppealedCaseDetailsList;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.ActiveCaseKey;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseIDTYypeRecordStatusDetails;
import curam.appeal.sl.entity.struct.AppealID;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.AppealReadSummaryDetails;
import curam.appeal.sl.entity.struct.AppealRelationshipKey;
import curam.appeal.sl.entity.struct.AppealReopenHistoryDtls;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDAndDeadlineDate;
import curam.appeal.sl.entity.struct.CaseIDAndDeadlineDateList;
import curam.appeal.sl.entity.struct.DecisionDateDetails;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionResolutionDateStatusDetails;
import curam.appeal.sl.entity.struct.HearingDecisionStatusVersionDetails;
import curam.appeal.sl.entity.struct.HearingParticipatedAndTypeDetails;
import curam.appeal.sl.entity.struct.HearingParticipationAttendanceKey;
import curam.appeal.sl.entity.struct.HearingUserRoleParticipatedList;
import curam.appeal.sl.entity.struct.IssueDeliveryKeyForAppealList;
import curam.appeal.sl.entity.struct.ModifyDeadlineDateDetails;
import curam.appeal.sl.entity.struct.ParticipatedUserKey;
import curam.appeal.sl.entity.struct.ProductDeliveryKeyForAppealList;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.AppealedCaseFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.AppealedCase;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.CaseAlreadyAppealed;
import curam.appeal.sl.struct.CaseAndPriorAppeal;
import curam.appeal.sl.struct.CaseIDAppealCaseIDConstraintType;
import curam.appeal.sl.struct.CaseIDDeadlineDate;
import curam.appeal.sl.struct.ListAppealReopenHistoryDetails;
import curam.appeal.sl.struct.ListAppealReopenHistoryKey;
import curam.appeal.sl.struct.ReadReopenDetails;
import curam.appeal.sl.struct.ReadReopenKey;
import curam.appeal.sl.struct.ReopenHearingCaseDetails;
import curam.appeal.sl.struct.ReopenHearingCaseKey;
import curam.appeal.sl.struct.UpdateAppealCaseStatusDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONSTRAINTTYPE;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.LAPARTICIPANTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.struct.CaseAppealIndicatorDetails;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseRelByCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseStatusAndEndDateDetails;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.Count;
import curam.message.BPOAPPEALREOPENHISTORY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the Cancel Hearing Case
 * presentation layer.
 * 
 */
public abstract class AppealReopenHistory extends
  curam.appeal.sl.base.AppealReopenHistory {

  // BEGIN, 33156, BAR
  // This constant refers to the number of permitted active
  // related appeal cases.
  protected static final short kRelatedAppeals = 1;

  // END, 33156, BAR

  // ___________________________________________________________________________
  /**
   * Service layer method to list the reopen history of a hearing case.
   * 
   * @param key The case id for the reopen history list items.
   * 
   * @return The list of hearing case reopen details
   */
  @Override
  public ListAppealReopenHistoryDetails list(
    final ListAppealReopenHistoryKey key) throws AppException,
    InformationalException {

    // AppealReopenHistory object
    final curam.appeal.sl.entity.intf.AppealReopenHistory appealReopenHistoryObj =
      AppealReopenHistoryFactory.newInstance();

    // Return structure
    final ListAppealReopenHistoryDetails listAppealReopenHistoryDetails =
      new ListAppealReopenHistoryDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = key.reopenHistoryCaseIDKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Perform read
    for (int i = 0; i < appealReopenHistoryObj
      .searchForReopenHistoryByCaseID(key.reopenHistoryCaseIDKey).dtls.size(); i++) {

      listAppealReopenHistoryDetails.dtls.addRef(appealReopenHistoryObj
        .searchForReopenHistoryByCaseID(key.reopenHistoryCaseIDKey).dtls
        .item(i));
    }

    return listAppealReopenHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to read a reopen records details.
   * 
   * @param key The reopen case history item id.
   * 
   * @return The hearing case reopen details
   */
  @Override
  public curam.appeal.sl.struct.ReadReopenDetails
    read(final ReadReopenKey key) throws AppException, InformationalException {

    // AppealReopenHistory object
    final curam.appeal.sl.entity.intf.AppealReopenHistory appealReopenHistoryObj =
      AppealReopenHistoryFactory.newInstance();

    // Return structure
    final ReadReopenDetails readReopenDetails = new ReadReopenDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Need to read for case ID before validating security
    readReopenDetails.readReopenDetails =
      appealReopenHistoryObj.read(key.readReopenDetailsKey);

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = readReopenDetails.readReopenDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    return readReopenDetails;
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to reopen a hearing case.
   * 
   * @param key The ID of the hearing case being reopened.
   * @param details The details of the hearing case being reopened.
   */
  @Override
  public void reopenCase(final ReopenHearingCaseKey key,
    final ReopenHearingCaseDetails details) throws AppException,
    InformationalException {

    // CaseSecurityCheck objects
    final Appeal appeal_boObj = AppealFactory.newInstance();

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Appeal objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealID appealID;
    final AppealKey appealKey = new AppealKey();
    final ModifyDeadlineDateDetails modifyDeadlineDateDetails =
      new ModifyDeadlineDateDetails();
    final CaseIDDeadlineDate caseIDDeadlineDate = new CaseIDDeadlineDate();

    AppealReadSummaryDetails appealReadSummaryDetails =
      new AppealReadSummaryDetails();
    CaseStatusAndEndDateDetails caseStatusAndEndDateDetails =
      new CaseStatusAndEndDateDetails();

    // Appeal time constraint objects
    int numDaysToRequestReopen = 0;

    // HearingDecision objects
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    DecisionDateDetails decisionDateDetails = new DecisionDateDetails();

    // AppealReopenHistory objects
    final curam.appeal.sl.entity.intf.AppealReopenHistory appealReopenHistoryObj =
      AppealReopenHistoryFactory.newInstance();
    final AppealReopenHistoryDtls appealReopenHistoryDtls =
      new AppealReopenHistoryDtls();

    // CaseStatus objects
    final UpdateAppealCaseStatusDetails updateAppealCaseStatusDetails =
      new UpdateAppealCaseStatusDetails();

    // Objects used for case of the appeal case being opened which has the
    // earliest deadline on the group of appealed cases belonged to that appeal
    // case
    CaseIDAndDeadlineDateList caseIDAndDeadlineDateList;
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    CaseIDAndDeadlineDate caseIDAndDeadlineDate;

    // Objects used for updating the deadlines of the active appealed cases
    // related to the appeal case being reopened.
    final ActiveCaseKey activeCaseKey = new ActiveCaseKey();
    ActiveAppealedCaseDeadlineDetailsList activeAppealedCaseDeadlineDetailsList;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Perform validations
    validateReopenHearingCase(key, details);

    updateAppealCaseStatusDetails.caseID = key.caseID;
    updateAppealCaseStatusDetails.statusCode = CASESTATUS.OPEN;
    updateAppealCaseStatusDetails.versionNo = details.caseVersionNo;
    appeal_boObj.updateCaseStatus(updateAppealCaseStatusDetails);

    // Insert deadline task
    caseIDDeadlineDate.caseID = key.caseID;

    // No longer have to read time constraints to get the deadline date
    // Firstly get the original deadline date
    appealCaseIDKey.caseID = key.caseID;
    appealReadSummaryDetails = appealObj.readByCase(appealCaseIDKey);

    // Read hearing case end date
    caseHeaderKey.caseID = key.caseID;
    caseStatusAndEndDateDetails =
      caseHeaderObj.readStatusCodeAndEndDate(caseHeaderKey);

    // Get the new deadline date
    int dateDiff = 0;

    dateDiff =
      details.reopenDate.subtract(caseStatusAndEndDateDetails.endDate);

    caseIDDeadlineDate.deadlineDate =
      appealReadSummaryDetails.deadlineDate.addDays(dateDiff);

    appeal_boObj.createDeadlineTask(caseIDDeadlineDate);

    // Read appeal ID
    appealCaseIDKey.caseID = key.caseID;
    appealID = appealObj.readAppealIDByCase(appealCaseIDKey);

    // Calculate timely indicator
    // - read hearing decision date
    int dateDiffInDays = 0;
    boolean blnDecisionFound;

    hearingDecisionCaseKey.caseID = key.caseID;
    try {

      decisionDateDetails =
        hearingDecisionObj
          .readDecisionIDDateAndVersionByCase(hearingDecisionCaseKey);
      blnDecisionFound = true;
    } catch (final RecordNotFoundException e) {

      blnDecisionFound = false;
    }
    // - calculate days since appeal decided
    if (blnDecisionFound) {

      dateDiffInDays =
        details.reopenDate.subtract(decisionDateDetails.decisionDate);

      // Get the case of the appeal case being opened which has the
      // earliest deadline on the group of appealed cases belonged to that
      // appeal case
      activeApprovedCaseKey.appealCaseID = key.caseID;

      caseIDAndDeadlineDateList =
        appealRelationshipObj
          .searchEarliestDeadlineDetails(activeApprovedCaseKey);

      // Get the earliest deadline date may return more than one record, but
      // the first one is the only interesting one.
      caseIDAndDeadlineDate = caseIDAndDeadlineDateList.dtls.item(0);

      // BEGIN, CR00284786, DG
      // Get the number of days in which a request for a hearing case
      // must be made
      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.appealCaseID = key.caseID;
      caseIDAppealCaseIDConstraintType.caseID = caseIDAndDeadlineDate.caseID;
      caseIDAppealCaseIDConstraintType.constraintType =
        CONSTRAINTTYPE.REOPEN_HEARING_CASE;
      final int timeConstraintLength =
        AppealFactory.newInstance().getTimeConstraintLength(
          caseIDAppealCaseIDConstraintType).numberOfDays;

      numDaysToRequestReopen = timeConstraintLength;

      if (timeConstraintLength == 0) {
        // Required constraint does not exist - throw exception
        final AppException ex =
          new AppException(
            curam.message.BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        final curam.util.type.CodeTableItemIdentifier constraintType =
          new curam.util.type.CodeTableItemIdentifier(
            curam.codetable.CONSTRAINTTYPE.TABLENAME,
            curam.codetable.CONSTRAINTTYPE.REOPEN_HEARING_CASE);

        ex.arg(constraintType);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(ex,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            9);
      }
      // END, CR00284786

    }
    // Update deadline date and timely indicator
    appealKey.appealID = appealID.appealID;

    // Find all appealed cases associated with the appeal and update their
    // deadlines with the same days as the appeal case deadline has been
    // updated.
    activeCaseKey.appealCaseID = key.caseID;
    activeAppealedCaseDeadlineDetailsList =
      appealRelationshipObj
        .searchActiveDeadlineDetailsByAppealCase(activeCaseKey);

    for (int i = 0; i < activeAppealedCaseDeadlineDetailsList.dtls.size(); i++) {

      // Objects used for managing the deadline of the appealed cases related to
      // the appeal case.
      ActiveAppealedCaseDeadlineDetails activeAppealedCaseDeadlineDetails;
      final AppealRelationshipKey appealRelationshipKey =
        new curam.appeal.sl.entity.struct.AppealRelationshipKey();
      final curam.appeal.sl.entity.struct.DeadlineDate deadlineDate =
        new curam.appeal.sl.entity.struct.DeadlineDate();

      activeAppealedCaseDeadlineDetails =
        activeAppealedCaseDeadlineDetailsList.dtls.item(i);

      // Update the deadline of the appealed case.
      appealRelationshipKey.appealRelationshipID =
        activeAppealedCaseDeadlineDetails.appealRelationshipID;
      deadlineDate.deadlineDate =
        activeAppealedCaseDeadlineDetails.deadlineDate.addDays(dateDiff);

      appealRelationshipObj.modifyDeadlineDate(appealRelationshipKey,
        deadlineDate);
    }

    modifyDeadlineDateDetails.deadlineDate = caseIDDeadlineDate.deadlineDate;
    modifyDeadlineDateDetails.versionNo = details.appealVersionNo;
    appealObj.modifyReopenDetails(appealKey, modifyDeadlineDateDetails);

    // Update indicators on related cases
    createEventsAndModifyAppealIndicators(key);

    // - does day count exceed timely day limit
    if (dateDiffInDays > numDaysToRequestReopen) {
      appealReopenHistoryDtls.timelyIndicator = false;
    } else {
      appealReopenHistoryDtls.timelyIndicator = true;
    }

    // Insert history record
    appealReopenHistoryDtls.caseID = key.caseID;
    appealReopenHistoryDtls.reopenDate = details.reopenDate;
    appealReopenHistoryDtls.reopenReasonCode = details.reopenReasonCode;
    appealReopenHistoryDtls.reopenReasonText = details.reopenReasonText;
    appealReopenHistoryDtls.reopenUserName = TransactionInfo.getProgramUser();
    appealReopenHistoryObj.insert(appealReopenHistoryDtls);

    if (blnDecisionFound) {
      final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
      final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
        new HearingDecisionStatusVersionDetails();

      hearingDecisionKey.hearingDecisionID =
        decisionDateDetails.hearingDecisionID;
      hearingDecisionStatusVersionDetails.decisionStatus =
        HEARINGDECISIONSTATUS.INPROGRESS;
      hearingDecisionStatusVersionDetails.versionNo =
        decisionDateDetails.versionNo;

      hearingDecisionObj.modifyStatus(hearingDecisionKey,
        hearingDecisionStatusVersionDetails);
    }

    // BEGIN, CR CR00050230, NSP
    if (key.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      // Get Issue Delivery RelatedProductCaseID using Appeal case ID
      final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
        new AppealCaseIDTYypeRecordStatusDetails();

      final AppealRelationship appealRelationship =
        AppealRelationshipFactory.newInstance();

      appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
      appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
      Count count;

      // counts the no. of issues cases attached to the appeal case.
      count =
        appealRelationship
          .countAppealedIssuesOnAppealCase(appealCaseIDTYypeRecordStatusDetails);

      // Create product item child element and add it to the root
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.caseID = key.caseID;
      // BEGIN, CR00052221, RKi
      ProductDeliveryKeyForAppealList productDeliveryKeyForAppealList;
      IssueDeliveryKeyForAppealList issueDeliveryKeyForAppealList;

      // If at least one issue is attached to the appeal case extra tab
      // (issue type) is displayed
      if (count.numberOfRecords >= 1) {
        issueDeliveryKeyForAppealList =
          appealRelationship
            .searchIssueCaseByAppeal(appealCaseIDTYypeRecordStatusDetails);
        for (int i = 0; i < issueDeliveryKeyForAppealList.dtls.size(); i++) {
          insertTransactionLogDetails.caseID =
            issueDeliveryKeyForAppealList.dtls.item(i).caseID;
          // Log Appeal Canceled event
          insertTransactionLogDetails.eventTypeCode =
            CASETRANSACTIONEVENTS.APPEAL_CANCELLED;
          caseTransactionLog
            .insertTransactionLog(insertTransactionLogDetails);

        }
      } else {
        // Read ProductDelivery
        productDeliveryKeyForAppealList =
          appealRelationship
            .searchProductDeliveryByAppealCaseID(appealCaseIDTYypeRecordStatusDetails);
        for (int i = 0; i < productDeliveryKeyForAppealList.dtls.size(); i++) {
          insertTransactionLogDetails.caseID =
            productDeliveryKeyForAppealList.dtls.item(i).caseID;
          // Log Appeal Canceled event
          insertTransactionLogDetails.eventTypeCode =
            CASETRANSACTIONEVENTS.APPEAL_CANCELLED;
          caseTransactionLog
            .insertTransactionLog(insertTransactionLogDetails);

        }
      }
      // END, CR00052221

    }
    // END, CR CR00050230

  }

  // ___________________________________________________________________________
  /**
   * Service layer method to validate the hearing case re-open details.
   * 
   * @param key The ID of the hearing case being reopened.
   * @param details The details of the hearing case being reopened.
   */
  @Override
  protected void validateReopenHearingCase(final ReopenHearingCaseKey key,
    final ReopenHearingCaseDetails details) throws AppException,
    InformationalException {

    // CaseHeader objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusAndEndDateDetails caseStatusAndEndDateDetails =
      new CaseStatusAndEndDateDetails();

    // HearingDecision objects
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionResolutionDateStatusDetails hearingDecisionResolutionDateStatusDetails =
      new HearingDecisionResolutionDateStatusDetails();

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingParticipatedAndTypeDetails hearingParticipatedAndTypeDetails =
      new HearingParticipatedAndTypeDetails();

    // AppealRelationship Objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // Objects needed for checking if a case has been already appealed
    final ActiveAppealCaseStatus activeAppealCaseStatus =
      new ActiveAppealCaseStatus();
    CaseAndPriorAppeal caseAndPriorAppeal;
    final AppealedCase appealedCaseObj = AppealedCaseFactory.newInstance();
    ActiveAppealedCaseDetailsList activeAppealedCaseDetailsList;
    CaseAlreadyAppealed caseAlreadyAppealed;

    // Hearing user role objects
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final ParticipatedUserKey participatedUserKey = new ParticipatedUserKey();
    // BEGIN, CR00124792, RKi
    final HearingParticipationAttendanceKey hearingParticipationAttendanceKey =
      new HearingParticipationAttendanceKey();
    // END, CR00124792

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Read hearing case status
    caseHeaderKey.caseID = key.caseID;
    caseStatusAndEndDateDetails =
      caseHeaderObj.readStatusCodeAndEndDate(caseHeaderKey);

    // Check case header status
    if (!caseStatusAndEndDateDetails.statusCode.equals(CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_CASENOTCLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Check case header end date is before reopen date
    if (caseStatusAndEndDateDetails.endDate.after(details.reopenDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_REOPENDATEINVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Today's date
    // Check reopen date is not in the future
    final Date currentDate = Date.getCurrentDate();

    if (details.reopenDate.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_REOPENDDATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Read hearing decision status
    boolean blnDecisionFound;

    hearingDecisionCaseKey.caseID = key.caseID;
    try {

      hearingDecisionResolutionDateStatusDetails =
        hearingDecisionObj
          .readResolutionDateStatusByCase(hearingDecisionCaseKey);
      blnDecisionFound = true;
    } catch (final RecordNotFoundException e) {

      blnDecisionFound = false;
    }
    if (!blnDecisionFound
      || !hearingDecisionResolutionDateStatusDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_NOHEARINGDECISION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Read hearing participation info
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();

    caseAndStatusKey.caseID = key.caseID;
    caseAndStatusKey.statusCode = curam.codetable.HEARINGSTATUS.COMPLETED;
    boolean blnHearingFound;

    try {
      hearingParticipatedAndTypeDetails =
        hearingObj
          .readLatestParticipatedAndTypeDetailsByCaseAndStatus(caseAndStatusKey);
      blnHearingFound = true;
    } catch (final RecordNotFoundException e) {

      blnHearingFound = false;
    }

    // if no hearing, throw an exception
    if (!blnHearingFound) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_NOHEARING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // BEGIN, 33156, BAR
    // Should be able to reopen a hearing case whenever there are
    // no existing "OPEN" hearing cases.

    // Get Lead CaseID
    activeAppealCaseStatus.appealCaseID = key.caseID;

    activeAppealedCaseDetailsList =
      appealRelationshipObj
        .searchActiveAppealedCaseDetailsByAppealCase(activeAppealCaseStatus);

    // count number of related "OPEN" appeal cases
    int relatedAppealCaseCount = 0;

    for (int i = 0; i < activeAppealedCaseDetailsList.dtls.size(); i++) {

      // check if the actual case is being appealed in another active appeal

      caseAndPriorAppeal = new CaseAndPriorAppeal();
      caseAndPriorAppeal.caseID =
        activeAppealedCaseDetailsList.dtls.item(i).caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        activeAppealedCaseDetailsList.dtls.item(i).priorAppealCaseID;

      caseAlreadyAppealed =
        appealedCaseObj.isAlreadyAppealed(caseAndPriorAppeal);

      if (caseAlreadyAppealed.appealed) {
        relatedAppealCaseCount++;
      }

    }

    if (relatedAppealCaseCount >= kRelatedAppeals) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_CASEOPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    // for a case to be reopened, the appellant, respondent or third party must
    // not have attended the hearing

    // if appellant didn't participate, then no need to search further
    /*
     * if (!hearingParticipatedAndTypeDetails.appellantParticipatedCode.equals(
     * HEARINGPARTICIPATION.PARTICIPATED)) {
     * return;
     * }
     */

    // BEGIN, CR00039200, RKi
    // Required structs
    participatedUserKey.caseID = key.caseID;

    // BEGIN, CR CR00067754, NSP
    participatedUserKey.statusCode = HEARINGPARTICIPATION.NOSHOW;
    // END, CR CR00067754

    // BEGIN, CR00124792, RKi
    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    Count count = new Count();

    hearingParticipationAttendanceKey.caseID = key.caseID;

    // BEGIN, CR CR00067754, NSP
    hearingParticipationAttendanceKey.statusCode =
      HEARINGPARTICIPATION.NOSHOW;
    hearingParticipationAttendanceKey.participantType =
      LAPARTICIPANTTYPE.APPELLANT;

    // retrieves the count of participants who have not participated in the
    // hearing.
    count =
      hearingParticipationObj
        .countHearingParticipantsByCaseIDTypeStatus(hearingParticipationAttendanceKey);
    // END, CR00124792
    // END, CR00039200

    // see if there are any third parties
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // if a third part exists, and didn't participate, no need to check further
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0
      && !hearingParticipatedAndTypeDetails.thirdPartyParticipatedCode
        .equals(HEARINGPARTICIPATION.PARTICIPATED)) {
      return;
    }

    // check if the respondent participated
    boolean respondantsParticipated = true;

    try {
      participatedUserKey.caseID = key.caseID;
      final HearingUserRoleParticipatedList hearingUserRoleParticipatedList =
        hearingUserRoleObj.searchUserParticipation(participatedUserKey);

      for (int i = 0; i < hearingUserRoleParticipatedList.dtls.size(); i++) {
        if (!hearingUserRoleParticipatedList.dtls.item(i).participatedCode
          .equals(HEARINGPARTICIPATION.PARTICIPATED)) {
          respondantsParticipated = false;
          break;
        }
      }

    } catch (final RecordNotFoundException e) {
      respondantsParticipated = false;
    }
    // BEGIN, CR00039200, RKi
    // all parties participated, so can't reopen the case
    if (respondantsParticipated && count.numberOfRecords == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_PARTICIPANTSPRESENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
    // END, CR00039200

  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to create events and modify indicators for all cases
   * related to the case being reopened.
   * 
   * @param key The ID of the hearing case being reopened.
   */
  @Override
  protected void createEventsAndModifyAppealIndicators(
    final ReopenHearingCaseKey key) throws AppException,
    InformationalException {

    // CaseHeader objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();

    // CaseEvent objects
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // current Date
    final Date currentDate = Date.getCurrentDate();

    // AppealRelationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    final ActiveAppealCaseStatus activeAppealCaseStatus =
      new ActiveAppealCaseStatus();
    ActiveAppealedCaseDetailsList activeAppealedCaseDetailsList;

    // Find all the active appealed cases associated with the appeal.
    activeAppealCaseStatus.appealCaseID = key.caseID;

    activeAppealedCaseDetailsList =
      appealRelationshipObj
        .searchActiveAppealedCaseDetailsByAppealCase(activeAppealCaseStatus);

    for (int i = 0; i < activeAppealedCaseDetailsList.dtls.size(); i++) {

      // Set appealed case
      caseHeaderKey.caseID =
        activeAppealedCaseDetailsList.dtls.item(i).caseID;

      // Update appealed case indicator
      caseAppealIndicatorDetails.appealIndicator = true;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);

      // Insert a case event against the appealed case
      caseEventDtls.caseEventID = uniqueIDObj.getNextID();
      caseEventDtls.caseID = caseHeaderKey.caseID;
      caseEventDtls.startDate = currentDate;
      caseEventDtls.endDate = currentDate;
      caseEventDtls.relatedID = key.caseID;
      caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
      caseEventDtls.eventTypeCode = CASEEVENTTYPE.APPEALREOPENED;
      caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
      caseEventObj.insert(caseEventDtls);

      // If the appealed case is an assessment update the associated product
      // delivery case indicator and insert a case event against it, if exists.
      CaseTypeCode caseTypeCode;
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = key.caseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

        final CaseRelationship caseRelationshipObj =
          CaseRelationshipFactory.newInstance();
        final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
          new CaseRelByCaseIDStatusReasonTypeKey();
        CaseRelationshipDtlsList caseRelationshipDtlsList;

        // Determine the product delivery for the assessment delivery
        caseRelByCaseIDStatusReasonTypeKey.caseID = caseKey.caseID;
        caseRelByCaseIDStatusReasonTypeKey.reasonCode =
          curam.codetable.CASERELATIONSHIPREASONCODE.DEFAULTCODE;
        caseRelByCaseIDStatusReasonTypeKey.statusCode =
          curam.codetable.CASERELATIONSHIPSTATUSCODE.DEFAULTCODE;
        caseRelByCaseIDStatusReasonTypeKey.typeCode =
          curam.codetable.CASERELATIONSHIPTYPECODE.ASSESSMENTPRODUCT;
        caseRelationshipDtlsList =
          caseRelationshipObj
            .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

        // If one found, update the associated product delivery case indicator
        // and insert a case event against it.
        if (caseRelationshipDtlsList.dtls.size() > 0) {

          caseHeaderKey.caseID =
            caseRelationshipDtlsList.dtls.item(0).relatedCaseID;
          caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
            caseAppealIndicatorDetails);

          caseEventDtls.caseEventID = uniqueIDObj.getNextID();
          caseHeaderKey.caseID = caseHeaderKey.caseID;
          caseEventObj.insert(caseEventDtls);
        }
      }

      // Update the prior appeal case indicator if there is one and insert a
      // case event against it
      caseHeaderKey.caseID =
        activeAppealedCaseDetailsList.dtls.item(i).priorAppealCaseID;
      if (caseHeaderKey.caseID > 0) {
        caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
          caseAppealIndicatorDetails);

        caseEventDtls.caseEventID = uniqueIDObj.getNextID();
        caseHeaderKey.caseID = caseHeaderKey.caseID;
        caseEventObj.insert(caseEventDtls);
      }

    }

    // Insert a case event against appeal case
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = key.caseID;
    caseEventObj.insert(caseEventDtls);

  }
}
