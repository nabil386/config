/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.tab.impl;

/**
 * Constants file to represent the IDs of menu items that are to be
 * conditionally
 * displayed based on the logic in the in the navigation state loader file(s).
 * 
 */
public abstract class TabLoaderConst {

  /**
   * String constant for the Hearing identifier.
   */
  public static final String kHearingID = "hearingID";

  /**
   * String constant for the ID of the Complete action.
   */
  public static final String kCompleteID = "CompleteHearing";

  /**
   * String constant for the ID of the Continue action.
   */
  public static final String kContinueID = "ContinueHearing";

  /**
   * String constant for the ID of the Reschedule action.
   */
  public static final String kRescheduleID = "RescheduleHearing";

  /**
   * String constant for the ID of the Adjourn action.
   */
  public static final String kAdjournID = "AdjournHearing";

  /**
   * String constant for the ID of the Add Witness action.
   */
  public static final String kAddWitnessID = "AddWitness";

  /**
   * String constant for case identifier.
   */
  public static final String kCaseID = "caseID";

  /**
   * String constants for menu items for managing Items of Interest
   */
  public static final String kBookmark = "Bookmark";

  public static final String kRemoveBookmark = "RemoveBookmark";

  public static final String kViewCancelDetails = "ViewCancelDetails";

  public static final String kEditCancelDetails = "EditCancelDetails";

  // BEGIN, CR00448154, DG
  public static final String kAppealRequests = "AppealRequests";
  // END, CR00448154

}
