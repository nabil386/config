/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealStageDtls;
import curam.appeal.sl.entity.struct.AppealTypeAndProcess;
import curam.appeal.sl.entity.struct.ParentStageDetails;
import curam.appeal.sl.impl.KeySets;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.UniqueID;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * The AppealStage entity maintains the valid appeal stages for a product
 * appeal process definition.
 */
public abstract class AppealStage extends
  curam.appeal.sl.entity.base.AppealStage {

  // ___________________________________________________________________________
  /**
   * This method ensures that only active appeal stage records are considered
   * when counting the number of records whose parent appeal stage is equal
   * to the specified value.
   * 
   * @param key The parentAppealStageID and the recordStatus to read for.
   */
  @Override
  protected void precountParentAppealStage(final ParentStageDetails key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Sets record status to always be active and sets the value to be used for
   * matching any appeal type, before counting the number of matching appeal
   * stages within an appeal process.
   * 
   * @param key The process ID and appeal stage type.
   */
  @Override
  protected void precountAppealStagesForAppealType(
    final AppealTypeAndProcess key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.anyAppealTypeCode = APPEALSTAGEAPPEALTYPE.ANY;
  }

  // ___________________________________________________________________________
  /**
   * This method ensures that only appeal stage records with an active
   * record status are considered as part of the search.
   */
  @Override
  protected void presearchActiveStageParentByProcessAndType(
    final AppealTypeAndProcess key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.anyAppealTypeCode = APPEALSTAGEAPPEALTYPE.ANY;
  }

  // BEGIN, CR00272139, PB
  /**
   * Performs all pre-insert functionality for a new
   * appeal stage record.
   * 
   * @param details Contains new appeal stage details.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final AppealStageDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_APPEALSTAGE;
    details.appealStageID = uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet);
  }
  // END, CR00272139
}
