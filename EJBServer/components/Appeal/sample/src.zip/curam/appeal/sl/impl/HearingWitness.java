/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingDateAndType;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingWitnessHearingIDCPRID;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.fact.HearingParticipationFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.CreateCaseParticipantRoleLinkDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateHearingWitnessDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingIDKeyHW;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.HearingWitnessIDKey;
import curam.appeal.sl.struct.HearingWitnessNotificationDetails;
import curam.appeal.sl.struct.IsSufficientTimeForCorrespondence;
import curam.appeal.sl.struct.ModifyHearingWitnessDetails;
import curam.appeal.sl.struct.ModifyHearingWitnessStatus;
import curam.appeal.sl.struct.ReadHearingWitnessDetails;
import curam.appeal.sl.struct.ReadHearingWitnessDetailsList;
import curam.appeal.sl.struct.RelatedID;
import curam.appeal.sl.struct.ValidateHearingWitnessHearingStatusDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.ONBEHALFOF;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.TASKPRIORITY;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.TypeAndStatusAndParticipantRoleDetails;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.Representative;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.CancelClientKey;
import curam.core.sl.struct.CaseParticipantRoleDetails;
import curam.core.sl.struct.CreateStandardManualTaskDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.CuramInd;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOHEARINGSCHEDULE;
import curam.message.BPOHEARINGWITNESS;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Hearing Witness
 * process layer.
 * 
 */
public abstract class HearingWitness extends
  curam.appeal.sl.base.HearingWitness {

  // ___________________________________________________________________________
  /**
   * Creates a Hearing Witness
   * 
   * @param dtls
   * The details of the hearing witness
   * @return
   * Any informational messages
   */
  @Override
  public InformationalMsgDtlsList create(
    final CreateHearingWitnessDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Hearing witness variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();

    // Case participant role variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Representative variable
    final Representative representativeObj =
      RepresentativeFactory.newInstance();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Date variables
    final Date currentDate = Date.getCurrentDate();

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID = dtls.hearingWitness.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    // Begin CR00117296 LP
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // End CR00117296 LP
    validateInsert(dtls);

    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID == 0
      && dtls.representativeRegistrationDetails.representativeDtls.representativeName
        .length() == 0) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_WITNESSNAMEEMPTY);

    }

    // If the case participant role ID is 0,
    // the user is registering a representative
    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID == 0) {

      // Populate the representative registration date
      dtls.representativeRegistrationDetails.representativeRegistrationDetails.registrationDate =
        currentDate;

      dtls.representativeRegistrationDetails.representativeDtls.representativeType =
        REPRESENTATIVETYPE.WITNESS;

      // Register the representative
      representativeObj
        .registerRepresentative(dtls.representativeRegistrationDetails);

    }

    // Populate the case participant role
    final CaseParticipantRoleDetails caseParticipantRoleDtls =
      new CaseParticipantRoleDetails();

    caseParticipantRoleDtls.dtls.caseID = hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleDtls.dtls.participantRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    caseParticipantRoleDtls.dtls.fromDate = currentDate;
    caseParticipantRoleDtls.dtls.toDate = currentDate;
    caseParticipantRoleDtls.dtls.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleDtls.dtls.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGWITNESS;
    caseParticipantRoleDtls.dtls.comments = dtls.hearingWitness.comments;

    caseParticipantRole_boObj
      .insertCaseParticipantRole(caseParticipantRoleDtls);

    // Map the newly created caseParticipantRoleID
    // to the CreateHearingWitnessDetails object
    dtls.hearingWitness.caseParticipantRoleID =
      caseParticipantRoleDtls.dtls.caseParticipantRoleID;

    dtls.hearingWitness.participatedCode = HEARINGPARTICIPATION.DEFAULTCODE;

    hearingWitnessObj.insert(dtls.hearingWitness);

    final HearingWitnessNotificationDetails hearingWitnessNotificationDetails =
      new HearingWitnessNotificationDetails();

    hearingWitnessNotificationDetails.hearingID =
      dtls.hearingWitness.hearingID;
    hearingWitnessNotificationDetails.concernRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    hearingWitnessNotificationDetails.voluntaryIndicator =
      dtls.hearingWitness.voluntaryIndicator;

    // BEGIN, CR00177498, PM
    hearingWitnessNotificationDetails.caseParticipantRoleID =
      dtls.hearingWitness.caseParticipantRoleID;
    // END, CR00177498

    // Begin CR00117296 LP
    // create CaseParticipantRoleLink entries. For each hearing Participant
    // selected
    // an entry is inserted

    final CreateCaseParticipantRoleLinkDetails caseParticipantRoleLinkDetails =
      new CreateCaseParticipantRoleLinkDetails();

    caseParticipantRoleLinkDetails.caseParticipantRoleIDs =
      dtls.caseParticipantRoleIDs;
    caseParticipantRoleLinkDetails.relatedID =
      dtls.hearingWitness.caseParticipantRoleID;
    ;
    HearingParticipationFactory.newInstance()
      .createWitnessCaseParticipantRoleLinks(caseParticipantRoleLinkDetails);
    // End CR00117296 LP

    // BEGIN, CR00115728, RKi
    informationalMsgDtlsList.dtls
      .addAll(sendNotification(hearingWitnessNotificationDetails).dtls);
    // END, CR00115728

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Modify a Hearing Witness
   * 
   * @param dtls
   * The details of the hearing witness to modify
   */
  @Override
  public InformationalMsgDtlsList modify(
    final ModifyHearingWitnessDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Hearing witness variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingWitnessIDKey hearingWitnessIDKey =
      new curam.appeal.sl.entity.struct.HearingWitnessIDKey();
    curam.appeal.sl.entity.struct.ReadHearingWitnessDetails readHearingWitnessDetails;

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Case Participant Role variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails =
      new TypeAndStatusAndParticipantRoleDetails();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();

    // Read hearing id
    hearingWitnessIDKey.hearingWitnessID =
      dtls.hearingWitnessIDKey.hearingWitnessID;

    readHearingWitnessDetails = hearingWitnessObj.read(hearingWitnessIDKey);

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID = readHearingWitnessDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateModify(dtls);

    // Check case participant role to see if already canceled
    caseParticipantRole_eoKey.caseParticipantRoleID =
      readHearingWitnessDetails.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails =
      caseParticipantRole_eoObj
        .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

    if (typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_ALREADY_CANCELED);

    }

    // send notification if witness has been changed to involuntary
    if (dtls.modifyHearingWitnessDetails.voluntaryIndicator == false
      && readHearingWitnessDetails.voluntaryIndicator == true) {

      final HearingWitnessNotificationDetails hearingWitnessNotificationDetails =
        new HearingWitnessNotificationDetails();

      hearingWitnessNotificationDetails.hearingID =
        readHearingWitnessDetails.hearingID;
      hearingWitnessNotificationDetails.concernRoleID =
        readHearingWitnessDetails.participantRoleID;
      hearingWitnessNotificationDetails.voluntaryIndicator = false;
      informationalMsgDtlsList.dtls
        .addAll(sendNotification(hearingWitnessNotificationDetails).dtls);

    }
    // Modify witness details
    hearingWitnessIDKey =
      new curam.appeal.sl.entity.struct.HearingWitnessIDKey();
    hearingWitnessIDKey.hearingWitnessID =
      dtls.hearingWitnessIDKey.hearingWitnessID;

    hearingWitnessObj.modify(hearingWitnessIDKey,
      dtls.modifyHearingWitnessDetails);

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Read a Hearing Witness
   * 
   * @param key
   * The details of the hearing witness to read
   * @return
   * readHearingWitnessDetails Return details of a particular hearing
   * witness
   */
  @Override
  public ReadHearingWitnessDetails read(final HearingWitnessIDKey key)
    throws AppException, InformationalException {

    // Hearing witness variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingWitnessIDKey hearingWitnessIDKey =
      new curam.appeal.sl.entity.struct.HearingWitnessIDKey();
    ReadHearingWitnessDetails readHearingWitnessDetails_bo;
    curam.appeal.sl.entity.struct.ReadHearingWitnessDetails readHearingWitnessDetails =
      new curam.appeal.sl.entity.struct.ReadHearingWitnessDetails();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read hearing id
    hearingWitnessIDKey.hearingWitnessID =
      key.hearingWitnessIDKeytls.hearingWitnessID;
    readHearingWitnessDetails = hearingWitnessObj.read(hearingWitnessIDKey);

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID = readHearingWitnessDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    readHearingWitnessDetails_bo = new ReadHearingWitnessDetails();

    hearingWitnessIDKey =
      new curam.appeal.sl.entity.struct.HearingWitnessIDKey();
    hearingWitnessIDKey.hearingWitnessID =
      key.hearingWitnessIDKeytls.hearingWitnessID;
    readHearingWitnessDetails_bo.readHearingWitnessDetails =
      hearingWitnessObj.read(hearingWitnessIDKey);

    // Begin CR00117296 LP
    final RelatedID relatedID = new RelatedID();

    relatedID.key.relatedID =
      readHearingWitnessDetails_bo.readHearingWitnessDetails.caseParticipantRoleID;

    readHearingWitnessDetails_bo.caseParticipantRoleLinkDetailsList =
      HearingParticipationFactory.newInstance()
        .listCaseParticipantLinkByRelatedID(relatedID);
    readHearingWitnessDetails_bo.participantNames =
      this
        .buildConcernNameString(readHearingWitnessDetails_bo.caseParticipantRoleLinkDetailsList);
    // End CR00117296 LP
    return readHearingWitnessDetails_bo;

  }

  /**
   * Generates a comma separated string of ConcernRole names
   * 
   * @param list list of caseParticipantRoleLinkDetails
   * @return comma separated string of ConcernRole names
   */
  // BEGIN, CR00177241, PM
  protected String buildConcernNameString(
    final curam.appeal.sl.struct.CaseParticipantRoleLinkDetailsList list) {

    // END, CR00177241
    final StringBuffer buffer = new StringBuffer();
    int i;

    for (i = 0; i < list.dtls.dtls.size(); i++) {
      buffer.append(list.dtls.dtls.item(i).name);
      buffer.append(CuramConst.gkComma);
    }
    if (i > 0) {
      buffer.setLength(buffer.length() - 1);
    }
    return buffer.toString();
  }

  // ___________________________________________________________________________
  /**
   * Return a list of Hearing Witnesses
   * 
   * @param key
   * The Hearing ID to use to return a Hearing Witness listing
   * @return
   * readHearingWitnessDetailsList Returns a list of hearing witnesses
   */
  @Override
  public ReadHearingWitnessDetailsList list(final HearingIDKeyHW key)
    throws AppException, InformationalException {

    // Hearing witness variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    ReadHearingWitnessDetailsList readHearingWitnessDetailsList;

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.hearingIDKeyHW.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Return a list of hearing witnesses
    readHearingWitnessDetailsList = new ReadHearingWitnessDetailsList();
    readHearingWitnessDetailsList.readHearingWitnessDetailsList
      .addAll(hearingWitnessObj.searchByHearingID(key.hearingIDKeyHW).dtls);

    return readHearingWitnessDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Cancel a hearing witness
   * 
   * @param dtls
   * The status details of the hearing witness to cancel
   */
  @Override
  public void cancel(final ModifyHearingWitnessStatus dtls)
    throws AppException, InformationalException {

    // Hearing Witness Variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();

    HearingWitnessHearingIDCPRID hearingWitnessHearingIDCPRID;

    // Case Participant Role Variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Cancel key variable
    final CancelClientKey cancelClientKey = new CancelClientKey();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey_bo = new HearingKey();

    // Read hearing ID and case participant role id
    hearingWitnessHearingIDCPRID =
      hearingWitnessObj
        .readHearingIDCaseParticipantRoleID(dtls.hearingWitnessIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      hearingWitnessHearingIDCPRID.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read hearing ID and case participant role id
    hearingWitnessHearingIDCPRID =
      hearingWitnessObj
        .readHearingIDCaseParticipantRoleID(dtls.hearingWitnessIDKey);

    validateCancel(hearingWitnessHearingIDCPRID);

    // Cancel hearing witness
    cancelClientKey.caseParticipantRoleID =
      hearingWitnessHearingIDCPRID.caseParticipantRoleID;
    cancelClientKey.versionNo =
      dtls.cancelCaseParticipantRoleDetails.versionNo;

    caseParticipantRole_boObj.cancelCaseParticipantRole(cancelClientKey);

  }

  /**
   * Sends a notification to the hearing witness.
   * 
   * @param dtls
   * The details of the hearing witness we wish to create.
   * @return Any informational messages.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public InformationalMsgDtlsList sendNotification(
    final HearingWitnessNotificationDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages.
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Hearing variables.
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID;

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingKey hearingKey;
    HearingScheduleDate hearingScheduleDate;
    HearingTimeDetails hearingTimeDetails;

    // Null date
    final DateTime nullDate = DateTime.kZeroDateTime;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Populate hearing details
    hearingKey = new curam.appeal.sl.entity.struct.HearingKey();
    hearingKey.hearingID = dtls.hearingID;

    hearingScheduleDate = new HearingScheduleDate();
    hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);
    hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Read hearing case id
    hearingKey_bo = new HearingKey();

    hearingKey_bo.hearingKey.hearingID = dtls.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Read hearing type
    HearingDateAndType hearingDateAndType;

    hearingDateAndType = hearingObj.readScheduledDateAndType(hearingKey);

    // Check scheduled date
    if (!hearingScheduleDate.scheduledDateTime.equals(nullDate)) {

      hearingTimeDetails = new HearingTimeDetails();
      hearingTimeDetails.hearingID = dtls.hearingID;
      hearingTimeDetails.scheduledDateTime =
        hearingScheduleDate.scheduledDateTime;

      final IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondance =
        hearing_boObj.isSufficientTimeForCorrespondence(hearingTimeDetails);

      // Subject and reason message text.
      AppException subjectText;

      if (!isSufficientTimeForCorrespondance.isSufficientTime) {

        // If there is not enough time, inform the user
        final LocalisableString insufficientTime =
          new LocalisableString(
            BPOSCHEDULECORRESPONDENCE.ERR_TIME_INSUFFICIENT);

        final InformationalManager informationalManager =
          new InformationalManager();

        informationalManager.addInformationalMsg(insufficientTime,
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning);
        final String[] warnings =
          informationalManager.obtainInformationalAsString();

        for (int i = 0; i < warnings.length; i++) {

          final InformationalMsgDtls informationalMsgDtls =
            new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt = warnings[i];
          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
        }
        subjectText =
          new AppException(
            BPOHEARINGWITNESS.INF_HEARING_WITNESS_FV_CANNOTSENDCORRESPONDANCETOWITNESS);
      } else {
        if (dtls.voluntaryIndicator) {
          subjectText =
            new AppException(
              BPOHEARINGWITNESS.INF_HEARING_WITNESS_FV_NOTICESUBJECT);
        } else {
          subjectText =
            new AppException(
              BPOHEARINGWITNESS.INF_HEARING_WITNESS_FV_SUBPOENASUBJECT);
        }
      }

      // Set details to perform the creation of a communication
      communicationDetails.subjectText = subjectText.getMessage();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.concernRoleID = dtls.concernRoleID;

      communicationDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      communicationDetails.correspondentConcernRoleID = dtls.concernRoleID;

      // BEGIN, CR00202766, MC
      // CorrespondentTypeCode is not a mandatory entity field only set it if
      // the correspondence is going to the primary client.
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = hearingCaseID.hearingCaseID.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == dtls.concernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766;

      // Set status to either notice or subpoena
      // depending on whether the witness is voluntary or not.
      if (dtls.voluntaryIndicator) {

        communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
        // BEGIN, CR00021655, RKi
      } else {

        communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;
      }
      // END, CR00021655

      // Generate Document
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();
      final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        AppealProFormaDocumentGenerationFactory.newInstance();

      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      // caseParticipantRole object
      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
        new CaseParticipantRoleCaseAndTypeKey();
      CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

      // get the appellant for the appeal case
      caseParticipantRoleCaseAndTypeKey.caseID =
        hearingCaseID.hearingCaseID.caseID;
      // made changes to HearingWitness instead of Appellant
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGWITNESS;

      // get the active participant for the case
      caseParticipantRoleNameDetailsList =
        caseParticipantRoleObj
          .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALSTATEMENTLETTER;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;

      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;
      String hearingType = null;

      // BEGIN, CR00260476, NS
      final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
      final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

      // END, CR00260476

      // is hearing type location?
      // BEGIN, CR00021655, RKi
      if (dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.LOCATION)) {

        hearingType = TEMPLATEIDCODE.APPEALSCHEDULELOCATIONWITNESS;

      } else if (!dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // BEGIN, CR00260476, NS
        if (CASETYPECODE.CFSS_LEGALACTION.equals(caseTypeCode.caseTypeCode)) {
          hearingType = TEMPLATEIDCODE.LALEGALACTIONSUBPOENALOCATION;
        } else {
          hearingType = TEMPLATEIDCODE.APPEALSUBPOENALOCATION;
        }
        // END, CR00260476

      } // is hearing type phone?
      else if (dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.PHONE)) {

        hearingType = TEMPLATEIDCODE.APPEALSCHEDULEPHONEWITNESS;

      } else if (!dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.PHONE)) {

        hearingType = TEMPLATEIDCODE.APPEALSUBPOENAPHONE;
      } // is hearing type home?
      else if (!dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.HOME)) {

        hearingType = TEMPLATEIDCODE.APPEALSCHEDULEHOMEWITNESS;

        // BEGIN, CR00021661, RKi
      } else if (dtls.voluntaryIndicator
        && hearingDateAndType.typeCode.equals(HEARINGTYPE.HOME)) {

        hearingType = TEMPLATEIDCODE.APPEALSUBPOENAHOME;
      }
      // END, CR00021661
      // END, CR00021655

      // Set the document code
      generateDocumentDetails.dtls.documentIDCode = hearingType;

      // Set details to perform the creation of a communication
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;
      communicationDetails.communicationDate = Date.getCurrentDate();
      communicationDetails.concernRoleID = dtls.concernRoleID;
      communicationDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      communicationDetails.correspondentConcernRoleID = dtls.concernRoleID;

      // BEGIN, CR00202766, MC
      // CorrespondentTypeCode is not a mandatory entity field only set it if
      // the correspondence is going to the primary client.
      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == dtls.concernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766;

      // ConcernRoleKey Object
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = dtls.concernRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      communicationDetails.correspondentName =
        concernRoleNameDetails.concernRoleName;

      // get UserName
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.caseID = hearingCaseID.hearingCaseID.caseID;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.printInd = false;

      communicationObj = CommunicationFactory.newInstance();

      // BEGIN, CR00293187, CD
      // Create the communication
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

    return informationalMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to validate the status of a hearing witness.
   * 
   * @param dtls
   * The details of the hearing witness.
   */
  @Override
  protected void validateHearingStatus(
    final ValidateHearingWitnessHearingStatusDetails dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls = new HearingCaseStatusDtls();

    // Read status
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    if (hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_ALREADY_CANCELED);

    }

    if (dtls.participatedCode.equals(HEARINGPARTICIPATION.PARTICIPATED)
      || dtls.participatedCode.equals(HEARINGPARTICIPATION.NOSHOW)) {

      // Check to see if hearing has been held
      if (!hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.COMPLETED)
        && !hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.ADJOURNED)) {

        // Hearing has not been held yet
        final AppException e =
          new AppException(
            BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_HEARINGNOTHELD);

        e.arg(CodeTable.getOneItem(HEARINGPARTICIPATION.TABLENAME,
          dtls.participatedCode));

        throw e;

      }
    } else {

      // Hearing status must be scheduled.
      if (!hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

        throw new AppException(
          BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_NOT_SCHEDULED);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of the third party
   * 
   * @param key
   * The details of the hearing.
   */
  @Override
  protected void validateThirdParty(final HearingIDKeyHW key)
    throws AppException, InformationalException {

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList =
      new CaseParticipantRoleIDDetailsList();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID;

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingCaseID = new HearingCaseID();
    hearingKey_bo.hearingKey.hearingID = key.hearingIDKeyHW.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Retrieve third party participants
    caseParticipantRoleCaseAndTypeKey.caseID =
      hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    caseParticipantRoleIDDetailsList =
      caseParticipantRole
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // if no third party participants found
    if (caseParticipantRoleIDDetailsList.dtls.size() == 0) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_THIRDPARTYNOTEXIST);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate an insert.
   * 
   * @param dtls
   * The insert hearing witnesses details to validate
   */
  @Override
  protected void validateInsert(final CreateHearingWitnessDetails dtls)
    throws AppException, InformationalException {

    final ValidateHearingWitnessHearingStatusDetails validateHearingWitnessHearingStatusDetails =
      new ValidateHearingWitnessHearingStatusDetails();
    final HearingIDKeyHW hearingIDKeyHW = new HearingIDKeyHW();

    hearingIDKeyHW.hearingIDKeyHW.hearingID = dtls.hearingWitness.hearingID;
    validateHearingWitnessHearingStatusDetails.hearingID =
      dtls.hearingWitness.hearingID;
    validateHearingWitnessHearingStatusDetails.participatedCode =
      HEARINGPARTICIPATION.DEFAULTCODE;

    // BEGIN, CR00096787, RKi
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = dtls.hearingWitness.caseParticipantRoleID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd =
      clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    // BEGIN, CR00131191, RKi
    // validates if at least one participant is selected.
    if (dtls.caseParticipantRoleIDs.equals(CuramConst.gkEmpty)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARINGWITNESS_SELECT_ATLEAST_ONE_PARTICIPANT);
    }
    // END, CR00131191

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      throw new AppException(
        curam.message.BPOAPPEALCLIENTMERGE.ERR_CREATE_APPEAL_CASE_DUPLICATE_WITNESS);
    }
    // END, CR00096787

    validateHearingStatus(validateHearingWitnessHearingStatusDetails);

    // Validate third party representatives
    if (dtls.hearingWitness.behalfOfCode.equals(ONBEHALFOF.THIRDPARTY)) {
      validateThirdParty(hearingIDKeyHW);

    }

    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID != 0
      && dtls.representativeRegistrationDetails.representativeDtls.representativeName
        .length() > 0) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_EXISTING_AND_CREATE);

    }
  }

  // END, 35450

  // ___________________________________________________________________________
  /**
   * Method to validate modify witnesses.
   * 
   * @param dtls
   * The hearingID used to return a list of witnesses
   */
  @Override
  protected void validateModify(final ModifyHearingWitnessDetails dtls)
    throws AppException, InformationalException {

    // Validate hearing status variables
    final ValidateHearingWitnessHearingStatusDetails validateHearingWitnessHearingStatusDetails =
      new ValidateHearingWitnessHearingStatusDetails();

    curam.appeal.sl.entity.struct.ReadHearingWitnessDetails readHearingWitnessDetails =
      new curam.appeal.sl.entity.struct.ReadHearingWitnessDetails();

    final curam.appeal.sl.entity.struct.HearingWitnessIDKey hearingWitnessIDKey =
      new curam.appeal.sl.entity.struct.HearingWitnessIDKey();

    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();

    final HearingIDKeyHW hearingIDKeyHW = new HearingIDKeyHW();

    hearingWitnessIDKey.hearingWitnessID =
      dtls.hearingWitnessIDKey.hearingWitnessID;
    readHearingWitnessDetails = hearingWitnessObj.read(hearingWitnessIDKey);

    // Validate hearing status
    validateHearingWitnessHearingStatusDetails.hearingID =
      readHearingWitnessDetails.hearingID;
    validateHearingWitnessHearingStatusDetails.participatedCode =
      dtls.modifyHearingWitnessDetails.participatedCode;
    validateHearingStatus(validateHearingWitnessHearingStatusDetails);

    // Validate third party representatives
    if (dtls.modifyHearingWitnessDetails.behalfOfCode
      .equals(ONBEHALFOF.THIRDPARTY)) {

      hearingIDKeyHW.hearingIDKeyHW.hearingID =
        readHearingWitnessDetails.hearingID;
      validateThirdParty(hearingIDKeyHW);

    }

  }

  // END, 35450

  // ___________________________________________________________________________
  /**
   * Validate that the hearing representative may be canceled.
   * 
   * @param dtls
   * dtls to validate
   */
  @Override
  protected void validateCancel(final HearingWitnessHearingIDCPRID dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Case Participant Role Variables
    final CaseParticipantRole caseParticipantRole_Obj =
      CaseParticipantRoleFactory.newInstance();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails;
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey =
      new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // Read status
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Hearing status must be scheduled.
    if (!hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_NOT_SCHEDULED);

    }

    // Check if case participant role already canceled
    caseParticipantRoleKey.caseParticipantRoleID = dtls.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails =
      caseParticipantRole_Obj
        .readTypeAndStatusAndParticipant(caseParticipantRoleKey);

    if (typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_ALREADY_CANCELED);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new witness statement submission task.
   * 
   * @param appealCaseID
   * The appeal CaseID
   */
  @Override
  public void createWitnessStatementSubmissionTask(
    final AppealCaseID appealCaseID) throws AppException,
    InformationalException {

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDkey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails = new AppealTypeDetails();

    // Get Appeal Type
    appealCaseIDkey.caseID = appealCaseID.caseID;

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = appealCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (!caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDkey);
    }

    // Create a task
    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)
      || caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      // END, CR00115728
      createStandardManualTaskDetails.taskDtls.comments =
        BPOHEARINGSCHEDULE.INF_HEARING_TASK_COMMENTS.getMessageText();

      createStandardManualTaskDetails.taskDtls.subject =
        BPOHEARINGSCHEDULE.INF_HEARING_WITNESS_STATEMENT_TASK_SUBJECT
          .getMessageText();

    } else if (appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.HEARINGREVIEW)) {

      createStandardManualTaskDetails.taskDtls.comments =
        BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_TASK_COMMENTS.getMessageText();

      createStandardManualTaskDetails.taskDtls.subject =
        BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_WITNESS_STATEMENT_TASK_SUBJECT
          .getMessageText();
    }

    createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;

    createStandardManualTaskDetails.concerningDtls.caseID =
      appealCaseID.caseID;
    createStandardManualTaskDetails.taskDtls.taskDefinitionID =
      Appeal.kAppealStandardTask;

    // create the task
    workAllocationTaskObj.createTask(createStandardManualTaskDetails);
  }

}
