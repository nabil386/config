/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006-2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.struct.CaseRefIssueRefConcernRoleID;
import curam.appeal.sl.struct.IssueCaseRelatedCaseConcernDtlsList;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.message.BPOAPPEALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the Appeals Issue Case
 * service layer.
 * 
 */
public class IssueCase extends curam.appeal.sl.base.IssueCase {

  // BEGIN, CR00022056, DK

  // ___________________________________________________________________________
  /**
   * Performs a search for issue cases using the search criteria provided.
   * 
   * @param key
   * Search criteria for the issue case search
   * @return List of issue cases for the search criteria specified.
   */
  @Override
  public IssueCaseRelatedCaseConcernDtlsList searchIssueCases(
    final CaseRefIssueRefConcernRoleID key) throws AppException,
    InformationalException {

    // BEGIN, CR00053018, RKi
    // Required Objects
    final IssueCaseRelatedCaseConcernDtlsList issueCaseRelatedCaseConcernDtlsList =
      new IssueCaseRelatedCaseConcernDtlsList();

    final IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();

    // validation to check if at least one search criteria is entered.
    if (key.key.caseReference.equals(GeneralAppealConstants.kBlank)
      && key.key.issueReference.equals(GeneralAppealConstants.kBlank)
      && key.key.concernRoleID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    // invokes the entity search operation and returns the result
    issueCaseRelatedCaseConcernDtlsList.dtlsList =
      issueDeliveryObj
        .searchByIssueCaseRefRelatedCaseRefConcernRoleID(key.key);

    // END, CR00053018
    return issueCaseRelatedCaseConcernDtlsList;
  }
  // END, CR00022056

}
