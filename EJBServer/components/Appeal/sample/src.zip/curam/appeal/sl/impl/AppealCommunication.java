/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.impl.AppealableCaseType;
import curam.appeal.sl.entity.fact.AppealCancellationFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealedCaseRejectionFactory;
import curam.appeal.sl.entity.fact.CaseParticipantRoleLinkFactory;
import curam.appeal.sl.entity.fact.HearingDecisionAttachmentLinkFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.intf.AppealCancellation;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealedCaseRejection;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingDecisionAttachmentLink;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.AppealCancelReasonCode;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseRejectionReason;
import curam.appeal.sl.entity.struct.AppealCaseStatusDetails;
import curam.appeal.sl.entity.struct.AppealContinueDetails;
import curam.appeal.sl.entity.struct.AppealReasonCodeDetailsList;
import curam.appeal.sl.entity.struct.AppealRelationshipIDKey;
import curam.appeal.sl.entity.struct.AppealResolutionsList;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppealedCaseResolutionDetails;
import curam.appeal.sl.entity.struct.AppealedCaseResolutionDetailsList;
import curam.appeal.sl.entity.struct.AppealedDecisionDate;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDScheduled;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDetailsList;
import curam.appeal.sl.entity.struct.CaseTemplateAndAttachmentDetails;
import curam.appeal.sl.entity.struct.DateResolutionAndCaseRefDetails;
import curam.appeal.sl.entity.struct.HearingCaseUserNameDtlsList;
import curam.appeal.sl.entity.struct.HearingDateAndReferenceDetails;
import curam.appeal.sl.entity.struct.HearingDecisionAttachmentLinkKey;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionResolutionCodeDetails;
import curam.appeal.sl.entity.struct.HearingDtls;
import curam.appeal.sl.entity.struct.HearingFeeNoticeDetails;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantRoleTypeKey;
import curam.appeal.sl.entity.struct.HearingIDRefLocationAddressDetails;
import curam.appeal.sl.entity.struct.HearingIDRefScheduledDateDetails;
import curam.appeal.sl.entity.struct.HearingPostponeDateDetails;
import curam.appeal.sl.entity.struct.HearingRepresentativeKey;
import curam.appeal.sl.entity.struct.HearingScheduleNoticeDetails;
import curam.appeal.sl.entity.struct.HearingUserFullDetailsList;
import curam.appeal.sl.entity.struct.HearingUserRoleStatusKey;
import curam.appeal.sl.entity.struct.ReadCancelledCaseKey;
import curam.appeal.sl.entity.struct.ReadLocationType;
import curam.appeal.sl.entity.struct.ReceiptNoticeDetails;
import curam.appeal.sl.entity.struct.ReceiptNoticeDetailsList;
import curam.appeal.sl.entity.struct.ReceiptNoticeKey;
import curam.appeal.sl.entity.struct.RejectAppealCaseNoticeData;
import curam.appeal.sl.entity.struct.RelatedID;
import curam.appeal.sl.fact.AppealCommunicationFactory;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.AppealableCaseTypeAppealProcessFactory;
import curam.appeal.sl.fact.AppellantFactory;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.fact.ProductAppealProcessFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.IssueAppealProcess;
import curam.appeal.sl.struct.AppealCaseIDCaseID;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealCommunicationAdjournmentDetails;
import curam.appeal.sl.struct.AppealCommunicationAppealDetails;
import curam.appeal.sl.struct.AppealCommunicationAppealedCaseRejectDetails;
import curam.appeal.sl.struct.AppealCommunicationCancelReasonDetails;
import curam.appeal.sl.struct.AppealCommunicationContinueReasonDetails;
import curam.appeal.sl.struct.AppealCommunicationCourtDetails;
import curam.appeal.sl.struct.AppealCommunicationDecisionDetails;
import curam.appeal.sl.struct.AppealCommunicationFeeDetails;
import curam.appeal.sl.struct.AppealCommunicationFeeKey;
import curam.appeal.sl.struct.AppealCommunicationHomeDetails;
import curam.appeal.sl.struct.AppealCommunicationLocationDetails;
import curam.appeal.sl.struct.AppealCommunicationParticipantKey;
import curam.appeal.sl.struct.AppealCommunicationReceiptDetails;
import curam.appeal.sl.struct.AppealCommunicationReceiptWithoutContinueBenefitDetails;
import curam.appeal.sl.struct.AppealCommunicationRespondentDetails;
import curam.appeal.sl.struct.AppealCommunicationScheduleDetails;
import curam.appeal.sl.struct.AppealCommunicationStatementDetails;
import curam.appeal.sl.struct.AppealCommunicationTranscriptDetails;
import curam.appeal.sl.struct.AppealCommunicationWitnessDetails;
import curam.appeal.sl.struct.AppealCommunicationWitnessDetailsKey;
import curam.appeal.sl.struct.AppealReasonData;
import curam.appeal.sl.struct.AppealReceiptNoticeData;
import curam.appeal.sl.struct.AppealReceiptNoticeWithoutContinueBenefitData;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.AppealedCaseRejectData;
import curam.appeal.sl.struct.AppealedDecisionResolutionData;
import curam.appeal.sl.struct.AppellantHasAddedCaseIndicator;
import curam.appeal.sl.struct.CaseIDAppealCaseIDConstraintType;
import curam.appeal.sl.struct.HearingIDHearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.ListAppellantConcernRoleIDDetails;
import curam.appeal.sl.struct.ReadAppellantDetails;
import curam.appeal.sl.struct.ScheduleHearingData;
import curam.appeal.sl.struct.TemplateDataKey;
import curam.appeal.sl.struct.TimeConstraintLength;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALCANCELREASON;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALREASON;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASEREJECTIONREASON;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.CONSTRAINTTYPE;
import curam.codetable.FEEAPPROVED;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.ONBEHALFOF;
import curam.codetable.POSTPONEREASON;
import curam.codetable.RECORDSTATUS;
import curam.codetable.XSLTEMPLATETYPE;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.LocationFactory;
import curam.core.fact.MaintainXSLTemplateFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.Address;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.ConcernRole;
import curam.core.intf.Location;
import curam.core.intf.Organisation;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.ExternalPartyOfficeFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRole_eoTypeCode;
import curam.core.sl.entity.struct.ExternalPartyOfficeDtls;
import curam.core.sl.entity.struct.ExternalPartyOfficeKey;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.sl.struct.TemplateDataDetails;
import curam.core.sl.struct.WordTemplateDocumentAndDataDetails;
import curam.core.struct.AddressDataKey;
import curam.core.struct.AddressKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseRelByCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseRelationshipRelatedCaseIDKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernNameAddressDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.LocationKeyStruct;
import curam.core.struct.NameAddressReadKey;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.core.struct.OtherAddressData;
import curam.core.struct.SearchTemplatesByConcernAndTypeResult;
import curam.core.struct.SearchTemplatesKey;
import curam.core.struct.UserAddressDetailsList;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.core.struct.XSLTemplateDetails;
import curam.message.BPOAPPEALCOMMUNICATION;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.administration.struct.XSLTemplateDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.NotFoundIndicator;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.struct.XSLTemplateTypeKey;
import java.util.Map;

/**
 * This process class provides the functionality for the Appeal Communication
 * service layer.
 *
 */
public abstract class AppealCommunication
  extends curam.appeal.sl.base.AppealCommunication {

  protected final String kDelimiter = GeneralAppealConstants.kDelimiter;

  // Constant for the organization key
  protected final int kOrganisationID =
    GeneralAppealConstants.kOrganisationID;

  // Constants for decision document template field elements
  protected final String kOrganizationName =
    GeneralAppealConstants.kOrganizationName;

  protected final String kDecisionDate = GeneralAppealConstants.kDecisionDate;

  protected final String kAppealCaseReference =
    GeneralAppealConstants.kAppealCaseReference;

  protected final String kOrganizationAddress =
    GeneralAppealConstants.kOrganizationAddress;

  protected final String kAppellantName =
    GeneralAppealConstants.kAppellantName;

  protected final String kAppellantAddress =
    GeneralAppealConstants.kAppellantAddress;

  protected final String kHearingReference =
    GeneralAppealConstants.kHearingReference;

  protected final String kHearingDate = GeneralAppealConstants.kHearingDate;

  protected final String kHearingOfficials =
    GeneralAppealConstants.kHearingOfficials;

  protected final String kOverallDecision =
    GeneralAppealConstants.kOverallDecision;

  protected final String kIssueAndResolutionList =
    GeneralAppealConstants.kIssueAndResolutionList;

  protected final String kUserName = GeneralAppealConstants.kUserName;

  @Inject
  private Map<CASETYPECODEEntry, AppealableCaseType> appealableCaseTypeMap;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  public AppealCommunication() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details about an appeal for a specified case participant.
   *
   * @param key Unique internal reference number for the participant
   *
   * @return The appeal details for the specified participant
   */
  @Override
  public AppealCommunicationAppealDetails
    getAppealDetails(final AppealCommunicationParticipantKey key)
      throws AppException, InformationalException {

    // Appeal details object
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      new AppealCommunicationAppealDetails();

    // Organization objects
    final Organisation organisationObj = OrganisationFactory.newInstance();
    final OrganisationKey organisationKey = new OrganisationKey();
    OrganisationNameAndAddressDetails organisationNameAndAddressDetails;

    // Address objects
    final Address addressObj = AddressFactory.newInstance();
    final OtherAddressData otherAddressData_appellant =
      new OtherAddressData();
    final OtherAddressData otherAddressData_organization =
      new OtherAddressData();

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails =
      new CaseIDCaseRefAndParticipantRoleIDDetails();

    // ConcernRole objects
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final NameAddressReadKey nameAddressReadKey = new NameAddressReadKey();
    ConcernNameAddressDetails concernNameAddressDetails =
      new ConcernNameAddressDetails();

    // Appeal service layer objects
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

    // Users objects
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UserFullname userFullname;

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingIDRefLocationAddressDetails hearingIDRefLocationAddressDetails;

    // Appeal entity objects
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealReasonCodeDetailsList appealReasonCodeDetailsList;
    final AppealCaseID appealCaseID = new AppealCaseID();

    // Read organization name and address
    organisationKey.organisationID = kOrganisationID;
    organisationNameAndAddressDetails =
      organisationObj.readNameAndAddress(organisationKey);

    // Convert organization address to strings
    otherAddressData_organization.addressData =
      organisationNameAndAddressDetails.addressData;
    addressObj.getAddressStrings(otherAddressData_organization);

    // Set organization name and address
    appealCommunicationAppealDetails.organizationAddress =
      otherAddressData_appellant.addressData;
    appealCommunicationAppealDetails.organizationName =
      organisationNameAndAddressDetails.name;

    // Get case and participant details
    caseParticipantRole_eoKey.caseParticipantRoleID =
      key.caseParticipantRoleID;
    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRole_eoObj
      .readCaseIDCaseRefAndParticipantRoleID(caseParticipantRole_eoKey);

    // Set case reference and case ID
    appealCommunicationAppealDetails.caseReference =
      caseIDCaseRefAndParticipantRoleIDDetails.caseReference;
    appealCommunicationAppealDetails.appealCaseID =
      caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    // Read correspondent address
    nameAddressReadKey.concernRoleID =
      caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;
    concernNameAddressDetails =
      concernRoleObj.readNameAndAddress(nameAddressReadKey);

    // Convert correspondent address to strings
    otherAddressData_appellant.addressData =
      concernNameAddressDetails.addressData;
    addressObj.getAddressStrings(otherAddressData_appellant);

    // Set correspondent name and address
    appealCommunicationAppealDetails.correspondentAddress =
      otherAddressData_appellant.addressData;
    appealCommunicationAppealDetails.correspondentName =
      concernNameAddressDetails.fullName;

    // Get appellant details
    appealCaseKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    // BEGIN, CR00177498, PM
    readAppellantDetails = readAppellantDetails(appealCaseKey);
    // END, CR00177498

    if (readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID != 0) {

      // Read appellant address
      nameAddressReadKey.concernRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID;
      concernNameAddressDetails =
        concernRoleObj.readNameAndAddress(nameAddressReadKey);

      // Convert appellant address to strings
      otherAddressData_appellant.addressData =
        concernNameAddressDetails.addressData;
      addressObj.getAddressStrings(otherAddressData_appellant);

      // Set appellant details
      appealCommunicationAppealDetails.appellantAddress =
        otherAddressData_appellant.addressData;
      appealCommunicationAppealDetails.appellantCaseParticipantRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;
      appealCommunicationAppealDetails.appellantName =
        readAppellantDetails.concernRoleNameDetails.concernRoleName;
      appealCommunicationAppealDetails.appellantParticipantRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID;
    }

    // Get current user full name
    usersKey.userName = TransactionInfo.getProgramUser();
    userFullname = usersObj.getFullName(usersKey);

    // Set current user full name
    appealCommunicationAppealDetails.userFullName = userFullname.fullname;

    // Get latest hearing details - may not be any yet

    // Check for the latest scheduled hearing
    caseAndStatusKey.statusCode = curam.codetable.HEARINGSTATUS.SCHEDULED;
    caseAndStatusKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;

    try {
      hearingIDRefLocationAddressDetails =
        hearingObj.readLatestHearingIDRefLocationAddressByCaseAndStatus(
          caseAndStatusKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {

      hearingIDRefLocationAddressDetails = null;

    }

    if (hearingIDRefLocationAddressDetails != null) {
      // Set hearing details
      appealCommunicationAppealDetails.hearingAddressID =
        hearingIDRefLocationAddressDetails.addressID;
      appealCommunicationAppealDetails.hearingID =
        hearingIDRefLocationAddressDetails.hearingID;
      appealCommunicationAppealDetails.hearingReference =
        hearingIDRefLocationAddressDetails.hearingReference;
      appealCommunicationAppealDetails.hearingLocationID =
        hearingIDRefLocationAddressDetails.locationID;
    }

    // Get appeal reason
    appealCaseIDKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    // Set the AppealRelationship appealCaseID to be Appeal.caseID
    appealCaseID.appealCaseID = appealCaseIDKey.caseID;
    appealReasonCodeDetailsList =
      appealRelationshipObj.searchReasonByAppealCase(appealCaseID);

    if (!appealReasonCodeDetailsList.dtls.isEmpty()) {

      for (int i = 0; i < appealReasonCodeDetailsList.dtls.size(); i++) {

        final AppealReasonData appealReasonData = new AppealReasonData();

        // Convert appeal reason code to description
        appealReasonData.appealReasonCode = curam.util.type.CodeTable
          .getOneItem(curam.codetable.APPEALREASON.TABLENAME,
            appealReasonCodeDetailsList.dtls.item(i).reasonCode);

        appealCommunicationAppealDetails.appealReasonData
          .addRef(appealReasonData);
      }

    } // START CR00132747 LP
    else {
      // Legal Actions don't have a reason specified. So it to to Dash
      final AppealReasonData appealReasonData = new AppealReasonData();

      appealReasonData.appealReasonCode = CuramConst.gkDash;
      appealCommunicationAppealDetails.appealReasonData
        .addRef(appealReasonData);
    }
    // END CR00132747 LP
    // END, 36447, DB

    // Get issue date
    // Format date
    appealCommunicationAppealDetails.issueDate =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        curam.util.type.DateTime.getCurrentDateTime(),
        TransactionInfo.getUserTimeZone()).toString();

    // Return appeal details
    return appealCommunicationAppealDetails;

  }

  // BEGIN, CR00177498, PM
  /**
   * This method returns the appellant details
   *
   * @param key
   * The key of the appeal
   *
   * @return The appellant details
   */
  protected ReadAppellantDetails readAppellantDetails(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return details
    final ReadAppellantDetails readAppellantDetails =
      new ReadAppellantDetails();

    final StringBuffer appellantName = new StringBuffer();

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    // ConcernRole object
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the key
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // Get the active participant for the case
    caseParticipantRoleIDDetailsList = caseParticipantRole_eoObj
      .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Display a Multiple appellant link if appellant are more than 1.
    if (caseParticipantRoleIDDetailsList.dtls.size() > 0) {

      for (final CaseParticipantRoleIDDetails caseParticipantRoleIDDetails : caseParticipantRoleIDDetailsList.dtls
        .items()) {

        readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID =
          caseParticipantRoleIDDetails.caseParticipantRoleID;
        readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID =
          caseParticipantRoleIDDetails.participantRoleID;
        readAppellantDetails.caseParticipantRoleIDDetails.recordStatus =
          caseParticipantRoleIDDetails.recordStatus;

        concernRoleKey.concernRoleID =
          caseParticipantRoleIDDetails.participantRoleID;
        appellantName.append(
          concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName);

        appellantName.append(GeneralAppealConstants.kDelimiter);

        // Assign the name
        readAppellantDetails.concernRoleNameDetails.concernRoleName =
          appellantName.toString();
      }
    }

    // Return the appellant details
    return readAppellantDetails;
  }

  // END, CR00177498

  // ___________________________________________________________________________
  /**
   * Retrieves the specified address details.
   *
   * @param key Unique internal reference number for the address
   *
   * @return The address details
   */
  @Override
  public AppealCommunicationHomeDetails getHomeDetails(
    final AddressDataKey key) throws AppException, InformationalException {

    // Address objects
    final Address addressObj = AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    OtherAddressData otherAddressData = new OtherAddressData();

    // Home details
    final AppealCommunicationHomeDetails appealCommunicationHomeDetails =
      new AppealCommunicationHomeDetails();

    // Read address data
    addressKey.addressID = key.addressID;
    otherAddressData = addressObj.readAddressData(addressKey);

    // Convert address to strings
    addressObj.getAddressStrings(otherAddressData);

    // Set address details
    appealCommunicationHomeDetails.hearingAddress =
      otherAddressData.addressData;

    // Return home details
    return appealCommunicationHomeDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the address details for the specified location
   *
   * @param key Unique internal reference number for the location
   *
   * @return The location address
   */
  @Override
  public AppealCommunicationLocationDetails getLocationDetails(
    final LocationKeyStruct key) throws AppException, InformationalException {

    // Address objects
    final Address addressObj = AddressFactory.newInstance();
    final OtherAddressData otherAddressData = new OtherAddressData();

    // Location objects
    final Location locationObj = LocationFactory.newInstance();
    UserAddressDetailsList userAddressDetailsList;

    // Home details
    final AppealCommunicationLocationDetails appealCommunicationLocationDetails =
      new AppealCommunicationLocationDetails();

    // Read location address
    userAddressDetailsList = locationObj.searchLocationAddress(key);

    // Convert address to strings
    otherAddressData.addressData =
      userAddressDetailsList.dtls.item(0).addressData;
    addressObj.getAddressStrings(otherAddressData);

    // Set address details
    appealCommunicationLocationDetails.locationAddress =
      otherAddressData.addressData;

    // Return location details
    return appealCommunicationLocationDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the schedule details for the specified appeal case
   *
   * @param key Unique internal reference number for the appeal case
   *
   * @return Schedule details for the case
   */
  @Override
  public AppealCommunicationScheduleDetails getScheduleDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseIDScheduled caseIDScheduled = new CaseIDScheduled();
    HearingScheduleNoticeDetails hearingScheduleNoticeDetails =
      new HearingScheduleNoticeDetails();

    // Schedule details
    final AppealCommunicationScheduleDetails appealCommunicationScheduleDetails =
      new AppealCommunicationScheduleDetails();

    // Appeal entity objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // Read hearing details
    caseIDScheduled.caseID = key.caseID;

    // BEGIN, CR00131191, RKi
    try {
      hearingScheduleNoticeDetails =
        hearingObj.readLatestScheduleNoticeDetailsByCase(caseIDScheduled);
    } catch (final RecordNotFoundException re) {// there are no scheduled
                                                // hearings for this case.
    }
    // END, CR00131191
    // Set received date
    // Format date
    appealCommunicationScheduleDetails.receivedDate =
      hearingScheduleNoticeDetails.receivedDate.toString();

    // Set date string
    appealCommunicationScheduleDetails.scheduledDate =
      hearingScheduleNoticeDetails.scheduledDateTime.toString();

    // Set continue benefits string
    if (hearingScheduleNoticeDetails.continueBenefitsInd == true) {

      final AppException continueString = new AppException(
        curam.message.BPOAPPEALCOMMUNICATION.INF_CONTINUE_IS);

      appealCommunicationScheduleDetails.continueBenefitsString =
        continueString.getMessage();

    } else {

      final AppException continueString = new AppException(
        curam.message.BPOAPPEALCOMMUNICATION.INF_CONTINUE_IS_NOT);

      appealCommunicationScheduleDetails.continueBenefitsString =
        continueString.getMessage();

    }

    // Read appeal type
    appealCaseIDKey.caseID = key.caseID;

    // BEGIN , CR00302241 CR00302531, DK
    // read the appealID type to check if it is an appeal or a legal action
    final CaseKey appealCaseKey = new CaseKey();

    appealCaseKey.caseID = key.caseID;
    final CaseTypeCode appealCaseType =
      CaseHeaderFactory.newInstance().readCaseTypeCode(appealCaseKey);

    // Get case relationship id
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    long caseID = 0;

    if (appealCaseType.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      final CaseRelationshipCaseIDKey relationshipCaseIDKey =
        new CaseRelationshipCaseIDKey();

      relationshipCaseIDKey.caseID = key.caseID;
      CaseRelationshipDtlsList caseRelationshipDtlsListObj;

      caseRelationshipDtlsListObj =
        caseRelationshipObj.searchByCaseID(relationshipCaseIDKey);
      if (caseRelationshipDtlsListObj.dtls.size() > 0) {
        caseID = caseRelationshipDtlsListObj.dtls.item(0).relatedCaseID;
      }
    } else {
      final CaseRelationshipRelatedCaseIDKey existingRelationSearchKey =
        new CaseRelationshipRelatedCaseIDKey();

      existingRelationSearchKey.relatedCaseID = key.caseID;
      CaseRelationshipDtlsList caseRelationshipDtlsListObj;

      caseRelationshipDtlsListObj =
        caseRelationshipObj.searchByRelatedCaseID(existingRelationSearchKey);
      if (caseRelationshipDtlsListObj.dtls.size() > 0) {
        caseID = caseRelationshipDtlsListObj.dtls.item(0).caseID;
      }
    }
    // END , CR00302241 CR00302531, DK
    // Get reopen time limit for hearing cases
    // Begin CR00117296 LP
    final NotFoundIndicator notfoundIndicator = new NotFoundIndicator();

    appealTypeDetails =
      appealObj.readAppealTypeByCase(notfoundIndicator, appealCaseIDKey);
    // BEGIN, CR00284786, DG
    String constraintType = new String();

    if (!notfoundIndicator.isNotFound() && appealTypeDetails.appealTypeCode
      .equals(curam.codetable.APPEALTYPE.HEARING)) {
      // End CR00117296 LP
      constraintType = curam.codetable.CONSTRAINTTYPE.REOPEN_HEARING_CASE;

      // Get the time constraint
      final CaseIDAppealCaseIDConstraintType details =
        new CaseIDAppealCaseIDConstraintType();

      details.appealCaseID = key.caseID;
      details.caseID = caseID;
      details.constraintType = constraintType;
      final TimeConstraintLength timeConstraintLength =
        AppealFactory.newInstance().getTimeConstraintLength(details);

      appealCommunicationScheduleDetails.appealTimeLimit =
        timeConstraintLength.numberOfDays;

      if (timeConstraintLength.numberOfDays == 0) {
        // Required constraint does not exist - throw exception
        final AppException ex = new AppException(
          curam.message.BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        ex.arg(curam.util.type.CodeTable.getOneItem(
          curam.codetable.CONSTRAINTTYPE.TABLENAME,
          curam.codetable.CONSTRAINTTYPE.REOPEN_HEARING_CASE));
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(ex,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            6);
      }

    }

    // Return schedule details
    return appealCommunicationScheduleDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details for an appeal schedule notice
   *
   * @param key Unique internal reference numbers for the correspondent
   *
   * @return Details for the notice
   */
  @Override
  public ScheduleHearingData
    getScheduleNoticeDetails(final AppealCommunicationParticipantKey key)
      throws AppException, InformationalException {

    // Schedule notice object
    final ScheduleHearingData scheduleHearingData = new ScheduleHearingData();

    // Appeal objects
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Schedule objects
    AppealCommunicationScheduleDetails appealCommunicationScheduleDetails;
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Location objects
    AppealCommunicationLocationDetails appealCommunicationLocationDetails;
    final LocationKeyStruct locationKeyStruct = new LocationKeyStruct();

    // Home objects
    AppealCommunicationHomeDetails appealCommunicationHomeDetails;
    final AddressDataKey addressDataKey = new AddressDataKey();

    // Witness objects
    AppealCommunicationWitnessDetails appealCommunicationWitnessDetails;
    final AppealCommunicationWitnessDetailsKey appealCommunicationWitnessDetailsKey =
      new AppealCommunicationWitnessDetailsKey();

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoTypeCode caseParticipantRoleTypeCode;

    // Appellant variables
    AppellantHasAddedCaseIndicator hasAddedCaseIndicator;
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();
    final CaseParticipantRole_boKey caseParticipantRoleKey =
      new CaseParticipantRole_boKey();

    // Get appeal details
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.caseParticipantRoleID;
    appealCommunicationAppealDetails =
      getAppealDetails(appealCommunicationParticipantKey);

    // Set appeal details
    scheduleHearingData.assign(appealCommunicationAppealDetails);

    // Get schedule details
    appealCaseKey.caseID = appealCommunicationAppealDetails.appealCaseID;
    appealCommunicationScheduleDetails = getScheduleDetails(appealCaseKey);

    // if appellant doesn't have added case, appellant's benefits info
    // should not be displayed
    caseParticipantRoleKey.caseParticipantRoleID =
      appealCommunicationParticipantKey.caseParticipantRoleID;

    hasAddedCaseIndicator =
      appellant.appellantHasAddedCase(caseParticipantRoleKey);
    if (!hasAddedCaseIndicator.hasAddedCase) {
      appealCommunicationScheduleDetails.continueBenefitsString = "";
    }

    // Set schedule details
    scheduleHearingData.assign(appealCommunicationScheduleDetails);

    // Check for location
    if (appealCommunicationAppealDetails.hearingLocationID != 0) {

      // Get location details
      locationKeyStruct.locationID =
        appealCommunicationAppealDetails.hearingLocationID;
      appealCommunicationLocationDetails =
        getLocationDetails(locationKeyStruct);

      // Set location details
      scheduleHearingData.assign(appealCommunicationLocationDetails);

    } else if (appealCommunicationAppealDetails.hearingAddressID != 0) {

      // Get home details
      addressDataKey.addressID =
        appealCommunicationAppealDetails.hearingAddressID;
      appealCommunicationHomeDetails = getHomeDetails(addressDataKey);

      // Set home details
      scheduleHearingData.assign(appealCommunicationHomeDetails);

    } // START CR00132747 LP
    else {
      final curam.appeal.sl.entity.struct.HearingKey hearingKey =
        new curam.appeal.sl.entity.struct.HearingKey();

      hearingKey.hearingID = appealCommunicationAppealDetails.hearingID;
      final HearingDtls hearingDtls =
        HearingFactory.newInstance().read(hearingKey);
      OtherAddressData otherAddressData;

      if (hearingDtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
        final ExternalPartyOfficeKey externalPartyOfficeKey =
          new ExternalPartyOfficeKey();

        externalPartyOfficeKey.externalPartyOfficeID =
          hearingDtls.externalOfficeID;
        final AddressKey addressKey = new AddressKey();
        final ExternalPartyOfficeDtls externalPartyOfficeDtls =
          ExternalPartyOfficeFactory.newInstance()
            .read(externalPartyOfficeKey);

        addressKey.addressID = externalPartyOfficeDtls.primaryAddressID;
        otherAddressData =
          AddressFactory.newInstance().readAddressData(addressKey);
        AddressFactory.newInstance().getAddressStrings(otherAddressData);
        // BEGIN, CR00123104, RKi
        scheduleHearingData.locationAddress = otherAddressData.addressData;
        // END, CR00123104
      }
    }
    // END CR00132747

    // Read correspondent type
    caseParticipantRole_eoKey.caseParticipantRoleID =
      key.caseParticipantRoleID;
    caseParticipantRoleTypeCode =
      caseParticipantRole_eoObj.readTypeCode(caseParticipantRole_eoKey);

    // Check for witness
    if (caseParticipantRoleTypeCode.typeCode
      .equals(curam.codetable.CASEPARTICIPANTROLETYPE.HEARINGWITNESS)) {

      // Get witness details
      appealCommunicationWitnessDetailsKey.caseID =
        appealCommunicationAppealDetails.appealCaseID;
      appealCommunicationWitnessDetailsKey.caseParticipantRoleID =
        key.caseParticipantRoleID;
      appealCommunicationWitnessDetailsKey.hearingID =
        appealCommunicationAppealDetails.hearingID;
      appealCommunicationWitnessDetails =
        getWitnessDetails(appealCommunicationWitnessDetailsKey);

      // Set witness details
      scheduleHearingData.assign(appealCommunicationWitnessDetails);

      // if more than one appellant then don't add the appellants name
      // read appellants
      ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
        new ListAppellantConcernRoleIDDetails();

      listAppellantConcernRoleIDDetails =
        appellant.getAppellantDetails(appealCaseKey);

      if (listAppellantConcernRoleIDDetails.listDtls.dtls.size() > 1) {
        appealCommunicationAppealDetails.appellantName = "";
        appealCommunicationAppealDetails.appellantAddress = "";

      }

    }

    // Return schedule notice details
    return scheduleHearingData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details for the specified witness
   *
   * @param key Unique internal reference numbers for the witness, appeal case
   * and hearing
   *
   * @return Details of the witness
   */
  @Override
  public AppealCommunicationWitnessDetails
    getWitnessDetails(final AppealCommunicationWitnessDetailsKey key)
      throws AppException, InformationalException {

    // BEGIN CR00125303 LP
    final RelatedID relatedID = new RelatedID();

    relatedID.relatedID = key.caseParticipantRoleID;
    final CaseParticipantRoleLinkDetailsList caseParticipantRoleLinkDetailsList =
      CaseParticipantRoleLinkFactory.newInstance()
        .readParticipantDetailsByRelatedID(relatedID);
    final StringBuffer nameString = new StringBuffer();

    for (int i = 0; i < caseParticipantRoleLinkDetailsList.dtls.size(); i++) {
      nameString.append(caseParticipantRoleLinkDetailsList.dtls.item(i).name);
      nameString.append(CuramConst.gkComma);
    }
    if (nameString.length() > 0) {
      nameString.setLength(nameString.length() - 1);
    }

    final AppealCommunicationWitnessDetails appealCommunicationWitnessDetails =
      new AppealCommunicationWitnessDetails();

    appealCommunicationWitnessDetails.behalfOfName = nameString.toString();

    // Return witness details
    return appealCommunicationWitnessDetails;
    // End CR00125303 LP
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a request receipt notice for an appeal.
   *
   * @param key Contains the appeal case ID
   *
   * @return the receipt details
   */
  @Override
  public AppealCommunicationReceiptDetails getReceiptDetails(
    final AppealCaseIDKey key) throws AppException, InformationalException {

    // AppealRelationship object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // Return struct
    final AppealCommunicationReceiptDetails appealCommunicationReceiptDetails =
      new AppealCommunicationReceiptDetails();

    // Get list of ReceiptNoticeDetails
    final ReceiptNoticeKey receiptNoticeKey = new ReceiptNoticeKey();

    receiptNoticeKey.appealCaseID = key.caseID;
    final ReceiptNoticeDetailsList receiptNoticeDetailsList =
      appealRelationshipObj
        .searchOutstandingReceiptNoticeDetailsByAppealCase(receiptNoticeKey);

    // Appeal receipt notice data variable
    AppealReceiptNoticeData appealReceiptNoticeData;

    for (int i = 0; i < receiptNoticeDetailsList.dtls.size(); i++) {

      appealReceiptNoticeData = new AppealReceiptNoticeData();

      // Format the received effective date
      // Set date string
      appealReceiptNoticeData.effectiveDate =
        receiptNoticeDetailsList.dtls.item(i).appealedDecisionDate.toString();

      // Format the received date
      // Set date string
      appealReceiptNoticeData.receivedDate =
        receiptNoticeDetailsList.dtls.item(i).receivedDate.toString();

      // Set continue benefits string
      if (receiptNoticeDetailsList.dtls.item(i).continueBenefitsIndicator) {

        appealReceiptNoticeData.continueBenefitsString =
          BPOAPPEALCOMMUNICATION.INF_CONTINUE_YES.getMessageText();

      } else {

        appealReceiptNoticeData.continueBenefitsString =
          BPOAPPEALCOMMUNICATION.INF_CONTINUE_NO.getMessageText();

      }

      // Convert appealed case reason code to description
      appealReceiptNoticeData.reasonCode = curam.util.type.CodeTable
        .getOneItem(curam.codetable.APPEALREASON.TABLENAME,
          receiptNoticeDetailsList.dtls.item(i).reasonCode);

      // Add to receipt notice data list
      appealCommunicationReceiptDetails.appealReceiptNoticeData
        .addRef(appealReceiptNoticeData);

    }

    return appealCommunicationReceiptDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a cancellation notice for an appeal.
   *
   * @param key Contains the appeal case id
   *
   * @return the cancellation details
   */
  @Override
  public AppealCommunicationCancelReasonDetails getCancellationDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    final AppealCommunicationCancelReasonDetails appealCommunicationCancelReasonDetails =
      new AppealCommunicationCancelReasonDetails();

    final AppealCancellation appealCancellationObj =
      AppealCancellationFactory.newInstance();

    final ReadCancelledCaseKey readCancelledCaseKey =
      new ReadCancelledCaseKey();

    readCancelledCaseKey.caseID = key.caseID;

    final AppealCancelReasonCode appealCancelReasonCode =
      appealCancellationObj
        .readLatestCancelReasonCodeByCase(readCancelledCaseKey);

    // Convert appeal reason code to description
    appealCommunicationCancelReasonDetails.cancelReasonCode =
      CodeTable.getOneItem(APPEALCANCELREASON.TABLENAME,
        appealCancelReasonCode.cancelReasonCode);

    return appealCommunicationCancelReasonDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a continuance notice for an appeal.
   *
   * @param key contains the hearing id and appeal case id
   *
   * @return The continuance details
   */
  @Override
  public AppealCommunicationContinueReasonDetails
    getContinuanceDetails(final HearingIDHearingCaseID key)
      throws AppException, InformationalException {

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // HearingUserRole object
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();

    // Set the Key objects
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    HearingCaseUserNameDtlsList hearingCaseUserNameDtlsList =
      new HearingCaseUserNameDtlsList();

    hearingKey.hearingID = key.hearingID;

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.hearingCaseID;

    // get the continuance data
    final AppealContinueDetails appealContinueDetails =
      hearingObj.readContinaunceDetails(hearingKey);

    final AppealCommunicationContinueReasonDetails appealCommunicationContinueReasonDetails =
      new AppealCommunicationContinueReasonDetails();

    // copy into details struct
    // Format postpone date
    // Set date string
    appealCommunicationContinueReasonDetails.continuanceDate =
      appealContinueDetails.postponeDate.toString();

    // Set date string
    appealCommunicationContinueReasonDetails.scheduledDate =
      appealContinueDetails.scheduledDateTime.toString();

    appealCommunicationContinueReasonDetails.continuanceReasonText =
      appealContinueDetails.postponeReasonText;
    appealCommunicationContinueReasonDetails.continuanceReasonCode =
      CodeTable.getOneItem(POSTPONEREASON.TABLENAME,
        appealContinueDetails.postponeReasonCode);
    // BEGIN CR00125303 LP
    // type to search on
    String typeCode;
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = appealCaseIDKey.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    } else {
      // Get the name of the official/reviewer
      final AppealTypeDetails appealTypeDetails =
        appealObj.readAppealTypeByCase(appealCaseIDKey);

      if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

      } else {

        typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

      }
    }
    // END CR00125303 LP
    // BEGIN, CR00122980, RKi
    final ReadLocationType locationType =
      hearingObj.readLocationTypeByHearingID(hearingKey);

    if (locationType.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      final HearingIDCaseParticipantRoleTypeKey caseParticipantRoleTypeKey =
        new HearingIDCaseParticipantRoleTypeKey();

      caseParticipantRoleTypeKey.hearingID = key.hearingID;
      caseParticipantRoleTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      final ConcernRoleNameDetails concernRoleNameDetails = hearingObj
        .readOfficialNameByHearingIDTypeCode(caseParticipantRoleTypeKey);

      appealCommunicationContinueReasonDetails.hearingUserName =
        concernRoleNameDetails.concernRoleName;
    } else {
      // END, CR00122980
      // get the name of
      final HearingUserRoleStatusKey hearingUserRoleStatusKey =
        new HearingUserRoleStatusKey();

      hearingUserRoleStatusKey.hearingID = key.hearingID;
      hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.DEFAULTCODE;
      hearingUserRoleStatusKey.typeCode = typeCode;

      hearingCaseUserNameDtlsList = hearingUserRoleObj
        .searchActiveUserNameByHearingIDAndType(hearingUserRoleStatusKey);

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        hearingCaseUserNameDtlsList.dtls.item(0).orgObjectLinkID;
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      // END, CR00053295

      // Use name of first returned.
      appealCommunicationContinueReasonDetails.hearingUserName =
        caseOwnerDetails.userName;
    }

    return appealCommunicationContinueReasonDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details about the court date and hearing reference for an appeal
   * case.
   *
   * @param key Unique internal reference number for the appeal case
   *
   * @return The court date and hearing reference details for the specified
   * case.
   */
  @Override
  public AppealCommunicationCourtDetails getCourtDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // AppealRelationship object and structs
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealedDecisionDate appealedDecisionDate;
    final AppealCaseStatusDetails appealCaseStatusDetails =
      new AppealCaseStatusDetails();

    // Case Relationship manipulation variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
      new CaseRelByCaseIDStatusReasonTypeKey();
    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingIDRefLocationAddressDetails hearingIDRefLocationAddressDetails;

    // Return details
    final AppealCommunicationCourtDetails appealCommunicationCourtDetails =
      new AppealCommunicationCourtDetails();

    final curam.appeal.sl.entity.struct.CaseAndStatusKey caseAndStatusKey =
      new curam.appeal.sl.entity.struct.CaseAndStatusKey();

    // Read respondent data
    appealCaseStatusDetails.appealCaseID = key.caseID;
    appealedDecisionDate = appealRelationshipObj
      .readActiveAppealDecisionDate(appealCaseStatusDetails);

    // Read related case ID for this judicial review
    caseRelByCaseIDStatusReasonTypeKey.caseID = key.caseID;
    caseRelByCaseIDStatusReasonTypeKey.reasonCode =
      curam.codetable.CASERELATIONSHIPREASONCODE.LINKEDCASES;
    caseRelByCaseIDStatusReasonTypeKey.statusCode =
      curam.codetable.RECORDSTATUS.NORMAL;
    caseRelByCaseIDStatusReasonTypeKey.typeCode =
      curam.codetable.CASERELATIONSHIPTYPECODE.APPEALAPPEAL;

    caseRelationshipDtlsList = caseRelationshipObj
      .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

    // Read latest hearing reference for related case ID

    if (caseRelationshipDtlsList.dtls.size() != 0) {

      caseAndStatusKey.caseID =
        caseRelationshipDtlsList.dtls.item(0).relatedCaseID;
      caseAndStatusKey.statusCode = curam.codetable.HEARINGSTATUS.COMPLETED;

      hearingIDRefLocationAddressDetails =
        hearingObj.readLatestHearingIDRefLocationAddressByCaseAndStatus(
          caseAndStatusKey);
      appealCommunicationCourtDetails.hearingReference =
        hearingIDRefLocationAddressDetails.hearingReference;

      appealCommunicationCourtDetails.priorHearingReference =
        hearingIDRefLocationAddressDetails.hearingReference;

    }

    // Set return details
    // Format date
    appealCommunicationCourtDetails.appealedDecisionDate =
      appealedDecisionDate.decisionDate.toString();

    // appealCommunicationCourtDetails.priorHearingReference =
    // hearingIDRefLocationAddressDetails.hearingReference;

    return appealCommunicationCourtDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details for the specified decision
   *
   * @param key Unique internal reference numbers for the hearing and appeal
   * case
   *
   * @return Details of the decision
   */
  @Override
  public AppealCommunicationDecisionDetails getDecisionDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Hearing decision variables
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionResolutionCodeDetails hearingDecisionResolutionCodeDetails;
    String decisionCode;

    // Appeal variables
    final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // Appeal communication variables
    final AppealCommunicationDecisionDetails appealCommunicationDecisionDetails =
      new AppealCommunicationDecisionDetails();

    // Appeal Decision Resolution variable
    AppealedDecisionResolutionData appealedDecisionResolutionData;

    // Hearing user role variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    HearingCaseUserNameDtlsList hearingCaseUserNameDtlsList;
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingIDRefLocationAddressDetails hearingIDRefLocationAddressDetails;

    // AppealRelationShip variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    AppealedCaseResolutionDetailsList appealedCaseResolutionDetailsList;
    AppealedCaseResolutionDetails appealedCaseResolutionDetails;

    // Appeal service layer variables
    final AppealCaseIDCaseID appealCaseIDCaseID = new AppealCaseIDCaseID();

    // Product Appeal Process Service Layer variables
    curam.appeal.sl.struct.AppealStageType appealStageType;

    // Issue Appeal Process Service Layer variables
    final IssueAppealProcess issueAppealProcessObj =
      IssueAppealProcessFactory.newInstance();

    // Get the decision resolution code using the appeal case id
    hearingDecisionCaseKey.caseID = key.caseID;
    hearingDecisionResolutionCodeDetails =
      hearingDecisionObj.readResolutionCodeByCase(hearingDecisionCaseKey);

    appealCaseIDKey.caseID = key.caseID;
    appealTypeDetails = appealEntityObj.readAppealTypeByCase(appealCaseIDKey);

    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

    } else if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

    }

    caseAndStatusKey.caseID = key.caseID;
    caseAndStatusKey.statusCode = curam.codetable.HEARINGSTATUS.COMPLETED;

    // Only Check for hearing details if appeal type is not a Judicial Review
    if (!appealTypeDetails.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      hearingIDRefLocationAddressDetails =
        hearingObj.readLatestHearingIDRefLocationAddressByCaseAndStatus(
          caseAndStatusKey);
      appealCommunicationDecisionDetails.hearingReference =
        hearingIDRefLocationAddressDetails.hearingReference;

      // Search for user name using the hearing ID and the appeal type, this
      // will
      // be hearing reviewer of hearing official. If the hearing official is
      // an external party the official is read from the Concern Role entity.
      // BEGIN, CR00123228, RKi
      // Hearing Key
      final curam.appeal.sl.entity.struct.HearingKey hearingKey =
        new curam.appeal.sl.entity.struct.HearingKey();
      // struct which hold case participant role, type and hearing id
      final HearingIDCaseParticipantRoleTypeKey caseParticipantRoleTypeKey =
        new HearingIDCaseParticipantRoleTypeKey();

      hearingKey.hearingID = hearingIDRefLocationAddressDetails.hearingID;
      // reads what type of location is the hearing scheduled on
      final ReadLocationType readLocationType =
        hearingObj.readLocationTypeByHearingID(hearingKey);

      // if the location is external the official is read from concern role
      // entity
      if (readLocationType.locationType
        .equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
        caseParticipantRoleTypeKey.hearingID = hearingKey.hearingID;
        caseParticipantRoleTypeKey.typeCode =
          CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
        // read the external hearing official
        final ConcernRoleNameDetails concernRoleNameDetails = hearingObj
          .readOfficialNameByHearingIDTypeCode(caseParticipantRoleTypeKey);

        appealCommunicationDecisionDetails.hearingUserFullName =
          concernRoleNameDetails.concernRoleName;
      } else {
        // END, CR00123228
        hearingUserRoleStatusKey.hearingID =
          hearingIDRefLocationAddressDetails.hearingID;
        hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        hearingCaseUserNameDtlsList = hearingUserRoleObj
          .searchActiveUserNameByHearingIDAndType(hearingUserRoleStatusKey);

        // BEGIN, CR00053295, RKi
        final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
        CaseOwnerDetails caseOwnerDetails;

        orgObjectLinkKey.orgObjectLinkID =
          hearingCaseUserNameDtlsList.dtls.item(0).orgObjectLinkID;
        final curam.core.sl.intf.CaseUserRole caseUserRole =
          curam.core.sl.fact.CaseUserRoleFactory.newInstance();

        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        // END, CR00053295

        // Set the hearing user full name to be the full name of the FIRST
        // record returned
        appealCommunicationDecisionDetails.hearingUserFullName =
          caseOwnerDetails.userName;
      }
    }

    // Retrieve the decision resolution details for appealed cases.
    activeApprovedCaseKey.appealCaseID = key.caseID;

    appealedCaseResolutionDetailsList = appealRelationshipObj
      .searchAppealedCaseResolutionDetails(activeApprovedCaseKey);

    // Retrieve appeal resolution details for each appealed case
    for (int i = 0; i < appealedCaseResolutionDetailsList.dtls.size(); i++) {
      // BEGIN, CR00284786, DG
      String constraintType = new String();

      appealedCaseResolutionDetails =
        appealedCaseResolutionDetailsList.dtls.item(i);
      appealedDecisionResolutionData = new AppealedDecisionResolutionData();

      // Assign Resolution Details
      appealedDecisionResolutionData.appealedCaseReference =
        appealedCaseResolutionDetails.caseReference;
      appealedDecisionResolutionData.resolutionCode =
        CodeTable.getOneItem(HEARINGDECISIONRESOLUTION.TABLENAME,
          appealedCaseResolutionDetails.resolutionCode);

      appealedDecisionResolutionData.appealReasonCode = CodeTable.getOneItem(
        APPEALREASON.TABLENAME, appealedCaseResolutionDetails.reasonCode);

      // BEGIN, CR00095521, RKi
      // Case Header Objects
      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();

      // check if the parent case is an Issue case
      caseKey.caseID = appealedCaseResolutionDetails.caseID;
      CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // END, CR00095521

      // Attempt to get the time constraint
      if (isCaseTypeAppealable(appealedCaseResolutionDetails.caseID)) {
        appealCaseIDCaseID.appealCaseID = key.caseID;
        appealCaseIDCaseID.caseID = appealedCaseResolutionDetails.caseID;

        // BEGIN, CR00023186, RR

        // Set key to read CaseHeader
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = appealedCaseResolutionDetails.caseID;

        // Get the next appeal stage.
        if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
          appealStageType = ProductAppealProcessFactory.newInstance()
            .getNextAppealStage(appealCaseIDCaseID);
        } else {
          appealStageType = AppealableCaseTypeAppealProcessFactory
            .newInstance().getNextAppealStage(appealCaseIDCaseID);
        }

        if (appealStageType == null) {
          appealedDecisionResolutionData.appealTimeLimit =
            curam.message.BPOAPPEALCOMMUNICATION.INF_NO_APPEAL.toString();
        } else if (APPEALSTAGEAPPEALTYPE.HEARING
          .equals(appealStageType.appealStageType.appealStageType)) {
          constraintType = CONSTRAINTTYPE.REQUEST_HEARING_CASE;
        } else if (APPEALSTAGEAPPEALTYPE.HEARINGREVIEW
          .equals(appealStageType.appealStageType.appealStageType)) {
          constraintType = CONSTRAINTTYPE.REQUEST_HEARING_REVIEW;
        } else if (APPEALSTAGEAPPEALTYPE.JUDICIALREVIEW
          .equals(appealStageType.appealStageType.appealStageType)) {
          constraintType = CONSTRAINTTYPE.REQUEST_JUDICIAL_REVIEW;
        } else if (APPEALSTAGEAPPEALTYPE.ANY
          .equals(appealStageType.appealStageType.appealStageType)) {
          constraintType = CONSTRAINTTYPE.REQUEST_ANY_APPEAL;
        }

        // Retrieve the appeal time limit
        if (constraintType.length() != 0) {

          // CaseHeader variables
          caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

          // Get the case type
          caseKey.caseID = appealedCaseResolutionDetails.caseID;
          caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
          long caseID = 0;

          // Check if the case is an Appeal, get the product delivery ID
          if (caseTypeCode.caseTypeCode
            .equals(curam.codetable.CASETYPECODE.APPEAL)) {

            final CaseRelationshipRelatedCaseIDKey caseRelationshipRelatedCaseIDKey =
              new CaseRelationshipRelatedCaseIDKey();
            CaseRelationshipDtlsList caseRelationshipDtlsList;
            // CaseRelationship variables
            final CaseRelationship caseRelationshipObj =
              CaseRelationshipFactory.newInstance();

            caseRelationshipRelatedCaseIDKey.relatedCaseID =
              appealedCaseResolutionDetails.caseID;

            // Get the product delivery for the appeal case
            caseRelationshipDtlsList = caseRelationshipObj
              .searchByRelatedCaseID(caseRelationshipRelatedCaseIDKey);

            // If exactly one product delivery then use related case ID
            if (caseRelationshipDtlsList.dtls.size() > 0) {

              caseID = caseRelationshipDtlsList.dtls.item(0).caseID;

            } else {

              caseID = appealedCaseResolutionDetails.caseID;
            }
          } else {

            caseID = appealedCaseResolutionDetails.caseID;
          }

          // Get the time constraint
          final CaseIDAppealCaseIDConstraintType details =
            new CaseIDAppealCaseIDConstraintType();

          details.appealCaseID = key.caseID;
          details.caseID = caseID;
          details.constraintType = constraintType;
          final TimeConstraintLength timeConstraintLength =
            AppealFactory.newInstance().getTimeConstraintLength(details);

          if (timeConstraintLength.numberOfDays == 0) {
            final CodeTableItemIdentifier constraintTypeCode =
              new CodeTableItemIdentifier(CONSTRAINTTYPE.TABLENAME,
                constraintType);
            final AppException ex =
              new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

            ex.arg(constraintTypeCode);
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(ex,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                7);
          }
          // END, CR00284786
        }

      } else {

        // Standalone case with no associated product then use the default
        // environment variable
        final Integer appealTimeLimit = curam.util.resources.Configuration
          .getIntProperty(EnvVars.ENV_APPEAL_TIMELIMIT_FOR_STANDALONECASE);

        // Use default value if the variable is not set
        if (appealTimeLimit == null) { // BEGIN, CR00097244, RKi
          appealedDecisionResolutionData.appealTimeLimit =
            "" + EnvVars.ENV_APPEAL_TIMELIMIT_FOR_STANDALONECASE_DEFAULT;
        } else {
          appealedDecisionResolutionData.appealTimeLimit =
            appealTimeLimit.toString();
        }
      }

      appealCommunicationDecisionDetails.appealedDecisionResolutionData
        .addRef(appealedDecisionResolutionData);

    }

    // Populate communication decision details
    decisionCode = CodeTable.getOneItem(HEARINGDECISIONRESOLUTION.TABLENAME,
      hearingDecisionResolutionCodeDetails.resolutionCode);
    appealCommunicationDecisionDetails.decisionResolutionCode = decisionCode;

    return appealCommunicationDecisionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the fee details for the specified representative
   *
   * @param key Unique internal reference numbers for the hearing and appeal
   * case
   *
   * @return appealCommunicationFeeDetails details of the fee amount, behalf
   * of code and the fee approved code.
   */
  @Override
  public AppealCommunicationFeeDetails
    getFeeDetails(final AppealCommunicationFeeKey key)
      throws AppException, InformationalException {

    // Hearing representative variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingRepresentativeKey hearingRepresentativeKey =
      new HearingRepresentativeKey();

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    HearingFeeNoticeDetails hearingFeeNoticeDetails;

    HearingDateAndReferenceDetails hearingDateAndReferenceDetails;

    // Appeal communication variables
    final AppealCommunicationFeeDetails appealCommunicationFeeDetails =
      new AppealCommunicationFeeDetails();

    // Read the fee amount, behalf of code and fee approved code
    // using the hearing representative id

    hearingRepresentativeKey.hearingRepresentativeID =
      key.hearingRepresentativeID;
    hearingFeeNoticeDetails =
      hearingRepresentativeObj.readFeeNoticeDetails(hearingRepresentativeKey);

    appealCommunicationFeeDetails.feeAmount =
      hearingFeeNoticeDetails.feeAmount;
    appealCommunicationFeeDetails.hearingID =
      hearingFeeNoticeDetails.hearingID;

    // Set fee approval string to 'IS' or 'IS NOT' based on the fee approved
    // code
    if (hearingFeeNoticeDetails.feeApprovedCode
      .equals(FEEAPPROVED.APPROVED)) {

      appealCommunicationFeeDetails.feeApprovedString =
        BPOAPPEALCOMMUNICATION.INF_FEE_APPROVAL_IS.toString();

    } else {

      appealCommunicationFeeDetails.feeApprovedString =
        BPOAPPEALCOMMUNICATION.INF_FEE_APPROVAL_IS_NOT.toString();

    }

    // Read the scheduled date time for the hearing id
    hearingKey.hearingID = hearingFeeNoticeDetails.hearingID;
    hearingDateAndReferenceDetails =
      hearingObj.readScheduledDateAndReference(hearingKey);

    // Set the scheduled date based on the scheduled date time of the hearing

    // Set date string
    appealCommunicationFeeDetails.scheduledDate =
      hearingDateAndReferenceDetails.scheduledDateTime.toString();

    // Set the hearing reference number
    appealCommunicationFeeDetails.hearingReference =
      hearingDateAndReferenceDetails.referenceNumber;

    // Read case participant
    caseParticipantRoleCaseAndTypeKey.caseID = key.appealCaseID;
    // Set the case participant role type based on the behalf of code
    if (hearingFeeNoticeDetails.behalfOfCode.equals(ONBEHALFOF.APPELLANT)) {

      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;

    } else if (hearingFeeNoticeDetails.behalfOfCode
      .equals(ONBEHALFOF.RESPONDENT)) {

      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;

    } else if (hearingFeeNoticeDetails.behalfOfCode
      .equals(ONBEHALFOF.THIRDPARTY)) {

      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.THIRDPARTY;

    }

    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj.searchActiveRoleAndNameByCaseAndType(
        caseParticipantRoleCaseAndTypeKey);

    // Set behalf of name
    appealCommunicationFeeDetails.representingName =
      caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;

    return appealCommunicationFeeDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details about the respondent for an appeal case.
   *
   * @param key Unique internal reference number for the appeal case
   *
   * @return The respondent details for the specified case
   */
  @Override
  public AppealCommunicationRespondentDetails getRespondentDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();

    // Return details
    final AppealCommunicationRespondentDetails appealCommunicationRespondentDetails =
      new AppealCommunicationRespondentDetails();

    // Read respondent data
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.RESPONDENT;
    caseParticipantRoleCaseAndTypeKey.recordStatus =
      curam.codetable.RECORDSTATUS.NORMAL;
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj.searchActiveRoleAndNameByCaseAndType(
        caseParticipantRoleCaseAndTypeKey);

    if (!caseParticipantRoleNameDetailsList.dtls.isEmpty()) {

      // Set return details
      appealCommunicationRespondentDetails.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;
      appealCommunicationRespondentDetails.respondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
    }

    return appealCommunicationRespondentDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the scheduled date for the statement letter
   *
   * @param key Unique internal reference numbers for the hearing
   *
   * @return appealCommunicationStatementDetails scheduled date of the hearing
   */
  @Override
  public AppealCommunicationStatementDetails getStatementLetterDetails(
    final HearingKey key) throws AppException, InformationalException {

    // Appeal communication variables
    final AppealCommunicationStatementDetails appealCommunicationStatementDetails =
      new AppealCommunicationStatementDetails();

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();

    // Read the scheduled date
    // BEGIN, CR00021655, RKi
    try {
      // Set date string
      appealCommunicationStatementDetails.scheduledDate =
        hearingObj.readScheduledDate(key.hearingKey).scheduledDateTime
          .toString();
    } catch (final Exception e) {// DO NOTHING
    }
    // END, CR00021655

    return appealCommunicationStatementDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a transcription letter for an appeal.
   *
   * @param key Hearing unique identifier
   * @return Appeal communication transcript details
   */
  @Override
  public AppealCommunicationTranscriptDetails getTranscriptDetails(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    // details to be returned
    final AppealCommunicationTranscriptDetails appealCommunicationTranscriptDetails =
      new AppealCommunicationTranscriptDetails();

    final curam.appeal.sl.entity.struct.CaseAndStatusKey caseAndStatusKey =
      new curam.appeal.sl.entity.struct.CaseAndStatusKey();
    HearingIDRefScheduledDateDetails hearingIDRefScheduledDateDetails;

    // Read latest completed hearing
    caseAndStatusKey.caseID = key.caseID;
    caseAndStatusKey.statusCode = curam.codetable.HEARINGSTATUS.COMPLETED;

    try {
      hearingIDRefScheduledDateDetails = hearingObj
        .readLatestHearingIDRefScheduledDateByCaseAndStatus(caseAndStatusKey);
    } catch (final RecordNotFoundException e) {
      hearingIDRefScheduledDateDetails = null;
    }

    if (hearingIDRefScheduledDateDetails != null) {

      appealCommunicationTranscriptDetails.hearingReference =
        hearingIDRefScheduledDateDetails.hearingReference;

      // Set date string
      appealCommunicationTranscriptDetails.scheduledDate =
        hearingIDRefScheduledDateDetails.scheduledDateTime.toString();
    }

    return appealCommunicationTranscriptDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate the appeal request receipt notice for an
   * appealed case for an appeal.
   *
   * @param key The appealed case for which to generate the notice.
   * @return the receipt details
   */
  @Override
  public AppealCommunicationReceiptDetails
    getReceiptDetails(final AppealRelationshipKey key)
      throws AppException, InformationalException {

    // AppealRelationship object
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();

    // Return struct
    final AppealCommunicationReceiptDetails appealCommunicationReceiptDetails =
      new AppealCommunicationReceiptDetails();

    // Get correct AppealRelationshipKey
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;

    // Get ReceiptNoticeDetails
    final ReceiptNoticeDetails receiptNoticeDetails =
      appealRelationshipObj.readReceiptNoticeDetails(appealRelationshipKey);

    // Format the received effective date

    // Set date string in appeal receipt notice data variable
    final AppealReceiptNoticeData appealReceiptNoticeData =
      new AppealReceiptNoticeData();

    appealReceiptNoticeData.effectiveDate =
      receiptNoticeDetails.appealedDecisionDate.toString();

    // Format the received date
    // Set received date string in appeal receipt notice data variable
    appealReceiptNoticeData.receivedDate =
      receiptNoticeDetails.receivedDate.toString();

    // Set continue benefits string
    if (receiptNoticeDetails.continueBenefitsIndicator) {

      appealReceiptNoticeData.continueBenefitsString =
        BPOAPPEALCOMMUNICATION.INF_CONTINUE_YES.getMessageText();

    } else {

      appealReceiptNoticeData.continueBenefitsString =
        BPOAPPEALCOMMUNICATION.INF_CONTINUE_NO.getMessageText();

    }

    // Convert appealed case reason code to description
    appealReceiptNoticeData.reasonCode = curam.util.type.CodeTable.getOneItem(
      curam.codetable.APPEALREASON.TABLENAME,
      receiptNoticeDetails.reasonCode);

    // Add to receipt notice data list
    appealCommunicationReceiptDetails.appealReceiptNoticeData
      .addRef(appealReceiptNoticeData);

    return appealCommunicationReceiptDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a rejection notice for an appealed case.
   *
   * @param key Appeal case key
   * @return Appealed case rejection details
   */
  @Override
  public AppealCommunicationAppealedCaseRejectDetails
    getAppealedCaseRejectDetails(final AppealedCaseRejectData key)
      throws AppException, InformationalException {

    // Appeal rejection details
    final AppealCommunicationAppealedCaseRejectDetails appealCommunicationAppealedCaseRejectDetails =
      new AppealCommunicationAppealedCaseRejectDetails();

    // Appeal entity and manipulation variables
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // AppealCaseRejection object and manipulation variables
    final AppealedCaseRejection appealedCaseRejectionObj =
      AppealedCaseRejectionFactory.newInstance();
    AppealCaseRejectionReason appealCaseRejectionReason;
    final AppealRelationshipIDKey appealRelationshipIDKey =
      new AppealRelationshipIDKey();

    // AppealRelationship entity and manipulation variables
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();
    RejectAppealCaseNoticeData rejectAppealCaseNoticeData =
      new RejectAppealCaseNoticeData();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    // CaseHeader entity and manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseReference caseReference;
    final CaseSearchKey caseSearchKey = new curam.core.struct.CaseSearchKey();

    appealCaseIDKey.caseID = key.appealCaseID;

    // read appeal type
    final AppealTypeDetails appealTypeDetails =
      appealObj.readAppealTypeByCase(appealCaseIDKey);

    // BEGIN, CR00284786, DG
    String constraintType = new String();

    // set constraint type based on appeal type
    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      constraintType = CONSTRAINTTYPE.REQUEST_HEARING_CASE;
    } else if (appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.HEARINGREVIEW)) {
      constraintType = CONSTRAINTTYPE.REQUEST_HEARING_REVIEW;
    }

    // Get the time constraint
    final CaseIDAppealCaseIDConstraintType details =
      new CaseIDAppealCaseIDConstraintType();

    details.appealCaseID = key.appealCaseID;
    details.caseID = key.caseID;
    details.constraintType = constraintType;
    final TimeConstraintLength timeConstraintLength =
      AppealFactory.newInstance().getTimeConstraintLength(details);

    if (timeConstraintLength.numberOfDays == 0) {

      // Required constraint does not exist - throw exception
      final AppException ex = new AppException(
        curam.message.BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

      ex.arg(new curam.util.type.CodeTableItemIdentifier(
        curam.codetable.CONSTRAINTTYPE.TABLENAME, constraintType));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ex,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          5);
    }

    // set appeal time limit
    appealCommunicationAppealedCaseRejectDetails.appealTimeLimit =
      timeConstraintLength.numberOfDays;
    // END, CR00284786

    // read case rejection reason
    appealRelationshipIDKey.appealRelationshipID = key.appealRelationshipID;
    appealCaseRejectionReason =
      appealedCaseRejectionObj.readLatestReason(appealRelationshipIDKey);

    // assign reject details
    appealCommunicationAppealedCaseRejectDetails.appealRejectReason =
      CodeTable.getOneItem(CASEREJECTIONREASON.TABLENAME,
        appealCaseRejectionReason.reasonCode);

    // Read for appeal relationship data
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;

    rejectAppealCaseNoticeData = appealRelationshipObj
      .readAppealCaseRejectionDetails(appealRelationshipKey);

    // Convert appeal reason code to description
    appealCommunicationAppealedCaseRejectDetails.appealReasonCode =
      curam.util.type.CodeTable.getOneItem(
        curam.codetable.APPEALREASON.TABLENAME,
        rejectAppealCaseNoticeData.reasonCode);

    // Find the case reference for case
    caseSearchKey.caseID = rejectAppealCaseNoticeData.caseID;
    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    appealCommunicationAppealedCaseRejectDetails.appealedCaseReference =
      caseReference.caseReference;

    // Find the case reference for the prior case
    caseSearchKey.caseID = rejectAppealCaseNoticeData.priorAppealCaseID;

    // Appeals may not have a prior case associated with them.
    // Need to check for this instance.
    if (rejectAppealCaseNoticeData.priorAppealCaseID != 0) {

      caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

      appealCommunicationAppealedCaseRejectDetails.priorAppealCaseReference =
        caseReference.caseReference;

    }

    return appealCommunicationAppealedCaseRejectDetails;

  }

  // ___________________________________________________________________________
  /**
   * This operation gets the decision template data for an appeal communication.
   *
   * @param key Key which identifies the template data
   * @return Decision template data
   */
  @Override
  public TemplateDataDetails getDecisionTemplateData(
    final TemplateDataKey key) throws AppException, InformationalException {

    // Variable for return value
    final TemplateDataDetails templateDataDetails = new TemplateDataDetails();

    // Variables for appeal entity layer
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    AppealResolutionsList appealResolutionsList = new AppealResolutionsList();
    HearingIDRefScheduledDateDetails hearingIDRefScheduledDateDetails =
      new HearingIDRefScheduledDateDetails();
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey_entity =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingUserFullDetailsList hearingUserFullDetailsList;

    // Variables for appeal service layer
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();
    curam.appeal.sl.struct.AppealTypeDetails appealTypeDetails;

    // Variables for core service layer
    final Organisation organisationObj = OrganisationFactory.newInstance();
    final Address addressObj = AddressFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    final OrganisationKey organisationKey = new OrganisationKey();
    final OtherAddressData otherAddressData = new OtherAddressData();
    DateResolutionAndCaseRefDetails dateResolutionAndCaseRefDetails;
    OrganisationNameAndAddressDetails organisationNameAndAddressDetails;
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final NameAddressReadKey nameAddressReadKey = new NameAddressReadKey();
    ConcernNameAddressDetails concernNameAddressDetails =
      new ConcernNameAddressDetails();

    // User entity variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UserFullname userFullname;

    // Local variables
    String issueAndResolutionList = new String();
    String resolutionDescription;
    String reasonDescription;
    String overallDecisionDescription;
    String hearingOfficials = new String();
    int i;
    int numAppealedCases;

    // DOM variables used to create the BLOB
    final XMLOutputter outputter = new XMLOutputter();
    final Element rootElement = new Element(CuramConst.gkRoot);
    final Element fieldsElement = new Element(CuramConst.gkFields);
    final Element fieldElementAppellantName = new Element(CuramConst.gkField);
    final Element fieldElementAppellantAddress =
      new Element(CuramConst.gkField);
    final Element fieldElementIssues = new Element(CuramConst.gkField);
    final Element fieldElementOfficials = new Element(CuramConst.gkField);
    final Element fieldElementOrganizationName =
      new Element(CuramConst.gkField);
    final Element fieldElementOrganizationAddress =
      new Element(CuramConst.gkField);
    final Element fieldElementDecisionDate = new Element(CuramConst.gkField);
    final Element fieldElementUserName = new Element(CuramConst.gkField);
    final Element fieldElementOverallDecision =
      new Element(CuramConst.gkField);
    final Element fieldElementHearingReference =
      new Element(CuramConst.gkField);
    final Element fieldElementHearingDate = new Element(CuramConst.gkField);
    final Element fieldElementAppealCaseReference =
      new Element(CuramConst.gkField);

    // Retrieve decision date, resolution code and appeal case reference
    hearingDecisionCaseKey.caseID = key.appealCaseID;
    dateResolutionAndCaseRefDetails = hearingDecisionObj
      .readDateResolutionAndRefByCase(hearingDecisionCaseKey);

    // Get the description for the overall decision
    overallDecisionDescription =
      curam.util.type.CodeTable.getOneItem(APPEALCASERESOLUTION.TABLENAME,
        dateResolutionAndCaseRefDetails.resolutionCode);

    // Get the organization name and address
    organisationKey.organisationID = kOrganisationID;
    organisationNameAndAddressDetails =
      organisationObj.readNameAndAddress(organisationKey);

    // Get the appellant name and address
    appealCaseKey.caseID = key.appealCaseID;
    readAppellantDetails = appealObj.readAppellantDetails(appealCaseKey);
    if (readAppellantDetails != null) {
      nameAddressReadKey.concernRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID;
      concernNameAddressDetails =
        concernRoleObj.readNameAndAddress(nameAddressReadKey);
    }

    // Get the appeal type
    appealTypeDetails = appealObj.readAppealType(appealCaseKey);

    // Get the last completed hearing for the appeal case;
    // retrieve the hearing reference and scheduled date;
    // unless a judicial review
    if (!appealTypeDetails.appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.JUDICIALREVIEW)) {
      caseAndStatusKey.caseID = key.appealCaseID;
      caseAndStatusKey.statusCode = HEARINGSTATUS.COMPLETED;
      hearingIDRefScheduledDateDetails = hearingObj
        .readLatestHearingIDRefScheduledDateByCaseAndStatus(caseAndStatusKey);

      // Determine the users for the hearing
      hearingKey_entity.hearingID =
        hearingIDRefScheduledDateDetails.hearingID;
      hearingUserFullDetailsList =
        hearingUserRoleObj.searchAllByHearingID(hearingKey_entity);

      // Format a single value of comma delimited names for the officials
      for (i = 0; i < hearingUserFullDetailsList.dtls.size(); i++) {

        if (i > 0) {
          hearingOfficials = hearingOfficials
            .concat(GeneralAppealConstants.kDelimiterWithOutSpace);
        }
        // BEGIN, CR00053295, RKi
        final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
        CaseOwnerDetails caseOwnerDetails;

        orgObjectLinkKey.orgObjectLinkID =
          hearingUserFullDetailsList.dtls.item(i).orgObjectLinkID;
        final curam.core.sl.intf.CaseUserRole caseUserRole =
          curam.core.sl.fact.CaseUserRoleFactory.newInstance();

        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        hearingUserFullDetailsList.dtls.item(i).fullName =
          caseOwnerDetails.userFullName;
        hearingUserFullDetailsList.dtls.item(i).fullName =
          caseOwnerDetails.userFullName;
        // END, CR00053295
        hearingOfficials = hearingOfficials
          .concat(hearingUserFullDetailsList.dtls.item(i).fullName);
      }
    }

    // Get the current user
    usersKey.userName = TransactionInfo.getProgramUser();
    userFullname = usersObj.getFullName(usersKey);

    // Get all of the appealed cased details for the appeal case
    activeApprovedCaseKey.appealCaseID = key.appealCaseID;
    activeApprovedCaseKey.recordStatus = RECORDSTATUS.NORMAL;
    appealResolutionsList = appealRelationshipObj
      .searchActiveResolutionDetailsByAppealCase(activeApprovedCaseKey);
    numAppealedCases = appealResolutionsList.dtls.size();

    // Get delimited list of issues and their resolutions
    for (i = 0; i < numAppealedCases; i++) {
      resolutionDescription = curam.util.type.CodeTable.getOneItem(
        HEARINGDECISIONRESOLUTION.TABLENAME,
        appealResolutionsList.dtls.item(i).resolutionCode);

      reasonDescription =
        curam.util.type.CodeTable.getOneItem(APPEALREASON.TABLENAME,
          appealResolutionsList.dtls.item(i).reasonCode);

      if (i > 0) {
        issueAndResolutionList = issueAndResolutionList
          .concat(GeneralAppealConstants.kDelimiterWithOutSpace);
      }
      issueAndResolutionList = issueAndResolutionList
        .concat(appealResolutionsList.dtls.item(i).receivedDate
          + GeneralAppealConstants.kSpace);
      issueAndResolutionList = issueAndResolutionList
        .concat(reasonDescription + GeneralAppealConstants.kSpace);
      issueAndResolutionList = issueAndResolutionList
        .concat(appealResolutionsList.dtls.item(i).caseReference
          + GeneralAppealConstants.kSpace);
      issueAndResolutionList = issueAndResolutionList
        .concat(appealResolutionsList.dtls.item(i).effectiveDate
          + GeneralAppealConstants.kSpace);
      issueAndResolutionList =
        issueAndResolutionList.concat(resolutionDescription);
    }

    // Add appellant name element
    fieldElementAppellantName.setAttribute(CuramConst.gkName, kAppellantName);
    fieldElementAppellantName.setAttribute(CuramConst.gkValue,
      concernNameAddressDetails.fullName);
    fieldsElement.addContent(fieldElementAppellantName);

    // Add organization name element
    fieldElementOrganizationName.setAttribute(CuramConst.gkName,
      kOrganizationName);
    fieldElementOrganizationName.setAttribute(CuramConst.gkValue,
      organisationNameAndAddressDetails.name);
    fieldsElement.addContent(fieldElementOrganizationName);

    // Add decision date element
    fieldElementDecisionDate.setAttribute(CuramConst.gkName, kDecisionDate);
    fieldElementDecisionDate.setAttribute(CuramConst.gkValue,
      dateResolutionAndCaseRefDetails.decisionDate.toString());
    fieldsElement.addContent(fieldElementDecisionDate);

    // Add appellant address element
    fieldElementAppellantAddress.setAttribute(CuramConst.gkName,
      kAppellantAddress);
    otherAddressData.addressData = concernNameAddressDetails.addressData;
    addressObj.getAddressStrings(otherAddressData);
    fieldElementAppellantAddress.setAttribute(CuramConst.gkValue,
      otherAddressData.addressData);
    fieldsElement.addContent(fieldElementAppellantAddress);

    // Add organization address element
    fieldElementOrganizationAddress.setAttribute(CuramConst.gkName,
      kOrganizationAddress);
    otherAddressData.addressData =
      organisationNameAndAddressDetails.addressData;
    addressObj.getAddressStrings(otherAddressData);
    fieldElementOrganizationAddress.setAttribute(CuramConst.gkValue,
      otherAddressData.addressData);
    fieldsElement.addContent(fieldElementOrganizationAddress);

    // Add issue resolution element
    fieldElementIssues.setAttribute(CuramConst.gkName,
      kIssueAndResolutionList);
    fieldElementIssues.setAttribute(CuramConst.gkValue,
      issueAndResolutionList);
    fieldsElement.addContent(fieldElementIssues);

    // Add hearing official element
    fieldElementOfficials.setAttribute(CuramConst.gkName, kHearingOfficials);
    fieldElementOfficials.setAttribute(CuramConst.gkValue, hearingOfficials);
    fieldsElement.addContent(fieldElementOfficials);

    // Add appeal case reference element
    fieldElementAppealCaseReference.setAttribute(CuramConst.gkName,
      kAppealCaseReference);
    fieldElementAppealCaseReference.setAttribute(CuramConst.gkValue,
      dateResolutionAndCaseRefDetails.caseReference);
    fieldsElement.addContent(fieldElementAppealCaseReference);

    // Add hearing reference element
    fieldElementHearingReference.setAttribute(CuramConst.gkName,
      kHearingReference);
    fieldElementHearingReference.setAttribute(CuramConst.gkValue,
      hearingIDRefScheduledDateDetails.hearingReference);
    fieldsElement.addContent(fieldElementHearingReference);

    // Add hearing date element

    fieldElementHearingDate.setAttribute(CuramConst.gkName, kHearingDate);
    fieldElementHearingDate.setAttribute(CuramConst.gkValue,
      hearingIDRefScheduledDateDetails.scheduledDateTime.toString());
    fieldsElement.addContent(fieldElementHearingDate);

    // Add overall decision resolution element
    fieldElementOverallDecision.setAttribute(CuramConst.gkName,
      kOverallDecision);
    fieldElementOverallDecision.setAttribute(CuramConst.gkValue,
      overallDecisionDescription);
    fieldsElement.addContent(fieldElementOverallDecision);

    // Add user name element
    fieldElementUserName.setAttribute(CuramConst.gkName, kUserName);
    fieldElementUserName.setAttribute(CuramConst.gkValue,
      userFullname.fullname);
    fieldsElement.addContent(fieldElementUserName);

    // Convert template document data into a BLOB
    rootElement.addContent(fieldsElement);
    templateDataDetails.documentData = new curam.util.type.Blob(
      outputter.outputString(rootElement).getBytes());

    return templateDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation gets the word template document and data for an appeal
   * communication.
   *
   * @param key Key which identifies the word template document and data
   * @return Word template document and data
   */
  @Override
  public WordTemplateDocumentAndDataDetails
    getWordTemplateDocumentAndData(final HearingDecisionAttachmentLinkKey key)
      throws AppException, InformationalException {

    // Variable to be returned
    final WordTemplateDocumentAndDataDetails wordTemplateDocumentAndDataDetails =
      new WordTemplateDocumentAndDataDetails();

    // Variables from appeal service layer
    final TemplateDataKey templateDataKey = new TemplateDataKey();
    TemplateDataDetails templateDataDetails;

    // Variables from appeal entity layer
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionAttachmentLinkKey hearingDecisionAttachmentLinkKey =
      new HearingDecisionAttachmentLinkKey();
    CaseTemplateAndAttachmentDetails caseTemplateAndAttachmentDetails;

    // Variables from Appeal Communication server layer
    final curam.appeal.sl.intf.AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    // Get the appeal case ID, template ID and attachment ID for the word
    // document
    hearingDecisionAttachmentLinkKey.attachmentLinkID = key.attachmentLinkID;
    caseTemplateAndAttachmentDetails = hearingDecisionAttachmentLinkObj
      .readCaseTemplateAndAttachment(hearingDecisionAttachmentLinkKey);

    // Get the BLOB for the word document template
    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = caseTemplateAndAttachmentDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read the BLOB for the word template document
    wordTemplateDocumentAndDataDetails.document =
      caseTemplateAndAttachmentDetails.documentTemplateContents;

    // Get the BLOB for the word template data
    templateDataKey.appealCaseID = caseTemplateAndAttachmentDetails.caseID;
    templateDataDetails =
      appealCommunicationObj.getDecisionTemplateData(templateDataKey);
    wordTemplateDocumentAndDataDetails.templateData =
      templateDataDetails.documentData;

    return wordTemplateDocumentAndDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a hearing adjournment notice for an
   * appellant.
   *
   * @param key identifies the hearing case
   * @return Appeal case hearing adjournment details
   */
  @Override
  public AppealCommunicationAdjournmentDetails
    getAdjournmentDetails(final HearingIDHearingCaseID key)
      throws AppException, InformationalException {

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // HearingUserRole object
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();

    // Set the Key objects
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // case relationship objects
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelationshipRelatedCaseIDKey existingRelationSearchKey =
      new CaseRelationshipRelatedCaseIDKey();
    CaseRelationshipDtlsList caseRelationshipDtlsListObj;

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    HearingCaseUserNameDtlsList hearingCaseUserNameDtlsList =
      new HearingCaseUserNameDtlsList();

    appealCaseIDKey.caseID = key.hearingCaseID;

    caseAndStatusKey.caseID = key.hearingCaseID;
    caseAndStatusKey.statusCode = HEARINGSTATUS.ADJOURNED;

    final HearingPostponeDateDetails postponeDetails =
      hearingObj.readLatestPostponedByCaseIDAndStatus(caseAndStatusKey);

    // get the continuance data
    hearingKey.hearingID = postponeDetails.hearingID;
    final AppealContinueDetails appealContinueDetails =
      hearingObj.readContinaunceDetails(hearingKey);

    final AppealCommunicationAdjournmentDetails appealCommunicationAdjournmentDetails =
      new AppealCommunicationAdjournmentDetails();

    // Set date string
    appealCommunicationAdjournmentDetails.adjournedDate =
      postponeDetails.postponeDate.toString();

    appealCommunicationAdjournmentDetails.adjournedReasonText =
      appealContinueDetails.postponeReasonText;
    appealCommunicationAdjournmentDetails.adjournedReasonCode =
      CodeTable.getOneItem(POSTPONEREASON.TABLENAME,
        appealContinueDetails.postponeReasonCode);

    // Get case relationship id

    existingRelationSearchKey.relatedCaseID = key.hearingCaseID;

    caseRelationshipDtlsListObj =
      caseRelationshipObj.searchByRelatedCaseID(existingRelationSearchKey);
    // BEGIN, CR00284786, DG
    long caseID = 0;

    if (caseRelationshipDtlsListObj.dtls.size() > 0) {

      caseID = caseRelationshipDtlsListObj.dtls.item(0).caseID;

    }

    // Get statement time limit
    final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
      new CaseIDAppealCaseIDConstraintType();

    caseIDAppealCaseIDConstraintType.appealCaseID = key.hearingCaseID;
    caseIDAppealCaseIDConstraintType.caseID = caseID;
    caseIDAppealCaseIDConstraintType.constraintType =
      curam.codetable.CONSTRAINTTYPE.SUBMIT_STATEMENT;
    final TimeConstraintLength timeConstraintLength =
      AppealFactory.newInstance()
        .getTimeConstraintLength(caseIDAppealCaseIDConstraintType);

    if (timeConstraintLength.numberOfDays == 0) {
      // Required constraint does not exist - throw exception
      final AppException ex = new AppException(
        curam.message.BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

      ex.arg(curam.util.type.CodeTable.getOneItem(
        curam.codetable.CONSTRAINTTYPE.TABLENAME,
        curam.codetable.CONSTRAINTTYPE.SUBMIT_STATEMENT));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ex,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          4);
    }

    // Set statement submission time limit
    appealCommunicationAdjournmentDetails.statementSubmissionDate =
      curam.util.type.Date.getCurrentDate()
        .addDays(timeConstraintLength.numberOfDays).toString();
    // END, CR00284786
    // BEGIN CR00118512 LP
    // type to search on
    String typeCode;
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = appealCaseIDKey.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    } else {
      // Get the name of the official/reviewer
      final AppealTypeDetails appealTypeDetails =
        appealObj.readAppealTypeByCase(appealCaseIDKey);

      if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

      } else {

        typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

      }
    }
    // END CR00118512 LP
    // BEGIN, CR00123104, RKi
    final ReadLocationType locationType =
      hearingObj.readLocationTypeByHearingID(hearingKey);

    if (locationType.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      final HearingIDCaseParticipantRoleTypeKey caseParticipantRoleTypeKey =
        new HearingIDCaseParticipantRoleTypeKey();

      caseParticipantRoleTypeKey.hearingID = hearingKey.hearingID;
      caseParticipantRoleTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      final ConcernRoleNameDetails concernRoleNameDetails = hearingObj
        .readOfficialNameByHearingIDTypeCode(caseParticipantRoleTypeKey);

      appealCommunicationAdjournmentDetails.hearingUserName =
        concernRoleNameDetails.concernRoleName;
    } else {
      // END, CR00123104
      // get the name of
      final HearingUserRoleStatusKey hearingUserRoleStatusKey =
        new HearingUserRoleStatusKey();

      hearingUserRoleStatusKey.hearingID = postponeDetails.hearingID;
      hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      hearingUserRoleStatusKey.typeCode = typeCode;

      hearingCaseUserNameDtlsList = hearingUserRoleObj
        .searchActiveUserNameByHearingIDAndType(hearingUserRoleStatusKey);

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        hearingCaseUserNameDtlsList.dtls.item(0).orgObjectLinkID;
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      // END, CR00053295

      // Use name of first returned.
      appealCommunicationAdjournmentDetails.hearingUserName =
        caseOwnerDetails.userName;
    }

    return appealCommunicationAdjournmentDetails;
  }

  // BEGIN, CR CR00069029, NSP
  // ___________________________________________________________________________
  /**
   * Retrieves details to populate a request receipt notice without continue
   * benefit details for an appeal.
   *
   * @param key Contains the appeal case ID
   *
   * @return the receipt without continue benefit details
   */
  @Override
  public AppealCommunicationReceiptWithoutContinueBenefitDetails
    getReceiptWithoutContinueBenefitDetails(final AppealCaseIDKey key)
      throws AppException, InformationalException {

    // AppealRelationship object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // Return struct
    final AppealCommunicationReceiptWithoutContinueBenefitDetails appealCommunicationReceiptWithoutContinueBenefitDetails =
      new AppealCommunicationReceiptWithoutContinueBenefitDetails();

    // Get list of ReceiptNoticeDetails
    final ReceiptNoticeKey receiptNoticeKey = new ReceiptNoticeKey();

    receiptNoticeKey.appealCaseID = key.caseID;
    final ReceiptNoticeDetailsList receiptNoticeDetailsList =
      appealRelationshipObj
        .searchOutstandingReceiptNoticeDetailsByAppealCase(receiptNoticeKey);

    // Appeal receipt notice data variable
    AppealReceiptNoticeWithoutContinueBenefitData appealReceiptNoticeWithoutContinueBenefitData;

    for (int i = 0; i < receiptNoticeDetailsList.dtls.size(); i++) {

      appealReceiptNoticeWithoutContinueBenefitData =
        new AppealReceiptNoticeWithoutContinueBenefitData();

      // Set date string
      appealReceiptNoticeWithoutContinueBenefitData.effectiveDate =
        receiptNoticeDetailsList.dtls.item(i).appealedDecisionDate.toString();

      // Set date string
      appealReceiptNoticeWithoutContinueBenefitData.receivedDate =
        receiptNoticeDetailsList.dtls.item(i).receivedDate.toString();

      // Convert appealed case reason code to description
      appealReceiptNoticeWithoutContinueBenefitData.reasonCode =
        curam.util.type.CodeTable.getOneItem(
          curam.codetable.APPEALREASON.TABLENAME,
          receiptNoticeDetailsList.dtls.item(i).reasonCode);

      // Add to receipt notice data list
      appealCommunicationReceiptWithoutContinueBenefitDetails.appealReceiptNoticeWithoutContinueBenefitData
        .addRef(appealReceiptNoticeWithoutContinueBenefitData);
    }
    return appealCommunicationReceiptWithoutContinueBenefitDetails;
  }

  // END, CR CR00069029

  // BEGIN, CR00306369, KRK
  /**
   * Retrieves the list of templates for the specified appeal case.
   *
   * @param searchTemplatesKey The type of the template
   *
   * @return The List of XSL Template details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public SearchTemplatesByConcernAndTypeResult
    listTemplatesByConcernAndType(final SearchTemplatesKey searchTemplatesKey)
      throws AppException, InformationalException {

    SearchTemplatesByConcernAndTypeResult searchTemplatesByConcernAndTypeResult =
      new SearchTemplatesByConcernAndTypeResult();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = searchTemplatesKey.caseID;

    final CaseTypeCode caseTypeCode =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    if (CASETYPECODE.APPEAL.equals(caseTypeCode.caseTypeCode)) {

      final XSLTemplateTypeKey xslTemplateTypeKey = new XSLTemplateTypeKey();

      // Boolean variable used to indicate TemplateDtls should be returned
      boolean returnTemplateDtls = false;

      xslTemplateTypeKey.templateType = searchTemplatesKey.templateType;

      final XSLTemplateDetailsList xslTemplateDetailsList =
        XSLTemplateUtilityFactory.newInstance()
          .getAllTemplatesByType(xslTemplateTypeKey);

      for (final curam.util.administration.struct.XSLTemplateDetails xslTemplateDtls : xslTemplateDetailsList.dtls
        .items()) {

        returnTemplateDtls = false;

        if (XSLTEMPLATETYPE.ALL_APPEAL_TYPE.equals(xslTemplateDtls.relatesTo)
          || templatesRelatesToAppealCase(caseKey,
            xslTemplateDtls.relatesTo)) {

          returnTemplateDtls = true;
        }
        if (returnTemplateDtls) {

          final XSLTemplateDetails xslTemplateDetails =
            new XSLTemplateDetails();

          xslTemplateDetails.templateID = xslTemplateDtls.templateID;
          xslTemplateDetails.templateName = xslTemplateDtls.templateName;
          xslTemplateDetails.latestVersion = xslTemplateDtls.latestVersion;
          xslTemplateDetails.checkedOutInd = xslTemplateDtls.checkedOut;
          xslTemplateDetails.checkedOutBy = xslTemplateDtls.checkedOutBy;
          xslTemplateDetails.checkedOutVersion =
            xslTemplateDtls.checkedOutVersion;
          xslTemplateDetails.checkedOutTime = xslTemplateDtls.checkedOutTime;
          xslTemplateDetails.comment = xslTemplateDtls.coComment;
          xslTemplateDetails.editableInd = xslTemplateDtls.editable;
          xslTemplateDetails.localeIdentifier = xslTemplateDtls.locale;

          searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls
            .addRef(xslTemplateDetails);
        }
      }
    } else {

      searchTemplatesByConcernAndTypeResult = MaintainXSLTemplateFactory
        .newInstance().searchTemplatesByConcernAndType(searchTemplatesKey);
    }
    return searchTemplatesByConcernAndTypeResult;
  }

  /**
   * Retrieves the templates relates to appeal case.
   *
   * @param caseKey The caseID of the appeal case.
   * @param relatesTo The types of the appeals.
   *
   * @return Templates related to Appeal case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean templatesRelatesToAppealCase(final CaseKey caseKey,
    final String relatesTo) throws AppException, InformationalException {

    boolean templateFound = false;

    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    appealCaseKey.caseID = caseKey.caseID;

    final curam.appeal.sl.struct.AppealTypeDetails appealTypeDetails =
      AppealFactory.newInstance().readAppealType(appealCaseKey);

    if (APPEALTYPE.HEARING
      .equals(appealTypeDetails.appealTypeDetails.appealTypeCode)) {

      if (XSLTEMPLATETYPE.HEARING.equals(relatesTo)) {

        templateFound = true;
      }
    } else if (APPEALTYPE.HEARINGREVIEW
      .equals(appealTypeDetails.appealTypeDetails.appealTypeCode)) {

      if (XSLTEMPLATETYPE.HEARING_REVIEW.equals(relatesTo)) {
        templateFound = true;
      }
    } else if (APPEALTYPE.JUDICIALREVIEW
      .equals(appealTypeDetails.appealTypeDetails.appealTypeCode)) {

      if (XSLTEMPLATETYPE.JUDICAIL_REVIEW.equals(relatesTo)) {
        templateFound = true;
      }
    }

    return templateFound;
  }

  // END, CR00306369

  /**
   * Helper method to check if a given case is appealable.
   *
   * @param caseID Case identifier.
   * @return Boolean indicating if a case type is appealable.
   */
  private boolean isCaseTypeAppealable(final long caseID) {

    // Return object
    boolean isAppealable = false;

    // Read the case type
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(caseID);
    final CASETYPECODEEntry caseType = caseHeader.getCaseType();

    if (CASETYPECODEEntry.PRODUCTDELIVERY.equals(caseType)
      || CASETYPECODEEntry.ISSUE.equals(caseType)
      || CASETYPECODEEntry.INTEGRATEDCASE.equals(caseType)) {
      isAppealable = true;
    } else {
      final AppealableCaseType appealableCaseType =
        appealableCaseTypeMap.get(caseType);

      if (appealableCaseType != null) {
        isAppealable = true;
      }
    }

    return isAppealable;
  }
}
