/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealObjectDtls;
import curam.message.ENTAPPEALOBJECT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public class AppealObject extends curam.appeal.sl.entity.base.AppealObject {

  @Override
  protected void preinsert(final AppealObjectDtls details)
    throws AppException, InformationalException {

    validate(details);

  }

  private void validate(final AppealObjectDtls details) throws AppException,
    InformationalException {

    if (details.appealRelationshipID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTAPPEALOBJECT.ERR_ENT_APPEAL_OBJECT_FV_APPEAL_RELATIONSHIP_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (details.objectID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTAPPEALOBJECT.ERR_ENT_APPEAL_OBJECT_FV_OBJECT_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (details.objectType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTAPPEALOBJECT.ERR_ENT_APPEAL_OBJECT_TYPE_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }
}
