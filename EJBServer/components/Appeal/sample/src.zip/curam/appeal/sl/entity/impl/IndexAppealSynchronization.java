/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This class publishes events about the creation and modification of
 * Appeals so that interested parties can intercept and take
 * appropriate action.
 */
public abstract class IndexAppealSynchronization extends
  curam.appeal.sl.entity.base.IndexAppealSynchronization {

  // ___________________________________________________________________________
  /**
   * Publishes an event that an Appeal was inserted. This method uses
   * the central method SynchronizationEvents.raiseEvent which checks to
   * see if the synchronization events have been enabled before actually raising
   * the event.
   * 
   * @param details The details of the Appeal that was inserted.
   */
  @Override
  public void insert(final AppealDtls details) throws AppException,
    InformationalException {

    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    final SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass =
      GeneralAppealConstants.kEventClassAppeal;
    synchronizeEventsDetails.eventKey.eventType =
      GeneralAppealConstants.kEventTypeInsert;
    synchronizeEventsDetails.primaryEventData = details.appealID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

}
