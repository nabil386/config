/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

/**
 * This class maintains all the constants defined for the appeals related key
 * sets.
 */
public abstract class KeySets extends curam.util.resources.KeySet {

  // Constant for ProductAppealProcess entity.
  public static final String KEY_SET_PRODUCTAPPEALPROCESS = "PRODAPL";

  // Constant for AppealSatge entity.
  public static final String KEY_SET_APPEALSTAGE = "APLSTG";

  // Constant for LegalAction entity.
  public static final String KEY_SET_LEGALACTION = "LGLACTN";
}
