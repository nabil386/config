/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.sl.entity.fact.AppealProFormaDataSetLinkFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.CaseParticipantRoleLinkFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.intf.AppealProFormaDataSetLink;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.CaseParticipantRoleLink;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseIDAndAppellantType;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealProFormaDataSetLinkCommunicationKey;
import curam.appeal.sl.entity.struct.AppealProFormaDataSetLinkDtls;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDetails;
import curam.appeal.sl.entity.struct.CaseParticipantRoleLinkDetailsList;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDKey;
import curam.appeal.sl.entity.struct.HearingRepresentativeStatusCodeCPRID;
import curam.appeal.sl.entity.struct.RelatedID;
import curam.appeal.sl.fact.AppealCommunicationFactory;
import curam.appeal.sl.fact.AppellantFactory;
import curam.appeal.sl.intf.AppealCommunication;
import curam.appeal.sl.intf.Appellant;
import curam.appeal.sl.struct.AdjournmentNoticeData;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealCommunicationAdjournmentDetails;
import curam.appeal.sl.struct.AppealCommunicationAppealDetails;
import curam.appeal.sl.struct.AppealCommunicationAppealedCaseRejectDetails;
import curam.appeal.sl.struct.AppealCommunicationCancelReasonDetails;
import curam.appeal.sl.struct.AppealCommunicationContinueReasonDetails;
import curam.appeal.sl.struct.AppealCommunicationCourtDetails;
import curam.appeal.sl.struct.AppealCommunicationDecisionDetails;
import curam.appeal.sl.struct.AppealCommunicationFeeDetails;
import curam.appeal.sl.struct.AppealCommunicationFeeKey;
import curam.appeal.sl.struct.AppealCommunicationParticipantKey;
import curam.appeal.sl.struct.AppealCommunicationReceiptDetails;
import curam.appeal.sl.struct.AppealCommunicationReceiptWithoutContinueBenefitDetails;
import curam.appeal.sl.struct.AppealCommunicationRespondentDetails;
import curam.appeal.sl.struct.AppealCommunicationStatementDetails;
import curam.appeal.sl.struct.AppealCommunicationTranscriptDetails;
import curam.appeal.sl.struct.AppealReceiptData;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.AppealedCaseRejectData;
import curam.appeal.sl.struct.AppealedCaseRejectionNoticeData;
import curam.appeal.sl.struct.CancellationNoticeData;
import curam.appeal.sl.struct.ContinuanceNoticeData;
import curam.appeal.sl.struct.CourtPetitionData;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.DecisionNoticeData;
import curam.appeal.sl.struct.FeeLetterData;
import curam.appeal.sl.struct.HearingIDHearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.ListAppellantConcernRoleIDDetails;
import curam.appeal.sl.struct.ScheduleHearingData;
import curam.appeal.sl.struct.StatementLetterData;
import curam.appeal.sl.struct.TranscriptLetterData;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.DATASETTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.facade.fact.CommunicationFactory;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.FileNameAndDataDtls;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.struct.DataSetData;
import curam.core.sl.struct.DataSetPrimaryKey;
import curam.core.sl.struct.GenerateDocumentDetails1;
import curam.core.sl.struct.GetDataSetDataDetails;
import curam.core.sl.struct.PreviewProFormaKey;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;

/**
 * This process class extends the Pro Forma Document Generation service
 * layer for Appeals.
 * 
 */
public abstract class AppealProFormaDocumentGeneration extends
  curam.appeal.sl.base.AppealProFormaDocumentGeneration {

  protected final String kDelimiter = GeneralAppealConstants.kDelimiter;

  @Inject
  private CMISAccessInterface cmisAccess;

  /**
   * Add injection.
   */
  protected AppealProFormaDocumentGeneration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Method to wrap the CMIS integration of creating a new participant pro forma
   * communication.
   * 
   * @param proFormaDocGen
   * @param details
   * The document generation details.
   * @return The file name and contents if CMIS is enabled. Blank values
   * otherwise.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ProFormaReturnDocDetails createConcernRoleProFormaDoc(
    final CreateConcernRoleProFormaDocDtls details) throws AppException,
    InformationalException {

    ProFormaReturnDocDetails appealProFormaDtls =
      new ProFormaReturnDocDetails();

    details.dtls.creationDate = Date.getCurrentDate();

    final AppealProFormaDataSetLinkDtls proFormaDataSetLinkDtls =
      new AppealProFormaDataSetLinkDtls();

    proFormaDataSetLinkDtls.communicationID = details.communicationID;
    proFormaDataSetLinkDtls.relatedDataSetID = details.dtls.dataSetPrimaryKey;
    proFormaDataSetLinkDtls.relatedDataSetType = details.dtls.dataSetType;
    proFormaDataSetLinkDtls.templateIDCode = details.dtls.documentIDCode;

    AppealProFormaDataSetLinkFactory.newInstance().insert(
      proFormaDataSetLinkDtls);

    generateDocument1(details.dtls);

    if (cmisAccess
      .isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

      // save the contents to the content management system
      appealProFormaDtls = previewDocument(details.dtls);

      cmisAccess.create(details.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
        appealProFormaDtls.fileDate.copyBytes(), appealProFormaDtls.fileName,
        CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);

    }
    return appealProFormaDtls;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00390321, JAF
  /**
   * Method to preview a ProForma Communication for the Appeals component. If
   * CMIS is enabled, the file will be downloaded from the Content Management
   * System.
   * 
   * @param previewProFormaKey The document generation details.
   * 
   * @return The generated PDF file.
   * 
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public ProFormaReturnDocDetails previewProForma(
    final PreviewProFormaKey previewProFormaKey) throws AppException,
    InformationalException {

    ProFormaReturnDocDetails proFormaReturnDocDetails =
      new ProFormaReturnDocDetails();

    // ConcernRoleCommunication manipulation variables
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj =
      curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
    final curam.core.struct.ConcernRoleCommunicationKey concernRoleCommunicationKey =
      new curam.core.struct.ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;

    // Set key and read ConcernRoleCommunication
    concernRoleCommunicationKey.communicationID =
      previewProFormaKey.communicationID;

    concernRoleCommunicationDtls =
      concernRoleCommunicationObj.read(concernRoleCommunicationKey);

    if (previewProFormaKey.localeIdentifier == null
      || previewProFormaKey.localeIdentifier.length() == 0) {
      concernRoleCommunicationDtls.localeIdentifier =
        TransactionInfo.getProgramLocale();
    } else {
      concernRoleCommunicationDtls.localeIdentifier =
        previewProFormaKey.localeIdentifier;
    }

    if (concernRoleCommunicationDtls.communicationStatus
      .equals(COMMUNICATIONSTATUS.DRAFT) == false
      && cmisAccess
        .isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)
      && cmisAccess.contentExists(previewProFormaKey.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
      final FileNameAndDataDtls fileDetails =
        cmisAccess.read(previewProFormaKey.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION);

      proFormaReturnDocDetails.fileName = fileDetails.fileName;
      proFormaReturnDocDetails.fileDate = fileDetails.fileContent;

    } else {
      final GenerateDocumentDetails1 generateDocumentDetails =
        new GenerateDocumentDetails1();
      final AppealProFormaDataSetLink appealProFormaDataSetLinkObj =
        AppealProFormaDataSetLinkFactory.newInstance();

      final AppealProFormaDataSetLinkCommunicationKey appealProFormaDataSetLinkCommunicationKey =
        new AppealProFormaDataSetLinkCommunicationKey();
      AppealProFormaDataSetLinkDtls appealProFormaDataSetLinkDtls =
        new AppealProFormaDataSetLinkDtls();

      appealProFormaDataSetLinkCommunicationKey.communicationID =
        previewProFormaKey.communicationID;

      // BEGIN, CR00395709, JAF
      // if document is in the ProFormaRelatedDataSetLink entity, call the
      // Appeals preview method
      try {
        appealProFormaDataSetLinkDtls =
          appealProFormaDataSetLinkObj
            .readByCommunicationID(appealProFormaDataSetLinkCommunicationKey);

        generateDocumentDetails.dataSetPrimaryKey =
          appealProFormaDataSetLinkDtls.relatedDataSetID;
        generateDocumentDetails.dataSetType =
          appealProFormaDataSetLinkDtls.relatedDataSetType;
        generateDocumentDetails.documentIDCode =
          appealProFormaDataSetLinkDtls.templateIDCode;

        proFormaReturnDocDetails = previewDocument(generateDocumentDetails);

        return proFormaReturnDocDetails;

      } catch (final RecordNotFoundException e) {
      }

      // otherwise call the method which does not read from
      // ProFormaRelatedDataSetLink,
      // Communication.previewProForma()
      final curam.core.facade.intf.Communication commObj =
        CommunicationFactory.newInstance();

      proFormaReturnDocDetails = commObj.previewProForma(previewProFormaKey);
      // END, CR00395709, JAF
    }

    return proFormaReturnDocDetails;
  }

  // END, CR00390321, JAF

  // ___________________________________________________________________________
  /**
   * This method calls the appropriate getDataSet(X)Data method based on
   * the data set type.
   * 
   * @param dtls Primary key of the data set and the data set type
   * 
   * @return The appropriate data set
   */
  @Override
  protected DataSetData getDataSetData(final GetDataSetDataDetails dtls)
    throws AppException, InformationalException {

    // Data set object
    DataSetData dataSetData;
    final DataSetPrimaryKey dataSetPrimaryKey = new DataSetPrimaryKey();

    // Set primary key
    dataSetPrimaryKey.dataSetPrimaryKey = dtls.dataSetPrimaryKey;

    // Call appropriate data set method
    if (dtls.dataSetType.equals(DATASETTYPE.SCHEDULE_NOTICE)) {

      dataSetData = getDataSetScheduleNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType
      .equals(DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE)) {

      dataSetData = getDataSetRescheduleNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.CONTINUED_SCHEDULE_NOTICE)) {

      dataSetData = getDataSetContinuedNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.REQUEST_RECEIPT)) {

      dataSetData = getDataSetRequestReceiptData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.REQUEST_SINGLE_RECEIPT)) {

      dataSetData = getDataSetSingleRequestReceiptData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.CONTINUANCE_NOTICE)) {

      dataSetData = getDataSetContinuanceNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.CANCELLATION_NOTICE)) {

      dataSetData = getDataSetCancellationNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType
      .equals(DATASETTYPE.APPEALED_CASE_REJECTION_NOTICE)) {

      dataSetData =
        getDataSetAppealedCaseRejectionNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.TRANSCRIPTION_LETTER)) {

      dataSetData = getDataSetTranscriptionLetterData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.DECISION_NOTICE)) {

      dataSetData = getDataSetDecisionNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.FEE_LETTER)) {

      dataSetData = getDataSetFeeLetterData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.STATEMENT_LETTER)) {

      dataSetData = getDataSetStatementLetterData(dataSetPrimaryKey);

    } else if (dtls.dataSetType.equals(DATASETTYPE.COURT_PETITION)) {

      dataSetData = getDataSetCourtPetitionData(dataSetPrimaryKey);

    } else if (dtls.dataSetType
      .equals(DATASETTYPE.HEARING_ATTENDANCE_CANCELLATION_NOTICE)) {

      dataSetData =
        getDataSetAttendanceCancellationNoticeData(dataSetPrimaryKey);

    } else if (dtls.dataSetType
      .equals(DATASETTYPE.HEARING_ADJOURNMENT_NOTICE)) {

      dataSetData = getDataSetAdjournmentNoticeData(dataSetPrimaryKey);

    } else {

      dataSetData = getCustomDataSetData(dataSetPrimaryKey);

    }

    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for schedule notices
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetScheduleNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    ScheduleHearingData scheduleHearingData = new ScheduleHearingData();
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // BEGIN, CR00021690, RKi
    // Appeal Case Key
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final Appellant appellant = AppellantFactory.newInstance();

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseKey.caseID = appealCommunicationAppealDetails.appealCaseID;
    scheduleHearingData.multipleAppellants.multipleAppellants = false;

    // read appellants
    ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
      new ListAppellantConcernRoleIDDetails();

    listAppellantConcernRoleIDDetails =
      appellant.getAppellantDetails(appealCaseKey);

    // BEGIN, CR00177498, PM
    final CaseParticipantRoleLink caseParticipantRoleLink =
      CaseParticipantRoleLinkFactory.newInstance();
    final RelatedID relatedID = new RelatedID();

    relatedID.relatedID = key.dataSetPrimaryKey;
    relatedID.recordStatus = RECORDSTATUS.NORMAL;
    final CaseParticipantRoleLinkDetailsList caseParticipantRoleLinkDetailsList =
      caseParticipantRoleLink.readParticipantDetailsByRelatedID(relatedID);

    final StringBuffer appellantsName = new StringBuffer();

    for (final CaseParticipantRoleLinkDetails caseParticipantRoleLinkDetails : caseParticipantRoleLinkDetailsList.dtls
      .items()) {

      // concatenate appellant's name
      final ConcernRole concernRole = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID =
        caseParticipantRoleLinkDetails.participantRoleID;
      final ConcernRoleNameDetails concernRoleNameDetails =
        concernRole.readConcernRoleName(concernRoleKey);

      appellantsName.append(concernRoleNameDetails.concernRoleName);

      appellantsName.append(kDelimiter);

      appealCommunicationAppealDetails.appellantName =
        appellantsName.toString();
    }
    // END, CR00177498

    // END, CR00021690
    scheduleHearingData =
      appealCommunicationObj
        .getScheduleNoticeDetails(appealCommunicationParticipantKey);

    // Set schedule string
    final AppException scheduledFor =
      new AppException(
        curam.message.BPOAPPEALPROFORMADOCUMENTGENERATION.INF_SCHEDULED_FOR);

    scheduleHearingData.scheduleString = scheduledFor.getMessage();
    scheduleHearingData.assign(appealCommunicationAppealDetails);

    // BEGIN, CR00021690, RKi
    if (listAppellantConcernRoleIDDetails.listDtls.dtls.size() > 1) {
      scheduleHearingData.multipleAppellants.multipleAppellants = true;
    }
    // END, CR00021690

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add data to document
    documentObj.add(scheduleHearingData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the request receipt.
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return the request receipt data
   */
  @Override
  protected DataSetData getDataSetRequestReceiptData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Appeal Case ID Key
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // the primary id is the appellant id
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseIDKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // BEGIN, CR CR00069029
    AppealCommunicationReceiptDetails appealCommunicationReceiptDetails;
    AppealCommunicationReceiptWithoutContinueBenefitDetails appealCommunicationReceiptWithoutContinueBenefitDetails;

    // read caseParticipantRole
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.dataSetPrimaryKey;
    CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    caseParticipantRoleDtls =
      caseParticipantRole.read(caseParticipantRoleKey);

    // create person object
    final Person personObj = PersonFactory.newInstance();
    final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
    // BEGIN, CR00236272, AK
    SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

    searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
      caseParticipantRoleDtls.participantRoleID;

    // Search whether appellant is associated with the case or not
    searchCaseDetails = personObj.searchCase1(searchCaseKey_fo);
    // END, CR00236272

    // Assign struct details to data struct
    final AppealReceiptData appealReceiptData = new AppealReceiptData();

    if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() >= 1) {

      // get the receipt details
      appealCommunicationReceiptDetails =
        appealCommunicationObj.getReceiptDetails(appealCaseIDKey);
      appealReceiptData.assign(appealCommunicationReceiptDetails);
    } else {

      // get the receipt details
      appealCommunicationReceiptWithoutContinueBenefitDetails =
        appealCommunicationObj
          .getReceiptWithoutContinueBenefitDetails(appealCaseIDKey);
      appealReceiptData
        .assign(appealCommunicationReceiptWithoutContinueBenefitDetails);
    }
    // END, CR CR00069029

    appealReceiptData.assign(appealCommunicationAppealDetails);

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add all the receipt data to document
    documentObj.add(appealReceiptData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the continuance notices.
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return the continuance data
   */
  @Override
  protected DataSetData getDataSetContinuanceNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // key to lookup continuance details
    final HearingIDHearingCaseID hearingIDHearingCaseID =
      new HearingIDHearingCaseID();

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // the primary id is the appellant id
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseIDKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // get the continuance details
    hearingIDHearingCaseID.hearingCaseID =
      appealCommunicationAppealDetails.appealCaseID;
    hearingIDHearingCaseID.hearingID =
      appealCommunicationAppealDetails.hearingID;

    final AppealCommunicationContinueReasonDetails appealCommunicationContinueReasonDetails =
      appealCommunicationObj.getContinuanceDetails(hearingIDHearingCaseID);

    // Assign struct details to data struct
    final ContinuanceNoticeData continuanceNoticeData =
      new ContinuanceNoticeData();

    continuanceNoticeData.assign(appealCommunicationAppealDetails);
    continuanceNoticeData.assign(appealCommunicationContinueReasonDetails);

    // map date to string
    continuanceNoticeData.continuanceDate =
      appealCommunicationContinueReasonDetails.continuanceDate.toString();

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add to the document
    documentObj.add(continuanceNoticeData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the cancellation notices.
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return the cancel details
   */
  @Override
  protected DataSetData getDataSetCancellationNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Appeal Case Key
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final curam.appeal.sl.intf.Appellant appellant =
      curam.appeal.sl.fact.AppellantFactory.newInstance();

    // the primary id is the appellant id
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // read appellants
    ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
      new ListAppellantConcernRoleIDDetails();

    listAppellantConcernRoleIDDetails =
      appellant.getAppellantDetails(appealCaseKey);

    if (listAppellantConcernRoleIDDetails.listDtls.dtls.size() > 1) {

      // concatenate appellant's name
      final StringBuffer appellantsName = new StringBuffer();

      for (int i = 0; i < listAppellantConcernRoleIDDetails.listDtls.dtls
        .size(); i++) {
        if (i > 0) {
          appellantsName.append(kDelimiter);
        }
        appellantsName.append(listAppellantConcernRoleIDDetails.listDtls.dtls
          .item(i).concernRoleName);
      }
      appealCommunicationAppealDetails.appellantName =
        appellantsName.toString();

    }

    // get the cancel details
    final AppealCommunicationCancelReasonDetails appealCommunicationCancelReasonDetails =
      appealCommunicationObj.getCancellationDetails(appealCaseKey);

    // Assign to data struct
    final CancellationNoticeData cancellationNoticeData =
      new CancellationNoticeData();

    cancellationNoticeData.assign(appealCommunicationAppealDetails);
    cancellationNoticeData.assign(appealCommunicationCancelReasonDetails);

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add data to document
    documentObj.add(cancellationNoticeData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for court petitions
   * 
   * @param key Unique internal reference number for the appeal case
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetCourtPetitionData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();
    AppealCommunicationRespondentDetails appealCommunicationRespondentDetails;
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;
    AppealCommunicationCourtDetails appealCommunicationCourtDetails;

    // CourtPetitionData object
    final CourtPetitionData courtPetitionData = new CourtPetitionData();

    // Get respondent data
    appealCaseKey.caseID = key.dataSetPrimaryKey;
    appealCommunicationRespondentDetails =
      appealCommunicationObj.getRespondentDetails(appealCaseKey);

    // Get appeal data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      appealCommunicationRespondentDetails.caseParticipantRoleID;
    appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    // Get court date data
    appealCommunicationCourtDetails =
      appealCommunicationObj.getCourtDetails(appealCaseKey);

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Assign data to struct
    courtPetitionData.assign(appealCommunicationRespondentDetails);
    courtPetitionData.assign(appealCommunicationAppealDetails);
    courtPetitionData.assign(appealCommunicationCourtDetails);

    // Add data to document
    documentObj.add(courtPetitionData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for decision notices
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetDecisionNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final curam.appeal.sl.intf.AppealCommunication appealCommunicationObj =
      curam.appeal.sl.fact.AppealCommunicationFactory.newInstance();
    AppealCommunicationDecisionDetails appealCommunicationDecisionDetails;
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // key to lookup decision details
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final curam.appeal.sl.intf.Appellant appellant =
      curam.appeal.sl.fact.AppellantFactory.newInstance();

    // AppellantType data
    // AppellantTypeDetails appellantTypeDetails;

    // Get the appeal data
    appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    // Get the decision details
    appealCaseKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // Read the appellant type for the case
    appealCaseIDKey.caseID = appealCaseKey.caseID;

    // read appellants
    ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
      new ListAppellantConcernRoleIDDetails();

    listAppellantConcernRoleIDDetails =
      appellant.getAppellantDetails(appealCaseKey);

    if (listAppellantConcernRoleIDDetails.listDtls.dtls.size() > 1) {

      // concatenate appellant's name
      final StringBuffer appellantsName = new StringBuffer();

      for (int i = 0; i < listAppellantConcernRoleIDDetails.listDtls.dtls
        .size(); i++) {
        if (i > 0) {
          appellantsName.append(kDelimiter);
        }
        appellantsName.append(listAppellantConcernRoleIDDetails.listDtls.dtls
          .item(i).concernRoleName);
      }
      appealCommunicationAppealDetails.appellantName =
        appellantsName.toString();

    }

    appealCommunicationDecisionDetails =
      appealCommunicationObj.getDecisionDetails(appealCaseKey);

    // Assign struct details to data struct
    final DecisionNoticeData decisionNoticeData = new DecisionNoticeData();

    decisionNoticeData.assign(appealCommunicationAppealDetails);
    decisionNoticeData.assign(appealCommunicationDecisionDetails);

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add to the document
    documentObj.add(decisionNoticeData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for fee letters
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetFeeLetterData(final DataSetPrimaryKey key)
    throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Hearing representative variables
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new HearingRepresentativeIDKey();
    HearingRepresentativeStatusCodeCPRID hearingRepresentativeStatusCodeCPRID;

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    AppealCommunicationFeeDetails appealCommunicationFeeDetails;
    final AppealCommunicationFeeKey appealCommunicationFeeKey =
      new AppealCommunicationFeeKey();
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Read for the case participant role id
    hearingRepresentativeIDKey.hearingRepresentativeID =
      key.dataSetPrimaryKey;
    hearingRepresentativeStatusCodeCPRID =
      hearingRepresentativeObj
        .readStatusCaseParticipantRoleID(hearingRepresentativeIDKey);

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      hearingRepresentativeStatusCodeCPRID.caseParticipantRoleID;

    // Get the appeal data
    appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCommunicationFeeKey.appealCaseID =
      appealCommunicationAppealDetails.appealCaseID;
    appealCommunicationFeeKey.hearingRepresentativeID = key.dataSetPrimaryKey;
    appealCommunicationFeeDetails =
      appealCommunicationObj.getFeeDetails(appealCommunicationFeeKey);

    // Assign struct details to data struct
    final FeeLetterData feeLetterData = new FeeLetterData();

    feeLetterData.assign(appealCommunicationAppealDetails);
    feeLetterData.assign(appealCommunicationFeeDetails);
    feeLetterData.scheduledDate =
      appealCommunicationFeeDetails.scheduledDate.toString();
    feeLetterData.feeApprovalString =
      appealCommunicationFeeDetails.feeApprovedString;
    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add to the document
    documentObj.add(feeLetterData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for statement letter
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetStatementLetterData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    AppealCommunicationStatementDetails appealCommunicationStatementDetails;
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Hearing variables
    final HearingKey hearingKey_bo = new HearingKey();

    // Get the appeal data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;
    appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    hearingKey_bo.hearingKey.hearingID =
      appealCommunicationAppealDetails.hearingID;
    appealCommunicationStatementDetails =
      appealCommunicationObj.getStatementLetterDetails(hearingKey_bo);

    // Assign struct details to data struct
    final StatementLetterData statementLetterData = new StatementLetterData();

    statementLetterData.assign(appealCommunicationAppealDetails);
    statementLetterData.scheduledDate =
      appealCommunicationStatementDetails.scheduledDate.toString();

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add to the document
    documentObj.add(statementLetterData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the continuance notices.
   * 
   * @param key Data set primary key
   * @return Data set data
   */
  @Override
  protected DataSetData getDataSetTranscriptionLetterData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data Set data
    final DataSetData dataSetData = new DataSetData();

    // AppealCommunication object and manipulation variables
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final Appellant appellant = AppellantFactory.newInstance();

    // Transcript Letter Data
    final TranscriptLetterData transcriptLetterData =
      new TranscriptLetterData();

    // Create XML document object
    final XMLDocument xmlDocumentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // get appeal details
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // read appellants
    ListAppellantConcernRoleIDDetails listAppellantConcernRoleIDDetails =
      new ListAppellantConcernRoleIDDetails();

    listAppellantConcernRoleIDDetails =
      appellant.getAppellantDetails(appealCaseKey);

    if (listAppellantConcernRoleIDDetails.listDtls.dtls.size() > 1) {

      // concatenate appellant's name
      final StringBuffer appellantsName = new StringBuffer();

      for (int i = 0; i < listAppellantConcernRoleIDDetails.listDtls.dtls
        .size(); i++) {
        if (i > 0) {
          appellantsName.append(kDelimiter);
        }
        appellantsName.append(listAppellantConcernRoleIDDetails.listDtls.dtls
          .item(i).concernRoleName);
      }
      appealCommunicationAppealDetails.appellantName =
        appellantsName.toString();

    }

    // get transcript details
    final AppealCommunicationTranscriptDetails appealCommunicationTranscriptDetails =
      appealCommunicationObj.getTranscriptDetails(appealCaseKey);

    // assign appeal details
    transcriptLetterData.assign(appealCommunicationAppealDetails);

    // assign transcript details
    transcriptLetterData.scheduledDate =
      appealCommunicationTranscriptDetails.scheduledDate.toString();

    // add details to XML Document
    xmlDocumentObj.add(transcriptLetterData);

    // create an XML string
    dataSetData.dataSetData = xmlDocumentObj.toString();

    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for schedule notices for rescheduled hearings
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetRescheduleNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    ScheduleHearingData scheduleHearingData;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;
    scheduleHearingData =
      appealCommunicationObj
        .getScheduleNoticeDetails(appealCommunicationParticipantKey);

    // Set schedule string
    final AppException rescheduledTo =
      new AppException(
        curam.message.BPOAPPEALPROFORMADOCUMENTGENERATION.INF_RESCHEDULED_TO);

    scheduleHearingData.scheduleString = rescheduledTo.getMessage();

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add data to document
    documentObj.add(scheduleHearingData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for schedule notices for continued hearings
   * 
   * @param key Unique internal reference number for the participant
   * 
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetContinuedNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    ScheduleHearingData scheduleHearingData;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;
    scheduleHearingData =
      appealCommunicationObj
        .getScheduleNoticeDetails(appealCommunicationParticipantKey);

    // Set schedule string
    final AppException continuedTo =
      new AppException(
        curam.message.BPOAPPEALPROFORMADOCUMENTGENERATION.INF_CONTINUED_TO);

    scheduleHearingData.scheduleString = continuedTo.getMessage();

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add data to document
    documentObj.add(scheduleHearingData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a data set stream for a single appeal request receipt
   * 
   * @param key Unique internal reference number for the appealed case
   * @return An XML stream for the data set
   */
  @Override
  protected DataSetData getDataSetSingleRequestReceiptData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set return object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Set AppealCaseID with AppealRelationship objects
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKeyEntity =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    appealRelationshipKeyEntity.appealRelationshipID = key.dataSetPrimaryKey;
    final AppealCaseID appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKeyEntity);

    // Struct for finding participantRoleID
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    caseParticipantRoleCaseAndTypeKey.caseID = appealCaseID.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // Search for participant role details from case participant role object.
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check for non returned
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      // Set participant role ID
      appealCommunicationParticipantKey.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;

    }

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    // Set appealRelationshipKey
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();

    appealRelationshipKey.appealRelationshipID = key.dataSetPrimaryKey;

    // get the receipt details
    final AppealCommunicationReceiptDetails appealCommunicationReceiptDetails =
      appealCommunicationObj.getReceiptDetails(appealRelationshipKey);

    // Assign struct details to data struct
    final AppealReceiptData appealReceiptData = new AppealReceiptData();

    appealReceiptData.assign(appealCommunicationAppealDetails);
    appealReceiptData.assign(appealCommunicationReceiptDetails);

    // Add all the receipt data to XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    documentObj.add(appealReceiptData);

    // Retrieve XML stream for data set and return
    dataSetData.dataSetData = documentObj.toString();
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the appealed case rejection notices.
   * 
   * @param key Data set key
   * @return Data set
   */
  @Override
  protected DataSetData getDataSetAppealedCaseRejectionNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // to be returned
    final DataSetData dataSetData = new DataSetData();

    // AppealCaseRejection object and manipulation variables
    final AppealedCaseRejectData appealedCaseRejectData =
      new AppealedCaseRejectData();

    // Appeal object and manipulation variables
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // AppealCommunication object and manipulation variables
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();
    AppealCommunicationAppealedCaseRejectDetails appealCommunicationAppealedCaseRejectDetails;
    AppealCommunicationAppealDetails appealCommunicationAppealDetails;

    // AppealRelationship object and manipulation variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    AppealCaseIDAndAppellantType appealCaseIDAndAppellantType;

    // Communication helper objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Create XML document object
    final XMLDocument xmlDocumentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // data to be added to XML Document
    final AppealedCaseRejectionNoticeData appealedCaseRejectionNoticeData =
      new AppealedCaseRejectionNoticeData();

    // Determine case ID and appellant type
    appealRelationshipKey.appealRelationshipID = key.dataSetPrimaryKey;
    appealCaseIDAndAppellantType =
      appealRelationshipObj
        .readAppealCaseIDAndAppellantType(appealRelationshipKey);

    appealCaseIDKey.caseID = appealCaseIDAndAppellantType.appealCaseID;

    // Appellant is not the organization
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    caseParticipantRoleCaseAndTypeKey.caseID = appealCaseIDKey.caseID;

    // get the active participant for the case
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    appealCommunicationParticipantKey.caseParticipantRoleID =
      caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;

    // read appeal details
    appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    // assign appeal details
    appealedCaseRejectionNoticeData.assign(appealCommunicationAppealDetails);

    // set case ids to get the appealed case rejection details
    appealedCaseRejectData.appealCaseID =
      appealCommunicationAppealDetails.appealCaseID;
    appealedCaseRejectData.caseID = appealCaseIDAndAppellantType.caseID;
    appealedCaseRejectData.appealRelationshipID = key.dataSetPrimaryKey;

    // read reject details for the appealed case
    appealCommunicationAppealedCaseRejectDetails =
      appealCommunicationObj
        .getAppealedCaseRejectDetails(appealedCaseRejectData);

    // assign appealed case details
    appealedCaseRejectionNoticeData
      .assign(appealCommunicationAppealedCaseRejectDetails);

    // add details to XML Document
    xmlDocumentObj.add(appealedCaseRejectionNoticeData);

    // create an XML string
    dataSetData.dataSetData = xmlDocumentObj.toString();

    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the Hearing attendance cancellation notices.
   * 
   * @param key Data set key
   * @return Data set
   */

  @Override
  public DataSetData getDataSetAttendanceCancellationNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();
    ScheduleHearingData scheduleHearingData;
    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // Get schedule data
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;
    scheduleHearingData =
      appealCommunicationObj
        .getScheduleNoticeDetails(appealCommunicationParticipantKey);

    // Set schedule string
    final AppException scheduledFor =
      new AppException(
        curam.message.BPOAPPEALPROFORMADOCUMENTGENERATION.INF_SCHEDULED_FOR);

    scheduleHearingData.scheduleString = scheduledFor.getMessage();

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add data to document
    documentObj.add(scheduleHearingData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the data set for the Hearing adjournment notices.
   * 
   * @param key Data set key
   * @return adjournment data set
   */

  @Override
  public DataSetData getDataSetAdjournmentNoticeData(
    final DataSetPrimaryKey key) throws AppException, InformationalException {

    // Data set object
    final DataSetData dataSetData = new DataSetData();

    // Appeal Communication objects
    final AppealCommunication appealCommunicationObj =
      AppealCommunicationFactory.newInstance();

    final AppealCommunicationParticipantKey appealCommunicationParticipantKey =
      new AppealCommunicationParticipantKey();

    // key to lookup adjournment details
    final HearingIDHearingCaseID hearingIDHearingCaseID =
      new HearingIDHearingCaseID();

    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // the primary id is the appellant id
    appealCommunicationParticipantKey.caseParticipantRoleID =
      key.dataSetPrimaryKey;

    // Get the appeal data
    final AppealCommunicationAppealDetails appealCommunicationAppealDetails =
      appealCommunicationObj
        .getAppealDetails(appealCommunicationParticipantKey);

    appealCaseIDKey.caseID = appealCommunicationAppealDetails.appealCaseID;

    // get the adjournment details
    hearingIDHearingCaseID.hearingCaseID =
      appealCommunicationAppealDetails.appealCaseID;
    hearingIDHearingCaseID.hearingID =
      appealCommunicationAppealDetails.hearingID;

    final AppealCommunicationAdjournmentDetails appealCommunicationAdjourmentDetails =
      appealCommunicationObj.getAdjournmentDetails(hearingIDHearingCaseID);

    // Assign struct details to data struct
    final AdjournmentNoticeData adjournmentNoticeData =
      new AdjournmentNoticeData();

    adjournmentNoticeData.assign(appealCommunicationAppealDetails);
    adjournmentNoticeData.assign(appealCommunicationAdjourmentDetails);

    // map date to string
    adjournmentNoticeData.adjournedDate =
      appealCommunicationAdjourmentDetails.adjournedDate.toString();

    // BEGIN, CR00021655, RKi
    adjournmentNoticeData.adjournedReasonText =
      appealCommunicationAdjourmentDetails.adjournedReasonCode;
    adjournmentNoticeData.statementSubmissionDate =
      appealCommunicationAppealDetails.issueDate;
    // END, CR00021655

    // Create XML document object
    final XMLDocument documentObj =
      new XMLDocument(XMLEncodingConstants.kEncodeUTF8);

    // Add to the document
    documentObj.add(adjournmentNoticeData);

    // Retrieve XML stream for data set
    dataSetData.dataSetData = documentObj.toString();

    // Return data set stream
    return dataSetData;

  }

}
