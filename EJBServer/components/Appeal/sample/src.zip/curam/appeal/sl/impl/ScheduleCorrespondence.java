/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005, 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.ThirdParty;
import curam.appeal.sl.entity.struct.HearingDtls;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingInterpreterNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingRepresentativeNameParticipantDetailsList;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterHearingKey;
import curam.appeal.sl.entity.struct.HearingStatusDetails;
import curam.appeal.sl.entity.struct.HearingWitnessNameAndParticipantDetailsList;
import curam.appeal.sl.entity.struct.PostponedHearingCaseKey;
import curam.appeal.sl.entity.struct.ThirdPartyDtls;
import curam.appeal.sl.entity.struct.ThirdPartyKeyList;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.IsSufficientTimeForCorrespondence;
import curam.appeal.sl.struct.ScheduleHearingDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import java.util.ArrayList;
import java.util.List;

/**
 * Maintains business process functionality for creating notices for scheduled
 * hearings or hearing reviews.
 */
public abstract class ScheduleCorrespondence extends
  curam.appeal.sl.base.ScheduleCorrespondence {

  // ___________________________________________________________________________
  /**
   * Creates a notice for the appellant on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createAppellantHearingNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // InformationalManager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // CaseParticipantRole object and manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = dtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // search for appellant
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // BEGIN, CR CR00069031, NSP
        final Person person = PersonFactory.newInstance();
        final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
        // BEGIN, CR00236272, AK
        SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

        searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        searchCaseDetails = person.searchCase1(searchCaseKey_fo);
        // END, CR00236272
        // Check if the appellant is associated with any case or not and den set
        // document code accordingly
        if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() > 0) {
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULELOCATIONAPPELLANT;
        } else {
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULELOCATIONWITHOUTAIDSTATUSAPPELLANT;
        }
        // END, CR CR00069031

      } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEHOMEAPPELLANT;

      } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEPHONEAPPELLANT;

      } else if (dtls.typeCode.equals(HEARINGTYPE.DESK)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEDESKAPPELLANT;

      } else {
        // No Associated document for hearing type
        informationalManager.addInformationalMsg(new AppException(
          BPOSCHEDULECORRESPONDENCE.ERR_NO_DOCUMENT_FOR_HEARING_TYPE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

      // Throw exceptions for any validation errors found
      informationalManager.failOperation();

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a notice for the appellant on the hearing review case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createAppellantHearingReviewNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = dtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // search for appellant
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;

      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // BEGIN, CR CR00066777, NSP
      final Person person = PersonFactory.newInstance();
      final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
      // BEGIN, CR00236272, AK
      SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

      searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      searchCaseDetails = person.searchCase1(searchCaseKey_fo);
      // END, CR00236272

      // Check if the appellant is associated with any case or not and den set
      // document code accordingly
      if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() > 0) {
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEREVIEWAPPELLANT;
      } else {
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEREVIEWWITHOUTAIDSTATUSAPPELLANT;
      }
      // END, CR CR00066777

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;

      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key and document
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates notices for the interpreters on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createInterpreterHearingNotices(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // Hearing Service Supplier object and manipulation variables
    final curam.appeal.sl.entity.intf.HearingServiceSupplier hearingServiceSupplierObj =
      curam.appeal.sl.entity.fact.HearingServiceSupplierFactory.newInstance();

    final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
      new HearingServiceSupplierInterpreterHearingKey();

    HearingInterpreterNameParticipantDetailsList hearingInterpreterNameParticipantDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    hearingServiceSupplierInterpreterHearingKey.hearingID =
      key.hearingKey.hearingID;
    hearingServiceSupplierInterpreterHearingKey.recordStatus =
      RECORDSTATUS.NORMAL;
    hearingServiceSupplierInterpreterHearingKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    // Search for interpreters
    hearingInterpreterNameParticipantDetailsList =
      hearingServiceSupplierObj
        .searchActiveInterpreterNameAndCaseParticipantByHearingID(hearingServiceSupplierInterpreterHearingKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < hearingInterpreterNameParticipantDetailsList.dtls
      .size(); i++) {

      if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULELOCATIONINTERPRETER;

      } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEHOMEINTERPRETER;

      } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEPHONEINTERPRETER;

      }

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).fullName;

      // Create the communication
      concernRoleKey.concernRoleID =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).participantRoleID;

      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingInterpreterNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates notices for the representatives on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  protected void createRepresentativeHearingNotices(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // InformationalManager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Hearing Representative entity and manipulation variables
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeNameParticipantDetailsList hearingRepresentativeNameParticipantDetailsList;

    // Hearing Representative business object and manipulation variables
    hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // search for representatives
    hearingRepresentativeNameParticipantDetailsList =
      hearingRepresentativeObj
        .searchActiveHearingRepNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHR);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;
      }
    } catch (final RecordNotFoundException e) {
      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;
    }

    for (int i = 0; i < hearingRepresentativeNameParticipantDetailsList.dtls
      .size(); i++) {

      if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULELOCATIONREP;

      } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEHOMEREP;

      } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEPHONEREP;
      } else if (dtls.typeCode.equals(HEARINGTYPE.DESK)) {

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALSCHEDULEDESKREP;

      } else {
        // No Associated document for hearing type
        informationalManager.addInformationalMsg(new AppException(
          BPOSCHEDULECORRESPONDENCE.ERR_NO_DOCUMENT_FOR_HEARING_TYPE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

      // Set up communication details
      communicationDetails.concernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      communicationDetails.caseID = dtls.caseID;

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).fullName;

      // Create the communication
      concernRoleKey.concernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

      // Throw exceptions for any validation errors found
      informationalManager.failOperation();
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates notices for the representatives on the hearing review case for
   * which a hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  protected void createRepresentativeHearingReviewNotices(
    final HearingKey key, final ScheduleHearingDetails dtls)
    throws AppException, InformationalException {

    // Hearing Representative entity and manipulation variables
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeNameParticipantDetailsList hearingRepresentativeNameParticipantDetailsList;

    // Hearing Representative business object and manipulation variables
    hearingIDStatusKeyHR.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // search for representatives
    hearingRepresentativeNameParticipantDetailsList =
      hearingRepresentativeObj
        .searchActiveHearingRepNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHR);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < hearingRepresentativeNameParticipantDetailsList.dtls
      .size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).fullName;

      // Create the communication
      concernRoleKey.concernRoleID =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).participantRoleID;

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      // BEGIN, CR00132817, RKi
      // Set data set key and document
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingRepresentativeNameParticipantDetailsList.dtls.item(i).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEREVIEWREP;
      // END, CR00132817

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a notice for the third party on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  protected void createThirdPartyHearingNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    caseParticipantRoleCaseAndTypeKey.caseID = dtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    // search for third party
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    // Read Third Parties for which notice has to be sent
    final List thirdPartiesList = new ArrayList();

    // Hearing Service Layer Object
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingKey.hearingID = key.hearingKey.hearingID;

    // ThirdParty Service Layer Object
    final ThirdParty thirdParty = ThirdPartyFactory.newInstance();

    // List of active Third Parties for the Hearing
    final ThirdPartyKeyList thirdPartyKeyList =
      thirdParty.searchThirdPartyByHearingID(hearingKey);

    for (int i = 0; i < thirdPartyKeyList.dtls.size(); i++) {
      final ThirdPartyDtls thirdPartyDtls =
        thirdParty.read(thirdPartyKeyList.dtls.item(i));

      // If attendance required, then only need to send the notice
      if (thirdPartyDtls.attendanceRequired) {
        thirdPartiesList.add(new Long(thirdPartyDtls.caseParticipantRoleID));
      }
    }

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      final Long caseParticipantRoleID =
        new Long(
          caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID);

      // If ThirdParty has attendance required then send notice
      if (thirdPartiesList.contains(caseParticipantRoleID)) {

        if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULELOCATIONTHIRDPARTY;

        } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULEHOMETHIRDPARTY;

        } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULEPHONETHIRDPARTY;

        }

        communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
        communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
        communicationDetails.communicationDate =
          curam.util.type.Date.getCurrentDate();
        communicationDetails.correspondentConcernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
        // BEGIN, CR00202766, MC
        // correspondentTypeCode is not a mandatory entity field only set it if
        // the
        // correspondence is going to the primary client
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = dtls.caseID;

        if (CaseHeaderFactory.newInstance().readParticipantRoleID(
          caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
          communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
        }
        // END, CR00202766
        communicationDetails.userName =
          curam.util.transaction.TransactionInfo.getProgramUser();
        communicationDetails.subjectText =
          BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
            .getMessageText();
        communicationDetails.communicationText =
          GeneralAppealConstants.kSpace;

        communicationDetails.correspondentName =
          caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

        // Create the communication
        concernRoleKey.concernRoleID =
          caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;

        final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
          new curam.util.xml.struct.XSLTemplateIDCodeKey();

        xslTemplateIDCodeKey.templateIDCode =
          generateDocumentDetails.dtls.documentIDCode;
        xslTemplateIDCodeKey.localeIdentifier =
          TransactionInfo.getProgramLocale();

        final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
          curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

        final XSLTemplateInstanceKey xslTemplateInstanceKey =
          xslTemplateUtilityObj
            .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

        proFormaCommDetails.assign(communicationDetails);
        proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
        proFormaCommDetails.proFormaVersionNo =
          xslTemplateInstanceKey.templateVersion;
        proFormaCommDetails.addressID =
          concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
        proFormaCommDetails.caseID = dtls.caseID;
        // BEGIN, CR00293187, CD
        generateDocumentDetails.communicationID =
          communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

        // Set data set key
        generateDocumentDetails.dtls.dataSetPrimaryKey =
          caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

        // Generate the document
        appealProFormaDocumentGenerationObj
          .createConcernRoleProFormaDoc(generateDocumentDetails);
        // END, CR00293187
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a notice for the third party on the hearing review case for which
   * a hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createThirdPartyHearingReviewNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    caseParticipantRoleCaseAndTypeKey.caseID = dtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    // search for third party
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;

      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // BEGIN, CR00132817, RKi
      // Set data set key and document
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEREVIEWTHIRDPARTY;
      // END, CR00132817

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates notices for the witnesses on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  protected void createWitnessHearingNotices(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // Hearing Witness entity and manipulation variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    final HearingIDStatusKeyHW hearingIDStatusKeyHW =
      new HearingIDStatusKeyHW();
    HearingWitnessNameAndParticipantDetailsList hearingWitnessNameAndParticipantDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    hearingIDStatusKeyHW.hearingID = key.hearingKey.hearingID;
    hearingIDStatusKeyHW.recordStatus = RECORDSTATUS.NORMAL;

    // search for witnesses
    hearingWitnessNameAndParticipantDetailsList =
      hearingWitnessObj
        .searchActiveHearingWitnessNameAndCaseParticipantRoleByHearingID(hearingIDStatusKeyHW);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < hearingWitnessNameAndParticipantDetailsList.dtls
      .size(); i++) {

      if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // If witness is voluntary
        if (hearingWitnessNameAndParticipantDetailsList.dtls.item(i).voluntaryIndicator) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULELOCATIONWITNESS;

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
              .getMessageText();

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

        } else {

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
              .getMessageText();

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSUBPOENALOCATION;

        }

      } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

        // If witness is voluntary
        if (hearingWitnessNameAndParticipantDetailsList.dtls.item(i).voluntaryIndicator) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULEHOMEWITNESS;

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
              .getMessageText();

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

        } else {

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
              .getMessageText();

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSUBPOENAHOME;

        }

      } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {

        // If witness is voluntary
        if (hearingWitnessNameAndParticipantDetailsList.dtls.item(i).voluntaryIndicator) {

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSCHEDULEPHONEWITNESS;

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
              .getMessageText();

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

        } else {

          // Set communication subject
          communicationDetails.subjectText =
            BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
              .getMessageText();

          // Set communication type
          communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

          // Set document code
          generateDocumentDetails.dtls.documentIDCode =
            TEMPLATEIDCODE.APPEALSUBPOENAPHONE;

        }

      }

      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).fullName;

      // Create the communication
      concernRoleKey.concernRoleID =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).participantRoleID;

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingWitnessNameAndParticipantDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }

  }

  // Start CR00117296 LP
  /**
   * Creates notices for the participants on the hearing case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  protected void createparticipantHearingNotices(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // START CR00132747 LP
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hearingKey.hearingID = key.hearingKey.hearingID;
    final HearingDtls hearingDtls = hearingObj.read(hearingKey);

    final CaseParticipantRole_eoCaseIDKey caseParticipantRole_eoCaseIDKey =
      new CaseParticipantRole_eoCaseIDKey();

    caseParticipantRole_eoCaseIDKey.caseID = hearingDtls.caseID;

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList =
      CaseParticipantRoleFactory.newInstance().searchByCaseID(
        caseParticipantRole_eoCaseIDKey);
    // END CR00132747
    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < caseParticipantRoleDtlsList.dtls.size(); i++) {
      // START CR00132747 LP
      // only participants and petitioner will get the correspondence
      if (!(caseParticipantRoleDtlsList.dtls.item(i).typeCode
        .equals(CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT) || caseParticipantRoleDtlsList.dtls
        .item(i).typeCode.equals(CASEPARTICIPANTROLETYPE.LEGALPETITIONER))) {
        continue;
      }
      // END CR00132747 LP
      if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)) {

        // Set communication type
        communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

        // Set communication subject
        communicationDetails.subjectText =
          BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
            .getMessageText();

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.LALEGALACTIONSUBPOENALOCATION;

      } else if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

        // Set communication type
        communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

        // Set communication subject
        communicationDetails.subjectText =
          BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
            .getMessageText();

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.LALEGALACTIONSUBPOENAPHONE;

      } else if (dtls.typeCode.equals(HEARINGTYPE.PHONE)) {

        // Set communication subject
        communicationDetails.subjectText =
          BPOSCHEDULECORRESPONDENCE.INF_HEARING_SUBPOENA_NOTICE
            .getMessageText();

        // Set communication type
        communicationDetails.typeCode = COMMUNICATIONTYPE.SUBPOENA;

        // Set document code
        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.LALEGALACTIONSCHEDULEPHONE;

      }

      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleDtlsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      // START CR00132747 LP
      concernRoleKey.concernRoleID =
        caseParticipantRoleDtlsList.dtls.item(i).participantRoleID;

      communicationDetails.correspondentName =
        concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      // END CR00132747 LP
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00269511, JAF
      proFormaCommDetails.localeIdentifier =
        xslTemplateIDCodeKey.localeIdentifier;
      // END, CR00269511, JAF

      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set data set key
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleDtlsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // End CR00117296 LP

  // ___________________________________________________________________________
  /**
   * Creates all notices for the relevant parties for the hearing notifying
   * them of the scheduled hearing details.
   * 
   * @param key Hearing unique identification
   * @param dtls Hearing details
   * @return Informational message list
   */
  @Override
  public InformationalMsgDtlsList createNotices(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // Hearing business object and manipulation variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondence;

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    final HearingTimeDetails hearingTimeDetails = new HearingTimeDetails();

    hearingTimeDetails.scheduledDateTime = dtls.scheduledDateTime;

    // Check for sufficient time for correspondence
    isSufficientTimeForCorrespondence =
      hearing_boObj.isSufficientTimeForCorrespondence(hearingTimeDetails);

    // If there is sufficient time
    if (isSufficientTimeForCorrespondence.isSufficientTime) {

      // Send hearing review notices
      if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        createRepresentativeHearingReviewNotices(key, dtls);
        createThirdPartyHearingReviewNotice(key, dtls);
        createAppellantHearingReviewNotice(key, dtls);
        createRespondentHearingReviewNotice(key, dtls);

      } else {

        // Send hearing case notices
        createRepresentativeHearingNotices(key, dtls);
        createInterpreterHearingNotices(key, dtls);
        createThirdPartyHearingNotice(key, dtls);
        createAppellantHearingNotice(key, dtls);
        createWitnessHearingNotices(key, dtls);
        // BEGIN CR00118512 LP
        createparticipantHearingNotices(key, dtls);
        // End CR00118512 LP
      }

    } else {

      // If there is not enough time, inform the user
      final LocalisableString insufficientTime =
        new LocalisableString(BPOSCHEDULECORRESPONDENCE.ERR_TIME_INSUFFICIENT);

      final InformationalManager informationalManager =
        new InformationalManager();

      informationalManager.addInformationalMsg(insufficientTime,
        curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);

      final String[] warnings =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls =
          new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

      }

    }

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Creates a notice for the respondent on the hearing review case for which a
   * hearing has been scheduled.
   * 
   * @param key Unique internal reference number for the hearing
   * @param dtls Hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createRespondentHearingReviewNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // CaseParticipantRole object and manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDetails hearingStatusDetails;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = dtls.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    // search for respondent
    caseParticipantRoleNameDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Read latest postponed hearing status
    final PostponedHearingCaseKey postponedHearingCaseKey =
      new PostponedHearingCaseKey();

    postponedHearingCaseKey.caseID = dtls.caseID;

    try {
      hearingStatusDetails =
        hearingObj.readLatestPostponedStatusByCase(postponedHearingCaseKey);

      if (hearingStatusDetails.statusCode.equals(HEARINGSTATUS.CONTINUED)) {

        // Hearing was continued, so use continued notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.CONTINUED_SCHEDULE_NOTICE;

      } else if (hearingStatusDetails.statusCode
        .equals(HEARINGSTATUS.RESCHEDULED)) {

        // Hearing was rescheduled, so use reschedule notice data set
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.RESCHEDULED_SCHEDULE_NOTICE;

      }
    } catch (final RecordNotFoundException e) {

      // There are no postponed hearings, so use standard schedule notice
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;

    }

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate =
        curam.util.type.Date.getCurrentDate();
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = dtls.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        BPOSCHEDULECORRESPONDENCE.INF_HEARING_SCHEDULE_NOTICE
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;

      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // BEGIN, CR00132817, RKi
      // Set data set key and document
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEREVIEWRESPOND;
      // END, CR00132817

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        generateDocumentDetails.dtls.documentIDCode;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = dtls.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a hearing schedule notice for the respondent on the hearing case.
   * 
   * @param key The hearing identifier
   * @param dtls The scheduling details for the hearing
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void createRespondentHearingCaseNotice(final HearingKey key,
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {// do nothing

  }

}
