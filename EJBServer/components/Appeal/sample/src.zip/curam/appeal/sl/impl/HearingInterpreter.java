/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingServiceSupplierFactory;
import curam.appeal.sl.entity.intf.HearingServiceSupplier;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingDateAndType;
import curam.appeal.sl.entity.struct.HearingInterpreterNameUserRoleDetails;
import curam.appeal.sl.entity.struct.HearingInterpreterNameUserRoleDetailsList;
import curam.appeal.sl.entity.struct.HearingInterpreterParticipantDetails;
import curam.appeal.sl.entity.struct.HearingInterpreterUserDetails;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingServiceSupplierDtls;
import curam.appeal.sl.entity.struct.HearingServiceSupplierIDKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterHearingKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierKey;
import curam.appeal.sl.entity.struct.HearingStatusDateTypeDetails;
import curam.appeal.sl.entity.struct.HearingStatusDetails;
import curam.appeal.sl.entity.struct.HearingSupplierIDTypeDetails;
import curam.appeal.sl.entity.struct.HearingSupplierIDTypeDetailsList;
import curam.appeal.sl.entity.struct.ParticipationAndHearingKeyDetails;
import curam.appeal.sl.entity.struct.SupplierLinkIDAndHearingIDKey;
import curam.appeal.sl.entity.struct.SupplierTypeDetails;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.CancelInterpreterKey;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateHearingInterpreterDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingInterpreterNoticeDetails;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.InterpreterDetails;
import curam.appeal.sl.struct.IsSufficientTimeForCorrespondence;
import curam.appeal.sl.struct.ListInterpreterDetails;
import curam.appeal.sl.struct.ListInterpreterKey;
import curam.appeal.sl.struct.ModifyInterpreterDetails;
import curam.appeal.sl.struct.ReadHearingInterpreterDetails;
import curam.appeal.sl.struct.ReadHearingInterpreterKey;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALSUPPLIERTYPE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.INTERPRETERTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.CancelCaseParticipantRoleDetails;
import curam.core.sl.entity.struct.CaseParticipantConcernRoleDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseUserRoleDtls;
import curam.core.sl.entity.struct.CaseUserRoleKey;
import curam.core.sl.entity.struct.CaseUserRoleStatusDetails;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.TypeAndStatusAndParticipantRoleDetails;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.UsersKey;
import curam.message.BPOHEARINGINTERPRETER;
import curam.message.BPOHEARINGSERVICESUPPLIER;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Hearing Interpreter
 * service layer.
 * 
 */
public abstract class HearingInterpreter extends
  curam.appeal.sl.base.HearingInterpreter {

  // ___________________________________________________________________________
  /**
   * Sends a hearing schedule notice to an interpreter.
   * 
   * @param dtls The hearing notice details
   * @return Any informational messages
   */
  @Override
  public InformationalMsgDtlsList sendNotice(
    final HearingInterpreterNoticeDetails dtls) throws AppException,
    InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Concern role objects
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleNameDetails concernRoleNameDetails;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingDateAndType hearingDateAndType;

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Case Participant Role objects
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantConcernRoleDetails caseParticipantConcernRoleDetails;

    // Read the case for the hearing
    hearingKey_bo.hearingKey.hearingID =
      dtls.hearingSSLinkAndTypeDetails.hearingID;

    // Read participant role ID
    caseParticipantRole_eoKey.caseParticipantRoleID =
      dtls.hearingSSLinkAndTypeDetails.supplierLinkID;
    caseParticipantConcernRoleDetails =
      caseParticipantRole_eoObj
        .readParticipantRoleDetails(caseParticipantRole_eoKey);

    communicationDetails.subjectText =
      curam.message.BPOHEARINGINTERPRETER.INF_HEARING_NOTICE.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.correspondentConcernRoleID =
      caseParticipantConcernRoleDetails.concernRoleID;

    communicationDetails.concernRoleID =
      caseParticipantConcernRoleDetails.concernRoleID;
    communicationDetails.concernRoleType =
      caseParticipantConcernRoleDetails.concernRoleType;
    communicationDetails.typeCode = curam.codetable.COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode =
      curam.codetable.COMMUNICATIONMETHOD.HARDCOPY;

    // Get correspondent name
    concernRoleKey.concernRoleID =
      caseParticipantConcernRoleDetails.concernRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName =
      systemUser.getSystemUserDetails().userName;

    // Read hearing type
    hearingKey.hearingID = dtls.hearingSSLinkAndTypeDetails.hearingID;
    hearingDateAndType = hearingObj.readScheduledDateAndType(hearingKey);

    // is hearing type location?
    if (hearingDateAndType.typeCode.equals(HEARINGTYPE.LOCATION)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULELOCATIONINTERPRETER;

    } // is hearing type phone?
    else if (hearingDateAndType.typeCode.equals(HEARINGTYPE.PHONE)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEPHONEINTERPRETER;

    } // if here - must be home
    else if (hearingDateAndType.typeCode.equals(HEARINGTYPE.HOME)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEHOMEINTERPRETER;

    }

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      generateDocumentDetails.dtls.documentIDCode;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // Set data set key and type
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      dtls.hearingSSLinkAndTypeDetails.supplierLinkID;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a hearing interpreter
   * 
   * @param key The key of the interpreter to cancel
   */
  @Override
  public void cancel(final CancelInterpreterKey key) throws AppException,
    InformationalException {

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    SupplierTypeDetails supplierTypeDetails = new SupplierTypeDetails();
    final HearingServiceSupplierKey hearingServiceSupplierKey =
      new HearingServiceSupplierKey();
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read the hearing ID
    hearingServiceSupplierKey.hearingServiceSupplierID =
      key.hearingServiceSupplierID;
    hearingKeyDetails =
      hearingServiceSupplierObj.readHearing(hearingServiceSupplierKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateCancel(key);

    hearingServiceSupplierKey.hearingServiceSupplierID =
      key.hearingServiceSupplierID;

    // Read type and supplier link id by hearing service supplier id
    supplierTypeDetails =
      hearingServiceSupplierObj
        .readTypeAndSupplierLinkID(hearingServiceSupplierKey);

    // Check to see if the type is third party.
    if (supplierTypeDetails.supplierType
      .equals(curam.codetable.APPEALSUPPLIERTYPE.PARTICIPANT)) {

      // Case participant role variables
      final CaseParticipantRole caseParticipantRole_eoObj =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleKey caseParticipantRole_eoKey =
        new CaseParticipantRoleKey();
      final CancelCaseParticipantRoleDetails cancelCaseParticipantRoleDetails =
        new CancelCaseParticipantRoleDetails();

      // Populate variables needed for modify record status
      caseParticipantRole_eoKey.caseParticipantRoleID =
        supplierTypeDetails.supplierLinkID;
      cancelCaseParticipantRoleDetails.recordStatus =
        curam.codetable.RECORDSTATUS.CANCELLED;
      cancelCaseParticipantRoleDetails.versionNo = key.linkVersionNo;

      // Set the record status to canceled.
      caseParticipantRole_eoObj.modifyRecordStatus(caseParticipantRole_eoKey,
        cancelCaseParticipantRoleDetails);

    } else if (supplierTypeDetails.supplierType
      .equals(APPEALSUPPLIERTYPE.USER)) {

      final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
      final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();

      caseUserRoleKey.caseUserRoleID = supplierTypeDetails.supplierLinkID;
      caseUserRoleObj.closeCaseUserRole(caseUserRoleKey);

    } else {

      throw new AppException(
        curam.message.BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_SUPPLIERTYPE_NOT_KNOWN);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to insert a hearing interpreter
   * 
   * @param details The details of the interpreter to insert
   * @return Any informational messages
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public InformationalMsgDtlsList insert(
    final CreateHearingInterpreterDetails details) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingTimeDetails hearingTimeDetails = new HearingTimeDetails();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingScheduleDate hearingScheduleDate = new HearingScheduleDate();
    HearingStatusDateTypeDetails hearingStatusDateTypeDetails =
      new HearingStatusDateTypeDetails();

    // Unique object variable
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Hearing Service Supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierDtls hearingServiceSupplierDtls =
      new HearingServiceSupplierDtls();

    // Hearing Interpreter variables
    final HearingInterpreterNoticeDetails hearingInterpreterNoticeDetails =
      new HearingInterpreterNoticeDetails();
    IsSufficientTimeForCorrespondence isSufficientTimeForCorrespondence =
      new IsSufficientTimeForCorrespondence();

    // Hearing representative variables
    final Representative representativeObj =
      RepresentativeFactory.newInstance();
    final RepresentativeRegistrationDetails representativeRegistrationDetails =
      new RepresentativeRegistrationDetails();

    AppException subjectText;

    // Notification variables
    final Notification notificationObj = NotificationFactory.newInstance();

    // Current date
    final Date currentDate = Date.getCurrentDate();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      details.hearingServiceSupplier.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateInsert(details);

    // Has the user/participant been registered?
    // If the Interpreter ID is empty, than it has not already been
    // Registered.
    if (StringUtil.isNullOrEmpty(details.interpreterID)) {

      // Populate representative details
      representativeRegistrationDetails.representativeDtls.comments =
        details.hearingServiceSupplier.comments;
      representativeRegistrationDetails.representativeDtls.representativeName =
        details.fullName;

      // use participant role code table if participant.
      representativeRegistrationDetails.representativeRegistrationDetails.addressData =
        details.addressData;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode =
        details.phoneAreaCode;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber =
        details.phoneNumber;

      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate =
        currentDate;

      representativeRegistrationDetails.representativeDtls.representativeType =
        REPRESENTATIVETYPE.INTERPRETER;

      representativeObj
        .registerRepresentative(representativeRegistrationDetails);

      // update interpreterID
      details.interpreterID =
        new Long(
          representativeRegistrationDetails.representativeDtls.concernRoleID)
          .toString();

      // Case Participant Role variables
      final CaseParticipantRole caseParticipantRole_eoObj =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleDtls caseParticipantRoleDtls =
        new CaseParticipantRoleDtls();

      // Populate the case participant role entry
      caseParticipantRoleDtls.caseID = hearingCaseID.hearingCaseID.caseID;
      caseParticipantRoleDtls.comments =
        details.hearingServiceSupplier.comments;
      caseParticipantRoleDtls.fromDate = Date.getCurrentDate();

      // Participant role ID is the interpreter ID from the facade.
      // need to convert to long format
      caseParticipantRoleDtls.participantRoleID =
        new Long(details.interpreterID).longValue();

      caseParticipantRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
      caseParticipantRoleDtls.typeCode =
        curam.codetable.CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

      // Insert the case participant role
      caseParticipantRole_eoObj.insert(caseParticipantRoleDtls);

      // Specify the type of supplier to participant
      hearingServiceSupplierDtls.supplierType =
        APPEALSUPPLIERTYPE.PARTICIPANT;

      // Update the interpreter type to service supplier.
      details.interpreterType = INTERPRETERTYPE.SERVICESUPPLIER;

      // Update the hearing service supplier link id with the
      // newly created case participant role id.
      hearingServiceSupplierDtls.supplierLinkID =
        caseParticipantRoleDtls.caseParticipantRoleID;

    } else {

      // Can only ever be a participant or a user
      if (details.interpreterType
        .equals(curam.codetable.INTERPRETERTYPE.USER)) {

        // BEGIN, CR00177498, PM
        OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
        final OrgObjectLink orgObjectLinkObj =
          OrgObjectLinkFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = details.interpreterID;
        try {
          orgObjectLinkDtls = orgObjectLinkObj.readByUsername(usersKey);
        } catch (final RecordNotFoundException re) {
          orgObjectLinkDtls.userName = details.interpreterID;
          orgObjectLinkDtls.orgObjectType = ORGOBJECTTYPE.USER;
          orgObjectLinkObj.insert(orgObjectLinkDtls);
        }
        // END, CR00177498

        // Case User Role variables
        final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();
        final CaseUserRoleDtls caseUserRoleDtls = new CaseUserRoleDtls();

        // Add an entry to the case user role table
        caseUserRoleDtls.caseID = hearingCaseID.hearingCaseID.caseID;
        caseUserRoleDtls.caseUserRoleID = uniqueIDObj.getNextID();
        caseUserRoleDtls.comments = details.hearingServiceSupplier.comments;
        caseUserRoleDtls.fromDate = Date.getCurrentDate();

        caseUserRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
        caseUserRoleDtls.typeCode = CASEUSERROLETYPE.INTERPRETER;

        caseUserRoleDtls.orgObjectLinkID = orgObjectLinkDtls.orgObjectLinkID;

        // Insert case user role details
        caseUserRole.insert(caseUserRoleDtls);
        // END, CR00071911

        // Update the supplier link id with
        // the newly created case user role id
        hearingServiceSupplierDtls.supplierLinkID =
          caseUserRoleDtls.caseUserRoleID;

        // Specify the type of supplier to USER
        hearingServiceSupplierDtls.supplierType = APPEALSUPPLIERTYPE.USER;

      } else {

        // Case Participant Role variables
        final CaseParticipantRole caseParticipantRole_eoObj =
          CaseParticipantRoleFactory.newInstance();
        final CaseParticipantRoleDtls caseParticipantRoleDtls =
          new CaseParticipantRoleDtls();

        // Populate the case participant role entry
        caseParticipantRoleDtls.caseID = hearingCaseID.hearingCaseID.caseID;
        caseParticipantRoleDtls.comments =
          details.hearingServiceSupplier.comments;
        caseParticipantRoleDtls.fromDate = Date.getCurrentDate();

        // Participant role ID is the interpreter ID from the facade.
        // need to convert to long format
        caseParticipantRoleDtls.participantRoleID =
          new Long(details.interpreterID).longValue();

        caseParticipantRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
        caseParticipantRoleDtls.typeCode =
          curam.codetable.CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

        // Insert the case participant role
        caseParticipantRole_eoObj.insert(caseParticipantRoleDtls);

        // Specify the type of supplier to participant
        hearingServiceSupplierDtls.supplierType =
          APPEALSUPPLIERTYPE.PARTICIPANT;

        // Update the hearing service supplier link id with the
        // newly created case participant role id.
        hearingServiceSupplierDtls.supplierLinkID =
          caseParticipantRoleDtls.caseParticipantRoleID;

        // Update the concern role id
        representativeRegistrationDetails.representativeDtls.concernRoleID =
          new Long(details.interpreterID).longValue();

      }

    }

    // Insert an entry for the hearing service supplier.
    hearingServiceSupplierDtls.comments =
      details.hearingServiceSupplier.comments;
    hearingServiceSupplierDtls.hearingID =
      details.hearingServiceSupplier.hearingID;
    hearingServiceSupplierDtls.hearingServiceSupplierID =
      uniqueIDObj.getNextID();

    hearingServiceSupplierDtls.participatedCode =
      HEARINGPARTICIPATION.NOTHELD;

    // Insert the hearing service supplier
    hearingServiceSupplierObj.insert(hearingServiceSupplierDtls);

    hearingKey.hearingID = details.hearingServiceSupplier.hearingID;
    hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);

    hearingTimeDetails.hearingID = hearingKey.hearingID;
    hearingTimeDetails.scheduledDateTime =
      hearingScheduleDate.scheduledDateTime;

    isSufficientTimeForCorrespondence =
      hearing_boObj.isSufficientTimeForCorrespondence(hearingTimeDetails);

    if (isSufficientTimeForCorrespondence.isSufficientTime) {

      // Read the type code
      hearingStatusDateTypeDetails =
        hearingObj.readStatusAndDateAndType(hearingKey);

      hearingInterpreterNoticeDetails.hearingSSLinkAndTypeDetails.hearingID =
        details.hearingServiceSupplier.hearingID;

      hearingInterpreterNoticeDetails.hearingSSLinkAndTypeDetails.hearingServiceSupplierID =
        details.hearingServiceSupplier.hearingServiceSupplierID;
      hearingInterpreterNoticeDetails.hearingSSLinkAndTypeDetails.supplierLinkID =
        hearingServiceSupplierDtls.supplierLinkID;
      hearingInterpreterNoticeDetails.hearingSSLinkAndTypeDetails.supplierType =
        details.interpreterType;

      // If typeCode is phone
      if (hearingStatusDateTypeDetails.typeCode.equals(HEARINGTYPE.PHONE)) {

        // Set subject message
        subjectText =
          new AppException(
            curam.message.BPOHEARINGINTERPRETER.INF_HEARING_INTERPRETER_FV_PHONE_HEARING);

      } else if (hearingStatusDateTypeDetails.typeCode
        .equals(HEARINGTYPE.HOME)) {

        // Set subject message
        subjectText =
          new AppException(
            curam.message.BPOHEARINGINTERPRETER.INF_HEARING_INTERPRETER_FV_HOME_HEARING);

      } else {

        // Set subject message
        subjectText =
          new AppException(
            curam.message.BPOHEARINGINTERPRETER.INF_HEARING_INTERPRETER_FV_LOCATION_HEARING);

      }

      // Can only ever be a participant or a user
      if (details.interpreterType
        .equals(curam.codetable.INTERPRETERTYPE.USER)) {

        final StandardManualTaskDtls standardManualTaskDtls =
          new StandardManualTaskDtls();

        // Set Notification details
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          details.interpreterID;

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          hearingCaseID.hearingCaseID.caseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          subjectText.getMessage();
        standardManualTaskDtls.dtls.taskDtls.subject =
          curam.message.BPOHEARINGINTERPRETER.INF_HEARING_NOTICE
            .getMessageText();

        standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
          Appeal.kAppealNotificationTask;

        // Create notification
        notificationObj
          .createWorkAllocationNotification(standardManualTaskDtls);

      } else {

        informationalMsgDtlsList.dtls
          .addAll(sendNotice(hearingInterpreterNoticeDetails).dtls);

      }

    } else {

      if (!details.interpreterType
        .equals(curam.codetable.INTERPRETERTYPE.USER)) {

        final LocalisableString insufficientTime =
          new LocalisableString(
            BPOSCHEDULECORRESPONDENCE.ERR_TIME_INSUFFICIENT);

        final InformationalManager informationalManager =
          new InformationalManager();

        informationalManager.addInformationalMsg(insufficientTime,
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning);

        final String[] warnings =
          informationalManager.obtainInformationalAsString();

        for (int i = 0; i < warnings.length; i++) {

          final InformationalMsgDtls informationalMsgDtls =
            new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt = warnings[i];
          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

        }
      }

    }

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Method to list interpreters for standalone cases
   * 
   * @param key The details of the interpreter to insert
   * 
   * @return listInterpreterDetails The list of all interpreters for
   * a given hearing id.
   */
  @Override
  public ListInterpreterDetails list(final ListInterpreterKey key)
    throws AppException, InformationalException {

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    HearingSupplierIDTypeDetailsList hearingSupplierIDTypeDetailsList =
      new HearingSupplierIDTypeDetailsList();
    HearingSupplierIDTypeDetails hearingSupplierIDTypeDetails =
      new HearingSupplierIDTypeDetails();
    final SupplierLinkIDAndHearingIDKey supplierLinkIDAndHearingIDKey =
      new SupplierLinkIDAndHearingIDKey();

    // Interpreter variables
    final ListInterpreterDetails listInterpreterDetails =
      new ListInterpreterDetails();
    InterpreterDetails interpreterDetails;
    HearingInterpreterUserDetails hearingInterpreterUserDetails =
      new HearingInterpreterUserDetails();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Hearing variables
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // populate hearing key details
    hearingKeyDetails.hearingID = key.hearingID;

    hearingSupplierIDTypeDetailsList =
      hearingServiceSupplierObj
        .searchInterpreterByHearingID(hearingKeyDetails);

    // local variable to count the number of hearing suppliers.
    final int countInterpreter =
      hearingSupplierIDTypeDetailsList.dtls.items().length;

    // For each interpreter, read interpreter details
    for (int i = 0; i < countInterpreter; i++) {

      hearingSupplierIDTypeDetails =
        hearingSupplierIDTypeDetailsList.dtls.item(i);

      supplierLinkIDAndHearingIDKey.supplierLinkID =
        hearingSupplierIDTypeDetails.supplierLinkID;
      supplierLinkIDAndHearingIDKey.hearingID = key.hearingID;

      interpreterDetails = new InterpreterDetails();

      if (hearingSupplierIDTypeDetails.supplierType
        .equals(APPEALSUPPLIERTYPE.USER)) {

        hearingInterpreterUserDetails =
          hearingServiceSupplierObj
            .readInterpreterByUserRoleAndHearingID(supplierLinkIDAndHearingIDKey);

        // BEGIN, CR00053295, RKi
        final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
        CaseOwnerDetails caseOwnerDetails;

        orgObjectLinkKey.orgObjectLinkID =
          hearingInterpreterUserDetails.orgObjectLinkID;
        final curam.core.sl.intf.CaseUserRole caseUserRole =
          curam.core.sl.fact.CaseUserRoleFactory.newInstance();

        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        interpreterDetails.fullName = caseOwnerDetails.userFullName;
        hearingInterpreterUserDetails.fullName =
          caseOwnerDetails.userFullName;
        // END, CR00053295

        interpreterDetails.assign(hearingInterpreterUserDetails);
        interpreterDetails.interpreterID = caseOwnerDetails.userName;
        interpreterDetails.fullName = hearingInterpreterUserDetails.fullName;

        interpreterDetails.hearingServiceSupplierID =
          hearingSupplierIDTypeDetails.hearingServiceSupplierID;

        listInterpreterDetails.interpreterDetails.addRef(interpreterDetails);

      }
    }

    return listInterpreterDetails;
  }

  // BEGIN, CR00246931, GP
  /**
   * Method to list participant interpreters for standalone cases.
   * 
   * @param key contains the hearingID.
   * @return The list of all participant interpreters for a given hearing id.
   * 
   * @throws AppException Generic exception signature.
   * @throws InformationalException Generic exception signature.
   */
  @Override
  public ListInterpreterDetails
    listParticipants(final ListInterpreterKey key) throws AppException,
      InformationalException {

    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    HearingSupplierIDTypeDetailsList hearingSupplierIDTypeDetailsList =
      new HearingSupplierIDTypeDetailsList();
    final SupplierLinkIDAndHearingIDKey supplierLinkIDAndHearingIDKey =
      new SupplierLinkIDAndHearingIDKey();

    final ListInterpreterDetails listInterpreterDetails =
      new ListInterpreterDetails();
    InterpreterDetails interpreterDetails;
    HearingInterpreterParticipantDetails hearingInterpreterParticipantDetails =
      new HearingInterpreterParticipantDetails();

    final Hearing hearingObj = HearingFactory.newInstance();
    final HearingKey hearingKey = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    hearingKey.hearingKey.hearingID = key.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case.
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    hearingKeyDetails.hearingID = key.hearingID;

    hearingSupplierIDTypeDetailsList =
      hearingServiceSupplierObj
        .searchInterpreterByHearingID(hearingKeyDetails);

    // For each interpreter, read interpreter details.
    for (final HearingSupplierIDTypeDetails hearingSupplierIDTypeDetails : hearingSupplierIDTypeDetailsList.dtls
      .items()) {

      supplierLinkIDAndHearingIDKey.supplierLinkID =
        hearingSupplierIDTypeDetails.supplierLinkID;
      supplierLinkIDAndHearingIDKey.hearingID = key.hearingID;

      interpreterDetails = new InterpreterDetails();

      if (hearingSupplierIDTypeDetails.supplierType
        .equals(APPEALSUPPLIERTYPE.PARTICIPANT)) {

        hearingInterpreterParticipantDetails =
          hearingServiceSupplierObj
            .readInterpreterByCaseParticipantRoleAndHearingID(supplierLinkIDAndHearingIDKey);

        interpreterDetails.assign(hearingInterpreterParticipantDetails);
        interpreterDetails.interpreterID =
          new Long(hearingSupplierIDTypeDetails.supplierLinkID).toString();
        interpreterDetails.fullName =
          hearingInterpreterParticipantDetails.concernRoleName;

        interpreterDetails.hearingServiceSupplierID =
          hearingSupplierIDTypeDetails.hearingServiceSupplierID;

        listInterpreterDetails.interpreterDetails.addRef(interpreterDetails);

      }

    }

    return listInterpreterDetails;

  }

  // END, CR00246931

  /**
   * Method to modify interpreters.
   * 
   * @param details The hearing supplier id used to
   * return a list of interpreters
   */
  @Override
  public void modify(final ModifyInterpreterDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierIDKey hearingServiceSupplierIDKey =
      new HearingServiceSupplierIDKey();
    final HearingServiceSupplierKey hearingServiceSupplierKey =
      new HearingServiceSupplierKey();
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Read the hearing ID
    hearingServiceSupplierKey.hearingServiceSupplierID =
      details.hearingServiceSupplierID;
    hearingKeyDetails =
      hearingServiceSupplierObj.readHearing(hearingServiceSupplierKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // validate modify details
    validateModify(details);

    // Modify hearing interpreter
    hearingServiceSupplierIDKey.hearingServiceSupplierID =
      details.hearingServiceSupplierID;
    hearingServiceSupplierObj.modifyParticipatedCodeAndComment(
      hearingServiceSupplierIDKey,
      details.hearingSSParticipationAndCommentDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to read a hearing interpreter.
   * 
   * @param key The hearing interpreter to view
   * 
   * @return readHearingInterpreterDetails the hearing interpreter details
   */
  @Override
  public ReadHearingInterpreterDetails read(
    final ReadHearingInterpreterKey key) throws AppException,
    InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Hearing variables
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierKey hearingServiceSupplierKey =
      new HearingServiceSupplierKey();
    SupplierTypeDetails supplierTypeDetails = new SupplierTypeDetails();

    // Interpreter variables
    HearingInterpreterUserDetails hearingInterpreterUserDetails =
      new HearingInterpreterUserDetails();
    HearingInterpreterParticipantDetails hearingInterpreterParticipantDetails =
      new HearingInterpreterParticipantDetails();
    final ReadHearingInterpreterDetails readHearingInterpreterDetails =
      new ReadHearingInterpreterDetails();
    final SupplierLinkIDAndHearingIDKey supplierLinkIDAndHearingIDKey =
      new SupplierLinkIDAndHearingIDKey();

    // Read the hearing id
    hearingServiceSupplierKey.hearingServiceSupplierID =
      key.hearingServiceSupplierID;
    hearingKeyDetails =
      hearingServiceSupplierObj.readHearing(hearingServiceSupplierKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read the type by supplier link id
    supplierTypeDetails =
      hearingServiceSupplierObj
        .readTypeAndSupplierLinkID(hearingServiceSupplierKey);

    supplierLinkIDAndHearingIDKey.supplierLinkID =
      supplierTypeDetails.supplierLinkID;
    supplierLinkIDAndHearingIDKey.hearingID = hearingKeyDetails.hearingID;

    // Read from case user role table if its of type user, otherwise
    // read from the case participant role table.
    if (supplierTypeDetails.supplierType.equals(APPEALSUPPLIERTYPE.USER)) {

      // Retrieve Interpreter details from case user role table
      hearingInterpreterUserDetails =
        hearingServiceSupplierObj
          .readInterpreterByUserRoleAndHearingID(supplierLinkIDAndHearingIDKey);

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        hearingInterpreterUserDetails.orgObjectLinkID;
      final curam.core.sl.intf.CaseUserRole caseUserRole =
        curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      hearingInterpreterUserDetails.fullName = caseOwnerDetails.userFullName;
      // END, CR00053295

      // Populate interpreter details struct to return
      readHearingInterpreterDetails.comments =
        hearingInterpreterUserDetails.comments;
      readHearingInterpreterDetails.interpreterID = caseOwnerDetails.userName;
      readHearingInterpreterDetails.linkVersionNo =
        hearingInterpreterUserDetails.caseUserVersionNo;
      readHearingInterpreterDetails.name =
        hearingInterpreterUserDetails.fullName;
      readHearingInterpreterDetails.participatedCode =
        hearingInterpreterUserDetails.participatedCode;
      readHearingInterpreterDetails.recordStatus =
        hearingInterpreterUserDetails.recordStatus;
      readHearingInterpreterDetails.supplierType =
        hearingInterpreterUserDetails.supplierType;
      readHearingInterpreterDetails.supplierVersionNo =
        hearingInterpreterUserDetails.supplierVersionNo;

    } else if (supplierTypeDetails.supplierType
      .equals(APPEALSUPPLIERTYPE.PARTICIPANT)) {

      // Retrieve Interpreter details from case participant role table
      hearingInterpreterParticipantDetails =
        hearingServiceSupplierObj
          .readInterpreterByCaseParticipantRoleAndHearingID(supplierLinkIDAndHearingIDKey);

      // Populate interpreter details struct to return
      readHearingInterpreterDetails.comments =
        hearingInterpreterParticipantDetails.comments;
      readHearingInterpreterDetails.interpreterID =
        new Long(supplierLinkIDAndHearingIDKey.supplierLinkID).toString();
      readHearingInterpreterDetails.linkVersionNo =
        hearingInterpreterParticipantDetails.caseParticipantVersionNo;
      readHearingInterpreterDetails.participatedCode =
        hearingInterpreterParticipantDetails.participatedCode;
      readHearingInterpreterDetails.recordStatus =
        hearingInterpreterParticipantDetails.recordStatus;
      readHearingInterpreterDetails.supplierType =
        hearingInterpreterParticipantDetails.supplierType;
      readHearingInterpreterDetails.supplierVersionNo =
        hearingInterpreterParticipantDetails.supplierVersionNo;
      readHearingInterpreterDetails.name =
        hearingInterpreterParticipantDetails.concernRoleName;

    } else {

      // Type not 'Participant' or 'User', throw exception
      throw new AppException(
        curam.message.BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_SUPPLIERTYPE_NOT_KNOWN);

    }

    return readHearingInterpreterDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to validate an insert.
   * 
   * @param dtls The insert hearing interpreter details to validate
   */
  @Override
  protected void validateInsert(final CreateHearingInterpreterDetails dtls)
    throws AppException, InformationalException {

    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingStatusDetails hearingStatusDetails = new HearingStatusDetails();

    // Hearing variables
    final HearingKey hearingKey_bo = new HearingKey();

    // Read the hearing status
    hearingKey.hearingID = dtls.hearingServiceSupplier.hearingID;
    hearingStatusDetails = hearingObj.readStatusByHearingID(hearingKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      dtls.hearingServiceSupplier.hearingID;

    // BEGIN, CR00125085, RKi
    // check to see if the service supplier is a valid one.
    if (dtls.interpreterType.equals(INTERPRETERTYPE.SERVICESUPPLIER)) {
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      try {
        // BEGIN, CR00442218, VT
        if (!dtls.interpreterID.isEmpty()) {
          concernRoleKey.concernRoleID = Long.parseLong(dtls.interpreterID);
        }
        // END, CR00442218
      } catch (final NumberFormatException re) {

        throw new AppException(
          BPOHEARINGSERVICESUPPLIER.ERR_HEARINGSERVICESUPPLIER_FV_RECORDDOESNOTEXIST);
      }
    }
    // END, CR00125085

    // check that the name is NOT entered if an existing interpreter is entered
    if (!StringUtil.isNullOrEmpty(dtls.interpreterID)
      && dtls.fullName.length() > 0) {

      throw new AppException(
        curam.message.BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_EXISTING_AND_CREATE);
    }

    // check that the name is entered if an existing interpreter is not entered
    if (StringUtil.isNullOrEmpty(dtls.interpreterID)
      && dtls.fullName.length() == 0) {

      throw new AppException(
        BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_NAME_NOT_ENTERED);
    }

    // Check to see if hearing status is scheduled. If not, throw an exception
    if (!hearingStatusDetails.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_STATUS_NOT_SCHEDULED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Check to see if entry needs to be added to the case participant role
    // Or case user role table
    if (dtls.interpreterType.equals(curam.codetable.INTERPRETERTYPE.USER)) {

      // Check to determine whether the interpreter id is null
      // If its not null or empty, than its alright to perform a read
      if (!StringUtil.isNullOrEmpty(dtls.interpreterID)) {

        // Loop through list to see if there exists a role of type 'Interpreter'
        // for the same user. If it does exist, throw an exception
        // TODO
        // Hearing Service Supplier variables
        final HearingServiceSupplier hearingServiceSupplierObj =
          HearingServiceSupplierFactory.newInstance();
        final HearingServiceSupplierInterpreterHearingKey hearingServiceSupplierInterpreterHearingKey =
          new HearingServiceSupplierInterpreterHearingKey();
        HearingInterpreterNameUserRoleDetailsList hearingInterpreterNameUserRoleDetailsList;

        // Search for internal interpreters
        hearingServiceSupplierInterpreterHearingKey.hearingID =
          dtls.hearingServiceSupplier.hearingID;
        hearingServiceSupplierInterpreterHearingKey.recordStatus =
          RECORDSTATUS.NORMAL;
        hearingServiceSupplierInterpreterHearingKey.typeCode =
          CASEUSERROLETYPE.INTERPRETER;

        hearingInterpreterNameUserRoleDetailsList =
          hearingServiceSupplierObj
            .searchActiveInterpreterNameAndCaseUserRoleByHearingID(hearingServiceSupplierInterpreterHearingKey);

        // BEGIN, CR00177498, PM
        for (final HearingInterpreterNameUserRoleDetails hearingInterpreterNameUserRoleDetails : hearingInterpreterNameUserRoleDetailsList.dtls
          .items()) {

          final OrgObjectLink orgObjectLink =
            OrgObjectLinkFactory.newInstance();

          orgObjectLinkKey.orgObjectLinkID =
            hearingInterpreterNameUserRoleDetails.orgObjectLinkID;
          final OrgObjectLinkDtls orgObjectLinkDtls =
            orgObjectLink.read(orgObjectLinkKey);

          if (orgObjectLinkDtls.userName.equals(dtls.interpreterID)) {
            throw new AppException(
              BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_CASEUSERROLE_ALREADY_EXISTS);
          }
        }// END, CR00177498
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to validate a cancel operation.
   * 
   * @param dtls The cancel hearing interpreter details to validate
   */
  @Override
  protected void validateCancel(final CancelInterpreterKey dtls)
    throws AppException, InformationalException {

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();
    SupplierTypeDetails supplierTypeDetails = new SupplierTypeDetails();
    final HearingServiceSupplierKey hearingServiceSupplierKey =
      new HearingServiceSupplierKey();

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails =
      new TypeAndStatusAndParticipantRoleDetails();

    // Case User role variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    CaseUserRoleDtls caseUserRoleDtls = new CaseUserRoleDtls();

    // Read type and supplier link id by hearing service supplier id
    hearingServiceSupplierKey.hearingServiceSupplierID =
      dtls.hearingServiceSupplierID;
    supplierTypeDetails =
      hearingServiceSupplierObj
        .readTypeAndSupplierLinkID(hearingServiceSupplierKey);

    // Check to see if the type is a participant or a user
    if (supplierTypeDetails.supplierType
      .equals(curam.codetable.APPEALSUPPLIERTYPE.PARTICIPANT)) {

      caseParticipantRole_eoKey.caseParticipantRoleID =
        supplierTypeDetails.supplierLinkID;
      typeAndStatusAndParticipantRoleDetails =
        caseParticipantRole
          .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

      // Check to see if status is empty
      if (!StringUtil
        .isNullOrEmpty(typeAndStatusAndParticipantRoleDetails.recordStatus)) {

        // Status not empty, check to see if canceled
        if (typeAndStatusAndParticipantRoleDetails.recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

          throw new AppException(
            BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_PARTICIPANTROLE_ALREADY_CANCELLED);

        }

      }
    } else {

      caseUserRoleKey.caseUserRoleID = supplierTypeDetails.supplierLinkID;

      // Read the status
      caseUserRoleDtls = caseUserRoleObj.read(caseUserRoleKey);

      // Check to see if status is null
      if (!StringUtil.isNullOrEmpty(caseUserRoleDtls.recordStatus)) {

        // Status not null, check to see if status is canceled
        if (caseUserRoleDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

          throw new AppException(
            BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_CASEUSERROLE_ALREADY_CANCELLED);

        }

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate modify interpreters
   * 
   * @param details The hearingID used to return a list of interpreters
   */
  @Override
  public void validateModify(final ModifyInterpreterDetails details)
    throws AppException, InformationalException {

    // Hearing service supplier variables
    final HearingServiceSupplier hearingServiceSupplierObj =
      HearingServiceSupplierFactory.newInstance();

    SupplierTypeDetails supplierTypeDetails = new SupplierTypeDetails();
    final HearingServiceSupplierKey hearingServiceSupplierKey =
      new HearingServiceSupplierKey();
    ParticipationAndHearingKeyDetails participationAndHearingKeyDetails;
    final HearingServiceSupplierIDKey hearingServiceSupplierIDKey =
      new HearingServiceSupplierIDKey();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();

    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails =
      new TypeAndStatusAndParticipantRoleDetails();

    // Case User role variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    CaseUserRoleStatusDetails caseUserRoleStatusDetails =
      new CaseUserRoleStatusDetails();

    // Read type and supplier link id by hearing service supplier id
    hearingServiceSupplierIDKey.hearingServiceSupplierID =
      details.hearingServiceSupplierID;

    hearingServiceSupplierKey.hearingServiceSupplierID =
      details.hearingServiceSupplierID;

    participationAndHearingKeyDetails =
      hearingServiceSupplierObj
        .readHearingAndParticipatedCode(hearingServiceSupplierKey);

    supplierTypeDetails =
      hearingServiceSupplierObj
        .readTypeAndSupplierLinkID(hearingServiceSupplierKey);

    // Ensure participated code field is not null

    if (StringUtil
      .isNullOrEmpty(details.hearingSSParticipationAndCommentDetails.participatedCode)) {

      throw new AppException(
        BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_PARTICIPATED_CODE_NOT_ENTERED);

    }

    hearingKey.hearingID = participationAndHearingKeyDetails.hearingID;

    // Get hearing case and status details
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    if (hearingCaseStatusDtls.statusCode
      .equals(curam.codetable.HEARINGSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_CASE_CANCELED);

    }

    // If the status is not completed or adjourned,
    // the participated code cannot be updated.
    if (!hearingCaseStatusDtls.statusCode
      .equals(curam.codetable.HEARINGSTATUS.ADJOURNED)
      && !hearingCaseStatusDtls.statusCode
        .equals(curam.codetable.HEARINGSTATUS.COMPLETED)) {

      // Read the participated code from the database
      // and check against the participated code from the modify
      // interpreter screen.
      if (!details.hearingSSParticipationAndCommentDetails.participatedCode
        .equals(participationAndHearingKeyDetails.participatedCode)) {

        throw new AppException(
          BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_CANNOT_MODIFY_PARTICIPATED_CODE);
      }

    }

    // Run a check to see if the record has been canceled already
    if (supplierTypeDetails.supplierType
      .equals(curam.codetable.APPEALSUPPLIERTYPE.PARTICIPANT)) {

      caseParticipantRole_eoKey.caseParticipantRoleID =
        supplierTypeDetails.supplierLinkID;
      typeAndStatusAndParticipantRoleDetails =
        caseParticipantRole
          .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

      // Check to see if status is empty
      if (!StringUtil
        .isNullOrEmpty(typeAndStatusAndParticipantRoleDetails.recordStatus)) {

        // Status not empty, check to see if canceled
        if (typeAndStatusAndParticipantRoleDetails.recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

          throw new AppException(
            BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_PARTICIPANTROLE_ALREADY_CANCELLED);

        }

      }
    } else {

      caseUserRoleKey.caseUserRoleID = supplierTypeDetails.supplierLinkID;

      // Read the status
      caseUserRoleStatusDetails =
        caseUserRoleObj.readRecordStatus(caseUserRoleKey);

      // Check to see if status is null
      if (!StringUtil.isNullOrEmpty(caseUserRoleStatusDetails.recordStatus)) {

        // Status not null, check to see if status is canceled
        if (caseUserRoleStatusDetails.recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

          throw new AppException(
            BPOHEARINGINTERPRETER.ERR_HEARING_INTERPRETER_FV_CASEUSERROLE_ALREADY_CANCELLED);

        }

      }

    }

  }

}
