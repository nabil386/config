/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.tab.impl;

import com.google.inject.Inject;
import curam.codetable.CASESTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.sl.fact.BookmarkFactory;
import curam.core.sl.struct.CountCaseBookmarkKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;
import curam.util.transaction.TransactionInfo;
import java.util.Map;

public class AppealHomeMenuLoader implements DynamicMenuStateLoader {

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Constructor.
   */
  public AppealHomeMenuLoader() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public MenuState loadMenuState(final MenuState menuState,
    final Map<String, String> pageParameters, @SuppressWarnings("unused")
    final String[] idsToUpdate) throws AppException, InformationalException {

    // configure menuState
    final MenuState returnState = menuState;
    final String caseIdParam = pageParameters.get(TabLoaderConst.kCaseID);

    // BEGIN , CR00362634, DK
    // parameters to get the case status
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey key = new CaseHeaderKey();
    CaseStatusCode status = new CaseStatusCode();

    // get the caseID as a long
    key.caseID = Long.parseLong(caseIdParam);
    status = caseHeaderObj.readCaseStatus(key);
    // if the case is cancelled, set the cancelled status constant to true
    if (status.statusCode.equals(CASESTATUS.CANCELED)) {
      returnState.setVisible(true, TabLoaderConst.kViewCancelDetails);
      returnState.setEnabled(true, TabLoaderConst.kViewCancelDetails);

      returnState.setVisible(true, TabLoaderConst.kEditCancelDetails);
      returnState.setEnabled(true, TabLoaderConst.kEditCancelDetails);
    } else {
      returnState.setVisible(true, TabLoaderConst.kViewCancelDetails);
      returnState.setEnabled(false, TabLoaderConst.kViewCancelDetails);

      returnState.setVisible(true, TabLoaderConst.kEditCancelDetails);
      returnState.setEnabled(false, TabLoaderConst.kEditCancelDetails);
    }
    // END , CR00362634, DK

    Boolean caseIsBookmarkedInd = false;
    final curam.core.sl.intf.Bookmark bookmarkObj =
      BookmarkFactory.newInstance();
    final CountCaseBookmarkKey countCaseBookmarkKey =
      new CountCaseBookmarkKey();

    countCaseBookmarkKey.dtls.userName = TransactionInfo.getProgramUser();
    countCaseBookmarkKey.dtls.caseID = Long.parseLong(caseIdParam);

    // return number of case bookmarks for the current user
    Count count = null;

    try {
      count = bookmarkObj.countCaseBookmark(countCaseBookmarkKey);
    } catch (final Exception e) {
      // In the case of an exception being thrown, display both of the actions
      returnState.setVisible(true, TabLoaderConst.kBookmark);
      returnState.setEnabled(true, TabLoaderConst.kBookmark);

      returnState.setVisible(true, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(true, TabLoaderConst.kRemoveBookmark);
    }

    // check if a case bookmark record exists, the default is false
    if (count.numberOfRecords > 0) {
      caseIsBookmarkedInd = true;
    }

    if (caseIsBookmarkedInd == true) {
      returnState.setVisible(false, TabLoaderConst.kBookmark);
      returnState.setEnabled(false, TabLoaderConst.kBookmark);

      returnState.setVisible(true, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(true, TabLoaderConst.kRemoveBookmark);

    } else {
      returnState.setVisible(true, TabLoaderConst.kBookmark);
      returnState.setEnabled(true, TabLoaderConst.kBookmark);

      returnState.setVisible(false, TabLoaderConst.kRemoveBookmark);
      returnState.setEnabled(false, TabLoaderConst.kRemoveBookmark);
    }

    return returnState;
  }

}
