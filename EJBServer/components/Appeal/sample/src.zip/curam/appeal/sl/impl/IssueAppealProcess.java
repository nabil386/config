/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealProcessFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealStageConfigurationFactory;
import curam.appeal.sl.entity.intf.AppealProcess;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealStageConfiguration;
import curam.appeal.sl.entity.struct.AppealCaseAndCase;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealProcessDtls;
import curam.appeal.sl.entity.struct.AppealProcessID;
import curam.appeal.sl.entity.struct.AppealProcessIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealProcessKey;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppealStageConfigurationDetails;
import curam.appeal.sl.entity.struct.AppealStageConfigurationDetailsList;
import curam.appeal.sl.entity.struct.AppealStageConfigurationDtls;
import curam.appeal.sl.entity.struct.AppealStageConfigurationID;
import curam.appeal.sl.entity.struct.AppealStageConfigurationKey;
import curam.appeal.sl.entity.struct.AppealTypeAndProcess;
import curam.appeal.sl.entity.struct.CaseTypeIDStartDateActiveDetails;
import curam.appeal.sl.entity.struct.IssueAppealProcessIDAndRecordStatus;
import curam.appeal.sl.entity.struct.IssueAppealRecordStatusStartDate;
import curam.appeal.sl.entity.struct.IssueAppealStageModifyRecordStatus;
import curam.appeal.sl.entity.struct.ModifyIssueStage;
import curam.appeal.sl.entity.struct.PriorAppealCaseID;
import curam.appeal.sl.entity.struct.PriorAppealCaseIDAndCaseIDDetailsList;
import curam.appeal.sl.entity.struct.ProcessSummary;
import curam.appeal.sl.entity.struct.StageAndParentDetailsList;
import curam.appeal.sl.struct.AppealCaseIDCaseID;
import curam.appeal.sl.struct.AppealStageConfigID;
import curam.appeal.sl.struct.AppealStageType;
import curam.appeal.sl.struct.CaseAndPriorAppeal;
import curam.appeal.sl.struct.CreateIssueProcessDetails;
import curam.appeal.sl.struct.CreateIssueStageDetails;
import curam.appeal.sl.struct.IssueAppealProcessKey;
import curam.appeal.sl.struct.IssueProcessDetailsList;
import curam.appeal.sl.struct.IssueStagePositionDetails;
import curam.appeal.sl.struct.ListIssueProcessDtls;
import curam.appeal.sl.struct.ModifyIssueStageDetails;
import curam.appeal.sl.struct.OrderedAppealStage;
import curam.appeal.sl.struct.OrderedAppealStageList;
import curam.appeal.sl.struct.PriorAppealCount;
import curam.appeal.sl.struct.ProcessAndStageDetails;
import curam.appeal.sl.struct.ProductAndStartDateAndAppealType;
import curam.appeal.sl.struct.ReadIssueStagedetails;
import curam.appeal.sl.struct.StageFirstLevelDetails;
import curam.appeal.sl.struct.StageFirstLevelDetailsList;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.message.BPOISSUEAPPEALSTAGE;
import curam.message.BPOISSUECASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.Date;

/**
 * Provides the facade functionality for maintaining and accessing issue appeal
 * process definitions for a Product.
 */
public abstract class IssueAppealProcess extends
  curam.appeal.sl.base.IssueAppealProcess {

  // ___________________________________________________________________________
  /**
   * Returns the details for a specified issue appeal process including all of
   * it's associated active appeal stages.
   * 
   * @param key
   * The issue appeal process to read.
   * @return The issue appeal process details including the ordered list of
   * active appeal stages for the process.
   */
  @Override
  public ProcessAndStageDetails readIssueProcessDetails(
    final IssueAppealProcessKey key) throws AppException,
    InformationalException {

    // Service Layer Variables

    final ProcessAndStageDetails processAndStageDetails =
      new ProcessAndStageDetails();

    // Entity layer variables for Product Appeal Process

    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    appealProcessKey.appealProcessID = key.appealProcessID;
    // Get the process details

    try {
      processAndStageDetails.processSummary =
        appealProcessObj.readIssueProcess(appealProcessKey);

    } catch (final RecordNotFoundException e) {

      processAndStageDetails.processSummary = new ProcessSummary();
    }

    // Get list of active stages
    processAndStageDetails.orderedAppealStageList =
      listOrderedActiveStages(key);

    return processAndStageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates a new issue appeal process definition for a issue. A new issue
   * appeal process is created with no appeal stages.
   * 
   * @param details
   * The issue and start date for which to create the new issue appeal
   * process.
   */
  @Override
  public void createIssueProcess(final CreateIssueProcessDetails details)
    throws AppException, InformationalException {

    // Entity layer variables for Product Appeal Process

    final AppealProcess issueAppealProcessObj =
      AppealProcessFactory.newInstance();

    final AppealProcessDtls appealProcessDtls = new AppealProcessDtls();

    final AppealStageConfigurationDtls appealStageConfigurationDtls =
      new AppealStageConfigurationDtls();

    // Validate before creating an Issue Appeal process
    validateCreateIssueProcess(details);

    // Add new process for this Product ID with this start date
    appealProcessDtls.caseTypeID =
      details.createIssueProcessDetails.caseTypeID;
    appealProcessDtls.caseType = CASETYPECODE.ISSUE;
    appealProcessDtls.startDate = details.createIssueProcessDetails.startDate;
    appealProcessDtls.recordStatus = RECORDSTATUS.NORMAL;

    issueAppealProcessObj.insert(appealProcessDtls);

    appealStageConfigurationDtls.appealProcessID =
      appealProcessDtls.appealProcessID;
    appealStageConfigurationDtls.appealTypeCode =
      details.createIssueProcessDetails.appealTypeCode;
    appealStageConfigurationDtls.recordStatus = RECORDSTATUS.NORMAL;

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    appealStageConfigurationObj.insert(appealStageConfigurationDtls);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all issue appeal processes for a issue. This list
   * includes the first appeal stage, if any, defined for each process.
   * 
   * @param details
   * The case type id and case type to obtain the list of issue appeal
   * processes
   * @return The list of issue appeal processes
   */
  @Override
  public IssueProcessDetailsList listIssueProcess(
    final ListIssueProcessDtls details) throws AppException,
    InformationalException {

    // Entity layer variables for issue Appeal Process
    final AppealProcess appealProcess = AppealProcessFactory.newInstance();

    final IssueProcessDetailsList issueProcessDetailsList =
      new IssueProcessDetailsList();

    details.listIssueProcessDtls.caseType = CASETYPECODE.ISSUE;

    issueProcessDetailsList.issueProcessList =
      appealProcess.searchIssueProcess(details.listIssueProcessDtls);

    return issueProcessDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns active stages for a process in the correct order.
   * 
   * @param key
   * The issue appeal process for which to return appeal stages.
   * @return List of ordered appeal stages including numerical indicator of
   * order sequence.
   */
  @Override
  public OrderedAppealStageList listOrderedActiveStages(
    final IssueAppealProcessKey key) throws AppException,
    InformationalException {

    // Variables for ordered list of active stages

    final OrderedAppealStageList orderedAppealStageList =
      new OrderedAppealStageList();

    OrderedAppealStage orderedAppealStage;

    // Variable for domain APPEAL_STAGE_SEQUENCE
    byte appealStageSequence = 1;

    // Variables for domain APPEAL_STAGE_ID
    long nextParentAppealStageID;

    // Entity layer variables for Appeal Stage

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    AppealStageConfigurationDetails appealStageConfigurationDetails;

    AppealStageConfigurationDetailsList appealStageConfigurationDetailsList;

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    appealProcessKey.appealProcessID = key.appealProcessID;

    // Get unsorted list of Issue appeal processes
    appealStageConfigurationDetailsList =
      appealStageConfigurationObj.searchIssueStages(appealProcessKey);

    // First stage in list has a null parent ID

    nextParentAppealStageID = 0;

    // If at least one stage exists then sort the list

    if (appealStageConfigurationDetailsList.dtls.size() >= 1) {

      for (int i = 0; i < appealStageConfigurationDetailsList.dtls.size(); i++) {

        // Find the next stage in the list

        orderedAppealStage = new OrderedAppealStage();

        for (int j = 0; j < appealStageConfigurationDetailsList.dtls.size(); j++) {

          appealStageConfigurationDetails =
            appealStageConfigurationDetailsList.dtls.item(j);

          // If the parent ID matches then have found the next stage

          if (appealStageConfigurationDetails.parentStageConfID == nextParentAppealStageID) {

            // If this stage is active then add it to the ordered list

            if (appealStageConfigurationDetails.recordStatus
              .equals(RECORDSTATUS.NORMAL)) {

              orderedAppealStage.appealStageID =
                appealStageConfigurationDetails.appealStageConfID;
              orderedAppealStage.appealTypeCode =
                appealStageConfigurationDetails.appealTypeCode;

              orderedAppealStage.stageSequence = appealStageSequence;

              orderedAppealStageList.orderedAppealStage
                .addRef(orderedAppealStage);

              appealStageSequence++;
            }

            // Let this be the next parent ID

            nextParentAppealStageID =
              appealStageConfigurationDetails.appealStageConfID;
            break;
          }
        }
      }
    }

    return orderedAppealStageList;
  }

  // ___________________________________________________________________________
  /**
   * Create Issue Stage.
   * 
   * @param dtls
   * The issue stage details to be created.
   */

  @Override
  public void createIssueStage(final CreateIssueStageDetails dtls)
    throws AppException, InformationalException {

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationDtls appealStageConfigurationDtls =
      new AppealStageConfigurationDtls();

    final IssueAppealProcessKey issueAppealProcessKey =
      new IssueAppealProcessKey();

    // Validate before creating an Issue Stage
    validateCreateStage(dtls);

    AppealStageConfigurationID appealStageconfigurationID =
      new AppealStageConfigurationID();

    // Get the stage ID of the last stage in the list for this process,
    // this will be the parent ID of the new stage; if no stages found then
    // this is the first stage in the list and parent ID should be null.

    issueAppealProcessKey.appealProcessID = dtls.appealProcessID;

    try {
      appealStageconfigurationID =
        appealStageConfigurationObj.readLastStageID(issueAppealProcessKey);

      appealStageConfigurationDtls.parentStageConfID =
        appealStageconfigurationID.appealStageConfID;
    } catch (final RecordNotFoundException e) {

      appealStageConfigurationDtls.parentStageConfID = 0;
    }

    // Add the new stage to the end of the list

    appealStageConfigurationDtls.appealTypeCode = dtls.appealTypeCode;

    appealStageConfigurationDtls.recordStatus = RECORDSTATUS.NORMAL;
    appealStageConfigurationDtls.versionNo = 0;

    appealStageConfigurationDtls.appealProcessID = dtls.appealProcessID;

    appealStageConfigurationObj.insert(appealStageConfigurationDtls);

  }

  // ___________________________________________________________________________
  /**
   * Read Issue Stage details.
   * 
   * @param key
   * The issue appeal config ID for reading the Issue Stage details.
   * @return The issue stage details.
   */

  @Override
  public ReadIssueStagedetails readIssueStage(final AppealStageConfigID key)
    throws AppException, InformationalException {

    final AppealStageConfiguration appealStageConfiguration =
      AppealStageConfigurationFactory.newInstance();

    final ReadIssueStagedetails issueStagedetails =
      new ReadIssueStagedetails();

    final AppealStageConfigurationDetails appealStageConfigurationDetails =
      new AppealStageConfigurationDetails();

    AppealStageConfigurationDtls appealStageConfigurationDtls =
      new AppealStageConfigurationDtls();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    appealStageConfigurationKey.appealStageConfID =
      key.StageConfigID.appealStageConfID;

    appealStageConfigurationDtls =
      appealStageConfiguration.read(appealStageConfigurationKey);

    appealStageConfigurationDetails.appealStageConfID =
      appealStageConfigurationDtls.appealStageConfID;
    appealStageConfigurationDetails.appealTypeCode =
      appealStageConfigurationDtls.appealTypeCode;
    appealStageConfigurationDetails.parentStageConfID =
      appealStageConfigurationDtls.parentStageConfID;
    appealStageConfigurationDetails.recordStatus =
      appealStageConfigurationDtls.recordStatus;

    issueStagedetails.IssuestageDetails
      .assign(appealStageConfigurationDetails);

    return issueStagedetails;

  }

  // ___________________________________________________________________________
  /**
   * Validation for modifying an issue stage.
   * 
   * @param key
   * The issue appeal config ID for modifying the Issue Stage details.
   */

  @Override
  public void validateModifyDetails(final AppealStageConfigurationID key)
    throws AppException, InformationalException {

    // Variable for validation error messages

    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Issue Appeal Process

    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    IssueAppealRecordStatusStartDate issueAppealRecordStatusStartDate;

    // Entity layer variables for Appeal Stage

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    IssueAppealProcessIDAndRecordStatus issueAppealProcessIDAndRecordStatus;

    // Get the stage details for validation

    appealStageConfigurationKey.appealStageConfID = key.appealStageConfID;

    issueAppealProcessIDAndRecordStatus =
      appealStageConfigurationObj
        .readStatusAndProcessID(appealStageConfigurationKey);

    // Get the process details for validation

    appealProcessKey.appealProcessID =
      issueAppealProcessIDAndRecordStatus.appealProcessID;

    issueAppealRecordStatusStartDate =
      appealProcessObj.readStartDateAndStatusDetails(appealProcessKey);

    // Check if other active appeal processes exist with a later start date

    final AppealProcessIDAndDateDetails appealProcessIDAndDateDetails =
      new AppealProcessIDAndDateDetails();

    appealProcessIDAndDateDetails.appealProcessID =
      appealProcessKey.appealProcessID;
    appealProcessIDAndDateDetails.startDate =
      issueAppealRecordStatusStartDate.startDate;

    if (!appealProcessIDAndDateDetails.startDate.after(Date.getCurrentDate())) {
      if (appealProcessObj
        .countActiveAppealProcessesLaterDate(appealProcessIDAndDateDetails).numberOfRecords > 0) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_MODIFY_XRV_EXPIRED_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_MODIFY_XRV_ACTIVE_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Modify an issue stage details.
   * 
   * @param details
   * The issue stage details for modifying the Issue Stage details.
   */

  @Override
  public void modifyIssueStageDetails(final ModifyIssueStageDetails details)
    throws AppException, InformationalException {

    // Variables for Appeal Stage entity layer

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    final ModifyIssueStage issueStage = new ModifyIssueStage();

    // Variable for validation details

    final AppealStageConfigurationID appealStageConfigurationID =
      new AppealStageConfigurationID();

    // Validate before modifying
    validateModifyIssueStage(details);

    appealStageConfigurationID.appealStageConfID =
      details.appeaStageConfigurationID;

    // Modify at the entity layer

    appealStageConfigurationKey.appealStageConfID =
      details.appeaStageConfigurationID;
    issueStage.appealTypeCode = details.appealTypeCode;

    appealStageConfigurationObj.modifyIssueStage(appealStageConfigurationKey,
      issueStage);
  }

  // BEGIN, CR CRCR00061124, NSP
  // ___________________________________________________________________________
  /**
   * Validation for creating an issue stage.
   * 
   * @param details
   * The issue stage details for creating the Issue Stage details.
   */

  @Override
  public void validateCreateStage(final CreateIssueStageDetails details)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process
    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();
    final AppealProcessKey appealProcessKey = new AppealProcessKey();
    ProcessSummary processSummary;

    appealProcessKey.appealProcessID = details.appealProcessID;
    processSummary = appealProcessObj.readIssueProcess(appealProcessKey);

    // Check that the start date is in present or future
    if (processSummary.startDate.before(Date.getCurrentDate())
      && !processSummary.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALSTAGE.ERR_ADDISSUESTAGE_ISSUEAPPEALPROCESS_XRV_PAST_STARTDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check that appeal process is having canceled record status
    if (processSummary.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALSTAGE.ERR_ADDISSUESTAGE_ISSUEAPPEALPROCESS_XRV_CANCELLED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // END, CR CR00061124

  // ___________________________________________________________________________
  /**
   * Delete an Issue Appeal Process. This sets the Record Status to "CANCELLED".
   * 
   * @param key
   * The issue appeal process to read.
   */

  @Override
  public void cancelProcess(final AppealProcessKey key) throws AppException,
    InformationalException {

    // Entity layer variables for Appeal Process
    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    final AppealProcessKey appealProcessKey = new AppealProcessKey();
    final IssueAppealProcessIDAndRecordStatus issueAppealProcessIDAndRecordStatus =
      new IssueAppealProcessIDAndRecordStatus();

    // Validate before cancellation.
    validateCancelProcess(key);

    // Set the record status to canceled.

    issueAppealProcessIDAndRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;
    issueAppealProcessIDAndRecordStatus.appealProcessID = key.appealProcessID;

    appealProcessKey.appealProcessID = key.appealProcessID;

    // Update record status of the Appeal Process

    appealProcessObj.modifyRecordStatus(appealProcessKey,
      issueAppealProcessIDAndRecordStatus);

  }

  // ___________________________________________________________________________
  /**
   * Delete an Issue Appeal Stage for an Appeal Process. This sets the Record
   * Status to "CANCELLED".
   * 
   * @param key
   * The issue appeal stage to read.
   */

  @Override
  public void cancelStage(final AppealStageConfigurationID key)
    throws AppException, InformationalException {

    // Entity layer variables for Appeal Stage Configuration

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    final IssueAppealStageModifyRecordStatus issueAppealStageModifyRecordStatus =
      new IssueAppealStageModifyRecordStatus();

    // Validate before cancellation

    validateCancelStage(key);

    // Set the record status to be canceled

    issueAppealStageModifyRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;
    appealStageConfigurationKey.appealStageConfID = key.appealStageConfID;

    // Update record status of the Appeal Stage

    appealStageConfigurationObj.modifyRecordStatus(
      appealStageConfigurationKey, issueAppealStageModifyRecordStatus);

  }

  // ___________________________________________________________________________
  /**
   * Validates that an appeal stage can be canceled.
   * 
   * @param key
   * The appealStageConfigurationID for canceling an appeal stage.
   */
  protected void validateCancelStage(final AppealStageConfigurationID key)
    throws AppException, InformationalException {

    // Variable for validation error messages

    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Issue Appeal Process

    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    IssueAppealRecordStatusStartDate issueAppealRecordStatusStartDate;

    // Entity layer variables for Appeal Stage

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    IssueAppealProcessIDAndRecordStatus issueAppealProcessIDAndRecordStatus;

    // Get the stage details for validation

    appealStageConfigurationKey.appealStageConfID = key.appealStageConfID;

    issueAppealProcessIDAndRecordStatus =
      appealStageConfigurationObj
        .readStatusAndProcessID(appealStageConfigurationKey);

    // Check if this stage is already canceled

    if (issueAppealProcessIDAndRecordStatus.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_XRV_ALREADY_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Get the process details for validation

    appealProcessKey.appealProcessID =
      issueAppealProcessIDAndRecordStatus.appealProcessID;

    issueAppealRecordStatusStartDate =
      appealProcessObj.readStartDateAndStatusDetails(appealProcessKey);

    // Check if the process is canceled

    if (issueAppealRecordStatusStartDate.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_XRV_CANCELLED_APPEAL_PROCESS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if other active appeal processes exist with a later start date

    final AppealProcessIDAndDateDetails appealProcessIDAndDateDetails =
      new AppealProcessIDAndDateDetails();

    appealProcessIDAndDateDetails.appealProcessID =
      appealProcessKey.appealProcessID;
    appealProcessIDAndDateDetails.startDate =
      issueAppealRecordStatusStartDate.startDate;

    if (!appealProcessIDAndDateDetails.startDate.after(Date.getCurrentDate())) {
      if (appealProcessObj
        .countActiveAppealProcessesLaterDate(appealProcessIDAndDateDetails).numberOfRecords > 0) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_XRV_EXPIRED_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALSTAGE_XRV_ACTIVE_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates that an appeal process can be canceled.
   * 
   * @param key
   * The issue appeal process.
   */
  protected void validateCancelProcess(final AppealProcessKey key)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Appeal Process

    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    IssueAppealRecordStatusStartDate issueAppealRecordStatusStartDate;

    // Get details for validation

    appealProcessKey.appealProcessID = key.appealProcessID;

    issueAppealRecordStatusStartDate =
      appealProcessObj.readStartDateAndStatusDetails(appealProcessKey);

    // Check if the process is already canceled

    if (issueAppealRecordStatusStartDate.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_PROCESS_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if other active appeal processes exist with a later start date

    final AppealProcessIDAndDateDetails appealProcessIDAndDateDetails =
      new AppealProcessIDAndDateDetails();

    appealProcessIDAndDateDetails.appealProcessID =
      appealProcessKey.appealProcessID;
    appealProcessIDAndDateDetails.startDate =
      issueAppealRecordStatusStartDate.startDate;

    if (!appealProcessIDAndDateDetails.startDate.after(Date.getCurrentDate())) {
      if (appealProcessObj
        .countActiveAppealProcessesLaterDate(appealProcessIDAndDateDetails).numberOfRecords > 0) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_EXPIRED_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_ACTIVE_APPEAL_PROCESS),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Inform user of any and all validation errors

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Counts the number of prior appeals on an appealed case
   * 
   * @param key
   * The prior appeal case ID and the implementation case ID.
   * 
   * @return The number of prior appeals.
   */

  @Override
  public PriorAppealCount getNumberPriorAppeals(final CaseAndPriorAppeal key)
    throws AppException, InformationalException {

    // Variables for AppealRelationship Entity

    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();

    final PriorAppealCaseID priorAppealCaseID = new PriorAppealCaseID();

    // Variable for number of prior appeal stages

    final PriorAppealCount priorAppealCount = new PriorAppealCount();

    // Start to count the number of prior appeal stages

    priorAppealCount.count = 0;
    priorAppealCaseID.priorAppealCaseID = key.priorAppealCaseID;
    appealCaseAndCase.caseID = key.caseID;

    // Loop until all prior appeal cases have been counted

    while (priorAppealCaseID.priorAppealCaseID != 0) {

      priorAppealCount.count++;

      // BEGIN, CR00297475, DG
      // Get the prior appeal case identifier
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.appealCaseID = priorAppealCaseID.priorAppealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == key.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00297475
    }

    return priorAppealCount;
  }

  // BEGIN, CR CR00061126, NSP
  // ___________________________________________________________________________
  /**
   * Validates that an appeal stage can be modified
   * 
   * @param details
   * of the Issue appeal stage to be modified
   */
  protected void validateModifyIssueStage(
    final ModifyIssueStageDetails details) throws AppException,
    InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process
    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();
    final AppealProcessKey appealProcessKey = new AppealProcessKey();
    ProcessSummary processSummary;

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    final AppealStageConfigurationKey appealStageConfigurationKey =
      new AppealStageConfigurationKey();

    IssueAppealProcessIDAndRecordStatus issueAppealProcessIDAndRecordStatus;

    // Get the stage details for validation
    appealStageConfigurationKey.appealStageConfID =
      details.appeaStageConfigurationID;

    issueAppealProcessIDAndRecordStatus =
      appealStageConfigurationObj
        .readStatusAndProcessID(appealStageConfigurationKey);

    appealProcessKey.appealProcessID =
      issueAppealProcessIDAndRecordStatus.appealProcessID;

    processSummary = appealProcessObj.readIssueProcess(appealProcessKey);

    // Check if Appeal process is in present or in future
    if (processSummary.startDate.before(Date.getCurrentDate())
      && !processSummary.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALSTAGE.ERR_MODIFYISSUESTAGE_ISSUEAPPEALPROCESS_XRV_PAST_STARTDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if appeal process is already canceled
    if (processSummary.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALSTAGE.ERR_MODIFYISSUESTAGE_ISSUEAPPEALPROCESS_XRV_CANCELLED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // END, CR CR00061126

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage in a
   * process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage at the requested position or null if none are
   * found.
   */
  @Override
  public AppealStageType getStageAtPosition(
    final IssueStagePositionDetails key) throws AppException,
    InformationalException {

    // BEGIN, CR00284786, DG
    // Variable for returning the appeal stage
    final AppealStageType appealStageType = new AppealStageType();

    appealStageType.appealStageType.appealStageType =
      getStageDetailsAtPosition(key).appealTypeCode;

    return appealStageType;
    // END, CR00284786
  }

  // BEGIN, CR CR00061117, NSP
  // ___________________________________________________________________________
  /**
   * Validates that an appeal process can be created
   * 
   * @param details
   * The product ID and appeal process start date
   */
  public void validateCreateIssueProcess(
    final CreateIssueProcessDetails details) throws AppException,
    InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Check that start date is mentioned
    if (details.createIssueProcessDetails.startDate.isZero()) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            curam.message.BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_STARTDATE_MUST_BE_PRESENT),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check that start date is in present or in future
    if (!details.createIssueProcessDetails.startDate.isZero()
      && details.createIssueProcessDetails.startDate.before(Date
        .getCurrentDate())) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            curam.message.BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_STARTDATE_PAST),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Entity layer variables for Product Appeal Process
    final AppealProcess appealProcess = AppealProcessFactory.newInstance();

    final curam.appeal.sl.entity.struct.ListIssueProcessDtls listIssueProcessDtls =
      new curam.appeal.sl.entity.struct.ListIssueProcessDtls();

    final IssueProcessDetailsList issueProcessDetailsList =
      new IssueProcessDetailsList();

    listIssueProcessDtls.caseTypeID =
      details.createIssueProcessDetails.caseTypeID;
    listIssueProcessDtls.caseType = CASETYPECODE.ISSUE;

    issueProcessDetailsList.issueProcessList =
      appealProcess.searchIssueProcess(listIssueProcessDtls);

    // Check that there is no active appeal process with the same start date
    if (!details.createIssueProcessDetails.startDate.isZero()
      && issueProcessDetailsList.issueProcessList.dtls.size() > 0) {

      int startDateCnt = 0;

      for (int i = 0; i < issueProcessDetailsList.issueProcessList.dtls
        .size(); i++) {

        if (details.createIssueProcessDetails.startDate
          .equals(issueProcessDetailsList.issueProcessList.dtls.item(i).startDate)) {

          startDateCnt++;
          if (startDateCnt > 0) {

            informationalManager
              .addInformationalMsg(
                new AppException(
                  curam.message.BPOISSUEAPPEALSTAGE.ERR_ISSUEAPPEALPROCESS_XRV_PROCESS_ALREADY_EXISTS),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError);
          }
        }
      }
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // END, CR CR00061117

  // ___________________________________________________________________________
  /**
   * Returns the next level of appeal for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID
   * @return Next valid appeal stage type
   */
  @Override
  public AppealStageType getNextAppealStage(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // BEGIN, CR00295153, DG
    final AppealStageType appealStageType = new AppealStageType();

    // BEGIN, CR00296080, DG
    final OrderedAppealStage orderedAppealStage =
      getNextAppealStageDetails(appealCaseIDCaseID);

    if (orderedAppealStage != null) {
      appealStageType.appealStageType.appealStageType =
        orderedAppealStage.appealTypeCode;
    }
    // END, CR00295153

    return appealStageType;

  }

  // BEGIN, CR00095879, RKi
  // ___________________________________________________________________________
  /**
   * Returns the list of active appeal stages for a Issue where an appeal of the
   * specified type can be created. For each appeal stage an indicator as to
   * whether or not the stage is first level of appeal for the issue is also
   * returned.
   * 
   * @param details
   * The Issue Configuration Identifier, date and appeal type to search
   * for
   * @return List of appeal stage identifiers including an indicator for whether
   * or not the stage is the first level of appeal.
   */
  @Override
  public StageFirstLevelDetailsList listStageFirstLevelForAppealType(
    final ProductAndStartDateAndAppealType details) throws AppException,
    InformationalException {

    // Variables for formatting the return and the return variable itself.
    StageFirstLevelDetailsList stageFirstLevelDetailsList =
      new StageFirstLevelDetailsList();

    // Variables for determining the active product appeal process
    final curam.appeal.sl.entity.intf.AppealProcess appealProcessObj =
      curam.appeal.sl.entity.fact.AppealProcessFactory.newInstance();

    new CaseTypeIDStartDateActiveDetails();
    StageAndParentDetailsList stageAndParentDetailsList =
      new StageAndParentDetailsList();
    final IssueStagePositionDetails stagePositionDetails =
      new IssueStagePositionDetails();

    long appealProcessID = 0;
    // Variables for getting the list of active appeal stages for a issue
    // appeal process configuration
    final curam.appeal.sl.entity.intf.AppealStageConfiguration appealStageConfigurationObj =
      curam.appeal.sl.entity.fact.AppealStageConfigurationFactory
        .newInstance();
    final AppealTypeAndProcess appealTypeAndProcess =
      new AppealTypeAndProcess();

    // Determine the active issue appeal process configuration for the
    // product.
    try {
      final CaseTypeIDStartDateActiveDetails caseTypeIDStartDateActiveDetails =
        new CaseTypeIDStartDateActiveDetails();

      caseTypeIDStartDateActiveDetails.startDate = details.startDate;
      caseTypeIDStartDateActiveDetails.caseTypeID = details.productID;
      caseTypeIDStartDateActiveDetails.recordStatus = RECORDSTATUS.NORMAL;
      appealProcessID =
        appealProcessObj
          .readProcessIDByCaseTypeIDAndStartDate(caseTypeIDStartDateActiveDetails).appealProcessID;

    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for the issue
      stageFirstLevelDetailsList = null;
    }

    if (stageFirstLevelDetailsList != null) {
      // Get all of the active appeal stages for the issue appeal process where
      // the an appeal of the specified type can be created; note that appeal
      // stages configured for "any" type of appeal are also included.
      appealTypeAndProcess.productAppealProcessID = appealProcessID;
      appealTypeAndProcess.appealTypeCode = details.appealStageAppealTypeCode;
      appealTypeAndProcess.recordStatus = RECORDSTATUS.NORMAL;
      appealTypeAndProcess.anyAppealTypeCode = APPEALSTAGEAPPEALTYPE.ANY;
      stageAndParentDetailsList =
        appealStageConfigurationObj
          .searchActiveStageParentByProcessAndType(appealTypeAndProcess);

      // For each appeal stage determine whether it is the first level of
      // appeal; an
      // appeal stage is the first stage when it has no active parent appeal
      // stage.
      for (int i = 0; i < stageAndParentDetailsList.dtls.size(); i++) {

        final StageFirstLevelDetails stageFirstLevelDetails =
          new StageFirstLevelDetails();

        stageFirstLevelDetails.appealStageID =
          stageAndParentDetailsList.dtls.item(i).appealStageID;

        // If there is no active parent for an appeal stage then the appeal
        // stage is
        // the first level of appeal for a issue.
        if (stageAndParentDetailsList.dtls.item(i).parentAppealStageID == 0) {
          stageFirstLevelDetails.firstLevelIndicator = true;

        } else {
          // If this matches the first active stage then it is a first level of
          // appeal
          stagePositionDetails.position = 0;
          stagePositionDetails.caseTypeID = details.productID;
          stagePositionDetails.startDate = details.startDate;
          final AppealStageType appealStageType =
            getStageAtPosition(stagePositionDetails);

          if (appealStageType.appealStageType.appealStageType
            .equals(details.appealStageAppealTypeCode)
            || appealStageType.appealStageType.appealStageType
              .equals(APPEALSTAGEAPPEALTYPE.ANY)) {

            stageFirstLevelDetails.firstLevelIndicator = true;

          } else {

            stageFirstLevelDetails.firstLevelIndicator = false;
          }
        }

        stageFirstLevelDetailsList.stageFirstLevelDetails
          .addRef(stageFirstLevelDetails);
      }

    }

    return stageFirstLevelDetailsList;
  }

  // END, CR00095879

  // BEGIN, CR00284786, DG
  // ___________________________________________________________________________
  /**
   * Get the details of the current appeal stage for a case.
   * 
   * @param appealCaseIDCaseID
   * The appeal case and case identifiers.
   * @return Details of the current appeal stage for the case.
   */
  @Override
  public OrderedAppealStage getCurrentAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    PriorAppealCaseID priorAppealCaseID;
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();

    final IssueStagePositionDetails issueStagePositionDetails =
      new IssueStagePositionDetails();

    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Retrieve Prior AppealCaseID if it exists. Otherwise this is a new appeal
    // case.
    if (appealCaseAndCase.appealCaseID != 0) {
      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;
      priorAppealCaseID =
        appealRelationshipObj
          .readPriorAppealByAppealCaseAndCase(appealCaseAndCase);

      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

      // Case header variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();
      CaseTypeCode caseTypeCode;

      // AppealRelationship object and structs
      final AppealCaseID appealCaseID = new AppealCaseID();
      PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList;

      caseKey.caseID = appealCaseIDCaseID.appealCaseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = appealCaseIDCaseID.caseID;

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      if (priorAppealCount.count == 0
        && caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);
        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

        }
      }
    }

    // Determine the appeal type for the next stage in the appeal process for
    // the Issue.
    // Return Variable
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = appealCaseIDCaseID.caseID;
    issueStagePositionDetails.caseTypeID =
      IssueDeliveryFactory.newInstance().read(issueDeliveryKey).issueConfigurationID;
    issueStagePositionDetails.startDate = Date.getCurrentDate();
    issueStagePositionDetails.position = priorAppealCount.count + 1;
    orderedAppealStage = getStageDetailsAtPosition(issueStagePositionDetails);

    return orderedAppealStage;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage details in
   * a process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage details at the requested position or null if none
   * are found.
   */
  @Override
  public OrderedAppealStage getStageDetailsAtPosition(
    final IssueStagePositionDetails key) throws AppException,
    InformationalException {

    final CaseTypeIDStartDateActiveDetails caseTypeIDStartDateActiveDetails =
      new CaseTypeIDStartDateActiveDetails();

    // Variable for Appeal Process
    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    // Variables for getting the sorted list of active stages for an
    // appeal process
    OrderedAppealStageList orderedAppealStageList;
    OrderedAppealStage orderedAppealStage = null;
    final AppealProcessID appealProcessID = new AppealProcessID();

    try {
      // Get the active appeal process for this issue based on the
      // start date provided.
      caseTypeIDStartDateActiveDetails.startDate = key.startDate;
      caseTypeIDStartDateActiveDetails.caseTypeID = key.caseTypeID;
      caseTypeIDStartDateActiveDetails.recordStatus = RECORDSTATUS.NORMAL;
      appealProcessID.appealProcessID =
        appealProcessObj
          .readProcessIDByCaseTypeIDAndStartDate(caseTypeIDStartDateActiveDetails).appealProcessID;
    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for the issue
      throw new AppException(
        BPOISSUECASE.ERR_ISSUECASE_NO_ACTIVEAPPEAL_PROCESS);
    }

    final IssueAppealProcessKey issueAppealProcessKey =
      new IssueAppealProcessKey();

    issueAppealProcessKey.appealProcessID = appealProcessID.appealProcessID;

    // Get ordered list of stages for the active appeal process
    orderedAppealStageList = listOrderedActiveStages(issueAppealProcessKey);

    // Get the appeal stage at the specified position
    if (key.position < orderedAppealStageList.orderedAppealStage.size()) {

      orderedAppealStage =
        orderedAppealStageList.orderedAppealStage.item((int) key.position);

    }
    return orderedAppealStage;
  }

  // END, CR00284786

  // ___________________________________________________________________________
  /**
   * Returns the next level stage details for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID.
   * @return Details of the next appeal stage for a case.
   */
  @Override
  public OrderedAppealStage getNextAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Details to return
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    PriorAppealCaseID priorAppealCaseID;
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();

    final IssueStagePositionDetails issueStagePositionDetails =
      new IssueStagePositionDetails();

    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Retrieve Prior AppealCaseID if it exists
    if (appealCaseIDCaseID.appealCaseID != 0) {
      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;
      // BEGIN, CR00347052, DK
      // Get the prior appeal case identifier
      priorAppealCaseID = new PriorAppealCaseID();
      final AppealCaseID appealCaseID1 = new AppealCaseID();

      appealCaseID1.appealCaseID = appealCaseIDCaseID.appealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID1);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == appealCaseIDCaseID.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00347052

      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

      // Case header variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseKey caseKey = new CaseKey();
      CaseTypeCode caseTypeCode;

      // AppealRelationship object and structs
      final AppealCaseID appealCaseID = new AppealCaseID();
      PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList;

      caseKey.caseID = appealCaseIDCaseID.appealCaseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = appealCaseIDCaseID.caseID;

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      if (priorAppealCount.count == 0
        && caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);
        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

        }
      }
    }

    // Only increase the count if the appeal case exists
    // Otherwise we are looking for the 1st stage in the appeal
    // process
    if (appealCaseIDCaseID.appealCaseID != 0) {
      priorAppealCount.count++;
    }

    // Determine the appeal type for the next stage in the appeal process for
    // the Issue.
    // BEGIN, CR00096605, RKi
    // BEGIN, CR00284786, DG
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = appealCaseIDCaseID.caseID;
    issueStagePositionDetails.caseTypeID =
      IssueDeliveryFactory.newInstance().read(issueDeliveryKey).issueConfigurationID;
    issueStagePositionDetails.startDate = Date.getCurrentDate();
    issueStagePositionDetails.position = priorAppealCount.count;
    orderedAppealStage = getStageDetailsAtPosition(issueStagePositionDetails);
    // END, CR00096605
    // END, CR00284786

    return orderedAppealStage;
  }

}
