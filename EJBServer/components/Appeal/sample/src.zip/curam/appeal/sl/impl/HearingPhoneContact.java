/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingPhoneContactFactory;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingContactDetails;
import curam.appeal.sl.entity.struct.HearingPhoneContactDtls;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AddToHearingPhoneContactDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingContactDetailsList;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingPhoneContactDetails;
import curam.appeal.sl.struct.HearingPhoneContactHearingIDKey;
import curam.appeal.sl.struct.HearingPhoneContactIDKey;
import curam.appeal.sl.struct.ModifyHearingPhoneContactDetails;
import curam.appeal.sl.struct.ModifyHearingPhoneContactStatusDetails;
import curam.appeal.sl.struct.ReadForModifyDetails;
import curam.appeal.sl.struct.ReadHearingPhoneContactDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.PHONETYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.MaintainConcernRolePhoneFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRolePhoneNumber;
import curam.core.intf.MaintainConcernRolePhone;
import curam.core.intf.PhoneNumber;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.PhoneNumberDtls;
import curam.message.BPOHEARINGPHONECONTACT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the HearingPhoneNumber
 * service layer.
 * 
 */
public abstract class HearingPhoneContact extends
  curam.appeal.sl.base.HearingPhoneContact {

  // ___________________________________________________________________________
  /**
   * Lists all phone contacts for the given hearing.
   * 
   * @param key
   * The Hearing ID associated with the Hearing phone contact
   * 
   * @return hearingContactDetailsList list of all hearing phone contacts
   */
  @Override
  public HearingContactDetailsList list(
    final HearingPhoneContactHearingIDKey key) throws AppException,
    InformationalException {

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Hearing Phone Contact object
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.entity.fact.HearingPhoneContactFactory.newInstance();

    hearingKey.hearingID = key.hearingID;

    // Hearing case status details
    final HearingCaseStatusDtls hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Hearing phone contact key
    curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey;

    // Hearing contact details variables
    HearingContactDetailsList hearingContactDetailsListRet;
    curam.appeal.sl.entity.struct.HearingContactDetailsList hearingContactDetailsList;
    HearingContactDetails[] hearingContactDetailsArray;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseStatusDtls.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Get phone contact details
    hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();
    hearingPhoneContactHearingIDKey.hearingID = key.hearingID;
    hearingContactDetailsList =
      hearingPhoneContactObj
        .searchPhoneContacts(hearingPhoneContactHearingIDKey);
    hearingContactDetailsListRet = new HearingContactDetailsList();

    hearingContactDetailsArray = hearingContactDetailsList.dtls.items();

    for (int i = 0; i < hearingContactDetailsArray.length; i++) {

      hearingContactDetailsListRet.hearingContactDetails
        .addRef(hearingContactDetailsArray[i]);

    }

    return hearingContactDetailsListRet;

  }

  // ___________________________________________________________________________
  /**
   * Creates new phone contact.
   * 
   * @param details
   * Details of the hearing phone contact
   */
  @Override
  public void create(final HearingPhoneContactDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();

    curam.appeal.sl.entity.struct.HearingKey hearingKey;

    // Hearing case variables
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Unique object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Case Participant Role variables
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails =
      new CaseIDCaseRefAndParticipantRoleIDDetails();

    // Concern Role variables
    final ConcernRolePhoneNumber concernRolePhoneNumberObj =
      ConcernRolePhoneNumberFactory.newInstance();
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls;

    // Phone Number variables
    final PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberDtls phoneNumberDtls;

    hearingKey = new curam.appeal.sl.entity.struct.HearingKey();
    hearingKey.hearingID = details.hearingID;

    // Get the case id
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseStatusDtls.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the Hearing Phone Contact Details
    validate(details);

    // Insert phone number
    phoneNumberDtls = new PhoneNumberDtls();
    phoneNumberDtls.phoneAreaCode = details.phoneAreaCode;
    phoneNumberDtls.phoneCountryCode = details.phoneCountryCode;
    phoneNumberDtls.phoneExtension = details.phoneExtension;
    phoneNumberDtls.phoneNumber = details.phoneNumber;
    phoneNumberDtls.statusCode = RECORDSTATUS.DEFAULTCODE;
    phoneNumberDtls.comments = details.comments;
    phoneNumberDtls.phoneNumberID = uniqueIDObj.getNextID();

    phoneNumberObj.insert(phoneNumberDtls);

    // Determine the participantRoleID for the interpreter
    caseParticipantRoleKey.caseParticipantRoleID =
      details.caseParticipantRoleID;
    caseIDCaseRefAndParticipantRoleIDDetails =
      caseParticipantRoleObj
        .readCaseIDCaseRefAndParticipantRoleID(caseParticipantRoleKey);

    // Insert entry into ConcernRolePhoneNumber
    concernRolePhoneNumberDtls = new ConcernRolePhoneNumberDtls();
    concernRolePhoneNumberDtls.concernRoleID =
      caseIDCaseRefAndParticipantRoleIDDetails.participantRoleID;
    concernRolePhoneNumberDtls.concernRolePhoneNumberID =
      uniqueIDObj.getNextID();
    concernRolePhoneNumberDtls.endDate = details.endDate;
    concernRolePhoneNumberDtls.phoneNumberID = phoneNumberDtls.phoneNumberID;
    concernRolePhoneNumberDtls.startDate = details.startDate;
    concernRolePhoneNumberDtls.typeCode = PHONETYPE.DEFAULTCODE;
    concernRolePhoneNumberObj.insert(concernRolePhoneNumberDtls);
  }

  // ___________________________________________________________________________
  /**
   * Validates inserted data.
   * 
   * @param details
   * Details of the hearing phone contact to validate
   */
  @Override
  protected void validate(final HearingPhoneContactDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00416551, KRK
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // END, CR00416551

    // Is start date specified?
    if (details.startDate.equals(Date.kZeroDate)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_STARTDATENOTSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // BEGIN, CR00416551, KRK
    if (details.endDate.equals(Date.kZeroDate)) {

      ValidationManagerFactory
        .getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(
            BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_ENDDATENOTSPECIFIED),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          ValidationManagerConst.kSetTwo, 0);
    }

    // Is end date set before the start date?
    if (!details.endDate.isZero()
      && details.endDate.before(details.startDate)) {
      // END, CR00416551

      final AppException e =
        new AppException(
          BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_PHONENUMBERINVALIDSTARTDATE);

      // Specify the arguments
      e.arg(details.startDate);
      e.arg(details.endDate);

      informationalManager.addInformationalMsg(e, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Is phone country code specified?
    if (StringUtil.isNullOrEmpty(details.phoneCountryCode)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_COUNTRYCODENOTSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Is phone area code specified?
    if (StringUtil.isNullOrEmpty(details.phoneAreaCode)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_AREACODENOTSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Is contact phone number specified?
    if (StringUtil.isNullOrEmpty(details.phoneNumber)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_PHONENUMBERNOTSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Case participant role must exist for the appeal case
    if (details.caseParticipantRoleID == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGPHONECONTACT.ERR_APPEAL_FV_CASEPARTICIPANTMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);
    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Adds an existing phone number to the hearing phone contacts
   * 
   * @param details
   * The details of the phone number to be added
   */
  @Override
  public void addPhoneNumber(final AddToHearingPhoneContactDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Hearing phone contact variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.entity.fact.HearingPhoneContactFactory.newInstance();
    HearingPhoneContactDtls hearingPhoneContactDtls;

    // Hearing case variables
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Unique object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    hearingKey.hearingID = details.hearingcontactDetails.hearingID;

    // Get the case id
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseStatusDtls.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validatePhoneNumber(details);

    // Insert details into Hearing Phone Contact
    hearingPhoneContactDtls = new HearingPhoneContactDtls();
    hearingPhoneContactDtls.caseParticipantRoleID =
      details.hearingcontactDetails.caseParticipantRoleID;
    hearingPhoneContactDtls.hearingID =
      details.hearingcontactDetails.hearingID;
    hearingPhoneContactDtls.concernRolePhoneNumberID =
      details.hearingcontactDetails.concernRolePhoneNumberID;
    hearingPhoneContactDtls.hearingPhoneContactID = uniqueIDObj.getNextID();
    hearingPhoneContactDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    hearingPhoneContactObj.insert(hearingPhoneContactDtls);

  }

  // ___________________________________________________________________________
  /**
   * Validates the details to be added to the hearing phone contact.
   * 
   * @param details
   * Details of the hearing phone contact to validate
   */
  @Override
  public void validatePhoneNumber(
    final AddToHearingPhoneContactDetails details) throws AppException,
    InformationalException {

    // Hearing case status details
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingKey hearingKey;

    // Hearing Phone Contact variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();
    curam.appeal.sl.entity.struct.HearingContactDetailsList hearingContactDetailsList;

    hearingKey = new curam.appeal.sl.entity.struct.HearingKey();
    hearingKey.hearingID = details.hearingcontactDetails.hearingID;

    // Read hearing case status
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // If hearing type is not status 'SCHEDULED', throw validation exception
    if (!hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      throw new AppException(
        curam.message.BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_FV_STATUSNOTSCHEDULED);

    }

    // check that an active phone number doesn't already exist for the hearing
    hearingPhoneContactHearingIDKey.hearingID =
      details.hearingcontactDetails.hearingID;

    try {
      hearingContactDetailsList =
        hearingPhoneContactObj
          .searchPhoneContacts(hearingPhoneContactHearingIDKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      hearingContactDetailsList = null;
    }

    if (hearingContactDetailsList != null) {

      // Search for matching active number
      for (int i = 0; i < hearingContactDetailsList.dtls.size(); i++) {

        if (hearingContactDetailsList.dtls.item(i).concernRolePhoneNumberID == details.hearingcontactDetails.concernRolePhoneNumberID
          && hearingContactDetailsList.dtls.item(i).recordStatus
            .equals(RECORDSTATUS.NORMAL)) {

          throw new AppException(
            curam.message.BPOHEARINGPHONECONTACT.ERR_PHONE_CONTACT_EXISTS);
        }

      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a specified hearing phone contact
   * 
   * @param key
   * Unique internal reference number of the hearing phone contact
   * @return The details of the hearing phone contact to be modified
   */
  @Override
  public ReadForModifyDetails
    readForModify(final HearingPhoneContactIDKey key) throws AppException,
      InformationalException {

    // Hearing Phone Contact variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingPhoneContactIDKey hearingPhoneContactIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactIDKey();
    curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();

    final ReadForModifyDetails readForModifyDetails =
      new ReadForModifyDetails();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read hearing id
    hearingPhoneContactIDKey.hearingPhoneContactID =
      key.hearingPhoneContactIDKey.hearingPhoneContactID;
    hearingPhoneContactHearingIDKey =
      hearingPhoneContactObj.readHearingID(hearingPhoneContactIDKey);

    // Read hearing Case ID
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      hearingPhoneContactHearingIDKey.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve the hearing phone contact details
    readForModifyDetails.readForModifyHearingPhoneContactDetails =
      hearingPhoneContactObj.readDetailsForModify(hearingPhoneContactIDKey);

    return readForModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the details of a specified hearing phone contact
   * 
   * @param key
   * Unique reference number of the hearing phone contact
   * @return The details of the hearing phone contact
   */
  @Override
  public ReadHearingPhoneContactDetails read(
    final HearingPhoneContactIDKey key) throws AppException,
    InformationalException {

    // Hearing Phone Contact variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingPhoneContactIDKey hearingPhoneContactIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactIDKey();
    curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();

    final ReadHearingPhoneContactDetails readHearingPhoneContactDetails =
      new ReadHearingPhoneContactDetails();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read hearing id
    hearingPhoneContactIDKey.hearingPhoneContactID =
      key.hearingPhoneContactIDKey.hearingPhoneContactID;
    hearingPhoneContactHearingIDKey =
      hearingPhoneContactObj.readHearingID(hearingPhoneContactIDKey);

    // Read hearing Case ID
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      hearingPhoneContactHearingIDKey.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve the hearing phone contact details
    readHearingPhoneContactDetails.readHearingPhoneContactDetails =
      hearingPhoneContactObj.readDetails(hearingPhoneContactIDKey);

    return readHearingPhoneContactDetails;
  }

  // ___________________________________________________________________________
  /**
   * modifies the status of the hearing phone contact to canceled
   * 
   * @param details
   * The status and reference to the hearing phone contact
   */
  @Override
  public void cancel(final ModifyHearingPhoneContactStatusDetails details)
    throws AppException, InformationalException {

    // Hearing Phone Contact Variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      curam.appeal.sl.entity.fact.HearingPhoneContactFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingPhoneContactIDKey hearingPhoneContactIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactIDKey();
    final curam.appeal.sl.entity.struct.HearingPhoneContactModifyStatusDetails hearingPhoneContactModifyStatusDetails =
      new curam.appeal.sl.entity.struct.HearingPhoneContactModifyStatusDetails();
    curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Read hearing id
    hearingPhoneContactIDKey.hearingPhoneContactID =
      details.hearingPhoneContactID;
    hearingPhoneContactHearingIDKey =
      hearingPhoneContactObj.readHearingID(hearingPhoneContactIDKey);

    // Read hearing Case ID
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      hearingPhoneContactHearingIDKey.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Cancel hearing phone contact
    if (!details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      hearingPhoneContactModifyStatusDetails.recordStatus =
        RECORDSTATUS.CANCELLED;
      hearingPhoneContactModifyStatusDetails.versionNo = details.versionNo;
      hearingPhoneContactObj.modifyStatus(hearingPhoneContactIDKey,
        hearingPhoneContactModifyStatusDetails);
    } else {
      throw new AppException(
        BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_ALREADY_CANCELED);
    }
  }

  // ___________________________________________________________________________
  /**
   * Modifies a hearing phone contact
   * 
   * @param details
   * The details to be modified
   */
  @Override
  public void modify(final ModifyHearingPhoneContactDetails details)
    throws AppException, InformationalException {

    // Hearing Phone Contact variables
    final curam.appeal.sl.entity.intf.HearingPhoneContact hearingPhoneContactObj =
      HearingPhoneContactFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingPhoneContactIDKey hearingPhoneContactIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactIDKey();
    curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey hearingPhoneContactHearingIDKey =
      new curam.appeal.sl.entity.struct.HearingPhoneContactHearingIDKey();
    curam.appeal.sl.entity.struct.ReadForModifyHearingPhoneContactDetails readForModifyHearingPhoneContactDetails =
      new curam.appeal.sl.entity.struct.ReadForModifyHearingPhoneContactDetails();

    // Hearing variables
    final curam.appeal.sl.intf.Hearing hearing_boObj =
      curam.appeal.sl.fact.HearingFactory.newInstance();
    HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Maintain Concern Role Phone variables
    final MaintainPhoneNumberKey maintainPhoneNumberKey =
      new MaintainPhoneNumberKey();

    final MaintainConcernRolePhone maintainConcernRolePhoneObj =
      MaintainConcernRolePhoneFactory.newInstance();

    // Read hearing id
    hearingPhoneContactIDKey.hearingPhoneContactID =
      details.hearingPhoneContactID;
    hearingPhoneContactHearingIDKey =
      hearingPhoneContactObj.readHearingID(hearingPhoneContactIDKey);

    // Read hearing Case ID
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID =
      hearingPhoneContactHearingIDKey.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read for extra details which haven't been passed in
    readForModifyHearingPhoneContactDetails =
      hearingPhoneContactObj.readDetailsForModify(hearingPhoneContactIDKey);

    // Check if hearing status code of phone number is canceled
    if (!readForModifyHearingPhoneContactDetails.phoneContactStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      // set up details in order to modify phone number
      final ConcernRolePhoneDetails concernRolePhoneDetails =
        new ConcernRolePhoneDetails();

      concernRolePhoneDetails.concernRolePhoneNumberID =
        readForModifyHearingPhoneContactDetails.concernRolePhoneNumberID;
      concernRolePhoneDetails.concernRoleID =
        readForModifyHearingPhoneContactDetails.concernRoleID;
      concernRolePhoneDetails.typeCode =
        readForModifyHearingPhoneContactDetails.typeCode;
      concernRolePhoneDetails.statusCode =
        readForModifyHearingPhoneContactDetails.phoneNumberStatus;
      concernRolePhoneDetails.startDate =
        readForModifyHearingPhoneContactDetails.phoneStartDate;
      concernRolePhoneDetails.endDate =
        readForModifyHearingPhoneContactDetails.phoneEndDate;
      concernRolePhoneDetails.versionNo =
        readForModifyHearingPhoneContactDetails.concernRolePhoneVersionNo;
      concernRolePhoneDetails.phoneCountryCode = details.phoneCountryCode;
      concernRolePhoneDetails.phoneAreaCode = details.phoneAreaCode;
      concernRolePhoneDetails.phoneExtension = details.phoneExtension;
      concernRolePhoneDetails.phoneNumber = details.phoneNumber;
      concernRolePhoneDetails.comments = details.comments;

      // If the phoneNumberID is the same as the primaryPhoneNumberID,
      // the primaryPhoneInd is set to true
      concernRolePhoneDetails.primaryPhoneInd =
        readForModifyHearingPhoneContactDetails.phoneNumberID == readForModifyHearingPhoneContactDetails.primaryPhoneNumberID;

      maintainPhoneNumberKey.concernRoleID =
        readForModifyHearingPhoneContactDetails.concernRoleID;

      // Call core functionality to modify the details
      maintainConcernRolePhoneObj.modifyPhoneNumber(maintainPhoneNumberKey,
        concernRolePhoneDetails);

    } else {
      throw new AppException(
        BPOHEARINGPHONECONTACT.ERR_HEARING_PHONE_CONTACT_CANCELED);
    }
  }
}
