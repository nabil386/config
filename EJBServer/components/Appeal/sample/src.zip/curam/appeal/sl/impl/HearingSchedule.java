/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.HearingActivityLinkFactory;
import curam.appeal.sl.entity.fact.HearingParticipationFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.HearingActivityLink;
import curam.appeal.sl.entity.intf.HearingParticipation;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.intf.ThirdParty;
import curam.appeal.sl.entity.struct.AdjournedOrCompletedHearing;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealContinueDetails;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppealedCaseDetailsList;
import curam.appeal.sl.entity.struct.CancelHearingCaseParticipantRoleDetails;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseParticipantRoleID_eoDetails;
import curam.appeal.sl.entity.struct.HearingActivityIDDetailsList;
import curam.appeal.sl.entity.struct.HearingActivityIDKey;
import curam.appeal.sl.entity.struct.HearingActivityLinkDtls;
import curam.appeal.sl.entity.struct.HearingCaseIDScheduledDateTimeStatusCode;
import curam.appeal.sl.entity.struct.HearingCaseUserDtls;
import curam.appeal.sl.entity.struct.HearingCaseUserDtlsList;
import curam.appeal.sl.entity.struct.HearingConcernRoleDetailsList;
import curam.appeal.sl.entity.struct.HearingDateAndLocationDetails;
import curam.appeal.sl.entity.struct.HearingDtls;
import curam.appeal.sl.entity.struct.HearingIDKey;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingParticipantKey;
import curam.appeal.sl.entity.struct.HearingParticipatedDetailsList;
import curam.appeal.sl.entity.struct.HearingParticipationDtls;
import curam.appeal.sl.entity.struct.HearingPostponeDateDetails;
import curam.appeal.sl.entity.struct.HearingPostponeModifyDetails;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingScheduleDetails;
import curam.appeal.sl.entity.struct.HearingStatusDateTypeDetails;
import curam.appeal.sl.entity.struct.HearingStatusDetails;
import curam.appeal.sl.entity.struct.HearingUserRoleDtls;
import curam.appeal.sl.entity.struct.HearingUserRoleStatusKey;
import curam.appeal.sl.entity.struct.ModifyStatusCodesDetails;
import curam.appeal.sl.entity.struct.ParticipantRoleKeyList;
import curam.appeal.sl.entity.struct.PostponedHearingKey;
import curam.appeal.sl.entity.struct.ProductDeliveryIDDetailsList;
import curam.appeal.sl.entity.struct.ReadLocationType;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.ContinuanceCorrespondenceFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.fact.HearingWitnessFactory;
import curam.appeal.sl.fact.ScheduleCorrespondenceFactory;
import curam.appeal.sl.intf.ContinuanceCorrespondence;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.intf.HearingWitness;
import curam.appeal.sl.intf.ScheduleCorrespondence;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.AppealEventTypeDetails;
import curam.appeal.sl.struct.CaseIDAppealCaseIDConstraintType;
import curam.appeal.sl.struct.ContinueHearingDetails;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.ExistingHearingCaseUserDtlsList;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingCaseParticipantAddressData;
import curam.appeal.sl.struct.HearingContinueEventDetails;
import curam.appeal.sl.struct.HearingContinueTypeDetails;
import curam.appeal.sl.struct.HearingDurationDetails;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingReferenceNumber;
import curam.appeal.sl.struct.HearingScheduleReturnDtls;
import curam.appeal.sl.struct.RescheduleDeskHearingDetails;
import curam.appeal.sl.struct.RescheduleExternalLocationHearingDetails;
import curam.appeal.sl.struct.RescheduleHearingDetails;
import curam.appeal.sl.struct.RescheduleHearingReviewDetails_bo;
import curam.appeal.sl.struct.RescheduleHomeHearingDetails;
import curam.appeal.sl.struct.RescheduleLocationHearingDetails;
import curam.appeal.sl.struct.ReschedulePhoneHearingDetails;
import curam.appeal.sl.struct.ScheduleDeskHearingDetails;
import curam.appeal.sl.struct.ScheduleExternalLocationHearingDetails;
import curam.appeal.sl.struct.ScheduleHearingDetails;
import curam.appeal.sl.struct.ScheduleHearingReviewDetails_bo;
import curam.appeal.sl.struct.ScheduleHomeHearingDetails;
import curam.appeal.sl.struct.ScheduleLocationHearingDetails;
import curam.appeal.sl.struct.SchedulePhoneHearingDetails;
import curam.appeal.sl.struct.ScheduleUserName;
import curam.appeal.sl.struct.ValidateContinueDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.ACTIVITYPRIORITY;
import curam.codetable.ACTIVITYTIMESTATUS;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.CONSTRAINTTYPE;
import curam.codetable.HEARINGACTIVITYTYPE;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKPRIORITY;
import curam.codetable.impl.LOCATIONSCHEDULETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.ViewStandardActivityUserDetails;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.CaseTransactionLogFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainActivityFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainUserActivityFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.KeySets;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseStatus;
import curam.core.intf.CaseTransactionLog;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainActivity;
import curam.core.intf.MaintainConcernRoleAddress;
import curam.core.intf.MaintainUserActivity;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseUserRoleDtls;
import curam.core.sl.entity.struct.CaseUserRoleKey;
import curam.core.sl.entity.struct.LocationDateAndTypeKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.ReadByCaseIDTypeAndStatusKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleIDTypeDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleIDTypeKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.entity.struct.SlotDtls;
import curam.core.sl.entity.struct.SlotForSchedulingDetails;
import curam.core.sl.entity.struct.SlotForSchedulingDetailsList;
import curam.core.sl.fact.SlotAllocationFactory;
import curam.core.sl.fact.SlotFactory;
import curam.core.sl.intf.Slot;
import curam.core.sl.intf.SlotAllocation;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.DetermineWorkItemKey;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.sl.struct.ReadTransactionLogDetailsList;
import curam.core.sl.struct.SlotAllocationAddDetails;
import curam.core.sl.struct.SlotAllocationRemoveDetails;
import curam.core.sl.struct.SlotKey;
import curam.core.sl.struct.TaskCreateDetails;
import curam.core.sl.struct.UserWorkItemDetails;
import curam.core.struct.ActivityIntervalDetails;
import curam.core.struct.AttendeeNameIDDetails;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderStatusAndFromDateDtls;
import curam.core.struct.CaseIDList;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusEndDateTimeDetails;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.CaseTransactionLogDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.core.struct.CreateUserActivityWarnConflictResult;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainActivityKey;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.SearchUserByDateRangeResult;
import curam.core.struct.UniqueIDKeySet;
import curam.core.struct.UserActivityKey;
import curam.core.struct.UserActivitySearchKey;
import curam.core.struct.UsersKey;
import curam.core.struct.VersionNumberDetails;
import curam.events.SCHEDULEHEARING;
import curam.message.BPOAPPEALCOMMUNICATION;
import curam.message.BPOCASEUSERROLE;
import curam.message.BPOHEARINGSCHEDULE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.FrequencyPattern;
import curam.util.workflow.impl.EnactmentService;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Maintains business process functionality for scheduling a hearing on a case.
 * 
 */
public abstract class HearingSchedule extends
  curam.appeal.sl.base.HearingSchedule {

  // A constant for the zero date created by the time only widget
  // which is date 1970-01-01 rather than the normal zero date.
  protected static final DateTime kZeroEPOCDate = new DateTime(0);

  /**
   * Clones details from the hearing being rescheduled for the new hearing.
   * This method caters for all types of appeals.
   * 
   * @param details
   * Reschedule hearing details
   * @param oldList
   * List of the existing reviewers/officials
   * @param oldHearing
   * Unique identification of the hearing that is going to be cloned
   */

  @Override
  protected void
    cloneReschedule(final RescheduleHearingDetails details,
      final ExistingHearingCaseUserDtlsList oldList,
      final HearingKey oldHearing) throws AppException,
      InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    final HearingKey key = new HearingKey();
    final HearingKey clonedKey = new HearingKey();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    hearingKey_bo.hearingKey.hearingID = details.hearingID;

    // updates the external official roles and activities.
    // BEGIN, CR00123228, RKi
    if (details.scheduleHearingDetails.locationType
      .equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      // update roles and activities
      updateRolesAndActivitiesForExternalUser(hearingKey_bo,
        details.scheduleHearingDetails, oldList);
    } else { // END, CR00123228
      // update roles and activities
      updateRolesAndActivities(hearingKey_bo, details.scheduleHearingDetails,
        oldList);
    }

    hearingAppealTypeCode.appealTypeCode =
      details.scheduleHearingDetails.appealTypeCode;

    // The hearing being cloned
    key.hearingKey.hearingID = oldHearing.hearingKey.hearingID;

    // The hearing whose details are being created from the cloned hearing.
    clonedKey.hearingKey.hearingID = details.hearingID;

    // clone hearing
    hearing_boObj.cloneHearing(key, clonedKey, hearingAppealTypeCode);

  }

  /**
   * Continues a hearing for all appeal types.
   * 
   * @param details
   * Hearing details
   * @param type
   * Hearing appeal type code
   * @return
   * Informational messages
   */
  @Override
  protected InformationalMsgDtlsList continueAHearing(
    final ContinueHearingDetails details, final HearingAppealTypeCode type)
    throws AppException, InformationalException {

    // Return value
    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Appeal entity variable
    final ModifyStatusCodesDetails modifyStatusCodesDetails =
      new ModifyStatusCodesDetails();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingStatusDateTypeDetails hearingStatusDateTypeDetails;
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingScheduleDate hearingScheduleDate;

    final ValidateContinueDetails validateContinueDetails =
      new ValidateContinueDetails();
    final HearingPostponeModifyDetails hearingPostponeModifyDetails =
      new HearingPostponeModifyDetails();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    final PostponedHearingKey postponedHearingKey = new PostponedHearingKey();
    HearingPostponeDateDetails hearingPostponeDateDetails;

    // Continue hearing type details
    final ContinueHearingDetails continueHearingDetails =
      new ContinueHearingDetails();
    final HearingContinueTypeDetails hearingContinueTypeDetails =
      new HearingContinueTypeDetails();

    // Hearing Continue Event details
    final HearingContinueEventDetails hearingContinueEventDetails =
      new HearingContinueEventDetails();

    // BEGIN, CR00115728, RKi
    // Identify the Hearing and the Hearing Case
    hearingKey.hearingID = details.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // End, CR00115728, RKi
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // read status, date and type
    hearingStatusDateTypeDetails =
      hearingObj.readStatusAndDateAndType(hearingKey);

    // read scheduled date
    hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);

    // set validate continue details
    validateContinueDetails.caseID = hearingCaseID.caseID;
    validateContinueDetails.postponedDate = details.postponeDate;
    // set validate continue details
    validateContinueDetails.scheduledDateTime =
      hearingScheduleDate.scheduledDateTime;
    validateContinueDetails.statusCode =
      hearingStatusDateTypeDetails.statusCode;

    // validate continue hearing
    validateContinue(validateContinueDetails);

    // set hearing type code for notification
    hearingContinueTypeDetails.hearingTypeCode =
      hearingStatusDateTypeDetails.typeCode;

    // set appeal type code for notification
    hearingContinueTypeDetails.appealTypeCode = type.appealTypeCode;

    continueHearingDetails.assign(details);

    postponedHearingKey.caseID = hearingCaseID.caseID;
    postponedHearingKey.postponeDate = details.postponeDate.getDateTime();
    postponedHearingKey.statusCode1 = HEARINGSTATUS.CONTINUED;

    // read postponed adjourned hearing for the date specified, if it exists
    try {
      hearingPostponeDateDetails =
        hearingObj
          .readLatestPostponedByCaseIDStatusAndDate(postponedHearingKey);
    } catch (final RecordNotFoundException e) {
      hearingPostponeDateDetails = null;
    }

    // set postpone date details
    if (hearingPostponeDateDetails != null) {

      // if there is postponed hearing for the date, add one second
      hearingPostponeModifyDetails.postponeDate =
        hearingPostponeDateDetails.postponeDate.addTime(0, 0, 1);

    } else {

      // if postponed does not exist, add it
      hearingPostponeModifyDetails.postponeDate =
        details.postponeDate.getDateTime();
    }

    hearingPostponeModifyDetails.postponeReasonCode =
      details.postponeReasonCode;
    // leave status as scheduled until later
    hearingPostponeModifyDetails.statusCode = HEARINGSTATUS.SCHEDULED;
    hearingPostponeModifyDetails.postponeReasonText = details.comments;

    // modify postpone details
    hearingObj
      .modifyPostponeDetails(hearingKey, hearingPostponeModifyDetails);

    // BEGIN, CR00115728, RKi
    // Update schedule date for the schedule hearing task
    final AppealCaseID appealCaseID = new AppealCaseID();

    appealCaseID.caseID = hearingCaseID.caseID;
    createScheduleHearingTask(appealCaseID);
    final ContinuanceCorrespondence continuanceCorrespondenceObj =
      ContinuanceCorrespondenceFactory.newInstance();

    // Create and send notices. This must be done prior to changing the case
    // status, as the document generation will look for a scheduled status,
    // but after updating the postpone details, as these are also read by the
    // document generation.
    informationalMsgDtlsList =
      continuanceCorrespondenceObj.createNotices(hearingContinueTypeDetails,
        continueHearingDetails);
    // END, CR00115728
    // change status
    modifyStatusCodesDetails.statusCode = HEARINGSTATUS.CONTINUED;
    hearingObj.modifyStatus(hearingKey, modifyStatusCodesDetails);

    hearingContinueEventDetails.appealTypeCode = type.appealTypeCode;
    hearingContinueEventDetails.caseID = hearingCaseID.caseID;
    hearingContinueEventDetails.hearingID = details.hearingID;

    // insert continue event
    insertContinueEvents(hearingContinueEventDetails);

    return informationalMsgDtlsList;

  }

  /**
   * Continues a hearing for a hearing case appeal.
   * 
   * @param details
   * Hearing details
   * @return
   * Informational messages
   */
  @Override
  public InformationalMsgDtlsList continueHearing(
    final ContinueHearingDetails details) throws AppException,
    InformationalException {

    // Return value
    InformationalMsgDtlsList informationalMsgDtlsList;

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Hearing Activity Link objects and structs
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingIDKey hearingIDKey = new HearingIDKey();
    HearingActivityIDDetailsList hearingActivityIDDetailsList =
      new HearingActivityIDDetailsList();

    // Maintain Activity objects and structs
    final MaintainActivity maintainActivityObj =
      MaintainActivityFactory.newInstance();
    MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;

    // common processing for all types
    informationalMsgDtlsList =
      continueAHearing(details, hearingAppealTypeCode);

    hearingKey.hearingID = details.hearingID;
    // BEGIN, CR00123104, RKi
    final ReadLocationType locationType =
      hearingObj.readLocationTypeByHearingID(hearingKey);

    // END, CR00123104

    if (locationType.locationType.equals(HEARINGLOCATIONTYPE.INTERNAL)) {

      // Slot allocation variables
      final SlotAllocation slotAllocationObj =
        SlotAllocationFactory.newInstance();
      final SlotAllocationRemoveDetails slotAllocationRemoveDetails =
        new SlotAllocationRemoveDetails();

      // remove old slot allocation
      final HearingDateAndLocationDetails hearingDateAndLocationDetails =
        hearingObj.readScheduledDateAndLocation(hearingKey);
      final DateTime scheduledDateTime =
        hearingDateAndLocationDetails.scheduledDateTime;

      slotAllocationRemoveDetails.locationID =
        hearingDateAndLocationDetails.locationID;
      slotAllocationRemoveDetails.slotAllocationDate =
        new Date(scheduledDateTime);

      // Set the start time to be the previous schedule time
      // of the hearing.

      // BEGIN, CR00233538, PM
      // Fill the start time with the default date value.
      final Calendar oldStartTimeCalendar = scheduledDateTime.getCalendar();

      oldStartTimeCalendar.set(Calendar.YEAR, 1970);
      oldStartTimeCalendar.set(Calendar.MONTH, 1);
      oldStartTimeCalendar.set(Calendar.DAY_OF_YEAR, 1);
      final DateTime oldStartTime = new DateTime(oldStartTimeCalendar);

      slotAllocationRemoveDetails.startTime =
        TimeZoneUtility.getTimeZoneAdjustedDateTime(oldStartTime,
          TransactionInfo.getUserTimeZone());
      // END, CR00233538

      slotAllocationObj.remove(slotAllocationRemoveDetails);

    }

    // Find all entries with matching hearing ID to one being continued
    hearingIDKey.hearingID = hearingKey.hearingID;
    hearingActivityIDDetailsList =
      hearingActivityLinkObj.searchActivityIDByHearingID(hearingIDKey);

    // For each hearing activity found, change record status to canceled.
    for (int i = 0; i < hearingActivityIDDetailsList.dtls.size(); i++) {

      maintainActivityKey.activityID =
        hearingActivityIDDetailsList.dtls.item(i).activityID;

      maintainActivityDetails =
        maintainActivityObj.viewActivity(maintainActivityKey);
      maintainActivityDetails.recordStatusCode = RECORDSTATUS.CANCELLED;

      maintainActivityObj.modifyActivity(maintainActivityDetails);

    }

    // BEGIN, CR CR00049931, NSP
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    final curam.appeal.sl.entity.intf.Hearing hearingObj1 =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    hearingCaseID = hearingObj1.readCase(hearingKey);

    if (hearingCaseID.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingCaseID.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.HEARING_CONTINUED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = hearingCaseID.caseID;
      ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog caseTransactionObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls caseTransactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911
      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {
            // BEGIN, CR00071911, RKi
            caseTransactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            caseTransactionDtls.userName =
              systemUser.getUserDetails().userName;
            caseTransactionDtls.transactionType =
              CASETRANSACTIONEVENTS.HEARING_CASE_CREATED;
            caseTransactionObj.insert(caseTransactionDtls);
            // END, CR00071911
          }
        }
      }

    }
    // END, CR CR00049931
    return informationalMsgDtlsList;

  }

  /**
   * Continues a hearing review for a hearing case appeal.
   * 
   * @param dtls
   * Hearing details
   * @return
   * Informational messages
   */
  @Override
  public InformationalMsgDtlsList continueHearingReview(
    final ContinueHearingDetails dtls) throws AppException,
    InformationalException {

    // Return value
    InformationalMsgDtlsList informationalMsgDtlsList;

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingEntityKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;

    informationalMsgDtlsList = continueAHearing(dtls, hearingAppealTypeCode);

    // read caseID
    hearingEntityKey.hearingID = dtls.hearingID;
    hearingCaseID = hearingObj.readCase(hearingEntityKey);

    // BEGIN, CR CR00049931, NSP
    if (hearingCaseID.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingCaseID.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.HEARING_REVIEW_CONTINUED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = hearingCaseID.caseID;
      ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog caseTransactionObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls caseTransactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911

      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {

            // BEGIN, CR00071911, RKi
            caseTransactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            caseTransactionDtls.userName =
              systemUser.getUserDetails().userName;
            caseTransactionDtls.transactionType =
              CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED;
            caseTransactionObj.insert(caseTransactionDtls);
            // END, CR00071911
          }
        }
      }

    }
    // END, CR CR00049931
    return informationalMsgDtlsList;
  }

  /**
   * Gets a new reference number a hearing or hearing review.
   * 
   * @return Hearing
   * reference number
   */
  @Override
  protected HearingReferenceNumber getReferenceNumber() throws AppException,
    InformationalException {

    final HearingReferenceNumber hearingReferenceNumber =
      new HearingReferenceNumber();

    // unique ID generator and key set
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    // get key set
    uniqueIDKeySet.keySetName = KeySets.KEY_SET_CASE;

    // get unique identifier
    hearingReferenceNumber.referenceNumber =
      String.valueOf(uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));

    return hearingReferenceNumber;

  }

  /**
   * Insert event records for continue hearing.
   * 
   * @param details
   * Appeal type details
   */
  @Override
  protected void insertContinueEvents(
    final HearingContinueEventDetails details) throws AppException,
    InformationalException {

    // Case Event manipulation variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Unique ID generator
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      caseEventDtls.eventTypeCode = CASEEVENTTYPE.HEARINGCONTINUED;

    } else if (details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      caseEventDtls.eventTypeCode = CASEEVENTTYPE.HEARINGREVIEWCONTINUED;

    }

    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.startDate = Date.getCurrentDate();
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.relatedID = details.hearingID;

    // save CaseEvent to database
    caseEventObj.insert(caseEventDtls);

  }

  /**
   * Insert event records for related cases.
   * 
   * @param details
   * Hearing details
   * @param type
   * Appeal event type
   */
  @Override
  protected void insertHearingEvents(final ScheduleHearingDetails details,
    final AppealEventTypeDetails type) throws AppException,
    InformationalException {

    // CaseEvent object and manipulation variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // AppealRelationship entity and manipulation variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealedCaseDetailsList appealedCaseDetailsList;
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // Unique ID generation variables
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // set case event data
    caseEventDtls.eventTypeCode = type.eventTypeCode;
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.startDate = Date.getCurrentDate();
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.NORMAL;
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.relatedID = details.hearingID;

    // insert case event for the appeal
    caseEventObj.insert(caseEventDtls);

    // List all the appealed cases associated with the appeal
    appealCaseID.appealCaseID = details.caseID;
    appealedCaseDetailsList =
      appealRelationshipObj
        .searchAppealedCaseDetailsByAppealCase(appealCaseID);

    // set data for case event for each appealed case
    for (int i = 0; i < appealedCaseDetailsList.dtls.size(); i++) {

      caseEventDtls.caseID = appealedCaseDetailsList.dtls.item(i).caseID;
      caseEventDtls.caseEventID = uniqueIDObj.getNextID();

      // insert case event for each appealed case
      caseEventObj.insert(caseEventDtls);
    }

  }

  /**
   * Manages the tasks for the reschedule of a hearing or hearing review.
   * 
   * @param hearingKey
   * Hearing scheduled details
   */
  @Override
  protected void manageRescheduleTasks(final HearingKey oldHearingKey,
    final HearingKey hearingKey) throws AppException, InformationalException {

    // Work Flow Event Object
    final Event closeTaskEvent = new Event();
    final Event createTaskEvent = new Event();

    // Raise work flow event to close the complete hearing tasks
    closeTaskEvent.eventKey.eventClass = Appeal.kEventClass;
    closeTaskEvent.eventKey.eventType =
      Appeal.kAppealCloseCompleteHearingTask;
    closeTaskEvent.primaryEventData = oldHearingKey.hearingKey.hearingID;

    EventService.raiseEvent(closeTaskEvent);

    // Raise work flow event to recreate the schedule hearing task.
    createTaskEvent.eventKey.eventClass = Appeal.kEventClass;
    createTaskEvent.eventKey.eventType = Appeal.kAppealCompleteHearingTask;
    createTaskEvent.primaryEventData = hearingKey.hearingKey.hearingID;

    EventService.raiseEvent(createTaskEvent);

  }

  /**
   * Manages the reschedule events for all types of hearing for all appeal
   * types. Cancels events for the rescheduled hearing or hearing review.
   * Creates events for newly scheduled hearing or hearing review.
   * 
   * @param details
   * Reschedule home hearing details
   */
  @Override
  protected void
    manageRescheduleEvents(final RescheduleHearingDetails details)
      throws AppException, InformationalException {

    // Hearing object and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Schedule hearing details
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Appeal event type details
    final AppealEventTypeDetails appealEventTypeDetails =
      new AppealEventTypeDetails();

    if (details.scheduleHearingDetails.appealTypeCode
      .equals(APPEALTYPE.HEARING)) {
      appealEventTypeDetails.eventTypeCode = CASEEVENTTYPE.HEARINGSCHEDULED;

    } else {

      appealEventTypeDetails.eventTypeCode =
        CASEEVENTTYPE.HEARINGREVIEWSCHEDULED;

    }

    hearingKey.hearingID = details.hearingID;

    // read appeal case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    scheduleHearingDetails.caseID = hearingCaseID.caseID;
    scheduleHearingDetails.hearingID = details.hearingID;

    // insert hearing events
    insertHearingEvents(scheduleHearingDetails, appealEventTypeDetails);

  }

  /**
   * Reschedules a hearing for a hearing case.
   * 
   * @param details
   * Reschedule hearing details
   * @return
   * Unique identification of the rescheduled hearing and
   * informational messages.
   */
  @Override
  protected HearingScheduleReturnDtls rescheduleHearing(
    final RescheduleHearingDetails details) throws AppException,
    InformationalException {

    // return value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Reschedule hearing details
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final HearingPostponeModifyDetails hearingPostponeModifyDetails =
      new HearingPostponeModifyDetails();
    final HearingDtls hearingDtls = new HearingDtls();

    // Schedule Correspondence manipulation variables
    final ScheduleCorrespondence scheduleCorrespondenceObj =
      ScheduleCorrespondenceFactory.newInstance();

    // Hearing User Role entity and manipulation variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();
    // BEGIN, CR00123228, RKi
    HearingCaseUserDtlsList hearingCaseUserDtlsList =
      new HearingCaseUserDtlsList();

    final ExistingHearingCaseUserDtlsList existingHearingCaseUserDtlsList =
      new ExistingHearingCaseUserDtlsList();
    // END, CR00123228

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.scheduleHearingDetails.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = details.scheduleHearingDetails.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // Hearing Activity Link objects and structs
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingIDKey hearingIDKey = new HearingIDKey();
    HearingActivityIDDetailsList hearingActivityIDDetailsList =
      new HearingActivityIDDetailsList();

    // Maintain Activity objects and structs
    final MaintainActivity maintainActivityObj =
      MaintainActivityFactory.newInstance();
    MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();

    final HearingKey scheduleHearingKey = new HearingKey();

    rescheduleHearingDetails.assign(details);

    // validate reschedule data
    validateReschedule(rescheduleHearingDetails);

    hearingKey.hearingID = details.hearingID;

    hearingPostponeModifyDetails.postponeDate = DateTime.getCurrentDateTime();

    hearingPostponeModifyDetails.postponeReasonCode =
      details.postponeReasonCode;
    hearingPostponeModifyDetails.statusCode = HEARINGSTATUS.RESCHEDULED;
    hearingPostponeModifyDetails.postponeReasonText =
      details.postponeReasonText;

    // modify postpone details
    hearingObj
      .modifyPostponeDetails(hearingKey, hearingPostponeModifyDetails);

    // get reference number
    final HearingReferenceNumber hearingReferenceNumber =
      getReferenceNumber();

    // Set hearing details.
    hearingDtls.assign(details.scheduleHearingDetails);

    hearingDtls.noticeDate = Date.getCurrentDate();

    hearingDtls.referenceNumber = hearingReferenceNumber.referenceNumber;
    hearingDtls.statusCode = HEARINGSTATUS.SCHEDULED;
    hearingDtls.respondentParticipatedCode = HEARINGPARTICIPATION.NOTHELD;
    hearingDtls.thirdPartyParticipatedCode = HEARINGPARTICIPATION.NOTHELD;

    // BEGIN, CR00246392, PM
    final ReadLocationType readLocationType =
      hearingObj.readLocationTypeByHearingID(hearingKey);

    hearingDtls.locationType = readLocationType.locationType;
    // END, CR00246392

    hearingObj.insert(hearingDtls);

    hearingScheduleReturnDtls.hearingKey_bo.hearingKey.hearingID =
      hearingDtls.hearingID;
    hearingUserRoleStatusKey.hearingID = details.hearingID;
    hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    if (details.scheduleHearingDetails.appealTypeCode
      .equals(APPEALTYPE.HEARINGREVIEW)) {
      hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
    } else {
      hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    }

    // BEGIN, CR00123228, RKi
    final HearingCaseUserDtls hearingCaseUserDtls = new HearingCaseUserDtls();

    if (readLocationType.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
      hearingUserRoleStatusKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      hearingUserRoleStatusKey.caseID = details.scheduleHearingDetails.caseID;
      final ParticipantRoleKeyList participantRoleKeyList =
        hearingObj
          .searchParticipantRoleIdByHearingID(hearingUserRoleStatusKey);

      // in case of external location the concern role and case participant role
      // identifiers are assigned to the existing to retrieve the official names
      for (int i = 0; i < participantRoleKeyList.dtls.size(); i++) {
        hearingCaseUserDtls.caseUserRoleID =
          participantRoleKeyList.dtls.item(i).participantRoleID;
        hearingCaseUserDtls.orgObjectLinkID =
          participantRoleKeyList.dtls.item(i).caseParticipantRoleID;
        hearingCaseUserDtlsList.dtls.addRef(hearingCaseUserDtls);
        // assign list of existing roles
        existingHearingCaseUserDtlsList.hearingCaseUserDtlsList
          .assign(hearingCaseUserDtlsList);
      }

    } else { // END, CR00123228
      // read list of users for the hearing
      hearingCaseUserDtlsList =
        hearingUserRoleObj
          .searchActiveByHearingIDAndRoletype(hearingUserRoleStatusKey);

      // assign list of existing roles
      existingHearingCaseUserDtlsList.hearingCaseUserDtlsList
        .assign(hearingCaseUserDtlsList);
    }

    // Hearing key of the hearing being cloned
    final HearingKey oldHearing = new HearingKey();

    // hearing being cloned is the old hearing
    oldHearing.hearingKey.hearingID = details.hearingID;

    // new hearing details contain new created hearing identification
    details.hearingID = hearingDtls.hearingID;

    // clone reschedule
    cloneReschedule(details, existingHearingCaseUserDtlsList, oldHearing);

    // Find all entries with matching hearing ID to one being rescheduled
    hearingIDKey.hearingID = oldHearing.hearingKey.hearingID;

    // Hearing Participation Objects
    // BEGIN, CR00124792, RKi
    final ThirdParty thirdPartyObj = ThirdPartyFactory.newInstance();
    final CaseParticipantRoleID_eoDetails caseParticipantRoleID_eoDetails =
      new CaseParticipantRoleID_eoDetails();
    final curam.appeal.sl.entity.intf.HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    final HearingParticipationDtls hearingParticipationDtls =
      new HearingParticipationDtls();
    // Parameter Object to insert Hearing Participation
    HearingParticipatedDetailsList hearingParticipatedDetailsList =
      new HearingParticipatedDetailsList();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();

    hearingIDStatusKeyHR.hearingID = oldHearing.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDStatusKeyHR.participantType = CASEPARTICIPANTROLETYPE.APPELLANT;

    hearingParticipatedDetailsList =
      hearingParticipationObj
        .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);
    for (int i = 0; i < hearingParticipatedDetailsList.dtls.size(); i++) {

      // assigning the values to insert into hearing participation
      hearingParticipationDtls.caseParticipantRoleID =
        hearingParticipatedDetailsList.dtls.item(i).caseParticipantRoleID;
      // BEGIN, CR00132410, RKi
      hearingParticipationDtls.hearingID = details.hearingID;
      // END, CR00132410
      hearingParticipationDtls.participatedCode =
        HEARINGPARTICIPATION.NOTHELD;
      hearingParticipationDtls.caseID =
        hearingParticipatedDetailsList.dtls.item(i).caseID;
      hearingParticipationObj.insert(hearingParticipationDtls);

    }

    // Parameter Object to insert Hearing Participation
    hearingIDStatusKeyHR.hearingID = hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingIDStatusKeyHR.participantType = CASEPARTICIPANTROLETYPE.THIRDPARTY;

    hearingParticipatedDetailsList =
      hearingParticipationObj
        .searchParticipantsByHearingIDParticipantType(hearingIDStatusKeyHR);

    for (int i = 0; i < hearingParticipatedDetailsList.dtls.size(); i++) {

      hearingParticipationDtls.caseParticipantRoleID =
        hearingParticipatedDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipationDtls.hearingID = hearingDtls.hearingID;
      hearingParticipationDtls.participatedCode =
        HEARINGPARTICIPATION.NOTHELD;
      hearingParticipationDtls.caseID =
        hearingParticipatedDetailsList.dtls.item(i).caseID;

      // Read ThirdParty details
      caseParticipantRoleID_eoDetails.caseParticipantRoleID =
        hearingParticipatedDetailsList.dtls.item(i).caseParticipantRoleID;
      final AppealIDAndDateDetails appealIDAndDateDetails =
        thirdPartyObj
          .readThirdPartyByCaseParticipantRoleID(caseParticipantRoleID_eoDetails);

      // If ThirdParty is not deleted, then insert the record in
      if (appealIDAndDateDetails.date.isZero()) {
        // update the third party to Hearing case.
        hearingParticipationObj.insert(hearingParticipationDtls);
      }
    }
    // END, CR00124792
    // BEGIN CR00118512 LP
    // add legal participants
    final HearingKey slHearingKey = new HearingKey();

    slHearingKey.hearingKey.hearingID = oldHearing.hearingKey.hearingID;
    final HearingCaseID hearingCaseID =
      HearingFactory.newInstance().getCase(slHearingKey);
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();

    caseParticipantRoleCaseAndTypeKey.caseID =
      hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;
    final CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList =
      caseParticipantRole
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int j = 0; j < caseParticipantRoleIDDetailsList.dtls.size(); j++) {

      hearingParticipationDtls.hearingID = hearingDtls.hearingID;
      hearingParticipationDtls.participatedCode =
        HEARINGPARTICIPATION.NOTHELD;
      hearingParticipationDtls.caseID = hearingDtls.caseID;
      // assign the caseParticipant Role value
      hearingParticipationDtls.caseParticipantRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(j).caseParticipantRoleID;

      // add legal participants
      hearingParticipationObj.insert(hearingParticipationDtls);
    }
    // END CR00118512 LP
    hearingActivityIDDetailsList =
      hearingActivityLinkObj.searchActivityIDByHearingID(hearingIDKey);

    // For each hearing activity found, change record status to canceled.
    for (int i = 0; i < hearingActivityIDDetailsList.dtls.size(); i++) {

      maintainActivityKey.activityID =
        hearingActivityIDDetailsList.dtls.item(i).activityID;

      maintainActivityDetails =
        maintainActivityObj.viewActivity(maintainActivityKey);
      maintainActivityDetails.recordStatusCode = RECORDSTATUS.CANCELLED;

      maintainActivityObj.modifyActivity(maintainActivityDetails);

    }

    // create reschedule notices
    hearingScheduleReturnDtls.informationalMsgDtlsList =
      scheduleCorrespondenceObj.createNotices(
        hearingScheduleReturnDtls.hearingKey_bo,
        details.scheduleHearingDetails);

    // manage reschedule events
    manageRescheduleEvents(details);

    // assign again, as cloneReschedule updates the list
    existingHearingCaseUserDtlsList.hearingCaseUserDtlsList
      .assign(hearingCaseUserDtlsList);

    scheduleHearingKey.hearingKey.hearingID = details.hearingID;

    // manage reschedule tasks
    manageRescheduleTasks(oldHearing, scheduleHearingKey);

    // BEGIN, CR CR00049931, NSP
    if (details.scheduleHearingDetails.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();
      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID =
        details.scheduleHearingDetails.caseID;
      if (details.scheduleHearingDetails.appealTypeCode
        .equals(APPEALTYPE.HEARING)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_RESCHEDULED;
      }
      if (details.scheduleHearingDetails.appealTypeCode
        .equals(APPEALTYPE.HEARINGREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_REVIEW_RESCHEDULED;
      }

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = details.scheduleHearingDetails.caseID;
      ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new curam.core.sl.struct.ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog transactionObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls transactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911

      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {

            transactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            transactionDtls.userName = systemUser.getUserDetails().userName;
            if (details.scheduleHearingDetails.appealTypeCode
              .equals(APPEALTYPE.HEARING)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_CASE_CREATED;
            }
            if (details.scheduleHearingDetails.appealTypeCode
              .equals(APPEALTYPE.HEARINGREVIEW)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED;
            }
            transactionDtls.caseID =
              hearingScheduleReturnDtls.hearingKey_bo.hearingKey.hearingID;
            transactionObj.insert(transactionDtls);
          }
        }
      }
    }
    // END, CR CR00049931

    // BEGIN, CR00196975, RB
    if (CASETYPECODE.CFSS_LEGALACTION.equals(caseTypeCode.caseTypeCode)) {
      slHearingKey.hearingKey.hearingID = hearingDtls.hearingID;
      manageScheduleHearingTasks(slHearingKey);
    }
    // END, CR00196975, RB

    return hearingScheduleReturnDtls;

  }

  /**
   * Reschedule a hearing review.
   * 
   * @param details
   * Hearing review details
   * 
   * @return
   * Hearing unique identifier
   */
  @Override
  public HearingScheduleReturnDtls rescheduleHearingReview(
    final RescheduleHearingReviewDetails_bo details) throws AppException,
    InformationalException {

    // return value
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    HearingDurationDetails hearingDurationDetails;

    // Appeal key
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Reschedule hearing variables
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Schedule Hearing variables
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Read the hearing case id
    hearingKey_bo.hearingKey.hearingID =
      details.rescheduleHearingReviewDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Populate the schedule hearing details
    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    scheduleHearingDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    scheduleHearingDetails.comments =
      details.rescheduleHearingReviewDetails.comments;
    scheduleHearingDetails.scheduledDateTime =
      details.rescheduleHearingReviewDetails.scheduledDateTime;
    // Get duration for hearings
    appealCaseIDKey.caseID = hearingCaseID.hearingCaseID.caseID;
    hearingDurationDetails = hearing_boObj.getDuration(appealCaseIDKey);

    scheduleHearingDetails.endTime =
      scheduleHearingDetails.scheduledDateTime.addTime(0,
        hearingDurationDetails.duration, 0);
    scheduleHearingDetails.typeCode = HEARINGTYPE.HEARINGREVIEW;

    // Populate the reschedule hearing details
    rescheduleHearingDetails.hearingID =
      details.rescheduleHearingReviewDetails.hearingID;
    rescheduleHearingDetails.postponeReasonCode =
      details.rescheduleHearingReviewDetails.postponeReasonCode;
    rescheduleHearingDetails.postponeReasonText =
      details.rescheduleHearingReviewDetails.postponeReasonText;
    rescheduleHearingDetails.scheduleHearingDetails = scheduleHearingDetails;
    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList =
      details.scheduleUserNameList;
    rescheduleHearingDetails.versionNo =
      details.rescheduleHearingReviewDetails.versionNo;

    // reschedule hearing

    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);

    return hearingScheduleReturnDtls;

  }

  /**
   * Reschedules a home based hearing for a hearing case.
   * 
   * @param details
   * Reschedule home hearing details
   * @return
   * Unique identification of the rescheduled hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls rescheduleHomeHearing(
    final RescheduleHomeHearingDetails details) throws AppException,
    InformationalException {

    // return value
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Reschedule Hearing details
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    hearingKey.hearingID = details.rescheduleHearingDetailsCommon.hearingID;

    // read hearing case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    // map common details
    rescheduleHearingDetails.assign(details.rescheduleHearingDetailsCommon);
    rescheduleHearingDetails.scheduleHearingDetails.appealTypeCode =
      APPEALTYPE.HEARING;
    rescheduleHearingDetails.scheduleHearingDetails.comments =
      details.rescheduleHearingDetailsCommon.comments;
    rescheduleHearingDetails.scheduleHearingDetails.caseID =
      hearingCaseID.caseID;
    rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime =
      details.rescheduleHearingDetailsCommon.scheduledDateTime;
    scheduleUserName.userName =
      details.rescheduleHearingDetailsCommon.userName;

    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);

    // map details specific for home hearing
    rescheduleHearingDetails.scheduleHearingDetails.addressID =
      details.homeHearingDetails.addressID;
    rescheduleHearingDetails.scheduleHearingDetails.typeCode =
      HEARINGTYPE.HOME;

    // Format the out of offices times so that the date part is equal to
    // the scheduled date of the hearing
    final Calendar scheduledCalendar =
      rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime
        .getCalendar();
    final Calendar fromTimeCalendar =
      details.homeHearingDetails.outOfOfficeFromTime.getCalendar();

    fromTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    fromTimeCalendar.set(Calendar.MONTH,
      scheduledCalendar.get(Calendar.MONTH));
    fromTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    rescheduleHearingDetails.scheduleHearingDetails.outOfOfficeFromTime =
      new DateTime(fromTimeCalendar);

    final Calendar toTimeCalendar =
      details.homeHearingDetails.outOfOfficeToTime.getCalendar();

    toTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    toTimeCalendar.set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    toTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    rescheduleHearingDetails.scheduleHearingDetails.outOfOfficeToTime =
      new DateTime(toTimeCalendar);

    // reschedule hearing
    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);

    return hearingScheduleReturnDtls;

  }

  /**
   * Reschedules a location based hearing for a hearing case.
   * 
   * @param details
   * Reschedule home hearing details
   * @return
   * Unique identification of the rescheduled hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls rescheduleLocationHearing(
    final RescheduleLocationHearingDetails details) throws AppException,
    InformationalException {

    // return value
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Reschedule Hearing details
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // Slot allocation variables
    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();
    final SlotAllocationAddDetails slotAllocationAddDetails =
      new SlotAllocationAddDetails();
    final SlotAllocationRemoveDetails slotAllocationRemoveDetails =
      new SlotAllocationRemoveDetails();

    // map details specific for location hearing
    // get the start time for the slot
    final Slot slotObj = SlotFactory.newInstance();
    final SlotKey slotKey = new SlotKey();

    slotKey.slotID = details.locationHearingDetails.slotID;
    final SlotDtls slotDtls = slotObj.read(slotKey).details;

    final Date newScheduledDate =
      new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        details.rescheduleHearingDetailsCommon.scheduledDateTime,
        TransactionInfo.getUserTimeZone()));

    // Set the scheduled date time to be the scheduled date and the start time
    // of the slot.

    // BEGIN, CR00233538, PM
    final Calendar dateTime = newScheduledDate.getCalendar();
    DateTime scheduledDateTime = new DateTime(dateTime);
    final Calendar scheduledDateTimeCalendar =
      scheduledDateTime.getCalendar();

    // Set the end time of the hearing.
    final Calendar endTimeCalendar = slotDtls.endTime.getCalendar();

    endTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledDateTimeCalendar.get(Calendar.DAY_OF_MONTH));
    endTimeCalendar.set(Calendar.MONTH,
      scheduledDateTimeCalendar.get(Calendar.MONTH));
    endTimeCalendar.set(Calendar.YEAR,
      scheduledDateTimeCalendar.get(Calendar.YEAR));
    endTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    rescheduleHearingDetails.scheduleHearingDetails.endTime =
      new DateTime(endTimeCalendar);
    // BEGIN, CR00312465, VT
    rescheduleHearingDetails.scheduleHearingDetails.endTime =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        rescheduleHearingDetails.scheduleHearingDetails.endTime,
        TransactionInfo.getServerTimeZone());

    // Slot end date time of the new hearing.
    final DateTime slotEndDateTime =
      new DateTime(rescheduleHearingDetails.scheduleHearingDetails.endTime);

    // END, CR00312465

    // END, CR00233538

    // BEGIN, CR00312465, VT
    hearingKey.hearingID = details.rescheduleHearingDetailsCommon.hearingID;

    // read hearing case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    // map common details
    rescheduleHearingDetails.assign(details.rescheduleHearingDetailsCommon);
    rescheduleHearingDetails.scheduleHearingDetails.appealTypeCode =
      APPEALTYPE.HEARING;
    rescheduleHearingDetails.scheduleHearingDetails.comments =
      details.rescheduleHearingDetailsCommon.comments;
    rescheduleHearingDetails.scheduleHearingDetails.caseID =
      hearingCaseID.caseID;
    scheduleUserName.userName =
      details.rescheduleHearingDetailsCommon.userName;

    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);
    // END, CR00312465

    rescheduleHearingDetails.scheduleHearingDetails.locationID =
      details.locationHearingDetails.locationID;
    rescheduleHearingDetails.scheduleHearingDetails.typeCode =
      HEARINGTYPE.LOCATION;

    // remove old slot allocation
    final HearingDateAndLocationDetails hearingDateAndLocationDetails =
      hearingObj.readScheduledDateAndLocation(hearingKey);

    // BEGIN, CR00233538, PM
    scheduledDateTime = hearingDateAndLocationDetails.scheduledDateTime;
    // END, CR00233538

    if (scheduledDateTime
      .equals(details.rescheduleHearingDetailsCommon.scheduledDateTime)) {

      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARING_DATETIME_NOT_CHANGED);
    }

    // BEGIN, CR00312465, VT
    // If the new hearing start date time is earlier than current date time,
    // set the hearing start date time to current date time.
    if (details.rescheduleHearingDetailsCommon.scheduledDateTime
      .before(DateTime.getCurrentDateTime())) {
      details.rescheduleHearingDetailsCommon.scheduledDateTime =
        TimeZoneUtility.getTimeZoneAdjustedDateTime(
          DateTime.getCurrentDateTime(), TransactionInfo.getServerTimeZone());
    }

    final DetermineWorkItemKey determineWorkItemKey =
      new DetermineWorkItemKey();

    determineWorkItemKey.userName =
      details.rescheduleHearingDetailsCommon.userName;
    determineWorkItemKey.numWorkUnits =
      details.locationHearingDetails.numberOfWorkUnits;
    determineWorkItemKey.relatedID = hearingCaseID.caseID;

    final UserWorkItemDetails userWorkItemDetails =
      SlotAllocationFactory.newInstance()
        .determineNumberOfUnitsAndDurationForUser(determineWorkItemKey);

    // Add the work item duration to the start date time to determine the end
    // date time.
    final DateTime endDateTime =
      details.rescheduleHearingDetailsCommon.scheduledDateTime.addTime(0,
        userWorkItemDetails.workItemDuration, 0);

    if (endDateTime.after(slotEndDateTime)) {
      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARINGSCHEDULE_XRV_INSUFFICIENT_TIME);
    }

    // Rescheduled start and end date times.
    rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime =
      details.rescheduleHearingDetailsCommon.scheduledDateTime;
    rescheduleHearingDetails.scheduleHearingDetails.endTime = endDateTime;
    // END, CR00312465

    // reschedule hearing
    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);

    slotAllocationRemoveDetails.locationID =
      hearingDateAndLocationDetails.locationID;
    slotAllocationRemoveDetails.slotAllocationDate =
      new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(scheduledDateTime,
        TransactionInfo.getUserTimeZone()));

    // BEGIN, CR00312465, VT
    SlotForSchedulingDetailsList slotForSchedulingDetailsList =
      new SlotForSchedulingDetailsList();

    // BEGIN, CR00333142, AKr
    final LocationDateAndTypeKey locationDateAndTypeKey =
      new LocationDateAndTypeKey();

    locationDateAndTypeKey.locationID =
      hearingDateAndLocationDetails.locationID;
    locationDateAndTypeKey.effectiveDate =
      new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(scheduledDateTime,
        TransactionInfo.getUserTimeZone()));
    locationDateAndTypeKey.locationScheduleType =
      LOCATIONSCHEDULETYPEEntry.APPEALSHEARINGS.getCode();
    locationDateAndTypeKey.status = RECORDSTATUSEntry.NORMAL.getCode();

    slotForSchedulingDetailsList =
      curam.core.sl.entity.fact.SlotFactory.newInstance()
        .searchAppealSlotsbyLocationAndDate(locationDateAndTypeKey);
    // END, CR00333142

    for (final SlotForSchedulingDetails slotForSchedulingDetails : slotForSchedulingDetailsList.dtls
      .items()) {

      final DateTime slotStartTime = slotForSchedulingDetails.startTime;
      final DateTime slotEndTime = slotForSchedulingDetails.endTime;
      final Calendar oldStartTimeCalendar = slotStartTime.getCalendar();

      oldStartTimeCalendar.set(Calendar.HOUR_OF_DAY, scheduledDateTime
        .getCalendar().get(Calendar.HOUR_OF_DAY));
      oldStartTimeCalendar.set(Calendar.MINUTE, scheduledDateTime
        .getCalendar().get(Calendar.MINUTE));
      oldStartTimeCalendar.set(Calendar.SECOND, scheduledDateTime
        .getCalendar().get(Calendar.SECOND));
      final DateTime oldStartTime = new DateTime(oldStartTimeCalendar);

      // Set the start date time to previous schedule's slot start time.
      if (oldStartTime.equals(slotStartTime)
        || oldStartTime.after(slotStartTime)
        && oldStartTime.before(slotEndTime)) {
        slotAllocationRemoveDetails.startTime =
          TimeZoneUtility.getTimeZoneAdjustedDateTime(slotStartTime,
            TransactionInfo.getUserTimeZone());
        break;
      }

    }
    // END, CR00312465

    slotAllocationObj.remove(slotAllocationRemoveDetails);

    // add new slot allocation
    slotAllocationAddDetails.positionID =
      details.locationHearingDetails.positionID;
    slotAllocationAddDetails.details.slotAllocationDate =
      new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        details.rescheduleHearingDetailsCommon.scheduledDateTime,
        TransactionInfo.getUserTimeZone()));
    slotAllocationAddDetails.details.slotID =
      details.locationHearingDetails.slotID;

    slotAllocationAddDetails.details.numberWorkUnits =
      details.locationHearingDetails.numberOfWorkUnits;

    slotAllocationObj.add(slotAllocationAddDetails);

    return hearingScheduleReturnDtls;

  }

  /**
   * Reschedules a phone based hearing for a hearing case.
   * 
   * @param details
   * Reschedule home hearing details
   * @return
   * Unique identification of the rescheduled hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls reschedulePhoneHearing(
    final ReschedulePhoneHearingDetails details) throws AppException,
    InformationalException {

    // return value
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Reschedule Hearing details
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    hearingKey.hearingID = details.rescheduleHearingDetailsCommon.hearingID;

    // read hearing case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    // map common details
    rescheduleHearingDetails.assign(details.rescheduleHearingDetailsCommon);
    rescheduleHearingDetails.scheduleHearingDetails.appealTypeCode =
      APPEALTYPE.HEARING;
    rescheduleHearingDetails.scheduleHearingDetails.comments =
      details.rescheduleHearingDetailsCommon.comments;
    rescheduleHearingDetails.scheduleHearingDetails.caseID =
      hearingCaseID.caseID;
    rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime =
      details.rescheduleHearingDetailsCommon.scheduledDateTime;
    scheduleUserName.userName =
      details.rescheduleHearingDetailsCommon.userName;

    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);

    // map details specific for phone hearing
    rescheduleHearingDetails.scheduleHearingDetails.typeCode =
      HEARINGTYPE.PHONE;
    // Format the end time so that the date is equal to the scheduled date
    final Calendar scheduledCalendar =
      rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime
        .getCalendar();
    final Calendar endTimeCalendar =
      details.phoneHearingDetails.endTime.getCalendar();

    endTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    endTimeCalendar
      .set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    endTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    rescheduleHearingDetails.scheduleHearingDetails.endTime =
      new DateTime(endTimeCalendar);
    rescheduleHearingDetails.scheduleHearingDetails.inPersonIndicator =
      details.phoneHearingDetails.inPersonIndicator;

    // reschedule hearing
    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);

    return hearingScheduleReturnDtls;

  }

  /**
   * Schedules a hearing of all types.
   * 
   * @param dtls Hearing details
   * @return Unique identifier of the new created hearing
   * and informational messages
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  protected HearingScheduleReturnDtls scheduleHearing(
    final ScheduleHearingDetails dtls) throws AppException,
    InformationalException {

    // returned value
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingDtls hearingDtls = new HearingDtls();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingPostponeDateDetails hearingPostponeDateDetails;
    HearingPostponeDateDetails hearingPostponeDateDetailsAdjourned;
    HearingPostponeDateDetails hearingPostponeDateDetailsContinued;

    // Hearing business object and manipulation variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey key = new HearingKey();
    final HearingKey clonedKey = new HearingKey();
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Hearing User Role entity and manipulation variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();
    HearingCaseUserDtlsList hearingCaseUserDtlsList;

    // Schedule Correspondence business object
    final ScheduleCorrespondence scheduleCorrespondenceObj =
      ScheduleCorrespondenceFactory.newInstance();

    // details for roles updating
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();
    final AppealEventTypeDetails appealEventTypeDetails =
      new AppealEventTypeDetails();
    final ExistingHearingCaseUserDtlsList existingHearingCaseUserDtlsList =
      new ExistingHearingCaseUserDtlsList();
    HearingCaseUserDtls hearingCaseUserDtls;

    // CaseStatus objects
    final CaseStatus caseStatusObj = CaseStatusFactory.newInstance();
    final CurrentCaseStatusKey currentCaseStatusKey =
      new CurrentCaseStatusKey();
    CaseStatusDtls caseStatusDtls = new CaseStatusDtls();
    final CaseStatusKey caseStatusKey = new CaseStatusKey();
    // BEGIN, CR00441728, RD
    final CaseStatusEndDateTimeDetails caseStatusEndDateTimeDetails =
      new CaseStatusEndDateTimeDetails();
    // END, CR00441728
    final CaseStatusDtls newCaseStatusDtls = new CaseStatusDtls();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    VersionNumberDetails versionNumberDetails;
    final CaseHeaderStatusAndFromDateDtls caseHeaderStatusAndFromDateDtls =
      new CaseHeaderStatusAndFromDateDtls();

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = dtls.caseID;
    CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = dtls.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    final AppealCaseID appealCaseID = new AppealCaseID();

    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();

    // validate data
    validateScheduleHearing(dtls);

    hearingDtls.assign(dtls);

    // set status code to 'scheduled'.
    hearingDtls.statusCode = HEARINGSTATUS.SCHEDULED;
    hearingDtls.respondentParticipatedCode = HEARINGPARTICIPATION.NOTHELD;
    hearingDtls.thirdPartyParticipatedCode = HEARINGPARTICIPATION.NOTHELD;

    // get unique reference number
    final HearingReferenceNumber hearingReferenceNumber =
      getReferenceNumber();

    // set reference number
    hearingDtls.referenceNumber = hearingReferenceNumber.referenceNumber;

    // set notice date
    hearingDtls.noticeDate = Date.getCurrentDate();

    // insert Hearing record
    hearingObj.insert(hearingDtls);

    hearingScheduleReturnDtls.hearingKey_bo.hearingKey.hearingID =
      hearingDtls.hearingID;

    // BEGIN, CR CR00020935, RKi
    final curam.appeal.sl.entity.struct.HearingKey hrngKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    hrngKey.hearingID = hearingDtls.hearingID;

    // BEGIN, CR00177498, PM
    // updates the hearing participation entity with legal participants
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

      final HearingParticipation hearingParticipationObj =
        HearingParticipationFactory.newInstance();

      final HearingParticipationDtls hearingParticipationDtls =
        new HearingParticipationDtls();
      // Parameter Object to insert Hearing Participation
      // START, CR00125994, LP
      CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
        new CaseParticipantRoleNameDetailsList();
      final ReadByCaseIDTypeAndStatusKey readByCaseIDTypeAndStatusKey =
        new ReadByCaseIDTypeAndStatusKey();

      readByCaseIDTypeAndStatusKey.caseID = hearingDtls.caseID;
      readByCaseIDTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      readByCaseIDTypeAndStatusKey.typeCode =
        CASEPARTICIPANTROLETYPE.LEGALPARTICIPANT;
      caseParticipantRoleNameDetailsList =
        CaseParticipantRoleFactory.newInstance()
          .readCaseParticipantRolesByTypeCaseIDAndStatus(
            readByCaseIDTypeAndStatusKey);
      for (final CaseParticipantRoleNameDetails caseParticipantRoleNameDetails : caseParticipantRoleNameDetailsList.dtls
        .items()) {

        // assigning the values to insert into hearing participation
        hearingParticipationDtls.caseParticipantRoleID =
          caseParticipantRoleNameDetails.caseParticipantRoleID;
        hearingParticipationDtls.hearingID = hearingDtls.hearingID;
        hearingParticipationDtls.participatedCode =
          HEARINGPARTICIPATION.NOTHELD;
        hearingParticipationDtls.caseID = hearingDtls.caseID;
        hearingParticipationObj.insert(hearingParticipationDtls);
      }
    }
    // END, CR00177498

    // BEGIN, CR00124792, RKi
    final CaseParticipantRoleID_eoDetails caseParticipantRoleID_eoDetails =
      new CaseParticipantRoleID_eoDetails();
    final ThirdParty thirdPartyObj = ThirdPartyFactory.newInstance();
    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();

    final HearingParticipationDtls hearingParticipationDtls =
      new HearingParticipationDtls();
    // Parameter Object to insert Hearing Participation
    // START, CR00125994, LP
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();
    final ReadByCaseIDTypeAndStatusKey readByCaseIDTypeAndStatusKey =
      new ReadByCaseIDTypeAndStatusKey();

    readByCaseIDTypeAndStatusKey.caseID = hearingDtls.caseID;
    readByCaseIDTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    readByCaseIDTypeAndStatusKey.typeCode = CASEPARTICIPANTROLETYPE.APPELLANT;
    caseParticipantRoleNameDetailsList =
      CaseParticipantRoleFactory.newInstance()
        .readCaseParticipantRolesByTypeCaseIDAndStatus(
          readByCaseIDTypeAndStatusKey);
    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      // assigning the values to insert into hearing participation
      hearingParticipationDtls.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipationDtls.hearingID = hearingDtls.hearingID;
      hearingParticipationDtls.participatedCode =
        HEARINGPARTICIPATION.NOTHELD;
      hearingParticipationDtls.caseID = hearingDtls.caseID;
      hearingParticipationObj.insert(hearingParticipationDtls);
    }

    // Parameter Object to insert Hearing Participation
    readByCaseIDTypeAndStatusKey.caseID = hearingDtls.caseID;
    readByCaseIDTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    readByCaseIDTypeAndStatusKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    caseParticipantRoleNameDetailsList =
      CaseParticipantRoleFactory.newInstance()
        .readCaseParticipantRolesByTypeCaseIDAndStatus(
          readByCaseIDTypeAndStatusKey);
    ;

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      hearingParticipationDtls.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      hearingParticipationDtls.hearingID = hearingDtls.hearingID;
      hearingParticipationDtls.participatedCode =
        HEARINGPARTICIPATION.NOTHELD;
      hearingParticipationDtls.caseID = hearingDtls.caseID;
      // END, CR00125994, LP

      // Read ThirdParty details
      caseParticipantRoleID_eoDetails.caseParticipantRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;
      final AppealIDAndDateDetails appealIDAndDateDetails =
        thirdPartyObj
          .readThirdPartyByCaseParticipantRoleID(caseParticipantRoleID_eoDetails);

      // If ThirdParty is not deleted, then insert the record in
      if (appealIDAndDateDetails.date.isZero()) {
        // update the third party to Hearing case.
        hearingParticipationObj.insert(hearingParticipationDtls);
      }
    }
    // END, CR00124792
    caseAndStatusKey.caseID = dtls.caseID;
    caseAndStatusKey.statusCode = HEARINGSTATUS.ADJOURNED;

    // read postponed adjourned hearing, if it exists
    try {
      hearingPostponeDateDetailsAdjourned =
        hearingObj.readLatestPostponedByCaseIDAndStatus(caseAndStatusKey);
    } catch (final RecordNotFoundException e) {
      hearingPostponeDateDetailsAdjourned = null;
    }

    caseAndStatusKey.statusCode = HEARINGSTATUS.CONTINUED;

    // read postponed continued hearing, if it exists
    try {
      hearingPostponeDateDetailsContinued =
        hearingObj.readLatestPostponedByCaseIDAndStatus(caseAndStatusKey);
    } catch (final RecordNotFoundException e) {
      hearingPostponeDateDetailsContinued = null;
    }

    // set attributes for updateRoles
    scheduleHearingDetails.assign(dtls);

    // set appeal type code
    scheduleHearingDetails.appealTypeCode = dtls.appealTypeCode;
    scheduleHearingDetails.hearingID = hearingDtls.hearingID;

    // determine which one of the postponed hearings is the latest
    if (hearingPostponeDateDetailsAdjourned != null
      && hearingPostponeDateDetailsContinued == null) {
      hearingPostponeDateDetails = hearingPostponeDateDetailsAdjourned;
    } else if (hearingPostponeDateDetailsContinued != null
      && hearingPostponeDateDetailsAdjourned == null) {
      hearingPostponeDateDetails = hearingPostponeDateDetailsContinued;
    } else if (hearingPostponeDateDetailsAdjourned != null
      && hearingPostponeDateDetailsContinued != null) {

      if (hearingPostponeDateDetailsAdjourned.postponeDate
        .after(hearingPostponeDateDetailsContinued.postponeDate)) {

        hearingPostponeDateDetails = hearingPostponeDateDetailsAdjourned;

      } else {

        hearingPostponeDateDetails = hearingPostponeDateDetailsContinued;
      }

    } else {
      hearingPostponeDateDetails = null;
    }

    if (hearingPostponeDateDetails != null) {

      // The hearing being cloned
      key.hearingKey.hearingID = hearingPostponeDateDetails.hearingID;
      // The hearing whose details are being created from the cloned hearing.
      clonedKey.hearingKey.hearingID = hearingDtls.hearingID;

      hearingAppealTypeCode.appealTypeCode = dtls.appealTypeCode;

      // clone hearing
      hearing_boObj.cloneHearing(key, clonedKey, hearingAppealTypeCode);

      hearingUserRoleStatusKey.hearingID =
        hearingPostponeDateDetails.hearingID;
      hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      // BEGIN, CR00123228, RKi
      if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        hearingUserRoleStatusKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
      } else {
        if (dtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {
          hearingUserRoleStatusKey.typeCode =
            CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
        } else {
          hearingUserRoleStatusKey.typeCode =
            CASEUSERROLETYPE.HEARINGOFFICIAL;
        }
      }// END, CR00123228

      // read list of users for the hearing
      hearingCaseUserDtlsList =
        hearingUserRoleObj
          .searchActiveByHearingIDAndRoletype(hearingUserRoleStatusKey);

      // Map the data about hearing reviewers to the list for update roles
      for (int i = 0; i < hearingCaseUserDtlsList.dtls.size(); i++) {

        hearingCaseUserDtls = new HearingCaseUserDtls();
        hearingCaseUserDtls.caseUserRoleID =
          hearingCaseUserDtlsList.dtls.item(i).caseUserRoleID;

        // Add user to the list
        existingHearingCaseUserDtlsList.hearingCaseUserDtlsList.dtls
          .addRef(hearingCaseUserDtls);
      }

    }

    // update user roles
    // BEGIN, CR00123228, RKi

    if (dtls.locationType.equals(HEARINGLOCATIONTYPE.EXTERNAL)) {

      // BEGIN, CR00126446, RKi
      hearingUserRoleStatusKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      hearingUserRoleStatusKey.caseID = dtls.caseID;
      hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      final ParticipantRoleKeyList participantRoleKeyList =
        hearingObj
          .searchParticipantRoleIdByHearingID(hearingUserRoleStatusKey);

      // Map the data about hearing reviewers to the list for update roles
      for (int i = 0; i < participantRoleKeyList.dtls.size(); i++) {

        hearingCaseUserDtls = new HearingCaseUserDtls();
        hearingCaseUserDtls.caseUserRoleID =
          participantRoleKeyList.dtls.item(i).participantRoleID;
        // BEGIN CR00125303 LP
        hearingCaseUserDtls.orgObjectLinkID =
          participantRoleKeyList.dtls.item(i).caseParticipantRoleID;
        // END CR00125303 LP
        // Add user to the list
        existingHearingCaseUserDtlsList.hearingCaseUserDtlsList.dtls
          .addRef(hearingCaseUserDtls);
      }
      // END, CR00126446

      updateRolesAndActivitiesForExternalUser(
        hearingScheduleReturnDtls.hearingKey_bo, scheduleHearingDetails,
        existingHearingCaseUserDtlsList);
    } else { // END, CR00123228
      updateRolesAndActivities(hearingScheduleReturnDtls.hearingKey_bo,
        scheduleHearingDetails, existingHearingCaseUserDtlsList);
    }

    if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      appealEventTypeDetails.eventTypeCode =
        CASEEVENTTYPE.HEARINGREVIEWSCHEDULED;

    } else {

      appealEventTypeDetails.eventTypeCode = CASEEVENTTYPE.HEARINGSCHEDULED;

    }

    // insert hearing events
    insertHearingEvents(scheduleHearingDetails, appealEventTypeDetails);

    // Raise work flow event to create the complete hearing task hearing task.

    // Create the list we will pass to the enactment service.
    final List enactmentStructs = new ArrayList();
    final TaskCreateDetails taskCreateDetails = new TaskCreateDetails();

    // Set Task Priority
    taskCreateDetails.priority = TASKPRIORITY.LOW;

    enactmentStructs.add(hearingDtls);
    enactmentStructs.add(taskCreateDetails);

    // Enact work flow to create the complete hearing task.
    EnactmentService.startProcess(Appeal.kAppealCompleteHearingTask,
      enactmentStructs);

    appealCaseID.caseID = dtls.caseID;
    // Create Witness Statement Submission Task
    hearingWitnessObj.createWitnessStatementSubmissionTask(appealCaseID);

    // remove schedule hearing task
    removeScheduleHearingTask(appealCaseID);

    key.hearingKey.hearingID = hearingDtls.hearingID;

    // notify all involved that the hearing is scheduled
    hearingScheduleReturnDtls.informationalMsgDtlsList =
      scheduleCorrespondenceObj.createNotices(key, scheduleHearingDetails);

    // Read current status
    currentCaseStatusKey.caseID = dtls.caseID;
    // BEGIN, CR00115728, RKi
    caseKey.caseID = appealCaseID.caseID;
    caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      caseHeaderKey.caseID = dtls.caseID;
      final CaseStatusCode caseStatusCode =
        caseHeader.readCaseStatus(caseHeaderKey);

      caseStatusDtls.statusCode = caseStatusCode.statusCode;
    } else {
      // BEGIN, CR00236272, AK
      caseStatusDtls =
        caseStatusObj.readCurrentStatusByCaseID1(currentCaseStatusKey);
      // END, CR00236272
    }
    // END, CR00115728

    // Update the appeal case status to 'Active' if it is 'Approved'
    if (caseStatusDtls.statusCode.equals(CASESTATUS.APPROVED)) {

      // UniqueID object
      final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

      // current Date
      final Date currentDate = Date.getCurrentDate();

      // read the version number
      caseHeaderKey.caseID = dtls.caseID;
      versionNumberDetails = caseHeaderObj.readVersionNumber(caseHeaderKey);

      // Modify the Case Header Status
      caseHeaderStatusAndFromDateDtls.startDate = currentDate;
      caseHeaderStatusAndFromDateDtls.statusCode = CASESTATUS.ACTIVE;
      caseHeaderStatusAndFromDateDtls.versionNo =
        versionNumberDetails.versionNo;
      caseHeaderObj.modifyCaseHeaderStatus(caseHeaderKey,
        caseHeaderStatusAndFromDateDtls);

      // Close current status
      caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;
      // BEGIN, CR00441728, RD
      caseStatusEndDateTimeDetails.endDate = currentDate;
      caseStatusEndDateTimeDetails.endDateTime = currentDate.getDateTime();
      caseStatusEndDateTimeDetails.versionNo = caseStatusDtls.versionNo;
      caseStatusObj.modifyEndDateTime(caseStatusKey,
        caseStatusEndDateTimeDetails);
      // END, CR00441728

      // Insert new 'Active' status record
      newCaseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
      newCaseStatusDtls.caseID = dtls.caseID;
      newCaseStatusDtls.startDate = currentDate;
      newCaseStatusDtls.endDate = Date.kZeroDate;
      newCaseStatusDtls.statusCode = CASESTATUS.ACTIVE;
      caseStatusObj.insert(newCaseStatusDtls);
    }

    // BEGIN, CR CR00049931, NSP
    if (hearingDtls.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingDtls.caseID;

      if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_SCHEDULED;
      }
      if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.HEARING_REVIEW_SCHEDULED;
      }

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);

      final SystemUser systemUser = SystemUserFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = appealCaseID.caseID;
      ReadTransactionLogDetailsList readTransactionLogDetailsList =
        new curam.core.sl.struct.ReadTransactionLogDetailsList();

      readTransactionLogDetailsList =
        caseTransactionLog.readAllTransactions(caseIDKey);
      // BEGIN, CR00071911, RKi
      final CaseTransactionLog transactionObj =
        CaseTransactionLogFactory.newInstance();
      final curam.core.struct.CaseTransactionLogDtls transactionDtls =
        new CaseTransactionLogDtls();

      // END, CR00071911

      if (readTransactionLogDetailsList.dtlsList.size() > 0) {

        for (int i = 0; i < readTransactionLogDetailsList.dtlsList.size(); i++) {
          if (readTransactionLogDetailsList.dtlsList.item(i).eventTypeDesc
            .equals(CASETRANSACTIONEVENTS.CASEPARTICIPANT_INSERT)) {
            transactionDtls.transactionDateTime =
              readTransactionLogDetailsList.dtlsList.item(i).transactionDateTime;
            transactionDtls.userName = systemUser.getUserDetails().userName;
            if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_CASE_CREATED;
            }
            if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
              transactionDtls.transactionType =
                CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED;
            }
            transactionDtls.caseID =
              hearingScheduleReturnDtls.hearingKey_bo.hearingKey.hearingID;
            transactionObj.insert(transactionDtls);
          }
        }
      }

    }
    // END, CR CR00049931

    // BEGIN, CR00196975, RB
    if (CASETYPECODE.CFSS_LEGALACTION.equals(caseTypeCode.caseTypeCode)) {
      key.hearingKey.hearingID = hearingDtls.hearingID;
      manageScheduleHearingTasks(key);
    }
    // END, CR00196975, RB

    return hearingScheduleReturnDtls;
  }

  // BEGIN, CR00196975, RB
  /**
   * Raises an event when a hearing is scheduled.
   * 
   * @param hearingKey
   * Unique identifier for the hearing.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void manageScheduleHearingTasks(final HearingKey hearingKey)
    throws AppException, InformationalException {

    final Event event = new Event();

    event.eventKey = SCHEDULEHEARING.UPDATECOURTSCHEDULEDATE;
    event.primaryEventData = hearingKey.hearingKey.hearingID;

    try {
      EventService.raiseEvent(event);
    } catch (final AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }

  // END, CR00196975, RB

  /**
   * Adding the calendar event for the hearing official.
   * 
   * @param appelantConcernRoleID
   * @param caseID
   * @param hearingOfficialRoleID
   * @param endDateTime
   * @param locationID
   * @throws InformationalException - Generic Information Exception
   * @throws AppException - Generic App Exception
   */
  protected void createCalendarEvent(final long appelantConcernRoleID,
    final long caseID, final long hearingOfficialRoleID,
    final DateTime endDateTime, final long locationID,
    final DateTime scheduledDateTime) throws AppException,
    InformationalException {

    final MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    final UserActivityKey userActivityKey = new UserActivityKey();
    final AttendeeNameIDDetails attendeeNameIDDetails =
      new AttendeeNameIDDetails();
    final UniqueID uniqueID = UniqueIDFactory.newInstance();

    // adding the event as a calendar event
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    caseEventDtls.caseID = caseID;
    caseEventDtls.caseEventID = uniqueID.getNextID();
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.HEARINGSCHEDULED;
    caseEventDtls.startDate = new Date(scheduledDateTime);
    caseEventDtls.endDate = new Date(endDateTime);
    caseEventObj.insert(caseEventDtls);

    final ConcernRoleKey key = new ConcernRoleKey();
    final ConcernRole roleObj = ConcernRoleFactory.newInstance();

    key.concernRoleID = hearingOfficialRoleID;
    final MaintainUserActivity maintainUserActivityObj =
      MaintainUserActivityFactory.newInstance();
    final ViewStandardActivityUserDetails userDetails =
      new ViewStandardActivityUserDetails();

    userActivityKey.userName = TransactionInfo.getProgramUser();
    maintainActivityDetails.activityTypeCode =
      curam.codetable.ACTIVITYTYPE.APPOINTMENT;
    maintainActivityDetails.userName = TransactionInfo.getProgramUser();
    maintainActivityDetails.concernRoleID = hearingOfficialRoleID;
    maintainActivityDetails.activityID =
      curam.util.type.UniqueID.nextUniqueID();
    maintainActivityDetails.activityTypeCode =
      curam.codetable.ACTIVITYTYPE.APPOINTMENT;
    maintainActivityDetails.frequencyPattern =
      FrequencyPattern.kZeroFrequencyPattern.toString();
    maintainActivityDetails.startDateTime = scheduledDateTime;

    userDetails.concernRoleType = curam.codetable.ACTIVITYCLIENTTYPE.PERSON;
    userDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
    userDetails.caseID = caseID;
    userDetails.allDayInd = true;
    userDetails.attendeeNameDetails =
      curam.codetable.ACTIVITYCLIENTTYPE.PERSON;
    userDetails.concernRoleID = appelantConcernRoleID;
    userDetails.startDateTime = scheduledDateTime;
    userDetails.endDateTime = endDateTime;
    userDetails.priorityCode = curam.codetable.ACTIVITYPRIORITY.MEDIUM;
    userDetails.timeStatusCode = curam.codetable.ACTIVITYTIMESTATUS.BUSY;
    userDetails.locationID = locationID;
    userDetails.concernRoleName = roleObj.read(key).concernRoleName;
    userDetails.subject =
      GeneralAppealConstants.kActivitySubject + userDetails.concernRoleName;
    maintainActivityDetails.assign(userDetails);

    maintainUserActivityObj.createUserActivityIgnoreConflict(userActivityKey,
      maintainActivityDetails, attendeeNameIDDetails);
  }

  /**
   * Schedules a hearing review.
   * 
   * @param dtls
   * Hearing review details
   * @return
   * HearingKey unique identifier of the new created hearing
   */
  @Override
  public HearingScheduleReturnDtls scheduleHearingReview(
    final ScheduleHearingReviewDetails_bo dtls) throws AppException,
    InformationalException {

    // Return variable
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Schedule Hearing variables
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Hearing objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingDurationDetails hearingDurationDetails;

    // Appeal key
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    scheduleHearingDetails.caseID = dtls.scheduleHearingReviewDetails.caseID;
    scheduleHearingDetails.comments =
      dtls.scheduleHearingReviewDetails.comments;
    scheduleHearingDetails.scheduledDateTime =
      dtls.scheduleHearingReviewDetails.scheduledDateTime;
    scheduleHearingDetails.typeCode = HEARINGTYPE.HEARINGREVIEW;
    scheduleHearingDetails.scheduleUserNameList = dtls.scheduleUserNameList;

    // BEGIN, 32119, SM
    // Get duration for hearings
    appealCaseIDKey.caseID = dtls.scheduleHearingReviewDetails.caseID;
    hearingDurationDetails = hearing_boObj.getDuration(appealCaseIDKey);
    scheduleHearingDetails.endTime =
      scheduleHearingDetails.scheduledDateTime.addTime(0,
        hearingDurationDetails.duration, 0);

    // Schedule the hearing
    hearingScheduleReturnDtls = scheduleHearing(scheduleHearingDetails);

    // Return the hearing id
    return hearingScheduleReturnDtls;

  }

  /**
   * Schedules a home based hearing.
   * 
   * @param dtls
   * Hearing details
   * @return
   * Unique identifier of the new created hearing
   * and informational messages.
   */
  @Override
  public HearingScheduleReturnDtls scheduleHomeHearing(
    final ScheduleHomeHearingDetails dtls) throws AppException,
    InformationalException {

    // Schedule Hearing Details
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // map common details
    scheduleHearingDetails.caseID = dtls.scheduleHearingDetailsCommon.caseID;
    scheduleHearingDetails.scheduledDateTime =
      dtls.scheduleHearingDetailsCommon.scheduledDateTime;
    scheduleUserName.userName = dtls.scheduleHearingDetailsCommon.userName;
    scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);
    scheduleHearingDetails.comments =
      dtls.scheduleHearingDetailsCommon.comments;

    // map home hearing details
    scheduleHearingDetails.addressID = dtls.homeHearingDetails.addressID;

    // Format the out of offices times so that the date part is equal to
    // the scheduled date of the hearing
    final Calendar scheduledCalendar =
      scheduleHearingDetails.scheduledDateTime.getCalendar();
    final Calendar fromTimeCalendar =
      dtls.homeHearingDetails.outOfOfficeFromTime.getCalendar();

    fromTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    fromTimeCalendar.set(Calendar.MONTH,
      scheduledCalendar.get(Calendar.MONTH));
    fromTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    // BEGIN, CR00095666, RKi
    fromTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    scheduleHearingDetails.outOfOfficeFromTime =
      new DateTime(fromTimeCalendar);
    final TimeZone timeZone = TransactionInfo.getServerTimeZone();

    TimeZoneUtility.getTimeZoneAdjustedDateTime(
      scheduleHearingDetails.outOfOfficeFromTime, timeZone);
    // END, CR00095666

    final Calendar toTimeCalendar =
      dtls.homeHearingDetails.outOfOfficeToTime.getCalendar();

    toTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    toTimeCalendar.set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    toTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    // BEGIN,CR00095666, RKi
    toTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    scheduleHearingDetails.outOfOfficeToTime = new DateTime(toTimeCalendar);
    TimeZoneUtility.getTimeZoneAdjustedDateTime(
      scheduleHearingDetails.outOfOfficeToTime, timeZone);
    // END, CR00095666

    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARING;

    // set hearing type
    scheduleHearingDetails.typeCode = HEARINGTYPE.HOME;

    return scheduleHearing(scheduleHearingDetails);

  }

  /**
   * Schedules a location based hearing.
   * 
   * @param dtls
   * Hearing details
   * @return
   * Unique identifier of the new created hearing and
   * informational messages
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public HearingScheduleReturnDtls scheduleLocationHearing(
    final ScheduleLocationHearingDetails dtls) throws AppException,
    InformationalException {

    // Schedule Hearing Details
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // get the start time for the slot
    final Slot slotObj = SlotFactory.newInstance();
    final SlotKey slotKey = new SlotKey();

    slotKey.slotID = dtls.locationHearingDetails.slotID;
    final SlotDtls slotDtls = slotObj.read(slotKey).details;

    // BEGIN, CR00246549, NS
    final Date scheduledDate =
      new Date(dtls.scheduleHearingDetailsCommon.scheduledDateTime);
    final Calendar dateTime = scheduledDate.getCalendar();
    final DateTime scheduledDateTime = new DateTime(dateTime);
    final Calendar scheduledDateTimeCalendar =
      scheduledDateTime.getCalendar();

    // Set the start time of the hearing.
    final Calendar startTimeCalendar = slotDtls.startTime.getCalendar();

    startTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledDateTimeCalendar.get(Calendar.DAY_OF_MONTH));
    startTimeCalendar.set(Calendar.MONTH,
      scheduledDateTimeCalendar.get(Calendar.MONTH));
    startTimeCalendar.set(Calendar.YEAR,
      scheduledDateTimeCalendar.get(Calendar.YEAR));
    startTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    scheduleHearingDetails.scheduledDateTime =
      new DateTime(startTimeCalendar);
    scheduleHearingDetails.scheduledDateTime =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        scheduleHearingDetails.scheduledDateTime,
        TransactionInfo.getServerTimeZone());

    // BEGIN, CR00312465, VT
    final DateTime slotStartDateTime =
      new DateTime(scheduleHearingDetails.scheduledDateTime);
    // END, CR00312465

    // Set the end time of the hearing.
    final Calendar endTimeCalendar = slotDtls.endTime.getCalendar();

    endTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledDateTimeCalendar.get(Calendar.DAY_OF_MONTH));
    endTimeCalendar.set(Calendar.MONTH,
      scheduledDateTimeCalendar.get(Calendar.MONTH));
    endTimeCalendar.set(Calendar.YEAR,
      scheduledDateTimeCalendar.get(Calendar.YEAR));
    endTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    scheduleHearingDetails.endTime = new DateTime(endTimeCalendar);

    // BEGIN, CR00312465, VT
    scheduleHearingDetails.endTime =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        scheduleHearingDetails.endTime, TransactionInfo.getServerTimeZone());
    final DateTime slotEndDateTime =
      new DateTime(scheduleHearingDetails.endTime);
    // END, CR00312465

    // END, CR00246549

    // BEGIN, CR00312465, VT
    final UserActivitySearchKey userActivitySearchKey =
      new UserActivitySearchKey();

    userActivitySearchKey.userName =
      dtls.scheduleHearingDetailsCommon.userName;
    userActivitySearchKey.selectedDate =
      new Date(dtls.scheduleHearingDetailsCommon.scheduledDateTime);
    userActivitySearchKey.startDateTime = slotStartDateTime;
    userActivitySearchKey.endDateTime = slotEndDateTime;

    // Get user activity details list by user and date.
    final MaintainUserActivity maintainUserActivityObj =
      MaintainUserActivityFactory.newInstance();
    final SearchUserByDateRangeResult searchUserByDateRangeResult =
      maintainUserActivityObj.searchUserByDateRange(userActivitySearchKey);

    // First slot allocation for the user.
    if (searchUserByDateRangeResult.detailsList.dtls.isEmpty()) {

      // If the hearing start date time is earlier than current date time,
      // set the hearing start date time to current date time.
      if (scheduleHearingDetails.scheduledDateTime.before(DateTime
        .getCurrentDateTime())) {
        scheduleHearingDetails.scheduledDateTime =
          TimeZoneUtility.getTimeZoneAdjustedDateTime(
            DateTime.getCurrentDateTime(),
            TransactionInfo.getServerTimeZone());
      }

      // Get the last activity details of the user.
    } else {
      final ActivityIntervalDetails activityIntervalDetails =
        searchUserByDateRangeResult.detailsList.dtls
          .item(searchUserByDateRangeResult.detailsList.dtls.size() - 1);

      if (activityIntervalDetails.endDateTime.before(DateTime
        .getCurrentDateTime())) {
        scheduleHearingDetails.scheduledDateTime =
          TimeZoneUtility.getTimeZoneAdjustedDateTime(
            DateTime.getCurrentDateTime(),
            TransactionInfo.getServerTimeZone());
      } else {
        scheduleHearingDetails.scheduledDateTime =
          activityIntervalDetails.endDateTime;
      }
    }

    final DetermineWorkItemKey determineWorkItemKey =
      new DetermineWorkItemKey();

    determineWorkItemKey.userName =
      dtls.scheduleHearingDetailsCommon.userName;
    determineWorkItemKey.numWorkUnits =
      dtls.locationHearingDetails.numberOfWorkUnits;
    determineWorkItemKey.relatedID = dtls.scheduleHearingDetailsCommon.caseID;

    final UserWorkItemDetails userWorkItemDetails =
      SlotAllocationFactory.newInstance()
        .determineNumberOfUnitsAndDurationForUser(determineWorkItemKey);

    // Add the work item duration to the start date time to determine the end
    // date time.
    final DateTime endDateTime =
      scheduleHearingDetails.scheduledDateTime.addTime(0,
        userWorkItemDetails.workItemDuration, 0);

    if (endDateTime.after(slotEndDateTime)) {
      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARINGSCHEDULE_XRV_INSUFFICIENT_TIME);
    }

    scheduleHearingDetails.endTime = endDateTime;
    scheduleHearingDetails.slotID = slotDtls.slotID;
    // END, CR00312465

    // map common details
    scheduleHearingDetails.caseID = dtls.scheduleHearingDetailsCommon.caseID;
    scheduleUserName.userName = dtls.scheduleHearingDetailsCommon.userName;
    scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);
    scheduleHearingDetails.comments =
      dtls.scheduleHearingDetailsCommon.comments;
    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARING;

    // map home hearing details
    scheduleHearingDetails.locationID =
      dtls.locationHearingDetails.locationID;

    // set hearing type
    scheduleHearingDetails.typeCode = HEARINGTYPE.LOCATION;
    scheduleHearingDetails.locationType = HEARINGLOCATIONTYPE.INTERNAL;

    // schedule hearing
    // schedule hearing
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      scheduleHearing(scheduleHearingDetails);

    // add slot allocation
    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();
    final SlotAllocationAddDetails slotAllocationAddDetails =
      new SlotAllocationAddDetails();

    slotAllocationAddDetails.positionID =
      dtls.locationHearingDetails.positionID;
    slotAllocationAddDetails.details.slotAllocationDate =
      new Date(dtls.scheduleHearingDetailsCommon.scheduledDateTime);
    slotAllocationAddDetails.details.slotID =
      dtls.locationHearingDetails.slotID;
    slotAllocationAddDetails.details.numberWorkUnits =
      dtls.locationHearingDetails.numberOfWorkUnits;

    slotAllocationObj.add(slotAllocationAddDetails);

    return hearingScheduleReturnDtls;

  }

  /**
   * Schedules a phone based hearing.
   * 
   * @param dtls Hearing details
   * @return
   * Unique identifier of the new created hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls schedulePhoneHearing(
    final SchedulePhoneHearingDetails dtls) throws AppException,
    InformationalException {

    // Schedule Hearing Details
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // map common details
    scheduleHearingDetails.caseID = dtls.scheduleHearingDetailsCommon.caseID;
    scheduleHearingDetails.scheduledDateTime =
      dtls.scheduleHearingDetailsCommon.scheduledDateTime;
    scheduleUserName.userName = dtls.scheduleHearingDetailsCommon.userName;
    scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);
    scheduleHearingDetails.comments =
      dtls.scheduleHearingDetailsCommon.comments;
    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARING;

    // map phone hearing details
    // Format the end time so that the date is equal to the scheduled date
    final Calendar scheduledCalendar =
      scheduleHearingDetails.scheduledDateTime.getCalendar();
    final Calendar endTimeCalendar =
      dtls.phoneHearingDetails.endTime.getCalendar();

    endTimeCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    endTimeCalendar
      .set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    endTimeCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    // BEGIN, CR00126156, RKi
    endTimeCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    // END, CR00126156
    scheduleHearingDetails.endTime = new DateTime(endTimeCalendar);
    scheduleHearingDetails.inPersonIndicator =
      dtls.phoneHearingDetails.inPersonIndicator;

    // set hearing type
    scheduleHearingDetails.typeCode = HEARINGTYPE.PHONE;

    // schedule hearing
    return scheduleHearing(scheduleHearingDetails);

  }

  // BEGIN, CR00123228, RKi
  /**
   * Updates user roles and activities for external official.
   * 
   * @param key
   * Hearing identifier
   * @param dtls
   * Schedule hearing details
   * @param list
   * List of users details for new scheduled hearing
   */
  protected void updateRolesAndActivitiesForExternalUser(
    final HearingKey key, final ScheduleHearingDetails dtls,
    final ExistingHearingCaseUserDtlsList list) throws AppException,
    InformationalException {

    // HearingUserRole entity and manipulation variables
    final HearingParticipation hearingParticipationObj =
      HearingParticipationFactory.newInstance();
    final HearingParticipationDtls hearingParticipationDtls =
      new HearingParticipationDtls();

    final CancelHearingCaseParticipantRoleDetails cancelHearingCaseParticipantRoleDetails =
      new CancelHearingCaseParticipantRoleDetails();

    // CaseUserRole entity and manipulation variables
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    // MaintainUserActivity manipulation variables
    final MaintainUserActivity maintainUserActivityObj =
      MaintainUserActivityFactory.newInstance();
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;
    final UserActivityKey userActivityKey = new UserActivityKey();
    final MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    final AttendeeNameIDDetails attendeeNameIDDetails =
      new AttendeeNameIDDetails();

    // HearingActivityLink entity and manipulation variables
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    HearingActivityLinkDtls hearingActivityLinkDtls =
      new HearingActivityLinkDtls();

    Count count;
    boolean recordFound = false;

    // new list
    for (int i = 0; i < dtls.scheduleUserNameList.scheduleUserName.size(); i++) {

      recordFound = false;

      // old list
      for (int j = 0; j < list.hearingCaseUserDtlsList.dtls.size(); j++) {

        final ConcernRole concernRole = ConcernRoleFactory.newInstance();

        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID =
          list.hearingCaseUserDtlsList.dtls.item(j).caseUserRoleID;

        final ConcernRoleNameDetails concernRoleNameDetails =
          concernRole.readConcernRoleName(concernRoleKey);

        // if the role is in the list of existing roles
        if (dtls.scheduleUserNameList.scheduleUserName.item(i).userName
          .equals(concernRoleNameDetails.concernRoleName)) {

          recordFound = true;

          // set attributes for activity creation
          userActivityKey.userName = concernRoleNameDetails.concernRoleName;
          maintainActivityDetails.userName =
            concernRoleNameDetails.concernRoleName;
          maintainActivityDetails.activityTypeCode = ACTIVITYTYPE.DEFAULTCODE;
          maintainActivityDetails.caseID = dtls.caseID;
          if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
            // For a home hearing, the activity must start with the out of
            // office time (which will be one or before the scheduled time of
            // the hearing)
            maintainActivityDetails.startDateTime = dtls.outOfOfficeFromTime;
          } else {
            maintainActivityDetails.startDateTime = dtls.scheduledDateTime;
          }
          maintainActivityDetails.priorityCode = ACTIVITYPRIORITY.DEFAULTCODE;
          maintainActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
          maintainActivityDetails.frequencyPattern =
            CuramConst.gkDefaultFrequencyPattern;
          if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
            maintainActivityDetails.subject =
              BPOHEARINGSCHEDULE.INF_HEARING_ACTIVITY_SUBJECT
                .getMessageText();
          } else if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
            maintainActivityDetails.subject =
              BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_ACTIVITY_SUBJECT
                .getMessageText();
          }

          if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
            maintainActivityDetails.endDateTime = dtls.outOfOfficeToTime;
          } else {
            maintainActivityDetails.endDateTime = dtls.endTime;
          }

          maintainActivityDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;

          // Only create user activity if hearing is not of type desk based
          if (!dtls.typeCode.equals(HEARINGTYPE.DESK)) {

            // create activity for the user
            createUserActivityWarnConflictResult =
              maintainUserActivityObj.createUserActivityWarnConflict(
                userActivityKey, maintainActivityDetails,
                attendeeNameIDDetails);

            if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

              if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {

                throw new AppException(
                  BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_OFFICIAL);

              } else {

                throw new AppException(
                  BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_REVIEWER);

              }
            }

            // Check for an existing HearingActivityLink entry
            hearingActivityIDKey.activityID =
              createUserActivityWarnConflictResult.activityKey.activityID;
            count =
              hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);
            if (count.numberOfRecords <= 0) {

              // Add entry to HearingActivityLink
              hearingActivityLinkDtls = new HearingActivityLinkDtls();
              hearingActivityLinkDtls.activityID =
                hearingActivityIDKey.activityID;
              hearingActivityLinkDtls.hearingID = key.hearingKey.hearingID;
              hearingActivityLinkDtls.typeCode = HEARINGACTIVITYTYPE.HEARING;
              hearingActivityLinkObj.insert(hearingActivityLinkDtls);
            }
          }
          hearingParticipationDtls.hearingID = key.hearingKey.hearingID;
          hearingParticipationDtls.caseID = dtls.caseID;
          // create a hearing user role based on the existing case user role id
          hearingParticipationDtls.caseParticipantRoleID =
            list.hearingCaseUserDtlsList.dtls.item(j).orgObjectLinkID;
          hearingParticipationDtls.participatedCode =
            HEARINGPARTICIPATION.NOTHELD;

          // insert hearing participant role
          hearingParticipationObj.insert(hearingParticipationDtls);

          // remove it from the old list, so that the case user role id
          // is not deleted
          list.hearingCaseUserDtlsList.dtls.remove(j);

          // update iterator;
          j--;
          break;

        }
      }
      if (!recordFound) {
        // BEGIN, CR00126446 ,RKi
        final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey =
          new ReadByParticipantRoleTypeAndCaseKey();

        readByParticipantRoleTypeAndCaseKey.participantRoleID =
          dtls.officialConcernRoleID;
        readByParticipantRoleTypeAndCaseKey.typeCode =
          CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
        readByParticipantRoleTypeAndCaseKey.caseID = dtls.caseID;
        readByParticipantRoleTypeAndCaseKey.recordStatus =
          RECORDSTATUS.NORMAL;
        ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails =
          new ReadByParticipantRoleTypeAndCaseDetails();

        try {

          // BEGIN, CR00313597, SK
          readByParticipantRoleTypeAndCaseDetails =
            caseParticipantRole
              .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(readByParticipantRoleTypeAndCaseKey);
          // END, CR00313597

        } catch (final RecordNotFoundException re) {// No record exists in the
                                                    // case participant role for
                                                    // the participant
          // with same role.
        }
        if (readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID == 0) {
          // END CR00126446
          caseParticipantRoleDtls.participantRoleID =
            dtls.officialConcernRoleID;
          caseParticipantRoleDtls.caseID = dtls.caseID;
          caseParticipantRoleDtls.fromDate = Date.getCurrentDate();
          caseParticipantRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
          caseParticipantRoleDtls.typeCode =
            CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;

          try {
            // insert case participant role
            caseParticipantRole.insert(caseParticipantRoleDtls);
          } catch (final AppException e) {
            if (e.getCatEntry().equals(
              BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_OWNER)) {
              throw new AppException(
                BPOHEARINGSCHEDULE.ERR_HEARING_USER_ROLE_NAME);

            }
            throw e;

          }
        }

        // set attributes for activity creation
        userActivityKey.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;

        maintainActivityDetails.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;
        maintainActivityDetails.activityTypeCode = ACTIVITYTYPE.DEFAULTCODE;
        maintainActivityDetails.caseID = dtls.caseID;
        if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
          // For a home hearing, the activity must start with the out of
          // office time (which will be on or before the scheduled time of
          // the hearing)
          maintainActivityDetails.startDateTime = dtls.outOfOfficeFromTime;
        } else {
          maintainActivityDetails.startDateTime = dtls.scheduledDateTime;
        }
        maintainActivityDetails.priorityCode = ACTIVITYPRIORITY.DEFAULTCODE;
        maintainActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
        maintainActivityDetails.frequencyPattern =
          CuramConst.gkDefaultFrequencyPattern;
        if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
          maintainActivityDetails.subject =
            BPOHEARINGSCHEDULE.INF_HEARING_ACTIVITY_SUBJECT.getMessageText();
        } else if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
          maintainActivityDetails.subject =
            BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_ACTIVITY_SUBJECT
              .getMessageText();
        }
        if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
          maintainActivityDetails.endDateTime = dtls.outOfOfficeToTime;
        } else {
          maintainActivityDetails.endDateTime = dtls.endTime;
        }

        maintainActivityDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;

        // Only create user activity if hearing is not of type desk based
        if (!dtls.typeCode.equals(HEARINGTYPE.DESK)) {

          // create activity for the user
          createUserActivityWarnConflictResult =
            maintainUserActivityObj
              .createUserActivityWarnConflict(userActivityKey,
                maintainActivityDetails, attendeeNameIDDetails);
          if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

            if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

              throw new AppException(
                BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_REVIEWER);

            } else {

              throw new AppException(
                BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_OFFICIAL);

            }

          }

          // Check for an existing HearingActivityLink entry
          hearingActivityIDKey.activityID =
            createUserActivityWarnConflictResult.activityKey.activityID;
          count =
            hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);
          if (count.numberOfRecords <= 0) {

            // Add entry to HearingActivityLink
            hearingActivityLinkDtls = new HearingActivityLinkDtls();
            hearingActivityLinkDtls.activityID =
              hearingActivityIDKey.activityID;
            hearingActivityLinkDtls.hearingID = key.hearingKey.hearingID;
            hearingActivityLinkDtls.typeCode = HEARINGACTIVITYTYPE.HEARING;
            hearingActivityLinkObj.insert(hearingActivityLinkDtls);
          }
        }

        // set details for hearing user role creation
        hearingParticipationDtls.hearingID = key.hearingKey.hearingID;
        hearingParticipationDtls.caseID = dtls.caseID;
        // create a hearing user role based on the existing case user role id
        // BEGIN CR00125434 , RKi
        if (readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID == 0) {
          hearingParticipationDtls.caseParticipantRoleID =
            caseParticipantRoleDtls.caseParticipantRoleID;
        } else {
          hearingParticipationDtls.caseParticipantRoleID =
            readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
        }
        // END CR00125434
        hearingParticipationDtls.participatedCode =
          HEARINGPARTICIPATION.NOTHELD;

        // insert hearing participant role
        hearingParticipationObj.insert(hearingParticipationDtls);

      }

    }

    // for remaining users from the old list
    for (int i = 0; i < list.hearingCaseUserDtlsList.dtls.size(); i++) {
      // BEGIN CR00125434 , RKi
      final ReadByParticipantRoleIDTypeKey participantRoleIDTypeKey =
        new ReadByParticipantRoleIDTypeKey();

      participantRoleIDTypeKey.participantRoleID =
        list.hearingCaseUserDtlsList.dtls.item(i).caseUserRoleID;
      participantRoleIDTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      participantRoleIDTypeKey.recordStatus = RECORDSTATUS.NORMAL;
      ReadByParticipantRoleIDTypeDetails readByParticipantRoleIDTypeDetails =
        new ReadByParticipantRoleIDTypeDetails();

      readByParticipantRoleIDTypeDetails =
        caseParticipantRole
          .readByParticipantRoleIDType(participantRoleIDTypeKey);
      // END CR00125434,
      cancelHearingCaseParticipantRoleDetails.caseParticipantRoleID =
        readByParticipantRoleIDTypeDetails.caseParticipantRoleID;
      cancelHearingCaseParticipantRoleDetails.recordStatus =
        RECORDSTATUS.CANCELLED;
      cancelHearingCaseParticipantRoleDetails.endDate = Date.getCurrentDate();
      // close case user role
      hearingParticipationObj
        .cancelCaseParticipantRoleOnHearing(cancelHearingCaseParticipantRoleDetails);
    }
  }

  // END, CR00123228

  /**
   * Updates user roles and activities.
   * 
   * @param key
   * Hearing identifier
   * @param dtls
   * Schedule hearing details
   * @param list
   * List of users details for new scheduled hearing
   */
  @Override
  protected void updateRolesAndActivities(final HearingKey key,
    final ScheduleHearingDetails dtls,
    final ExistingHearingCaseUserDtlsList list) throws AppException,
    InformationalException {

    // HearingUserRole entity and manipulation variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final HearingUserRoleDtls hearingUserRoleDtls = new HearingUserRoleDtls();

    // CaseUserRole entity and manipulation variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    CaseUserRoleDtls caseUserRoleDtls = new CaseUserRoleDtls();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

    // MaintainUserActivity manipulation variables
    final MaintainUserActivity maintainUserActivityObj =
      MaintainUserActivityFactory.newInstance();
    CreateUserActivityWarnConflictResult createUserActivityWarnConflictResult;
    final UserActivityKey userActivityKey = new UserActivityKey();
    final MaintainActivityDetails maintainActivityDetails =
      new MaintainActivityDetails();
    final AttendeeNameIDDetails attendeeNameIDDetails =
      new AttendeeNameIDDetails();

    // HearingActivityLink entity and manipulation variables
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    HearingActivityLinkDtls hearingActivityLinkDtls =
      new HearingActivityLinkDtls();

    Count count;
    boolean recordFound = false;

    // new list
    for (int i = 0; i < dtls.scheduleUserNameList.scheduleUserName.size(); i++) {

      recordFound = false;

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

      // END, CR00053295

      // old list
      for (int j = 0; j < list.hearingCaseUserDtlsList.dtls.size(); j++) {

        // BEGIN, CR00095673, RKi
        caseUserRoleKey.caseUserRoleID =
          list.hearingCaseUserDtlsList.dtls.item(j).caseUserRoleID;
        caseUserRoleDtls = caseUserRoleObj.read(caseUserRoleKey);

        orgObjectLinkKey.orgObjectLinkID = caseUserRoleDtls.orgObjectLinkID;
        // END, CR00095673
        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        // BEGIN, CR00127034, RKi
        // if the role is in the list of existing roles
        if (dtls.scheduleUserNameList.scheduleUserName.item(i).userName
          .equals(caseOwnerDetails.userName)) {
          // END, CR00127034
          recordFound = true;

          // set attributes for activity creation
          userActivityKey.userName = caseOwnerDetails.userName;
          maintainActivityDetails.userName = caseOwnerDetails.userName;
          maintainActivityDetails.activityTypeCode = ACTIVITYTYPE.DEFAULTCODE;
          maintainActivityDetails.caseID = dtls.caseID;
          if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
            // For a home hearing, the activity must start with the out of
            // office time (which will be one or before the scheduled time of
            // the hearing)
            maintainActivityDetails.startDateTime = dtls.outOfOfficeFromTime;
          } else {
            maintainActivityDetails.startDateTime = dtls.scheduledDateTime;
          }
          maintainActivityDetails.priorityCode = ACTIVITYPRIORITY.DEFAULTCODE;
          maintainActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
          maintainActivityDetails.frequencyPattern =
            CuramConst.gkDefaultFrequencyPattern;
          if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
            maintainActivityDetails.subject =
              BPOHEARINGSCHEDULE.INF_HEARING_ACTIVITY_SUBJECT
                .getMessageText();
          } else if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
            maintainActivityDetails.subject =
              BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_ACTIVITY_SUBJECT
                .getMessageText();
          }

          if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
            maintainActivityDetails.endDateTime = dtls.outOfOfficeToTime;
          } else {
            maintainActivityDetails.endDateTime = dtls.endTime;
          }

          maintainActivityDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;

          // Only create user activity if hearing is not of type desk based
          if (!dtls.typeCode.equals(HEARINGTYPE.DESK)) {

            // create activity for the user
            createUserActivityWarnConflictResult =
              maintainUserActivityObj.createUserActivityWarnConflict(
                userActivityKey, maintainActivityDetails,
                attendeeNameIDDetails);

            if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

              if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {

                throw new AppException(
                  BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_OFFICIAL);

              } else {

                throw new AppException(
                  BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_REVIEWER);

              }
            }

            // Check for an existing HearingActivityLink entry
            hearingActivityIDKey.activityID =
              createUserActivityWarnConflictResult.activityKey.activityID;
            count =
              hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);
            if (count.numberOfRecords <= 0) {

              // Add entry to HearingActivityLink
              hearingActivityLinkDtls = new HearingActivityLinkDtls();
              hearingActivityLinkDtls.activityID =
                hearingActivityIDKey.activityID;
              hearingActivityLinkDtls.hearingID = key.hearingKey.hearingID;
              hearingActivityLinkDtls.typeCode = HEARINGACTIVITYTYPE.HEARING;
              hearingActivityLinkObj.insert(hearingActivityLinkDtls);
            }
          }

          hearingUserRoleDtls.hearingID = key.hearingKey.hearingID;

          // create a hearing user role based on the existing case user role id
          hearingUserRoleDtls.caseUserRoleID =
            list.hearingCaseUserDtlsList.dtls.item(j).caseUserRoleID;
          hearingUserRoleDtls.hearingID = key.hearingKey.hearingID;
          hearingUserRoleDtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

          // insert hearing user role
          hearingUserRoleObj.insert(hearingUserRoleDtls);

          // remove it from the old list, so that the case user role id
          // is not deleted
          list.hearingCaseUserDtlsList.dtls.remove(j);

          // update iterator;
          j--;
          break;

        }
      }
      if (!recordFound) {
        // BEGIN, CR00095673, RKi
        // OrgObjectLink variables
        OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
        final OrgObjectLink orgObjectLinkObj =
          OrgObjectLinkFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        // BEGIN, CR00127034, RKi
        usersKey.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;
        // END, CR00127034
        try {
          orgObjectLinkDtls = orgObjectLinkObj.readByUsername(usersKey);
        } catch (final RecordNotFoundException re) {
          orgObjectLinkDtls.orgObjectLinkID = 0;
        }

        // inserts the user into OrgObjectLink only if the user
        // does not already exist
        // BEGIN, CR00127034, RKi
        orgObjectLinkDtls.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;
        // END, CR00127034
        orgObjectLinkDtls.orgObjectType = ORGOBJECTTYPE.USER;

        if (orgObjectLinkDtls.orgObjectLinkID == 0) {
          orgObjectLinkObj.insert(orgObjectLinkDtls);
        }
        caseUserRoleDtls.orgObjectLinkID = orgObjectLinkDtls.orgObjectLinkID;
        // END, CR00095673

        caseUserRoleDtls.caseID = dtls.caseID;
        caseUserRoleDtls.fromDate = Date.getCurrentDate();
        caseUserRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
        if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

          caseUserRoleDtls.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

        } else {

          caseUserRoleDtls.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

        }

        try {
          // insert case user role
          caseUserRoleObj.insert(caseUserRoleDtls);
        } catch (final AppException e) {
          if (e.getCatEntry().equals(
            BPOCASEUSERROLE.ERR_CASEUSERROLE_FV_OWNER)) {
            throw new AppException(
              BPOHEARINGSCHEDULE.ERR_HEARING_USER_ROLE_NAME);

          }
          throw e;

        }

        // set attributes for activity creation
        // BEGIN, CR00095673, RKi
        // BEGIN, CR00127034, RKi
        userActivityKey.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;
        // END, CR00095673

        maintainActivityDetails.userName =
          dtls.scheduleUserNameList.scheduleUserName.item(i).userName;
        maintainActivityDetails.activityTypeCode = ACTIVITYTYPE.DEFAULTCODE;
        maintainActivityDetails.caseID = dtls.caseID;
        if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
          // For a home hearing, the activity must start with the out of
          // office time (which will be on or before the scheduled time of
          // the hearing)
          maintainActivityDetails.startDateTime = dtls.outOfOfficeFromTime;
        } else {
          maintainActivityDetails.startDateTime = dtls.scheduledDateTime;
        }
        maintainActivityDetails.priorityCode = ACTIVITYPRIORITY.DEFAULTCODE;
        maintainActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
        maintainActivityDetails.frequencyPattern =
          CuramConst.gkDefaultFrequencyPattern;
        if (dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
          maintainActivityDetails.subject =
            BPOHEARINGSCHEDULE.INF_HEARING_ACTIVITY_SUBJECT.getMessageText();
        } else if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
          maintainActivityDetails.subject =
            BPOHEARINGSCHEDULE.INF_HEARINGREVIEW_ACTIVITY_SUBJECT
              .getMessageText();
        }
        if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {
          maintainActivityDetails.endDateTime = dtls.outOfOfficeToTime;
        } else {
          maintainActivityDetails.endDateTime = dtls.endTime;
        }

        maintainActivityDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;

        // Only create user activity if hearing is not of type desk based
        if (!dtls.typeCode.equals(HEARINGTYPE.DESK)) {

          // create activity for the user
          createUserActivityWarnConflictResult =
            maintainUserActivityObj
              .createUserActivityWarnConflict(userActivityKey,
                maintainActivityDetails, attendeeNameIDDetails);
          if (createUserActivityWarnConflictResult.activityConflictDetails.conflictInd) {

            if (dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

              throw new AppException(
                BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_REVIEWER);

            } else {

              throw new AppException(
                BPOHEARINGSCHEDULE.ERR_ACTIVITY_CONFLICT_HEARING_OFFICIAL);

            }

          }

          // Check for an existing HearingActivityLink entry
          hearingActivityIDKey.activityID =
            createUserActivityWarnConflictResult.activityKey.activityID;
          count =
            hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);
          if (count.numberOfRecords <= 0) {

            // Add entry to HearingActivityLink
            hearingActivityLinkDtls = new HearingActivityLinkDtls();
            hearingActivityLinkDtls.activityID =
              hearingActivityIDKey.activityID;
            hearingActivityLinkDtls.hearingID = key.hearingKey.hearingID;
            hearingActivityLinkDtls.typeCode = HEARINGACTIVITYTYPE.HEARING;
            hearingActivityLinkObj.insert(hearingActivityLinkDtls);
          }
        }

        // set details for hearing user role creation
        hearingUserRoleDtls.caseUserRoleID = caseUserRoleDtls.caseUserRoleID;
        hearingUserRoleDtls.hearingID = key.hearingKey.hearingID;
        hearingUserRoleDtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

        // insert hearing user role
        hearingUserRoleObj.insert(hearingUserRoleDtls);

      }

    }

    // for remaining users from the old list
    for (int i = 0; i < list.hearingCaseUserDtlsList.dtls.size(); i++) {
      caseUserRoleKey.caseUserRoleID =
        list.hearingCaseUserDtlsList.dtls.item(i).caseUserRoleID;
      // close case user role
      caseUserRoleObj.closeCaseUserRole(caseUserRoleKey);
    }
  }

  /**
   * Validates a reschedule of a hearing for any appeal type.
   * 
   * @param details
   * Reschedule hearing details
   */
  @Override
  protected void validateReschedule(final RescheduleHearingDetails details)
    throws AppException, InformationalException {

    // variables to lookup existing hearings
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingCaseIDScheduledDateTimeStatusCode hearingCaseIDScheduledDateTimeStatusCode =
      new HearingCaseIDScheduledDateTimeStatusCode();

    hearingCaseIDScheduledDateTimeStatusCode.caseID =
      details.scheduleHearingDetails.caseID;
    hearingCaseIDScheduledDateTimeStatusCode.scheduledDateTime =
      details.scheduleHearingDetails.scheduledDateTime;
    hearingCaseIDScheduledDateTimeStatusCode.statusCode =
      HEARINGSTATUS.COMPLETED;

    // Can't reschedule for same date and time as an existing completed hearing
    // for this case
    if (hearingObj
      .countByCaseIDStatusScheduledDateTime(hearingCaseIDScheduledDateTimeStatusCode).numberOfRecords > 0) {
      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARING_SAME_SCHEDULEDDATETIME);
    }

    if (details.scheduleHearingDetails.appealTypeCode
      .equals(APPEALTYPE.HEARING)) {

      validateRescheduleHearing(details);

    } else if (

    details.scheduleHearingDetails.appealTypeCode
      .equals(APPEALTYPE.HEARINGREVIEW)) {

      validateRescheduleHearingReview(details);

    }

  }

  /**
   * Validates a reschedule of a hearing for a hearing case
   * 
   * @param details
   * Reschedule hearing details
   */
  @Override
  protected void validateRescheduleHearing(
    final RescheduleHearingDetails details) throws AppException,
    InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingStatusDetails hearingStatusDetails;

    final InformationalManager informationalManager =
      new InformationalManager();

    // Variable for validating empty time entries
    // The time entries have been formatted prior to this method call so
    // that their date part is set to the scheduled date of the hearing.
    // Therefore to determine if no time value has been entered must
    // compare against a date time value for the scheduled date but with
    // a zero time.
    final DateTime emptyTime =
      new DateTime(new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        details.scheduleHearingDetails.scheduledDateTime,
        TransactionInfo.getUserTimeZone())).getCalendar());

    hearingKey.hearingID = details.hearingID;

    // read hearing status
    hearingStatusDetails = hearingObj.readStatusByHearingID(hearingKey);
    // BEGIN, CR00126739, RKi
    // OrgTime is added to store the original date time of the scheduled time.
    // The scheduled date time, because of the Time zone gets converted to
    // user time zone below and so wrong validations.
    final DateTime OrgTime = details.scheduleHearingDetails.scheduledDateTime;

    // END, CR00126739

    // BEGIN, CR00095666, RKi
    details.scheduleHearingDetails.scheduledDateTime.getCalendar()
      .setTimeZone(TransactionInfo.getServerTimeZone());
    details.scheduleHearingDetails.scheduledDateTime =
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        details.scheduleHearingDetails.scheduledDateTime,
        TransactionInfo.getUserTimeZone());
    // END, CR00095666
    // hearing must be scheduled
    if (!hearingStatusDetails.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      throw new AppException(BPOHEARINGSCHEDULE.ERR_FV_HEARING_STATUS_CODE);
    }

    // hearing official must be specified
    if (details.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .size() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGSCHEDULE.ERR_FV_OFFICIAL_UNSPECIFIED),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    if (details.scheduleHearingDetails.typeCode.equals(HEARINGTYPE.DESK)) {
      // BEGIN, CR00126739, RKi
      // Expected hearing date must not be in the past
      if (new Date(OrgTime).before(Date.getCurrentDate())) {

        final AppException e =
          new AppException(BPOHEARINGSCHEDULE.ERR_XFV_EXPECTED_DATE_SMALL);

        // add date argument
        e.arg(new Date(OrgTime));
        informationalManager.addInformationalMsg(e, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }
      // END, CR00126739
    } else {

      // hearing date must be specified
      if (details.scheduleHearingDetails.scheduledDateTime
        .equals(DateTime.kZeroDateTime)) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_DATETIME_UNSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);
      }

    }

    if (details.scheduleHearingDetails.typeCode.equals(HEARINGTYPE.PHONE)) {

      // Hearing end time must be specified
      if (details.scheduleHearingDetails.endTime.equals(kZeroEPOCDate)
        || details.scheduleHearingDetails.endTime.isZero()
        || details.scheduleHearingDetails.endTime.equals(emptyTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_ENDTIME_UNSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

      // Hearing end time must be after the scheduled time of the hearing
      if (!details.scheduleHearingDetails.endTime
        .after(details.scheduleHearingDetails.scheduledDateTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_END_TIME_AFTER_SCHEDULED_TIME),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

    } else if (details.scheduleHearingDetails.typeCode
      .equals(HEARINGTYPE.HOME)) {

      // Out of office start time must be specified
      if (details.scheduleHearingDetails.outOfOfficeFromTime
        .equals(kZeroEPOCDate)
        || details.scheduleHearingDetails.outOfOfficeFromTime.isZero()
        || details.scheduleHearingDetails.outOfOfficeFromTime
          .equals(emptyTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_OUT_OF_OFFICE_START_TIME),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

      // Out of office start time must be on or before the hearing start
      // time
      if (details.scheduleHearingDetails.outOfOfficeFromTime
        .after(details.scheduleHearingDetails.scheduledDateTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_XFV_OUT_OF_OFFICE_START_TIME_START_TIME),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

      // Out of office end time must be specified
      if (details.scheduleHearingDetails.outOfOfficeToTime
        .equals(kZeroEPOCDate)
        || details.scheduleHearingDetails.outOfOfficeToTime.isZero()
        || details.scheduleHearingDetails.outOfOfficeToTime.equals(emptyTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_OUT_OF_OFFICE_END_TIME),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

      // Out of office end time must be later than the hearing start time
      if (!details.scheduleHearingDetails.outOfOfficeToTime
        .after(details.scheduleHearingDetails.scheduledDateTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_XFV_OUT_OF_OFFICE_END_TIME_START_TIME),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);
      }

    }

    informationalManager.failOperation();

  }

  /**
   * Validates the schedule details for a hearing for all appeal types.
   * 
   * @param details
   * Hearing details
   */
  @Override
  protected void
    validateScheduleHearing(final ScheduleHearingDetails details)
      throws AppException, InformationalException {

    // CaseHeader entity and manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseStatusCode caseStatusCode;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingScheduleDetails hearingScheduleDetails;
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    AppealContinueDetails appealContinueDetails = new AppealContinueDetails();

    final InformationalManager informationalManager =
      new InformationalManager();

    // Variable for validating empty time entries
    // The time entries have been formatted prior to this method call so
    // that their date part is set to the scheduled date of the hearing.
    // Therefore to determine if no time value has been entered must
    // compare against a date time value for the scheduled date but with
    // a zero time.
    final DateTime emptyTime =
      new DateTime(
        new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
          details.scheduledDateTime, TransactionInfo.getUserTimeZone()))
          .getCalendar());

    // variable to lookup existing hearings date time
    final HearingCaseIDScheduledDateTimeStatusCode hearingCaseIDScheduledDateTimeStatusCode =
      new HearingCaseIDScheduledDateTimeStatusCode();

    hearingCaseIDScheduledDateTimeStatusCode.caseID = details.caseID;
    hearingCaseIDScheduledDateTimeStatusCode.scheduledDateTime =
      details.scheduledDateTime;
    hearingCaseIDScheduledDateTimeStatusCode.statusCode =
      HEARINGSTATUS.COMPLETED;

    // Can't reschedule for same date and time as an existing completed hearing
    // for this case
    if (hearingObj
      .countByCaseIDStatusScheduledDateTime(hearingCaseIDScheduledDateTimeStatusCode).numberOfRecords > 0) {

      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARING_SAME_SCHEDULEDDATETIME);
    }

    // Read status code for the appeal case
    caseHeaderKey.caseID = details.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // appeal case status must be 'approved' or 'active'.
    if (!caseStatusCode.statusCode.equals(CASESTATUS.APPROVED)
      && !caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {
      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_CASESTATUS_NOTAPPROVEDORACTIVE);
    }

    // Search for existing scheduled hearing for the appeal case
    caseAndStatusKey.caseID = details.caseID;
    caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;
    try {
      hearingScheduleDetails =
        hearingObj.readScheduledByCaseID(caseAndStatusKey);
    } catch (final RecordNotFoundException e) {
      hearingScheduleDetails = null;
    }

    if (hearingScheduleDetails != null) {
      throw new AppException(BPOHEARINGSCHEDULE.ERR_SCHEDULED_HEARING_EXISTS);
    }

    if (details.typeCode.equals(HEARINGTYPE.DESK)) {
      // BEGIN, CR00095678, RKi
      // Expected hearing date must not be in the past
      if (new Date(details.scheduledDateTime).before(Date.getCurrentDate())) {
        final AppException e =
          new AppException(BPOHEARINGSCHEDULE.ERR_XFV_EXPECTED_DATE_SMALL);

        // END, CR00095678
        // add date argument
        e.arg(new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
          details.scheduledDateTime, TransactionInfo.getUserTimeZone())));
        informationalManager.addInformationalMsg(e, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }

    } else {

      // Variables for determining whether the last hearing on the appeal case
      // has been continued
      HearingPostponeDateDetails hearingPostponeDateDetails;
      HearingScheduleDate lastHeldDate;
      final AdjournedOrCompletedHearing adjournedOrCompletedHearing =
        new AdjournedOrCompletedHearing();
      final DateTime currentDateTime = DateTime.getCurrentDateTime();

      // If the last hearing on the appeal case was continued, then
      // the new hearing must be scheduled for a date which is after the
      // original scheduled date of the continued hearing.
      // To determine this :
      // 1) Get the most recently continued hearing for the appeal case
      // 2) Determine if that continued hearing is the last hearing on the
      // appeal case. For example, if a subsequent hearing was scheduled
      // and held (adjourned or completed) then the retrieved continued
      // hearing was not the last hearing on the appeal case.
      // 3) If the last hearing on the case was continued, then ensure that
      // the new hearing is scheduled for a date which is after the
      // original scheduled date of the continued hearing.

      caseAndStatusKey.statusCode = HEARINGSTATUS.CONTINUED;
      try {
        hearingPostponeDateDetails =
          hearingObj.readLatestPostponedByCaseIDAndStatus(caseAndStatusKey);

      } catch (final RecordNotFoundException e) {
        hearingPostponeDateDetails = null;
      }

      if (hearingPostponeDateDetails != null) {

        // Read the details for the most recently continued hearing
        hearingKey.hearingID = hearingPostponeDateDetails.hearingID;
        appealContinueDetails = hearingObj.readContinaunceDetails(hearingKey);

        // If the scheduled hearing for the most recently continued hearing is
        // on or after the current date then need to validate that the
        // scheduled date of the new hearing is after the continued hearing's
        // original scheduled date.
        if (!appealContinueDetails.scheduledDateTime.before(currentDateTime)) {
          boolean performValidation = true;

          // Determine if there have been any completed or adjourned hearings
          // on the appeal case since the last continued hearing. If there
          // has then the validation against the continued hearing's
          // scheduled date is not required.
          try {
            adjournedOrCompletedHearing.caseID = details.caseID;
            lastHeldDate =
              hearingObj
                .readLatestAdjournOrCompletedHearingDateByCaseID(adjournedOrCompletedHearing);

            if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
              lastHeldDate.scheduledDateTime,
              TransactionInfo.getUserTimeZone())).after(new Date(
              TimeZoneUtility.getTimeZoneAdjustedDateTime(
                hearingPostponeDateDetails.postponeDate,
                TransactionInfo.getUserTimeZone())))) {
              performValidation = false;
            }

          } catch (final RecordNotFoundException e) {
            performValidation = true;
          }

          // If the last hearing on the appeal case was continued, ensure
          // that the scheduled date of the new hearing is after the
          // continued hearing's original scheduled date.
          if (performValidation
            && !details.scheduledDateTime
              .after(appealContinueDetails.scheduledDateTime)) {

            informationalManager
              .addInformationalMsg(
                new AppException(
                  BPOHEARINGSCHEDULE.ERR_HEARING_DATETIME_NOT_AFTER_CONTINUEDHEARING),
                GeneralConstants.kEmpty,
                InformationalElement.InformationalType.kError);
          }
        }
      }

      // hearing date and time must be specified
      if (details.scheduledDateTime.equals(DateTime.kZeroDateTime)) {

        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_DATETIME_UNSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);
      }

    }

    // hearing official or hearing reviewer must be specified
    if (details.scheduleUserNameList.scheduleUserName.size() == 0) {

      if (details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        throw new AppException(BPOHEARINGSCHEDULE.ERR_FV_REVIEWER_UNSPECIFIED);

      } else {
        throw new AppException(BPOHEARINGSCHEDULE.ERR_FV_OFFICIAL_UNSPECIFIED);

      }

    }

    if (!details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      if (details.typeCode.equals(HEARINGTYPE.PHONE)) {

        // Hearing end time must be specified
        if (details.endTime.equals(kZeroEPOCDate) || details.endTime.isZero()
          || details.endTime.equals(emptyTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_FV_ENDTIME_UNSPECIFIED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

        // Hearing end time must be after the scheduled time of the hearing
        if (!details.endTime.after(details.scheduledDateTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_END_TIME_AFTER_SCHEDULED_TIME),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

      } else if (details.typeCode.equals(HEARINGTYPE.HOME)) {

        // Out of office start time must be specified
        if (details.outOfOfficeFromTime.equals(kZeroEPOCDate)
          || details.outOfOfficeFromTime.isZero()
          || details.outOfOfficeFromTime.equals(emptyTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_FV_OUT_OF_OFFICE_START_TIME),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

        // Out of office start time must be on or before the hearing start
        // time
        if (details.outOfOfficeFromTime.after(details.scheduledDateTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_XFV_OUT_OF_OFFICE_START_TIME_START_TIME),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

        // Out of office end time must be specified
        if (details.outOfOfficeToTime.equals(kZeroEPOCDate)
          || details.outOfOfficeToTime.isZero()
          || details.outOfOfficeToTime.equals(emptyTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_FV_OUT_OF_OFFICE_END_TIME),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

        // Out of office end time must be later than the hearing start time
        if (!details.outOfOfficeToTime.after(details.scheduledDateTime)) {

          informationalManager.addInformationalMsg(new AppException(
            BPOHEARINGSCHEDULE.ERR_XFV_OUT_OF_OFFICE_END_TIME_START_TIME),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

        }

      }

    }

    informationalManager.failOperation();

  }

  /**
   * Validates a continuance for a hearing for all appeal types.
   * 
   * @param dtls
   * Hearing continue details
   */
  @Override
  protected void validateContinue(final ValidateContinueDetails dtls)
    throws AppException, InformationalException {

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingPostponeDateDetails hearingPostponeDateDetails;

    // If there have been any other hearing continuances for the appeal case,
    // validate that the current continuance date is on or after the
    // continuance date of the most recently continued hearing.
    // By ensuring that the recorded continuance dates are consecutive,
    // this means that the most recently continued hearing can always be
    // determined.
    // Note: that hearing continuances, by their nature, result in the
    // postponement of the hearing until a later date. Therefore it would
    // not make sense to have a hearing continued on a date which is before
    // a previously continued hearing!
    try {
      caseAndStatusKey.statusCode = HEARINGSTATUS.CONTINUED;
      caseAndStatusKey.caseID = dtls.caseID;
      hearingPostponeDateDetails =
        hearingObj.readLatestPostponedByCaseIDAndStatus(caseAndStatusKey);

      if (dtls.postponedDate.before(new Date(
        hearingPostponeDateDetails.postponeDate.asLong()))) {
        throw new AppException(
          BPOHEARINGSCHEDULE.ERR_CONTINUANCE_DATE_BEFORE_PREVIOUSCONTINUANCE_DATE);
      }
    } catch (final RecordNotFoundException e) {// If there are no previously
                                               // continued
      // hearings then there is no need to validate the postpone date for the
      // hearing being currently continued.
    }

    if (!dtls.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {
      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_FV_HEARING_CONTINUE_STATUS);
    }

    if (!Date.getCurrentDate().before(
      new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        dtls.scheduledDateTime, TransactionInfo.getUserTimeZone())))) {
      throw new AppException(BPOHEARINGSCHEDULE.ERR_XFV_HEARING_CONTINUE_DATE);
    }
  }

  /**
   * Validates a reschedule of a hearing for a hearing review case
   * 
   * @param details
   * rescheduled hearing review details
   */
  @Override
  protected void validateRescheduleHearingReview(
    final RescheduleHearingDetails details) throws AppException,
    InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingStatusDetails hearingStatusDetails = new HearingStatusDetails();

    final InformationalManager informationalManager =
      new InformationalManager();

    // Read the hearing status of the hearing id being specified
    hearingKey.hearingID = details.hearingID;
    hearingStatusDetails = hearingObj.readStatusByHearingID(hearingKey);

    if (!hearingStatusDetails.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARINGREVIEW_NOT_SCHEDULED);

    }

    if (details.scheduleHearingDetails.typeCode.equals(HEARINGTYPE.DESK)) {
      // Expected hearing date must not be in the past
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        details.scheduleHearingDetails.scheduledDateTime,
        TransactionInfo.getUserTimeZone())).before(Date.getCurrentDate())) {

        final AppException e =
          new AppException(BPOHEARINGSCHEDULE.ERR_XFV_EXPECTED_DATE_SMALL);

        // add date argument
        e.arg(new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
          details.scheduleHearingDetails.scheduledDateTime,
          TransactionInfo.getUserTimeZone())));
        informationalManager.addInformationalMsg(e, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }

    } else {

      if (details.scheduleHearingDetails.scheduledDateTime
        .equals(DateTime.kZeroDateTime)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_FV_DATETIME_UNSPECIFIED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      }

      // hearing date and time must not be in the past
      if (details.scheduleHearingDetails.scheduledDateTime.before(DateTime
        .getCurrentDateTime())) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGSCHEDULE.ERR_XFV_DATETIME_INVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);
      }
    }

    if (details.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .size() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGSCHEDULE.ERR_FV_HEARINGREVIEWER_UNSPECIFIED),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  /**
   * Returns the list of addresses for the appellant for a caseID.
   * 
   * @param key
   * Hearing case unique identification
   * @return
   * list of address details
   */
  @Override
  public HearingCaseParticipantAddressData listAppellantAddressByCase(
    final HearingCaseID key) throws AppException, InformationalException {

    // to be returned
    final HearingCaseParticipantAddressData hearingCaseParticipantAddressData =
      new HearingCaseParticipantAddressData();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    // Address maintenance object
    final MaintainConcernRoleAddress maintainConcernRoleAddressObj =
      MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // End, CR00115728, RKi
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = key.hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    caseParticipantRoleCaseAndTypeKey.caseID = key.hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // search for appellant (only one record is expected)
    caseParticipantRoleIDDetailsList =
      caseParticipantRole_eoObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    if (caseParticipantRoleIDDetailsList.dtls.size() > 0) {

      maintainAddressKey.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;

      hearingCaseParticipantAddressData.hearingCaseParticipantRoleID.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;

      // read address list
      hearingCaseParticipantAddressData.readMultiByConcRoleIDResult =
        maintainConcernRoleAddressObj
          .readmultiByConcernRoleID(maintainAddressKey);

    }

    return hearingCaseParticipantAddressData;

  }

  /**
   * Returns the list of addresses for the appellant for a hearingID.
   * 
   * @param key
   * Hearing unique identification
   * @return
   * list of address details
   */
  @Override
  public HearingCaseParticipantAddressData listAppellantAddressByHearing(
    final HearingKey key) throws AppException, InformationalException {

    // to be returned
    final HearingCaseParticipantAddressData hearingCaseParticipantAddressData =
      new HearingCaseParticipantAddressData();

    // Hearing manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingConcernRoleDetailsList hearingConcernRoleDetailsList;
    final HearingParticipantKey hearingParticipantKey =
      new HearingParticipantKey();

    // Address maintenance object
    final MaintainConcernRoleAddress maintainConcernRoleAddressObj =
      MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // get caseID
    final HearingCaseID hearingCaseID = hearing_boObj.getCase(key);

    // BEGIN, CR00115728, RKi
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // End, CR00115728, RKi
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    hearingParticipantKey.hearingID = key.hearingKey.hearingID;
    hearingParticipantKey.recordStatus = RECORDSTATUS.NORMAL;
    hearingParticipantKey.typeCode = CASEPARTICIPANTROLETYPE.APPELLANT;

    // search for appellant (only one record is expected)
    hearingConcernRoleDetailsList =
      hearingObj.searchParticipantRoleByTypeAndStatus(hearingParticipantKey);

    if (hearingConcernRoleDetailsList.dtls.size() > 0) {

      maintainAddressKey.concernRoleID =
        hearingConcernRoleDetailsList.dtls.item(0).participantRoleID;

      hearingCaseParticipantAddressData.hearingCaseParticipantRoleID.concernRoleID =
        hearingConcernRoleDetailsList.dtls.item(0).participantRoleID;

      // read address list
      hearingCaseParticipantAddressData.readMultiByConcRoleIDResult =
        maintainConcernRoleAddressObj
          .readmultiByConcernRoleID(maintainAddressKey);

    }

    return hearingCaseParticipantAddressData;

  }

  /**
   * Schedules a desk based hearing.
   * 
   * @param details
   * Desk Based Hearing details
   * @return
   * Hearing unique identifier and informational messages
   */
  @Override
  public HearingScheduleReturnDtls scheduleDeskHearing(
    final ScheduleDeskHearingDetails details) throws AppException,
    InformationalException {

    // Hearing manipulation variables
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // map common details
    scheduleHearingDetails.caseID =
      details.scheduleHearingDetailsCommon.caseID;
    scheduleHearingDetails.scheduledDateTime =
      details.scheduleHearingDetailsCommon.scheduledDateTime;

    // Add Hearing Officials name to list only if specified
    scheduleUserName.userName = details.scheduleHearingDetailsCommon.userName;
    if (details.scheduleHearingDetailsCommon.userName.length() != 0) {
      scheduleHearingDetails.scheduleUserNameList.scheduleUserName
        .addRef(scheduleUserName);
    }

    scheduleHearingDetails.comments =
      details.scheduleHearingDetailsCommon.comments;

    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARING;

    // set hearing type
    scheduleHearingDetails.typeCode = HEARINGTYPE.DESK;

    return scheduleHearing(scheduleHearingDetails);
  }

  /**
   * Reschedules a desk based hearing for a hearing case.
   * 
   * @param details
   * Reschedule desk hearing details
   * @return
   * Unique identification of the rescheduled hearing and informational
   * messages
   */
  @Override
  public HearingScheduleReturnDtls rescheduleDeskHearing(
    final RescheduleDeskHearingDetails details) throws AppException,
    InformationalException {

    // Hearing manipulation variables
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    hearingKey.hearingID = details.rescheduleHearingDetailsCommon.hearingID;

    // read hearing case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    // map common details
    rescheduleHearingDetails.assign(details.rescheduleHearingDetailsCommon);
    rescheduleHearingDetails.scheduleHearingDetails.appealTypeCode =
      APPEALTYPE.HEARING;
    rescheduleHearingDetails.scheduleHearingDetails.comments =
      details.rescheduleHearingDetailsCommon.comments;
    rescheduleHearingDetails.scheduleHearingDetails.caseID =
      hearingCaseID.caseID;
    rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime =
      details.rescheduleHearingDetailsCommon.scheduledDateTime;
    scheduleUserName.userName =
      details.rescheduleHearingDetailsCommon.userName;
    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);

    // map details specific for desk-based hearing
    rescheduleHearingDetails.scheduleHearingDetails.typeCode =
      HEARINGTYPE.DESK;

    // reschedule hearing
    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);

    return hearingScheduleReturnDtls;
  }

  /**
   * Calculated the deadline date to schedule a hearing for a specified hearing
   * case.
   * 
   * @param key
   * Hearing ID
   * @return
   * schedule hearing deadline date.
   */
  @Override
  public DeadlineDate calculateScheduleDeadlineDate(final AppealCaseID key)
    throws AppException, InformationalException {

    final DeadlineDate deadlineDate = new DeadlineDate();

    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // Appeal Objects
    final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    AppealTypeDetails appealTypeDetails;
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealCaseIDKey entityAppealCaseIDKey = new AppealCaseIDKey();
    curam.appeal.sl.entity.struct.DeadlineDate entityDeadlineDate;

    // AppealRelationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseKey =
      new curam.appeal.sl.entity.struct.AppealCaseID();
    ProductDeliveryIDDetailsList productIDDetailsList;

    // Number of days in which a hearing must be scheduled
    Integer timeToScheduleHearingInteger;
    int timeToScheduleHearing =
      EnvVars.ENV_APPEAL_TIMETOSCHEDULEHEARING_DEFAULT;
    // BEGIN CR00118512 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    // BEGIN, CR00284786, DG
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
      || caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)
      || caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      appealCaseIDKey.caseID = key.caseID;
      entityAppealCaseIDKey.caseID = key.caseID;

      // Get Appeal decision date
      entityDeadlineDate =
        appealEntityObj.readDeadlineDateByCase(entityAppealCaseIDKey);

      // Get Appeal Type
      appealTypeDetails =
        appealEntityObj.readAppealTypeByCase(appealCaseIDKey);

      // Get a list of all cases which are associated with the specified
      // appeal case.
      long caseID = 0;

      appealCaseID.appealCaseID = key.caseID;
      final CaseIDList caseIDList =
        appealRelationshipObj.searchCaseIDForAppeal(appealCaseID);

      // Use the first record returned as it is has the earliest deadline
      // date
      if (caseIDList.dtls.size() > 0) {
        caseID = caseIDList.dtls.item(0).caseID;
      }

      appealCaseKey.appealCaseID = key.caseID;
      productIDDetailsList =
        appealRelationshipObj
          .searchProductDeliveryIDByAppealCase(appealCaseKey);
      if (productIDDetailsList.dtls.size() > 0) {
        caseID = productIDDetailsList.dtls.item(0).productDeliveryID;
      }

      // Get the constraint for the hearing type
      String constraintType = CuramConst.gkEmpty;

      if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        constraintType = CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGCASE;
      } else {
        constraintType =
          CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGREVIEW;
      }

      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.appealCaseID = key.caseID;
      caseIDAppealCaseIDConstraintType.caseID = caseID;
      caseIDAppealCaseIDConstraintType.constraintType = constraintType;
      final int timeConstraintLength =
        AppealFactory.newInstance().getTimeConstraintLength(
          caseIDAppealCaseIDConstraintType).numberOfDays;

      timeToScheduleHearing = timeConstraintLength;

      if (timeConstraintLength == 0) {
        final CodeTableItemIdentifier constraintTypeCode =
          new CodeTableItemIdentifier(CONSTRAINTTYPE.TABLENAME,
            constraintType);
        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        ex.arg(constraintTypeCode);
        throw ex;
      }

    } else {
      entityDeadlineDate = new curam.appeal.sl.entity.struct.DeadlineDate();
      // END CR00118512 LP
      // Standalone case with no associated product then use the default
      // environment variable
      timeToScheduleHearingInteger =
        Configuration
          .getIntProperty(EnvVars.ENV_APPEAL_TIMETOSCHEDULEHEARING);

      // Use default value if the variable is not set
      if (timeToScheduleHearingInteger != null) {
        timeToScheduleHearing = timeToScheduleHearingInteger.intValue();
      }
    }
    // END, CR00284786

    // Change No days to negative value in order to subtract the number of days
    timeToScheduleHearing = 0 - timeToScheduleHearing;

    // Calculate the deadline date for the appeal case based
    deadlineDate.date =
      entityDeadlineDate.deadlineDate.addDays(timeToScheduleHearing);

    return deadlineDate;
  }

  /**
   * Method to create the schedule hearing task
   * 
   * @param appealCaseID
   * Contains the caseID for the appeal case.
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public void createScheduleHearingTask(final AppealCaseID appealCaseID)
    throws AppException, InformationalException {

    // Create the list we will pass to the enactment service.
    final List enactmentStructs = new ArrayList();
    final TaskCreateDetails taskCreateDetails = new TaskCreateDetails();

    DeadlineDate scheduleDeadlineDate;

    // Set Task CaseID & DeadlineDate
    taskCreateDetails.caseID = appealCaseID.caseID;

    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = appealCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);
    boolean isCreateTask;

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {
      isCreateTask = true;
    } else {
      // - read appeal type
      appealCaseIDKey.caseID = appealCaseID.caseID;
      appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);
      isCreateTask =
        appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)
          || appealTypeDetails.appealTypeCode
            .equals(APPEALTYPE.HEARINGREVIEW);
    }

    if (isCreateTask) {

      // Calculate schedule deadline date
      scheduleDeadlineDate = calculateScheduleDeadlineDate(appealCaseID);
      taskCreateDetails.deadlineDateTime =
        scheduleDeadlineDate.date.getDateTime();

      // Assign priority to task
      taskCreateDetails.priority = TASKPRIORITY.LOW;

      enactmentStructs.add(taskCreateDetails);

      // Enact work flow to create the schedule hearing task.
      EnactmentService.startProcess(Appeal.kAppealScheduleHearingTask,
        enactmentStructs);

    }

  }

  /*
   * Method to modify the schedule hearing task details
   * 
   * @param appealCaseID Contains the caseID for the appeal case.
   */
  @Override
  public void modifyScheduleHearingTask(final AppealCaseID appealCaseID)
    throws AppException, InformationalException {

    removeScheduleHearingTask(appealCaseID);

    createScheduleHearingTask(appealCaseID);
  }

  /*
   * Method to remove a schedule hearing task.
   * 
   * @param appealCaseID Contains the caseID for the appeal case.
   */
  @Override
  public void removeScheduleHearingTask(final AppealCaseID appealCaseID)
    throws AppException, InformationalException {

    // Work Flow event object
    final Event closeTaskEvent = new Event();

    // Raise work flow event to close the existing schedule hearing task.
    closeTaskEvent.eventKey.eventClass = Appeal.kEventClass;
    closeTaskEvent.eventKey.eventType = Appeal.kAppealScheduleHearingTask;
    closeTaskEvent.primaryEventData = appealCaseID.caseID;

    EventService.raiseEvent(closeTaskEvent);
  }

  /**
   * Schedules a external location based hearing.
   * 
   * @param details
   * Hearing details
   * @return
   * Unique identifier of the new created hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls scheduleExternalLocationHearing(
    final ScheduleExternalLocationHearingDetails details)
    throws AppException, InformationalException {

    // Schedule Hearing Details
    final ScheduleHearingDetails scheduleHearingDetails =
      new ScheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    // set the scheduled date time to be the scheduled date and the
    // start time of the slot
    final ConcernRole concernRole = ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.officialConcernRoleID;

    // BEGIN, CR00285004, MC
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    if (concernRoleKey.concernRoleID != 0) {
      concernRoleNameDetails =
        concernRole.readConcernRoleName(concernRoleKey);
    } else {
      throw new AppException(BPOHEARINGSCHEDULE.ERR_FV_OFFICIAL_UNSPECIFIED);
    }
    // END, CR00285004

    scheduleHearingDetails.scheduledDateTime =
      details.externalHearingDetails.scheduledDateTime;

    // map common details
    scheduleHearingDetails.caseID = details.externalHearingDetails.caseID;
    scheduleUserName.userName = concernRoleNameDetails.concernRoleName;
    scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);
    scheduleHearingDetails.comments = details.externalHearingDetails.comments;
    scheduleHearingDetails.appealTypeCode = APPEALTYPE.HEARING;

    // map home hearing details
    scheduleHearingDetails.externalOfficeID = details.locationID;

    // set hearing type
    scheduleHearingDetails.typeCode = HEARINGTYPE.LOCATION;
    scheduleHearingDetails.endTime = details.scheduledEndTime;

    scheduleHearingDetails.locationType = HEARINGLOCATIONTYPE.EXTERNAL;
    scheduleHearingDetails.officialConcernRoleID =
      details.officialConcernRoleID;

    // schedule hearing
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      scheduleHearing(scheduleHearingDetails);

    return hearingScheduleReturnDtls;
  }

  /**
   * Reschedules a location based hearing for a hearing case.
   * 
   * @param details
   * Reschedule home hearing details
   * @return
   * Unique identification of the rescheduled hearing and
   * informational messages
   */
  @Override
  public HearingScheduleReturnDtls rescheduleExternalLocationHearing(
    final RescheduleExternalLocationHearingDetails details)
    throws AppException, InformationalException {

    // return value
    HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    // Hearing entity and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID =
      new curam.appeal.sl.entity.struct.HearingCaseID();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();

    // Reschedule Hearing details
    final RescheduleHearingDetails rescheduleHearingDetails =
      new RescheduleHearingDetails();

    // Schedule user name
    final ScheduleUserName scheduleUserName = new ScheduleUserName();

    hearingKey.hearingID =
      details.rescheduleExternalLocationHearing.hearingID;

    // read hearing case id
    hearingCaseID = hearingObj.readCase(hearingKey);

    // map common details
    rescheduleHearingDetails
      .assign(details.rescheduleExternalLocationHearing);
    rescheduleHearingDetails.scheduleHearingDetails.appealTypeCode =
      APPEALTYPE.HEARING;
    rescheduleHearingDetails.scheduleHearingDetails.comments =
      details.rescheduleExternalLocationHearing.comments;
    rescheduleHearingDetails.scheduleHearingDetails.caseID =
      hearingCaseID.caseID;
    final ConcernRole concernRole = ConcernRoleFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.officialConcernRoleID;

    final ConcernRoleNameDetails concernRoleNameDetails =
      concernRole.readConcernRoleName(concernRoleKey);

    scheduleUserName.userName = concernRoleNameDetails.concernRoleName;

    rescheduleHearingDetails.scheduleHearingDetails.scheduleUserNameList.scheduleUserName
      .addRef(scheduleUserName);

    // set the scheduled date time to be the scheduled date and the
    // start time of the slot
    rescheduleHearingDetails.scheduleHearingDetails.scheduledDateTime =
      details.rescheduleExternalLocationHearing.scheduledDateTime;

    rescheduleHearingDetails.scheduleHearingDetails.officialConcernRoleID =
      details.officialConcernRoleID;

    // end time of the slot
    rescheduleHearingDetails.scheduleHearingDetails.endTime =
      details.scheduledEndTime;

    rescheduleHearingDetails.scheduleHearingDetails.externalOfficeID =
      details.locationID;
    rescheduleHearingDetails.scheduleHearingDetails.typeCode =
      HEARINGTYPE.LOCATION;
    rescheduleHearingDetails.scheduleHearingDetails.locationType =
      HEARINGLOCATIONTYPE.EXTERNAL;

    // reschedule hearing
    hearingScheduleReturnDtls = rescheduleHearing(rescheduleHearingDetails);
    final HearingDateAndLocationDetails hearingDateAndLocationDetails =
      hearingObj.readScheduledDateAndLocation(hearingKey);
    final DateTime scheduledDateTime =
      hearingDateAndLocationDetails.scheduledDateTime;

    if (scheduledDateTime
      .equals(details.rescheduleExternalLocationHearing.scheduledDateTime)) {

      throw new AppException(
        BPOHEARINGSCHEDULE.ERR_HEARING_DATETIME_NOT_CHANGED);
    }

    return hearingScheduleReturnDtls;
  }
}
