/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.impl.AppealableCaseType;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealedCaseRejectionFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealedCaseRejection;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseIDList;
import curam.appeal.sl.entity.struct.AppealCaseIDTYypeRecordStatusDetails;
import curam.appeal.sl.entity.struct.AppealTimeConstraintDetails;
import curam.appeal.sl.entity.struct.AppealTimeConstraintKey;
import curam.appeal.sl.entity.struct.AppealedCaseCountDetails;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDTypeAndBenefitsDetails;
import curam.appeal.sl.entity.struct.CaseOwnerStatusAndDeadlineDate;
import curam.appeal.sl.entity.struct.CasePriorCaseStatus;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionDtls;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionStatusDetails;
import curam.appeal.sl.entity.struct.HearingDecisionStatusVersionDetails;
import curam.appeal.sl.entity.struct.HearingDecisionVersionDetails;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.IdAndResolutionDetails;
import curam.appeal.sl.entity.struct.ModifyDeadlineDateDetails;
import curam.appeal.sl.entity.struct.ModifyDecisionResolutionDetails;
import curam.appeal.sl.entity.struct.NormalAndApprovedAppealCaseStatus;
import curam.appeal.sl.entity.struct.NormalAppealCaseStatus;
import curam.appeal.sl.entity.struct.ReadForRemoveDetails;
import curam.appeal.sl.entity.struct.ReadForValidateModifyAppealedCaseDetails;
import curam.appeal.sl.entity.struct.ReadSummaryDetails;
import curam.appeal.sl.entity.struct.RecordStatusDetails;
import curam.appeal.sl.entity.struct.ResolutionAndStatusDetails;
import curam.appeal.sl.entity.struct.ResolutionDetails;
import curam.appeal.sl.entity.struct.ResolutionForModifyDetails;
import curam.appeal.sl.entity.struct.ResolutionPriorAppealDetails;
import curam.appeal.sl.entity.struct.ResolutionPriorAppealForModifyDetails;
import curam.appeal.sl.entity.struct.StatusAndRecordStatus;
import curam.appeal.sl.entity.struct.TimelyIndicator;
import curam.appeal.sl.fact.AppealDecisionFactory;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealDecision;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealCaseStatusDetails;
import curam.appeal.sl.struct.AppealDeadlineDateDetails;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.AppealResolutionDetails;
import curam.appeal.sl.struct.AppealTypeDetails;
import curam.appeal.sl.struct.AppealedCaseRejectionComment;
import curam.appeal.sl.struct.AppealedCaseRejectionReasons;
import curam.appeal.sl.struct.AppealedCaseRemoveDetails;
import curam.appeal.sl.struct.AppealedCaseSummaryDetails;
import curam.appeal.sl.struct.CalculateAppealDeadlineDateDetails;
import curam.appeal.sl.struct.CalculateAppealDeadlineDateDetails1;
import curam.appeal.sl.struct.CaseAlreadyAppealed;
import curam.appeal.sl.struct.CaseAndPriorAppeal;
import curam.appeal.sl.struct.CaseIDAppealCaseIDConstraintType;
import curam.appeal.sl.struct.CaseIDDeadlineDate;
import curam.appeal.sl.struct.CaseIDDetails;
import curam.appeal.sl.struct.CaseIDProductID;
import curam.appeal.sl.struct.CreateBenefitTaskAppealedCaseDetails;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.IsTimelyResult;
import curam.appeal.sl.struct.ModifyAppealedCaseDetails;
import curam.appeal.sl.struct.ModifyResolutionDetails;
import curam.appeal.sl.struct.ProductIDDetails;
import curam.appeal.sl.struct.ReadAppealDetails;
import curam.appeal.sl.struct.ReadForModifyAppealedCaseDetails;
import curam.appeal.sl.struct.ReadResolutionDetails;
import curam.appeal.sl.struct.ReadResolutionForModifyDetails;
import curam.appeal.sl.struct.ReadResolutionPriorAppealDetails;
import curam.appeal.sl.struct.ReadResolutionPriorAppealForModifyDetails;
import curam.appeal.sl.struct.RemoveRelationshipLinksDetails;
import curam.appeal.sl.struct.ValidateModifyAppealedCaseDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONSTRAINTTYPE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.NotificationFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.Notification;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseRegDateEndDateDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.Count;
import curam.core.struct.OwnerID;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.core.struct.regDateDetails;
import curam.message.BPOAPPEAL;
import curam.message.BPOAPPEALCOMMUNICATION;
import curam.message.BPOAPPEALEDCASE;
import curam.message.BPOISSUEAPPEALRELATIONSHIP;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.util.type.UniqueID;
import java.util.Map;

/**
 * This process class provides the functionality for the AppealedCase service
 * layer.
 */
public abstract class AppealedCase extends curam.appeal.sl.base.AppealedCase {

  @Inject
  private Map<CASETYPECODEEntry, AppealableCaseType> appealableCaseTypeMap;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  public AppealedCase() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Removes the selected appealed case from the appeal by updating the record
   * status to canceled
   * 
   * @param details
   * Contains the record status, version numbers and
   * appealRelationshipID
   */

  @Override
  public void remove(final AppealedCaseRemoveDetails details)
    throws AppException, InformationalException {

    // Variables for notification
    final Notification notification = NotificationFactory.newInstance();
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Variables for case header and ownership
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseKey caseKey = new CaseKey();
    CaseReference caseReference;
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseTypeCode caseTypeCode;
    ReadParticipantRoleIDDetails readParticipantRoleIDDetails;
    final OwnerID ownerID = new OwnerID();

    // Variables for Appeal service layer
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    DeadlineDate deadlineDate;
    final RemoveRelationshipLinksDetails removeRelationshipLinksDetails =
      new RemoveRelationshipLinksDetails();

    // Variables for the Appeal entity
    final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final ModifyDeadlineDateDetails modifyDeadlineDateDetails =
      new ModifyDeadlineDateDetails();

    // Variables for AppealedCase service layer
    final CreateBenefitTaskAppealedCaseDetails createBenefitTaskAppealedCaseDetails =
      new CreateBenefitTaskAppealedCaseDetails();

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKeyForModify =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKeyForRead =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final RecordStatusDetails recordStatusDetails = new RecordStatusDetails();
    ReadForRemoveDetails readForRemoveDetails;

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // AppealRelationship entity variables
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.struct.AppealCaseID();

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = details.appealRelationshipID;
    appealCaseID.caseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey).appealCaseID;

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Variable for task update
    final CaseIDDeadlineDate caseIDDeadlineDate = new CaseIDDeadlineDate();

    // Validate the removal and then remove the appealed case from appeal

    validateRemove(appealCaseID, details);

    recordStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
    appealRelationshipKeyForModify.appealRelationshipID =
      details.appealRelationshipID;
    appealRelationshipObj.modifyRecordStatus(appealRelationshipKeyForModify,
      recordStatusDetails);

    // If the appealed case being removed has already been approved then
    // need to
    // determine if the removal of that appealed case affects the overall
    // appeal
    // deadline date.

    appealRelationshipKeyForRead.appealRelationshipID =
      details.appealRelationshipID;
    readForRemoveDetails =
      appealRelationshipObj.readForRemove(appealRelationshipKeyForRead);
    if (readForRemoveDetails.statusCode.equals(CASESTATUS.APPROVED)) {
      appealCaseKey.caseID = readForRemoveDetails.appealCaseID;
      deadlineDate = appealObj.calculateDeadlineDate(appealCaseKey);

      // If the overall appeal deadline date has changed as a result of the
      // removal of the approved appealed case, then update the appeal deadline
      // date and it's associated deadline task accordingly.

      if (!deadlineDate.date.equals(readForRemoveDetails.deadlineDate)) {
        appealCaseIDKey.caseID = readForRemoveDetails.appealCaseID;
        modifyDeadlineDateDetails.deadlineDate = deadlineDate.date;
        modifyDeadlineDateDetails.versionNo = details.appealVersionNo;
        appealEntityObj.modifyDeadlineDate(appealCaseIDKey,
          modifyDeadlineDateDetails);

        // Apply the new deadline date to the deadline task
        caseIDDeadlineDate.deadlineDate = deadlineDate.date;
        caseIDDeadlineDate.caseID = appealCaseIDKey.caseID;
        appealObj.modifyDeadlineTask(caseIDDeadlineDate);

        // Notification when the user is not the owner of the case
        caseHeaderKey.caseID = readForRemoveDetails.caseID;
        // BEGIN, CR00053295, RKi
        final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();
        CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
        // END, CR00053295

        if (!caseOwnerDetails.userName.equals(TransactionInfo
          .getProgramUser())) {

          caseSearchKey.caseID = readForRemoveDetails.caseID;
          caseReference =
            caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

          readParticipantRoleIDDetails =
            caseHeaderObj.readParticipantRoleID(caseHeaderKey);

          standardManualTaskDtls.dtls.taskDtls.subject =
            caseReference.toString();
          standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
            GeneralAppealConstants.kAppealedCaseRemovalNotification;
          standardManualTaskDtls.dtls.concerningDtls.caseID =
            readForRemoveDetails.caseID;
          standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
            readParticipantRoleIDDetails.concernRoleID;

          standardManualTaskDtls.dtls.assignDtls.assignmentID =
            ownerID.toString();

          notification
            .createWorkAllocationNotification(standardManualTaskDtls);
        }
      }
    }

    // Remove any relationships to this appealed case
    caseKey.caseID = readForRemoveDetails.caseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    removeRelationshipLinksDetails.appealTypeCode =
      readForRemoveDetails.appealTypeCode;
    removeRelationshipLinksDetails.caseID = readForRemoveDetails.caseID;
    removeRelationshipLinksDetails.priorAppealCaseID =
      readForRemoveDetails.priorAppealCaseID;
    removeRelationshipLinksDetails.caseTypeCode = caseTypeCode.caseTypeCode;
    appealObj.removeRelationshipLinks(removeRelationshipLinksDetails);

    // If benefits had been discontinued then need to resume benefits.
    if (!readForRemoveDetails.continueBenefitsIndicator) {
      createBenefitTaskAppealedCaseDetails.caseID =
        readForRemoveDetails.caseID;
      createBenefitTaskAppealedCaseDetails.caseType =
        caseTypeCode.caseTypeCode;
      createBenefitTaskAppealedCaseDetails.continueBenefitsIndicator = true;
      appealObj.createBenefitTask(createBenefitTaskAppealedCaseDetails);
    }

    // BEGIN, CR00050710, RKi
    if (readForRemoveDetails.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = readForRemoveDetails.caseID;

      // Log Remove From Hearing Case event
      if (readForRemoveDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.REMOVED_FROM_HEARING_CASE;
      }

      // Log Remove From Hearing Review event
      if (readForRemoveDetails.appealTypeCode
        .equals(APPEALTYPE.HEARINGREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.REMOVED_FROM_HEARING_REVIEW;
      }

      // Log Remove From Judicial Review event
      if (readForRemoveDetails.appealTypeCode
        .equals(APPEALTYPE.JUDICIALREVIEW)) {
        insertTransactionLogDetails.eventTypeCode =
          CASETRANSACTIONEVENTS.REMOVED_FROM_JUDICIAL_REVIEW;
      }
      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);
    }
    // END, CR00050710
  }

  // ___________________________________________________________________________
  /**
   * Returns the details needed for display on the modify Appealed case page
   * 
   * @param key
   * Contains the appealRelationshipID
   * 
   * @return The details to be displayed on the modify Appealed case page
   */
  @Override
  public ReadForModifyAppealedCaseDetails readForModify(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Variable for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    // Variable to contain the appealed case details
    final ReadForModifyAppealedCaseDetails readForModifyAppealedCaseDetails =
      new ReadForModifyAppealedCaseDetails();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Appeal Case entity variable
    AppealCaseID appealCaseID;

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Get the details from the AppealRelationship entity
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    readForModifyAppealedCaseDetails.readForModifyAppealedCaseDetails =
      appealRelationshipObj.readForModifyAppealedCase(appealRelationshipKey);

    return readForModifyAppealedCaseDetails;
  }

  // _________________________________________________________________________
  /**
   * Returns the appealed case details for a particular appealed case
   * 
   * @param key
   * Contains the appealRelationshipID
   * 
   * @return The details for a particular appealed case
   */
  @Override
  public AppealedCaseSummaryDetails read(final AppealRelationshipKey key)
    throws AppException, InformationalException {

    // Variable for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    // Variable to contain the appealed case details
    final AppealedCaseSummaryDetails appealedCaseSummaryDetails =
      new AppealedCaseSummaryDetails();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // AppealRelationship entity variables
    ReadSummaryDetails readSummaryDetails = new ReadSummaryDetails();

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    readSummaryDetails =
      appealRelationshipObj.readSummary(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = readSummaryDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Get the details from the AppealRelationship entity
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    appealedCaseSummaryDetails.readSummaryDetails =
      appealRelationshipObj.readSummary(appealRelationshipKey);

    AppealCaseID appealCaseID;
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppealDetails readAppealDetails = new ReadAppealDetails();

    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);
    appealCaseKey.caseID = appealCaseID.appealCaseID;
    readAppealDetails = appealObj.readAppealDetails(appealCaseKey);
    appealedCaseSummaryDetails.readSummaryDetails.deadlineDate =
      readAppealDetails.appealReadSummaryDetails.deadlineDate;

    return appealedCaseSummaryDetails;

  }

  // _________________________________________________________________________
  /**
   * Validates the appealed case details to be modified
   * 
   * @param details
   * The appealed case details to be validated
   */

  @Override
  protected void validateModify(
    final ValidateModifyAppealedCaseDetails details) throws AppException,
    InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Variables for case header details for the appealed case
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeaderKey appealCaseHeaderKey = new CaseHeaderKey();
    final CaseHeaderKey priorAppealCaseHeaderKey = new CaseHeaderKey();
    CaseStatusCode appealCaseStatusCode;
    regDateDetails regDateDetails;

    CaseRegDateEndDateDetails priorAppealCaseRegDateEndDateDetails;

    // added to get case start date
    CaseStartDate caseStartDate;

    // Get the case ID values as case header keys
    caseHeaderKey.caseID =
      details.readForValidateModifyAppealedCaseDetails.caseID;
    appealCaseHeaderKey.caseID =
      details.readForValidateModifyAppealedCaseDetails.appealCaseID;
    priorAppealCaseHeaderKey.caseID =
      details.readForValidateModifyAppealedCaseDetails.priorAppealCaseID;

    // added to get case start date
    caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);
    // If the appeal case has been closed then cannot modify the appealed
    // case
    appealCaseStatusCode = caseHeaderObj.readStatus(appealCaseHeaderKey);
    // BEGIN, CR00097244, RKi
    if (appealCaseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      informationalManager.addInformationalMsg(
        // END, CR00097244
        new AppException(BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_CLOSED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } // Has a decision been made on the appeal?
    else if (details.readForValidateModifyAppealedCaseDetails.resolutionCode
      .equals(HEARINGDECISIONRESOLUTION.ACCEPTED)
      || details.readForValidateModifyAppealedCaseDetails.resolutionCode
        .equals(HEARINGDECISIONRESOLUTION.REJECTED)
      || details.readForValidateModifyAppealedCaseDetails.resolutionCode
        .equals(HEARINGDECISIONRESOLUTION.REMANDED)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_DECISION_MADE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } // Check if a decision has already been made on this appeal.
    else if (details.readForValidateModifyAppealedCaseDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_DECISION_MADE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } else {
      regDateDetails = caseHeaderObj.readRegDate(caseHeaderKey);

      // If the effective date been changed
      // then must not be before registration date
      // and appeal case must not have already been approved.

      if (!details.modifyAppealedCaseDetails.appealedDecisionDate
        .equals(details.readForValidateModifyAppealedCaseDetails.appealedDecisionDate)) {

        if (details.readForValidateModifyAppealedCaseDetails.statusCode
          .equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {

          // BEGIN, CR CR00066604, NSP
          informationalManager
            .addInformationalMsg(
              new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RESOLUTIONAPPRDATE_LATER_STARTDATE),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
          // END, CR CR00066604

        } // BEGIN, HARP 64092, PN
        // changed the condition to compare Effective with Case start date
        else if (details.modifyAppealedCaseDetails.appealedDecisionDate
          .before(caseStartDate.startDate)) {
          informationalManager
            .addInformationalMsg(
              new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XFV_EFFECTIVEDATE_BEFORE_CASESTARTDATE),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
        }
      }

      // If the receipt date has changed
      // then check that the appeal has not already been approved.

      if (!details.modifyAppealedCaseDetails.receivedDate
        .equals(details.readForValidateModifyAppealedCaseDetails.receivedDate)) {

        if (details.readForValidateModifyAppealedCaseDetails.statusCode
          .equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {

          informationalManager
            .addInformationalMsg(
              new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RECEIPTDATE_ALREADY_APPROVED),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);

        } else {

          // If there is a prior appeal case
          // then check the dates of the prior appeal case.

          if (details.readForValidateModifyAppealedCaseDetails.priorAppealCaseID != 0) {

            priorAppealCaseRegDateEndDateDetails =
              caseHeaderObj.readRegDateAndEndDate(priorAppealCaseHeaderKey);

            if (details.modifyAppealedCaseDetails.receivedDate
              .before(priorAppealCaseRegDateEndDateDetails.endDate)) {

              informationalManager
                .addInformationalMsg(
                  new AppException(
                    BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RECEIPTDATE_BEFORE_ENDDATE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError);
            }

            if (details.modifyAppealedCaseDetails.receivedDate
              .before(priorAppealCaseRegDateEndDateDetails.registrationDate)) {

              informationalManager
                .addInformationalMsg(
                  new AppException(
                    BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RECEIPTDATE_BEFORE_REGDATE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError);
            }
          } // If there is no prior appeal case
          // then check the registration date of the appealed case.
          else {
            if (details.modifyAppealedCaseDetails.receivedDate
              .before(regDateDetails.registrationDate)) {

              informationalManager
                .addInformationalMsg(
                  new AppException(
                    BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RECEIPTDATE_BEFORE_REGDATE),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError);
            }
          }
        }
      }

      // If the receipt method has changed
      // then check that the case is not already approved.

      if (!details.modifyAppealedCaseDetails.receiptMethod
        .equals(details.readForValidateModifyAppealedCaseDetails.receiptMethod)) {

        if (details.readForValidateModifyAppealedCaseDetails.statusCode
          .equals(CASESTATUS.APPROVED)) {

          informationalManager
            .addInformationalMsg(
              new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_RECEIPTMETHOD_ALREADY_APPROVED),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
        }
      }
    }

    // Report any validation errors found.
    informationalManager.failOperation();
  }

  // _________________________________________________________________________
  /**
   * Modifies the details of a particular appealed case and recalculates the
   * deadline date of the appealed case
   * 
   * @param details
   * The details of a particular appealed case to be modified
   */
  @Override
  public void modify(final ModifyAppealedCaseDetails details)
    throws AppException, InformationalException {

    // Variables for Appeal service layer
    final Appeal appealObj = AppealFactory.newInstance();
    final CreateBenefitTaskAppealedCaseDetails createBenefitTaskAppealedCaseDetails =
      new CreateBenefitTaskAppealedCaseDetails();
    DeadlineDate deadlineDate = new DeadlineDate();
    final AppealDeadlineDateDetails appealDeadlineDateDetails =
      new AppealDeadlineDateDetails();
    IsTimelyResult isTimelyResult = new IsTimelyResult();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    AppealTypeDetails appealTypeDetails;

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipEntityKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    // Variables for validation details
    final ValidateModifyAppealedCaseDetails validateModifyAppealedCaseDetails =
      new ValidateModifyAppealedCaseDetails();
    ReadForValidateModifyAppealedCaseDetails readForValidateModifyAppealedCaseDetails;
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();

    // Variables for Case Header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode = new CaseTypeCode();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // AppealRelationship entity variables
    AppealCaseID appealCaseID;

    // Read the appealed case ID for the security check
    appealRelationshipEntityKey.appealRelationshipID =
      details.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipEntityKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read the existing details for the appealed case
    readForValidateModifyAppealedCaseDetails =
      appealRelationshipObj
        .readForValidateModify(appealRelationshipEntityKey);

    // Validate the modified details for the appealed case
    validateModifyAppealedCaseDetails.readForValidateModifyAppealedCaseDetails
      .assign(readForValidateModifyAppealedCaseDetails);
    validateModifyAppealedCaseDetails.modifyAppealedCaseDetails
      .assign(details.modifyAppealedCaseDetails);
    validateModify(validateModifyAppealedCaseDetails);

    appealCaseKey.caseID =
      readForValidateModifyAppealedCaseDetails.appealCaseID;
    appealTypeDetails = appealObj.readAppealType(appealCaseKey);

    // If either of the effective date or the receipt date has changed
    // then update the timeliness indicator.
    if (!details.modifyAppealedCaseDetails.appealedDecisionDate
      .equals(readForValidateModifyAppealedCaseDetails.appealedDecisionDate)
      || !details.modifyAppealedCaseDetails.receivedDate
        .equals(readForValidateModifyAppealedCaseDetails.receivedDate)) {

      // BEGIN, CR00269510, ZV
      appealDeadlineDateDetails.appealedDecisionDate =
        details.modifyAppealedCaseDetails.appealedDecisionDate;
      appealDeadlineDateDetails.appealType =
        appealTypeDetails.appealTypeDetails.appealTypeCode;
      appealDeadlineDateDetails.caseID =
        readForValidateModifyAppealedCaseDetails.caseID;
      appealDeadlineDateDetails.receivedDate =
        details.modifyAppealedCaseDetails.receivedDate;
      // END, CR00269510

      isTimelyResult = appealObj.isTimely(appealDeadlineDateDetails);
      details.modifyAppealedCaseDetails.timelyIndicator =
        isTimelyResult.timelyInd;

      // BEGIN, CR00284484, KOH
      // If the date has not been changed, the timelyIndicator in the modify
      // struct will be populated from the database.
    } else {
      final TimelyIndicator timelyIndicator =
        appealRelationshipObj
          .readTimelyIndicator(appealRelationshipEntityKey);

      details.modifyAppealedCaseDetails.timelyIndicator =
        timelyIndicator.timelyIndicator;
    }
    // END, CR00284484

    // If this is not a judicial review then recalculate the deadline date
    if (!appealTypeDetails.appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.JUDICIALREVIEW)) {

      calculateAppealDeadlineDateDetails1.appealTypeCode =
        appealTypeDetails.appealTypeDetails.appealTypeCode;
      calculateAppealDeadlineDateDetails1.implCaseID =
        readForValidateModifyAppealedCaseDetails.caseID;
      calculateAppealDeadlineDateDetails1.receivedDate =
        details.modifyAppealedCaseDetails.receivedDate;
      calculateAppealDeadlineDateDetails1.appealCaseID =
        appealCaseID.appealCaseID;
      deadlineDate =
        calculateDeadlineDate1(calculateAppealDeadlineDateDetails1);
      details.modifyAppealedCaseDetails.deadlineDate = deadlineDate.date;
    }

    // Modify the appeal relationship entity for this appealed case

    appealRelationshipObj.modifyDetails(appealRelationshipEntityKey,
      details.modifyAppealedCaseDetails);

    // If the Continue Benefits Indicator has changed
    // then create a new Benefit Task.
    if (details.modifyAppealedCaseDetails.continueBenefitsIndicator != readForValidateModifyAppealedCaseDetails.continueBenefitsIndicator) {

      caseKey.caseID = readForValidateModifyAppealedCaseDetails.caseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
      createBenefitTaskAppealedCaseDetails.caseID = caseKey.caseID;
      createBenefitTaskAppealedCaseDetails.caseType =
        caseTypeCode.caseTypeCode;
      createBenefitTaskAppealedCaseDetails.continueBenefitsIndicator =
        details.modifyAppealedCaseDetails.continueBenefitsIndicator;

      appealObj.createBenefitTask(createBenefitTaskAppealedCaseDetails);
    }
  }

  // _________________________________________________________________________
  /**
   * Determines if the appealed case can be removed from the appeal
   * 
   * @param details
   * Contains the record status, version numbers and
   * appealRelationshipID
   */
  @Override
  protected void validateRemove(
    final curam.appeal.sl.struct.AppealCaseID appealCaseID,
    final AppealedCaseRemoveDetails details) throws AppException,
    InformationalException {

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    ResolutionAndStatusDetails resolutionAndStatusDetails;

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // BEGIN, CR00022466, RKi
    // Set key to read CaseHeader
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseIDTypeAndBenefitsDetails caseIDTypeAndBenefitsDetails =
      new CaseIDTypeAndBenefitsDetails();
    final AppealCaseID appealCaseIDObj = new AppealCaseID();

    appealCaseIDObj.appealCaseID = appealCaseID.caseID;
    appealRelationshipKey.appealRelationshipID = details.appealRelationshipID;
    caseIDTypeAndBenefitsDetails =
      appealRelationshipObj
        .readCaseIDCaseTypeAndContinueBenefits(appealRelationshipKey);
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    if (caseIDTypeAndBenefitsDetails.caseType.equals(CASETYPECODE.ISSUE)) {

      // cannot delete an issue if an decision status other than 'Not Started'
      // exists for the issue.
      ResolutionDetails resolutionDetails;

      resolutionDetails =
        appealRelationshipObj.readResolution(appealRelationshipKey);
      if (!HEARINGDECISIONRESOLUTION.NOTDECIDED
        .equals(resolutionDetails.resolutionCode)) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALRELATIONSHIP.ERR_FV_APPEALCASEDECISION_NOTDECIDED_CANNOT_CANCEL),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

      // checks if the appeal case status is canceled to remove an issue from
      // appeal case.
      caseHeaderKey.caseID = appealCaseID.caseID;
      CaseStatusCode caseStatusCode = new CaseStatusCode();

      caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
      if (CASESTATUS.CANCELED.equals(caseStatusCode.statusCode)) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALRELATIONSHIP.ERR_FV_APPEALCASE_CANCELLED_ISSUE_CANNOT_BE_REMOVED),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

      // checks if an appeal case has at least one appealed issue.
      Count count;
      final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
        new AppealCaseIDTYypeRecordStatusDetails();

      appealCaseIDTYypeRecordStatusDetails.appealCaseID = appealCaseID.caseID;
      appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
      appealCaseIDTYypeRecordStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
      count =
        appealRelationshipObj
          .countActiveAppealedIssuesOnAppealCase(appealCaseIDTYypeRecordStatusDetails);
      if (count.numberOfRecords < 2) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOISSUEAPPEALRELATIONSHIP.ERR_FV_ATLEAST_ONE_APPEALEDISSUE_CANNOT_CANCEL_APPEALCASE),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

      // checks if the appealed case status is deleted
      StatusAndRecordStatus statusAndRecordStatus;

      statusAndRecordStatus =
        appealRelationshipObj
          .readStatusAndRecordStatus(appealRelationshipKey);
      if (RECORDSTATUS.CANCELLED.equals(statusAndRecordStatus.recordStatus)) {
        informationalManager.addInformationalMsg(new AppException(
          BPOISSUEAPPEALRELATIONSHIP.ERR_FV_APPEALEDISSUE_ALREADY_CANCELLED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

    } else {
      // END, CR00022466
      AppealedCaseCountDetails appealedCaseCountDetails;
      final NormalAppealCaseStatus normalAppealCaseStatus =
        new NormalAppealCaseStatus();

      // Variables for Appeal entity
      final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
      CaseOwnerStatusAndDeadlineDate caseOwnerStatusAndDeadlineDate;
      final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
        curam.appeal.sl.entity.fact.AppealFactory.newInstance();
      final AppealCaseStatusDetails appealStatusDtls =
        new AppealCaseStatusDetails();
      final NormalAndApprovedAppealCaseStatus normalAndApprovedAppealCaseStatus =
        new NormalAndApprovedAppealCaseStatus();

      // Appeal case status must be open or active
      appealCaseIDKey.caseID = appealCaseID.caseID;
      caseOwnerStatusAndDeadlineDate =
        appealEntityObj.readCaseOwnerStatusAndDeadlineDate(appealCaseIDKey);
      appealStatusDtls.statusCode = caseOwnerStatusAndDeadlineDate.statusCode;

      if (!appealStatusDtls.statusCode.equals(CASESTATUS.OPEN)
        && !appealStatusDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !appealStatusDtls.statusCode.equals(CASESTATUS.APPROVED)) {

        // Cannot approve an appealed case for an inactive appeal case
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASESTATUSINVALID),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else {
        // If a decision has already been made on the appealed case then
        // it cannot
        // be removed.
        appealRelationshipKey.appealRelationshipID =
          details.appealRelationshipID;
        resolutionAndStatusDetails =
          appealRelationshipObj
            .readResolutionAndRecordStatus(appealRelationshipKey);

        if (resolutionAndStatusDetails.resolutionCode
          .equals(HEARINGDECISIONRESOLUTION.ACCEPTED)
          || resolutionAndStatusDetails.resolutionCode
            .equals(HEARINGDECISIONRESOLUTION.REJECTED)
          || resolutionAndStatusDetails.resolutionCode
            .equals(HEARINGDECISIONRESOLUTION.REMANDED)) {

          informationalManager
            .addInformationalMsg(new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_DECISION_MADE),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);

          // If the appealed case has already been removed by another
          // user
          // then need to report this to the current user.
        } else if (resolutionAndStatusDetails.recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {

          informationalManager
            .addInformationalMsg(new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_ALREADY_REMOVED),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);

        } else {

          final ReadForRemoveDetails readForRemoveDetails =
            appealRelationshipObj.readForRemove(appealRelationshipKey);

          // At least one approved appealed case needs to be there for
          // the approved appeal case
          if (appealStatusDtls.statusCode.equals(CASESTATUS.APPROVED)
            && readForRemoveDetails.statusCode
              .equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {

            // Check is there any other approved appealed case apart
            // from this
            normalAndApprovedAppealCaseStatus.appealCaseID =
              appealCaseID.caseID;

            appealedCaseCountDetails =
              appealRelationshipObj
                .countActiveAndApprovedAppealedCasesByAppealCase(normalAndApprovedAppealCaseStatus);

            if (appealedCaseCountDetails.recordCount <= 1) {
              informationalManager.addInformationalMsg(new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_CANNOT_REMOVE_APPROVED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError);
            }

          } // If there are no other appealed cases on this appeal
          // then cannot
          // remove this appealed case from the appeal as each appeal
          // must have at least one appealed case.
          else {

            normalAppealCaseStatus.appealCaseID = appealCaseID.caseID;
            normalAppealCaseStatus.normalRecordStatus = RECORDSTATUS.NORMAL;

            appealedCaseCountDetails =
              appealRelationshipObj
                .countActiveAppealedCasesByAppealCase(normalAppealCaseStatus);

            if (appealedCaseCountDetails.recordCount <= 1) {
              informationalManager.addInformationalMsg(new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_CANNOT_REMOVE),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError);
            }
          }
        }
      }
    }

    // Report any validation errors found
    informationalManager.failOperation();
  }

  // _________________________________________________________________________
  /**
   * Calculates the deadline date for an appealed case.
   * 
   * @param details
   * Contains the details needed to calculate the deadline date
   * 
   * @return The calculated deadline date of the appealed case
   * @deprecated Since Curam 6.0 SP2, Replaced with
   * {@link calculateDeadlineDate1} which takes into account time
   * constraints stored on the new AppealStageTimeConstraints
   * entity, As part of the appeals enhancements in v6SP2 time
   * constraints are now stored on the AppealStageTimeConstraints
   * entity. Using the new method calculareDeadlineDate1 will lookup
   * time constraints in new location first before falling back to
   * the legacy tables. See release note: CR00295153.
   */
  @Override
  @Deprecated
  public DeadlineDate calculateDeadlineDate(
    final CalculateAppealDeadlineDateDetails details) throws AppException,
    InformationalException {

    // Variable for the return deadline date
    final DeadlineDate deadlineDate = new DeadlineDate();

    // BEGIN, CR00095359, RKi
    // Case Header Objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // check if the parent case is an Issue case
    caseKey.caseID = details.implCaseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    // END, CR00095359

    // Appeal Service Layer Objects
    final Appeal appealObj = AppealFactory.newInstance();
    final CaseIDDetails caseIDDetails = new CaseIDDetails();
    ProductIDDetails productIDDetails = new ProductIDDetails();

    // Appeal entity Object
    final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // Appeal Time Constraint Objects
    final AppealTimeConstraintKey appealTimeConstraintKey =
      new AppealTimeConstraintKey();
    AppealTimeConstraintDetails appealTimeConstraintDetails =
      new AppealTimeConstraintDetails();

    // Number of days in which an appeal must be decided and implemented
    Integer timeToDecideAndImplementHearingInteger;
    int timeToDecideAndImplementHearing =
      EnvVars.ENV_APPEAL_TIMETODECIDEANDIMPLEMENTHEARING_DEFAULT;

    caseIDDetails.caseID = details.implCaseID;

    if (!CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
      productIDDetails = appealObj.getProductForCase(caseIDDetails);
    }

    // if the parent case is an Issue case, then the time constraints
    // should read from Issue related time constraint entities and
    // not Product related time constraints.
    // BEGIN, CR00095359, RKi
    if (productIDDetails.productID != 0
      || CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {

      if (!CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
        // Get Appeal Case's lead case ID and product ID
        final curam.appeal.sl.struct.AppealCaseID appealCaseID =
          new curam.appeal.sl.struct.AppealCaseID();

        appealCaseID.caseID = details.implCaseID;
        final CaseIDProductID caseIDProductID =
          appealObj.getCaseIDAndProductIDForAppealCase(appealCaseID);

        if (caseIDProductID.caseID != 0) {
          appealTimeConstraintKey.caseID = caseIDProductID.caseID;
        } else {
          appealTimeConstraintKey.caseID = details.implCaseID;
        }
      } else {
        appealTimeConstraintKey.caseID = details.implCaseID;
      }

      appealTimeConstraintKey.constraintDate =
        curam.util.type.Date.getCurrentDate();
      appealTimeConstraintKey.recordStatus =
        curam.codetable.RECORDSTATUS.NORMAL;
      // END, CR00095359

      if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        appealTimeConstraintKey.constraintType =
          CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGCASE;
      } else {
        appealTimeConstraintKey.constraintType =
          CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGREVIEW;
      }

      try {
        // BEGIN, CR00095359, RKi
        if (!CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
          appealTimeConstraintDetails =
            appealEntityObj
              .readTimeConstraintByTypeAndProductCase(appealTimeConstraintKey);
        } else {

          appealTimeConstraintDetails =
            appealEntityObj
              .readTimeConstraintByTypeAndIssueConfiguration(appealTimeConstraintKey);
        }
        // END, CR00095359
        timeToDecideAndImplementHearing =
          appealTimeConstraintDetails.numberOfDays;

      } catch (final RecordNotFoundException e) {
        final CodeTableItemIdentifier constraintType =
          new CodeTableItemIdentifier(CONSTRAINTTYPE.TABLENAME,
            appealTimeConstraintKey.constraintType);
        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        ex.arg(constraintType);
        throw ex;
      }

    } else {

      // Standalone case with no associated product then use the default
      // environment variable
      timeToDecideAndImplementHearingInteger =
        curam.util.resources.Configuration
          .getIntProperty(EnvVars.ENV_APPEAL_TIMETODECIDEANDIMPLEMENTHEARING);

      // Use default value if the variable is not set
      if (timeToDecideAndImplementHearingInteger != null) {
        timeToDecideAndImplementHearing =
          timeToDecideAndImplementHearingInteger.intValue();
      }
    }

    // Calculate the deadline date for the appeal case based
    deadlineDate.date =
      details.receivedDate.addDays(timeToDecideAndImplementHearing);

    return deadlineDate;
  }

  // _________________________________________________________________________
  /**
   * Validates the details for an appealed case modification.
   * 
   * @param dtls
   * The appealed case resolution details to validate
   */
  @Override
  protected void validateModifyResolution(final ModifyResolutionDetails dtls)
    throws AppException, InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    curam.appeal.sl.entity.struct.AppealCaseStatusDetails appealCaseStatusDetails;

    // Hearing Object
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingKey hearingKey;

    // HearingDecision Object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails;

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // HARP, BEGIN 47570, SH
    // Appeal Object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseIDKey appealCaseIDKey =
      new curam.appeal.sl.entity.struct.AppealCaseIDKey();
    curam.appeal.sl.entity.struct.AppealTypeDetails appealTypeDetails;

    // Get the appeal case id and status
    appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
    appealCaseStatusDetails =
      appealRelationshipObj
        .readAppealCaseAndAppealStatus(appealRelationshipKey);

    // Check for correct status
    if (!appealCaseStatusDetails.statusCode.equals(CASESTATUS.OPEN)
      && !appealCaseStatusDetails.statusCode.equals(CASESTATUS.APPROVED)
      && !appealCaseStatusDetails.statusCode.equals(CASESTATUS.ACTIVE)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_NOT_ACTIVE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    } else {

      // Find the hearing
      caseAndStatusKey.caseID = appealCaseStatusDetails.appealCaseID;
      caseAndStatusKey.statusCode = HEARINGSTATUS.COMPLETED;
      boolean hearingfound = true;

      try {

        hearingKey =
          hearingObj.readLatestHearingByCaseAndStatus(caseAndStatusKey);

      } catch (final curam.util.exception.RecordNotFoundException e) {

        hearingfound = false;

        // Find the appeal type
        appealCaseIDKey.caseID = appealCaseStatusDetails.appealCaseID;
        appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

        // Throw exception only if not a judicial review.
        if (!appealTypeDetails.appealTypeCode
          .equals(APPEALTYPE.JUDICIALREVIEW)) {

          informationalManager
            .addInformationalMsg(new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_NO_FINAL_HEARING),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
        }
      }

      // Make sure the hearing has been found.
      if (hearingfound) {

        caseAndStatusKey.caseID = appealCaseStatusDetails.appealCaseID;
        caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;
        try {

          hearingKey =
            hearingObj.readLatestHearingByCaseAndStatus(caseAndStatusKey);

        } catch (final curam.util.exception.RecordNotFoundException e) {
          hearingKey = null;
        }

        if (hearingKey != null) {
          // Find the appeal type
          appealCaseIDKey.caseID = appealCaseStatusDetails.appealCaseID;
          appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

          // Throw exception only if not a judicial review.
          if (!appealTypeDetails.appealTypeCode
            .equals(APPEALTYPE.JUDICIALREVIEW)) {

            informationalManager.addInformationalMsg(new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_FINAL_NO_HEARING_HELD),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
          }
        } else {

          // Get the appeal decision status
          hearingDecisionCaseKey.caseID =
            appealCaseStatusDetails.appealCaseID;
          try {

            hearingDecisionStatusDetails =
              hearingDecisionObj.readStatusByCase(hearingDecisionCaseKey);

            // Check if appeal decision has been submitted for approval
            if (hearingDecisionStatusDetails.decisionStatus
              .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

              informationalManager.addInformationalMsg(new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_DECISION_SUBMITTED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError);

            } else if (hearingDecisionStatusDetails.decisionStatus
              .equals(HEARINGDECISIONSTATUS.APPROVED)) {

              // Check if appeal decision has been approved
              informationalManager.addInformationalMsg(new AppException(
                BPOAPPEALEDCASE.ERR_APPEALEDCASE_XRV_DECISION_APPROVED),
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError);
            }

          } catch (final curam.util.exception.RecordNotFoundException e) {// HearingDecision
            // does not
            // need to
            // exist.
            // Equivalent to status of Not Started.
          }
        }
      }
    }

    // Report any validation errors found.
    informationalManager.failOperation();
  }

  // _________________________________________________________________________
  /**
   * Modifies the resolution details for an appealed case.
   * 
   * @param dtls
   * The appealed case resolution details to modify
   */
  @Override
  public void modifyResolution(final ModifyResolutionDetails dtls)
    throws AppException, InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey_eo =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.ModifyResolutionDetails modifyResolutionDetails =
      new curam.appeal.sl.entity.struct.ModifyResolutionDetails();
    AppealCaseID appealCaseID;

    // HearingDecision Object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final ModifyDecisionResolutionDetails modifyDecisionResolutionDetails =
      new ModifyDecisionResolutionDetails();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();
    IdAndResolutionDetails idAndResolutionDetails;

    // AppealDecision Object
    final AppealDecision appealDecisionObj =
      AppealDecisionFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    AppealResolutionDetails appealResolutionDetails;

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Check case security
    appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Read the appealed case ID for the security check
    appealRelationshipKey_eo.appealRelationshipID = dtls.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey_eo);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate data
    validateModifyResolution(dtls);

    // Set modify structs
    appealRelationshipKey_eo.appealRelationshipID =
      appealRelationshipKey.appealRelationshipID;
    modifyResolutionDetails.assign(dtls);

    // Modify the resolution
    appealRelationshipObj.modifyResolution(appealRelationshipKey_eo,
      modifyResolutionDetails);

    // Find the appeal case id
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey_eo);

    // Check if hearing decision record exists
    hearingDecisionCaseKey.caseID = appealCaseID.appealCaseID;
    boolean recordfound = true;

    try {

      idAndResolutionDetails =
        hearingDecisionObj.readIDAndResolutionByCase(hearingDecisionCaseKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {

      recordfound = false;
      idAndResolutionDetails = null;
    }

    // Only execute if a hearing decision record exists
    if (recordfound) {

      // Recalculate the overall appeal resolution
      appealCaseKey.caseID = appealCaseID.appealCaseID;
      appealResolutionDetails =
        appealDecisionObj.calculateResolution(appealCaseKey);

      // Set the key for the hearing decision
      hearingDecisionKey.hearingDecisionID =
        idAndResolutionDetails.hearingDecisionID;

      // Check if resolution code has changed
      if (!appealResolutionDetails.resolutionCode
        .equals(idAndResolutionDetails.resolutionCode)) {

        // Modify the resolution code and status
        modifyDecisionResolutionDetails.resolutionCode =
          appealResolutionDetails.resolutionCode;
        hearingDecisionStatusVersionDetails.decisionStatus =
          HEARINGDECISIONSTATUS.INPROGRESS;
        modifyDecisionResolutionDetails.versionNo = dtls.decisionVersionNo;

        hearingDecisionObj.modifyResolutionCode(hearingDecisionKey,
          modifyDecisionResolutionDetails);

      }
    } // BEGIN , CR00296215 , DK
    else {
      // Local variables used to create new decision
      final HearingDecisionDtls hearingDecisionDtls =
        new HearingDecisionDtls();

      // Calculate resolution based on appealed case resolutions
      appealCaseKey.caseID = appealCaseID.appealCaseID;
      appealResolutionDetails =
        appealDecisionObj.calculateResolution(appealCaseKey);

      // Insert a hearing decision
      hearingDecisionDtls.caseID = appealCaseID.appealCaseID;
      hearingDecisionDtls.decisionStatus = HEARINGDECISIONSTATUS.INPROGRESS;
      hearingDecisionDtls.decisionDate = Date.getCurrentDate();
      hearingDecisionDtls.hearingDecisionID = UniqueID.nextUniqueID();
      hearingDecisionDtls.resolutionCode =
        appealResolutionDetails.resolutionCode;
      hearingDecisionObj.insert(hearingDecisionDtls);
      hearingDecisionKey.hearingDecisionID =
        hearingDecisionDtls.hearingDecisionID;
    }
    // END , CR00296215 , DK
    // Report any validation errors found.
    informationalManager.failOperation();
  }

  // _________________________________________________________________________
  /**
   * Reads the resolution details for an appealed case where a case is being
   * directly appealed. That is where a decision from a prior appeal case is not
   * being appealed.
   * 
   * @param key
   * The appealRelationshipID of the appealed case being read.
   * @return The resolution details for the appealed case.
   */
  @Override
  public ReadResolutionDetails
    readResolution(final AppealRelationshipKey key) throws AppException,
      InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    ResolutionDetails resolutionDetails;

    // Return struct
    final ReadResolutionDetails readResolutionDetails =
      new ReadResolutionDetails();

    // Retrieve the resolution details
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    resolutionDetails =
      appealRelationshipObj.readResolution(appealRelationshipKey);

    // Assign the retrieved details to the return struct
    readResolutionDetails.resolutionAndCaseDetails.assign(resolutionDetails);

    return readResolutionDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the details required for modifying the resolution of an appealed case
   * where a case is being appealed directly. That is where a decision from a
   * prior appeal case is not being appealed.
   * 
   * @param key
   * The appealRelationshipID of the appealed case being read.
   * @return The details required for modifying the appealed case resolution.
   */
  @Override
  public ReadResolutionForModifyDetails readResolutionForModify(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    ResolutionForModifyDetails resolutionForModifyDetails;

    // HearingDecision Object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionVersionDetails hearingDecisionVersionDetails;

    // Return struct
    final ReadResolutionForModifyDetails readResolutionForModifyDetails =
      new ReadResolutionForModifyDetails();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Appeal Case entity variable
    AppealCaseID appealCaseID;

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve the resolution details
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    resolutionForModifyDetails =
      appealRelationshipObj.readResolutionForModify(appealRelationshipKey);

    // Assign the retrieved details to the return struct
    readResolutionForModifyDetails.resolutionForModifyDetails
      .assign(resolutionForModifyDetails);

    // Retrieve hearing decision version no for the appeal decision
    // As a hearing may not have been held, catch all record not found
    // exceptions
    hearingDecisionCaseKey.caseID = resolutionForModifyDetails.caseID;

    try {

      hearingDecisionVersionDetails =
        hearingDecisionObj.readVersionNoByCase(hearingDecisionCaseKey);

      readResolutionForModifyDetails.decisionVersionNo =
        hearingDecisionVersionDetails.versionNo;

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // No record was found because the hearing has not been held yet
      hearingDecisionVersionDetails =
        new curam.appeal.sl.entity.struct.HearingDecisionVersionDetails();
      readResolutionForModifyDetails.decisionVersionNo = 0;
    }

    return readResolutionForModifyDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the resolution details for an appealed case where a decision from a
   * prior appeal case is being appealed.
   * 
   * @param key
   * The appealRelationshipID of the appealed case being read.
   * @return The resolution details for the appealed case.
   */
  @Override
  public ReadResolutionPriorAppealDetails readResolutionPriorAppeal(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    ResolutionPriorAppealDetails resolutionPriorAppealDetails;

    // Return struct
    final ReadResolutionPriorAppealDetails readResolutionPriorAppealDetails =
      new ReadResolutionPriorAppealDetails();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Appeal Case entity variable
    AppealCaseID appealCaseID;

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve the resolution details
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    resolutionPriorAppealDetails =
      appealRelationshipObj.readResolutionPriorAppeal(appealRelationshipKey);

    // Assign the retrieved details to the return struct
    readResolutionPriorAppealDetails.resolutionCasePriorAppealDetails
      .assign(resolutionPriorAppealDetails);

    return readResolutionPriorAppealDetails;
  }

  // _________________________________________________________________________
  /**
   * Reads the details required for modifying the resolution of an appealed case
   * where a decision from a prior appeal case is being appealed.
   * 
   * @param key
   * The appealRelationshipID of the appealed case being read.
   * @return The details required for modifying the appealed case resolution.
   */
  @Override
  public ReadResolutionPriorAppealForModifyDetails
    readResolutionPriorAppealForModify(final AppealRelationshipKey key)
      throws AppException, InformationalException {

    // AppealRelationship Object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    ResolutionPriorAppealForModifyDetails resolutionPriorAppealForModifyDetails;

    // HearingDecision Object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionVersionDetails hearingDecisionVersionDetails;

    // Return struct
    final ReadResolutionPriorAppealForModifyDetails readResolutionPriorAppealForModifyDetails =
      new ReadResolutionPriorAppealForModifyDetails();

    // Appeal Security process variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Appeal Case entity variables
    AppealCaseID appealCaseID;

    // Read the appealed case ID for the security check
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve the resolution details
    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    resolutionPriorAppealForModifyDetails =
      appealRelationshipObj
        .readResolutionPriorAppealForModify(appealRelationshipKey);

    // Assign the retrieved details to the return struct
    readResolutionPriorAppealForModifyDetails.resolutionPriorAppealForModifyDetails
      .assign(resolutionPriorAppealForModifyDetails);

    // Retrieve hearing decision version no for the appeal decision
    // As a hearing may not have been held, catch all record not found
    // exceptions
    hearingDecisionCaseKey.caseID =
      resolutionPriorAppealForModifyDetails.caseID;
    try {

      hearingDecisionVersionDetails =
        hearingDecisionObj.readVersionNoByCase(hearingDecisionCaseKey);
      readResolutionPriorAppealForModifyDetails.decisionVersionNo =
        hearingDecisionVersionDetails.versionNo;

    } catch (final curam.util.exception.RecordNotFoundException e) {
      // No record was found because the hearing has not been held yet
      hearingDecisionVersionDetails =
        new curam.appeal.sl.entity.struct.HearingDecisionVersionDetails();
      readResolutionPriorAppealForModifyDetails.decisionVersionNo = 0;
    }

    return readResolutionPriorAppealForModifyDetails;

  }

  // ___________________________________________________________________________
  /**
   * Determine if the case that is already being appealed is on an active appeal
   * case.
   * 
   * @param caseAndPriorAppeal
   * Contains the caseID (the case being appealed) and the
   * priorAppealCaseID (the appeal case being appealed) combination.
   * 
   * @return True if the case is already being appealed, false if not.
   */
  @Override
  public CaseAlreadyAppealed isAlreadyAppealed(
    final CaseAndPriorAppeal caseAndPriorAppeal) throws AppException,
    InformationalException {

    // Appeal relationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealCaseIDList appealCaseIDList;

    // Search criteria object
    final CasePriorCaseStatus casePriorCaseStatus = new CasePriorCaseStatus();

    // Return object
    final CaseAlreadyAppealed caseAlreadyAppealed = new CaseAlreadyAppealed();

    casePriorCaseStatus.caseID = caseAndPriorAppeal.caseID;
    casePriorCaseStatus.priorCaseID = caseAndPriorAppeal.priorAppealCaseID;

    appealCaseIDList =
      appealRelationshipObj
        .searchActiveAppealByCaseAndPriorAppealCase(casePriorCaseStatus);

    if (appealCaseIDList.dtls.size() > 0) {
      caseAlreadyAppealed.appealed = true;
    } else {
      caseAlreadyAppealed.appealed = false;
    }

    return caseAlreadyAppealed;

  }

  // _________________________________________________________________________
  /**
   * Lists rejection reasons for an appealed case
   * 
   * @param key
   * Unique identifier for the appealed case
   * 
   * @return List of rejection reasons for the appealed case
   */
  @Override
  public AppealedCaseRejectionReasons listRejectionReasons(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Return variable
    final AppealedCaseRejectionReasons appealedCaseRejectionReasons =
      new AppealedCaseRejectionReasons();

    // Appealed case rejection entity
    final AppealedCaseRejection appealedCaseRejectionObj =
      AppealedCaseRejectionFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipIDKey appealRelationshipIDKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipIDKey();

    // Get the list of rejection reasons for this appealed case
    appealRelationshipIDKey.appealRelationshipID = key.appealRelationshipID;
    appealedCaseRejectionReasons.dtls =
      appealedCaseRejectionObj.searchByAppealedCase(appealRelationshipIDKey);

    return appealedCaseRejectionReasons;
  }

  // _________________________________________________________________________
  /**
   * Reads case ID of the appeal on the appealed case
   * 
   * @param key
   * Appealed case rejection ID
   * 
   * @return Appeal case ID
   */
  @Override
  public curam.appeal.sl.struct.AppealCaseID readAppealCaseID(
    final AppealRelationshipKey key) throws AppException,
    InformationalException {

    // Return variable
    final curam.appeal.sl.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.struct.AppealCaseID();

    // Appeal relationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey_entity =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    AppealCaseID appealCaseID_entity =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // Read the appeal case ID for this appealed case relationship
    appealRelationshipKey_entity.appealRelationshipID =
      key.appealRelationshipID;
    appealCaseID_entity =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey_entity);
    appealCaseID.caseID = appealCaseID_entity.appealCaseID;

    return appealCaseID;
  }

  // _________________________________________________________________________
  /**
   * Reads the appealed case rejection comment details for modification
   * 
   * @param key
   * Appealed case rejection ID
   * 
   * @return Appealed case rejection comment details
   */
  @Override
  public AppealedCaseRejectionComment readForModifyRejectionComment(
    final curam.appeal.sl.struct.AppealedCaseRejectionKey key)
    throws AppException, InformationalException {

    // Return variable
    final AppealedCaseRejectionComment appealedCaseRejectionComment =
      new AppealedCaseRejectionComment();

    // Appealed case rejection entity
    final AppealedCaseRejection appealedCaseRejectionObj =
      AppealedCaseRejectionFactory.newInstance();

    // Read the appealed case rejection comment details for modification
    appealedCaseRejectionComment.appealedCaseRejectionReasonText =
      appealedCaseRejectionObj.readReasonText(key.dtls);

    return appealedCaseRejectionComment;
  }

  // _________________________________________________________________________
  /**
   * Modifies the comment text of an appealed case rejection reason
   * 
   * @param details
   * Modified comment for the rejection reason
   */
  @Override
  public void modifyRejectionComment(
    final AppealedCaseRejectionComment details) throws AppException,
    InformationalException {

    // Appealed case rejection entity
    final AppealedCaseRejection appealedCaseRejectionObj =
      AppealedCaseRejectionFactory.newInstance();

    // Modify the appealed case rejection comment
    appealedCaseRejectionObj.modifyReasonText(
      details.appealedCaseRejectionKey,
      details.appealedCaseRejectionReasonText);
  }

  // BEGIN , CR00289874 , DK
  // _________________________________________________________________________
  /**
   * Add resolutions to items under appeal
   * 
   * @param details
   * of the appealed items
   */
  @Override
  public void addResolutionToAppealedItems(
    final curam.appeal.sl.struct.AddResolutionDetails details)
    throws AppException, InformationalException {

    // convert tab delimited string to list of strings
    final StringList appealedItemsList =
      StringUtil.tabText2StringList(details.appealedItemsList);

    ModifyResolutionDetails resolutionDetails;

    // loop through the list and set the resolution details
    for (int i = 0; i < appealedItemsList.size(); i++) {
      final long appealRelationshipID =
        Long.parseLong(appealedItemsList.item(i).trim());

      // set the resolution details
      resolutionDetails = new ModifyResolutionDetails();
      resolutionDetails.appealRelationshipID = appealRelationshipID;
      resolutionDetails.resolutionCode = details.resolutionCode;
      modifyResolution(resolutionDetails);
    }
  }

  // END , CR00289874 , DK

  // _________________________________________________________________________
  /**
   * Calculates the deadline date for an appealed case.
   * 
   * @param details
   * Contains the details needed to calculate the deadline date
   * 
   * @return The calculated deadline date of the appealed case
   */
  @Override
  public DeadlineDate calculateDeadlineDate1(
    final CalculateAppealDeadlineDateDetails1 details) throws AppException,
    InformationalException {

    // Variable for the return deadline date
    final DeadlineDate deadlineDate = new DeadlineDate();

    // Number of days in which an appeal must be decided and implemented
    int timeToDecideAndImplementHearing =
      EnvVars.ENV_APPEAL_TIMETODECIDEANDIMPLEMENTHEARING_DEFAULT;

    if (isCaseTypeAppealable(details.implCaseID)
      && !details.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      String constraintType = CuramConst.gkEmpty;

      if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        constraintType = CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGCASE;
      } else if (details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
        constraintType =
          CONSTRAINTTYPE.TIMETODECIDEANDIMPLEMENT_HEARINGREVIEW;
      }
      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.constraintType = constraintType;
      caseIDAppealCaseIDConstraintType.appealCaseID = details.appealCaseID;
      caseIDAppealCaseIDConstraintType.caseID = details.implCaseID;
      timeToDecideAndImplementHearing =
        AppealFactory.newInstance().getTimeConstraintLength(
          caseIDAppealCaseIDConstraintType).numberOfDays;

      if (timeToDecideAndImplementHearing == 0) {
        final CodeTableItemIdentifier constraintTypeCode =
          new CodeTableItemIdentifier(CONSTRAINTTYPE.TABLENAME,
            constraintType);
        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        ex.arg(constraintTypeCode);
        throw ex;
      }
    } else {

      // Standalone case with no associated product then use the default
      // environment variable
      final Integer timeToDecideAndImplementHearingInteger =
        curam.util.resources.Configuration
          .getIntProperty(EnvVars.ENV_APPEAL_TIMETODECIDEANDIMPLEMENTHEARING);

      // Use default value if the variable is not set
      if (timeToDecideAndImplementHearingInteger != null) {
        timeToDecideAndImplementHearing =
          timeToDecideAndImplementHearingInteger.intValue();
      }
    }

    // Calculate the deadline date for the appeal case based
    deadlineDate.date =
      details.receivedDate.addDays(timeToDecideAndImplementHearing);

    return deadlineDate;
  }

  /**
   * Helper method to check if a given case is appealable.
   * 
   * @param caseID Case identifier.
   * @return Boolean indicating if a case type is appealable.
   */
  private boolean isCaseTypeAppealable(final long caseID) {

    // Return object
    boolean isAppealable = false;

    // Read the case type
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(caseID);
    final CASETYPECODEEntry caseType = caseHeader.getCaseType();

    if (CASETYPECODEEntry.PRODUCTDELIVERY.equals(caseType)
      || CASETYPECODEEntry.ISSUE.equals(caseType)
      || CASETYPECODEEntry.INTEGRATEDCASE.equals(caseType)) {
      isAppealable = true;
    } else {
      final AppealableCaseType appealableCaseType =
        appealableCaseTypeMap.get(caseType);

      if (appealableCaseType != null) {
        isAppealable = true;
      }
    }

    return isAppealable;
  }
}
