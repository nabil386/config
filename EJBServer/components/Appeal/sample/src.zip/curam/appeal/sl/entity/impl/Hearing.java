/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.struct.AdjournedOrCompletedHearing;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDScheduled;
import curam.appeal.sl.entity.struct.HearingActualTimeDetails;
import curam.appeal.sl.entity.struct.HearingAttendeeTabDetailKey;
import curam.appeal.sl.entity.struct.HearingDtls;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingModifyDetails;
import curam.appeal.sl.entity.struct.HearingOfficialTabDetailHearingIDKey;
import curam.appeal.sl.entity.struct.HearingParticipantKey;
import curam.appeal.sl.entity.struct.HearingPostponeModifyDetails;
import curam.appeal.sl.entity.struct.HearingPostponeTimeStatusModifyDetails;
import curam.appeal.sl.entity.struct.HearingTimeStatusModifyDetails;
import curam.appeal.sl.entity.struct.PostponedHearingCaseKey;
import curam.appeal.sl.entity.struct.PostponedHearingKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALSUPPLIERTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.AddressFactory;
import curam.core.fact.LocationFactory;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.Address;
import curam.core.intf.Location;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.LocationKey;
import curam.core.struct.LocationNameStructRef;
import curam.core.struct.OtherAddressData;
import curam.message.BPOHEARING;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import java.util.Calendar;

/**
 * A hearing which is held on case, for example a Hearing Case Appeal.
 */
public abstract class Hearing extends curam.appeal.sl.entity.base.Hearing {

  protected static final int kOneDay = 1;

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Details
   * 
   * @param dtls Hearing details
   */
  @Override
  protected void validateInsert(final HearingDtls dtls) throws AppException,
    InformationalException {

    // Address object and manipulation variables
    final Address addressObj = AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    OtherAddressData otherAddressData = null;
    final AddressDtls addressDtls = new AddressDtls();

    // Location object and manipulation variables
    final Location locationObj = LocationFactory.newInstance();
    LocationNameStructRef locationNameStructRef = null;

    final LocationKey locationKey = new LocationKey();

    final InformationalManager informationalManager =
      new InformationalManager();

    // Hearing date and time must be specified
    if (dtls.scheduledDateTime.equals(DateTime.kZeroDateTime)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_HEARING_FV_DATETIME), GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Hearing type must be specified
    if (dtls.typeCode.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_HEARING_FV_TYPECODE), GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (dtls.typeCode.equals(HEARINGTYPE.HOME)) {

      if (dtls.addressID == 0) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_FV_ADDRESS), GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

      } else {
        addressKey.addressID = dtls.addressID;

        // read address data
        try {
          otherAddressData = addressObj.readAddressData(addressKey);
        } catch (final RecordNotFoundException e) {
          informationalManager.addInformationalMsg(new AppException(
            BPOHEARING.ERR_HEARING_FV_ADDRESS_INVALID),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);
        }

        if (otherAddressData != null) {
          addressDtls.addressID = dtls.addressID;
          addressObj.clone(addressDtls);
        }
      }
    } else if (dtls.typeCode.equals(HEARINGTYPE.LOCATION)
      && dtls.locationType.equals(HEARINGLOCATIONTYPE.INTERNAL)) {
      if (dtls.locationID == 0) {
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARING.ERR_HEARING_FV_LOCATION), GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);
      } else {
        locationKey.locationID = dtls.locationID;
        try {
          locationNameStructRef = locationObj.readLocationName(locationKey);
        } catch (final RecordNotFoundException e) {
          informationalManager.addInformationalMsg(new AppException(
            BPOHEARING.ERR_HEARING_FV_LOCATION_INVALID),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);
        }
        if (locationNameStructRef != null) {
          if (!locationNameStructRef.statusCode.equals(RECORDSTATUS.NORMAL)) {
            informationalManager.addInformationalMsg(new AppException(
              BPOHEARING.ERR_HEARING_FV_LOCATION_INVALID),
              GeneralConstants.kEmpty,
              InformationalElement.InformationalType.kError);
          }
        }
      }
    }

    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Details
   * 
   * @param details Hearing details
   */
  @Override
  protected void preinsert(final HearingDtls details) throws AppException,
    InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Performs the pre-read functionality for the readScheduledByCaseID method.
   * Ensures that the statusCode in the key is set to 'Scheduled' so that only
   * the scheduled hearing is retrieved.
   * 
   * @param key The caseID and statusCode to retrieve values for.
   */
  @Override
  protected void prereadScheduledByCaseID(final CaseAndStatusKey key)
    throws AppException, InformationalException {

    key.statusCode = HEARINGSTATUS.SCHEDULED;

  }

  // ___________________________________________________________________________
  /**
   * Performs pre-read validation when reading the latest postponed hearing.
   * 
   * @param key The caseID and statusCode to retrieve values for.
   */
  protected void prereadLatestPostponedByCaseIDAndStatus(
    final CaseAndStatusKey key) throws AppException, InformationalException {

    if (key.statusCode.equalsIgnoreCase(HEARINGSTATUS.SCHEDULED)
      || key.statusCode.equalsIgnoreCase(HEARINGSTATUS.COMPLETED)) {

      throw new AppException(BPOHEARING.ERR_READ_POSTPONE_IMPROPER_USAGE);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates details for modify
   * 
   * @param key Hearing identifier
   * @param details Hearing modify details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyCommentsAndTimes method.
    protected
    void premodifyCommentsAndTimes(final HearingKey key,
      final HearingModifyDetails details) throws AppException,
      InformationalException {

    validateModify(details);

  }

  // ___________________________________________________________________________
  /**
   * Performs pre modify postpone details validation
   * 
   * @param key Hearing unique identifier
   * @param details Hearing postpone details for modify
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyPostponeDetails method.
    protected
    void premodifyPostponeDetails(final HearingKey key,
      final HearingPostponeModifyDetails details) throws AppException,
      InformationalException {

    validateModifyPostpone(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates modify details
   * 
   * @param details Hearing details
   */
  @Override
  protected void validateModify(final HearingModifyDetails details)
    throws AppException, InformationalException {

    if (details.actualStartTime.after(details.actualEndTime)) {

      throw new AppException(BPOHEARING.ERR_HEARING_FV_STARTENDTIME);
    }

  }

  // ___________________________________________________________________________
  /**
   * Performs pre modify postpone details validation
   * 
   * @param details Hearing postpone details for modify
   */
  @Override
  protected void validateModifyPostpone(
    final HearingPostponeModifyDetails details) throws AppException,
    InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    if (details.postponeReasonCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_FV_HEARING_CONTINUE_REASON), GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }
    // date requested cannot be blank
    if (details.postponeDate.isZero()
      || DateTime.kZeroDateTime.equals(details.postponeDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARING.ERR_HEARING_FV_POSTPONE_DATETIME),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates that the modifyPostponeAndTimeAndStatus details are correct. This
   * includes ensuring that the actual start and end times for the postponement
   * are set to the scheduled date of the hearing.
   * 
   * @param key Hearing identifier
   * @param details Hearing postpone, actual time and hearing status details
   */
  @Override
  protected void
    premodifyPostponeAndTimeAndStatusDetails(final HearingKey key,
      final HearingPostponeTimeStatusModifyDetails details)
      throws AppException, InformationalException {

    // Variables for validating the details for the modify
    final HearingPostponeModifyDetails hearingPostponeModifyDetails =
      new HearingPostponeModifyDetails();
    final HearingActualTimeDetails hearingActualTimeDetails =
      new HearingActualTimeDetails();
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    hearingActualTimeDetails.actualEndTime = details.actualEndTime;
    hearingActualTimeDetails.actualStartTime = details.actualStartTime;
    hearingActualTimeDetails.scheduledDateTime =
      hearingObj.readScheduledDate(key).scheduledDateTime;

    // Format the actual times so that their dates are equal to the scheduled
    // date of the hearing.
    formatActualTimes(hearingActualTimeDetails);

    // Update the details object with the actual times formatted with the
    // date portion set correctly.
    details.actualEndTime = hearingActualTimeDetails.actualEndTime;
    details.actualStartTime = hearingActualTimeDetails.actualStartTime;

    // Validate the hearing postponement details.
    hearingPostponeModifyDetails.assign(details);
    validateModifyPostpone(hearingPostponeModifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the details for the modifyStatusAndTimeDetails method
   * are correct. This includes ensuring that the actual start and end times
   * have a date which is equal to the scheduled date of the hearing.
   * 
   * @param key Hearing identifier
   * @param details Details for modifying the hearing status and actual times
   */
  @Override
  protected void premodifyStatusAndTimeDetails(final HearingKey key,
    final HearingTimeStatusModifyDetails details) throws AppException,
    InformationalException {

    // Time formatting variables
    final HearingActualTimeDetails hearingActualTimeDetails =
      new HearingActualTimeDetails();
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    hearingActualTimeDetails.actualEndTime = details.actualEndTime;
    hearingActualTimeDetails.actualStartTime = details.actualStartTime;
    hearingActualTimeDetails.scheduledDateTime =
      hearingObj.readScheduledDate(key).scheduledDateTime;

    // Format the actual times so that their dates are equal to the scheduled
    // date of the hearing.
    formatActualTimes(hearingActualTimeDetails);

    // Update the details object with the actual times formatted with the
    // date portion set correctly.
    details.actualEndTime = hearingActualTimeDetails.actualEndTime;
    details.actualStartTime = hearingActualTimeDetails.actualStartTime;
  }

  // ___________________________________________________________________________
  /**
   * Formats the actual start and actual end date-time values such that the date
   * is equal to the scheduled date of the hearing.
   * 
   * @param details Hearing details
   */
  @Override
  public void formatActualTimes(final HearingActualTimeDetails details)
    throws AppException, InformationalException {

    // Actual time formatting variables
    final Calendar scheduledCalendar =
      details.scheduledDateTime.getCalendar();
    final Calendar startCalendar = details.actualStartTime.getCalendar();
    final Calendar endCalendar = details.actualEndTime.getCalendar();

    // Set the date for the actual start time to be the date of the scheduled
    // hearing
    startCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    startCalendar.set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    startCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    // BEGIN, CR00095666, RKi
    startCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    details.actualStartTime = new DateTime(startCalendar);
    TimeZoneUtility.getTimeZoneAdjustedDateTime(details.actualStartTime,
      TransactionInfo.getServerTimeZone());
    // END, CR00095666

    // Set the date for the actual end time to be the date of the scheduled
    // hearing
    endCalendar.set(Calendar.DAY_OF_MONTH,
      scheduledCalendar.get(Calendar.DAY_OF_MONTH));
    endCalendar.set(Calendar.MONTH, scheduledCalendar.get(Calendar.MONTH));
    endCalendar.set(Calendar.YEAR, scheduledCalendar.get(Calendar.YEAR));
    // BEGIN, CR00095666, RKi
    endCalendar.setTimeZone(TransactionInfo.getUserTimeZone());
    details.actualEndTime = new DateTime(endCalendar);
    TimeZoneUtility.getTimeZoneAdjustedDateTime(details.actualEndTime,
      TransactionInfo.getServerTimeZone());
    // END, CR00095666
  }

  // ___________________________________________________________________________
  /**
   * Sets end date for the read
   * 
   * @param key The caseID, status and date to retrieve value for.
   */
  @Override
  protected void prereadLatestPostponedByCaseIDStatusAndDate(
    final PostponedHearingKey key) throws AppException,
    InformationalException {

    Date nextDay = new Date(key.postponeDate);

    // add one day to the date specified
    nextDay = nextDay.addDays(kOneDay);

    key.nextDay = new DateTime(nextDay.getCalendar());

  }

  // ___________________________________________________________________________
  /**
   * This method ensures that the readLatestPostponedStatusByCase uses a zero
   * date-time value for the emptyPostponedDate.
   * 
   * @param key The caseID and emptyPostponedDate to read for,
   */
  @Override
  protected void prereadLatestPostponedStatusByCase(
    final PostponedHearingCaseKey key) throws AppException,
    InformationalException {

    key.emptyPostponedDate = curam.util.type.DateTime.kZeroDateTime;
  }

  // ___________________________________________________________________________
  /**
   * This method ensures that the readSummaryDetails reads user details only
   * for Hearing Official.
   * 
   * @param key The hearingID, user typeCode and record status to read for.
   */
  @Override
  protected void prereadSummaryDetails(final HearingParticipantKey key) {

    key.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

  }

  // ___________________________________________________________________________
  /**
   * This method ensures that only adjourned or completed hearings are read
   * 
   * @param key contains the Adjourned and Completed statuses.
   */

  @Override
  protected void prereadLatestAdjournOrCompletedHearingDateByCaseID(
    final AdjournedOrCompletedHearing key) {

    key.adjourned = HEARINGSTATUS.ADJOURNED;
    key.completed = HEARINGSTATUS.COMPLETED;

  }

  // ___________________________________________________________________________
  /**
   * This method ensures that only scheduled hearings are read
   * 
   * @param key contains the scheduled status.
   */

  @Override
  protected void prereadLatestScheduleNoticeDetailsByCase(
    final CaseIDScheduled key) {

    key.scheduled = HEARINGSTATUS.SCHEDULED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active records are considered as part of the search
   * 
   * @param key The search criteria
   */
  @Override
  protected void presearchActiveParticipantNameAddrByIDAndType(
    final HearingParticipantKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * This method ensures that the prereadDeskHearingSummaryDetails reads user
   * details only
   * for Hearing Official and with a Record Status of Normal
   * 
   * @param key The hearingID, user typeCode and record status to read for.
   */
  @Override
  protected void prereadDeskHearingSummaryDetails(
    final HearingParticipantKey key) {

    key.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyCommentsAndTimes
   */
  @Override
  public void
    modify(final HearingKey key, final HearingModifyDetails details)
      throws AppException, InformationalException {

    HearingFactory.newInstance().modifyCommentsAndTimes(key, details);
  }

  // BEGIN, CR00196348, MC
  @Override
  protected void prereadHearingAttendeeTabDetails(
    final HearingAttendeeTabDetailKey hearingAttendeeKey)
    throws AppException, InformationalException {

    hearingAttendeeKey.hearingOfficialRoleType =
      CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
    hearingAttendeeKey.hearingOfficialUserRoleType =
      CASEUSERROLETYPE.HEARINGOFFICIAL;
    hearingAttendeeKey.normalRecordStatus = RECORDSTATUS.NORMAL;
    hearingAttendeeKey.productProviderRoleType =
      CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER;
    hearingAttendeeKey.userServiceSupplierCode = APPEALSUPPLIERTYPE.USER;
  }

  @Override
  protected void presearchHearingOfficialTabDetail(
    final HearingOfficialTabDetailHearingIDKey hearingOfficialTabDetailKey)
    throws AppException, InformationalException {

    hearingOfficialTabDetailKey.normalRecordStatus = RECORDSTATUS.NORMAL;
  }
  // END, CR00196348

}
