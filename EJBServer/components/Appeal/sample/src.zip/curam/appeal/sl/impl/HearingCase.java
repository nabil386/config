/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealObjectFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.AppealObject;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Appellant;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.struct.ActiveAppealCaseKey;
import curam.appeal.sl.entity.struct.AppealCaseIDCaseIDRecordStatus;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealID;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStructList;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppealTypeStatusDetails;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.ModifyDeadlineDateDetails;
import curam.appeal.sl.entity.struct.OverallDecisionDetails;
import curam.appeal.sl.entity.struct.ReceiptNotice;
import curam.appeal.sl.entity.struct.RecordStatusDetails;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.AppealedCaseFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.AddAppealObjectsDetails;
import curam.appeal.sl.struct.AddAppealedCaseDetails;
import curam.appeal.sl.struct.AddCaseDetails;
import curam.appeal.sl.struct.AddNewAppealedCaseDetails;
import curam.appeal.sl.struct.AppealAndAppealedCaseDetails;
import curam.appeal.sl.struct.AppealCaseIDDeadlineDate;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealModifyDetails;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.AppealStatementDetails;
import curam.appeal.sl.struct.CalculateAppealDeadlineDateDetails1;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateHearingAndAppealObjectsDetails;
import curam.appeal.sl.struct.CreateHearingCaseDetails;
import curam.appeal.sl.struct.CreateNewHearingCaseDetails;
import curam.appeal.sl.struct.CreateParticipantDetails;
import curam.appeal.sl.struct.CreateReceiptNoticeDetails;
import curam.appeal.sl.struct.CreateReceiptNoticeDtls;
import curam.appeal.sl.struct.CreateUserRoleDetails;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.EnterAppellantDetails;
import curam.appeal.sl.struct.EnterAppellantKey;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingCaseHearingDetailsList;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingCaseModifyDetails;
import curam.appeal.sl.struct.HearingCaseModifyKey;
import curam.appeal.sl.struct.HearingCaseSummaryDetails;
import curam.appeal.sl.struct.HearingCaseSummaryDetailsAndCancelledInd;
import curam.appeal.sl.struct.HearingCaseSummaryKey;
import curam.appeal.sl.struct.NotifyOwnerDetails;
import curam.appeal.sl.struct.ReadAppealDetails;
import curam.appeal.sl.struct.ReadAppealUserDetails;
import curam.appeal.sl.struct.ReadAppellantDetails;
import curam.appeal.sl.struct.ValidateParticipantRoleDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.CaseStatus;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.intf.CaseTransactionLog;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseRelByCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseTypeDetails_eo;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.message.BPOAPPEAL;
import curam.message.BPOAPPEALEVENTS;
import curam.message.BPOHEARINGCASE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Hearing Case service
 * layer.
 * 
 */
public abstract class HearingCase extends curam.appeal.sl.base.HearingCase {

  // BEGIN, 31413, BR
  // This constant refers to the number of permitted active
  // related appeal cases.
  protected static final short kRelatedAppeals = 1;

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  public HearingCase() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, 31413, BR

  // ___________________________________________________________________________
  /**
   * Validates the details of a hearing case
   * 
   * @param details
   * Hearing case details
   */
  @Override
  public void
    validateCreateHearingCase(final CreateHearingCaseDetails details)
      throws AppException, InformationalException {

    // currentDate variable
    final Date currentDate = Date.getCurrentDate();

    // caseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseTypeDetails_eo caseTypeDetails;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // caseRelationship variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    CaseRelationshipDtlsList caseRelationshipDtlsList;
    final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
      new CaseRelByCaseIDStatusReasonTypeKey();

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

    caseHeaderKey.caseID = details.leadCaseID;
    caseTypeDetails = caseHeaderObj.readType(caseHeaderKey);

    if (caseTypeDetails.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {
      throw new AppException(
        curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_INTEGRATEDCASE);
    }

    // parentCaseID must not be blank
    if (details.leadCaseID == 0) {
      throw new AppException(curam.message.BPOAPPEAL.ERR_APPEAL_FV_CASEID);
    }

    final InformationalManager informationalManager =
      new InformationalManager();

    // received date must not be in the future
    if (details.dateReceived.after(currentDate)) {

      informationalManager.addInformationalMsg(new AppException(
        curam.message.BPOAPPEAL.ERR_APPEAL_FV_RECEIVEDDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Received date must not be empty
    if (details.dateReceived.isZero()) {

      throw new AppException(
        curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_RECEIVEDDATE_EMPTY);
    }

    caseHeaderObj.readRegDateAndReference(caseHeaderKey);

    // Received date must not be before the effective date.
    if (details.dateReceived.before(details.effectiveDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_XFV_DATERECEIVED_BEFORE_EFFECTIVEDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Effective date must not be after current date.
    if (details.effectiveDate.after(currentDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_EFFECTIVEDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    caseRelByCaseIDStatusReasonTypeKey.caseID = details.leadCaseID;
    caseRelByCaseIDStatusReasonTypeKey.reasonCode =
      curam.codetable.CASERELATIONSHIPREASONCODE.LINKEDCASES;

    // BEGIN, 31413, BR
    caseRelByCaseIDStatusReasonTypeKey.statusCode =
      curam.codetable.RECORDSTATUS.NORMAL;
    caseRelByCaseIDStatusReasonTypeKey.typeCode =
      curam.codetable.CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL;
    // END, 31413, BR

    caseRelationshipDtlsList =
      caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

    // BEGIN, 31413, BR
    // -- should be able to create a new hearing case whenever there are
    // -- no existing "OPEN" hearing cases.

    // Appeal objects
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // count number of related "OPEN" appeal cases
    int relatedAppealCaseCount = 0;

    for (int i = 0; i < caseRelationshipDtlsList.dtls.size(); i++) {

      // check status and type of appeal
      appealCaseIDKey.caseID =
        caseRelationshipDtlsList.dtls.item(i).relatedCaseID;
      final AppealTypeStatusDetails appealTypeStatusDetails =
        appealObj.readAppealTypeStatusByCase(appealCaseIDKey);

      if (!appealTypeStatusDetails.statusCode.equals(CASESTATUS.CLOSED)
        && !appealTypeStatusDetails.statusCode.equals(CASESTATUS.CANCELED)
        && appealTypeStatusDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        relatedAppealCaseCount++;
      }
    }

    if (relatedAppealCaseCount >= kRelatedAppeals) {

      throw new AppException(
        curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_ACTIVE);

    }
    // END, 31413, BR

    if (details.caseParticipantRoleID == 0) {

      throw new AppException(
        curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_CASEPARTICIPANT);
    }

    if (details.caseParticipantRoleID != 0) {

      caseParticipantRole_eoKey.caseParticipantRoleID =
        details.caseParticipantRoleID;

      caseIDAndParticipantRoleIDDetails =
        caseParticipantRole_eoObj
          .readCaseIDAndParticipantRoleIDDetails(caseParticipantRole_eoKey);

      caseHeaderKey.caseID = details.leadCaseID;
      readParticipantRoleIDDetails =
        caseHeaderObj.readParticipantRoleID(caseHeaderKey);

      if (caseIDAndParticipantRoleIDDetails.participantRoleID != readParticipantRoleIDDetails.concernRoleID) {
        throw new AppException(
          curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_APPELLANT);
      }

      if (caseTypeDetails.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.ASSESSMENTDELIVERY)) {

        caseRelByCaseIDStatusReasonTypeKey.caseID = details.leadCaseID;
        caseRelByCaseIDStatusReasonTypeKey.reasonCode =
          curam.codetable.CASERELATIONSHIPREASONCODE.LINKEDCASES;
        caseRelByCaseIDStatusReasonTypeKey.statusCode =
          curam.codetable.CASESTATUS.ACTIVE;
        caseRelByCaseIDStatusReasonTypeKey.typeCode =
          caseTypeDetails.caseTypeCode;

        caseRelationshipDtlsList =
          caseRelationshipObj
            .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

        for (int i = 0; i < caseRelationshipDtlsList.dtls.size(); i++) {

          if (caseRelationshipDtlsList.dtls.item(i).typeCode
            .equals(curam.codetable.CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL)) {

            throw new AppException(
              curam.message.BPOHEARINGCASE.ERR_HEARINGCASE_FV_ACTIVE);
          }

        }

      }

    }

    informationalManager.failOperation();

  }

  // _________________________________________________________________________
  /**
   * Creates a receipt notice
   * 
   * @param details
   * The details of the receipt notice
   * @deprecated
   */
  @Deprecated
  public void createReceiptNoticeDetails(
    final CreateReceiptNoticeDetails details) throws AppException,
    InformationalException {

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.communicationDate =
      curam.util.type.Date.getCurrentDate();
    communicationDetails.correspondentConcernRoleID =
      details.appellantParticipantRoleID;
    communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;

    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;

    // Add subject title to communication
    communicationDetails.subjectText =
      BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();

    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    // Set the key to read the concern role name
    concernRoleKey.concernRoleID = details.appellantParticipantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    proFormaCommDetails.caseID = details.appealCaseID;

    // BEGIN, CR00293187, CD
    // appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // set primary key of the data set to the appellant
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      details.appellantCaseParticipantRoleID;

    // Set document code and type
    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // ___________________________________________________________________________
  /**
   * This method returns the home page details of the specified hearing case
   * 
   * @param key
   * The identifier of the hearing case
   * 
   * @return The details of the hearing case home page
   */
  @Override
  public HearingCaseSummaryDetails
    readSummary(final HearingCaseSummaryKey key) throws AppException,
      InformationalException {

    // Return details
    final HearingCaseSummaryDetails hearingCaseSummaryDetails =
      new HearingCaseSummaryDetails();

    // Hearing object
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingCaseHearingDetailsList hearingCaseHearingDetailsList;
    final HearingCaseID hearingCaseID = new HearingCaseID();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    OverallDecisionDetails overallDecisionDetails;
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();

    // Appellant Details
    ReadAppellantDetails readAppellantDetails;
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Owner details
    ReadAppealUserDetails readAppealUserDetails;

    // Appeal Details
    ReadAppealDetails readAppealDetails;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = key.hearingCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read the appeal details
    appealCaseKey.caseID = key.hearingCaseID;

    readAppealDetails = appeal_boObj.readAppealDetails(appealCaseKey);

    // Read the appellant details
    readAppellantDetails = appeal_boObj.readAppellantDetails(appealCaseKey);

    // Read the owner details
    readAppealUserDetails = appeal_boObj.readOwnerDetails(appealCaseKey);

    // Get the list of hearings
    hearingCaseID.hearingCaseID.caseID = key.hearingCaseID;
    hearingCaseHearingDetailsList =
      hearing_boObj.listForHearingCase(hearingCaseID);

    // Get the decision details for the hearing case
    try {

      hearingDecisionCaseKey.caseID = key.hearingCaseID;
      overallDecisionDetails =
        hearingDecisionObj.readOverallDecisionByCase(hearingDecisionCaseKey);

      hearingCaseSummaryDetails.hearingCaseDetails.decisionResolution =
        overallDecisionDetails.resolutionCode;
      hearingCaseSummaryDetails.hearingCaseDetails.decisionStatus =
        overallDecisionDetails.decisionStatus;
      hearingCaseSummaryDetails.hearingCaseDetails.decisionVersionNo =
        overallDecisionDetails.versionNo;
      hearingCaseSummaryDetails.hearingCaseDetails.hearingDecisionID =
        overallDecisionDetails.hearingDecisionID;

    } catch (final RecordNotFoundException e) {

      hearingCaseSummaryDetails.hearingCaseDetails.decisionStatus =
        curam.codetable.HEARINGDECISIONSTATUS.NOTSTARTED;
      hearingCaseSummaryDetails.hearingCaseDetails.decisionResolution =
        curam.codetable.APPEALCASERESOLUTION.NOTDECIDED;
      hearingCaseSummaryDetails.hearingCaseDetails.attachmentID = 0;
    }

    // Assign the details to the return struct
    hearingCaseSummaryDetails.hearingCaseHearingDetailsList =
      hearingCaseHearingDetailsList;

    // Assign the details to the return object
    hearingCaseSummaryDetails.hearingCaseDetails
      .assign(readAppealDetails.appealReadSummaryDetails);

    hearingCaseSummaryDetails.hearingCaseDetails.appellantParticipantRoleID =
      readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;

    hearingCaseSummaryDetails.hearingCaseDetails.appellantName =
      readAppellantDetails.concernRoleNameDetails.concernRoleName;

    hearingCaseSummaryDetails.hearingCaseDetails.ownerFullName =
      readAppealUserDetails.userFullname.fullname;
    hearingCaseSummaryDetails.hearingCaseDetails.ownerUserName =
      readAppealUserDetails.userName;

    // BEGIN, CR00021086, RKi
    // To determine if the hearing case has single or multiple appellants.
    // Required structs
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealID appealID = new AppealID();
    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();
    Count count = new Count();
    final Appellant appellantObj = AppellantFactory.newInstance();

    appealCaseIDKey.caseID = key.hearingCaseID;

    // retrieve appealID
    appealID = appealObj.readAppealIDByCase(appealCaseIDKey);
    appealIDAndDateDetails.appealID = appealID.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    // retrieves the count of appellants existing on a hearing case
    count =
      appellantObj.countActiveAppellantsByAppealID(appealIDAndDateDetails);
    if (count.numberOfRecords > 1) {
      hearingCaseSummaryDetails.multipleAppellant.multipleAppellants = true;
    }
    // END, CR00021086

    // BEGIN, CR00050118, RKi

    final CaseTransactionLog caseTransactionLog =
      curam.core.sl.fact.CaseTransactionLogFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();

    // ReadTransactionLogDetailsList readTransactionLogDetailsList = new
    // ReadTransactionLogDetailsList();
    caseIDKey.caseID = key.hearingCaseID;
    hearingCaseSummaryDetails.transactionDtlsList.transactionDetailsList =
      caseTransactionLog.readAllTransactions(caseIDKey);

    // END, CR00050118
    // Return the details
    return hearingCaseSummaryDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns the home page details of the specified hearing case
   * 
   * @param key
   * The identifier of the hearing case
   * 
   * @return The details of the hearing case home page
   */
  @Override
  public HearingCaseSummaryDetailsAndCancelledInd readSummaryAndCancelledInd(
    final HearingCaseSummaryKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingCaseSummaryDetailsAndCancelledInd hearingCaseSummaryDetailsAndCancelledInd =
      new HearingCaseSummaryDetailsAndCancelledInd();

    hearingCaseSummaryDetailsAndCancelledInd.assign(readSummary(key));

    // Return the details
    return hearingCaseSummaryDetailsAndCancelledInd;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a hearing case
   * 
   * @param details
   * The details of the hearing case being modified
   */
  @Override
  public void modifyHearingCase(final AppealModifyDetails details)
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // HearingAppealTypeCode variable
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Update the hearing case
    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARING;
    appeal_boObj.modify(details, hearingAppealTypeCode);
  }

  // ___________________________________________________________________________
  /**
   * Method to read hearing case details for modification
   * 
   * @param key
   * The key of the hearing case being modified
   * 
   * @return The hearing case details
   */
  @Override
  public HearingCaseModifyDetails
    readForModify(final HearingCaseModifyKey key) throws AppException,
      InformationalException {

    // Return details
    final HearingCaseModifyDetails hearingCaseModifyDetails =
      new HearingCaseModifyDetails();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Read the hearing case
    appealCaseKey.caseID = key.hearingCaseID;
    hearingCaseModifyDetails.appealModifyDetails =
      appeal_boObj.read(appealCaseKey);

    return hearingCaseModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Adds a statement to a hearing case
   * 
   * @param details
   * The details of the statement being added
   */
  @Override
  public InformationalMsgDtlsList addStatement(
    final AppealStatementDetails details) throws AppException,
    InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Update the hearing case
    final InformationalMsgDtlsList informationalMsgDtlsList =
      appeal_boObj.addStatement(details);

    return informationalMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list the hearings for a hearing case
   * 
   * @param key
   * The hearing case ID
   * 
   * @return the list of hearing details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public HearingCaseHearingDetailsList listHearings(
    final curam.appeal.sl.entity.struct.HearingCaseID key)
    throws AppException, InformationalException {

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingCaseID hearingCaseID = new HearingCaseID();

    // Return structure
    final HearingCaseHearingDetailsList hearingCaseHearingDetailsList =
      new HearingCaseHearingDetailsList();

    // Retrieve list
    hearingCaseID.hearingCaseID.caseID = key.caseID;
    hearingCaseHearingDetailsList.HearingCaseHearingDetails
      .addAll(hearing_boObj.listForHearingCase(hearingCaseID).HearingCaseHearingDetails);

    return hearingCaseHearingDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method notifies the case owner of the specified case that a hearing
   * case has been created.
   * 
   * @param details
   * The caseID to send notification to case owner
   */
  @Override
  public void notifyOwner(final NotifyOwnerDetails details)
    throws AppException, InformationalException {

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Notification variables
    final Notification notificationObj = NotificationFactory.newInstance();

    // StandardManualTask details
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Case User Role objects
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    AppException subjectInfo;

    subjectInfo =
      new AppException(
        curam.message.BPOHEARINGCASE.INF_HEARINGCASE_FV_CASEUNDERAPPEAL);

    // read maintainCase
    CaseReferenceAndStatusDetails caseReferenceAndStatusDtls =
      new CaseReferenceAndStatusDetails();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = details.caseID;
    caseReferenceAndStatusDtls =
      caseHeaderObj.readCaseReferenceAndStatusByCaseID(caseSearchKey);

    subjectInfo.arg(caseReferenceAndStatusDtls.caseReference);

    if (details.priorAppealCaseID != 0) {

      caseHeaderKey.caseID = details.priorAppealCaseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // Owner of hearing case
      orgObjectLinkKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // A notification is sent to the case owner of the prior appeal case when
      // a decision from a prior appeal case is being appealed.
      // A check to ensure the current user is not the user to whom the
      // notification is being sent is carried out first.
      final SystemUser systemUser = SystemUserFactory.newInstance();

      if (!caseOwnerDetails.userName
        .equals(systemUser.getUserDetails().userName)) {

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          details.priorAppealCaseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          GeneralAppealConstants.kSpace;
        standardManualTaskDtls.dtls.taskDtls.subject =
          subjectInfo.getMessage();

        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userFullName;
        standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
          caseHeaderDtls.concernRoleID;
        // BEGIN, CR00053295, RKi
        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
        // END, CR00053295
      }

    }

    caseHeaderKey.caseID = details.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // A notification is sent to the case owner of the implementation case being
    // appealed.
    final SystemUser systemUser = SystemUserFactory.newInstance();

    if (!caseOwnerDetails.userName
      .equals(systemUser.getUserDetails().userName)) {

      standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject = subjectInfo.getMessage();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseHeaderDtls.concernRoleID;

      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to create a hearing case
   * 
   * @param details
   * The details of the hearing case being created
   * 
   * @return Contains the ID of the hearing case created
   */
  @Override
  public HearingCaseSummaryKey create(
    final CreateNewHearingCaseDetails details) throws AppException,
    InformationalException {

    // CaseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    final Appeal appealObj = AppealFactory.newInstance();

    final AppealDtls appealDtls = new AppealDtls();

    // Case Status object
    final CaseStatus caseStatusObj = CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    // user roles
    final CreateUserRoleDetails createUserRoleDetails =
      new CreateUserRoleDetails();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // variable to create appellant participant record
    final CreateParticipantDetails createParticipantDetails =
      new CreateParticipantDetails();

    // Add hearing case struct
    final AddAppealedCaseDetails addAppealedCaseDetails =
      new AddAppealedCaseDetails();

    // return struct
    final HearingCaseSummaryKey hearingCaseSummaryKey =
      new HearingCaseSummaryKey();

    // Appeal Security variables
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for creating an Hearing Case
    validateSecurityKey.caseID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kCreateSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateCreate(details);

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // create the case header
    // BEGIN, CR00052221, RKi
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
    caseHeaderDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseHeaderDtls.caseTypeCode = curam.codetable.CASETYPECODE.APPEAL;
    caseHeaderDtls.concernRoleID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.participantRoleID;
    caseHeaderDtls.caseReference =
      CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();
    caseHeaderDtls.startDate = currentDate;
    caseHeaderDtls.expectedEndDate = Date.kZeroDate;
    caseHeaderDtls.endDate = Date.kZeroDate;
    caseHeaderDtls.effectiveDate = Date.kZeroDate;
    caseHeaderDtls.registrationDate = currentDate;
    caseHeaderDtls.priorityCode = curam.codetable.CASEPRIORITY.DEFAULTCODE;
    caseHeaderDtls.classificationCode =
      curam.codetable.CASECLASSIFICATION.DEFAULTCODE;
    caseHeaderDtls.appealIndicator = false;
    // BEGIN ,CR00284371 , DK
    final boolean isIntegratedCaseInd =
      caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode
        .equals(CASETYPECODE.INTEGRATEDCASE);

    if (isIntegratedCaseInd) {
      caseHeaderDtls.integratedCaseID =
        details.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
    } else {
      caseHeaderDtls.integratedCaseID =
        details.appealCaseCreateDetails.appealCaseCreateDetails.parentCaseID;
    }
    // END , CR00284371 , DK
    caseHeaderDtls.receivedDate =
      details.appealCaseCreateDetails.addAppealedCaseInputDetails.dateReceived;

    // BEGIN, CR00071911, RKi
    // the owner ID is update when the CaseUserRole is created
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    // END, CR00071911
    caseHeaderObj.insert(caseHeaderDtls);

    // insert the appeal object
    appealDtls.caseID = caseHeaderDtls.caseID;
    appealDtls.appealTypeCode = curam.codetable.APPEALTYPE.HEARING;
    appealDtls.difficultyCode =
      details.appealCaseCreateDetails.difficultyCode;
    appealDtls.comments =
      details.appealCaseCreateDetails.addAppealedCaseInputDetails.comments;
    appealObj.insert(appealDtls);

    // create the user roles
    createUserRoleDetails.appealCaseID = caseHeaderDtls.caseID;
    appeal_boObj.createUserRoles(createUserRoleDetails);

    createParticipantDetails.participantRoleID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.participantRoleID;
    createParticipantDetails.appealCaseID = caseHeaderDtls.caseID;

    if (details.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {
      // Create the respondent for the hearing case
      appeal_boObj.createRespondentParticipant(createParticipantDetails);
    } else {
      // Create the appellant for the hearing case
      // BEGIN, CR00021086, RKi
      CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey =
        appeal_boObj.createAppellantParticipant(createParticipantDetails);

      // add the appellant to appellant entity
      final Appellant appellantObj = AppellantFactory.newInstance();
      final AppellantDtls appellantDtls = new AppellantDtls();

      appellantDtls.appealID = appealDtls.appealID;
      appellantDtls.caseParticipantRoleID =
        caseParticipantRoleKey.caseParticipantRoleID;
      appellantDtls.appellantTypeCode =
        details.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode;
      appellantDtls.emergencyCode =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.emergencyCode;
      appellantDtls.comments =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.comments;
      appellantDtls.receivedDate =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.dateReceived;
      appellantDtls.fromDate = Date.getCurrentDate();
      appellantDtls.reasonCode =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.reasonCode;
      appellantDtls.receiptMethod =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.receiptMethod;
      appellantDtls.receiptNoticeIndicator =
        details.appealCaseCreateDetails.addAppealedCaseInputDetails.receiptNoticeIndicator;
      appellantObj.insert(appellantDtls);
      // END, CR00021086
    }

    // insert case status details
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.endDate = curam.util.type.Date.kZeroDate;
    caseStatusDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseStatusDtls.startDate = currentDate;
    caseStatusObj.insert(caseStatusDtls);

    // Add the case to the newly created hearing case
    addAppealedCaseDetails.appealCaseID = appealDtls.caseID;
    addAppealedCaseDetails.implCaseID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
    addAppealedCaseDetails.priorAppealCaseID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.priorAppealCaseID;
    addAppealedCaseDetails.addAppealedCaseInputDetails =
      details.appealCaseCreateDetails.addAppealedCaseInputDetails;
    addAppealedCase(addAppealedCaseDetails);

    hearingCaseSummaryKey.hearingCaseID = caseHeaderDtls.caseID;

    // BEGIN, CR00295153, DG
    // calculate initial appeal deadline date
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();

    calculateAppealDeadlineDateDetails1.appealTypeCode = APPEALTYPE.HEARING;
    calculateAppealDeadlineDateDetails1.implCaseID =
      details.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
    calculateAppealDeadlineDateDetails1.receivedDate =
      details.appealCaseCreateDetails.addAppealedCaseInputDetails.dateReceived;
    calculateAppealDeadlineDateDetails1.appealCaseID = caseHeaderDtls.caseID;

    // Update deadline date on case
    // Note: this must be done after the appeal case and appeal relationship
    // have been created. Otherwise the time constraints will not be retrieved
    // correctly.
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final ModifyDeadlineDateDetails modifyDeadlineDateDetails =
      new ModifyDeadlineDateDetails();

    appealCaseIDKey.caseID = appealDtls.caseID;

    // BEGIN, CR00323206, KRK
    modifyDeadlineDateDetails.deadlineDate =
      AppealedCaseFactory.newInstance().calculateDeadlineDate1(
        calculateAppealDeadlineDateDetails1).date;
    // END, CR00323206
    modifyDeadlineDateDetails.versionNo =
      appealObj.readDetailsForModify(appealCaseIDKey).versionNo;
    appealObj.modifyDeadlineDate(appealCaseIDKey, modifyDeadlineDateDetails);
    // END, CR00295153

    // BEGIN, CR00050710, RKi
    if (appealDtls.caseID != 0) {
      // BEGIN, CR00443340, DG
      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();
      final InsertTransactionLogDetails insertTransactionLogDetails1 =
        new InsertTransactionLogDetails();

      LocalisableString description =
        new LocalisableString(BPOAPPEALEVENTS.APPEALCREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEAL_CREATED, description,
        details.appealCaseCreateDetails.appealCaseCreateDetails.caseID,
        details.appealCaseCreateDetails.appealCaseCreateDetails.caseID);

      description = new LocalisableString(BPOAPPEALEVENTS.APPEALEDTOHEARING);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEALED_TO_HEARING_CASE, description,
        details.appealCaseCreateDetails.appealCaseCreateDetails.caseID,
        details.appealCaseCreateDetails.appealCaseCreateDetails.caseID);

      description = new LocalisableString(BPOAPPEALEVENTS.HEARINGCASECREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.HEARING_CASE_CREATED, description,
        appealDtls.caseID, appealDtls.caseID);
      // END, CR00443340
    }
    // END, CR00050710

    return hearingCaseSummaryKey;

  }

  // ___________________________________________________________________________
  /**
   * Method to add a hearing case to an appeal
   * 
   * @param details
   * The details of the hearing case being added
   */
  @Override
  public void addAppealedCase(final AddAppealedCaseDetails details)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // object to add an appeal case
    final AddNewAppealedCaseDetails addNewAppealedCaseDetails =
      new AddNewAppealedCaseDetails();

    // set up the struct and add the case
    addNewAppealedCaseDetails.implCaseID = details.implCaseID;
    addNewAppealedCaseDetails.appealCaseID = details.appealCaseID;
    addNewAppealedCaseDetails.appealTypeCode = APPEALTYPE.HEARING;
    addNewAppealedCaseDetails.priorAppealCaseID = details.priorAppealCaseID;
    addNewAppealedCaseDetails.addAppealedCaseInputDetails =
      details.addAppealedCaseInputDetails;

    // relationship key to get the appealRelationshipID
    final AppealRelationshipKey appealRelationshipKey =
      appealObj.addAppealedCase(addNewAppealedCaseDetails);

    // notify the owner

    final NotifyOwnerDetails notifyOwnerDetails = new NotifyOwnerDetails();

    notifyOwnerDetails.caseID = details.implCaseID;
    notifyOwnerDetails.appealCaseID = details.appealCaseID;
    notifyOwnerDetails.priorAppealCaseID = details.priorAppealCaseID;

    notifyOwner(notifyOwnerDetails);

    if (details.addAppealedCaseInputDetails.receiptNoticeIndicator) {

      // appeal case details object
      final AppealAndAppealedCaseDetails appealAndAppealedCaseDetails =
        new AppealAndAppealedCaseDetails();

      // set object ID properties
      appealAndAppealedCaseDetails.appealCaseID = details.appealCaseID;
      appealAndAppealedCaseDetails.appealRelationshipID =
        appealRelationshipKey.appealRelationshipID;

      createReceiptNotice(appealAndAppealedCaseDetails);

      final AppealCaseIDCaseIDRecordStatus appealCaseIDCaseIDRecordStatus =
        new AppealCaseIDCaseIDRecordStatus();

      appealCaseIDCaseIDRecordStatus.appealCaseID = details.appealCaseID;
      appealCaseIDCaseIDRecordStatus.caseID = details.implCaseID;
      appealCaseIDCaseIDRecordStatus.recordStatus = RECORDSTATUS.NORMAL;

      final ReceiptNotice receiptNotice = new ReceiptNotice();

      receiptNotice.receiptNoticeIndicator = true;

      appealRelationshipObj.modifyReceiptNoticeIndicator(
        appealCaseIDCaseIDRecordStatus, receiptNotice);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates adding an appealed case to a hearing case Currently does no
   * validation.
   * 
   * @param details
   * The appeal case details entered
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void
    validateAddAppealedCase(final AddAppealedCaseDetails details)
      throws AppException, InformationalException {// no validation

  }

  // ___________________________________________________________________________
  /**
   * Takes in appellant details
   * 
   * @param key
   * Contains implCaseID and caseParticipantRole
   * 
   * @return The participantRoleID and indicator of any active appeals
   */
  @Override
  public EnterAppellantDetails enterAppellantDetails(
    final EnterAppellantKey key) throws AppException, InformationalException {

    // CaseParticipantRole objects
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    final Appeal appealObj = AppealFactory.newInstance();

    final ActiveAppealCaseKey activeAppealCaseKey = new ActiveAppealCaseKey();

    // object to pass to the validate participant role method
    final ValidateParticipantRoleDetails validateParticipantRoleDetails =
      new ValidateParticipantRoleDetails();

    // return structure
    final EnterAppellantDetails enterAppellantDetails =
      new EnterAppellantDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an Hearing Case
    validateSecurityKey.caseID = key.implCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kCreateSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // get the participantRoleID
    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;

    caseIDAndParticipantRoleIDDetails =
      caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);

    // validate the participant role belongs to the case
    validateParticipantRoleDetails.caseID =
      caseIDAndParticipantRoleIDDetails.caseID;
    validateParticipantRoleDetails.participantRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    validateParticipantRoleDetails.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;
    appeal_boObj.validateParticipantRole(validateParticipantRoleDetails);

    // count the active appeals
    activeAppealCaseKey.participantRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    activeAppealCaseKey.appealTypeCode = curam.codetable.APPEALTYPE.HEARING;

    activeAppealCaseKey.caseParticipantRoleTypeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    final curam.core.struct.Count count =
      appealObj.countActiveByTypeAndParticipantAndRole(activeAppealCaseKey);

    if (count.numberOfRecords > 0) {
      enterAppellantDetails.activeAppealsIndicator = true;
    }

    enterAppellantDetails.participantRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;

    return enterAppellantDetails;

  }

  // ___________________________________________________________________________
  /**
   * Validates if it is valid to appeal the selected case to the hearing case
   * level.
   * 
   * @param key
   * Contains hearing case id
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void validateAppealedCaseSelection(final HearingCaseID key)
    throws AppException, InformationalException {// no validation

  }

  // ___________________________________________________________________________
  /**
   * Method to validate creating a hearing case
   * 
   * @param details
   * The details of the hearing case being created
   */
  @Override
  protected void validateCreate(final CreateNewHearingCaseDetails details)
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    appealObj
      .validateCreateAppealCase(details.appealCaseCreateDetails.appealCaseCreateDetails);

  }

  // ___________________________________________________________________________
  /**
   * Add a hearing case to an appeal
   * 
   * @param details
   * The details of the hearing case being added
   */
  @Override
  public void addCase(final AddCaseDetails details) throws AppException,
    InformationalException {

    // appeal objects
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // appeal case key
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // variables used to call other validations
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();
    final AppealCaseIDDeadlineDate appealCaseIDDeadlineDate =
      new AppealCaseIDDeadlineDate();

    // today's date
    final Date currentDate = Date.getCurrentDate();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining a Hearing Case
    validateSecurityKey.caseID = details.addAppealedCaseDetails.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // add the appealed case
    addAppealedCase(details.addAppealedCaseDetails);

    // calculate initial appeal deadline date
    calculateAppealDeadlineDateDetails1.implCaseID =
      details.addAppealedCaseDetails.implCaseID;
    calculateAppealDeadlineDateDetails1.receivedDate = currentDate;
    calculateAppealDeadlineDateDetails1.appealTypeCode =
      curam.codetable.APPEALTYPE.HEARING;
    calculateAppealDeadlineDateDetails1.appealCaseID =
      details.addAppealedCaseDetails.appealCaseID;
    final DeadlineDate newDeadlineDate =
      AppealedCaseFactory.newInstance().calculateDeadlineDate1(
        calculateAppealDeadlineDateDetails1);

    // read the appeal case owner and deadline date
    appealCaseIDKey.caseID = details.addAppealedCaseDetails.appealCaseID;

    // validate the new deadline date for the appeal
    appealCaseIDDeadlineDate.appealCaseID =
      details.addAppealedCaseDetails.appealCaseID;
    appealCaseIDDeadlineDate.deadlineDate = newDeadlineDate.date;
    appeal_boObj.validateAppealDeadline(appealCaseIDDeadlineDate);

  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal for all appealed cases for an appeal where no receipt notice has
   * been previously created.
   * 
   * @param details
   * The appeal case for which to create the receipt notice
   */
  @Override
  public void createReceiptNotice(final CreateReceiptNoticeDtls details)
    throws AppException, InformationalException {

    // caseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // get the appellant for the appeal case
    caseParticipantRoleCaseAndTypeKey.caseID = details.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // get the active participant for the case
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // BEGIN, CR00078516, RKi
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {
      // END, CR00078516
      communicationDetails.caseID = details.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;
      communicationDetails.subjectText =
        curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      concernRoleObj.readConcernRoleName(concernRoleKey);
      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

      // BEGIN, CR00293187, CD
      // appeal pro forma document objects
      final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        AppealProFormaDocumentGenerationFactory.newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;

      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal for a single appealed case for an appeal.
   * 
   * @param details
   * The details to create the notice
   */
  @Override
  public void createReceiptNotice(final AppealAndAppealedCaseDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    // Get the appellant for the appeal case
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    caseParticipantRoleCaseAndTypeKey.caseID = details.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // Get the active participant for the case
    final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // BEGIN, CR00078516, RKi
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {
      // END, CR00078516
      // Communication objects
      final CommunicationDetails communicationDetails =
        new CommunicationDetails();
      final ProFormaCommDetails1 proFormaCommDetails =
        new ProFormaCommDetails1();
      final Communication communicationObj =
        CommunicationFactory.newInstance();
      // Concern role details
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // ConcernRoleNameDetails concernRoleNameDetails;

      communicationDetails.caseID = details.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;
      communicationDetails.subjectText =
        curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication for the appeal case
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      concernRoleObj.readConcernRoleName(concernRoleKey);
      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

      // BEGIN, CR00293187, CD
      // Appeal pro forma document objects
      final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        AppealProFormaDocumentGenerationFactory.newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set attributes
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        details.appealRelationshipID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.REQUEST_SINGLE_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }
  }

  // BEGIN, CR00021348, RKi
  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal.
   * 
   * @param key
   * case participant role key
   */
  @Override
  public void
    createReceiptNoticeForAppellant(final CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Get appeal case ID and participant role ID
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails =
      new CaseIDAndParticipantRoleIDDetails();

    caseIDAndParticipantRoleIDDetails =
      caseParticipantRoleObj.readCaseIDAndParticipantRoleIDDetails(key);

    concernRoleKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    communicationDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    communicationDetails.correspondentConcernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;
    communicationDetails.subjectText =
      BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    // BEGIN, CR CR00069029, NSP
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // create person object
    final Person personObj = PersonFactory.newInstance();
    final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
    // BEGIN, CR00236272, AK
    SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

    searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Search whether appellant is associated with the case or not
    searchCaseDetails = personObj.searchCase1(searchCaseKey_fo);
    // END, CR00236272

    if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() >= 1) {

      // if appellant is associated with the case, then acknowledge an appeal
      // request with continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;

      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
    } else {

      // if appellant is not associated with the case, then acknowledge an
      // appeal request with no continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASEWITHOUTCONTINUEBENEFITS;

      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASEWITHOUTCONTINUEBENEFITS;
    }
    // END, CR CR00069029

    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

    // BEGIN, CR00293187, CD
    // appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();

    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    generateDocumentDetails.dtls.dataSetPrimaryKey =
      key.caseParticipantRoleID;

    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // ___________________________________________________________________________
  /**
   * Create a hearing case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "AOT1,1001|AOT2,2001|AOT2,2002" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   * 
   * @param key
   * details of the hearing review case.
   * @return The hearing case identifier.
   */
  @Override
  public HearingCaseSummaryKey createWithAppealObjects(
    final CreateHearingAndAppealObjectsDetails details) throws AppException,
    InformationalException {

    // Create the hearing case
    final HearingCaseSummaryKey hearingCaseSummaryKey = create(details.dtls);

    //
    // Check for any approved appeal objects on a previous appeal case.
    //
    final AppealObject appealObectObj = AppealObjectFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    if (details.dtls.appealCaseCreateDetails.appealCaseCreateDetails.priorAppealCaseID != 0
      && details.appealObjectsDelimitedList.isEmpty()) {

      // Get all the appeal relationship records for the previous case
      appealCaseID.appealCaseID =
        details.dtls.appealCaseCreateDetails.appealCaseCreateDetails.priorAppealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {

        if (o.statusCode.equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {
          // Retrieve the objects for this relationship
          final AppealObjectKeyStruct appealObjectKeyStruct =
            new AppealObjectKeyStruct();

          appealObjectKeyStruct.appealRelationshipID = o.appealRelationshipID;
          final AppealObjectDtlsStructList appealObjectDtlsStructList =
            appealObectObj
              .searchByAppealRelationshipID(appealObjectKeyStruct);

          if (!appealObjectDtlsStructList.dtls.isEmpty()) {
            if (details.appealObjectsDelimitedList.length() != 0) {
              details.appealObjectsDelimitedList +=
                CuramConst.gkPipeDelimiterChar;
            }
            details.appealObjectsDelimitedList +=
              appealObjectDtlsStructList.dtls.get(0).objectID
                + CuramConst.gkComma
                + appealObjectDtlsStructList.dtls.get(0).objectType;

          }

        }
      }
    }

    // If appeal objects have been supplied then add them
    if (details.appealObjectsDelimitedList.length() != 0) {
      // Cancel the Appeal Relationship record created for the related case.
      // This has to be canceled as we are appealing a list of objects
      // on the case instead of the case itself.
      final RecordStatusDetails recordStatusDetails =
        new RecordStatusDetails();

      appealCaseID.appealCaseID = hearingCaseSummaryKey.hearingCaseID;
      recordStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
      final AppealRelationShipDetailsList appealRelationshipList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationshipList.dtls) {
        appealRelationshipKey.appealRelationshipID = o.appealRelationshipID;
        recordStatusDetails.versionNo =
          appealRelationshipObj
            .readForModifyAppealedCase(appealRelationshipKey).versionNo;
        appealRelationshipObj.modifyRecordStatus(appealRelationshipKey,
          recordStatusDetails);
      }

      // Add the objects to the case
      final AddAppealObjectsDetails addAppealObjectsDetails =
        new AddAppealObjectsDetails();

      addAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      addAppealObjectsDetails.appealCaseID =
        hearingCaseSummaryKey.hearingCaseID;
      addAppealObjectsDetails.caseID =
        details.dtls.appealCaseCreateDetails.appealCaseCreateDetails.caseID;
      addAppealObjectsDetails.comments =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.comments;
      addAppealObjectsDetails.continueBenefitsIndicator =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.continueBenefitsIndicator;
      addAppealObjectsDetails.dateReceived =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.dateReceived;
      addAppealObjectsDetails.effectiveDate =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.effectiveDate;
      addAppealObjectsDetails.emergencyCode =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.emergencyCode;
      addAppealObjectsDetails.reasonCode =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.reasonCode;
      addAppealObjectsDetails.receiptMethod =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.receiptMethod;
      addAppealObjectsDetails.receiptNoticeIndicator =
        details.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails.receiptNoticeIndicator;
      curam.appeal.sl.fact.AppealFactory.newInstance()
        .addAppealObjectsToCase(addAppealObjectsDetails);
    }
    // Return the hearing case identifier
    return hearingCaseSummaryKey;
  }

}
