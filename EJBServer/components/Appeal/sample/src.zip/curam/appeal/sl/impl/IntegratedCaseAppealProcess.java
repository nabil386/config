/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.sl.entity.fact.AppealProcessFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealStageConfigurationFactory;
import curam.appeal.sl.entity.intf.AppealProcess;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealStageConfiguration;
import curam.appeal.sl.entity.struct.AppealCaseAndCase;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealProcessID;
import curam.appeal.sl.entity.struct.AppealProcessKey;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppealStageConfigurationDetails;
import curam.appeal.sl.entity.struct.AppealStageConfigurationDetailsList;
import curam.appeal.sl.entity.struct.AppealTypeAndProcess;
import curam.appeal.sl.entity.struct.CaseTypeIDStartDateActiveDetails;
import curam.appeal.sl.entity.struct.PriorAppealCaseID;
import curam.appeal.sl.entity.struct.PriorAppealCaseIDAndCaseIDDetailsList;
import curam.appeal.sl.entity.struct.StageAndParentDetailsList;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.intf.IssueAppealProcess;
import curam.appeal.sl.struct.AppealCaseIDCaseID;
import curam.appeal.sl.struct.AppealStageType;
import curam.appeal.sl.struct.CaseAndPriorAppeal;
import curam.appeal.sl.struct.IssueAppealProcessKey;
import curam.appeal.sl.struct.IssueStagePositionDetails;
import curam.appeal.sl.struct.OrderedAppealStage;
import curam.appeal.sl.struct.OrderedAppealStageList;
import curam.appeal.sl.struct.PriorAppealCount;
import curam.appeal.sl.struct.ProductAndStartDateAndAppealType;
import curam.appeal.sl.struct.StageFirstLevelDetails;
import curam.appeal.sl.struct.StageFirstLevelDetailsList;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.message.BPOINTEGRATEDCASEAPPEALPROCESS;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;

/**
 * Provides the functionality for maintaining and accessing the configuration
 * for
 * an appealable case type.
 */
public abstract class IntegratedCaseAppealProcess extends
  curam.appeal.sl.base.IntegratedCaseAppealProcess {

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  public IntegratedCaseAppealProcess() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of active appeal stages for an appealable case type.
   * For each appeal stage an indicator as to whether or not the stage is first
   * level
   * of appeal for the case type is also returned.
   * 
   * @param details
   * The case identifier, date and appeal type to search for
   * @return List of appeal stage identifiers including an indicator for whether
   * or not the stage is the first level of appeal.
   */
  @Override
  public StageFirstLevelDetailsList listStageFirstLevelForAppealType(
    final ProductAndStartDateAndAppealType details) throws AppException,
    InformationalException {

    // Return List
    final StageFirstLevelDetailsList stageFirstLevelDetailsList =
      new StageFirstLevelDetailsList();

    // Variables for determining the active appeal process
    final curam.appeal.sl.entity.intf.AppealProcess appealProcessObj =
      curam.appeal.sl.entity.fact.AppealProcessFactory.newInstance();
    StageAndParentDetailsList stageAndParentDetailsList =
      new StageAndParentDetailsList();
    final IssueStagePositionDetails stagePositionDetails =
      new IssueStagePositionDetails();
    AppealStageType appealStageType;

    // Variables for getting the list of active appeal stages for an appealable
    // case
    // appeal process configuration
    final curam.appeal.sl.entity.intf.AppealStageConfiguration appealStageConfigurationObj =
      curam.appeal.sl.entity.fact.AppealStageConfigurationFactory
        .newInstance();
    final AppealTypeAndProcess appealTypeAndProcess =
      new AppealTypeAndProcess();

    // Determine the active appeal process configuration for this case type
    long appealProcessID = 0;

    try {
      final CaseTypeIDStartDateActiveDetails caseTypeIDStartDateActiveDetails =
        new CaseTypeIDStartDateActiveDetails();

      caseTypeIDStartDateActiveDetails.startDate = details.startDate;
      caseTypeIDStartDateActiveDetails.caseTypeID = details.productID;
      caseTypeIDStartDateActiveDetails.recordStatus = RECORDSTATUS.NORMAL;
      appealProcessID =
        appealProcessObj
          .readProcessIDByCaseTypeIDAndStartDate(caseTypeIDStartDateActiveDetails).appealProcessID;
    } catch (final RecordNotFoundException e) {// There is no active appeal
      // process defined for this case type
    }

    if (appealProcessID != 0) {
      // Get all of the active appeal stages for the appeal process where
      // the an appeal of the specified type can be created; note that appeal
      // stages configured for "any" type of appeal are also included.
      appealTypeAndProcess.productAppealProcessID = appealProcessID;
      appealTypeAndProcess.appealTypeCode = details.appealStageAppealTypeCode;
      appealTypeAndProcess.recordStatus = RECORDSTATUS.NORMAL;
      appealTypeAndProcess.anyAppealTypeCode = APPEALSTAGEAPPEALTYPE.ANY;
      stageAndParentDetailsList =
        appealStageConfigurationObj
          .searchActiveStageParentByProcessAndType(appealTypeAndProcess);

      // For each appeal stage determine whether it is the first level of
      // appeal; An appeal stage is the first stage when it has no active
      // parent appeal stage.
      for (int i = 0; i < stageAndParentDetailsList.dtls.size(); i++) {

        final StageFirstLevelDetails stageFirstLevelDetails =
          new StageFirstLevelDetails();

        stageFirstLevelDetails.appealStageID =
          stageAndParentDetailsList.dtls.item(i).appealStageID;

        // If there is no active parent for an appeal stage then the appeal
        // stage is the first level of appeal for an appealable case type.
        if (stageAndParentDetailsList.dtls.item(i).parentAppealStageID == 0) {
          stageFirstLevelDetails.firstLevelIndicator = true;

        } else {
          // If this matches the first active stage then it is a first level of
          // appeal
          stagePositionDetails.position = 0;
          stagePositionDetails.caseTypeID = details.productID;
          stagePositionDetails.startDate = details.startDate;
          appealStageType = getStageAtPosition(stagePositionDetails);

          if (appealStageType.appealStageType.appealStageType
            .equals(details.appealStageAppealTypeCode)
            || appealStageType.appealStageType.appealStageType
              .equals(APPEALSTAGEAPPEALTYPE.ANY)) {
            stageFirstLevelDetails.firstLevelIndicator = true;
          } else {
            stageFirstLevelDetails.firstLevelIndicator = false;
          }
        }

        stageFirstLevelDetailsList.stageFirstLevelDetails
          .addRef(stageFirstLevelDetails);
      }

    }

    return stageFirstLevelDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage in a
   * process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage at the requested position or null if none are
   * found.
   */
  @Override
  public AppealStageType getStageAtPosition(
    final IssueStagePositionDetails key) throws AppException,
    InformationalException {

    // Variable for returning the appeal stage
    final AppealStageType appealStageType = new AppealStageType();

    appealStageType.appealStageType.appealStageType =
      getStageDetailsAtPosition(key).appealTypeCode;
    return appealStageType;

  }

  // ___________________________________________________________________________
  /**
   * Returns active stages for a process in the correct order.
   * 
   * @param key
   * The appeal process for which to return appeal stages.
   * @return List of ordered appeal stages including numerical indicator of
   * order sequence.
   */
  @Override
  public OrderedAppealStageList listOrderedActiveStages(
    final IssueAppealProcessKey key) throws AppException,
    InformationalException {

    // Variables for ordered list of active stages

    final OrderedAppealStageList orderedAppealStageList =
      new OrderedAppealStageList();

    OrderedAppealStage orderedAppealStage;

    // Variable for domain APPEAL_STAGE_SEQUENCE
    byte appealStageSequence = 1;

    // Variables for domain APPEAL_STAGE_ID
    long nextParentAppealStageID;

    // Entity layer variables for Appeal Stage

    final AppealStageConfiguration appealStageConfigurationObj =
      AppealStageConfigurationFactory.newInstance();

    AppealStageConfigurationDetails appealStageConfigurationDetails;

    AppealStageConfigurationDetailsList appealStageConfigurationDetailsList;

    final AppealProcessKey appealProcessKey = new AppealProcessKey();

    appealProcessKey.appealProcessID = key.appealProcessID;

    // Get unsorted list of stages for this appeal process configuration
    appealStageConfigurationDetailsList =
      appealStageConfigurationObj.searchIssueStages(appealProcessKey);

    // First stage in list has a null parent ID

    nextParentAppealStageID = 0;

    // If at least one stage exists then sort the list

    if (appealStageConfigurationDetailsList.dtls.size() >= 1) {

      for (int i = 0; i < appealStageConfigurationDetailsList.dtls.size(); i++) {

        // Find the next stage in the list

        orderedAppealStage = new OrderedAppealStage();

        for (int j = 0; j < appealStageConfigurationDetailsList.dtls.size(); j++) {

          appealStageConfigurationDetails =
            appealStageConfigurationDetailsList.dtls.item(j);

          // If the parent ID matches then have found the next stage

          if (appealStageConfigurationDetails.parentStageConfID == nextParentAppealStageID) {

            // If this stage is active then add it to the ordered list

            if (appealStageConfigurationDetails.recordStatus
              .equals(RECORDSTATUS.NORMAL)) {

              orderedAppealStage.appealStageID =
                appealStageConfigurationDetails.appealStageConfID;
              orderedAppealStage.appealTypeCode =
                appealStageConfigurationDetails.appealTypeCode;

              orderedAppealStage.stageSequence = appealStageSequence;

              orderedAppealStageList.orderedAppealStage
                .addRef(orderedAppealStage);

              appealStageSequence++;
            }

            // Let this be the next parent ID

            nextParentAppealStageID =
              appealStageConfigurationDetails.appealStageConfID;
            break;
          }
        }
      }
    }

    return orderedAppealStageList;
  }

  /**
   * Get the details of the current appeal stage for a case.
   * 
   * @param appealCaseIDCaseID
   * The appeal case and case identifiers.
   * @return Details of the current appeal stage for the case.
   */
  @Override
  public OrderedAppealStage getStageDetailsAtPosition(
    final IssueStagePositionDetails key) throws AppException,
    InformationalException {

    // Variable for Appeal Process
    final AppealProcess appealProcessObj = AppealProcessFactory.newInstance();

    // Variables for getting the sorted list of active stages for an
    // appeal process
    OrderedAppealStageList orderedAppealStageList;
    OrderedAppealStage orderedAppealStage = null;
    final AppealProcessID appealProcessID = new AppealProcessID();

    try {
      // Get the active appeal process for this Appealable Case based on the
      // start date provided.
      final CaseTypeIDStartDateActiveDetails caseTypeIDStartDateActiveDetails =
        new CaseTypeIDStartDateActiveDetails();

      caseTypeIDStartDateActiveDetails.startDate = key.startDate;
      caseTypeIDStartDateActiveDetails.caseTypeID = key.caseTypeID;
      caseTypeIDStartDateActiveDetails.recordStatus = RECORDSTATUS.NORMAL;
      appealProcessID.appealProcessID =
        appealProcessObj
          .readProcessIDByCaseTypeIDAndStartDate(caseTypeIDStartDateActiveDetails).appealProcessID;
    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for this case type
      // BEGIN, CR00355362, DG
      throw new AppException(
        BPOINTEGRATEDCASEAPPEALPROCESS.ERR_INTEGRATED_CASE_NO_ACTIVEAPPEAL_PROCESS);
      // END, CR00355362
    }

    final IssueAppealProcessKey issueAppealProcessKey =
      new IssueAppealProcessKey();

    issueAppealProcessKey.appealProcessID = appealProcessID.appealProcessID;

    // Get ordered list of stages for the active appeal process
    orderedAppealStageList = listOrderedActiveStages(issueAppealProcessKey);

    // Get the appeal stage at the specified position
    if (key.position < orderedAppealStageList.orderedAppealStage.size()) {

      orderedAppealStage =
        orderedAppealStageList.orderedAppealStage.item((int) key.position);

    }

    return orderedAppealStage;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage details in
   * a process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage details at the requested position or null if none
   * are found.
   */
  @Override
  public OrderedAppealStage getCurrentAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcessObj =
      IssueAppealProcessFactory.newInstance();
    final PriorAppealCaseID priorAppealCaseID = new PriorAppealCaseID();
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();

    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Retrieve Prior AppealCaseID if it exists. Otherwise this is a new appeal
    // case.
    if (appealCaseIDCaseID.appealCaseID != 0) {
      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;

      // BEGIN, CR00297475, DG
      // Get the prior appeal case identifier
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == appealCaseIDCaseID.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00297475

      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount =
        issueAppealProcessObj.getNumberPriorAppeals(caseAndPriorAppeal);

      // AppealRelationship object and structs
      PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList;

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
        caseHeaderDAO.get(appealCaseIDCaseID.caseID);

      if (priorAppealCount.count == 0
        && caseHeader.getCaseType().equals(CASETYPECODEEntry.APPEAL)) {

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);
        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount =
            issueAppealProcessObj.getNumberPriorAppeals(caseAndPriorAppeal);

        }
      }
    }

    //
    // Determine the appeal type for the next stage in the appeal process for
    // the case
    //
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Get the CaseTypeID
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(appealCaseIDCaseID.caseID);

    // Get the stage details at the given position
    final IssueStagePositionDetails issueStagePositionDetails =
      new IssueStagePositionDetails();

    issueStagePositionDetails.caseTypeID =
      caseHeader.getAdminCaseConfiguration().getID();
    issueStagePositionDetails.startDate = Date.getCurrentDate();
    issueStagePositionDetails.position = priorAppealCount.count;
    orderedAppealStage = getStageDetailsAtPosition(issueStagePositionDetails);

    return orderedAppealStage;
  }

  // ___________________________________________________________________________
  /**
   * Returns the next level of appeal for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID
   * @return Next valid appeal stage type
   */
  @Override
  public AppealStageType getNextAppealStage(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // BEGIN, CR00295153, DG
    final AppealStageType appealStageType = new AppealStageType();

    // BEGIN, CR00296080, DG
    final OrderedAppealStage orderedAppealStage =
      getNextAppealStageDetails(appealCaseIDCaseID);

    if (orderedAppealStage != null) {
      appealStageType.appealStageType.appealStageType =
        orderedAppealStage.appealTypeCode;
    }
    // END, CR00295153

    return appealStageType;

  }

  // ___________________________________________________________________________
  /**
   * Returns the next level stage details for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID.
   * @return Details of the next appeal stage for a case.
   */
  @Override
  public OrderedAppealStage getNextAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Details to return
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final IssueAppealProcess issueAppealProcessObj =
      IssueAppealProcessFactory.newInstance();
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();
    final IssueStagePositionDetails issueStagePositionDetails =
      new IssueStagePositionDetails();

    // Case header variables
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(appealCaseIDCaseID.caseID);

    // Retrieve Prior AppealCaseID if it exists
    if (appealCaseIDCaseID.appealCaseID != 0) {
      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;

      // BEGIN, CR00297475, DG
      // Get the prior appeal case identifier
      final PriorAppealCaseID priorAppealCaseID = new PriorAppealCaseID();
      final AppealCaseID appealCaseID1 = new AppealCaseID();

      appealCaseID1.appealCaseID = appealCaseIDCaseID.appealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID1);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == appealCaseIDCaseID.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00297475

      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount =
        issueAppealProcessObj.getNumberPriorAppeals(caseAndPriorAppeal);

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      if (priorAppealCount.count == 0
        && caseHeader.getCaseType().equals(CASETYPECODEEntry.APPEAL)) {
        final AppealCaseID appealCaseID = new AppealCaseID();

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        final PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);

        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount =
            issueAppealProcessObj.getNumberPriorAppeals(caseAndPriorAppeal);

        }
      }
    }

    // Only increase the count if the appeal case exists
    // Otherwise we are looking for the 1st stage in the appeal
    // process
    if (appealCaseIDCaseID.appealCaseID != 0) {
      priorAppealCount.count++;
    }

    // Get the details for the next stage in the appeal process
    issueStagePositionDetails.caseTypeID =
      caseHeader.getAdminCaseConfiguration().getID();
    issueStagePositionDetails.startDate = Date.getCurrentDate();
    issueStagePositionDetails.position = priorAppealCount.count;
    orderedAppealStage = getStageDetailsAtPosition(issueStagePositionDetails);

    return orderedAppealStage;
  }

}
