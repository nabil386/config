/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealObjectFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.AppealObject;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Appellant;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.struct.AppealCaseIDCaseIDRecordStatus;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealID;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStructList;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.HearingCaseID;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDetails;
import curam.appeal.sl.entity.struct.HearingDetailsList;
import curam.appeal.sl.entity.struct.HearingUserFullDetails;
import curam.appeal.sl.entity.struct.HearingUserFullDetailsList;
import curam.appeal.sl.entity.struct.HearingUserTypeKey;
import curam.appeal.sl.entity.struct.ModifyDeadlineDateDetails;
import curam.appeal.sl.entity.struct.OverallDecisionDetails;
import curam.appeal.sl.entity.struct.ReceiptNotice;
import curam.appeal.sl.entity.struct.RecordStatusDetails;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.AppealedCaseFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.struct.AddAppealObjectsDetails;
import curam.appeal.sl.struct.AddNewAppealedCaseDetails;
import curam.appeal.sl.struct.AppealAndAppealedCaseDetails;
import curam.appeal.sl.struct.AppealCaseCreateDetails;
import curam.appeal.sl.struct.AppealCaseIDDeadlineDate;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealModifyDetails;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.CalculateAppealDeadlineDateDetails1;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateHearingReviewAndAppealObjectsDetails;
import curam.appeal.sl.struct.CreateParticipantDetails;
import curam.appeal.sl.struct.CreateReceiptNoticeDtls;
import curam.appeal.sl.struct.CreateUserRoleDetails;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingReviewAddAppealedCaseDetails;
import curam.appeal.sl.struct.HearingReviewAddCaseDetails;
import curam.appeal.sl.struct.HearingReviewCaseIDKey;
import curam.appeal.sl.struct.HearingReviewCaseSummaryDetails;
import curam.appeal.sl.struct.HearingReviewHearingDetails;
import curam.appeal.sl.struct.HearingReviewHearingDetailsList;
import curam.appeal.sl.struct.NotifyOwnerDetails;
import curam.appeal.sl.struct.ReadAppealDetails;
import curam.appeal.sl.struct.ReadAppealUserDetails;
import curam.appeal.sl.struct.ReadAppellantDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASECLASSIFICATION;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASEPRIORITY;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseStatus;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseFactory;
import curam.core.sl.fact.CaseTransactionLogFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.intf.CaseTransactionLog;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.message.BPOAPPEALEVENTS;
import curam.message.BPOHEARINGCASE;
import curam.message.BPOHEARINGREVIEW;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Hearing Review service
 * layer.
 */
public abstract class HearingReview extends
  curam.appeal.sl.base.HearingReview {

  // This constant refers to the number of permitted active
  // related appeal cases.
  protected static final short kRelatedAppeals = 1;

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  public HearingReview() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the hearing review details.
   * 
   * @param details
   * The details of the hearing review being modified
   */
  @Override
  public void modify(final AppealModifyDetails details) throws AppException,
    InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // HearingAppealTypeCode Variable
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Update the hearing review
    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    appeal_boObj.modify(details, hearingAppealTypeCode);

  }

  // ___________________________________________________________________________
  /**
   * Method to read hearing review details for modification
   * 
   * @param key
   * The key of the hearing review being modified
   * 
   * @return The hearing review details
   */
  @Override
  public AppealModifyDetails readForModify(final HearingReviewCaseIDKey key)
    throws AppException, InformationalException {

    // Return details
    AppealModifyDetails appealModifyDetails = new AppealModifyDetails();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Read the hearing case
    appealCaseKey.caseID = key.caseID;
    appealModifyDetails = appeal_boObj.read(appealCaseKey);

    return appealModifyDetails;

  }

  // ___________________________________________________________________________
  /*
   * This method retrieves the details of a hearing review case
   * 
   * @param Key Identifies the hearing review whose details are being read
   * 
   * @return The details of the hearing review
   */
  @Override
  public HearingReviewCaseSummaryDetails readSummary(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Return details
    final HearingReviewCaseSummaryDetails hearingReviewCaseSummaryDetails =
      new HearingReviewCaseSummaryDetails();

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppealDetails readAppealDetails = new ReadAppealDetails();
    ReadAppealUserDetails readAppealUserDetails = new ReadAppealUserDetails();

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    OverallDecisionDetails overallDecisionDetails;

    // Appellant Details
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // HearingReviewCaseIDKey
    final HearingReviewCaseIDKey hearingReviewCaseIDKey =
      new HearingReviewCaseIDKey();

    // HearingReviewHearingDetailsList
    HearingReviewHearingDetailsList hearingReviewHearingDetailsList =
      new HearingReviewHearingDetailsList();

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read appeal details
    appealCaseKey.caseID = key.caseID;
    readAppealDetails = appeal_boObj.readAppealDetails(appealCaseKey);

    // If the appellant is not the organization then read for the appellant
    // details.
    readAppellantDetails = appeal_boObj.readAppellantDetails(appealCaseKey);

    readAppealUserDetails = appeal_boObj.readOwnerDetails(appealCaseKey);

    hearingReviewCaseIDKey.caseID = key.caseID;
    hearingReviewHearingDetailsList = listHearings(hearingReviewCaseIDKey);

    // Get the decision details for the hearing case
    try {

      hearingDecisionCaseKey.caseID = key.caseID;
      overallDecisionDetails =
        hearingDecisionObj.readOverallDecisionByCase(hearingDecisionCaseKey);

      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.decisionResolution =
        overallDecisionDetails.resolutionCode;
      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.decisionStatus =
        overallDecisionDetails.decisionStatus;
      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.decisionVersionNo =
        overallDecisionDetails.versionNo;
      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.hearingDecisionID =
        overallDecisionDetails.hearingDecisionID;

    } catch (final RecordNotFoundException e) {

      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.decisionStatus =
        HEARINGDECISIONSTATUS.NOTSTARTED;
      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.decisionResolution =
        APPEALCASERESOLUTION.NOTDECIDED;
      hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.attachmentID =
        0;

    }

    hearingReviewCaseSummaryDetails.hearingReviewCaseDetails
      .assign(readAppealDetails.appealReadSummaryDetails);

    hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.appellantParticipantRoleID =
      readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;

    hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.appellantName =
      readAppellantDetails.concernRoleNameDetails.concernRoleName;

    hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.ownerUserName =
      readAppealUserDetails.userName;
    hearingReviewCaseSummaryDetails.hearingReviewCaseDetails.ownerFullName =
      readAppealUserDetails.userFullname.fullname;

    // Assign the details
    hearingReviewCaseSummaryDetails.hearingReviewHearingDetailsList =
      hearingReviewHearingDetailsList;

    // BEGIN, CR00021086, RKi
    // To determine if the hearing review case has single or multiple
    // appellants.
    // Required structs
    final Appeal appealObj = AppealFactory.newInstance();
    AppealID appealID = new AppealID();
    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();
    Count count = new Count();
    final Appellant appellantObj = AppellantFactory.newInstance();

    appealCaseIDKey.caseID = key.caseID;

    // retrieve appealID
    appealID = appealObj.readAppealIDByCase(appealCaseIDKey);
    appealIDAndDateDetails.appealID = appealID.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    // retrieves the count of appellants existing on a hearing review case
    count =
      appellantObj.countActiveAppellantsByAppealID(appealIDAndDateDetails);
    if (count.numberOfRecords > 1) {
      hearingReviewCaseSummaryDetails.multipleIndicator.multipleAppellants =
        true;
    }
    // END, CR00021086

    // BEGIN, CR00050118, RKi
    final CaseTransactionLog caseTransactionLog =
      CaseTransactionLogFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();

    caseIDKey.caseID = key.caseID;
    hearingReviewCaseSummaryDetails.transactionDtlsList.transactionDetailsList =
      caseTransactionLog.readAllTransactions(caseIDKey);
    // END, CR00050118

    // Return the details
    return hearingReviewCaseSummaryDetails;

  }

  // ___________________________________________________________________________
  /**
   * Lists all hearings for the specified Hearing Review case.
   * 
   * @param key
   * hearing review case key
   * 
   * @return list of all hearing reviews
   */
  @Override
  public HearingReviewHearingDetailsList listHearings(
    final HearingReviewCaseIDKey key) throws AppException,
    InformationalException {

    // Hearing variables
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    HearingDetails hearingDetails;
    HearingDetailsList hearingDetailsList;

    // Hearing review variables
    HearingReviewHearingDetailsList hearingReviewHearingDetailsList;
    HearingReviewHearingDetails hearingReviewDetails;

    // User Role variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    HearingUserTypeKey hearingUserTypeKey;
    HearingUserFullDetailsList hearingUserFullDetailsList;
    HearingUserFullDetails hearingUserFullDetails;

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Search hearings by case id
    hearingCaseID = new HearingCaseID();
    hearingCaseID.caseID = key.caseID;

    hearingDetailsList = hearingObj.searchHearingsByCaseID(hearingCaseID);
    final int countHearingDetailsList =
      hearingDetailsList.dtls.items().length;

    hearingReviewHearingDetailsList = new HearingReviewHearingDetailsList();

    // Go through all hearing details
    for (int i = 0; i < countHearingDetailsList; i++) {

      hearingDetails = hearingDetailsList.dtls.item(i);

      hearingUserTypeKey = new HearingUserTypeKey();
      hearingUserTypeKey.hearingID = hearingDetails.hearingID;
      hearingUserTypeKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;

      hearingUserFullDetailsList =
        hearingUserRoleObj.searchAllByHearingIDAndType(hearingUserTypeKey);
      hearingUserFullDetails = new HearingUserFullDetails();

      String hearingUserNames = "";

      // Populate the hearing review list, iterate through user list,
      // extract the username and add to tab delimited hearingUserNames
      // string
      for (int j = 0; j < hearingUserFullDetailsList.dtls.items().length; j++) {

        // BEGIN, CR00053295, RKi
        // CaseUserRole Objects
        final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
        CaseOwnerDetails caseOwnerDetails;
        final curam.core.sl.intf.CaseUserRole caseUserRole =
          curam.core.sl.fact.CaseUserRoleFactory.newInstance();

        orgObjectLinkKey.orgObjectLinkID =
          hearingUserFullDetailsList.dtls.item(j).orgObjectLinkID;
        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        hearingUserFullDetailsList.dtls.item(j).fullName =
          caseOwnerDetails.userFullName;
        // END, CR00053295

        hearingUserFullDetails = hearingUserFullDetailsList.dtls.item(j);
        hearingUserNames += hearingUserFullDetails.fullName;

        // Do not add comma after the last user name in the list
        if (j < hearingUserFullDetailsList.dtls.items().length - 1) {
          hearingUserNames += CuramConst.gkComma + CuramConst.gkSpace;
        }

      }

      hearingReviewDetails = new HearingReviewHearingDetails();
      hearingReviewDetails.hearingID = hearingDetails.hearingID;
      hearingReviewDetails.referenceNumber = hearingDetails.referenceNumber;
      hearingReviewDetails.reviewerNames = hearingUserNames;
      hearingReviewDetails.statusCode = hearingDetails.statusCode;
      hearingReviewDetails.date =
        new Date(
          TimeZoneUtility.getTimeZoneAdjustedDateTime(
            hearingDetails.scheduledDateTime,
            TransactionInfo.getUserTimeZone()));

      hearingReviewHearingDetailsList.dtls.addRef(hearingReviewDetails);

    }

    return hearingReviewHearingDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Notifies the relevant user(s) about the hearing review.
   * 
   * @param details
   * The details required to notify the owners
   */
  @Override
  public void notifyOwnerAboutReview(final NotifyOwnerDetails details)
    throws AppException, InformationalException {

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Notification variables
    final Notification notificationObj = NotificationFactory.newInstance();

    // StandardManualTask details
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Case User Role objects
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    AppException subjectInfo;

    subjectInfo =
      new AppException(BPOHEARINGREVIEW.INF_HEARINGREVIEW_FV_CASEUNDERAPPEAL);

    // read maintainCase
    CaseReferenceAndStatusDetails caseReferenceAndStatusDtls =
      new CaseReferenceAndStatusDetails();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = details.caseID;
    caseReferenceAndStatusDtls =
      caseHeaderObj.readCaseReferenceAndStatusByCaseID(caseSearchKey);

    subjectInfo.arg(caseReferenceAndStatusDtls.caseReference);

    // SystemUser to get username
    final SystemUser systemUser = SystemUserFactory.newInstance();

    if (details.priorAppealCaseID != 0) {

      caseHeaderKey.caseID = details.priorAppealCaseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // Owner of hearing case
      orgObjectLinkKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // A notification is sent to the case owner of the prior appeal case
      // when a decision from a prior appeal case is being appealed. A check
      // to ensure the current user is not the user to whom the notification
      // is being sent is carried out first.
      if (!caseOwnerDetails.userName
        .equals(systemUser.getUserDetails().userName)) {

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          details.priorAppealCaseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          GeneralAppealConstants.kSpace;
        standardManualTaskDtls.dtls.taskDtls.subject =
          subjectInfo.getMessage();

        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userFullName;
        standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
          caseHeaderDtls.concernRoleID;

        // BEGIN, CR00053295, RKi
        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
        // END, CR00053295
      }

    }

    caseHeaderKey.caseID = details.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // A notification is sent to the case owner of the implementation case being
    // appealed.
    if (!caseOwnerDetails.userName
      .equals(systemUser.getUserDetails().userName)) {

      standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject = subjectInfo.getMessage();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseHeaderDtls.concernRoleID;

      // BEGIN, CR00053295, RKi
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295

    }
  }

  // ___________________________________________________________________________
  /**
   * Adds an appealed case to the hearing review.
   * 
   * @param details
   * The details required to add an appealed case to a review
   */
  @Override
  protected void addAppealedCase(
    final HearingReviewAddAppealedCaseDetails details) throws AppException,
    InformationalException {

    // Appeal objects
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // AddNewAppealedCase details
    final AddNewAppealedCaseDetails addNewAppealedCaseDetails =
      new AddNewAppealedCaseDetails();

    // Details of owner to be notified
    final NotifyOwnerDetails notifyOwnerDetails = new NotifyOwnerDetails();

    // Add the appealed case
    addNewAppealedCaseDetails.assign(details.addAppealedCaseDetails);
    addNewAppealedCaseDetails.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    addNewAppealedCaseDetails.addAppealedCaseInputDetails =
      details.addAppealedCaseDetails.addAppealedCaseInputDetails;

    // relationship key to get the appealRelationshipID
    final AppealRelationshipKey appealRelationshipKey =
      appealObj.addAppealedCase(addNewAppealedCaseDetails);

    // notify the owner
    notifyOwnerDetails.caseID = details.addAppealedCaseDetails.implCaseID;
    notifyOwnerDetails.appealCaseID =
      details.addAppealedCaseDetails.appealCaseID;
    notifyOwnerDetails.priorAppealCaseID =
      details.addAppealedCaseDetails.priorAppealCaseID;

    notifyOwnerAboutReview(notifyOwnerDetails);

    if (details.addAppealedCaseDetails.addAppealedCaseInputDetails.receiptNoticeIndicator) {

      // appeal case details object
      final AppealAndAppealedCaseDetails appealAndAppealedCaseDetails =
        new AppealAndAppealedCaseDetails();

      // set object ID properties
      appealAndAppealedCaseDetails.appealCaseID =
        details.addAppealedCaseDetails.appealCaseID;
      appealAndAppealedCaseDetails.appealRelationshipID =
        appealRelationshipKey.appealRelationshipID;

      createReceiptNotice(appealAndAppealedCaseDetails);

      // create and set record status object
      final AppealCaseIDCaseIDRecordStatus appealCaseIDCaseIDRecordStatus =
        new AppealCaseIDCaseIDRecordStatus();

      appealCaseIDCaseIDRecordStatus.appealCaseID =
        details.addAppealedCaseDetails.appealCaseID;
      appealCaseIDCaseIDRecordStatus.caseID =
        details.addAppealedCaseDetails.implCaseID;
      appealCaseIDCaseIDRecordStatus.recordStatus = RECORDSTATUS.NORMAL;

      // Set receipt notice to true
      final ReceiptNotice receiptNotice = new ReceiptNotice();

      receiptNotice.receiptNoticeIndicator = true;

      appealRelationshipObj.modifyReceiptNoticeIndicator(
        appealCaseIDCaseIDRecordStatus, receiptNotice);
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new hearing review case
   * 
   * @param details
   * The new hearing review details
   */
  @Override
  public HearingReviewCaseIDKey create(final AppealCaseCreateDetails details)
    throws AppException, InformationalException {

    // caseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    // Case Status object
    final CaseStatus caseStatusObj = CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Appeal objects
    final Appeal appealObj = AppealFactory.newInstance();
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final AppealDtls appealDtls = new AppealDtls();

    // Return variable
    final HearingReviewCaseIDKey hearingReviewCaseIDKey =
      new HearingReviewCaseIDKey();

    // Create User Roles
    final CreateUserRoleDetails createUserRoleDetails =
      new CreateUserRoleDetails();

    // Create participant details
    final CreateParticipantDetails createParticipantDetails =
      new CreateParticipantDetails();

    // Variable for adding an appealed case to a hearing review
    final HearingReviewAddAppealedCaseDetails hearingReviewAddAppealedCaseDetails =
      new HearingReviewAddAppealedCaseDetails();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for creating an appeal case
    validateSecurityKey.caseID = details.appealCaseCreateDetails.caseID;
    validateSecurityKey.type = AppealSecurity.kCreateSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateCreate(details);

    // Insert the CaseHeader record for the hearing review case
    caseHeaderDtls.statusCode = CASESTATUS.OPEN;
    caseHeaderDtls.concernRoleID =
      details.appealCaseCreateDetails.participantRoleID;
    caseHeaderDtls.caseTypeCode = CASETYPECODE.APPEAL;
    caseHeaderDtls.caseReference =
      CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;

    caseHeaderDtls.caseID = uniqueIDObj.getNextID();
    caseHeaderDtls.startDate = currentDate;
    caseHeaderDtls.expectedEndDate = Date.kZeroDate;
    caseHeaderDtls.endDate = Date.kZeroDate;
    caseHeaderDtls.effectiveDate = Date.kZeroDate;
    caseHeaderDtls.registrationDate = currentDate;
    caseHeaderDtls.priorityCode = CASEPRIORITY.DEFAULTCODE;
    caseHeaderDtls.classificationCode = CASECLASSIFICATION.DEFAULTCODE;

    caseHeaderDtls.appealIndicator = false;
    // the owner ID is update when the CaseUserRole is created
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    caseHeaderDtls.caseReference =
      CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;
    caseHeaderDtls.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;
    // BEGIN ,CR00284371 , DK
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.appealCaseCreateDetails.caseID;
    final boolean isIntegratedCaseInd =
      caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode
        .equals(CASETYPECODE.INTEGRATEDCASE);

    if (isIntegratedCaseInd) {
      caseHeaderDtls.integratedCaseID =
        details.appealCaseCreateDetails.caseID;
    } else {
      caseHeaderDtls.integratedCaseID =
        details.appealCaseCreateDetails.parentCaseID;
    }
    // END , CR00284371 , DK
    caseHeaderObj.insert(caseHeaderDtls);

    // insert Appeal Details
    appealDtls.appealTypeCode = APPEALTYPE.HEARINGREVIEW;
    appealDtls.caseID = caseHeaderDtls.caseID;
    appealDtls.difficultyCode = details.difficultyCode;
    appealDtls.comments = details.addAppealedCaseInputDetails.comments;
    appealObj.insert(appealDtls);

    createUserRoleDetails.appealCaseID = caseHeaderDtls.caseID;
    appeal_boObj.createUserRoles(createUserRoleDetails);

    createParticipantDetails.participantRoleID =
      details.appealCaseCreateDetails.participantRoleID;
    createParticipantDetails.appealCaseID = caseHeaderDtls.caseID;

    // When the organization is the appellant the respondent is a participant
    // on the appeal case. Otherwise the appellant is a participant on the
    // appeal case.
    if (details.appealCaseCreateDetails.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {

      appeal_boObj.createRespondentParticipant(createParticipantDetails);

    } else {
      // BEGIN, CR00021086, RKi
      CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey =
        appeal_boObj.createAppellantParticipant(createParticipantDetails);
      // add the appellant to appellant entity
      final Appellant appellantObj = AppellantFactory.newInstance();
      final AppellantDtls appellantDtls = new AppellantDtls();

      appellantDtls.appealID = appealDtls.appealID;
      appellantDtls.caseParticipantRoleID =
        caseParticipantRoleKey.caseParticipantRoleID;
      appellantDtls.appellantTypeCode =
        details.appealCaseCreateDetails.appellantTypeCode;
      appellantDtls.emergencyCode =
        details.addAppealedCaseInputDetails.emergencyCode;
      appellantDtls.comments = details.addAppealedCaseInputDetails.comments;
      appellantDtls.receivedDate =
        details.addAppealedCaseInputDetails.dateReceived;
      appellantDtls.fromDate = Date.getCurrentDate();
      appellantDtls.reasonCode =
        details.addAppealedCaseInputDetails.reasonCode;
      appellantDtls.receiptMethod =
        details.addAppealedCaseInputDetails.receiptMethod;
      appellantDtls.receiptNoticeIndicator =
        details.addAppealedCaseInputDetails.receiptNoticeIndicator;
      appellantObj.insert(appellantDtls);
      // END, CR00021086

    }

    // Insert caseStatus record
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.endDate = Date.kZeroDate;
    caseStatusDtls.statusCode = CASESTATUS.OPEN;
    caseStatusDtls.startDate = currentDate;

    caseStatusObj.insert(caseStatusDtls);

    // Add the appealed case
    hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.addAppealedCaseInputDetails =
      details.addAppealedCaseInputDetails;
    hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID =
      appealDtls.caseID;
    hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.priorAppealCaseID =
      details.appealCaseCreateDetails.priorAppealCaseID;
    hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.implCaseID =
      details.appealCaseCreateDetails.caseID;
    addAppealedCase(hearingReviewAddAppealedCaseDetails);

    hearingReviewCaseIDKey.caseID = caseHeaderDtls.caseID;

    // BEGIN, CR00295153, DG
    // Calculate the initial appeal deadline date for the hearing review case
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();

    calculateAppealDeadlineDateDetails1.appealTypeCode =
      APPEALTYPE.HEARINGREVIEW;
    calculateAppealDeadlineDateDetails1.implCaseID =
      details.appealCaseCreateDetails.caseID;
    calculateAppealDeadlineDateDetails1.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;
    calculateAppealDeadlineDateDetails1.appealCaseID = caseHeaderDtls.caseID;

    // Update deadline date on case
    // Note: this must be done after the appeal case and appeal relationship
    // have been created. Otherwise the time constraints will not be retrieved
    // correctly.
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final ModifyDeadlineDateDetails modifyDeadlineDateDetails =
      new ModifyDeadlineDateDetails();

    appealCaseIDKey.caseID = appealDtls.caseID;
    // BEGIN, CR00323206, KRK
    modifyDeadlineDateDetails.deadlineDate =
      AppealedCaseFactory.newInstance().calculateDeadlineDate1(
        calculateAppealDeadlineDateDetails1).date;
    // END, CR00323206
    modifyDeadlineDateDetails.versionNo =
      appealObj.readDetailsForModify(appealCaseIDKey).versionNo;
    appealObj.modifyDeadlineDate(appealCaseIDKey, modifyDeadlineDateDetails);
    // END, CR00295153

    // BEGIN, CR00050710, RKi
    if (appealDtls.caseID != 0) {

      // BEGIN, CR00443340, DG
      LocalisableString description =
        new LocalisableString(BPOAPPEALEVENTS.APPEALCREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEAL_CREATED, description,
        details.appealCaseCreateDetails.caseID,
        details.appealCaseCreateDetails.caseID);

      description =
        new LocalisableString(BPOAPPEALEVENTS.APPEALEDTOHEARINGREVIEW);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEALED_TO_HEARING_REVIEW, description,
        details.appealCaseCreateDetails.caseID,
        details.appealCaseCreateDetails.caseID);

      description =
        new LocalisableString(BPOAPPEALEVENTS.HEARINGREVIEWCASECREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED, description,
        appealDtls.caseID, appealDtls.caseID);
      // END, CR00443340
    }
    // END, CR00050710
    return hearingReviewCaseIDKey;

  }

  // ___________________________________________________________________________
  /**
   * Validates the details for a new hearing review case
   * 
   * @param details
   * The new hearing review details to be validated
   */
  @Override
  public void validateCreate(final AppealCaseCreateDetails details)
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Validate the appeal case creation
    appealObj.validateCreateAppealCase(details.appealCaseCreateDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal for all appealed cases for an appeal where no receipt notice has
   * been previously created.
   * 
   * @param details
   * The appeal case for which to generate outstanding notices.
   */
  @Override
  public void createReceiptNotice(final CreateReceiptNoticeDtls details)
    throws AppException, InformationalException {

    // caseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // get the appellant for the appeal case
    caseParticipantRoleCaseAndTypeKey.caseID = details.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // get the active participant for the case
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check that record is found
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      communicationDetails.caseID = details.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;
      communicationDetails.subjectText =
        BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

      // BEGIN, CR00293187, CD
      // appeal pro forma document objects
      final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        AppealProFormaDocumentGenerationFactory.newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;

      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal for an appealed case for an appeal.
   * 
   * @param details
   * The appeal case and the appealed case identifiers
   */
  @Override
  public void createReceiptNotice(final AppealAndAppealedCaseDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    // Get the appellant for the appeal case
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    caseParticipantRoleCaseAndTypeKey.caseID = details.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // Get the active participant for the case
    final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check that record is found
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      // Communication objects
      final CommunicationDetails communicationDetails =
        new CommunicationDetails();
      final ProFormaCommDetails1 proFormaCommDetails =
        new ProFormaCommDetails1();
      final Communication communicationObj =
        CommunicationFactory.newInstance();

      // Concern role details
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // Appeal pro forma document objects
      final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        AppealProFormaDocumentGenerationFactory.newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      communicationDetails.caseID = details.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // get UserName
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;

      communicationDetails.subjectText =
        BPOHEARINGREVIEW.INF_HEARINGREVIEW_SUBJECTTEXT.getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication for the appeal case
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set attributes
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        details.appealRelationshipID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGCASE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.REQUEST_SINGLE_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * Adds a request for appeal to an existing hearing review case.
   * 
   * @param details
   * The details for the appealed case to add.
   */
  @Override
  public void addCase(final HearingReviewAddCaseDetails details)
    throws AppException, InformationalException {

    // Appeal process object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // variables used to call other validations
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();
    final AppealCaseIDDeadlineDate appealCaseIDDeadlineDate =
      new AppealCaseIDDeadlineDate();

    // today's date
    final Date currentDate = Date.getCurrentDate();

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID =
      details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // BEGIN, CR00296080, DG
    // add the appealed case
    addAppealedCase(details.hearingReviewAddAppealedCaseDetails);
    // END, CR00296080

    // if case is of Appeal type then calculate deadline date for appeal case
    // CaseHeader object
    DeadlineDate newDeadlineDate;
    CaseTypeCode caseTypeCode;
    final CaseKey caseKey = new CaseKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseKey.caseID =
      details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.implCaseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      appealCaseKey.caseID =
        details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.implCaseID;
      newDeadlineDate = appeal_boObj.calculateDeadlineDate(appealCaseKey);

    } else {

      // recalculate overall appeal deadline
      calculateAppealDeadlineDateDetails1.implCaseID =
        details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.implCaseID;
      calculateAppealDeadlineDateDetails1.receivedDate = currentDate;
      calculateAppealDeadlineDateDetails1.appealTypeCode =
        APPEALTYPE.HEARINGREVIEW;
      calculateAppealDeadlineDateDetails1.appealCaseID =
        details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID;
      newDeadlineDate =
        AppealedCaseFactory.newInstance().calculateDeadlineDate1(
          calculateAppealDeadlineDateDetails1);
    }
    // validate the new deadline date for the appeal
    appealCaseIDDeadlineDate.appealCaseID =
      details.hearingReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID;
    appealCaseIDDeadlineDate.deadlineDate = newDeadlineDate.date;
    appeal_boObj.validateAppealDeadline(appealCaseIDDeadlineDate);

  }

  // BEGIN, CR00021348, RKi
  // ___________________________________________________________________________
  /**
   * This method creates receipt notices for the appellant
   * 
   * @param key
   * identifies the appellant
   */
  @Override
  public void
    createReceiptNoticeForAppellant(final CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // caseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Get appeal case ID and participant role ID
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails =
      new CaseIDAndParticipantRoleIDDetails();

    caseIDAndParticipantRoleIDDetails =
      caseParticipantRoleObj.readCaseIDAndParticipantRoleIDDetails(key);

    concernRoleKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // Check that record is found
    communicationDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    communicationDetails.correspondentConcernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;
    communicationDetails.subjectText =
      BPOHEARINGREVIEW.INF_HEARINGREVIEW_SUBJECTTEXT.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    // BEGIN, CR CR00069029, NSP
    // create person object
    final Person personObj = PersonFactory.newInstance();
    final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
    // BEGIN, CR00236272, AK
    SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

    searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Search whether appellant is associated with the case or not
    searchCaseDetails = personObj.searchCase1(searchCaseKey_fo);
    // END, CR00236272

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() >= 1) {

      // appellant is associated with the case, so acknowledge an appeal
      // request with continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;
    } else {

      // appellant is not associated with the case, so acknowledge an appeal
      // request with no continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEWWITHOUTCONTINUEBENEFITS;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEWWITHOUTCONTINUEBENEFITS;
    } // END, CR CR00069029
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

    // BEGIN, CR00293187, CD
    // appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();

    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    generateDocumentDetails.dtls.dataSetPrimaryKey =
      key.caseParticipantRoleID;
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // END, CR00021348

  // ___________________________________________________________________________
  /**
   * Create a judicial review case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "1001,AOT1|2001,AOT2|2002,AOT2" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   * 
   * @param details
   * Details of the hearing review case to be created.
   * @return The Hearing review case identifier.
   */
  @Override
  public HearingReviewCaseIDKey createWithAppealObjects(
    final CreateHearingReviewAndAppealObjectsDetails details)
    throws AppException, InformationalException {

    // Create the hearing case
    final HearingReviewCaseIDKey hearingReviewCaseKey = create(details.dtls);

    //
    // Check for any approved appeal objects on a previous appeal case.
    //
    final AppealObject appealObectObj = AppealObjectFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    if (details.dtls.appealCaseCreateDetails.priorAppealCaseID != 0
      && details.appealObjectsDelimitedList.isEmpty()) {

      // Get all the appeal relationship records for the previous case
      appealCaseID.appealCaseID =
        details.dtls.appealCaseCreateDetails.priorAppealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {

        if (o.statusCode.equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {
          // Retrieve the objects for this relationship
          final AppealObjectKeyStruct appealObjectKeyStruct =
            new AppealObjectKeyStruct();

          appealObjectKeyStruct.appealRelationshipID = o.appealRelationshipID;
          final AppealObjectDtlsStructList appealObjectDtlsStructList =
            appealObectObj
              .searchByAppealRelationshipID(appealObjectKeyStruct);

          if (!appealObjectDtlsStructList.dtls.isEmpty()) {
            if (details.appealObjectsDelimitedList.length() != 0) {
              details.appealObjectsDelimitedList +=
                CuramConst.gkPipeDelimiterChar;
            }
            details.appealObjectsDelimitedList +=
              appealObjectDtlsStructList.dtls.get(0).objectID
                + CuramConst.gkComma
                + appealObjectDtlsStructList.dtls.get(0).objectType;

          }

        }
      }
    }

    // If appeal objects have been supplied then add them
    if (details.appealObjectsDelimitedList.length() != 0) {

      // Cancel the Appeal Relationship record created for the related case.
      // This has to be canceled as we are appealing a list of objects
      // on the case instead of the case itself.
      final RecordStatusDetails recordStatusDetails =
        new RecordStatusDetails();

      appealCaseID.appealCaseID = hearingReviewCaseKey.caseID;
      recordStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
      final AppealRelationShipDetailsList appealRelationshipList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationshipList.dtls) {
        appealRelationshipKey.appealRelationshipID = o.appealRelationshipID;
        recordStatusDetails.versionNo =
          appealRelationshipObj
            .readForModifyAppealedCase(appealRelationshipKey).versionNo;
        appealRelationshipObj.modifyRecordStatus(appealRelationshipKey,
          recordStatusDetails);
      }

      // Add the objects to the case
      final AddAppealObjectsDetails addAppealObjectsDetails =
        new AddAppealObjectsDetails();

      addAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      addAppealObjectsDetails.appealCaseID = hearingReviewCaseKey.caseID;
      addAppealObjectsDetails.caseID =
        details.dtls.appealCaseCreateDetails.caseID;
      addAppealObjectsDetails.comments =
        details.dtls.addAppealedCaseInputDetails.comments;
      addAppealObjectsDetails.continueBenefitsIndicator =
        details.dtls.addAppealedCaseInputDetails.continueBenefitsIndicator;
      addAppealObjectsDetails.dateReceived =
        details.dtls.addAppealedCaseInputDetails.dateReceived;
      addAppealObjectsDetails.effectiveDate =
        details.dtls.addAppealedCaseInputDetails.effectiveDate;
      addAppealObjectsDetails.emergencyCode =
        details.dtls.addAppealedCaseInputDetails.emergencyCode;
      addAppealObjectsDetails.reasonCode =
        details.dtls.addAppealedCaseInputDetails.reasonCode;
      addAppealObjectsDetails.receiptMethod =
        details.dtls.addAppealedCaseInputDetails.receiptMethod;
      addAppealObjectsDetails.receiptNoticeIndicator =
        details.dtls.addAppealedCaseInputDetails.receiptNoticeIndicator;
      curam.appeal.sl.fact.AppealFactory.newInstance()
        .addAppealObjectsToCase(addAppealObjectsDetails);
    }

    return hearingReviewCaseKey;
  }
}
