/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingDateAndType;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantRoleIDStatusHR;
import curam.appeal.sl.entity.struct.HearingRepHearingIDCPRID;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.fact.HearingParticipationFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.CaseParticipantRoleLinkDetailsList;
import curam.appeal.sl.struct.CreateCaseParticipantRoleLinkDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateHearingRepresentativeDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingIDKeyHR;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingRepresentativeIDKey;
import curam.appeal.sl.struct.HearingTimeDetails;
import curam.appeal.sl.struct.ModifyHearingRepFeeDetails;
import curam.appeal.sl.struct.ModifyHearingRepresentativeDetails;
import curam.appeal.sl.struct.ModifyHearingRepresentativeStatus;
import curam.appeal.sl.struct.ReadHearingRepresentativeDetails;
import curam.appeal.sl.struct.ReadHearingRepresentativeDetailsList;
import curam.appeal.sl.struct.ValidateHearingRepresentativeHearingStatusDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.FEEAPPROVED;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.ONBEHALFOF;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.TypeAndStatusAndParticipantRoleDetails;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.CancelClientKey;
import curam.core.sl.struct.CaseParticipantRoleDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.core.struct.CuramInd;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOHEARINGREPRESENTATIVE;
import curam.message.BPOHEARINGWITNESS;
import curam.message.BPOSCHEDULECORRESPONDENCE;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Hearing
 * Representative service layer.
 * 
 */
public abstract class HearingRepresentative extends
  curam.appeal.sl.base.HearingRepresentative {

  // ___________________________________________________________________________
  /**
   * Service layer method to create a hearing representative.
   * 
   * @param dtls
   * The details of the hearing representative
   * @return
   * Any informational messages
   */
  @Override
  public InformationalMsgDtlsList create(
    final CreateHearingRepresentativeDetails dtls) throws AppException,
    InformationalException {

    // Variable for returning informational messages
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // HearingIDCaseParticipantRoleIDStatusHR object
    final HearingIDCaseParticipantRoleIDStatusHR hearingIDCaseParticipantRoleIDStatusHR =
      new HearingIDCaseParticipantRoleIDStatusHR();

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Representative object
    final Representative representativeObj =
      RepresentativeFactory.newInstance();

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_boObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleDetails caseParticipantRoleDetails =
      new CaseParticipantRoleDetails();

    // InformationalManager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // BEGIN, CR00096787, RKi
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID =
      dtls.hearingRepresentativeDetails.hearingRepresentativeID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd =
      clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      throw new AppException(
        curam.message.BPOAPPEALCLIENTMERGE.ERR_CREATE_APPEAL_CASE_DUPLICATE_REPRESENTATIVE);
    }
    // END, CR00096787

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      dtls.hearingRepresentativeDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // check for representative already inserted.
    hearingIDCaseParticipantRoleIDStatusHR.hearingID =
      dtls.hearingRepresentativeDetails.hearingID;
    hearingIDCaseParticipantRoleIDStatusHR.caseParticipantRoleID =
      dtls.hearingRepresentativeDetails.caseParticipantRoleID;
    hearingIDCaseParticipantRoleIDStatusHR.recordStatus = RECORDSTATUS.NORMAL;
    final Count count =
      hearingRepresentativeObj
        .countActiveByHearingIDCaseParticipantRoleID(hearingIDCaseParticipantRoleIDStatusHR);

    // if some found, inform the user that this representative already
    // exists for this hearing
    if (count.numberOfRecords > 0) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEEXISTS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    this.validateInsert(dtls);

    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID == 0
      && dtls.representativeRegistrationDetails.representativeDtls.representativeName
        .length() == 0) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_REPRESENTATIVENAMEEMPTY),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // If registering participant
    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID == 0) {

      // Add registration date.
      final Date currentDate = Date.getCurrentDate();

      dtls.representativeRegistrationDetails.representativeRegistrationDetails.registrationDate =
        currentDate;

      dtls.representativeRegistrationDetails.representativeDtls.representativeType =
        REPRESENTATIVETYPE.HEARINGREPRESENTATIVE;

      // Register representative
      representativeObj
        .registerRepresentative(dtls.representativeRegistrationDetails);
    }

    // Insert new case participant role of type HEARINGREPRESENTATIVE
    caseParticipantRoleDetails.dtls.caseID =
      hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleDetails.dtls.participantRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    caseParticipantRoleDetails.dtls.fromDate = Date.getCurrentDate();
    caseParticipantRoleDetails.dtls.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGREPRESENTATIVE;
    caseParticipantRole_boObj
      .insertCaseParticipantRole(caseParticipantRoleDetails);

    // Insert hearing representative
    dtls.hearingRepresentativeDetails.caseParticipantRoleID =
      caseParticipantRoleDetails.dtls.caseParticipantRoleID;
    dtls.hearingRepresentativeDetails.feeApprovedCode =
      FEEAPPROVED.NOTACTIONED;
    dtls.hearingRepresentativeDetails.participatedCode =
      HEARINGPARTICIPATION.NOTHELD;
    hearingRepresentativeObj.insert(dtls.hearingRepresentativeDetails);

    // BEGIN, CR CR00125721, LP
    /*
     * AppellantKeyList appellantKeyList = new AppellantKeyList();
     * HearingRepAppellantLink hearingRepAppellantLinkObj =
     * HearingRepAppellantLinkFactory.newInstance();
     * HearingRepAppellantLinkDtls hearingRepAppellantLinkDtls =
     * new HearingRepAppellantLinkDtls();
     * curam.appeal.sl.entity.struct.HearingKey hrngKey =
     * new curam.appeal.sl.entity.struct.HearingKey();
     * 
     * hrngKey.hearingID = dtls.hearingRepresentativeDetails.hearingID;
     * Appellant appellantObj = AppellantFactory.newInstance();
     * 
     * appellantKeyList = appellantObj.searchAppellantByHearingID(hrngKey);
     * 
     * for (int i = 0; i < appellantKeyList.dtls.size(); i++) {
     * 
     * hearingRepAppellantLinkDtls.appellantID =
     * appellantKeyList.dtls.item(i).appellantID;
     * hearingRepAppellantLinkDtls.hearingRepresentativeID =
     * dtls.hearingRepresentativeDetails.hearingRepresentativeID;
     * hearingRepAppellantLinkObj.insert(hearingRepAppellantLinkDtls);
     * 
     * }
     */
    // END, CR CR00125721 LP

    // Begin CR00117296 LP
    // create CaseParticipantRoleLink entries. For each hearing Participant
    // selected an entry is inserted
    final CreateCaseParticipantRoleLinkDetails caseParticipantRoleLinkDetails =
      new CreateCaseParticipantRoleLinkDetails();

    caseParticipantRoleLinkDetails.caseParticipantRoleIDs =
      dtls.caseParticipantRoleIDs;
    caseParticipantRoleLinkDetails.relatedID =
      dtls.hearingRepresentativeDetails.caseParticipantRoleID;
    ;
    HearingParticipationFactory.newInstance()
      .createRepresentativeCaseParticipantRoleLinks(
        caseParticipantRoleLinkDetails);

    // End CR00117296 LP

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Service layer method to modify a hearing representative.
   * 
   * @param dtls
   * The details of the hearing representative
   */
  @Override
  public void modify(final ModifyHearingRepresentativeDetails dtls)
    throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    // Contains hearingID and caseParticipantRoleID
    HearingRepHearingIDCPRID hearingRepHearingIDCPRID;

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // HearingIDKeyHR object
    final HearingIDKeyHR hearingIDKeyHR = new HearingIDKeyHR();

    // Case Participant Role variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails =
      new TypeAndStatusAndParticipantRoleDetails();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();

    // ValidateHearingRepresentativeHearingStatusDetails object
    final ValidateHearingRepresentativeHearingStatusDetails validateHearingRepresentativeHearingStatusDetails =
      new ValidateHearingRepresentativeHearingStatusDetails();

    // Read hearing ID and case participant role id
    hearingRepHearingIDCPRID =
      hearingRepresentativeObj
        .readHearingIDCaseParticipantRoleID(dtls.hearingRepresentativeIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingRepHearingIDCPRID.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate hearing status
    validateHearingRepresentativeHearingStatusDetails.hearingIDKeyHR.hearingIDKeyHR.hearingID =
      hearingRepHearingIDCPRID.hearingID;
    validateHearingRepresentativeHearingStatusDetails.participatedCode =
      dtls.modifyDetails.participatedCode;
    validateHearingStatus(validateHearingRepresentativeHearingStatusDetails);

    // Validate third party representatives
    if (dtls.modifyDetails.behalfOfCode.equals(ONBEHALFOF.THIRDPARTY)) {

      hearingIDKeyHR.hearingIDKeyHR.hearingID =
        hearingRepHearingIDCPRID.hearingID;
      validateThirdParty(hearingIDKeyHR);
    }

    // Check case participant role to see if already canceled
    caseParticipantRole_eoKey.caseParticipantRoleID =
      hearingRepHearingIDCPRID.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails =
      caseParticipantRole_eoObj
        .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

    if (typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEALREADYCANCELED);

    }

    // Modify representative
    hearingRepresentativeObj.modify(dtls.hearingRepresentativeIDKey,
      dtls.modifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to retrieve a hearing representative.
   * 
   * @param key
   * The ID of the hearing representative
   */
  @Override
  public ReadHearingRepresentativeDetails read(
    final HearingRepresentativeIDKey key) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Return structure
    final ReadHearingRepresentativeDetails readHearingRepresentativeDetails =
      new ReadHearingRepresentativeDetails();

    // Perform read
    readHearingRepresentativeDetails.readDetails =
      hearingRepresentativeObj.read(key.hearingRepresentativeIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      readHearingRepresentativeDetails.readDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Begin CR00117296 LP
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = hearingCaseID.hearingCaseID.caseID;
    final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {// Legal
                                                                          // Action
                                                                          // Security
                                                                          // will
                                                                          // be
                                                                          // provided
                                                                          // in
                                                                          // V
                                                                          // Next
    } else {
      // Appeal Security business objects
      final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
        AppealSecurityFactory.newInstance();
      final ValidateSecurityKey validateSecurityKey =
        new ValidateSecurityKey();

      // Validate security for maintaining an appeal case
      validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
      validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
      appealSecurityObj.validateSecurity(validateSecurityKey);
    }
    // End CR00117296 LP

    /*
     * // BEGIN, CR CR00020935, RKi
     * HearingRepresentativeKey hearingRepresentativeKey =
     * new HearingRepresentativeKey();
     * HearingRepAppellantLink hearingRepAppellantLinkObj =
     * HearingRepAppellantLinkFactory.newInstance();
     * 
     * hearingRepresentativeKey.hearingRepresentativeID =
     * key.hearingRepresentativeIDKey.hearingRepresentativeID;
     * 
     * readHearingRepresentativeDetails.appDetailsList =
     * hearingRepAppellantLinkObj.searchRepAppellantsByRepID(
     * hearingRepresentativeKey);
     * 
     * // END, CR CR00020935
     */
    // Begin CR00117296 LP
    final curam.appeal.sl.struct.RelatedID relatedID =
      new curam.appeal.sl.struct.RelatedID();

    relatedID.key.relatedID =
      readHearingRepresentativeDetails.readDetails.caseParticipantRoleID;
    readHearingRepresentativeDetails.caseParticipantRoleLinkDetailsList =
      HearingParticipationFactory.newInstance()
        .listCaseParticipantLinkByRelatedID(relatedID);
    ;

    readHearingRepresentativeDetails.participantNames =
      this
        .buildConcernNameString(readHearingRepresentativeDetails.caseParticipantRoleLinkDetailsList);
    // End CR00117296 LP
    return readHearingRepresentativeDetails;
  }

  /**
   * Generates a comma separated string of ConcernRole names
   * 
   * @param caseParticipantRoleLinkDetailsList list of
   * caseParticipantRoleLinkDetails
   * @return comma separated string of ConcernRole names
   */
  // BEGIN, CR00177241, PM
  protected
    String
    buildConcernNameString(
      final CaseParticipantRoleLinkDetailsList caseParticipantRoleLinkDetailsList) {

    // END, CR00177241
    final StringBuffer buffer = new StringBuffer();
    int i;

    for (i = 0; i < caseParticipantRoleLinkDetailsList.dtls.dtls.size(); i++) {
      buffer
        .append(caseParticipantRoleLinkDetailsList.dtls.dtls.item(i).name);
      buffer.append(CuramConst.gkComma);
    }
    if (i > 0) {
      buffer.setLength(buffer.length() - 1);
    }
    return buffer.toString();
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to retrieve a list of hearing representatives.
   * 
   * @param key
   * The ID of the hearing
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public ReadHearingRepresentativeDetailsList list(final HearingIDKeyHR key)
    throws AppException, InformationalException {

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();

    // Return structure
    final ReadHearingRepresentativeDetailsList readHearingRepresentativeDetailsList =
      new ReadHearingRepresentativeDetailsList();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.hearingIDKeyHR.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Retrieve list
    readHearingRepresentativeDetailsList.readDetailsList
      .addAll(hearingRepresentativeObj.searchByHearingID(key.hearingIDKeyHR).dtls);

    return readHearingRepresentativeDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to cancel a hearing representative.
   * 
   * @param dtls
   * The details of the hearing representative
   */
  @Override
  public void cancel(final ModifyHearingRepresentativeStatus dtls)
    throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Contains hearingID and caseParticipantRoleID
    HearingRepHearingIDCPRID hearingRepHearingIDCPRID;

    // CaseParticipantRole objects
    final CaseParticipantRole caseParticipantRole_boObj =
      CaseParticipantRoleFactory.newInstance();
    final CancelClientKey cancelClientKey = new CancelClientKey();

    // Read hearing ID and case participant role id
    hearingRepHearingIDCPRID =
      hearingRepresentativeObj
        .readHearingIDCaseParticipantRoleID(dtls.hearingRepresentativeIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingRepHearingIDCPRID.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate that the representative can be canceled
    validateCancel(hearingRepHearingIDCPRID);

    // Cancel CaseParticipantRole
    cancelClientKey.caseParticipantRoleID =
      hearingRepHearingIDCPRID.caseParticipantRoleID;
    cancelClientKey.versionNo =
      dtls.cancelCaseParticipantRoleDetails.versionNo;
    caseParticipantRole_boObj.cancelCaseParticipantRole(cancelClientKey);

  }

  // ___________________________________________________________________________
  /**
   * Service layer method to modify a hearing representative fee.
   * 
   * @param dtls
   * The details of the hearing representative
   */
  @Override
  public void modifyHearingFee(final ModifyHearingRepFeeDetails dtls)
    throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new curam.appeal.sl.entity.struct.HearingRepresentativeIDKey();
    curam.appeal.sl.entity.struct.ReadHearingRepresentativeDetails readHearingRepresentativeDetails;

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // CaseParticipantRole objects
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails =
      new TypeAndStatusAndParticipantRoleDetails();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();

    // Appeal objects
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Case User Role Variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    curam.core.sl.struct.CaseOwnerDetails ownerDetails =
      new curam.core.sl.struct.CaseOwnerDetails();

    // Task variables
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();
    final Notification notificationObj = NotificationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Read hearing ID
    hearingRepresentativeIDKey.hearingRepresentativeID =
      dtls.hearingRepresentativeIDKey.hearingRepresentativeID;
    readHearingRepresentativeDetails =
      hearingRepresentativeObj.read(hearingRepresentativeIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      readHearingRepresentativeDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Case Header Variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Check for zero amount fee approval
    if (dtls.modifyHearingRepFeeDetails.feeAmount.isZero()
      && dtls.modifyHearingRepFeeDetails.feeApprovedCode
        .equals(FEEAPPROVED.APPROVED)) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_APPROVEZEROFEEAMOUNT);
    }

    // Check case participant role to see if already canceled
    caseParticipantRole_eoKey.caseParticipantRoleID =
      readHearingRepresentativeDetails.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails =
      caseParticipantRole_eoObj
        .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

    if (typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEALREADYCANCELED);
    }

    // Modify representative fee
    hearingRepresentativeObj.modifyFee(dtls.hearingRepresentativeIDKey,
      dtls.modifyHearingRepFeeDetails);

    // If fee approved code is not actioned, than we do not need to
    // send any communications or create any notifications.
    if (!dtls.modifyHearingRepFeeDetails.feeApprovedCode
      .equals(FEEAPPROVED.NOTACTIONED)) {

      // Send notice if representative is on behalf of appellant,
      // respondent or third party
      if (readHearingRepresentativeDetails.behalfOfCode
        .equals(ONBEHALFOF.APPELLANT)
        || readHearingRepresentativeDetails.behalfOfCode
          .equals(ONBEHALFOF.THIRDPARTY)
        || readHearingRepresentativeDetails.behalfOfCode
          .equals(ONBEHALFOF.RESPONDENT)) {

        // Determine concernRoleID to send notice to
        caseParticipantRoleCaseAndTypeKey.caseID =
          hearingCaseID.hearingCaseID.caseID;
        if (readHearingRepresentativeDetails.behalfOfCode
          .equals(ONBEHALFOF.APPELLANT)) {

          caseParticipantRoleCaseAndTypeKey.typeCode =
            CASEPARTICIPANTROLETYPE.APPELLANT;

        } else if (readHearingRepresentativeDetails.behalfOfCode
          .equals(ONBEHALFOF.THIRDPARTY)) {

          caseParticipantRoleCaseAndTypeKey.typeCode =
            CASEPARTICIPANTROLETYPE.THIRDPARTY;

        } else if (readHearingRepresentativeDetails.behalfOfCode
          .equals(ONBEHALFOF.RESPONDENT)) {

          caseParticipantRoleCaseAndTypeKey.typeCode =
            CASEPARTICIPANTROLETYPE.RESPONDENT;

        }

        // This list will only be one item
        caseParticipantRoleIDDetailsList =
          caseParticipantRole_eoObj
            .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

        if (caseParticipantRoleIDDetailsList.dtls.size() > 0) {

          // Read the concern name
          concernRoleKey.concernRoleID =
            caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
          concernRoleNameDetails =
            concernRoleObj.readConcernRoleName(concernRoleKey);

          // Set details to perform the creation of a communication
          communicationDetails.concernRoleID =
            caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
          communicationDetails.caseID = hearingCaseID.hearingCaseID.caseID;
          communicationDetails.correspondentConcernRoleID =
            caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
          // BEGIN, CR00202766, MC
          // correspondentTypeCode is not a mandatory entity field only set it
          // if the
          // correspondence is going to the primary client
          caseHeaderKey.caseID = hearingCaseID.hearingCaseID.caseID;

          if (CaseHeaderFactory.newInstance().readParticipantRoleID(
            caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
            communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
          }
          // END, CR00202766
          communicationDetails.typeCode = COMMUNICATIONTYPE.LETTER;
          communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
          communicationDetails.correspondentName =
            concernRoleNameDetails.concernRoleName;
          final SystemUser systemUser = SystemUserFactory.newInstance();

          communicationDetails.userName =
            systemUser.getUserDetails().userName;

          // Determine rejection or approval notice
          if (dtls.modifyHearingRepFeeDetails.feeApprovedCode
            .equals(FEEAPPROVED.APPROVED)) {

            // Send fee approval notice
            communicationDetails.subjectText =
              BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEFEEAPPROVED
                .getMessageText();
            communicationDetails.communicationText =
              GeneralAppealConstants.kSpace;
          } else if (dtls.modifyHearingRepFeeDetails.feeApprovedCode
            .equals(FEEAPPROVED.REJECTED)) {

            // Send fee rejection notice
            communicationDetails.subjectText =
              BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEFEEREJECTED
                .getMessageText();

            communicationDetails.communicationText =
              GeneralAppealConstants.kSpace;
          }

          communicationDetails.communicationDate = Date.getCurrentDate();

          // Create the communication
          final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
            new XSLTemplateIDCodeKey();

          xslTemplateIDCodeKey.templateIDCode =
            TEMPLATEIDCODE.APPEALFEELETTER;
          xslTemplateIDCodeKey.localeIdentifier =
            TransactionInfo.getProgramLocale();

          final XSLTemplateUtility xslTemplateUtilityObj =
            XSLTemplateUtilityFactory.newInstance();

          final XSLTemplateInstanceKey xslTemplateInstanceKey =
            xslTemplateUtilityObj
              .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

          proFormaCommDetails.assign(communicationDetails);
          proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
          proFormaCommDetails.proFormaVersionNo =
            xslTemplateInstanceKey.templateVersion;
          proFormaCommDetails.addressID =
            concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
          // BEGIN, CR00293187, CD
          generateDocumentDetails.communicationID =
            communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

          if (!readHearingRepresentativeDetails.feeApprovedCode
            .equals(dtls.modifyHearingRepFeeDetails.feeApprovedCode)
            || !readHearingRepresentativeDetails.feeAmount
              .equals(dtls.modifyHearingRepFeeDetails.feeAmount)) {

            generateDocumentDetails.dtls.documentIDCode =
              TEMPLATEIDCODE.APPEALFEELETTER;

            // Set data set key and type
            generateDocumentDetails.dtls.dataSetType = DATASETTYPE.FEE_LETTER;
            generateDocumentDetails.dtls.dataSetPrimaryKey =
              dtls.hearingRepresentativeIDKey.hearingRepresentativeID;

            // Generate the document
            appealProFormaDocumentGenerationObj
              .createConcernRoleProFormaDoc(generateDocumentDetails);
            // END, CR00293187
          }

        } else {

          caseHeaderKey.caseID = hearingCaseID.hearingCaseID.caseID;

          // Read the case owner
          // retrieves the orgObjectLinkID
          ownerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

          // Read current user
          final SystemUser systemUser = SystemUserFactory.newInstance();
          final String currentUser = systemUser.getUserDetails().userName;

          if (!currentUser.equals(ownerDetails.userName)
            && (!readHearingRepresentativeDetails.feeApprovedCode
              .equals(dtls.modifyHearingRepFeeDetails.feeApprovedCode) || !readHearingRepresentativeDetails.feeAmount
              .equals(dtls.modifyHearingRepFeeDetails.feeAmount))) {

            // Set Notification details
            standardManualTaskDtls.dtls.concerningDtls.caseID =
              appealCaseIDKey.caseID;

            standardManualTaskDtls.dtls.taskDtls.comments =
              GeneralAppealConstants.kSpace;

            // Determine rejection or approval notice
            if (dtls.modifyHearingRepFeeDetails.feeApprovedCode
              .equals(FEEAPPROVED.APPROVED)) {

              // Send fee approval notice
              standardManualTaskDtls.dtls.taskDtls.subject =
                BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEFEEAPPROVED
                  .getMessageText();

            } else if (dtls.modifyHearingRepFeeDetails.feeApprovedCode
              .equals(FEEAPPROVED.REJECTED)) {

              // Send fee rejection notice
              standardManualTaskDtls.dtls.taskDtls.subject =
                BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_REPRESENTATIVEFEEREJECTED
                  .getMessageText();
            }

            standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
              Appeal.kAppealNotificationTask;

            standardManualTaskDtls.dtls.assignDtls.assignmentID =
              ownerDetails.userName;

            // Create the notification
            notificationObj
              .createWorkAllocationNotification(standardManualTaskDtls);

          }

        }

      }

    }

    // END HARP 35566
  }

  // ___________________________________________________________________________

  /**
   * Service layer method to send a notification to the hearing representative.
   * 
   * @param dtls
   * The details of the hearing representative
   * @return
   * Any informational messages
   */
  @Override
  public InformationalMsgDtlsList sendNotification(
    final CreateHearingRepresentativeDetails dtls) throws AppException,
    InformationalException {

    // Return of informational messages
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // InformationalManager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingDateAndType hearingDateAndTypeObj = new HearingDateAndType();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Variables for checking if sufficient time for correspondence
    final HearingTimeDetails hearingTimeDetails = new HearingTimeDetails();
    HearingScheduleDate hearingScheduleDate;

    // Determine the scheduled date for the hearing
    hearingKey.hearingID = dtls.hearingRepresentativeDetails.hearingID;
    hearingScheduleDate = hearingObj.readScheduledDate(hearingKey);
    hearingTimeDetails.scheduledDateTime =
      hearingScheduleDate.scheduledDateTime;

    // Check for sufficient time for correspondence
    if (!hearing_boObj.isSufficientTimeForCorrespondence(hearingTimeDetails).isSufficientTime) {

      // If there is not enough time, inform the user
      final LocalisableString insufficientTime =
        new LocalisableString(BPOSCHEDULECORRESPONDENCE.ERR_TIME_INSUFFICIENT);

      informationalManager.addInformationalMsg(insufficientTime,
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);

      final String[] warnings =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls =
          new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

      }

    } // BEGIN, HARP 46985, AC
    // else {

    // Read hearing type
    hearingKey.hearingID = dtls.hearingRepresentativeDetails.hearingID;
    hearingDateAndTypeObj = hearingObj.readScheduledDateAndType(hearingKey);

    // is hearing type location?
    if (hearingDateAndTypeObj.typeCode.equals(HEARINGTYPE.LOCATION)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULELOCATIONREP;

    } // is hearing type phone?
    else if (hearingDateAndTypeObj.typeCode.equals(HEARINGTYPE.PHONE)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEPHONEREP;

    } // if here - must be home
    else if (hearingDateAndTypeObj.typeCode.equals(HEARINGTYPE.HOME)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEHOMEREP;

    } else if (hearingDateAndTypeObj.typeCode.equals(HEARINGTYPE.DESK)) {
      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEDESKREP;

    } else if (hearingDateAndTypeObj.typeCode
      .equals(HEARINGTYPE.HEARINGREVIEW)) {

      // Set document code
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALSCHEDULEREVIEWREP;

    } else {

      // Unknown Hearing Type
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_UNKNOWN_HEARING_TYPE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Set data set key and type
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.SCHEDULE_NOTICE;
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      dtls.hearingRepresentativeDetails.caseParticipantRoleID;

    // }

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      dtls.hearingRepresentativeDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Read the concern name
    concernRoleKey.concernRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // Set details to perform the creation of a communication
    communicationDetails.concernRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    communicationDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    communicationDetails.correspondentConcernRoleID =
      dtls.representativeRegistrationDetails.representativeDtls.concernRoleID;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = hearingCaseID.hearingCaseID.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;

    communicationDetails.subjectText =
      BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_HEARINGNOTICESUBJECTTEXT
        .getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.communicationDate = Date.getCurrentDate();

    // Create the communication
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      generateDocumentDetails.dtls.documentIDCode;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187

    // Log all exceptions (if any)
    informationalManager.failOperation();

    return informationalMsgDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Service layer method to validate the status of a hearing representative
   * 
   * @param dtls
   * The details of the hearing representative
   */
  @Override
  protected void validateHearingStatus(
    final ValidateHearingRepresentativeHearingStatusDetails dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtlsObj =
      new HearingCaseStatusDtls();

    // Read status
    hearingKey.hearingID = dtls.hearingIDKeyHR.hearingIDKeyHR.hearingID;
    hearingCaseStatusDtlsObj =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    if (dtls.participatedCode.equals(HEARINGPARTICIPATION.PARTICIPATED)
      || dtls.participatedCode.equals(HEARINGPARTICIPATION.NOSHOW)) {

      // Check to see if hearing has been held
      if (!hearingCaseStatusDtlsObj.statusCode
        .equals(HEARINGSTATUS.COMPLETED)
        && !hearingCaseStatusDtlsObj.statusCode
          .equals(HEARINGSTATUS.ADJOURNED)) {

        // Hearing has not been held yet
        final AppException e =
          new AppException(
            BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_HEARINGNOTHELD);

        e.arg(CodeTable.getOneItem(HEARINGPARTICIPATION.TABLENAME,
          dtls.participatedCode));
        throw e;
      }
    } else {

      // Hearing status must be scheduled.
      if (!hearingCaseStatusDtlsObj.statusCode
        .equals(HEARINGSTATUS.SCHEDULED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_HEARINGNOTSCHEDULED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to validate a hearing case has a third party
   * participant.
   * 
   * @param dtls
   * The details of the hearing representative
   */
  @Override
  protected void validateThirdParty(final HearingIDKeyHR dtls)
    throws AppException, InformationalException {

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // CaseParticipantRole object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList =
      new CaseParticipantRoleIDDetailsList();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = dtls.hearingIDKeyHR.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Retrieve third party participants
    caseParticipantRoleCaseAndTypeKey.caseID =
      hearingCaseID.hearingCaseID.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;
    caseParticipantRoleIDDetailsList =
      caseParticipantRole
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // if no third party participants found
    if (caseParticipantRoleIDDetailsList.dtls.size() == 0) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_THIRDPARTYNOTEXIST);
    }
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to read hearing representative details used
   * when modifying representative fee.
   * 
   * @param key
   * The ID of the hearing representative
   */
  @Override
  public ModifyHearingRepFeeDetails readForModifyFee(
    final HearingRepresentativeIDKey key) throws AppException,
    InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new curam.appeal.sl.entity.struct.HearingRepresentativeIDKey();
    curam.appeal.sl.entity.struct.ReadHearingRepresentativeDetails readHearingRepresentativeDetails;

    // HearingObj objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Return structure
    final ModifyHearingRepFeeDetails modifyHearingRepFeeDetails =
      new ModifyHearingRepFeeDetails();

    // Perform read
    modifyHearingRepFeeDetails.modifyHearingRepFeeDetails =
      hearingRepresentativeObj
        .readForModifyFee(key.hearingRepresentativeIDKey);

    // Read hearing id
    hearingRepresentativeIDKey.hearingRepresentativeID =
      key.hearingRepresentativeIDKey.hearingRepresentativeID;
    readHearingRepresentativeDetails =
      hearingRepresentativeObj.read(hearingRepresentativeIDKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID =
      readHearingRepresentativeDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    return modifyHearingRepFeeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validate that the hearing representative may be canceled.
   * 
   * @param dtls
   * dtls to validate
   */
  @Override
  protected void validateCancel(final HearingRepHearingIDCPRID dtls)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Case Participant Role Variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_Obj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails;
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    // Read status
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Hearing status must be scheduled.
    if (!hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_NOT_SCHEDULED);

    }

    // Check if case participant role already canceled
    caseParticipantRoleKey.caseParticipantRoleID = dtls.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails =
      caseParticipantRole_Obj
        .readTypeAndStatusAndParticipant(caseParticipantRoleKey);

    if (typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGWITNESS.ERR_HEARING_WITNESS_FV_STATUS_ALREADY_CANCELED);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate an insert.
   * 
   * @param dtls
   * The insert hearing representative details to validate
   */
  @Override
  protected void
    validateInsert(final CreateHearingRepresentativeDetails dtls)
      throws AppException, InformationalException {

    // Validate hearing status
    final ValidateHearingRepresentativeHearingStatusDetails validateHearingRepresentativeHearingStatusDetails =
      new ValidateHearingRepresentativeHearingStatusDetails();

    validateHearingRepresentativeHearingStatusDetails.hearingIDKeyHR.hearingIDKeyHR.hearingID =
      dtls.hearingRepresentativeDetails.hearingID;

    validateHearingRepresentativeHearingStatusDetails.participatedCode =
      HEARINGPARTICIPATION.NOTHELD;

    // BEGIN, CR00125090, RKi
    // validates if at least one participant is selected.
    if (dtls.caseParticipantRoleIDs.equals(CuramConst.gkEmpty)) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_SELECT_ATLEAST_ONE_PARTICIPANT);
    }
    // END, CR00125090

    if (dtls.representativeRegistrationDetails.representativeDtls.concernRoleID != 0
      && dtls.representativeRegistrationDetails.representativeDtls.representativeName
        .length() > 0) {

      throw new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_EXISTING_AND_CREATE);
    }

    validateHearingStatus(validateHearingRepresentativeHearingStatusDetails);
  }

  // END, 35450

  // ___________________________________________________________________________
  /**
   * Method to validate modify representatives.
   * 
   * @param dtls
   * The modify hearing representative details to validate
   */
  @Override
  protected void
    validateModify(final ModifyHearingRepresentativeDetails dtls)
      throws AppException, InformationalException {

    // HearingRepresentative object
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingRepresentativeIDKey hearingRepresentativeIDKey =
      new curam.appeal.sl.entity.struct.HearingRepresentativeIDKey();
    curam.appeal.sl.entity.struct.ReadHearingRepresentativeDetails readHearingRepresentativeDetails;

    // ValidateHearingRepresentativeHearingStatusDetails object
    final ValidateHearingRepresentativeHearingStatusDetails validateHearingRepresentativeHearingStatusDetails =
      new ValidateHearingRepresentativeHearingStatusDetails();

    // Read hearing id
    hearingRepresentativeIDKey.hearingRepresentativeID =
      dtls.hearingRepresentativeIDKey.hearingRepresentativeID;
    readHearingRepresentativeDetails =
      hearingRepresentativeObj.read(hearingRepresentativeIDKey);

    // Validate hearing status
    validateHearingRepresentativeHearingStatusDetails.hearingIDKeyHR.hearingIDKeyHR.hearingID =
      readHearingRepresentativeDetails.hearingID;
    validateHearingRepresentativeHearingStatusDetails.participatedCode =
      dtls.modifyDetails.participatedCode;
    validateHearingStatus(validateHearingRepresentativeHearingStatusDetails);

    // HearingIDKeyHR object
    final HearingIDKeyHR hearingIDKeyHR = new HearingIDKeyHR();

    // Validate third party representatives
    if (dtls.modifyDetails.behalfOfCode.equals(ONBEHALFOF.THIRDPARTY)) {

      hearingIDKeyHR.hearingIDKeyHR.hearingID =
        readHearingRepresentativeDetails.hearingID;
      hearingIDKeyHR.hearingIDKeyHR.hearingID =
        readHearingRepresentativeDetails.hearingID;
      validateThirdParty(hearingIDKeyHR);
    }

  }

}
