/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.ClauseContractTextFactory;
import curam.appeal.sl.entity.intf.ClauseContractText;
import curam.appeal.sl.entity.struct.ClauseContractTextDtls;
import curam.appeal.sl.entity.struct.ClauseContractTextKey;
import curam.appeal.sl.entity.struct.ClauseCount;
import curam.appeal.sl.entity.struct.ClauseNameLanguageCodeAndRecordStatus;
import curam.appeal.sl.entity.struct.ClauseSearchByCategoryKey;
import curam.appeal.sl.entity.struct.ContractTextID;
import curam.appeal.sl.struct.ClauseKey;
import curam.appeal.sl.struct.ClauseListByCategoryDetailsList;
import curam.appeal.sl.struct.ClauseListByCategoryKey;
import curam.appeal.sl.struct.ClauseName;
import curam.appeal.sl.struct.CreateClauseDetails;
import curam.appeal.sl.struct.ListClauseDetails;
import curam.appeal.sl.struct.ModifyClauseDetails;
import curam.appeal.sl.struct.ReadClauseDetails;
import curam.appeal.sl.struct.ReadForViewClauseDetails;
import curam.appeal.sl.struct.RemoveClauseDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CONTRACTTEXTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.ContractTextFactory;
import curam.core.sl.entity.intf.ContractText;
import curam.core.sl.entity.struct.CancelContractTextDetails;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.core.sl.entity.struct.ContractTextKey;
import curam.message.BPOCLAUSE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * This business process class provides the service layer for administration of
 * standard clauses used in decision texts
 */
public abstract class Clause extends curam.appeal.sl.base.Clause {

  /**
   * Creates a new Clause
   * 
   * @param key
   * The details of the new Clause
   */
  @Override
  public void create(final CreateClauseDetails key) throws AppException,
    InformationalException {

    // Variables for Contract Text entity layer
    final ContractText contractTextObj = ContractTextFactory.newInstance();
    final ContractTextDtls contractTextDtls = new ContractTextDtls();

    // Variables for Clause entity layer
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextDtls clauseContractTextDtls =
      new ClauseContractTextDtls();

    // Check the clause details and throw an exception if there is a problem
    validateCreate(key);

    // Insert the new Contract Text for this clause
    contractTextDtls.typeCode = CONTRACTTEXTTYPE.APPEALS;
    contractTextDtls.contractText = key.contractText;
    contractTextDtls.languageCode = key.languageCode;
    contractTextDtls.recordStatus = RECORDSTATUS.NORMAL;
    contractTextObj.insert(contractTextDtls);

    // Insert the new Clause
    clauseContractTextDtls.contractTextID = contractTextDtls.contractTextID;
    clauseContractTextDtls.categoryCode = key.categoryCode;
    clauseContractTextDtls.clauseName = key.clauseName;
    clauseContractTextDtls.comments = key.comments;
    clauseContractTextObj.insert(clauseContractTextDtls);
  }

  /**
   * Gets the name of a Clause
   * 
   * @param key
   * The unique identifier of the Clause
   * 
   * @return The name of the Clause
   */
  @Override
  public ClauseName getName(final ClauseKey key) throws AppException,
    InformationalException {

    // Return variable
    final ClauseName clauseName = new ClauseName();

    // Variables for ClauseContractText entity layer
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextKey clauseContractTextKey =
      new ClauseContractTextKey();

    // Use the entity layer to read the name of the clause
    clauseContractTextKey.clauseContractTextID = key.clauseContractTextID;
    clauseName.clauseContractTextName =
      clauseContractTextObj.readName(clauseContractTextKey);

    return clauseName;
  }

  /**
   * Lists all clauses
   * 
   * @return List of all clauses
   */
  @Override
  public ListClauseDetails list() throws AppException, InformationalException {

    // Return variable
    final ListClauseDetails listClauseDetails = new ListClauseDetails();

    // Entity object for ClauseContractText
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();

    // Search all the clauses & initialize the output details struct
    // with the search result.
    listClauseDetails.searchClauseContractTextDetails =
      clauseContractTextObj.searchAllClauses();

    return listClauseDetails;
  }

  /**
   * Lists all clauses within one category
   * 
   * @param key
   * Category for list of clauses
   * 
   * @return List clauses for this category
   */
  @Override
  public ClauseListByCategoryDetailsList listByCategory(
    final ClauseListByCategoryKey key) throws AppException,
    InformationalException {

    // Return variable
    final ClauseListByCategoryDetailsList clauseListByCategoryDetailsList =
      new ClauseListByCategoryDetailsList();

    // Entity object for ClauseContractText
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseSearchByCategoryKey clauseSearchByCategoryKey =
      new ClauseSearchByCategoryKey();

    // Search for active clauses by category
    clauseSearchByCategoryKey.categoryCode = key.categoryCode;
    clauseSearchByCategoryKey.recordStatusCode = RECORDSTATUS.NORMAL;
    clauseListByCategoryDetailsList.clauseSearchByCategoryDetailsList =
      clauseContractTextObj.searchActiveByCategory(clauseSearchByCategoryKey);
    // BEGIN, CR00168216, VK
    // Replace the new line single character to individual characters
    // and it is needed to print in the word document properly.
    final int clauseListByCategoryDetailsListSize =
      clauseListByCategoryDetailsList.clauseSearchByCategoryDetailsList.dtls
        .size();

    for (int i = 0; i < clauseListByCategoryDetailsListSize; i++) {
      clauseListByCategoryDetailsList.clauseSearchByCategoryDetailsList.dtls
        .item(i).description =
        clauseListByCategoryDetailsList.clauseSearchByCategoryDetailsList.dtls
          .item(i).description.replaceAll(CuramConst.gkNewLine,
          GeneralAppealConstants.kNewLineReplace);
    }
    // END, CR00168216
    return clauseListByCategoryDetailsList;
  }

  /**
   * Modifies the details of a clause
   * 
   * @param details The clause details for modification
   */
  @Override
  public void modify(final ModifyClauseDetails details) throws AppException,
    InformationalException {

    // Variables for ClauseContractText entity
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextKey clauseContractTextKey =
      new ClauseContractTextKey();
    ContractTextID contractTextID = new ContractTextID();

    // Variables for ContractText entity
    final ContractText contractTextObj = ContractTextFactory.newInstance();
    final ContractTextKey contractTextKey = new ContractTextKey();

    // Validate the details for modification
    validateModify(details);

    // Get the contract text ID
    clauseContractTextKey.clauseContractTextID =
      details.modifyClauseContractTextDetails.clauseContractTextID;
    contractTextID =
      clauseContractTextObj.readContractTextID(clauseContractTextKey);

    // Modify the contract text details
    contractTextKey.contractTextID = contractTextID.contractTextID;
    contractTextObj
      .modify(contractTextKey, details.modifyContractTextDetails);

    // Modify the clause details
    clauseContractTextKey.clauseContractTextID =
      details.modifyClauseContractTextDetails.clauseContractTextID;

    clauseContractTextObj.modifyDetails(clauseContractTextKey,
      details.modifyClauseContractTextDetails);

  }

  /**
   * Reads for the details of a Clause
   * 
   * @param key
   * The unique identifier of a clause
   * 
   * @return The details of the Clause
   */
  @Override
  public ReadClauseDetails read(final ClauseKey key) throws AppException,
    InformationalException {

    // Return variable
    final ReadClauseDetails readClauseDetails = new ReadClauseDetails();

    // Variables for ClauseContractText entity
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextKey clauseContractTextKey =
      new ClauseContractTextKey();

    // Read the clause details from the entity layer
    clauseContractTextKey.clauseContractTextID = key.clauseContractTextID;

    readClauseDetails.readClauseContractTextDetails =
      clauseContractTextObj.readDetails(clauseContractTextKey);

    return readClauseDetails;
  }

  /**
   * Reads for the details of a Clause for viewing
   * 
   * @param key
   * The unique identifier of a clause
   * 
   * @return The details of the Clause for viewing
   */
  @Override
  public ReadForViewClauseDetails readForView(final ClauseKey key)
    throws AppException, InformationalException {

    // Return variable
    final ReadForViewClauseDetails readForViewClauseDetails =
      new ReadForViewClauseDetails();

    // Service layer variable for clause details
    ReadClauseDetails readClauseDetails;

    // Use service layer to read clause details
    readClauseDetails = read(key);

    // Select the clause details needed for the view page
    readForViewClauseDetails.categoryCode =
      readClauseDetails.readClauseContractTextDetails.categoryCode;
    readForViewClauseDetails.comments =
      readClauseDetails.readClauseContractTextDetails.comments;
    readForViewClauseDetails.clauseName =
      readClauseDetails.readClauseContractTextDetails.clauseName;
    readForViewClauseDetails.contractText =
      readClauseDetails.readClauseContractTextDetails.contractText;
    readForViewClauseDetails.languageCode =
      readClauseDetails.readClauseContractTextDetails.languageCode;
    readForViewClauseDetails.recordStatusCode =
      readClauseDetails.readClauseContractTextDetails.recordStatusCode;

    // Get the version number of the ContractText entity because it
    // will be needed as a page parameter for the remove page,
    // whereas the ClauseContractText version number is not needed here.
    readForViewClauseDetails.versionNo =
      readClauseDetails.readClauseContractTextDetails.contractTextVersionNo;

    return readForViewClauseDetails;
  }

  /**
   * Removes the clause from active status
   * 
   * @param key The unique identifier for the clause
   */
  @Override
  public void remove(final RemoveClauseDetails key) throws AppException,
    InformationalException {

    // Variables for ContractText entity
    final ContractText contractTextObj = ContractTextFactory.newInstance();
    final ContractTextKey contractTextKey = new ContractTextKey();
    final CancelContractTextDetails cancelContractTextDetails =
      new CancelContractTextDetails();

    // Variables for ClauseContractText entity
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextKey clauseContractTextKey =
      new ClauseContractTextKey();
    ContractTextID contractTextID;

    // Get the key for the contract text from the key for the clause
    clauseContractTextKey.clauseContractTextID = key.clauseContractTextID;
    contractTextID =
      clauseContractTextObj.readContractTextID(clauseContractTextKey);
    contractTextKey.contractTextID = contractTextID.contractTextID;

    // Cancel the status of the contract text
    cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelContractTextDetails.versionNo = key.versionNo;
    contractTextObj.cancel(contractTextKey, cancelContractTextDetails);
  }

  /**
   * Validates the creation of a new clause
   * 
   * @param key
   * The details of the new clause
   */
  @Override
  protected void validateCreate(final CreateClauseDetails key)
    throws AppException, InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Variables for ClauseContractText entity
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseNameLanguageCodeAndRecordStatus clauseNameLanguageCodeAndRecordStatus =
      new ClauseNameLanguageCodeAndRecordStatus();
    ClauseCount clauseCount;

    // Search for active clauses with the same name and language
    clauseNameLanguageCodeAndRecordStatus.clauseName = key.clauseName;
    clauseNameLanguageCodeAndRecordStatus.languageCode = key.languageCode;
    clauseNameLanguageCodeAndRecordStatus.recordStatusCode =
      RECORDSTATUS.NORMAL;

    clauseCount =
      clauseContractTextObj
        .countActiveByNameAndLanguage(clauseNameLanguageCodeAndRecordStatus);

    // If there are active clauses with this name and language then fail
    // validation
    if (clauseCount.count > 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOCLAUSE.ERR_CLAUSE_XFV_NAME_LANGUAGE), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kError);
    }

    // Throw exceptions for any validation errors found
    informationalManager.failOperation();
  }

  /**
   * Validates the modification of an existing clause
   * 
   * @param key
   * The clause details for modification
   */
  @Override
  protected void validateModify(final ModifyClauseDetails key)
    throws AppException, InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Variables for ClauseContractText entity
    final ClauseContractText clauseContractTextObj =
      ClauseContractTextFactory.newInstance();
    final ClauseContractTextKey clauseContractTextKey =
      new ClauseContractTextKey();
    ClauseNameLanguageCodeAndRecordStatus clauseNameLanguageCodeAndRecordStatus;
    ClauseCount clauseCount;

    // Get the existing name for this clause
    clauseContractTextKey.clauseContractTextID =
      key.modifyClauseContractTextDetails.clauseContractTextID;
    clauseNameLanguageCodeAndRecordStatus =
      clauseContractTextObj.readLanguageCodeAndName(clauseContractTextKey);

    // If the name has been modified then validate that there is no active
    // clause with this language and the modified name
    if (!clauseNameLanguageCodeAndRecordStatus.clauseName
      .equals(key.modifyClauseContractTextDetails.clauseName)) {

      clauseNameLanguageCodeAndRecordStatus.clauseName =
        key.modifyClauseContractTextDetails.clauseName;
      clauseNameLanguageCodeAndRecordStatus.recordStatusCode =
        RECORDSTATUS.NORMAL;

      clauseCount =
        clauseContractTextObj
          .countActiveByNameAndLanguage(clauseNameLanguageCodeAndRecordStatus);

      if (clauseCount.count > 0) {
        informationalManager.addInformationalMsg(new AppException(
          BPOCLAUSE.ERR_CLAUSE_XFV_NAME_LANGUAGE), CuramConst.gkEmpty,
          curam.util.exception.InformationalElement.InformationalType.kError);
      }
    }

    // Throw exceptions for any validation errors found
    informationalManager.failOperation();
  }

}
