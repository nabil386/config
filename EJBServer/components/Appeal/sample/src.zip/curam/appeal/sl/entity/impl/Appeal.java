/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.IndexAppealSynchronizationFactory;
import curam.appeal.sl.entity.struct.ActiveAppealCaseKey;
import curam.appeal.sl.entity.struct.AllAppealParticipantsKey;
import curam.appeal.sl.entity.struct.AppealCaseIDCurrentDateKey;
import curam.appeal.sl.entity.struct.AppealCaseTabDetailKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchByCaseRefKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchByHearingDateKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchKeyDtls;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.AppealModifyDetails;
import curam.appeal.sl.entity.struct.AppealParticipantsKey;
import curam.appeal.sl.entity.struct.AppealRelatedByCaseKey;
import curam.appeal.sl.entity.struct.AppealRelatedByTypeStatusKey;
import curam.appeal.sl.entity.struct.AppealTimeConstraintKey;
import curam.appeal.sl.entity.struct.CountActiveAppealsByRoleParticipantIDKey;
import curam.appeal.sl.entity.struct.CountAppealedItemsKey;
import curam.appeal.sl.entity.struct.CountRelatedCasesActiveAppealsByCaseIDKey;
import curam.appeal.sl.entity.struct.OrganisationAppellantTabDetailList;
import curam.appeal.sl.entity.struct.SearchActiveByImplCaseKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.CASERELATIONSHIPTYPECODE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOAPPEAL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.type.Date;

/**
 * The appeal of an adverse decision that was decided by the organization.
 */
public abstract class Appeal extends curam.appeal.sl.entity.base.Appeal {

  // ___________________________________________________________________________
  /**
   * Generates a unique appealID.
   * 
   * @param details appeal details
   */
  @Override
  protected void preinsert(final AppealDtls details) throws AppException,
    InformationalException {

    // Validate the details
    validate(details);

  }

  // ___________________________________________________________________________
  /**
   * Posts an event with the details of the Appeal that was just inserted
   * 
   * @param details The details of the Appeal.
   */
  @Override
  protected void postinsert(final AppealDtls details) throws AppException,
    InformationalException {

    IndexAppealSynchronizationFactory.newInstance().insert(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the appeal details
   * 
   * @param details The details of the appeal
   */
  @Override
  public void validate(final AppealDtls details) throws AppException,
    InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // CaseID must be supplied
    if (details.caseID == 0) {

      throw new AppException(BPOAPPEAL.ERR_APPEAL_FV_CASEID);

    }

    // Appeal type must be entered
    if (details.appealTypeCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_APPEALTYPE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Difficulty code must be provided
    if (details.difficultyCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_DIFFICULTYCODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Calls validate method prior to modification
   * 
   * @param key Identifies the case
   * @param dtls The appeal case details to be modified
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /**
   * The key cannot be removed as it
   * would be used in the base modifyAppeal
   * method.
   */
  protected void premodifyAppeal(final AppealKey key,
    final AppealModifyDetails dtls) throws AppException,
    InformationalException {

    validateModify(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Handles appeal case modification validation
   * 
   * @param dtls The appeal case details to be validated
   */
  @Override
  protected void validateModify(final AppealModifyDetails dtls)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Difficulty code must be provided
    if (dtls.difficultyCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_DIFFICULTYCODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the read for appeals by case uses a linked cases
   * relationship reason code and a product appeal relationship type code.
   * 
   * @param key The caseID, relationship reasonCode and relationship typeCode
   * to read for related appeal cases.
   */
  @Override
  protected void presearchAppealByCase(final AppealRelatedByCaseKey key)
    throws AppException, InformationalException {

    key.reasonCode = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    key.typeCode = CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the read for appeals by case uses a linked cases
   * relationship reason code and a product appeal relationship type code.
   * 
   * @param key The caseID, appealTypeCode and statusCode, relationship
   * typeCode and relationship reasonCode to read related
   * appeal cases for.
   */
  @Override
  protected void presearchRelatedAppealDetailsByTypeStatus(
    final AppealRelatedByTypeStatusKey key) throws AppException,
    InformationalException {

    key.reasonCode = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    key.typeCode = CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL;
  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key The appeal case ID, the constraint type and the record status
   * @deprecated
   */
  @Deprecated
  protected void prereadLeadCaseTimeConstraintByType(
    final AppealTimeConstraintKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key Contains the participant role and type, the appeal type
   * and status
   */
  @Override
  protected void presearchActiveByTypeAndParticipantAndRole(
    final ActiveAppealCaseKey key) throws AppException,
    InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;

  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key Contains the impl case ID and case status to set.
   */
  @Override
  protected void
    presearchActiveByImplCase(final SearchActiveByImplCaseKey key)
      throws AppException, InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key Contains the participant role and type, the appeal type
   * and status
   */
  @Override
  protected void precountActiveByTypeAndParticipantAndRole(
    final ActiveAppealCaseKey key) throws AppException,
    InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;

  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key The appeal case ID, the constraint type and the record status
   */
  @Override
  protected void prereadTimeConstraintByTypeAndProductCase(
    final AppealTimeConstraintKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Set the appellant & respondent participant type codes
   * 
   * @param key Search criteria for the appeal search
   */
  @Override
  protected void presearchByCaseReference(
    final AppealDatabaseSearchByCaseRefKey key) throws AppException,
    InformationalException {

    key.appellantParticipantRoleType = CASEPARTICIPANTROLETYPE.APPELLANT;
    key.respondentParticipantRoleType = CASEPARTICIPANTROLETYPE.RESPONDENT;
  }

  // ___________________________________________________________________________
  /**
   * Set the types to appellant & respondent participant type codes
   * 
   * @param key Search criteria for the appeal search
   * @deprecated Since Curam 6.0 SP1, replaced with
   * {presearchAppeal(AppealDatabaseSearchKeyDtls)}. See release note:
   * CR00289218.
   */
  @Deprecated
  @Override
  protected void presearchByAppealSearchCriteria(
    final AppealDatabaseSearchKey key) throws AppException,
    InformationalException {

    key.appellantParticipantRoleType = CASEPARTICIPANTROLETYPE.APPELLANT;
    key.respondentParticipantRoleType = CASEPARTICIPANTROLETYPE.RESPONDENT;
  }

  /**
   * Set the types to appellant & respondent participant type codes
   * 
   * @param key Search criteria for the appeal search
   */
  @Override
  protected void presearchAppeal(final AppealDatabaseSearchKeyDtls key)
    throws AppException, InformationalException {

    key.appellantParticipantRoleType = CASEPARTICIPANTROLETYPE.APPELLANT;
    key.respondentParticipantRoleType = CASEPARTICIPANTROLETYPE.RESPONDENT;

  }

  // ___________________________________________________________________________
  /**
   * Set the types to appellant & respondent participant type codes
   * 
   * @param key Search criteria for the appeal search
   */
  @Override
  protected void presearchByHearingDate(
    final AppealDatabaseSearchByHearingDateKey key) throws AppException,
    InformationalException {

    key.appellantParticipantRoleType = CASEPARTICIPANTROLETYPE.APPELLANT;
    key.respondentParticipantRoleType = CASEPARTICIPANTROLETYPE.RESPONDENT;
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyAppeal
   */
  @Override
  public void modify(final AppealKey key, final AppealModifyDetails dtls)
    throws AppException, InformationalException {

    AppealFactory.newInstance().modifyAppeal(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * Set the record status to ensure that only active records are returned
   * 
   * @param key The appeal case ID, the constraint type and the record status
   */
  @Override
  public void pregetShortestActiveTimeConstraintByTypeAndAppealCase(
    final AppealTimeConstraintKey key) {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // BEGIN, CR00195128, MC
  // ___________________________________________________________________________
  /**
   * Counts the active appeals for a given participant.
   * 
   * @param countAppealsForParticipantKey The appeal participant ID and the
   * details seen below.
   */
  @Override
  protected
    void
    precountActiveAppealsByRoleParticipantID(
      final CountActiveAppealsByRoleParticipantIDKey countAppealsForParticipantKey)
      throws AppException, InformationalException {

    countAppealsForParticipantKey.appealCaseType = CASETYPECODE.APPEAL;
    countAppealsForParticipantKey.recordStatus = RECORDSTATUS.NORMAL;
    countAppealsForParticipantKey.appellantParticipantType =
      CASEPARTICIPANTROLETYPE.APPELLANT;
    countAppealsForParticipantKey.respondentParticipantType =
      CASEPARTICIPANTROLETYPE.RESPONDENT;
  }

  // ___________________________________________________________________________
  /**
   * Counts the active appeals on cases associated with a given case ID.
   * 
   * @param countAppealsKey The appeal case ID and the details seen below.
   */
  @Override
  protected void precountRelatedCasesActiveAppealsByCaseID(
    final CountRelatedCasesActiveAppealsByCaseIDKey countAppealsKey)
    throws AppException, InformationalException {

    countAppealsKey.cancelledCaseStatus = CASESTATUS.CANCELED;
    countAppealsKey.closedCaseStatus = CASESTATUS.CLOSED;
    countAppealsKey.recordStatus = RECORDSTATUS.NORMAL;
  }

  // END, CR00195128

  // BEGIN, CR00196348, MC
  // ___________________________________________________________________________
  /**
   * Counts the active appeals items on cases associated with a given case ID.
   * 
   * @param countAppealsKey The appeal case ID and the details seen below.
   */
  @Override
  protected void prereadCountAppealedItemsTabDetail(
    final CountAppealedItemsKey countAppealedItemsKey) throws AppException,
    InformationalException {

    countAppealedItemsKey.appealCaseTypeCode = CASETYPECODE.APPEAL;
    countAppealedItemsKey.issueCaseTypeCode = CASETYPECODE.ISSUE;
    countAppealedItemsKey.productDeliveryCaseTypeCode =
      CASETYPECODE.PRODUCTDELIVERY;
    countAppealedItemsKey.integratedCaseTypeCodeOpt =
      CASETYPECODE.INTEGRATEDCASE;
    countAppealedItemsKey.normalRecordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Read the case details for the tab for a given case ID.
   * 
   * @param key The appeal case ID and the details seen below.
   */
  @Override
  protected void
    prereadAppealCaseTabDetails(final AppealCaseTabDetailKey key)
      throws AppException, InformationalException {

    key.currentDate = Date.getCurrentDate();

  }

  // ___________________________________________________________________________
  /**
   * Read the case participant details for the tab for a given case ID.
   * 
   * @param key The appeal case ID and the details seen below.
   * @deprecated
   */
  @Override
  @Deprecated
  protected void presearchAppealParticipantTabDetails(
    final AppealParticipantsKey appealParticipantsKey) throws AppException,
    InformationalException {

    appealParticipantsKey.normalRecordStatus = RECORDSTATUS.NORMAL;
    // If the respondent case participant role type is not set the respondent
    // is the product provider.
    appealParticipantsKey.respondentCaseParticipantTypeCode =
      CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER;
    appealParticipantsKey.appellantCaseParticipantTypeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;
  }

  // BEGIN, CR00288724, MC
  // ___________________________________________________________________________
  /**
   * Read the case participant details for the tab for a given case ID.
   * 
   * @param key The appeal case ID and the details seen below.
   */
  @Override
  protected void presearchAllAppealParticipantTabDetails(
    final AllAppealParticipantsKey appealParticipantsKey)
    throws AppException, InformationalException {

    appealParticipantsKey.normalRecordStatus = RECORDSTATUS.NORMAL;
    // If the respondent case participant role type is not set the respondent
    // is the product provider.
    appealParticipantsKey.respondentCaseParticipantTypeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;
    appealParticipantsKey.productProviderCaseParticipantTypeCode =
      CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER;
    appealParticipantsKey.appellantCaseParticipantTypeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;
  }

  // END, CR00288724
  // ___________________________________________________________________________
  /**
   * This operation returns the Appellants who if type Organization. The return
   * struct will be assigned to the struct used for the participants list
   * (AppealParticipantTabDetails) so the type field should always be appellant.
   * 
   * @param appealCaseIDCurrentDateKey The appeal case ID and current date.
   */
  @Override
  @Deprecated
  protected void postsearchOrganisationAppellantTabDetail(
    final AppealCaseIDCurrentDateKey appealCaseIDCurrentDateKey,
    final OrganisationAppellantTabDetailList organisationAppellantList)
    throws AppException, InformationalException {

    for (int i = 0; i < organisationAppellantList.dtls.size(); i++) {
      organisationAppellantList.dtls.item(i).caseParticipantTypeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
    }
  }

  // END, CR00196348

}
