/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2006 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingActivityLinkFactory;
import curam.appeal.sl.entity.intf.HearingActivityLink;
import curam.appeal.sl.entity.struct.HearingActivityIDKey;
import curam.core.struct.ActivityAttendeeStatusDetails;
import curam.core.struct.Count;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainActivityKey;
import curam.message.BPOAPPEALMAINTAINACTIVITY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Functions for manipulating user activity information and interfacing
 * with the activity and MaintainActivity objects.
 * 
 */
public abstract class AppealMaintainUserActivity extends
  curam.appeal.sl.base.AppealMaintainUserActivity {

  // ___________________________________________________________________________
  /**
   * Modifies user activity. Ignores activity modification conflicts.
   * 
   * Activities related to an appeal case, specifically a scheduled hearing for
   * an appeal case, cannot be managed outside of the appeals module.
   * 
   * @param details Returned activity details
   */
  @Override
  public void modifyUserActivityIgnoreConflict(
    final MaintainActivityDetails details) throws AppException,
    InformationalException {

    // Variables for determining if the activity is related to an appeal case
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    Count count;

    // Determine if the activity is related to an appeal case or not; do this by
    // searching for any activityID matches in the HearingActivityLink table.
    hearingActivityIDKey.activityID = details.activityID;
    count = hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);

    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALMAINTAINACTIVITY.ERR_APPEALMAINTAINACTIVITY_FV_HEARINGAPPEALLINKEXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

  }

  // ___________________________________________________________________________
  /**
   * Cancels specified user activity.
   * 
   * Activities related to an appeal case, specifically a scheduled hearing for
   * an appeal case, cannot be managed outside of the appeals module.
   * 
   * @param key Identifies activity to be canceled
   */
  @Override
  public void cancelUserActivity(final MaintainActivityKey key)
    throws AppException, InformationalException {

    // Variables for determining if the activity is related to an appeal case
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    Count count;

    // Determine if the activity is related to an appeal case or not; do this by
    // searching for any activityID matches in the HearingActivityLink table.
    hearingActivityIDKey.activityID = key.activityID;
    count = hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);

    if (count.numberOfRecords > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALMAINTAINACTIVITY.ERR_APPEALMAINTAINACTIVITY_FV_HEARINGAPPEALLINKEXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies the specified user activity and warns of any conflicts with other
   * activities.
   * 
   * Activities related to an appeal case, specifically a scheduled hearing for
   * an appeal case, cannot be managed outside of the appeals module.
   * 
   * @param details Activity details
   */
  @Override
  public void modifyUserActivityWarnConflict(
    final MaintainActivityDetails details) throws AppException,
    InformationalException {

    // Variables for determining if the activity is related to an appeal case
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    Count count;

    // Determine if the activity is related to an appeal case or not; do this by
    // searching for any activityID matches in the HearingActivityLink table.
    hearingActivityIDKey.activityID = details.activityID;
    count = hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);

    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALMAINTAINACTIVITY.ERR_APPEALMAINTAINACTIVITY_FV_HEARINGAPPEALLINKEXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies the record status of an attendee record.
   * 
   * Activities related to an appeal case, specifically a scheduled hearing for
   * an appeal case, cannot be managed outside of the appeals module.
   * 
   * @param details The activityID, the attendee ID and type and the record
   * status
   */
  @Override
  public void modifyActivityAttendeeStatus(
    final ActivityAttendeeStatusDetails details) throws AppException,
    InformationalException {

    // Variables for determining if the activity is related to an appeal case
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    Count count;

    // Determine if the activity is related to an appeal case or not; do this by
    // searching for any activityID matches in the HearingActivityLink table.
    hearingActivityIDKey.activityID = details.activityID;
    count = hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);

    if (count.numberOfRecords > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALMAINTAINACTIVITY.ERR_APPEALMAINTAINACTIVITY_FV_HEARINGAPPEALLINKEXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

}
