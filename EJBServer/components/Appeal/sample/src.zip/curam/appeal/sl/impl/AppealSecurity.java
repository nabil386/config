/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2005,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.struct.AppealCountDetails;
import curam.appeal.sl.entity.struct.AppealSecurityDtls;
import curam.appeal.sl.entity.struct.AppealSecurityKey;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.struct.AppealSecurityDetails;
import curam.appeal.sl.struct.AppealSecurityIDList;
import curam.appeal.sl.struct.AppealSecurityModifyDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.LocationSecurityCheckFactory;
import curam.core.fact.SecurityLinkFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.LocationSecurityCheck;
import curam.core.intf.SecurityLink;
import curam.core.intf.Users;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CheckLocationSecurityKey;
import curam.core.struct.RoleByCaseStatusTypeKey;
import curam.core.struct.SecurityResult;
import curam.core.struct.UserLocationDetails;
import curam.core.struct.UserNameDetails;
import curam.core.struct.UsersKey;
import curam.message.BPOAPPEALSECURITY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * Service layer methods for the appeal security functionality.
 */
public abstract class AppealSecurity extends
  curam.appeal.sl.base.AppealSecurity {

  /**
   * Identifies a Maintenance Security Check for a case
   */
  public static final short kMaintainSecurityCheck = 1;

  /**
   * Identifies an Approval Security Check for a case
   */
  public static final short kApproveSecurityCheck = 2;

  /**
   * Identifies a Read Security Check for a case
   */
  public static final short kReadSecurityCheck = 3;

  /**
   * Identifies an Decision Approval Security Check for a case
   */
  public static final short kApproveDecisionSecurityCheck = 4;

  /**
   * Identifies a Create Security Check for a case
   */
  public static final short kCreateSecurityCheck = 5;

  // ___________________________________________________________________________
  /**
   * Returns the appeal security SID references and location security level
   * 
   * @return The appeal security data
   */
  @Override
  public AppealSecurityDetails readSecurity() throws AppException,
    InformationalException {

    // Appeal security object and structs
    final curam.appeal.sl.entity.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.entity.fact.AppealSecurityFactory.newInstance();
    final AppealSecurityDetails appealSecurityDetails =
      new AppealSecurityDetails();

    // Read the single entity row for the appeal security entity.
    try {

      appealSecurityDetails.dtls = appealSecurityObj.readSecurityDetails();

    } catch (final curam.util.exception.RecordNotFoundException e) {// Return an
      // empty
      // struct as
      // there is
      // nothing set
      // yet
    }

    return appealSecurityDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the appeal security SID references and location security level
   * 
   * @return The appeal security data
   */
  @Override
  public AppealSecurityModifyDetails readForModify() throws AppException,
    InformationalException {

    // Appeal security object and structs
    final curam.appeal.sl.entity.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.entity.fact.AppealSecurityFactory.newInstance();
    final AppealSecurityModifyDetails appealSecurityModifyDetails =
      new AppealSecurityModifyDetails();

    // Read the single entity row for the appeal security entity.
    try {

      appealSecurityModifyDetails.dtls = appealSecurityObj.readForModify();

    } catch (final curam.util.exception.RecordNotFoundException e) {// Return an
      // empty
      // struct as
      // there is
      // nothing set
      // yet
    }

    return appealSecurityModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the appeal security SID references and location security level
   * 
   * @param details the appeal security data
   */
  @Override
  public void modify(final AppealSecurityModifyDetails details)
    throws AppException, InformationalException {

    // Appeal security object and structs
    final curam.appeal.sl.entity.intf.AppealSecurity appealSecurityObj =
      curam.appeal.sl.entity.fact.AppealSecurityFactory.newInstance();
    final AppealSecurityDtls appealSecurityDtls = new AppealSecurityDtls();
    final AppealSecurityKey appealSecurityKey = new AppealSecurityKey();

    // Count struct
    AppealCountDetails appealCountDetails;

    // Set the record details
    appealSecurityDtls.approveDecisionSID = details.dtls.approveDecisionSID;
    appealSecurityDtls.approveSID = details.dtls.approveSID;
    appealSecurityDtls.createSID = details.dtls.createSID;
    appealSecurityDtls.maintainSID = details.dtls.maintainSID;
    appealSecurityDtls.readSID = details.dtls.readSID;
    appealSecurityDtls.locationSecurityLevel =
      details.dtls.locationSecurityLevel;
    appealSecurityDtls.versionNo = details.dtls.versionNo;

    // Check if a record already exists in the entity
    appealCountDetails = appealSecurityObj.countRecords();

    // Modify or create the single entity row for the appeal security
    // entity.
    if (appealCountDetails.recordCount == 0) {

      // Create new row
      appealSecurityObj.insert(appealSecurityDtls);

    } else {

      // Set the key struct and modify
      appealSecurityKey.appealSecurityID = details.dtls.appealSecurityID;
      appealSecurityDtls.appealSecurityID = details.dtls.appealSecurityID;
      appealSecurityObj.modify(appealSecurityKey, appealSecurityDtls);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method performs an Appeal Case Security Check.
   * 
   * @param key
   * The case ID to be checked and type of security right
   */
  @Override
  public void validateSecurity(final ValidateSecurityKey key)
    throws AppException, InformationalException {

    // Appeal Security Variables
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    AppealSecurityDetails appealSecurityDetails;

    // Appeal Entity Variables
    CaseOwnerDetails caseOwnerDetails;
    // BEGIN, CR00071911, RKi
    final UserNameDetails userNameDetails_supervisor = new UserNameDetails();
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();
    UserNameAndFullName userNameAndFullName = new UserNameAndFullName();
    // END, CR00071911

    // Case Header Variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;
    final RoleByCaseStatusTypeKey roleByCaseStatusTypeKey =
      new RoleByCaseStatusTypeKey();

    // Data Based Security Variables
    SecurityResult securityResult;
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();

    // Participant Variables
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();

    // Location Security Check Variables
    final LocationSecurityCheck locationSecurityCheckObj =
      LocationSecurityCheckFactory.newInstance();
    final CheckLocationSecurityKey checkLocationSecurityKey =
      new CheckLocationSecurityKey();

    // User Details Variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UserLocationDetails userLocationDetails;

    // Local Variables use to calculate combinations of security rights
    // BEGIN, CR00287728, MC
    boolean maintainRights = false;
    boolean approveDecisionRights = false;
    boolean approveRights = false;
    boolean readRights = false;
    boolean createRights = false;

    // END, CR00287728

    // Get the user name for authorization checking
    usersKey.userName = TransactionInfo.getProgramUser();

    // Get participant for this case
    caseHeaderKey.caseID = key.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
    participantKeyStruct.participantID = caseHeaderDtls.concernRoleID;

    // Check Participant Sensitivity
    securityResult =
      dataBasedSecurity.checkParticipantSecurity(participantKeyStruct);
    if (!securityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALSECURITY.ERR_XFV_SENSITIVITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Read for Appeal Security settings
    appealSecurityDetails = appealSecurityObj.readSecurity();

    // Check location based security unless location security level is
    // undefined or if security check type is read-only
    if (key.type != kReadSecurityCheck
      && appealSecurityDetails.dtls.locationSecurityLevel.length() > 0) {

      // Get name of case owner and case supervisor unless creating
      if (key.type == kCreateSecurityCheck) {
        caseOwnerDetails = new CaseOwnerDetails();
        // BEGIN, CR00071911, RKi
      } else {
        caseHeaderKey.caseID = key.caseID;
        roleByCaseStatusTypeKey.caseID = key.caseID;
        // retrieves the orgObjectLinkID
        caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
        userNameAndFullName = caseUserRole.readSupervisor(caseHeaderKey);

        userNameDetails_supervisor.userName = userNameAndFullName.userName;
        // END, CR00071911
      }

      // Check if the user is the case owner or supervisor, unless
      // creating
      if (key.type == kCreateSecurityCheck
        || !caseOwnerDetails.userName.equals(usersKey.userName)
        && !userNameDetails_supervisor.userName.equals(usersKey.userName)) {

        // Get user location
        userLocationDetails = usersObj.readUserLocation(usersKey);
        checkLocationSecurityKey.locationID = userLocationDetails.locationID;

        // Get location security level for Appeals
        checkLocationSecurityKey.locationSecurityLevel =
          appealSecurityDetails.dtls.locationSecurityLevel;

        // Check location based security
        securityResult =
          locationSecurityCheckObj.authorize(checkLocationSecurityKey,
            usersKey);
        if (!securityResult.result) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .throwWithLookup(
              new AppException(BPOAPPEALSECURITY.ERR_XFV_LOCATION),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }

    // BEGIN, CR00287728, MC
    // Determine Maintain rights, inclusive of Create and Approval rights
    if (key.type == kMaintainSecurityCheck) {

      maintainRights =
        appealSecurityDetails.dtls.maintainSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.maintainSID, usersKey.userName)
          || appealSecurityDetails.dtls.approveSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.approveSID, usersKey.userName)
          || appealSecurityDetails.dtls.createSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.createSID, usersKey.userName);

    } else if (key.type == kCreateSecurityCheck) {

      createRights =
        appealSecurityDetails.dtls.createSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.createSID, usersKey.userName);

    } // Determine Read rights, inclusive of all other rights
    else if (key.type == kReadSecurityCheck) {

      readRights =
        appealSecurityDetails.dtls.readSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.readSID, usersKey.userName)
          || appealSecurityDetails.dtls.approveDecisionSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.approveDecisionSID, usersKey.userName)
          || appealSecurityDetails.dtls.maintainSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.maintainSID, usersKey.userName)
          // Include the associated maintain rights
          || appealSecurityDetails.dtls.approveSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.approveSID, usersKey.userName)
          || appealSecurityDetails.dtls.createSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.createSID, usersKey.userName);

    } else if (key.type == kApproveSecurityCheck) {

      approveRights =
        appealSecurityDetails.dtls.approveSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.approveSID, usersKey.userName);

    } else if (key.type == kApproveDecisionSecurityCheck) {

      approveDecisionRights =
        appealSecurityDetails.dtls.approveDecisionSID.length() > 0
          && curam.util.security.Authorisation.isSIDAuthorised(
            appealSecurityDetails.dtls.approveDecisionSID, usersKey.userName);
    }
    // END, CR00287728

    // Validate security rights unless there is no SID defined for that right
    if (key.type == kMaintainSecurityCheck
      && appealSecurityDetails.dtls.maintainSID.length() > 0
      && !maintainRights) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALSECURITY.ERR_XFV_MAINTAIN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (key.type == kApproveDecisionSecurityCheck
      && appealSecurityDetails.dtls.approveDecisionSID.length() > 0
      && !approveDecisionRights) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALSECURITY.ERR_XFV_DECISION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (key.type == kApproveSecurityCheck
      && appealSecurityDetails.dtls.approveSID.length() > 0 && !approveRights) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(new AppException(BPOAPPEALSECURITY.ERR_XFV_APPROVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (key.type == kCreateSecurityCheck
      && appealSecurityDetails.dtls.createSID.length() > 0 && !createRights) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(new AppException(BPOAPPEALSECURITY.ERR_XFV_CREATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (key.type == kReadSecurityCheck
      && appealSecurityDetails.dtls.readSID.length() > 0 && !readRights) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(new AppException(BPOAPPEALSECURITY.ERR_XFV_READ),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method returns the list of appeal security identifiers
   * 
   * @return appealSecurityIDList
   * The list of appeal security identifiers
   */
  @Override
  public AppealSecurityIDList listAppealSIDs() throws AppException,
    InformationalException {

    // Return variable
    final AppealSecurityIDList appealSecurityIDList =
      new AppealSecurityIDList();

    // Security Link variables
    final SecurityLink securityLinkObj = SecurityLinkFactory.newInstance();
    final curam.core.struct.SIDTypeKey sIDTypeKey =
      new curam.core.struct.SIDTypeKey();

    // List all Security Identifiers of type Appeal
    sIDTypeKey.sidType = curam.codetable.SECURITYIDENTIFIERTYPE.APPEAL;
    appealSecurityIDList.securityIDList =
      securityLinkObj.getSidsByType(sIDTypeKey);

    return appealSecurityIDList;
  }
}
