/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.impl;

import curam.appeal.util.impl.GeneralAppealConstants;
import curam.core.sl.entity.struct.Task_waDtls;
import curam.core.sl.entity.struct.Task_waKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.UserNameAndIDStruct;
import curam.core.struct.UserNameDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Provides the deadline task escalation functions for appeal deadline tasks.
 */
public abstract class CaseDeadlineFunction extends
  curam.appeal.sl.base.CaseDeadlineFunction {

  // ___________________________________________________________________________
  /**
   * This deadline function provides the escalation processing for the overall
   * appeal deadline task.
   * 
   * @param key
   * The product appeal process to activate.
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void processAppealDeadline(final Task_waDtls key)
    throws AppException, InformationalException {// do nothing

  }

  // ___________________________________________________________________________
  /**
   * This deadline function provides the escalation processing for the
   * implementation deadline task.
   * 
   * @param key
   * The product appeal process to activate.
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void processImplementationDeadline(final Task_waDtls key)
    throws AppException, InformationalException {// do nothing

  }

  // ___________________________________________________________________________
  /**
   * This deadline function provides the escalation processing for the schedule
   * hearing deadline task.
   * 
   * @param key
   * The product appeal process to activate.
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void processScheduleHearingDeadline(final Task_waDtls key)
    throws AppException, InformationalException {// do nothing

  }

  // ___________________________________________________________________________
  /**
   * This deadline function provides the escalation processing for the witness
   * statement deadline task.
   * 
   * @param key
   * The product appeal process to activate.
   */
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  public void processWitnessStatementDeadline(final Task_waDtls key)
    throws AppException, InformationalException {// do nothing

  }

  // ___________________________________________________________________________
  /**
   * Returns a users previously unassigned supervisor. If all supervisors have
   * been assigned to the current task then the most senior supervisor details
   * are returned.
   * 
   * @param userNameDetails
   * Contains User Name
   * @param taskWaKey
   * Contains the task id
   * @return Supervisor Name & ID
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected UserNameAndIDStruct getUserSupervisor(
    final UserNameDetails userNameDetails, final Task_waKey taskWaKey)
    throws AppException, InformationalException {

    final UserNameAndIDStruct userNameAndIDStruct = new UserNameAndIDStruct();

    return userNameAndIDStruct;

  }

  // ___________________________________________________________________________
  /**
   * Returns the Case Reference and the Status details of a particular case for
   * which the Case ID is passed in CaseSearchKey as a parameter.
   * 
   * @param key
   * Contains the Case ID for which the Case Reference Number is to
   * read
   * @return CaseReferenceAndStatusDetails Contains the CaseReference Number and
   * the Status details of Case
   */
  @Override
  public CaseReferenceAndStatusDetails getCaseReference(
    final CaseSearchKey key) throws AppException, InformationalException {

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    final CaseReferenceAndStatusDetails caseReferenceAndStatusDetails =
      caseHeaderObj.readCaseReferenceAndStatusByCaseID(key);

    return caseReferenceAndStatusDetails;
  }
}
