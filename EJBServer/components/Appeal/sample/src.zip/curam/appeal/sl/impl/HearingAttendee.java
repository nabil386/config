/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingActivityLinkFactory;
import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.intf.HearingActivityLink;
import curam.appeal.sl.entity.intf.HearingUserRole;
import curam.appeal.sl.entity.struct.HearingActivityIDDetails;
import curam.appeal.sl.entity.struct.HearingCaseUserRoleDetails;
import curam.appeal.sl.entity.struct.HearingID;
import curam.appeal.sl.entity.struct.HearingIDStatusType;
import curam.appeal.sl.entity.struct.HearingIDUserRoleDetails;
import curam.appeal.sl.entity.struct.HearingIDUserStatusTypeKey;
import curam.appeal.sl.entity.struct.HearingUserAttendeeActivityDetails;
import curam.appeal.sl.entity.struct.HearingUserAttendeeDetails;
import curam.appeal.sl.entity.struct.HearingUserNameStatusKey;
import curam.appeal.sl.entity.struct.HearingUserRoleParticipatedDetails;
import curam.appeal.sl.entity.struct.HearingUserRoleStatusKey;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.HearingAttendeeDetails;
import curam.appeal.sl.struct.HearingAttendeeModifyDetails;
import curam.appeal.sl.struct.HearingAttendeeNotifyDetails;
import curam.appeal.sl.struct.HearingAttendeeRemoveDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.HearingUserRoleIDKey;
import curam.appeal.sl.struct.ValidateModifyDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.HEARINGACTIVITYTYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.MaintainUserActivityFactory;
import curam.core.fact.NotificationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.MaintainUserActivity;
import curam.core.intf.Notification;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.struct.CaseUserRoleKey;
import curam.core.sl.entity.struct.ModifyRecordStatusDetails;
import curam.core.sl.entity.struct.ModifyTypeCodeDetails;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.struct.Count;
import curam.core.struct.IndicatorStruct;
import curam.core.struct.MaintainActivityKey;
import curam.message.BPOHEARINGATTENDEE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * Service layer methods for the hearing attendee functionality.
 */
public abstract class HearingAttendee extends
  curam.appeal.sl.base.HearingAttendee {

  // ___________________________________________________________________________
  /**
   * Displays details about a user attendee for the hearing.
   * 
   * @param key The hearing user role ID
   * 
   * @return the user attendee details associated with the hearing
   */
  @Override
  public HearingAttendeeDetails view(final HearingUserRoleIDKey key)
    throws AppException, InformationalException {

    // The return data struct
    final HearingAttendeeDetails hearingAttendeeDetails =
      new HearingAttendeeDetails();

    // Hearing user role object and variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingUserRoleIDKey hearingUserRoleIDKey =
      new curam.appeal.sl.entity.struct.HearingUserRoleIDKey();
    HearingUserAttendeeDetails hearingUserAttendeeDetails;
    HearingID hearingID;

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();

    // Set the hearing user role id struct
    hearingUserRoleIDKey.hearingUserRoleID =
      key.hearingUserRoleIDKey.hearingUserRoleID;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();
    final HearingKey hearingKey = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Get Hearing ID and Hearing Case ID
    hearingID = hearingUserRoleObj.readHearingID(hearingUserRoleIDKey);
    hearingKey.hearingKey.hearingID = hearingID.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    // Validate security for reading the Hearing Case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Find hearing user attendee details
    hearingUserAttendeeDetails =
      hearingUserRoleObj.readUserAttendeeDetails(hearingUserRoleIDKey);

    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      hearingUserAttendeeDetails.orgObjectLinkID;
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
    hearingAttendeeDetails.hearingUserAttendeeDetails.fullName =
      caseOwnerDetails.userFullName;
    // END, CR00053295

    // Assign user attendee details to the return struct.
    hearingAttendeeDetails.hearingUserAttendeeDetails =
      hearingUserAttendeeDetails;

    return hearingAttendeeDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method modifies a hearing user attendee
   * 
   * @param dtls Identifies the hearing
   */
  @Override
  public void modify(final HearingAttendeeModifyDetails dtls)
    throws AppException, InformationalException {

    // Hearing user role object and variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingUserRoleIDKey hearingUserRoleIDKey =
      new curam.appeal.sl.entity.struct.HearingUserRoleIDKey();
    final HearingUserRoleParticipatedDetails hearingUserRoleParticipatedDetails =
      new HearingUserRoleParticipatedDetails();
    HearingIDUserRoleDetails hearingIDUserRoleDetails;
    HearingID hearingID;

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();

    // Case user role object and structs
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    final ModifyTypeCodeDetails modifyTypeCodeDetails =
      new ModifyTypeCodeDetails();

    // Validation struct
    final ValidateModifyDetails validateModifyDetails =
      new ValidateModifyDetails();

    // Set the hearing user role id struct
    hearingUserRoleIDKey.hearingUserRoleID = dtls.hearingUserRoleID;

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();
    final HearingKey hearingKey = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Get Hearing ID and Hearing Case ID
    hearingID = hearingUserRoleObj.readHearingID(hearingUserRoleIDKey);
    hearingKey.hearingKey.hearingID = hearingID.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    // Validate security for reading the Hearing Case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the data
    validateModifyDetails.hearingUserRoleID = dtls.hearingUserRoleID;
    validateModifyDetails.participatedCode = dtls.participatedCode;
    validateModifyDetails.typeCode = dtls.typeCode;
    validateModify(validateModifyDetails);

    // Find the details needed for the modify
    hearingIDUserRoleDetails =
      hearingUserRoleObj.readRoleHearingAndUser(hearingUserRoleIDKey);

    // Modify the type
    caseUserRoleKey.caseUserRoleID = hearingIDUserRoleDetails.caseUserRoleID;
    modifyTypeCodeDetails.typeCode = dtls.typeCode;
    modifyTypeCodeDetails.versionNo = dtls.versionNo;
    caseUserRoleObj.modifyType(caseUserRoleKey, modifyTypeCodeDetails);

    // Modify the hearing user role record
    hearingUserRoleParticipatedDetails.participatedCode =
      dtls.participatedCode;
    hearingUserRoleParticipatedDetails.versionNo =
      dtls.hearingUserRoleVersionNo;
    hearingUserRoleObj.modifyParticipatedCode(hearingUserRoleIDKey,
      hearingUserRoleParticipatedDetails);
  }

  // ___________________________________________________________________________
  /**
   * Removes an attendee from the hearing
   * 
   * @param dtls The details of the attendee to be removed
   */
  @Override
  public void remove(final HearingAttendeeRemoveDetails dtls)
    throws AppException, InformationalException {

    // Hearing user role object and variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingUserRoleIDKey hearingUserRoleIDKey =
      new curam.appeal.sl.entity.struct.HearingUserRoleIDKey();
    final HearingUserRoleIDKey hearingUserRoleIDKey_po =
      new HearingUserRoleIDKey();
    final HearingUserNameStatusKey hearingUserNameStatusKey =
      new HearingUserNameStatusKey();
    HearingIDUserRoleDetails hearingIDUserRoleDetails;
    HearingID hearingID;

    // Hearing activity link object and variables
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingUserAttendeeActivityDetails hearingUserAttendeeActivityDetails =
      new HearingUserAttendeeActivityDetails();
    HearingActivityIDDetails hearingActivityIDDetails;

    // Hearing object
    final Hearing hearingObj = HearingFactory.newInstance();
    final HearingAttendeeNotifyDetails hearingAttendeeNotifyDetails =
      new HearingAttendeeNotifyDetails();

    // Case user role object
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleKey caseUserRoleKey = new CaseUserRoleKey();
    final ModifyRecordStatusDetails modifyRecordStatusDetails =
      new ModifyRecordStatusDetails();

    // UserActivity object and variables
    final MaintainUserActivity maintainUserActivityObj =
      MaintainUserActivityFactory.newInstance();
    final MaintainActivityKey maintainActivityKey = new MaintainActivityKey();
    final IndicatorStruct indicatorStruct = new IndicatorStruct();

    // Count struct
    Count count;

    // Set the hearing user role id struct
    hearingUserRoleIDKey.hearingUserRoleID = dtls.hearingUserRoleID;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();
    final HearingKey hearingKey = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Get Hearing ID and Hearing Case ID
    hearingID = hearingUserRoleObj.readHearingID(hearingUserRoleIDKey);
    hearingKey.hearingKey.hearingID = hearingID.hearingID;
    hearingCaseID = hearingObj.getCase(hearingKey);

    // Validate security for maintaining the Hearing Case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the data
    hearingUserRoleIDKey_po.hearingUserRoleIDKey = hearingUserRoleIDKey;
    validateRemove(hearingUserRoleIDKey_po);

    // Grab hearing user attendee's details
    hearingIDUserRoleDetails =
      hearingUserRoleObj.readRoleHearingAndUser(hearingUserRoleIDKey);

    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      hearingIDUserRoleDetails.orgObjectLinkID;
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

    // Modify the record status
    caseUserRoleKey.caseUserRoleID = hearingIDUserRoleDetails.caseUserRoleID;
    modifyRecordStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
    modifyRecordStatusDetails.versionNo = dtls.versionNo;
    caseUserRoleObj.modifyRecordStatus(caseUserRoleKey,
      modifyRecordStatusDetails);

    // Count number of hearing user roles for user and hearing
    hearingUserNameStatusKey.hearingID = hearingIDUserRoleDetails.hearingID;

    // Record status is canceled
    hearingUserNameStatusKey.recordStatus = RECORDSTATUS.CANCELLED;

    hearingUserNameStatusKey.orgObjectLinkID =
      hearingIDUserRoleDetails.orgObjectLinkID;
    count =
      hearingUserRoleObj
        .countActiveByHearingAndUser(hearingUserNameStatusKey);

    // Check if there are no more associated hearing user roles
    if (count.numberOfRecords <= 0) {

      // Find the activity id associated with type, user and hearing
      // There is the possibility that multiple records will be returned,
      // however our business logic does not allow for this and so we
      // perform a read, and assume only one record exists.
      hearingUserAttendeeActivityDetails.hearingID =
        hearingIDUserRoleDetails.hearingID;
      hearingUserAttendeeActivityDetails.userName = caseOwnerDetails.userName;
      hearingUserAttendeeActivityDetails.typeCode =
        HEARINGACTIVITYTYPE.HEARING;
      hearingActivityIDDetails =
        hearingActivityLinkObj
          .readActiveActivityByTypeHearingIDAndUser(hearingUserAttendeeActivityDetails);

      // Cancel the activity
      indicatorStruct.changeAllIndicator = false;
      maintainActivityKey.activityID = hearingActivityIDDetails.activityID;
      maintainUserActivityObj.cancelUserActivity(maintainActivityKey,
        indicatorStruct);

    }

    // Notify that the user has been removed
    hearingAttendeeNotifyDetails.hearingID =
      hearingIDUserRoleDetails.hearingID;
    hearingAttendeeNotifyDetails.inviteInd = false;
    hearingAttendeeNotifyDetails.userName = caseOwnerDetails.userName;
    notify(hearingAttendeeNotifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Validates user details before removing from a hearing
   * 
   * @param key The hearingUserRoleID for the user
   */
  @Override
  protected void validateRemove(final HearingUserRoleIDKey key)
    throws AppException, InformationalException {

    // Hearing user role object and variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingUserRoleIDKey hearingUserRoleIDKey =
      new curam.appeal.sl.entity.struct.HearingUserRoleIDKey();
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();
    HearingIDStatusType hearingIDStatusType;

    // Count variable
    Count count;
    final InformationalManager informationalManager =
      new InformationalManager();

    // Set the hearing user role id
    hearingUserRoleIDKey.hearingUserRoleID =
      key.hearingUserRoleIDKey.hearingUserRoleID;

    // Grab the needed variables for the validate
    hearingIDStatusType =
      hearingUserRoleObj.readHearingIDStatusAndRoleType(hearingUserRoleIDKey);

    // Check that user is active
    if (hearingIDStatusType.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      // The user has already been removed
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGATTENDEE.ERR_USER_REMOVED), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Check status and type
    if (!hearingIDStatusType.statusCode.equals(HEARINGSTATUS.SCHEDULED)) {

      // The hearing is not scheduled
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGATTENDEE.ERR_HEARING_NOT_SCHEDULED), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    } else if (hearingIDStatusType.typeCode
      .equals(curam.codetable.CASEUSERROLETYPE.HEARINGOFFICIAL)
      || hearingIDStatusType.typeCode
        .equals(curam.codetable.CASEUSERROLETYPE.HEARINGREVIEWER)) {

      // Count the number of users of type to be removed associated with the
      // hearing
      hearingUserRoleStatusKey.hearingID = hearingIDStatusType.hearingID;
      hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      hearingUserRoleStatusKey.typeCode = hearingIDStatusType.typeCode;
      count =
        hearingUserRoleObj
          .countActiveByHearingAndType(hearingUserRoleStatusKey);

      // Check that there are a minimum number of user of type to remove left
      if (count.numberOfRecords <= 1) {

        // Not enough users to officiate
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGATTENDEE.ERR_REMOVE_INSUFFICIENT_USERS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Log all exceptions (if any)
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Validates user details before modifying the hearing user role
   * 
   * @param dtls The user role details for the hearing
   */
  @Override
  protected void validateModify(final ValidateModifyDetails dtls)
    throws AppException, InformationalException {

    // Hearing user role object and variables
    final HearingUserRole hearingUserRoleObj =
      HearingUserRoleFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingUserRoleIDKey hearingUserRoleIDKey =
      new curam.appeal.sl.entity.struct.HearingUserRoleIDKey();
    final HearingIDUserStatusTypeKey hearingIDUserStatusTypeKey =
      new HearingIDUserStatusTypeKey();
    HearingCaseUserRoleDetails hearingCaseUserRoleDetails;
    final HearingUserRoleStatusKey hearingUserRoleStatusKey =
      new HearingUserRoleStatusKey();

    // Count variable
    Count count;
    final InformationalManager informationalManager =
      new InformationalManager();

    // Set the hearing user role id
    hearingUserRoleIDKey.hearingUserRoleID = dtls.hearingUserRoleID;

    // Grab the needed variables for the validate
    hearingCaseUserRoleDetails =
      hearingUserRoleObj
        .readHearingParticipatedAndUserDetails(hearingUserRoleIDKey);

    // Check that user is active
    if (hearingCaseUserRoleDetails.recordStatus
      .equals(RECORDSTATUS.CANCELLED)) {

      // The user has already been removed
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGATTENDEE.ERR_USER_REMOVED), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Check that participated code has been modified
    if (!hearingCaseUserRoleDetails.participatedCode
      .equals(dtls.participatedCode)) {

      if (hearingCaseUserRoleDetails.statusCode
        .equals(HEARINGSTATUS.SCHEDULED)
        || hearingCaseUserRoleDetails.statusCode
          .equals(HEARINGSTATUS.RESCHEDULED)) {

        // The hearing has not been held yet
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGATTENDEE.ERR_HEARING_NOT_HELD), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);

      } else if (dtls.participatedCode.equals(HEARINGPARTICIPATION.NOTHELD)) {

        // The hearing has been held, and so participated code is invalid
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGATTENDEE.ERR_INVALID_ATTENDANCE), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }
    }

    // Check that the role type is specified
    if (dtls.typeCode == null) {

      // No role type given
      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGATTENDEE.ERR_NO_ROLE_TYPE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    } else if (!hearingCaseUserRoleDetails.typeCode.equals(dtls.typeCode)) {

      // Find any records associated with the user and type
      hearingIDUserStatusTypeKey.hearingID =
        hearingCaseUserRoleDetails.hearingID;
      hearingIDUserStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
      hearingIDUserStatusTypeKey.typeCode = dtls.typeCode;
      final OrgObjectLinkKey arg0 = new OrgObjectLinkKey();

      arg0.orgObjectLinkID = hearingCaseUserRoleDetails.orgObjectLinkID;
      final OrgObjectLinkDtls orgObjectLinkdtls =
        OrgObjectLinkFactory.newInstance().read(arg0);

      hearingIDUserStatusTypeKey.userName = orgObjectLinkdtls.userName;
      count =
        hearingUserRoleObj
          .countActiveByHearingIDTypeAndUser(hearingIDUserStatusTypeKey);

      // Check that the user does not already have this role
      if (count.numberOfRecords > 0) {

        // The user already has this user role
        informationalManager.addInformationalMsg(new AppException(
          BPOHEARINGATTENDEE.ERR_ROLE_EXISTS), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError);
      }

      // Check that the user is not the last official or reviewer
      if (hearingCaseUserRoleDetails.typeCode
        .equals(curam.codetable.CASEUSERROLETYPE.HEARINGOFFICIAL)
        || hearingCaseUserRoleDetails.typeCode
          .equals(curam.codetable.CASEUSERROLETYPE.HEARINGREVIEWER)) {

        // Count the number of users of type associated with the hearing
        hearingUserRoleStatusKey.hearingID =
          hearingCaseUserRoleDetails.hearingID;
        hearingUserRoleStatusKey.recordStatus = RECORDSTATUS.NORMAL;
        hearingUserRoleStatusKey.typeCode =
          hearingCaseUserRoleDetails.typeCode;
        count =
          hearingUserRoleObj
            .countActiveByHearingAndType(hearingUserRoleStatusKey);

        // Check that there are a minimum number of user of type to remove left
        if (count.numberOfRecords <= 1) {

          // Not enough users to officiate
          informationalManager
            .addInformationalMsg(new AppException(
              BPOHEARINGATTENDEE.ERR_MODIFY_INSUFFICIENT_USERS),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError);
        }
      }

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Sends notification inviting/uninviting user to attend the hearing.
   * 
   * @param dtls The details of the user
   */
  @Override
  protected void notify(final HearingAttendeeNotifyDetails dtls)
    throws AppException, InformationalException {

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    curam.appeal.sl.entity.struct.HearingCaseID hearingCaseID;

    // Notification objects
    final Notification notificationObj = NotificationFactory.newInstance();
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Read hearing case ID
    hearingKey.hearingID = dtls.hearingID;
    hearingCaseID = hearingObj.readCase(hearingKey);

    // Set Notification details
    standardManualTaskDtls.dtls.concerningDtls.caseID = hearingCaseID.caseID;
    standardManualTaskDtls.dtls.assignDtls.assignmentID = dtls.userName;
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
      Appeal.kAppealNotificationTask;
    standardManualTaskDtls.dtls.taskDtls.comments =
      GeneralAppealConstants.kSpace;

    // Check if it is an invite or remove
    if (dtls.inviteInd) {

      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOHEARINGATTENDEE.INF_INVITE_NOTIFICATION_SUBJECT.getMessageText();

    } else {

      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOHEARINGATTENDEE.INF_REMOVE_NOTIFICATION_SUBJECT.getMessageText();

    }

    // Create notification
    notificationObj.createWorkAllocationNotification(standardManualTaskDtls);
  }

}
