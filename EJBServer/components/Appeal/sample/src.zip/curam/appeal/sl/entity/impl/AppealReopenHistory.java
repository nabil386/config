/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealReopenHistoryFactory;
import curam.appeal.sl.entity.struct.AppealReopenHistoryDtls;
import curam.appeal.sl.entity.struct.ReadReopenDetails;
import curam.appeal.sl.entity.struct.ReadReopenDetailsKey;
import curam.appeal.sl.entity.struct.ReopenHistoryCaseIDKey;
import curam.appeal.sl.entity.struct.TimelyIndicatorDetailsList;
import curam.core.impl.CuramConst;
import curam.message.BPOAPPEALREOPENHISTORY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * This process class provides the entity functionality for AppealReopenHistory
 * 
 */
public abstract class AppealReopenHistory extends
  curam.appeal.sl.entity.base.AppealReopenHistory {

  // ___________________________________________________________________________
  /**
   * Entity method to perform pre-insert operations.
   * 
   * @param details The details of the appeal to be reopened
   */
  @Override
  protected void preinsert(final AppealReopenHistoryDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Entity method to validate the appeal cancellation details.
   * 
   * @param details The details of the appeal to be reopened
   */
  @Override
  protected void validateInsert(final AppealReopenHistoryDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // case id must be supplied
    if (details.caseID == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_CASEIDEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // reason code must be supplied
    if (details.reopenReasonCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_REASONCODEEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // reopen date must be supplied
    if (details.reopenDate.isZero()) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_REOPENDATEEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // username must be supplied
    if (details.reopenUserName.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALREOPENHISTORY.ERR_APPEAL_REOPEN_HISTORY_FV_USERNAMEEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchReopenHistoryTimelyIndicator
   */
  @Override
  public TimelyIndicatorDetailsList listReopenHistoryTimelyIndicator(
    final ReopenHistoryCaseIDKey key) throws AppException,
    InformationalException {

    return AppealReopenHistoryFactory.newInstance()
      .searchReopenHistoryTimelyIndicator(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readDetailsAndUserFullName
   */
  @Override
  public ReadReopenDetails read(final ReadReopenDetailsKey key)
    throws AppException, InformationalException {

    return AppealReopenHistoryFactory.newInstance()
      .readDetailsAndUserFullName(key);
  }

}
