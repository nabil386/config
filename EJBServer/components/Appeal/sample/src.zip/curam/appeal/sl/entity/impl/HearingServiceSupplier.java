/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingServiceSupplierFactory;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingParticipationAndStatus;
import curam.appeal.sl.entity.struct.HearingServiceSupplierCloneDetails;
import curam.appeal.sl.entity.struct.HearingServiceSupplierDtls;
import curam.appeal.sl.entity.struct.HearingServiceSupplierIDKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterCaseKey;
import curam.appeal.sl.entity.struct.HearingServiceSupplierInterpreterHearingKey;
import curam.appeal.sl.entity.struct.UpdateNonParticipationDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationKey;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.RECORDSTATUS;
import curam.message.BPOHEARINGSERVICESUPPLIER;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;

/**
 * This process class provides the functionality for the Hearing Service
 * Supplier service layer.
 */
public class HearingServiceSupplier extends
  curam.appeal.sl.entity.base.HearingServiceSupplier {

  /**
   * Method to set default hearing service supplier values
   * 
   * @param dtls The details of the hearing service supplier which we
   * are going to apply default values too.
   */
  @Override
  protected void setDefaults(final HearingServiceSupplierDtls dtls)
    throws AppException, InformationalException {

    dtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

  }

  // BEGIN, HARP-28711, PK
  // __________________________________________________________________________
  /**
   * Method to validate details for inserting a hearing service supplier
   * 
   * @param dtls The details of the hearing service supplier to validate
   */
  @Override
  protected void validateInsert(final HearingServiceSupplierDtls dtls)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Check to see if supplier type is supplied
    if (StringUtil.isNullOrEmpty(dtls.supplierType)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGSERVICESUPPLIER.ERR_HEARINGSERVICESUPPLIER_FV_SUPPLIERTYPENOTINCLUDED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check to see if supplier id is supplied
    if (dtls.supplierLinkID == 0) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGSERVICESUPPLIER.ERR_HEARINGSERVICESUPPLIER_FV_SUPPLIERIDNOTINCLUDED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();
  }

  // __________________________________________________________________________
  /**
   * Method to do an insert
   * 
   * @param details The details of the hearing service supplier to insert
   */
  @Override
  protected void preinsert(final HearingServiceSupplierDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  // END, HARP-28711

  // BEGIN, HARP-31184, PK
  // __________________________________________________________________________
  /**
   * Method to clone hearing interpreter details
   * 
   * @param key The hearing service supplier
   * 
   * @param dtls The details of the hearing service supplier to clone
   */
  @Override
  public void clone(final HearingServiceSupplierIDKey key,
    final HearingKeyDetails dtls) throws AppException, InformationalException {

    // Hearing service supplier variables
    final curam.appeal.sl.entity.intf.HearingServiceSupplier hearingServiceSupplierObj =
      curam.appeal.sl.entity.fact.HearingServiceSupplierFactory.newInstance();
    final HearingServiceSupplierDtls hearingServiceSupplierDtls =
      new HearingServiceSupplierDtls();
    HearingServiceSupplierCloneDetails hearingServiceSupplierCloneDetails;

    try {

      // clone details
      hearingServiceSupplierCloneDetails = readCloneDetails(key);

    } catch (final RecordNotFoundException e) {

      throw new AppException(
        BPOHEARINGSERVICESUPPLIER.ERR_HEARINGSERVICESUPPLIER_FV_RECORDDOESNOTEXIST);

    }

    // assign details for insert
    hearingServiceSupplierDtls.comments =
      hearingServiceSupplierCloneDetails.comments;
    hearingServiceSupplierDtls.supplierLinkID =
      hearingServiceSupplierCloneDetails.supplierLinkID;
    hearingServiceSupplierDtls.supplierType =
      hearingServiceSupplierCloneDetails.supplierType;
    hearingServiceSupplierDtls.hearingID = dtls.hearingID;
    hearingServiceSupplierDtls.participatedCode =
      HEARINGPARTICIPATION.NOTHELD;

    // insert hearing service supplier
    hearingServiceSupplierObj.insert(hearingServiceSupplierDtls);

  }

  // END, HARP-31184, PK

  // ___________________________________________________________________________
  /**
   * Method to set default values for the search
   * 
   * @param key The caseID, recordStatusCode and caseParticipantRole typeCode
   * to read for.
   */
  protected void presearchActiveInterpreterAndCaseParticipantByCaseID(
    final HearingServiceSupplierInterpreterCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.typeCode = CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

  }

  // ___________________________________________________________________________
  /**
   * Method to set default values for the search
   * 
   * @param key The hearingCaseID, recordStatusCode and caseParticipantRole
   * typeCode to read for.
   */
  @Override
  protected void presearchActiveInterpreterAndCaseParticipantByHearingCaseID(
    final HearingServiceSupplierInterpreterCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.typeCode = CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

  }

  // ___________________________________________________________________________
  /**
   * Method to set default values for the search
   * 
   * @param key contains default values for search
   */
  @Override
  protected void presearchActiveInterpreterAndCaseParticipantByHearingID(
    final HearingServiceSupplierInterpreterHearingKey key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.typeCode = CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

  }

  // ___________________________________________________________________________
  /**
   * Method to set default values for the search
   * 
   * @param key The hearingID, recordStatusCode and caseParticipantRole
   * typeCode to read for.
   */
  @Override
  protected void presearchActiveInterpreterNameAndCaseParticipantByHearingID(
    final HearingServiceSupplierInterpreterHearingKey key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.typeCode = CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

  }

  // ___________________________________________________________________________
  /**
   * Sets the fields so that all non participants are updated to no-show
   * 
   * @param key contains the hearing ID and the participation code to search on
   * @param details contains the new participation code
   */
  @Override
  protected void premodifyNonParticipation(
    final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    key.participatedCode = HEARINGPARTICIPATION.NOTHELD;
    details.participatedCode = HEARINGPARTICIPATION.NOSHOW;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing service suppliers are considered when
   * determining the number of service suppliers for a hearing with a specified
   * participation.
   * 
   * @param key The hearingID, participationCode and recordStatus to read for
   */
  @Override
  protected void precountActiveParticipantByHearingParticipation(
    final HearingParticipationAndStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing service suppliers are considered when
   * determining the number of service suppliers for a hearing with a specified
   * participation.
   * 
   * @param key The hearingID, participationCode and recordStatus to read for
   */
  @Override
  protected void precountActiveUserByHearingParticipation(
    final HearingParticipationAndStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyNonParticipation
   */
  @Override
  public void updateNonParticipation(final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    HearingServiceSupplierFactory.newInstance().modifyNonParticipation(key,
      details);
  }
}
