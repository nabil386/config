/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingTranscriptionRequestFactory;
import curam.appeal.sl.entity.intf.HearingTranscriptionRequest;
import curam.appeal.sl.entity.struct.HearingActualTimeDetails;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingCaseUserNameDetails;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingTranscriptionRequestDtls;
import curam.appeal.sl.entity.struct.HearingTranscriptionRequestKey;
import curam.appeal.sl.entity.struct.TranscriptionAttachmentDetails;
import curam.appeal.sl.entity.struct.TranscriptionCaseAttachmentLinkDetails;
import curam.appeal.sl.entity.struct.TranscriptionDateSentDetails;
import curam.appeal.sl.entity.struct.TranscriptionModifyDetails;
import curam.appeal.sl.entity.struct.TranscriptionModifyStatusDetails;
import curam.appeal.sl.entity.struct.TranscriptionRecordCountDetails;
import curam.appeal.sl.entity.struct.TranscriptionRequesterStatusDetails;
import curam.appeal.sl.entity.struct.TranscriptionSearchSummaryDetails;
import curam.appeal.sl.entity.struct.TranscriptionSearchSummaryDetailsList;
import curam.appeal.sl.entity.struct.TranscriptionStatusDetails;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.CancelTranscriptionDetails;
import curam.appeal.sl.struct.CreateTranscriptionDetails;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.ListTranscriptionDetails;
import curam.appeal.sl.struct.ListTranscriptionDetailsList;
import curam.appeal.sl.struct.ModifyTranscriptionDetails;
import curam.appeal.sl.struct.ReadTranscriptionDetails;
import curam.appeal.sl.struct.TranscriptionCaseAttachmentDetails;
import curam.appeal.sl.struct.TranscriptionCaseParticipantDetails;
import curam.appeal.sl.struct.TranscriptionHearingKey;
import curam.appeal.sl.struct.TranscriptionManageAttachmentDetails;
import curam.appeal.sl.struct.TranscriptionRequestKey;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseAttachmentLinkFactory;
import curam.core.fact.MaintainAttachmentFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CaseAttachmentLink;
import curam.core.intf.MaintainAttachment;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullNameDetails;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.struct.AttachmentIDAndAttachmentLinkIDStruct;
import curam.core.struct.CaseAttachmentLinkDtls;
import curam.core.struct.CaseAttachmentLinkKey;
import curam.core.struct.CreateCaseAttachmentDetails;
import curam.core.struct.ModifyAttachmentDetails;
import curam.message.BPOHEARINGTRANSCRIBER;
import curam.message.BPOHEARINGTRANSCRIPTIONREQUEST;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the Hearing Transcription
 * service layer.
 * 
 */
public abstract class HearingTranscription extends
  curam.appeal.sl.base.HearingTranscription {

  // ___________________________________________________________________________
  /**
   * Method to cancel a hearing transcription request
   * 
   * @param details
   * The details of the transcription request to cancel
   */
  @Override
  public void cancel(final CancelTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID = new HearingCaseID();
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    final TranscriptionModifyStatusDetails transcriptionModifyStatusDetails =
      new TranscriptionModifyStatusDetails();

    // Read hearing id
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;
    hearingKeyDetails =
      hearingTranscriptionRequestObj
        .readHearing(hearingTranscriptionRequestKey);

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateCancel(details);

    // populate modify details
    transcriptionModifyStatusDetails.recordStatusCode =
      RECORDSTATUS.CANCELLED;
    transcriptionModifyStatusDetails.versionNo = details.versionNo;

    // set the record status to canceled
    hearingTranscriptionRequestObj.modifyStatus(
      hearingTranscriptionRequestKey, transcriptionModifyStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to create a hearing transcription request
   * 
   * @param details
   * The details of the transcription request to create
   */
  @Override
  public void create(final CreateTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestDtls hearingTranscriptionRequestDtls =
      new HearingTranscriptionRequestDtls();
    final TranscriptionHearingKey transcriptionHearingKey =
      new TranscriptionHearingKey();

    // TranscriptionCaseParticipantDetails object
    TranscriptionCaseParticipantDetails transcriptionCaseParticipantDetails;

    // Unique object variable
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = details.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateCreate(details);

    transcriptionCaseParticipantDetails = createTranscriber(details);

    // Insert the transcription request
    hearingTranscriptionRequestDtls.hearingTranscriptionRequestID =
      uniqueIDObj.getNextID();
    hearingTranscriptionRequestDtls.comments = details.comments;
    hearingTranscriptionRequestDtls.dateDue = details.dateDue;
    hearingTranscriptionRequestDtls.dateRequested = details.dateRequested;
    hearingTranscriptionRequestDtls.dateSentToTranscriber =
      details.dateSentToTranscriber;
    hearingTranscriptionRequestDtls.hearingID = details.hearingID;
    hearingTranscriptionRequestDtls.recordStatusCode = RECORDSTATUS.NORMAL;
    hearingTranscriptionRequestDtls.requestedByID = details.requestedByID;
    hearingTranscriptionRequestDtls.transcriberID =
      transcriptionCaseParticipantDetails.caseParticipantRoleID;

    hearingTranscriptionRequestObj.insert(hearingTranscriptionRequestDtls);

    // Notify owner
    transcriptionHearingKey.hearingID = details.hearingID;
    notifyOwner(transcriptionHearingKey);
  }

  // ___________________________________________________________________________
  /**
   * Method to create an attachment
   * 
   * @param details
   * The attachment details to create
   * @return
   * transcriptionCaseAttachmentDetails the Case Attachment Link ID
   * and the Attachment ID
   */
  @Override
  protected TranscriptionCaseAttachmentDetails createAttachment(
    final TranscriptionManageAttachmentDetails details) throws AppException,
    InformationalException {

    // Return details
    final TranscriptionCaseAttachmentDetails transcriptionCaseAttachmentDetails =
      new TranscriptionCaseAttachmentDetails();

    // MaintainAttachment objects
    final MaintainAttachment maintainAttachmentObj =
      MaintainAttachmentFactory.newInstance();
    final CreateCaseAttachmentDetails createCaseAttachmentDetails =
      new CreateCaseAttachmentDetails();
    AttachmentIDAndAttachmentLinkIDStruct attachmentIDAndAttachmentLinkIDStruct;

    // Hearing Transcription variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID = new HearingCaseID();
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Get the hearing id
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;
    hearingKeyDetails =
      hearingTranscriptionRequestObj
        .readHearing(hearingTranscriptionRequestKey);

    // Read the hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Insert attachment
    createCaseAttachmentDetails.caseID = hearingCaseID.hearingCaseID.caseID;
    createCaseAttachmentDetails.description =
      BPOHEARINGTRANSCRIPTIONREQUEST.INF_HEARINGTRANSCRIPTIONREQUEST_ATTACHMENTDESCRIPTION
        .getMessageText();
    createCaseAttachmentDetails.documentType = DOCUMENTTYPE.STATEMENT;
    createCaseAttachmentDetails.filelocation = details.fileLocation;
    createCaseAttachmentDetails.fileReference = details.fileReferenceNumber;
    createCaseAttachmentDetails.newCaseAttachmentContents =
      details.attachmentContents;
    createCaseAttachmentDetails.newCaseAttachmentName =
      details.attachmentName;
    createCaseAttachmentDetails.receiptDate = Date.getCurrentDate();

    attachmentIDAndAttachmentLinkIDStruct =
      maintainAttachmentObj
        .insertCaseAttachmentDetails(createCaseAttachmentDetails);

    transcriptionCaseAttachmentDetails.caseAttachmentLinkID =
      attachmentIDAndAttachmentLinkIDStruct.caseAttachmentLinkID;

    return transcriptionCaseAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to create a hearing transcriber
   * 
   * @param details
   * The hearing transcription details to validate
   * @return
   * The case participant role id of the transcriber
   */
  @Override
  public TranscriptionCaseParticipantDetails createTranscriber(
    final CreateTranscriptionDetails details) throws AppException,
    InformationalException {

    // Return object
    final TranscriptionCaseParticipantDetails transcriptionCaseParticipantDetails =
      new TranscriptionCaseParticipantDetails();
    long lCaseParticipantRoleID = 0; // holds ID of existing or newly created
    // case participant role record

    // Representative variables
    final Representative representativeObj =
      RepresentativeFactory.newInstance();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
      new CaseIDParticipantRoleKey();
    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList;
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    // Check for newly entered transcriber details.
    if (details.concernRoleID == 0) {
      // Set registration date
      details.representativeRegistrationDetails.representativeRegistrationDetails.registrationDate =
        Date.getCurrentDate();

      // Set the case participant role type
      details.representativeRegistrationDetails.representativeDtls.representativeType =
        REPRESENTATIVETYPE.TRANSCRIBER;

      // Insert the case participant role record
      representativeObj
        .registerRepresentative(details.representativeRegistrationDetails);

      // Update to newly created concern role ID
      details.concernRoleID =
        details.representativeRegistrationDetails.representativeDtls.concernRoleID;
    }

    // Get the hearing case ID
    hearingKey_bo.hearingKey.hearingID = details.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Check for transcriber already associated with case.
    caseIDParticipantRoleKey.caseID = hearingCaseID.hearingCaseID.caseID;
    caseIDParticipantRoleKey.participantRoleID = details.concernRoleID;
    caseParticipantRoleDtlsList =
      caseParticipantRole_eoObj
        .searchByParticipantRoleAndCase(caseIDParticipantRoleKey);

    if (!caseParticipantRoleDtlsList.dtls.isEmpty()) {

      // Should only return one row
      lCaseParticipantRoleID =
        caseParticipantRoleDtlsList.dtls.item(0).caseParticipantRoleID;

    } else {

      // UniqueID object
      final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

      // No existing record found - insert new one
      caseParticipantRoleDtls.caseParticipantRoleID = uniqueIDObj.getNextID();
      caseParticipantRoleDtls.caseID = hearingCaseID.hearingCaseID.caseID;
      caseParticipantRoleDtls.participantRoleID = details.concernRoleID;
      caseParticipantRoleDtls.fromDate = Date.getCurrentDate();
      caseParticipantRoleDtls.recordStatus = RECORDSTATUS.NORMAL;
      caseParticipantRoleDtls.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGTRANSCRIBER;
      caseParticipantRoleDtls.comments = details.comments;
      caseParticipantRole_eoObj.insert(caseParticipantRoleDtls);
      lCaseParticipantRoleID = caseParticipantRoleDtls.caseParticipantRoleID;
    }

    // Update the transcribers case participant role ID with the
    // existing or newly created case participant role ID
    transcriptionCaseParticipantDetails.caseParticipantRoleID =
      lCaseParticipantRoleID;
    return transcriptionCaseParticipantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to create a hearing transcription requests for standalone cases
   * 
   * @param key
   * The hearing transcription id of the hearing transcription
   * requests to list
   * @return
   * list of all hearing transcription requests for a given hearing
   * transcription id
   */
  @Override
  public ListTranscriptionDetailsList list(final TranscriptionHearingKey key)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    TranscriptionSearchSummaryDetailsList transcriptionSearchSummaryDetailsList;
    TranscriptionSearchSummaryDetails transcriptionSearchSummaryDetails;
    final ListTranscriptionDetailsList listTranscriptionDetailsList =
      new ListTranscriptionDetailsList();
    ListTranscriptionDetails listTranscriptionDetails;

    // Hearing variables
    final HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoFullNameDetails caseParticipantRoleFullNameDetails;

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = key.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Search transcription summary by hearing id
    hearingKeyDetails.hearingID = key.hearingID;
    transcriptionSearchSummaryDetailsList =
      hearingTranscriptionRequestObj
        .searchSummaryByHearing(hearingKeyDetails);

    // local variable to count the number of hearing suppliers.
    final int countTranscriptionRequests =
      transcriptionSearchSummaryDetailsList.dtls.items().length;

    // For each transcriber, read transcriber details
    for (int i = 0; i < countTranscriptionRequests; i++) {

      transcriptionSearchSummaryDetails =
        transcriptionSearchSummaryDetailsList.dtls.item(i);

      listTranscriptionDetails = new ListTranscriptionDetails();

      // read the requester full name using the requestedByID
      caseParticipantRole_eoKey.caseParticipantRoleID =
        transcriptionSearchSummaryDetails.requestedByID;
      caseParticipantRoleFullNameDetails =
        caseParticipantRole_eoObj.readFullName(caseParticipantRole_eoKey);
      listTranscriptionDetails.requesterName =
        caseParticipantRoleFullNameDetails.fullName;

      // read the transcriber full name using the transcriberID
      caseParticipantRole_eoKey.caseParticipantRoleID =
        transcriptionSearchSummaryDetails.transcriberID;
      caseParticipantRoleFullNameDetails =
        caseParticipantRole_eoObj.readFullName(caseParticipantRole_eoKey);
      listTranscriptionDetails.transcriberName =
        caseParticipantRoleFullNameDetails.fullName;

      // Populate the remainder of the transcription details list
      listTranscriptionDetails.dateRequested =
        transcriptionSearchSummaryDetails.dateRequested;
      listTranscriptionDetails.dateSentToRequester =
        transcriptionSearchSummaryDetails.dateSentToRequester;
      listTranscriptionDetails.recordStatusCode =
        transcriptionSearchSummaryDetails.recordStatusCode;
      listTranscriptionDetails.requestedByID =
        transcriptionSearchSummaryDetails.requestedByID;
      listTranscriptionDetails.transcriberID =
        transcriptionSearchSummaryDetails.transcriberID;
      listTranscriptionDetails.versionNo =
        transcriptionSearchSummaryDetails.versionNo;
      listTranscriptionDetails.hearingTranscriptionRequestID =
        transcriptionSearchSummaryDetails.hearingTranscriptionRequestID;

      // Add transcription details to the list
      listTranscriptionDetailsList.listTranscriptionDetails
        .addRef(listTranscriptionDetails);
    }

    return listTranscriptionDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to manage an attachment
   * 
   * @param details
   * The attachment details to manage
   * @return
   * The transcription case attachment details
   */
  @Override
  public TranscriptionCaseAttachmentDetails manageAttachment(
    final TranscriptionManageAttachmentDetails details) throws AppException,
    InformationalException {

    // Return variable
    TranscriptionCaseAttachmentDetails transcriptionCaseAttachmentDetails =
      new TranscriptionCaseAttachmentDetails();

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();

    // Case Attachment variables
    TranscriptionCaseAttachmentLinkDetails transcriptionCaseAttachmentLinkDetails;

    // Read the case attachment link
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;
    transcriptionCaseAttachmentLinkDetails =
      hearingTranscriptionRequestObj
        .readCaseAttachmentLink(hearingTranscriptionRequestKey);

    // Has a file been attached already?
    // If the caseAttachmentLinkID is not 0, than a file has been
    // attached.
    if (transcriptionCaseAttachmentLinkDetails.caseAttachmentLinkID == 0) {

      // no attachment, create new attachment
      transcriptionCaseAttachmentDetails = createAttachment(details);

    } else {

      // - Check for canceled attachment
      final TranscriptionAttachmentDetails transcriptionAttachmentDetails =
        hearingTranscriptionRequestObj
          .readAttachment(hearingTranscriptionRequestKey);

      if (!transcriptionAttachmentDetails.attachmentRecordStatus
        .equals(RECORDSTATUS.NORMAL)) {

        // existing canceled attachment - create new attachment
        transcriptionCaseAttachmentDetails = createAttachment(details);

      } else {

        // existing active attachment - modify it
        modifyAttachment(details);
        transcriptionCaseAttachmentDetails.caseAttachmentLinkID =
          transcriptionCaseAttachmentLinkDetails.caseAttachmentLinkID;
      }
    }

    return transcriptionCaseAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a hearing transcription request
   * 
   * @param details
   * The details of the transcription request to modify
   */
  @Override
  public void modify(final ModifyTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Hearing variables
    HearingKeyDetails hearingKeyDetails = new HearingKeyDetails();

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    final TranscriptionModifyDetails transcriptionModifyDetails =
      new TranscriptionModifyDetails();
    TranscriptionCaseAttachmentDetails transcriptionCaseAttachmentDetails =
      new TranscriptionCaseAttachmentDetails();

    // Attachment variables
    final TranscriptionManageAttachmentDetails transcriptionManageAttachmentDetails =
      new TranscriptionManageAttachmentDetails();

    // Read hearing id
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;
    hearingKeyDetails =
      hearingTranscriptionRequestObj
        .readHearing(hearingTranscriptionRequestKey);

    // Read hearing case id
    hearingKey_bo = new HearingKey();
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    validateModify(details);

    // set up attachment details
    transcriptionManageAttachmentDetails.attachmentContents =
      details.attachmentContents;
    transcriptionManageAttachmentDetails.attachmentName =
      details.attachmentName;
    transcriptionManageAttachmentDetails.attachmentVersion =
      details.attachmentVersion;
    transcriptionManageAttachmentDetails.fileLocation = details.fileLocation;
    transcriptionManageAttachmentDetails.fileReferenceNumber =
      details.fileReferenceNumber;
    transcriptionManageAttachmentDetails.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;

    // Adding check to ensure no attachment validation is
    // performed if no attachment details are provided.
    if (!(StringUtil.isNullOrEmpty(details.fileLocation)
      && StringUtil.isNullOrEmpty(details.fileReferenceNumber) && StringUtil
        .isNullOrEmpty(details.attachmentName))) {

      transcriptionCaseAttachmentDetails =
        manageAttachment(transcriptionManageAttachmentDetails);

    }

    // Modify hearing transcription request details
    transcriptionModifyDetails.dateDue = details.dateDue;
    transcriptionModifyDetails.dateRequested = details.dateRequested;
    transcriptionModifyDetails.dateSentToRequester =
      details.dateSentToRequester;
    transcriptionModifyDetails.dateSentToTranscriber =
      details.dateSentToTranscriber;
    transcriptionModifyDetails.dateReceivedFromTranscriber =
      details.dateReceivedFromTranscriber;
    transcriptionModifyDetails.requestedByID = details.requestedByID;
    transcriptionModifyDetails.versionNo = details.versionNo;
    transcriptionModifyDetails.comments = details.comments;
    transcriptionModifyDetails.caseAttachmentLinkID =
      transcriptionCaseAttachmentDetails.caseAttachmentLinkID;

    hearingTranscriptionRequestObj.modifyDetails(
      hearingTranscriptionRequestKey, transcriptionModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify an attachment
   * 
   * @param details
   * The details of the transcription attachments
   */
  @Override
  protected void modifyAttachment(
    final TranscriptionManageAttachmentDetails details) throws AppException,
    InformationalException {

    // Hearing Transcription variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    HearingTranscriptionRequestDtls hearingTranscriptionRequestDtls;

    // CaseAttachmentLink variables
    final CaseAttachmentLink caseAttachmentLinkObj =
      CaseAttachmentLinkFactory.newInstance();
    final CaseAttachmentLinkKey caseAttachmentLinkKey =
      new CaseAttachmentLinkKey();
    CaseAttachmentLinkDtls caseAttachmentLinkDtls;

    // MaintainAttachment objects
    final MaintainAttachment maintainAttachmentObj =
      MaintainAttachmentFactory.newInstance();
    final ModifyAttachmentDetails modifyAttachmentDetails =
      new ModifyAttachmentDetails();

    // Read hearing transcription details
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;
    hearingTranscriptionRequestDtls =
      hearingTranscriptionRequestObj.read(hearingTranscriptionRequestKey);

    // Read case attachment link details
    caseAttachmentLinkKey.caseAttachmentLinkID =
      hearingTranscriptionRequestDtls.caseAttachmentLinkID;
    caseAttachmentLinkDtls =
      caseAttachmentLinkObj.read(caseAttachmentLinkKey);

    // Update attachment
    modifyAttachmentDetails.attachmentContents = details.attachmentContents;
    modifyAttachmentDetails.attachmentDate = Date.getCurrentDate();
    modifyAttachmentDetails.attachmentID =
      caseAttachmentLinkDtls.attachmentID;
    modifyAttachmentDetails.attachmentName = details.attachmentName;
    modifyAttachmentDetails.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
    modifyAttachmentDetails.caseAttachmentLinkID =
      caseAttachmentLinkDtls.caseAttachmentLinkID;
    modifyAttachmentDetails.caseID = caseAttachmentLinkDtls.caseID;
    modifyAttachmentDetails.documentType = DOCUMENTTYPE.TRANSCRIPTION;
    modifyAttachmentDetails.fileLocation = details.fileLocation;
    modifyAttachmentDetails.fileReference = details.fileReferenceNumber;
    modifyAttachmentDetails.linkVersionNo = caseAttachmentLinkDtls.versionNo;
    modifyAttachmentDetails.receiptDate = Date.getCurrentDate();
    modifyAttachmentDetails.description =
      BPOHEARINGTRANSCRIPTIONREQUEST.INF_HEARINGTRANSCRIPTIONREQUEST_ATTACHMENTDESCRIPTION
        .getMessageText();
    modifyAttachmentDetails.versionNo = details.attachmentVersion;

    maintainAttachmentObj.modifyCaseAttachment(modifyAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to notify an owner
   * 
   * @param details
   * The hearing id used to notify the owner
   */
  @Override
  public void notifyOwner(final TranscriptionHearingKey details)
    throws AppException, InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseUserNameDetails hearingCaseUserNameDetails =
      new HearingCaseUserNameDetails();

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingKey hearingKey_bo;
    HearingCaseID hearingCaseID = new HearingCaseID();

    // Notification variables
    final Notification notificationObj = NotificationFactory.newInstance();
    AppException msg;

    final SystemUser systemUser = SystemUserFactory.newInstance();

    // Current user
    final String currentUser = systemUser.getUserDetails().userName;

    // Read the case owner for the appeal case associated
    // with the hearing
    hearingKey.hearingID = details.hearingID;
    hearingCaseUserNameDetails = hearingObj.readCaseOwner(hearingKey);
    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      hearingCaseUserNameDetails.ownerOrgObjectLinkID;
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

    if (!currentUser.equals(caseOwnerDetails.userName)) {

      // create the message to send to the case owner
      msg =
        new AppException(
          BPOHEARINGTRANSCRIBER.INF_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUESTED);

      // Retrieve hearing case id
      hearingKey_bo = new HearingKey();
      hearingKey_bo.hearingKey.hearingID = details.hearingID;
      hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

      // send a notification to the case owner that a transcript
      // has been requested
      final StandardManualTaskDtls standardManualTaskDtls =
        new StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID =
        hearingCaseID.hearingCaseID.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments = msg.getMessage();
      standardManualTaskDtls.dtls.taskDtls.subject = msg.getMessage();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userName;

      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
        Appeal.kAppealNotificationTask;

      // BEGIN, CR00053295, RKi
      // Create notification
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to view a hearing transcription request
   * 
   * @param key
   * The hearing transcription request id of the request we
   * wish to view.
   * @return
   * readTranscriptionDetails the requested hearing transcription request
   */
  @Override
  public ReadTranscriptionDetails read(final TranscriptionRequestKey key)
    throws AppException, InformationalException {

    // Hearing variables
    final Hearing hearing_boObj = HearingFactory.newInstance();
    final HearingKey hearingKey_bo = new HearingKey();
    HearingCaseID hearingCaseID;

    // Hearing variables
    HearingKeyDetails hearingKeyDetails;

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    HearingTranscriptionRequestDtls hearingTranscriptionRequestDtls;
    TranscriptionAttachmentDetails transcriptionAttachmentDetails =
      new TranscriptionAttachmentDetails();
    final ReadTranscriptionDetails readTranscriptionDetails =
      new ReadTranscriptionDetails();

    // Case participant role variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoFullNameDetails caseParticipantRoleFullNameDetails;

    // Read hearing id
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      key.hearingTranscriptionRequestID;
    hearingKeyDetails =
      hearingTranscriptionRequestObj
        .readHearing(hearingTranscriptionRequestKey);

    // Read hearing case id
    hearingKey_bo.hearingKey.hearingID = hearingKeyDetails.hearingID;
    hearingCaseID = hearing_boObj.getCase(hearingKey_bo);

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read the transcription request summary
    hearingTranscriptionRequestDtls =
      hearingTranscriptionRequestObj.read(hearingTranscriptionRequestKey);

    if (hearingTranscriptionRequestDtls.caseAttachmentLinkID != 0) {

      transcriptionAttachmentDetails =
        hearingTranscriptionRequestObj
          .readAttachment(hearingTranscriptionRequestKey);

      // Blank out attachment details if attachment is canceled
      if (transcriptionAttachmentDetails.attachmentRecordStatus
        .equals(RECORDSTATUS.NORMAL)) {

        readTranscriptionDetails.attachmentID =
          transcriptionAttachmentDetails.attachmentID;
        readTranscriptionDetails.attachmentName =
          transcriptionAttachmentDetails.attachmentName;
        readTranscriptionDetails.attachmentVersion =
          transcriptionAttachmentDetails.versionNo;
        readTranscriptionDetails.fileLocation =
          transcriptionAttachmentDetails.fileLocation;
        readTranscriptionDetails.fileReferenceNumber =
          transcriptionAttachmentDetails.fileReferenceNumber;

      } else {

        readTranscriptionDetails.attachmentID = 0;
        readTranscriptionDetails.attachmentName = "";
        readTranscriptionDetails.attachmentVersion = 1;
        readTranscriptionDetails.fileLocation = "";
        readTranscriptionDetails.fileReferenceNumber = "";

      }

    }

    readTranscriptionDetails.comments =
      hearingTranscriptionRequestDtls.comments;
    readTranscriptionDetails.dateDue =
      hearingTranscriptionRequestDtls.dateDue;
    readTranscriptionDetails.dateRequested =
      hearingTranscriptionRequestDtls.dateRequested;
    readTranscriptionDetails.dateSentToTranscriber =
      hearingTranscriptionRequestDtls.dateSentToTranscriber;
    readTranscriptionDetails.dateSentToRequester =
      hearingTranscriptionRequestDtls.dateSentToRequester;
    readTranscriptionDetails.dateReceivedFromTranscriber =
      hearingTranscriptionRequestDtls.dateReceivedFromTranscriber;
    readTranscriptionDetails.recordStatusCode =
      hearingTranscriptionRequestDtls.recordStatusCode;
    readTranscriptionDetails.requestedByID =
      hearingTranscriptionRequestDtls.requestedByID;
    readTranscriptionDetails.transcriberID =
      hearingTranscriptionRequestDtls.transcriberID;
    readTranscriptionDetails.versionNo =
      hearingTranscriptionRequestDtls.versionNo;

    // Read the full name for the requested by id
    caseParticipantRole_eoKey.caseParticipantRoleID =
      hearingTranscriptionRequestDtls.requestedByID;
    caseParticipantRoleFullNameDetails =
      caseParticipantRole_eoObj.readFullName(caseParticipantRole_eoKey);

    readTranscriptionDetails.requestedByName =
      caseParticipantRoleFullNameDetails.fullName;

    // Read the full name for the transcriber name
    caseParticipantRole_eoKey.caseParticipantRoleID =
      hearingTranscriptionRequestDtls.transcriberID;
    caseParticipantRoleFullNameDetails =
      caseParticipantRole_eoObj.readFullName(caseParticipantRole_eoKey);

    readTranscriptionDetails.transcriberName =
      caseParticipantRoleFullNameDetails.fullName;

    return readTranscriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate a cancel
   * 
   * @param details
   * The cancel transcription details to validate
   */
  @Override
  protected void validateCancel(final CancelTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    TranscriptionDateSentDetails transcriptionDateSentDetails =
      new TranscriptionDateSentDetails();
    TranscriptionStatusDetails transcriptionStatusDetails =
      new TranscriptionStatusDetails();

    // Retrieve the date sent to requester field
    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;

    transcriptionDateSentDetails =
      hearingTranscriptionRequestObj
        .readDateSentToRequester(hearingTranscriptionRequestKey);

    // Check to see if transcription date sent is null
    if (!transcriptionDateSentDetails.dateSentToRequester.isZero()) {

      throw new AppException(
        BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_CANNOT_CANCEL);

    }

    // Read the hearing transcription request status

    transcriptionStatusDetails =
      hearingTranscriptionRequestObj
        .readStatus(hearingTranscriptionRequestKey);

    if (transcriptionStatusDetails.recordStatusCode
      .equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUEST_ALREADY_CANCELLED);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate a create
   * 
   * @param details
   * The create transcription details to validate
   */
  @Override
  protected void validateCreate(final CreateTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;
    HearingActualTimeDetails hearingActualTimeDetails;

    // CaseParticipantRole variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoCaseIDDetails caseParticipantRoleCaseIDDetails;

    // HearingTranscriptionRequest variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final TranscriptionRequesterStatusDetails transcriptionRequesterStatusDetails =
      new TranscriptionRequesterStatusDetails();
    TranscriptionRecordCountDetails transcriptionRecordCountDetails;

    final InformationalManager informationalManager =
      new InformationalManager();

    // Check for no transcriber entered
    if (details.concernRoleID == 0
      && details.representativeRegistrationDetails.representativeDtls.representativeName
        .length() == 0) {

      throw new AppException(
        BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_TRANSCRIBERMISSING);
    }

    // Check for invalid request date
    if (details.dateRequested.after(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEREQUESTEDINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Get the hearing case ID and hearing status
    hearingKey.hearingID = details.hearingID;
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Check for requester already associated with case.
    caseParticipantRole_eoKey.caseParticipantRoleID = details.requestedByID;
    caseParticipantRoleCaseIDDetails =
      caseParticipantRole_eoObj.readCaseID(caseParticipantRole_eoKey);

    if (caseParticipantRoleCaseIDDetails.caseID != hearingCaseStatusDtls.caseID) {

      // Requester is not a case participant
      throw new AppException(
        BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUESTER_NOT_PARTICIPANT);
    }

    // Check for requester making multiple requests
    transcriptionRequesterStatusDetails.hearingID = details.hearingID;
    transcriptionRequesterStatusDetails.recordStatusCode =
      RECORDSTATUS.NORMAL;
    transcriptionRequesterStatusDetails.requestedByID = details.requestedByID;
    transcriptionRecordCountDetails =
      hearingTranscriptionRequestObj
        .countByHearingRequesterStatus(transcriptionRequesterStatusDetails);

    if (transcriptionRecordCountDetails.recordCount > 0) {

      // Cannot request more than one transcript
      throw new AppException(
        BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_MULTIPLEREQUESTINVALID);
    }

    hearingActualTimeDetails = hearingObj.readActualTimeDetails(hearingKey);

    // Convert DateTime to Date
    final Date hearingDate // Scheduled Hearing Date
    = new Date(hearingActualTimeDetails.scheduledDateTime.asLong());

    if (!details.dateDue.isZero()) {

      // Due date should be on or after the scheduled date of that hearing
      if (details.dateDue.before(hearingDate)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEINVALID),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Due date should not be in the past
      if (details.dateDue.before(Date.getCurrentDate())) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEINPAST),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Due date should not be before Date Requested
      if (details.dateDue.before(details.dateRequested)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEBEFOREREQUESTEDDATE),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    }

    if (hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.COMPLETED)
      || hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.ADJOURNED)) {

      // Check for invalid date sent
      if (!details.dateSentToTranscriber.isZero()
        && details.dateSentToTranscriber.after(Date.getCurrentDate())) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTINVALID),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Check for date sent to transcriber before date requested
      if (!details.dateSentToTranscriber.isZero()
        && details.dateSentToTranscriber.before(details.dateRequested)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTBEFOREDATEREQUESTED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Check for date sent to transcriber before the hearing date is scheduled
      if (!details.dateSentToTranscriber.isZero()
        && details.dateSentToTranscriber.before(hearingDate)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEBEFORESCHEDULED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Hearing has been held, transcription request must have a due date
      if (details.dateDue.isZero()) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_DUE_DATE_REQUIRED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    } else {

      // Hearing has not been completed or adjourned, so cannot
      // send transcription to transcriber before the hearing
      // has been held.
      if (!details.dateSentToTranscriber.isZero()) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_CANNOTSEND),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Method to validate a modify
   * 
   * @param details
   * The modify transcription details to validate
   */
  @Override
  protected void validateModify(final ModifyTranscriptionDetails details)
    throws AppException, InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingCaseStatusDtls hearingCaseStatusDtls;
    HearingActualTimeDetails hearingActualTimeDetails;

    // Hearing transcription request variables
    final HearingTranscriptionRequest hearingTranscriptionRequestObj =
      HearingTranscriptionRequestFactory.newInstance();
    final HearingTranscriptionRequestKey hearingTranscriptionRequestKey =
      new HearingTranscriptionRequestKey();
    TranscriptionStatusDetails transcriptionStatusDetails;
    HearingKeyDetails hearingKeyDetails;
    final TranscriptionRequesterStatusDetails transcriptionRequesterStatusDetails =
      new TranscriptionRequesterStatusDetails();
    TranscriptionRecordCountDetails transcriptionRecordCountDetails;

    // CaseParticipantRole variables
    final CaseParticipantRole caseParticipantRole_eoObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRole_eoKey =
      new CaseParticipantRoleKey();
    CaseParticipantRole_eoCaseIDDetails caseParticipantRoleCaseIDDetails;

    final InformationalManager informationalManager =
      new InformationalManager();

    hearingTranscriptionRequestKey.hearingTranscriptionRequestID =
      details.hearingTranscriptionRequestID;

    // Read hearing id
    hearingKeyDetails =
      hearingTranscriptionRequestObj
        .readHearing(hearingTranscriptionRequestKey);

    // Read the scheduled date,actual start time and end time.
    hearingKey.hearingID = hearingKeyDetails.hearingID;

    // Get the hearing case ID and hearing status
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    // Check for invalid request date
    if (details.dateRequested.after(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEREQUESTEDINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for invalid date sent to transcriber
    if (!details.dateSentToTranscriber.isZero()
      && details.dateSentToTranscriber.after(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for invalid date sent to requester
    if (!details.dateSentToRequester.isZero()
      && details.dateSentToRequester.after(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTTOREQUESTERINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    hearingActualTimeDetails = hearingObj.readActualTimeDetails(hearingKey);

    // Convert DateTime to Date
    final Date hearingDate =
      new Date(hearingActualTimeDetails.scheduledDateTime.asLong());

    // Due date should be on or after the scheduled date of that hearing
    if (!details.dateDue.isZero() && details.dateDue.before(hearingDate)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Due date should not be in the past
    if (!details.dateDue.isZero()
      && details.dateDue.before(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEINPAST),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Due date should not be before Date Requested
    if (!details.dateDue.isZero()
      && details.dateDue.before(details.dateRequested)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEDUEBEFOREREQUESTEDDATE),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    if (hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.COMPLETED)
      || hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.ADJOURNED)) {

      // Check for date sent to transcriber before date requested
      if (!details.dateSentToTranscriber.isZero()
        && details.dateSentToTranscriber.before(details.dateRequested)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTBEFOREDATEREQUESTED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      // Check for date sent to transcriber before the hearing date is scheduled
      if (!details.dateSentToTranscriber.isZero()
        && details.dateSentToTranscriber.before(hearingDate)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATEBEFORESCHEDULED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

      if (details.dateDue.isZero()) {

        // Hearing has been held, transcription request must have a due date
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_DUE_DATE_REQUIRED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    } else {

      // Hearing has not been completed or adjourned, so cannot
      // send transcription to transcriber before the hearing
      // has been held.
      if (!details.dateSentToTranscriber.isZero()) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_CANNOTSEND),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    }

    // Check for date sent to requester before date sent to transcriber
    if (!details.dateSentToRequester.isZero()
      && details.dateSentToRequester.before(details.dateSentToTranscriber)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTTOREQUESTERBEFOREDATESENT),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Cannot specify a date received from transcriber if a date sent to
    // transcriber is not specified.
    if (!details.dateReceivedFromTranscriber.isZero()
      && details.dateSentToTranscriber.isZero()) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATERECEIVEDFROMTRANSNOTNULL),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for date sent to requester before date requested
    if (!details.dateSentToRequester.isZero()
      && details.dateSentToRequester.before(details.dateRequested)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTTOREQUESTERBEFOREDATEREQ),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for invalid date received from transcriber
    if (!details.dateReceivedFromTranscriber.isZero()
      && details.dateReceivedFromTranscriber.after(Date.getCurrentDate())) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATERECFROMTRANSINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for date received from transcriber before date requested
    if (!details.dateReceivedFromTranscriber.isZero()
      && details.dateReceivedFromTranscriber.before(details.dateRequested)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATERECFROMTRANSBEFOREDATEREQ),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for date received from transcriber is before date sent to
    // transcriber
    if (!details.dateReceivedFromTranscriber.isZero()
      && details.dateReceivedFromTranscriber
        .before(details.dateSentToTranscriber)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATERECFROMTRANSBEFOREDATESNTTOTRANS),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check to ensure attachments have been included if the
    // Date received from transcriber field has been updated.
    if (!details.dateReceivedFromTranscriber.isZero()) {

      // Check to see if document reference and document location has
      // been populated.
      if (StringUtil.isNullOrEmpty(details.fileLocation)
        && StringUtil.isNullOrEmpty(details.fileReferenceNumber)
        && StringUtil.isNullOrEmpty(details.attachmentName)) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_TRANSCRIPTIONNOTATTACHED),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }

    } else {

      // Check to see if Date sent to requester is populated.
      // If it is, than an exception will be thrown. Cannot send
      // transcription to requester until it has been received.
      if (!details.dateSentToRequester.isZero()) {

        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATESENTTOREQUESTERNOTNULL),
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kError);

      }
    }

    // Check that the date received from transcriber is on or before date sent
    // to requester
    if (!details.dateReceivedFromTranscriber.isZero()
      && !details.dateSentToRequester.isZero()
      && details.dateReceivedFromTranscriber
        .after(details.dateSentToRequester)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_DATERECFROMTRANSBEFOREDATESNTTOREQ),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Read the hearing transcription request status
    transcriptionStatusDetails =
      hearingTranscriptionRequestObj
        .readStatus(hearingTranscriptionRequestKey);

    if (transcriptionStatusDetails.recordStatusCode
      .equals(RECORDSTATUS.CANCELLED)) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUEST_ALREADY_CANCELLED),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for requester already associated with case.
    caseParticipantRole_eoKey.caseParticipantRoleID = details.requestedByID;
    caseParticipantRoleCaseIDDetails =
      caseParticipantRole_eoObj.readCaseID(caseParticipantRole_eoKey);

    if (caseParticipantRoleCaseIDDetails.caseID != hearingCaseStatusDtls.caseID) {

      // Requester is not a case participant
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUESTER_NOT_PARTICIPANT),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Check for requester making multiple requests
    transcriptionRequesterStatusDetails.hearingID =
      hearingKeyDetails.hearingID;
    transcriptionRequesterStatusDetails.recordStatusCode =
      RECORDSTATUS.NORMAL;
    transcriptionRequesterStatusDetails.requestedByID = details.requestedByID;
    transcriptionRecordCountDetails =
      hearingTranscriptionRequestObj
        .countByHearingRequesterStatus(transcriptionRequesterStatusDetails);

    if (transcriptionRecordCountDetails.recordCount != 1) {

      // Cannot request more than one transcript
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_MULTIPLEREQUESTINVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError);

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

}
