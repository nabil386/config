/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealProcessID;
import curam.appeal.sl.entity.struct.CaseTypeIDStartDateActiveDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * An AppealProcess record is an appeals process definition for an Issue Case.
 */
public class AppealProcess extends curam.appeal.sl.entity.base.AppealProcess {

  // ___________________________________________________________________________
  /**
   * Entity method to read issue process by case type and start date.
   * 
   * @param key The key of case type id and start date
   */
  @Override
  public AppealProcessID readProcessIDByCaseTypeIDAndStartDate(
    final CaseTypeIDStartDateActiveDetails key) throws AppException,
    InformationalException {

    return super.readProcessIDByCaseTypeIDAndStartDate(key);
  }

}
