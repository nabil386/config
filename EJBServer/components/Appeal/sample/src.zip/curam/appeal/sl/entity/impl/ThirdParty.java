/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.ThirdPartyFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.CancelThirdPartyDetails;
import curam.appeal.sl.entity.struct.ThirdPartyDtls;
import curam.appeal.sl.entity.struct.ThirdPartyKey;
import curam.codetable.CASESTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.message.BPOTHIRDPARTY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * A ThirdParty is a type of Case Participant for an Appeal Hearing Case.
 * This table holds the definition and it is uniquely identified by the
 * thirdPartyID.
 */

public abstract class ThirdParty extends
  curam.appeal.sl.entity.base.ThirdParty {

  // __________________________________________________________________________
  /**
   * Cancel the third party.
   * 
   * @param key The third party identifier for canceling the third party.
   * @param details The Third party details for canceling.
   */

  public void remove(final ThirdPartyKey key,
    final CancelThirdPartyDetails details) throws AppException,
    InformationalException {

    validateRemove(key);
    super.cancelThirdParty(key, details);
  }

  // __________________________________________________________________________
  /**
   * Validation to be performed before the third party can be removed.
   * 
   * @param key The third party identifier for canceling the third party.
   */

  public void validateRemove(final ThirdPartyKey key) throws AppException,
    InformationalException {

    // Check Decision Status
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealKey appealKey = new AppealKey();
    AppealDtls appealDtls;

    final curam.appeal.sl.entity.intf.ThirdParty thirdPartyObj =
      ThirdPartyFactory.newInstance();

    ThirdPartyDtls thirdPartyDtls;

    thirdPartyDtls = thirdPartyObj.read(key);

    // Third party already removed
    if (!thirdPartyDtls.toDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOTHIRDPARTY.ERR_THIRD_PARTY_ALREADY_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // If case is closed
    // Get the appeal case start date from case header
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    appealKey.appealID = thirdPartyDtls.appealID;
    appealDtls = appealObj.read(appealKey);

    caseHeaderKey.caseID = appealDtls.caseID;

    // BEGIN, CR00303986, SG
    final CaseStatusCode caseStatusCode =
      caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Appeal Case is closed
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOTHIRDPARTY.ERR_APPEAL_CASE_CLOSED_THIRD_PARTY_CANNOT_BE_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Appeal Case is canceled
    // BEGIN, CR00303986, SG
    if (caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOTHIRDPARTY.ERR_APPEAL_CASE_CANCELLED_THIRD_PARTY_CANNOT_BE_REMOVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

}
