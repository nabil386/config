/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealCancellationFactory;
import curam.appeal.sl.entity.struct.AppealCancellationDtls;
import curam.appeal.sl.entity.struct.ModifyCancelCaseDetails;
import curam.appeal.sl.entity.struct.ModifyCancelCaseKey;
import curam.appeal.sl.entity.struct.ReadCancelledCaseDetails;
import curam.appeal.sl.entity.struct.ReadCancelledCaseKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.message.BPOAPPEALCANCELLATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for Appeal Cancellation entity.
 * 
 */
public abstract class AppealCancellation extends
  curam.appeal.sl.entity.base.AppealCancellation {

  // ___________________________________________________________________________
  /**
   * Entity method to call validation of details to be updated.
   * 
   * @param key contains the appeal cancellation id of the record being
   * modified
   * @param details the details to validate
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyReason method.
    protected
    void premodifyReason(final ModifyCancelCaseKey key,
      final ModifyCancelCaseDetails details) throws AppException,
      InformationalException {

    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Entity method to validate the modified cancel case details before
   * saving them.
   * 
   * @param details the details to validate
   */
  @Override
  protected void validateModify(final ModifyCancelCaseDetails details)
    throws AppException, InformationalException {

    // reason code must be supplied
    if (details.cancelReasonCode.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALCANCELLATION.ERR_APPEAL_CANCELLATION_FV_REASONCODEEMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Entity method to perform pre-insert operations.
   * 
   * @param details The details of the appeal cancellation
   */
  @Override
  protected void preinsert(final AppealCancellationDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Entity method to validate the appeal cancellation details.
   * 
   * @param details the details to validate
   */
  @Override
  protected void validateInsert(final AppealCancellationDtls details)
    throws AppException, InformationalException {

    // reason code must be supplied
    if (details.cancelReasonCode.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALCANCELLATION.ERR_APPEAL_CANCELLATION_FV_REASONCODEEMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readDetailsAndUserFullName
   */
  @Override
  public ReadCancelledCaseDetails read(final ReadCancelledCaseKey key)
    throws AppException, InformationalException {

    return AppealCancellationFactory.newInstance()
      .readDetailsAndUserFullName(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyReason
   */
  @Override
  public void modify(final ModifyCancelCaseKey key,
    final ModifyCancelCaseDetails details) throws AppException,
    InformationalException {

    AppealCancellationFactory.newInstance().modifyReason(key, details);
  }
}
