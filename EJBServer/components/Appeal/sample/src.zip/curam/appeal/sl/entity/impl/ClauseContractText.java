/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.ClauseContractTextDtls;
import curam.appeal.sl.entity.struct.ClauseContractTextKey;
import curam.appeal.sl.entity.struct.ClauseNameLanguageCodeAndRecordStatus;
import curam.appeal.sl.entity.struct.ClauseSearchByCategoryKey;
import curam.appeal.sl.entity.struct.ModifyClauseContractTextDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOCLAUSE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * The standard wording of a clause which is used when composing a
 * decision text. This entity class depends on the Contract Text entity.
 */
public abstract class ClauseContractText extends
  curam.appeal.sl.entity.base.ClauseContractText {

  // ___________________________________________________________________________
  /**
   * Prepares to count active clauses by name and language
   * 
   * @param key The name, language and recordStatus
   */
  @Override
  protected void precountActiveByNameAndLanguage(
    final ClauseNameLanguageCodeAndRecordStatus key) throws AppException,
    InformationalException {

    // Only active clauses are to be counted
    key.recordStatusCode = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Prepares for insertion of a new clause
   * 
   * @param details The details of the new clause
   */
  @Override
  protected void preinsert(final ClauseContractTextDtls details)
    throws AppException, InformationalException {

    // Check the clause details for insertion
    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Prepares for modification of an existing clause
   * 
   * @param details The clause details for modification
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyDetails method.
    protected
    void premodifyDetails(final ClauseContractTextKey key,
      final ModifyClauseContractTextDetails details) throws AppException,
      InformationalException {

    // Check the clause details for modification
    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Prepares for clause search by record status
   * 
   * @param key The record status for which to search
   */
  @Override
  protected void presearchActive(final ClauseSearchByCategoryKey key)
    throws AppException, InformationalException {

    // Only search for active clauses
    key.recordStatusCode = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Prepares for clause search by category
   * 
   * @param key The clause category for which to search
   */
  @Override
  protected void
    presearchActiveByCategory(final ClauseSearchByCategoryKey key)
      throws AppException, InformationalException {

    // Only search for active clauses
    key.recordStatusCode = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Validates the insertion of a new clause
   * 
   * @param details The clause details for modification
   */
  @Override
  protected void validateInsert(final ClauseContractTextDtls details)
    throws AppException, InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Validate the clause category
    if (details.categoryCode.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOCLAUSE.ERR_CLAUSE_FV_CATEGORY), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate the clause name
    if (details.clauseName.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOCLAUSE.ERR_CLAUSE_FV_NAME), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Throw exceptions for any validation errors found
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * Validates the modification of an existing clause
   * 
   * @param details The clause details for modification
   */
  @Override
  protected void
    validateModify(final ModifyClauseContractTextDetails details)
      throws AppException, InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Validate the clause category
    if (details.categoryCode.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOCLAUSE.ERR_CLAUSE_FV_CATEGORY), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Validate the clause name
    if (details.clauseName.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOCLAUSE.ERR_CLAUSE_FV_NAME), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Throw exceptions for any validation errors found
    informationalManager.failOperation();
  }

}
