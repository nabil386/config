/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingWitnessFactory;
import curam.appeal.sl.entity.struct.HearingCaseIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingCaseStatusDtls;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantRoleIDStatus;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingParticipationAndStatus;
import curam.appeal.sl.entity.struct.HearingWitnessCloneDetails;
import curam.appeal.sl.entity.struct.HearingWitnessDtls;
import curam.appeal.sl.entity.struct.HearingWitnessIDKey;
import curam.appeal.sl.entity.struct.ModifyHearingWitnessDetails;
import curam.appeal.sl.entity.struct.ReadHearingWitnessDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationKey;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.struct.Count;
import curam.message.ENTHEARINGWITNESS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This class provides the functionality for the Hearing Witness
 * entity layer.
 * 
 */

public abstract class HearingWitness extends
  curam.appeal.sl.entity.base.HearingWitness {

  // ___________________________________________________________________________
  /**
   * Validates the details of the modify action
   * 
   * @param key The hearing witness ID
   * 
   * @param dtls The modified hearing witness details
   */
  @Override
  protected void validateModify(

  final HearingWitnessIDKey key, final ModifyHearingWitnessDetails dtls)
    throws AppException, InformationalException {

    // Hearing variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    HearingKey hearingKey;
    HearingCaseStatusDtls hearingCaseStatusDtls;

    // Hearing witness variables
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    ReadHearingWitnessDetails readHearingWitnessDetails;
    HearingWitnessDtls hearingWitnessDtls;

    // Read hearing id
    hearingWitnessDtls = new HearingWitnessDtls();
    readHearingWitnessDetails = hearingWitnessObj.readDetailsAndName(key);
    hearingKey = new HearingKey();
    hearingKey.hearingID = readHearingWitnessDetails.hearingID;

    hearingWitnessDtls.assign(dtls);

    validate(hearingWitnessDtls);

    // Get case and status details
    hearingCaseStatusDtls =
      hearingObj.readCaseAndStatusByHearingID(hearingKey);

    if (hearingCaseStatusDtls.statusCode.equals(HEARINGSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTHEARINGWITNESS.ERR_HEARINGWITNESS_FV_CASE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of the insert action
   * 
   * @param dtls The hearing witness details
   */
  @Override
  protected void validateInsert(final HearingWitnessDtls dtls)
    throws AppException, InformationalException {

    validate(dtls);

    // Hearing Case variables
    HearingIDCaseParticipantRoleIDStatus hearingIDCaseParticipantRoleIDStatus;
    Count countActive;

    hearingIDCaseParticipantRoleIDStatus =
      new HearingIDCaseParticipantRoleIDStatus();
    hearingIDCaseParticipantRoleIDStatus.caseParticipantRoleID =
      dtls.caseParticipantRoleID;
    hearingIDCaseParticipantRoleIDStatus.hearingID = dtls.hearingID;
    hearingIDCaseParticipantRoleIDStatus.recordStatus =
      RECORDSTATUS.DEFAULTCODE;

    // count active hearing IDs
    countActive =
      countActiveByHearingIDCaseParticipantRoleID(hearingIDCaseParticipantRoleIDStatus);

    // Check to see if witness already exists, if it does
    // it throws an exception
    if (countActive.numberOfRecords != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTHEARINGWITNESS.ERR_HEARINGWITNESS_FV_WITNESS_ALREADY_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of the insert/modify action
   * 
   * @param dtls The hearing witness details
   */
  @Override
  protected void validate(final HearingWitnessDtls dtls) throws AppException,
    InformationalException {

    if (dtls.behalfOfCode.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTHEARINGWITNESS.ERR_HEARINGWITNESS_FV_BEHALF_OF_NOT_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing witnesses
   * 
   * @param key contains the hearingID and the status to search on
   */
  @Override
  protected void presearchActiveByHearingID(final HearingIDStatusKeyHW key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing witnesses
   * 
   * @param key contains the hearingID and the status to search on
   */
  @Override
  protected void
    presearchActiveHearingWitnessAndCaseParticipantRoleByHearingID(
      final HearingIDStatusKeyHW key) throws AppException,
      InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing witnesses
   * 
   * @param key contains the hearingCaseID and the status to search on
   */
  @Override
  protected void
    presearchActiveHearingWitnessAndCaseParticipantRoleByHearingCaseID(
      final HearingCaseIDStatusKeyHW key) throws AppException,
      InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to count active hearing witnesses
   * 
   * @param key contains the hearingCaseID and the status to search on
   */
  @Override
  protected void precountActiveByHearingIDCaseParticipantRoleID(
    final HearingIDCaseParticipantRoleIDStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * ensures validations are performed
   */
  @Override
  protected void preinsert(final HearingWitnessDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * ensures validations are performed
   */
  @Override
  protected void premodifyDetails(final HearingWitnessIDKey key,
    final ModifyHearingWitnessDetails details) throws AppException,
    InformationalException {

    validateModify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing witnesses
   * 
   * @param key contains the hearingID and the status to search on
   */
  @Override
  protected void
    presearchActiveHearingWitnessNameAndCaseParticipantRoleByHearingID(
      final HearingIDStatusKeyHW key) throws AppException,
      InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Sets the fields so that all non participants are updated to no-show
   * 
   * @param key contains the hearing ID and the participation code to search on
   * @param details contains the new participation code
   */
  @Override
  protected void premodifyNonParticipation(
    final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    key.participatedCode = HEARINGPARTICIPATION.NOTHELD;
    details.participatedCode = HEARINGPARTICIPATION.NOSHOW;

  }

  // ___________________________________________________________________________
  /**
   * Clones a hearing witness.
   * 
   * @param key The unique identifier of the hearing witness being cloned.
   * @param details The unique identifier of the hearing for which the cloned
   * witness is being created.
   */
  @Override
  public void clone(final HearingWitnessIDKey key, final HearingKey details)
    throws AppException, InformationalException {

    // Hearing Witness clone details
    HearingWitnessCloneDetails hearingWitnessCloneDetails;
    // Hearing Witness clone details
    final HearingWitnessDtls hearingWitnessDtls = new HearingWitnessDtls();

    // read clone details
    hearingWitnessCloneDetails = readCloneDetails(key);

    // assign details
    hearingWitnessDtls.behalfOfCode = hearingWitnessCloneDetails.behalfOfCode;
    hearingWitnessDtls.caseParticipantRoleID =
      hearingWitnessCloneDetails.caseParticipantRoleID;
    hearingWitnessDtls.comments = hearingWitnessCloneDetails.comments;
    hearingWitnessDtls.voluntaryIndicator =
      hearingWitnessCloneDetails.voluntaryIndicator;
    hearingWitnessDtls.hearingID = details.hearingID;

    hearingWitnessDtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

    // insert witness
    insert(hearingWitnessDtls);

  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing witnesses are considered when
   * determining the number of witnesses for a hearing with a specified
   * participation.
   * 
   * @param key The hearingID, participationCode and recordStatus to read for
   */
  @Override
  protected void precountActiveByHearingAndParticipation(
    final HearingParticipationAndStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readDetailsAndName
   */
  @Override
  public ReadHearingWitnessDetails read(final HearingWitnessIDKey key)
    throws AppException, InformationalException {

    return HearingWitnessFactory.newInstance().readDetailsAndName(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyDetails
   */
  @Override
  public void modify(final HearingWitnessIDKey key,
    final ModifyHearingWitnessDetails dtls) throws AppException,
    InformationalException {

    HearingWitnessFactory.newInstance().modifyDetails(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyNonParticipation
   */
  @Override
  public void updateNonParticipation(final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    HearingWitnessFactory.newInstance().modifyNonParticipation(key, details);
  }

}
