/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealStageTimeConstraintDtls;
import curam.appeal.sl.entity.struct.AppealStageTimeConstraintKey;
import curam.codetable.RECORDSTATUS;
import curam.message.ENTAPPEALSTAGETIMECONSTRAINT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;

public class AppealStageTimeConstraint extends
  curam.appeal.sl.entity.base.AppealStageTimeConstraint {

  // ___________________________________________________________________________
  /**
   * Performs all of the preinsert checks for the
   * appealStageTimeConstraintEntity
   * 
   * @param details The AppealStageTimeConstraintDtls that contains the create
   * details
   */
  @Override
  protected void preinsert(final AppealStageTimeConstraintDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Performs all of the premodify checks for the
   * appealStageTimeConstraintEntity
   * 
   * @param key The AppealStageTimeConstraintKey that indicates which record is
   * to be modified
   * @param details The AppealStageTimeConstraintDtls that contains the modify
   * details
   */
  @Override
  protected void premodify(final AppealStageTimeConstraintKey key,
    final AppealStageTimeConstraintDtls details) throws AppException,
    InformationalException {

    final AppealStageTimeConstraintKey appealStageTimeConstraintKey =
      new AppealStageTimeConstraintKey();

    appealStageTimeConstraintKey.appealStageTimeConstraintID =
      key.appealStageTimeConstraintID;

    final AppealStageTimeConstraintDtls appealStageTimeConstraintDtls =
      read(appealStageTimeConstraintKey);

    validate(details);

    if (appealStageTimeConstraintDtls.recordStatus
      .equalsIgnoreCase(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            ENTAPPEALSTAGETIMECONSTRAINT.ERR_ENT_APPEAL_STAGE_TIME_CONTRAINT_RV_ALREADY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method validates the fields in the parameter struct
   * 
   * @param details The appealStageTimeConstraintDtls being validated for insert
   * or modify
   */
  protected void validate(final AppealStageTimeConstraintDtls details)
    throws AppException, InformationalException {

    if (!details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      if (details.numberOfDays <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              ENTAPPEALSTAGETIMECONSTRAINT.ERR_ENT_APPEAL_STAGE_TIME_CONTRAINT_FV_NUMBEROFDAYS_NOT_SPECIFIED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      if (details.constraintType.length() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              ENTAPPEALSTAGETIMECONSTRAINT.ERR_ENT_APPEAL_STAGE_TIME_CONTRAINT_FV_CONSTRAINTTYPE_NOT_SPECIFIED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      if (details.fromDate.equals(Date.kZeroDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .throwWithLookup(
            new AppException(
              ENTAPPEALSTAGETIMECONSTRAINT.ERR_ENT_APPEAL_STAGE_TIME_CONTRAINT_FV_FROMDATE_NOT_SPECIFIED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }
}
