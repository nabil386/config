/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.struct.ActiveAppealCaseStatus;
import curam.appeal.sl.entity.struct.ActiveAppealResolutionKey;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.ActiveAssessmentsByPDAndAppealType;
import curam.appeal.sl.entity.struct.ActiveByAppealCaseAndAppealTypeKey;
import curam.appeal.sl.entity.struct.ActiveCaseKey;
import curam.appeal.sl.entity.struct.ActiveDecisionsByCaseAndAppealTypeKey;
import curam.appeal.sl.entity.struct.ActiveDecisionsByCaseKey;
import curam.appeal.sl.entity.struct.AppealCaseAndCase;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseStatus;
import curam.appeal.sl.entity.struct.AppealCaseStatusDetails;
import curam.appeal.sl.entity.struct.AppealRelationshipDtls;
import curam.appeal.sl.entity.struct.AppealRelationshipKey;
import curam.appeal.sl.entity.struct.CaseIDTypeAndBenefitsDetails;
import curam.appeal.sl.entity.struct.CasePriorCaseStatus;
import curam.appeal.sl.entity.struct.CaseStatus;
import curam.appeal.sl.entity.struct.ModifyAppealedCaseDetails;
import curam.appeal.sl.entity.struct.NormalAndApprovedAppealCaseStatus;
import curam.appeal.sl.entity.struct.NormalAppealCaseStatus;
import curam.appeal.sl.entity.struct.PriorCaseStatus;
import curam.appeal.sl.entity.struct.ReceiptNotice;
import curam.appeal.sl.entity.struct.ReceiptNoticeKey;
import curam.appeal.sl.entity.struct.ResolutionDetails;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.CASERELATIONSHIPTYPECODE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseTypeCode;
import curam.message.BPOAPPEALEDCASE;
import curam.message.BPOAPPEALRELATIONSHIP;
import curam.message.BPOISSUEAPPEALRELATIONSHIP;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.type.Date;

/**
 * The AppealRelationhip entity maintains the list of cases being appealed by
 * an appeal case. Therefore for each appeal case there will be one or more
 * AppealRelationship records - one for each case under appeal.
 */
public abstract class AppealRelationship extends
  curam.appeal.sl.entity.base.AppealRelationship {

  // ___________________________________________________________________________
  /**
   * Set the case status before performing the search
   * 
   * @param key Contains the statuses to set
   */
  @Override
  protected void presearchActiveAppealByCase(final CaseStatus key)
    throws AppException, InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the case status before performing the search
   * 
   * @param key Contains the statuses to set
   */
  @Override
  protected void presearchActiveAppealByCaseAndPriorAppealCase(
    final CasePriorCaseStatus key) throws AppException,
    InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the case status and record status before performing the search
   * 
   * @param key Contains the statuses to set
   */
  @Override
  protected void presearchActiveDecisionsByCaseAndAppealType(
    final ActiveDecisionsByCaseAndAppealTypeKey key) throws AppException,
    InformationalException {

    key.caseClosedStatus = CASESTATUS.CLOSED;
    key.activeRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the record status before performing the search
   * 
   * @param key Contains the status to set
   */
  @Override
  protected void presearchActiveDecisionsByAppealCase(
    final AppealCaseStatus key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Validate the appeal relationship entry
   * 
   * @param details Contains fields to validate
   */
  @Override
  protected void validate(final AppealRelationshipDtls details)
    throws AppException, InformationalException {

    CaseStartDate caseStartDate;
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final InformationalManager informationalManager =
      new InformationalManager();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.caseID;

    // CaseID must be supplied
    if (details.caseID == 0) {

      throw new AppException(BPOAPPEALRELATIONSHIP.ERR_FV_CASEID);

    }

    // AppealCaseID must be supplied
    if (details.appealCaseID == 0) {

      throw new AppException(BPOAPPEALRELATIONSHIP.ERR_FV_APPEALCASEID);

    }

    // ReceivedDate must be supplied
    if (details.receivedDate.isZero()) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALRECEIPTDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Method of receipt must be supplied
    if (details.receiptMethod.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_RECEIPTMETHOD), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Appeal decision date must be supplied
    if (details.appealedDecisionDate.isZero()) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALDECISIONDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // ReasonCode must be supplied
    if (details.reasonCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_REASONCODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Today's date
    final curam.util.type.Date currentDate =
      curam.util.type.Date.getCurrentDate();

    // Appealed decision date must not be in the future
    if (details.appealedDecisionDate.after(currentDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALDECISIONDATE_FUTURE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Received date must not be in the future
    if (details.receivedDate.after(currentDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_RECEIVEDDATE_FUTURE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Received date must not be before appealed decision date
    if (details.receivedDate.before(details.appealedDecisionDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_XFV_RECEIVEDBEFOREDECISION),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // changed the condition to compare Effective with Case start date
    caseHeaderKey.caseID = details.caseID;
    caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);

    // BEGIN, CR00086073, RKi
    CaseTypeCode caseTypeCode = new CaseTypeCode();

    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (details.appealedDecisionDate.before(caseStartDate.startDate)) {
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XFV_RESOLUTIONDATE_BEFORE_CASESTARTDATE),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager
          .addInformationalMsg(
            new AppException(
              BPOAPPEALEDCASE.ERR_APPEALEDCASE_XFV_EFFECTIVEDATE_BEFORE_CASESTARTDATE),
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }
    // END, CR00086073

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Set the case status and types before performing the search
   * 
   * @param key Contains the status and types to set
   */
  @Override
  protected void presearchActiveAssessmentsByProductDeliveryAndAppealType(
    final ActiveAssessmentsByPDAndAppealType key) throws AppException,
    InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.assessmentProduct = CASERELATIONSHIPTYPECODE.ASSESSMENTPRODUCT;
    key.linkedCases = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    key.defaultRecordStatus = RECORDSTATUS.DEFAULTCODE;

  }

  // ___________________________________________________________________________
  /**
   * Set the case status before performing the search
   * 
   * @param key Contains the status to set
   */
  @Override
  protected void presearchActiveAppealByCaseAndAppealType(
    final ActiveByAppealCaseAndAppealTypeKey key) throws AppException,
    InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;

  }

  // ___________________________________________________________________________
  /**
   * Calls validation before insert
   * 
   * @param details Contains the details of the record to insert
   */
  @Override
  protected void preinsert(final AppealRelationshipDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validate the Appealed Case details before modification
   * 
   * @param details Appealed Case details
   */
  @Override
  protected void premodifyDetails(final AppealRelationshipKey key,
    final ModifyAppealedCaseDetails details) throws AppException,
    InformationalException {

    // BEGIN, CR00022466, RKi
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    appealRelationshipKey.appealRelationshipID = key.appealRelationshipID;
    CaseIDTypeAndBenefitsDetails caseIDTypeAndBenefitsDetails =
      new CaseIDTypeAndBenefitsDetails();

    caseIDTypeAndBenefitsDetails =
      appealRelationshipObj
        .readCaseIDCaseTypeAndContinueBenefits(appealRelationshipKey);
    if (CASETYPECODE.ISSUE.equals(caseIDTypeAndBenefitsDetails.caseType)) {
      validateIssueModify(key, details);
    } else {
      validateModify(details);
    }
    // END, CR00022466
  }

  // BEGIN, CR00022466, RKi
  // ___________________________________________________________________________
  /**
   * Validate the modified details for the Appealed Case
   * 
   * @param details Appealed Case details
   */
  @Override
  public void validateIssueModify(final AppealRelationshipKey key,
    final ModifyAppealedCaseDetails details) throws AppException,
    InformationalException {

    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealCaseID appealCaseID = new AppealCaseID();
    CaseHeaderDtls caseHeaderDtls;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    appealCaseID = appealRelationshipObj.readAppealCaseID(key);
    caseHeaderKey.caseID = appealCaseID.appealCaseID;
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Check for missing values in required fields
    if (details.receivedDate.isZero()) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALRECEIPTDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.receiptMethod.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_RECEIPTMETHOD), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.appealedDecisionDate.isZero()) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALDECISIONDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.reasonCode.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_REASONCODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Check for inconsistent dates
    if (details.receivedDate.after(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOISSUEAPPEALRELATIONSHIP.ERR_FV_ISSUERECEIVEDDATE_FUTURE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    if (details.receivedDate.before(caseHeaderDtls.startDate)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALRELATIONSHIP.ERR_FV_ISSUERECEIVEDDATE_EARLIER_THAN_APPEALSTARTDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    if (details.appealedDecisionDate.after(caseHeaderDtls.startDate)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOISSUEAPPEALRELATIONSHIP.ERR_FV_RESOLUTIONAPPROVALDATE_AFTER_APPEALSTARTDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    if (CASESTATUS.CANCELED.equals(caseHeaderDtls.statusCode)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOISSUEAPPEALRELATIONSHIP.ERR_FV_APPEALCASE_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    ResolutionDetails resolutionDetails;

    resolutionDetails = appealRelationshipObj.readResolution(key);
    if (!HEARINGDECISIONRESOLUTION.NOTDECIDED
      .equals(resolutionDetails.resolutionCode)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOISSUEAPPEALRELATIONSHIP.ERR_FV_APPEALCASEDECISION_NOTDECIDED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Report any validation errors found
    informationalManager.failOperation();

  }

  // END, CR00022466

  // ___________________________________________________________________________
  /**
   * Validate the modified details for the Appealed Case
   * 
   * @param details Appealed Case details
   */
  @Override
  protected void validateModify(final ModifyAppealedCaseDetails details)
    throws AppException, InformationalException {

    // Variable for reporting of validation errors
    final InformationalManager informationalManager =
      new InformationalManager();

    // Check for missing values in required fields
    if (details.receivedDate.isZero()) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALRECEIPTDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.receiptMethod.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_RECEIPTMETHOD), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.appealedDecisionDate.isZero()) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALDECISIONDATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    if (details.reasonCode.length() == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_REASONCODE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Check for inconsistent dates
    if (details.receivedDate.after(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_RECEIVEDDATE_FUTURE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    if (details.appealedDecisionDate.after(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_FV_APPEALDECISIONDATE_FUTURE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    if (details.receivedDate.before(details.appealedDecisionDate)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALRELATIONSHIP.ERR_XFV_RECEIVEDBEFOREDECISION),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Report any validation errors found
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Set the appeal case status before performing the count
   * 
   * @param key Contains the case status to set
   */
  @Override
  protected void precountActiveAppealedCasesByAppealCase(
    final NormalAppealCaseStatus key) throws AppException,
    InformationalException {

    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the prior appeal case status before performing the count
   * 
   * @param key Contains the prior case status to set
   */
  @Override
  protected void precountActiveAppealByPriorAppealCase(
    final PriorCaseStatus key) throws AppException, InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the appeal case status before performing the count
   * 
   * @param key Contains the prior case status to set
   */
  @Override
  protected void precountActiveAppealByCase(final CaseStatus key)
    throws AppException, InformationalException {

    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.openStatusCode = CASESTATUS.OPEN;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Set the appeal case status before performing the count
   * 
   * @param key Contains the prior case status to set
   */
  @Override
  protected void precountActiveByAppealIntegratedCase(
    final NormalAppealCaseStatus key) throws AppException,
    InformationalException {

    key.normalRecordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveResolutionDetailsByAppealCase method so that only active
   * appealed cases are considered. Active in this instance means records with
   * an active recordStatus and appealed cases which have been approved.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case resolutions.
   */
  @Override
  protected void presearchActiveResolutionDetailsByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveResolutionByAppealCase method so that only active
   * appealed cases are considered. Active in this instance means records with
   * an active recordStatus and appealed cases which have been approved.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case resolutions.
   */
  @Override
  protected void presearchActiveResolutionByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveCaseOwnerByAppealCase method so that only active
   * appealed cases are considered. Active in this instance means records with
   * an active recordStatus and appealed cases which have been approved.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case resolutions.
   */
  @Override
  protected void presearchActiveCaseOwnerByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActivePriorCaseOwnerByAppealCase method so that only active
   * appealed cases are considered. Active in this instance means records with
   * an active recordStatus and appealed cases which have been approved.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case resolutions.
   */
  @Override
  protected void presearchActivePriorCaseOwnerByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveBenefitPriorAppealAndCaseTypeByAppealCase method so that only
   * active appealed cases are considered. Active in this instance means
   * records with an active recordStatus.
   * 
   * @param key The fields required to retrieve active appealed
   * case resolutions.
   */
  @Override
  protected void presearchActiveBenefitPriorAppealAndCaseTypeByAppealCase(
    final ActiveCaseKey key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensure the record status and existing receipt notice indicator
   * are set for the call to countOutstandingReceiptNoticesByAppealCase
   * so that only active records with outstanding receipt
   * notices for a given appeal case will be counted
   * 
   * @param key The appeal case ID and other details
   */
  @Override
  protected void precountOutstandingReceiptNoticesByAppealCase(
    final ReceiptNoticeKey key) throws AppException, InformationalException {

    key.receiptNoticeIndicator = false;
    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensure the record status and existing receipt notice indicator
   * are set for the call to
   * modifyOutstandingReceiptNoticeIndicatorByAppealCase
   * so that only active records with outstanding receipt
   * notices for a given appeal case will be modified
   * 
   * @param key The appeal case ID and other details
   * @param details The new value for the receipt notice indicator
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /**
   * The details cannot be removed as it will
   * be used by the base modifyOutstandingReceiptNoticeIndicatorByAppealCase
   * method.
   */
  protected void premodifyOutstandingReceiptNoticeIndicatorByAppealCase(
    final ReceiptNoticeKey key, final ReceiptNotice details)
    throws AppException, InformationalException {

    key.receiptNoticeIndicator = false;
    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensure that only active appealed cases where the receipt notice generation
   * is outstanding are returned.
   * 
   * @param key The appeal case to retrieve outstanding receipt notices for.
   */
  @Override
  protected void presearchOutstandingReceiptNoticeDetailsByAppealCase(
    final ReceiptNoticeKey key) throws AppException, InformationalException {

    key.receiptNoticeIndicator = false;
    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active and approved appeal relationship deadline dates
   * are considered when determining the earliest deadline date for an appeal
   * case.
   * 
   * @param key The appeal caseID to determine the earliest deadline date
   */
  @Override
  protected void prereadMinActiveApprovedDeadlineDateByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active appeal relationships records are considered. Also
   * ensures that only closed prior appeal cases are considered.
   * 
   * @param key The appeal decision search criteria
   */
  @Override
  protected void presearchActiveDecisionsByCase(
    final ActiveDecisionsByCaseKey key) throws AppException,
    InformationalException {

    key.caseClosedStatus = CASESTATUS.CLOSED;
    key.activeRecordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensure that only active records are considered when reading for
   * the prior appeal case of an appeal case and implementation case
   * 
   * @param key Identifies the appeal case and implementation case
   */

  @Override
  protected void prereadPriorAppealByAppealCaseAndCase(
    final AppealCaseAndCase key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensure that only active appeal relationship records are considered
   * when determining the number of records.
   * 
   * @param key The appealCaseID, resolutionCode and recordStatus to read for.
   */
  @Override
  protected void precountActiveByAppealCaseAndResolution(
    final ActiveAppealResolutionKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    // HARP, BEGIN 52077, KY
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
    // HARP, END 52077
  }

  // ___________________________________________________________________________
  /**
   * Ensure that only active appeal relationship records are considered
   * when determining the appeal decision date.
   * 
   * @param details The appealCaseID, statusCode to read for.
   */
  @Override
  protected void prereadActiveAppealDecisionDate(
    final AppealCaseStatusDetails details) throws AppException,
    InformationalException {

    details.statusCode = RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchDeadlineDetailsByAppealCase method so that only active & approved
   * appealed cases are considered.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case deadline details.
   */
  @Override
  protected void presearchDeadlineDetailsByAppealCase(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchDeadlineDetailsByAppealCase method so that only active & approved
   * appealed cases are considered.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case deadline details.
   */
  @Override
  protected void presearchEarliestDeadlineDetails(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Set the appeal case caseStatus and recordStatus before performing the count
   * 
   * @param key Contains the case status to set
   */
  @Override
  protected void precountActiveAndApprovedAppealedCasesByAppealCase(
    final NormalAndApprovedAppealCaseStatus key) throws AppException,
    InformationalException {

    key.normalRecordStatus = RECORDSTATUS.NORMAL;
    key.approvedStatusCode = APPEALRELATIONSHIPSTATUS.APPROVED;

  }

  // ___________________________________________________________________________
  /**
   * Returns resolution details for each appealed case on a specified appeal.
   * Only active and approved appealed cases are retrieved.
   * 
   * @param key The fields required to retrieve active and approved appealed
   * case resolution details.
   */
  @Override
  protected void presearchAppealedCaseResolutionDetails(
    final ActiveApprovedCaseKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveAppealedCaseDetailsByAppealCase method so that only active
   * appealed cases are considered.
   * 
   * @param key The fields required to retrieve active appealed cases.
   */
  @Override
  public void presearchActiveAppealedCaseDetailsByAppealCase(
    final ActiveAppealCaseStatus key) throws AppException,
    InformationalException {

    key.normalRecordStatus = RECORDSTATUS.NORMAL;
    key.activeStatusCode = CASESTATUS.ACTIVE;
    key.approvedStatusCode = CASESTATUS.APPROVED;
    key.openStatusCode = CASESTATUS.OPEN;
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the input parameters are set for the call to the
   * searchActiveDeadlineDetailsByAppealCase method so that only active
   * appealed cases are considered.
   * 
   * @param key The fields required to retrieve active appealed cases.
   */
  @Override
  public void presearchActiveDeadlineDetailsByAppealCase(
    final ActiveCaseKey key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

}
