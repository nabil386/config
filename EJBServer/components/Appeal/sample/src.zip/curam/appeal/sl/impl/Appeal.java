/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.facade.struct.HearingCaseSummaryKey;
import curam.appeal.facade.struct.HearingReviewCaseIDKey;
import curam.appeal.facade.struct.JudicialReviewCaseKey_fo;
import curam.appeal.impl.AppealEvents;
import curam.appeal.impl.Appealable;
import curam.appeal.impl.AppealableCaseType;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.AppealObjectFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealStageTimeConstraintFactory;
import curam.appeal.sl.entity.fact.HearingDecisionAttachmentLinkFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.AppealObject;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Appellant;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingDecisionAttachmentLink;
import curam.appeal.sl.entity.struct.ActiveAppealCaseDetailsList;
import curam.appeal.sl.entity.struct.ActiveAppealCaseKey;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.ActiveByAppealCaseAndAppealTypeKey;
import curam.appeal.sl.entity.struct.ActiveDecisionsByCaseKey;
import curam.appeal.sl.entity.struct.AllAppealParticipantsKey;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseIDList;
import curam.appeal.sl.entity.struct.AppealCaseIDOrProductDeliveryID;
import curam.appeal.sl.entity.struct.AppealCaseIDTYypeRecordStatusDetails;
import curam.appeal.sl.entity.struct.AppealCaseParticipantTabDetailList;
import curam.appeal.sl.entity.struct.AppealCaseStatus;
import curam.appeal.sl.entity.struct.AppealCountDetails;
import curam.appeal.sl.entity.struct.AppealKey;
import curam.appeal.sl.entity.struct.AppealModifyReadDetails;
import curam.appeal.sl.entity.struct.AppealModifyWithoutDeadlineDetails;
import curam.appeal.sl.entity.struct.AppealObjectDtls;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStruct;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStruct1;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStruct1List;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStructList;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct1;
import curam.appeal.sl.entity.struct.AppealRelatedByCaseDetailsList;
import curam.appeal.sl.entity.struct.AppealRelatedByCaseKey;
import curam.appeal.sl.entity.struct.AppealRelatedByTypeStatusDetailsList;
import curam.appeal.sl.entity.struct.AppealRelatedByTypeStatusKey;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppealRelationshipDtls;
import curam.appeal.sl.entity.struct.AppealResolutionsList;
import curam.appeal.sl.entity.struct.AppealStageTimeConstraintDtlsStruct1;
import curam.appeal.sl.entity.struct.AppealStageTimeConstraintDtlsStruct1List;
import curam.appeal.sl.entity.struct.AppealStageTimeConstraintKeyStruct1;
import curam.appeal.sl.entity.struct.AppealTimeConstraintKey;
import curam.appeal.sl.entity.struct.AppealTypeAndAppellantTypeDetails;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppealValidationModifyDetails;
import curam.appeal.sl.entity.struct.AppealedCaseCountDetails;
import curam.appeal.sl.entity.struct.AppealedCaseDetails;
import curam.appeal.sl.entity.struct.AppealedCaseDetails1;
import curam.appeal.sl.entity.struct.BehalfOfCodeHW;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseIDAndDeadlineDateList;
import curam.appeal.sl.entity.struct.CaseStatus;
import curam.appeal.sl.entity.struct.HearingCaseID;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionResolutionCodeDetails;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantIDKeyHW;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;
import curam.appeal.sl.entity.struct.HearingScheduleDate;
import curam.appeal.sl.entity.struct.HearingScheduleDetails;
import curam.appeal.sl.entity.struct.OverallDecisionDetails;
import curam.appeal.sl.entity.struct.OwnerNameAndFullName;
import curam.appeal.sl.entity.struct.PriorCaseStatus;
import curam.appeal.sl.entity.struct.ReadSummaryDetails;
import curam.appeal.sl.entity.struct.ReceiptNotice;
import curam.appeal.sl.entity.struct.ReceiptNoticeKey;
import curam.appeal.sl.entity.struct.UserSupervisorKey;
import curam.appeal.sl.fact.AppealDecisionFactory;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.AppealableCaseTypeAppealProcessFactory;
import curam.appeal.sl.fact.AppealedCaseApprovalFactory;
import curam.appeal.sl.fact.AppealedCaseFactory;
import curam.appeal.sl.fact.AppellantFactory;
import curam.appeal.sl.fact.HearingCaseFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.fact.HearingReviewFactory;
import curam.appeal.sl.fact.IntegratedCaseAppealProcessFactory;
import curam.appeal.sl.fact.IssueAppealProcessFactory;
import curam.appeal.sl.fact.JudicialReviewFactory;
import curam.appeal.sl.fact.ParticipantValidationFactory;
import curam.appeal.sl.fact.ProductAppealProcessFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.AppealedCaseApproval;
import curam.appeal.sl.intf.HearingCase;
import curam.appeal.sl.intf.HearingReview;
import curam.appeal.sl.intf.JudicialReview;
import curam.appeal.sl.intf.ParticipantValidation;
import curam.appeal.sl.intf.ProductAppealProcess;
import curam.appeal.sl.struct.*;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.attachment.impl.Attachment;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALEDCASETYPE;
import curam.codetable.APPEALOBJECTTYPE;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.CASERELATIONSHIPSTATUSCODE;
import curam.codetable.CASERELATIONSHIPTYPECODE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CONSTRAINTTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.DECISIONATTACHMENTTYPE;
import curam.codetable.DOCUMENTTYPE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.ONBEHALFOF;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONSTATUSCODE;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKPRIORITY;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.AddressFactory;
import curam.core.fact.AdminIntegratedCaseFactory;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseGroupsFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.CaseSecurityFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.DetermineCaseTypeFactory;
import curam.core.fact.MaintainAdminIntegratedCaseFactory;
import curam.core.fact.MaintainAttachmentFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.ProductFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.Address;
import curam.core.intf.AdminIntegratedCase;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseGroups;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.CaseSecurity;
import curam.core.intf.ConcernRole;
import curam.core.intf.DetermineCaseType;
import curam.core.intf.MaintainAdminIntegratedCase;
import curam.core.intf.Notification;
import curam.core.intf.Product;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.IssueConfigurationFactory;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.fact.ResolutionFactory;
import curam.core.sl.entity.intf.IssueConfiguration;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.core.sl.entity.intf.Resolution;
import curam.core.sl.entity.struct.AppealableIssues;
import curam.core.sl.entity.struct.AppealableIssuesList;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.ResolutionDtls;
import curam.core.sl.entity.struct.ResolutionStatus;
import curam.core.sl.entity.struct.TypeAndStatusAndParticipantRoleDetails;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.TaskManagementFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.TaskManagement;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.AppealableCaseTypeDetails;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CaseParticipantRoleDetails;
import curam.core.sl.struct.CreateStandardManualTaskDetails;
import curam.core.sl.struct.OrgObjectDetails;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.sl.struct.TaskCreateDetails;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AppealableIntegratedCases;
import curam.core.struct.AppealableIntegratedCasesList;
import curam.core.struct.AppealableProducts;
import curam.core.struct.AppealableProductsList;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseAppealIndicatorDetails;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseGroupsDtlsList;
import curam.core.struct.CaseGroupsReadmultiKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderReadmultiDetails1;
import curam.core.struct.CaseHeaderReadmultiDetails1List;
import curam.core.struct.CaseHeaderReadmultiKey1;
import curam.core.struct.CaseHeaderStatus;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDList;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReceivedDateVersionDetails;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseRegDateEndDateDetails;
import curam.core.struct.CaseRelByCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelByRelatedCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusEndDateTimeDetails;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.CaseStatusOwnerReferenceDetails;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CasesByOwnerKey;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernNameAddressDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ConcernRoleNameTypeAndAlternateID;
import curam.core.struct.Count;
import curam.core.struct.CreateCaseAttachmentDetails;
import curam.core.struct.CuramInd;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DetermineCaseTypeDtls;
import curam.core.struct.DetermineCaseTypeKey;
import curam.core.struct.GetCasesByOwnerResult;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.ICParticipantHomePageKey;
import curam.core.struct.ICParticipantHomePageName;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.NameAddressReadKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ReadAttachmentIn;
import curam.core.struct.ReadAttachmentOut;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.core.struct.SecurityResult;
import curam.core.struct.UserNameDetails;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.core.struct.VersionNumberDetails;
import curam.message.APPEALOBJECT;
import curam.message.APPEALSTAGE;
import curam.message.BPOAPPEAL;
import curam.message.BPOAPPEALCLIENTMERGE;
import curam.message.BPOAPPEALCOMMUNICATION;
import curam.message.BPOHEARINGCASE;
import curam.message.BPOHEARINGREVIEW;
import curam.piwrapper.caseconfiguration.impl.CaseConfiguration;
import curam.piwrapper.caseconfiguration.impl.CaseConfigurationDAO;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

/**
 * This process class provides the functionality for the Appeal service layer.
 *
 */
public abstract class Appeal extends curam.appeal.sl.base.Appeal {

  // BEGIN,, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;

  // BEGIN, CR00282959, DG
  @Inject
  private Map<APPEALOBJECTTYPEEntry, Appealable> appealableMap;

  @Inject
  private Map<CASETYPECODEEntry, AppealableCaseType> appealableCaseTypeMap;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  private CaseConfigurationDAO caseConfigurationDAO;

  // END, CR00282959

  // Add injection for using the new Attachment API
  public Appeal() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END,, CR00226594

  // BEGIN, CR00424946, DM
  @Inject
  private AppealEvents appealEvents;

  // END, CR00424946

  protected static final String kDesc = GeneralAppealConstants.kDescription;

  protected static final String kItem = GeneralAppealConstants.kLink;

  protected static final String kName = GeneralAppealConstants.kName;

  protected static final String kNavigationMenu =
    GeneralAppealConstants.kDynamicMenu;

  protected static final String kPageID = GeneralAppealConstants.kPageID;

  protected static final String kParam = GeneralAppealConstants.kParameter;

  protected static final String kParamCaseID =
    GeneralAppealConstants.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID =
    GeneralAppealConstants.kParamCaseParticipantRoleID;

  protected static final String kSeparator =
    GeneralAppealConstants.kSeparator;

  protected static final String kType = GeneralAppealConstants.kType;

  protected static final String kTypeCase = GeneralAppealConstants.kTypeCase;

  protected static final String kTypeProduct =
    GeneralAppealConstants.kTypeProduct;

  protected static final String kValue = GeneralAppealConstants.kValue;

  protected static final String kHearing = GeneralAppealConstants.kHearing;

  protected static final String kHearingReview =
    GeneralAppealConstants.kHearingReview;

  protected static final String kJudicialReview =
    GeneralAppealConstants.kJudicialReview;

  protected static final short kMaxActiveParticipants =
    GeneralAppealConstants.kMaxActiveParticipants;

  protected static final String kTypeIssue =
    GeneralAppealConstants.kTypeIssue;

  // Work flow constants
  protected static final String kEventClass =
    GeneralAppealConstants.kEventClass;

  protected static final String kManual = GeneralAppealConstants.kManual;

  protected static final String kAppealCompleteHearingTask =
    GeneralAppealConstants.kAppealCompleteHearingTask;

  protected static final String kAppealCloseCompleteHearingTask =
    GeneralAppealConstants.kAppealCloseCompleteHearingTask;

  protected static final String kAppealDeadlineTask =
    GeneralAppealConstants.kAppealDeadlineTask;

  protected static final String kAppealScheduleHearingTask =
    GeneralAppealConstants.kAppealScheduleHearingTask;

  protected static final String kAppealImplementationDeadlineTask =
    GeneralAppealConstants.kAppealImplementationDeadlineTask;

  protected static final String kAppealStandardTask =
    GeneralAppealConstants.kAppealStandardTask;

  protected static final String kAppealNotificationTask =
    GeneralAppealConstants.kAppealNotificationTask;

  // The following are temporary constants and will be calculated later
  // default days in the future for calculations.
  protected static final int kDefaultDaysInFuture =
    GeneralAppealConstants.kDefaultDaysInFuture;

  // default days for timely calculations
  protected static final int kDefaultDaysForRequest =
    GeneralAppealConstants.kDefaultDaysForRequest;

  // ___________________________________________________________________________
  /**
   * Creates a deadline task
   *
   * @param details
   * Details of the deadline task
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public void createDeadlineTask(final CaseIDDeadlineDate details)
    throws AppException, InformationalException {

    // Create the list we will pass to the enactment service.
    final java.util.List enactmentStructs = new java.util.ArrayList();
    final TaskCreateDetails taskCreateDetails = new TaskCreateDetails();

    // Set Task CaseID & DeadlineDate
    taskCreateDetails.caseID = details.caseID;
    taskCreateDetails.deadlineDateTime = details.deadlineDate.getDateTime();

    enactmentStructs.add(taskCreateDetails);

    // Enact work flow to create the appeal deadline Task.
    curam.util.workflow.impl.EnactmentService
      .startProcess(kAppealDeadlineTask, enactmentStructs);
  }

  // __________________________________________________________________________
  /**
   * Creates User Roles for the case owner and case supervisor
   *
   * @param details
   * The details of the user role being created
   */
  @Override
  public void createUserRoles(final CreateUserRoleDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00071911, RKi
    // CaseUserRole object
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    // Set the case header key to be the current case id
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.appealCaseID;

    // Create the case owner
    // the case owner will default to the current user
    caseUserRole.createOwner(caseHeaderKey, new OrgObjectLinkDtls());

    // END, CR00071911

  }

  // __________________________________________________________________________
  /**
   * Retrieves the appeal context description details
   *
   * @param key
   * Appeal case key
   *
   * @return The appeal context description details
   */
  @Override
  public AppealContextDescription getContextDescription(
    final AppealCaseDetails key) throws AppException, InformationalException {

    // Return details
    final AppealContextDescription appealContextDescription =
      new AppealContextDescription();

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseReference caseReference;

    // Appellant variables
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppellantDetails readAppellantDetails;
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Read the appellant type for the case
    appealCaseIDKey.caseID = key.caseID;

    caseSearchKey.caseID = key.caseID;
    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    appealCaseKey.caseID = key.caseID;
    readAppellantDetails = readAppellantDetails(appealCaseKey);

    // BEGIN, CR00078516, RKi
    if (!readAppellantDetails.concernRoleNameDetails.concernRoleName
      .equals("")) {
      appealContextDescription.description = new StringBuffer(
        readAppellantDetails.concernRoleNameDetails.concernRoleName)
          .append(kSeparator).append(caseReference.caseReference).toString();
    }
    // END, CR00078516

    // Get the appeal and appellant type details
    AppealTypeAndAppellantTypeDetails appealTypeAndAppellantTypeDetails;

    appealCaseIDKey.caseID = key.caseID;
    appealTypeAndAppellantTypeDetails =
      appealObj.readAppealTypeAppellantTypeByCase(appealCaseIDKey);

    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();

    ctitemKey.code = appealTypeAndAppellantTypeDetails.appealTypeCode;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = APPEALTYPE.TABLENAME;

    ctitem = codeTableInterface.getOneItem(ctitemKey);

    appealContextDescription.description =
      new StringBuffer(ctitem.description).append(kSeparator)
        .append(caseReference.caseReference).toString();

    // Return the context description
    return appealContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the appeal integrated case menu data
   *
   * @param key
   * Appeal case key
   *
   * @return The appeal integrated case menu data
   */
  @Override
  public AppealMenuData getMenuData(final AppealCaseDetails key)
    throws AppException, InformationalException {

    // Return details
    final AppealMenuData appealMenuData = new AppealMenuData();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // MaintainAdminIntegratedCase manipulation variable
    final MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj =
      MaintainAdminIntegratedCaseFactory.newInstance();

    final ICParticipantHomePageKey iCParticipantHomePageKey =
      new ICParticipantHomePageKey();
    ICParticipantHomePageName iCParticipantHomePageName =
      new ICParticipantHomePageName();

    // AppealCaseKey
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppellantDetails readAppellantDetails;

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeAndAppellantTypeDetails appealTypeAndAppellantTypeDetails;

    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;

    // BEGIN, 36709, CG

    // Get the appeal and appellant type details
    appealCaseIDKey.caseID = key.caseID;
    appealTypeAndAppellantTypeDetails =
      appealObj.readAppealTypeAppellantTypeByCase(appealCaseIDKey);

    // BEGIN, ,DK
    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    // Read the appellant details
    appealCaseKey.caseID = key.caseID;
    readAppellantDetails = readAppellantDetails(appealCaseKey);

    Element paramElement = new Element(kParam);

    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // Read the integrated case reference for the appeal case
    // BEGIN, CR00284786, DG
    caseKey.caseID = key.caseID;
    final boolean isIntegratedCaseInd =
      caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode
        .equals(CASETYPECODE.INTEGRATEDCASE);
    final IntegratedCaseReferenceKey integratedCaseReferenceKey =
      new IntegratedCaseReferenceKey();

    if (isIntegratedCaseInd) {
      integratedCaseReferenceKey.integratedCaseID = key.caseID;
      integratedCaseReferenceKey.caseReference =
        caseHeaderObj.readCaseReferenceAndICType(caseKey).caseReference;
    } else {
      integratedCaseReferenceKey.integratedCaseID =
        caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;
    }
    // END, CR00284786
    // END, 36709, CG
    if (integratedCaseReferenceKey.integratedCaseID != 0) {
      // Read IC page names, type and concern details
      icPageNamesICTypeAndConcernDetails =
        caseHeaderObj.readICPageNamesICTypeAndConcernDetails(caseKey);

      description.arg(new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
        icPageNamesICTypeAndConcernDetails.integratedCaseType));

      caseSearchKey.caseID = integratedCaseReferenceKey.integratedCaseID;

      description.arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

      linkElement.setAttribute(kPageID,
        icPageNamesICTypeAndConcernDetails.homePageName);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      linkElement.setAttribute(kType, kTypeCase);

      navigationMenuElement.addContent(linkElement);

      paramElement.setAttribute(kName, kParamCaseID);
      paramElement.setAttribute(kValue,
        String.valueOf(integratedCaseReferenceKey.integratedCaseID));

      linkElement.addContent(paramElement);

      // BEING, CR00078516, RKi
      // If Appellant Type Code is Organization
      if (!readAppellantDetails.concernRoleNameDetails.concernRoleName
        .equals("")) {
        // END, CR00078516
        iCParticipantHomePageKey.caseParticipantRoleID =
          readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;

        // Call MaintainAdminIntegratedCase BPO to read participant home
        // page name
        // and assign to the link element
        iCParticipantHomePageName = maintainAdminIntegratedCaseObj
          .getICParticipantHomePageName(iCParticipantHomePageKey);

        linkElement = new Element(kItem);

        description = new LocalisableString(
          curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

        description
          .arg(readAppellantDetails.concernRoleNameDetails.concernRoleName);

        linkElement.setAttribute(kDesc, description.toClientFormattedText());

        linkElement.setAttribute(kPageID,
          iCParticipantHomePageName.participantHomePageName);

        linkElement.setAttribute(kType,
          iCParticipantHomePageName.participantIconName);

        navigationMenuElement.addContent(linkElement);

        paramElement = new Element(kParam);

        paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
        paramElement.setAttribute(kValue,
          String.valueOf(iCParticipantHomePageKey.caseParticipantRoleID));

        linkElement.addContent(paramElement);
      }
    }
    // END, ,DK

    // BEGIN, CR00023223, RKi
    // checks if the appeal case is created on an issue case or a product
    // delivery case for the issue type(extra tab) to be displayed for the
    // appeal on issue case.
    final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
      new AppealCaseIDTYypeRecordStatusDetails();

    appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
    appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
    Count count;
    final AppealRelationship appealRelationship =
      AppealRelationshipFactory.newInstance();

    // counts the no. of issues cases attached to the appeal case.
    count = appealRelationship
      .countAppealedIssuesOnAppealCase(appealCaseIDTYypeRecordStatusDetails);

    // END, CR00023223

    paramElement = new Element(kParam);

    linkElement = new Element(kItem);

    final AppealParticipantHomePageName appealParticipantHomePageName =
      new AppealParticipantHomePageName();

    // Set the home page name depending upon the appeal type
    if (appealTypeAndAppellantTypeDetails.appealTypeCode
      .equals(curam.codetable.APPEALTYPE.HEARING)) {

      if (count.numberOfRecords >= 1) {

        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_HEARINGCASEISSUEHOMEFORIC);

        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kHearing;
        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_HEARINGCASEISSUEHOMEFORIC_DEFAULT;
        }
      } else {
        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration.getProperty(EnvVars.ENV_APPEAL_HEARINGCASEHOMEFORIC);

        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kHearing;

        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_HEARINGCASEHOMEFORIC_DEFAULT;
          // }
        }
      }

    } else if (appealTypeAndAppellantTypeDetails.appealTypeCode
      .equals(curam.codetable.APPEALTYPE.HEARINGREVIEW)) {

      if (count.numberOfRecords >= 1) {

        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_HEARINGREVIEWISSUEHOMEFORIC);

        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kHearing;
        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_HEARINGREVIEWISSUEHOMEFORIC_DEFAULT;
        }
      } else {
        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_HEARINGREVIEWHOMEFORIC);
        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kHearingReview;

        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_HEARINGREVIEWHOMEFORIC_DEFAULT;
        }
      }
    } else if (appealTypeAndAppellantTypeDetails.appealTypeCode
      .equals(curam.codetable.APPEALTYPE.JUDICIALREVIEW)) {

      if (count.numberOfRecords >= 1) {

        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_JUDICIALREVIEWISSUEHOMEFORIC);

        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kHearing;
        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_JUDICIALREVIEWISSUEHOMEFORIC_DEFAULT;
        }
      } else {
        appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
          Configuration
            .getProperty(EnvVars.ENV_APPEAL_JUDICIALREVIEWHOMEFORIC);

        appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
          kJudicialReview;

        if (appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName == null) {

          // set to the default value
          appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
            EnvVars.ENV_APPEAL_JUDICIALREVIEWHOMEFORIC_DEFAULT;
        }
      }
    }

    final String appealType = curam.util.type.CodeTable.getOneItem(
      curam.codetable.APPEALTYPE.TABLENAME,
      appealTypeAndAppellantTypeDetails.appealTypeCode);

    caseSearchKey.caseID = key.caseID;

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(appealType);

    description.arg(
      caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

    linkElement = new Element(kItem);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType,
      appealParticipantHomePageName.icParticipantHomePageName.participantIconName);

    linkElement.setAttribute(kPageID,
      appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    appealMenuData.menuData = outputter.outputString(navigationMenuElement);

    // Return the details
    return appealMenuData;

  }

  // ___________________________________________________________________________
  /**
   * This method returns the details of the appeal
   *
   * @param key
   * Contains the key of the appeal
   *
   * @return The appeal details
   */

  @Override
  public ReadAppealDetails readAppealDetails(final AppealCaseKey key)
    throws AppException, InformationalException {

    final ReadAppealDetails readAppealDetails = new ReadAppealDetails();

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.caseID;
    readAppealDetails.appealReadSummaryDetails =
      appealObj.readByCase(appealCaseIDKey);

    // Return the appeal details
    return readAppealDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method returns the appellant details
   *
   * @param key
   * The key of the appeal
   *
   * @return The appellant details
   */
  @Override
  public ReadAppellantDetails readAppellantDetails(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return details
    final ReadAppellantDetails readAppellantDetails =
      new ReadAppellantDetails();

    // CaseParticipantRole entity object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    // ConcernRole object
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetail;

    // Set the key
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    // Get the active participant for the case
    caseParticipantRoleIDDetailsList = caseParticipantRole_eoObj
      .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Display a Multiple appellant link if appellant are more than 1.
    if (caseParticipantRoleIDDetailsList.dtls.size() > 0) {

      readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).caseParticipantRoleID;
      readAppellantDetails.caseParticipantRoleIDDetails.participantRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      readAppellantDetails.caseParticipantRoleIDDetails.recordStatus =
        caseParticipantRoleIDDetailsList.dtls.item(0).recordStatus;

      concernRoleKey.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      concernRoleNameDetail =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // Assign the name
      readAppellantDetails.concernRoleNameDetails.concernRoleName =
        concernRoleNameDetail.concernRoleName;
    }

    // Return the appellant details
    return readAppellantDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the owner details
   *
   * @param key
   * Contains the caseID
   *
   * @return The owner details
   */
  @Override
  public ReadAppealUserDetails readOwnerDetails(final AppealCaseKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00053295, RKi
    // Return details
    final ReadAppealUserDetails readAppealUserDetails =
      new ReadAppealUserDetails();

    // Case User Role Variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

    // Case Header Variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // retrieves the case owner name
    caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

    // assign the user name to the return struct
    readAppealUserDetails.userName = caseOwnerDetails.userName;
    readAppealUserDetails.userFullname.fullname =
      caseOwnerDetails.userFullName;
    // END, CR00053295

    // Return the details
    return readAppealUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the home page name for an Appeal Case participant.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return The homepage name
   */
  @Override
  public AppealParticipantHomePageName
    resolveParticipantHome(final AppealParticipantHomePageKey key)
      throws AppException, InformationalException {

    // Return details
    final AppealParticipantHomePageName appealParticipantHomePageName =
      new AppealParticipantHomePageName();

    // MaintainAdminIntegratedCase manipulation variable
    final MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj =
      MaintainAdminIntegratedCaseFactory.newInstance();
    final ICParticipantHomePageKey iCParticipantHomePageKey =
      new ICParticipantHomePageKey();
    ICParticipantHomePageName iCParticipantHomePageName;

    // Assign key to read participant home page name
    iCParticipantHomePageKey.caseParticipantRoleID =
      key.icParticipantHomePageKey.caseParticipantRoleID;

    // Call MaintainAdminIntegratedCase BPO to read participant home page
    // name
    // and assign to return object
    iCParticipantHomePageName = maintainAdminIntegratedCaseObj
      .getICParticipantHomePageName(iCParticipantHomePageKey);

    // Assign the details
    appealParticipantHomePageName.icParticipantHomePageName.participantHomePageName =
      iCParticipantHomePageName.participantHomePageName;

    appealParticipantHomePageName.icParticipantHomePageName.participantIconName =
      iCParticipantHomePageName.participantIconName;

    // Return the details
    return appealParticipantHomePageName;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify appeal details
   *
   * @param dtls
   * The details of the appeal case
   * @param appealType
   * The type of appeal e.g. hearing/judicial case/review
   */
  @Override
  public void modify(final AppealModifyDetails dtls,
    final HearingAppealTypeCode appealType)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealKey appealKey = new AppealKey();
    final curam.appeal.sl.entity.struct.AppealModifyDetails appealModifyDetails =
      new curam.appeal.sl.entity.struct.AppealModifyDetails();

    // AppealValidationModifyDetails object
    AppealValidationModifyDetails appealValidationModifyDetails =
      new AppealValidationModifyDetails();

    // CaseHeader objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    final CaseReceivedDateVersionDetails caseReceivedDateVersionDetails =
      new CaseReceivedDateVersionDetails();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // OwnerID objects
    final OwnerNameAndFullName hearingCaseOwnerID =
      new OwnerNameAndFullName();

    // Notification objects
    final Notification notificationObj = NotificationFactory.newInstance();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = dtls.appealModifyReadDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    final CaseIDDeadlineDate caseIDDeadlineDate = new CaseIDDeadlineDate();

    // Validate appeal case details
    appealCaseIDKey.caseID = dtls.appealModifyReadDetails.caseID;
    appealValidationModifyDetails =
      appealObj.readValidationDetailsForModify(appealCaseIDKey);
    validateModify(dtls, appealValidationModifyDetails);

    // Check for "open" appeal status or if appeal type is judicial review
    if (appealValidationModifyDetails.statusCode.equals(CASESTATUS.OPEN)
      || appealType.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      // Set up AppealDeadlineDetails
      final AppealDeadlineDateDetails appealDeadlineDateDetails =
        new AppealDeadlineDateDetails();

      appealDeadlineDateDetails.caseID = dtls.appealModifyReadDetails.caseID;
      appealDeadlineDateDetails.appealType = appealType.appealTypeCode;
      appealDeadlineDateDetails.receivedDate =
        dtls.appealModifyReadDetails.receivedDate;

      // Check for modified receipt date
      if (!dtls.appealModifyReadDetails.receivedDate
        .equals(appealValidationModifyDetails.receivedDate)) {

        // Read hearing case owner
        caseHeaderKey.caseID = dtls.appealModifyReadDetails.caseID;
        // BEGIN, CR00053295, RKi
        final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();
        CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

        caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
        hearingCaseOwnerID.userName = caseOwnerDetails.userName;
        // END, CR00053295

        if (!hearingCaseOwnerID.userName
          .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

          // Set details for notification to send to hearing case
          // owner
          final StandardManualTaskDtls standardManualTaskDtls =
            new StandardManualTaskDtls();

          // Set Notification details
          standardManualTaskDtls.dtls.assignDtls.assignmentID =
            hearingCaseOwnerID.userName;

          standardManualTaskDtls.dtls.concerningDtls.caseID =
            dtls.appealModifyReadDetails.caseID;

          standardManualTaskDtls.dtls.taskDtls.comments =
            GeneralAppealConstants.kSpace;
          standardManualTaskDtls.dtls.taskDtls.subject =
            BPOAPPEAL.INF_APPEAL_FV_APPEALCASEDEADLINECHANGED
              .getMessageText();

          standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
            Appeal.kAppealNotificationTask;

          // Create notification
          notificationObj
            .createWorkAllocationNotification(standardManualTaskDtls);
        }

        // Update received date
        caseKey.caseID = dtls.appealModifyReadDetails.caseID;
        caseReceivedDateVersionDetails.receivedDate =
          dtls.appealModifyReadDetails.receivedDate;
        caseReceivedDateVersionDetails.versionNo =
          dtls.appealModifyReadDetails.caseHeaderVersionNo;
        caseHeaderObj.modifyReceivedDate(caseKey,
          caseReceivedDateVersionDetails);

        // Don't retrieve deadline date if appeal type is judicial
        // review
        if (!appealType.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

          // Call method to retrieve deadline date
          final DeadlineDate deadlineDate =
            getDeadlineDate(appealDeadlineDateDetails);

          appealModifyDetails.deadlineDate = deadlineDate.date;

          // Update deadline task
          caseIDDeadlineDate.deadlineDate = appealModifyDetails.deadlineDate;
          caseIDDeadlineDate.caseID = dtls.appealModifyReadDetails.caseID;
          modifyDeadlineTask(caseIDDeadlineDate);

        }
      }
    }

    // Update appeal case
    appealKey.appealID = dtls.appealModifyReadDetails.appealID;
    appealModifyDetails.assign(dtls.appealModifyReadDetails);

    if (appealType.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      final AppealModifyWithoutDeadlineDetails appealModifyWithoutDeadlineDetails =
        new AppealModifyWithoutDeadlineDetails();

      appealModifyWithoutDeadlineDetails.comments =
        appealModifyDetails.comments;
      appealModifyWithoutDeadlineDetails.versionNo =
        appealModifyDetails.versionNo;
      appealObj.modifyWithoutDeadlineDetails(appealKey,
        appealModifyWithoutDeadlineDetails);

    } else {

      appealObj.modify(appealKey, appealModifyDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to modify the appeal deadline task details
   *
   * @param caseIDDeadlineDate
   * The caseID and deadlineDate for the task
   */
  @Override
  public void modifyDeadlineTask(final CaseIDDeadlineDate caseIDDeadlineDate)
    throws AppException, InformationalException {

    // Work Flow event object
    final curam.util.events.struct.Event closeTaskEvent =
      new curam.util.events.struct.Event();

    closeTaskEvent.eventKey.eventClass = kEventClass;
    closeTaskEvent.eventKey.eventType = kAppealDeadlineTask;

    // Set the appeal caseID
    closeTaskEvent.primaryEventData = caseIDDeadlineDate.caseID;

    // Raise work flow event to close the existing deadline task.
    curam.util.events.impl.EventService.raiseEvent(closeTaskEvent);

    // Recreate deadline task
    createDeadlineTask(caseIDDeadlineDate);
  }

  // ___________________________________________________________________________
  /**
   * Method to read appeal details
   *
   * @param key
   * The key of the appeal case
   *
   * @return The appeal case details
   */
  @Override
  public AppealModifyDetails read(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return details
    final AppealModifyDetails appealModifyDetails = new AppealModifyDetails();

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Read the hearing case
    appealCaseIDKey.caseID = key.caseID;
    appealModifyDetails.appealModifyReadDetails =
      appealObj.readDetailsForModify(appealCaseIDKey);

    return appealModifyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate appeal modification details
   *
   * @param dtls
   * the appeal case modification details
   * @param existingDtls
   * the current appeal case details
   */
  @Override
  protected void validateModify(final AppealModifyDetails dtls,
    final AppealValidationModifyDetails existingDtls)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // - read appeal type
    appealCaseIDKey.caseID = dtls.appealModifyReadDetails.caseID;
    appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

    // Case Relationship manipulation variables
    final curam.core.intf.CaseRelationship caseRelationshipObj =
      curam.core.fact.CaseRelationshipFactory.newInstance();
    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    final InformationalManager informationalManager =
      new InformationalManager();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // Received date must be in the future
    // BEGIN, CR00269419, DM.
    boolean emptyDate = false;

    if (dtls.appealModifyReadDetails.receivedDate.after(currentDate)) {

      informationalManager.addInformationalMsg(
        new AppException(BPOAPPEAL.ERR_APPEAL_FV_RECEIVEDDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Received date must not be empty
    if (dtls.appealModifyReadDetails.receivedDate.isZero()) {

      informationalManager.addInformationalMsg(
        new AppException(BPOAPPEAL.ERR_APPEAL_FV_APPEALRECEIPTDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      emptyDate = true;

    }

    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      // Check for "active"
      if (!existingDtls.statusCode.equals(CASESTATUS.ACTIVE)) {

        throw new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_JUDICIALREVIEWMODIFYCASESTATUSINVALID);
      }

    } else {

      // Check for not appeal case status "open"
      if (!existingDtls.statusCode.equals(CASESTATUS.OPEN)) {

        // Check for "active" or "approved" hearing case status
        if (!(existingDtls.statusCode.equals(CASESTATUS.ACTIVE)
          || existingDtls.statusCode.equals(CASESTATUS.APPROVED))) {

          throw new AppException(
            BPOAPPEAL.ERR_APPEAL_FV_MODIFYCASESTATUSINVALID);
        }

        // Receipt date cannot be modified on approved case
        if (!dtls.appealModifyReadDetails.receivedDate
          .equals(existingDtls.receivedDate)) {

          informationalManager.addInformationalMsg(
            new AppException(
              BPOAPPEAL.ERR_APPEAL_FV_APPROVEDRECEIVEDATEMODIFIED),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }
      }
    }

    // determine appealed case id
    // BEGIN, CR00124669, RKi
    // variable to store the registration date
    Date registrationDate = Date.kZeroDate;

    // END, CR00124669

    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      // variable to lookup the related case
      final CaseRelByRelatedCaseIDStatusReasonTypeKey caseRelByRelatedCaseIDStatusReasonTypeKey =
        new CaseRelByRelatedCaseIDStatusReasonTypeKey();

      caseRelByRelatedCaseIDStatusReasonTypeKey.reasonCode =
        CASERELATIONSHIPREASONCODE.LINKEDCASES;
      caseRelByRelatedCaseIDStatusReasonTypeKey.relatedCaseID =
        dtls.appealModifyReadDetails.caseID;
      caseRelByRelatedCaseIDStatusReasonTypeKey.statusCode =
        RECORDSTATUS.DEFAULTCODE;
      caseRelByRelatedCaseIDStatusReasonTypeKey.typeCode =
        CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL;

      caseRelationshipDtlsList =
        caseRelationshipObj.searchByRelatedCaseIDStatusReasonType(
          caseRelByRelatedCaseIDStatusReasonTypeKey);
      // BEGIN, CR00124669, RKi
      if (caseRelationshipDtlsList.dtls.size() != 0) {
        caseHeaderKey.caseID = caseRelationshipDtlsList.dtls.item(0).caseID;

        registrationDate = caseHeaderObj
          .readRegDateAndReference(caseHeaderKey).registrationDate;
      }
      // END, CR00124669

    } else {

      // variable to lookup the related case
      final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
        new CaseRelByCaseIDStatusReasonTypeKey();

      caseRelByCaseIDStatusReasonTypeKey.caseID =
        dtls.appealModifyReadDetails.caseID;
      caseRelByCaseIDStatusReasonTypeKey.reasonCode =
        CASERELATIONSHIPREASONCODE.LINKEDCASES;
      caseRelByCaseIDStatusReasonTypeKey.statusCode =
        RECORDSTATUS.DEFAULTCODE;
      caseRelByCaseIDStatusReasonTypeKey.typeCode =
        CASERELATIONSHIPTYPECODE.APPEALAPPEAL;

      caseRelationshipDtlsList = caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);
      // BEGIN, CR00124669, RKi
      if (caseRelationshipDtlsList.dtls.size() != 0) {
        caseHeaderKey.caseID =
          caseRelationshipDtlsList.dtls.item(0).relatedCaseID;

        // BEGIN, CR00303986, SG
        final CaseRegDateEndDateDetails caseRegDateEndDateDetails =
          caseHeaderObj.readRegDateAndEndDate(caseHeaderKey);

        registrationDate = caseRegDateEndDateDetails.registrationDate;

        // The date received must not be before the end date of the
        // appealed case
        if (dtls.appealModifyReadDetails.receivedDate
          .before(caseRegDateEndDateDetails.endDate) && emptyDate == false) {
          // END, CR00303986

          informationalManager.addInformationalMsg(
            new AppException(
              BPOAPPEAL.ERR_APPEAL_XRV_DATERECEIVED_BEFORE_ENDDATE),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }
      }
      // END,CR00269419
      // END, CR00124669
    }
    // BEGIN, CR00124669, RKi
    if (registrationDate.equals(Date.kZeroDate)) {
      // The date received must not be before the registration date
      if (dtls.appealModifyReadDetails.receivedDate
        .before(registrationDate)) {
        informationalManager.addInformationalMsg(
          new AppException(
            BPOAPPEAL.ERR_APPEAL_XRV_DATERECEIVED_BEFORE_REGISTRATIONDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }
    // END, CR00124669

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Adds a statement to a hearing case
   *
   * @param details
   * The details of the statement being added
   *
   * @return Informational Messages, if any
   */
  @Override
  public InformationalMsgDtlsList
    addStatement(final AppealStatementDetails details)
      throws AppException, InformationalException {

    // Case Header objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusOwnerReferenceDetails caseStatusOwnerReferenceDetails;

    // CaseParticipantRole entity objects
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRole_eoKey =
      new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails;
    CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey;
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    long concernRoleID; // used when looking up appellant, respondent
    // or third party

    // AppealCaseStatusDetails objects
    final AppealCaseStatusDetails appealCaseStatusDetails =
      new AppealCaseStatusDetails();

    // MaintainAttachment objects
    final curam.core.intf.MaintainAttachment maintainAttachmentObj =
      MaintainAttachmentFactory.newInstance();
    final CreateCaseAttachmentDetails createCaseAttachmentDetails =
      new CreateCaseAttachmentDetails();

    // Hearing objects
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingScheduleDetails hearingScheduleDetails;

    // HearingWitness objects
    final curam.appeal.sl.entity.intf.HearingWitness hearingWitnessObj =
      curam.appeal.sl.entity.fact.HearingWitnessFactory.newInstance();
    HearingIDCaseParticipantIDKeyHW hearingIDCaseParticipantIDKeyHW;
    BehalfOfCodeHW behalfOfCodeHW;

    // AppealStatementCopyDetails object
    AppealStatementCopyDetails appealStatementCopyDetails;

    // Appeal details
    final AppealTimeConstraintKey appealTimeConstraintKey =
      new AppealTimeConstraintKey();
    final int submissionTimeLimit = 0;

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = details.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read case status, owner and reference no.
    caseHeaderKey.caseID = details.caseID;
    caseStatusOwnerReferenceDetails =
      caseHeaderObj.readStatusAndOwnerAndReference(caseHeaderKey);

    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      caseStatusOwnerReferenceDetails.ownerOrgObjectLinkID;
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
    // END, CR00053295

    // Read statement submitter details
    caseParticipantRole_eoKey.caseParticipantRoleID =
      details.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails = caseParticipantRole_eoObj
      .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

    // Validate statement
    appealCaseStatusDetails.statusCode =
      caseStatusOwnerReferenceDetails.statusCode;
    validateStatement(details, appealCaseStatusDetails);

    // Read scheduled hearing
    try {
      caseAndStatusKey.caseID = details.caseID;
      caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;
      hearingScheduleDetails =
        hearingObj.readScheduledByCaseID(caseAndStatusKey);
    } catch (final RecordNotFoundException e) {
      hearingScheduleDetails = null;
    }

    // BEGIN, CR00126659, RKi
    // a witness can submit a statement only if the hearing is scheduled.
    if (typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.HEARINGWITNESS)
      && hearingScheduleDetails == null) {

      throw new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_WITNESSSTATEMENT_ONLYFOR_SCHEDULED_HEARING);
    }
    // END, CR00126659

    // Determine submission time limit
    appealTimeConstraintKey.caseID = details.caseID;
    appealTimeConstraintKey.constraintDate =
      curam.util.type.Date.getCurrentDate();
    appealTimeConstraintKey.constraintType = CONSTRAINTTYPE.SUBMIT_STATEMENT;
    appealTimeConstraintKey.recordStatus =
      curam.codetable.RECORDSTATUS.NORMAL;

    // Determine if statement copies are sent
    boolean sendCopy = false;

    if (appealCaseStatusDetails.statusCode.equals(CASESTATUS.APPROVED)) {
      sendCopy = true;
    }
    if (appealCaseStatusDetails.statusCode.equals(CASESTATUS.OPEN)) {
      sendCopy = true;
    }
    if (appealCaseStatusDetails.statusCode.equals(CASESTATUS.ACTIVE)) {
      if (hearingScheduleDetails == null) {
        sendCopy = true;
      } else {
        // Is receipt date before scheduled date and within time limit
        final Date dtScheduledDate =
          new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
            hearingScheduleDetails.scheduledDateTime,
            TransactionInfo.getUserTimeZone()).getCalendar());

        if (details.receiptDate.before(dtScheduledDate) && dtScheduledDate
          .subtract(details.receiptDate) > submissionTimeLimit) {
          sendCopy = true;
        }
      }
    }
    if (!sendCopy) {
      // Message to user appears as informational
      final LocalisableString statementDateInvalid = new LocalisableString(
        BPOAPPEAL.ERR_APPEAL_FV_STATEMENTRECEIPTDATEINVALID);

      statementDateInvalid.arg(submissionTimeLimit);

      final InformationalManager informationalManager =
        new InformationalManager();

      informationalManager.addInformationalMsg(statementDateInvalid,
        curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);

      final String[] warnings =
        informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls =
          new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }

    }

    // Insert attachment
    createCaseAttachmentDetails.caseID = details.caseID;
    createCaseAttachmentDetails.caseParticipantRoleID =
      details.caseParticipantRoleID;
    createCaseAttachmentDetails.description = details.description;
    createCaseAttachmentDetails.documentType = DOCUMENTTYPE.STATEMENT;
    createCaseAttachmentDetails.filelocation = details.documentLocation;
    createCaseAttachmentDetails.fileReference = details.documentRef;
    createCaseAttachmentDetails.newCaseAttachmentContents =
      details.attachmentContents;
    createCaseAttachmentDetails.newCaseAttachmentName =
      details.attachmentName;
    createCaseAttachmentDetails.receiptDate = details.receiptDate;
    maintainAttachmentObj
      .insertCaseAttachmentDetails(createCaseAttachmentDetails);

    // Is statement from witness
    behalfOfCodeHW = null;
    if (typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.HEARINGWITNESS)) {

      // Read on behalf of code
      hearingIDCaseParticipantIDKeyHW = new HearingIDCaseParticipantIDKeyHW();
      hearingIDCaseParticipantIDKeyHW.caseParticipantRoleID =
        details.caseParticipantRoleID;
      hearingIDCaseParticipantIDKeyHW.hearingID =
        hearingScheduleDetails.hearingID;
      behalfOfCodeHW =
        hearingWitnessObj.readBehalfOfCodeByHearingAndCaseParticipant(
          hearingIDCaseParticipantIDKeyHW);
    }

    // Is this statement from the appellant or appellants witness
    if ((typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.APPELLANT)
      || typeAndStatusAndParticipantRoleDetails.typeCode
        .equals(CASEPARTICIPANTROLETYPE.HEARINGWITNESS))
      && (behalfOfCodeHW == null
        || behalfOfCodeHW.behalfOfCode.equals(ONBEHALFOF.APPELLANT))) {

      // Not from appellant
      // - look up concern role id for appellant
      concernRoleID = 0;
      caseParticipantRoleCaseAndTypeKey =
        new CaseParticipantRoleCaseAndTypeKey();
      caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
      caseParticipantRoleIDDetailsList = caseParticipantRole_eoObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);
      // BEGIN, CR 00021042, RKi
      for (int i = 0; i < caseParticipantRoleIDDetailsList.dtls.size(); i++) {

        // - send copy of statement
        if (caseParticipantRoleIDDetailsList.dtls
          .item(i).caseParticipantRoleID == details.caseParticipantRoleID) {
          continue;
        }
        concernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
        appealStatementCopyDetails = new AppealStatementCopyDetails();
        appealStatementCopyDetails.caseOwner = caseOwnerDetails.userFullName;
        appealStatementCopyDetails.participantRoleID = concernRoleID;
        appealStatementCopyDetails.receiptDate = details.receiptDate;
        appealStatementCopyDetails.referenceNumber = details.documentRef;
        appealStatementCopyDetails.submitterParticipantRoleID =
          typeAndStatusAndParticipantRoleDetails.participantRoleID;
        appealStatementCopyDetails.caseID = details.caseID;
        appealStatementCopyDetails.caseParticipantRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(i).caseParticipantRoleID;
        // details.caseParticipantRoleID;

        sendCopyOfStatementToAppellant(appealStatementCopyDetails);

      }
      // END, CR 00021042
    }

    // Is this statement from the respondent or respondents witness
    if (!typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.RESPONDENT)
      && (behalfOfCodeHW == null
        || !behalfOfCodeHW.behalfOfCode.equals(ONBEHALFOF.RESPONDENT))) {

      // Not from respondent
      // - look up concern role id for respondent
      concernRoleID = 0;
      caseParticipantRoleCaseAndTypeKey =
        new CaseParticipantRoleCaseAndTypeKey();
      caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;
      caseParticipantRoleIDDetailsList = caseParticipantRole_eoObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);
      if (!caseParticipantRoleIDDetailsList.dtls.isEmpty()) {

        concernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      }
      // - send copy of statement
      appealStatementCopyDetails = new AppealStatementCopyDetails();
      appealStatementCopyDetails.caseOwner = caseOwnerDetails.userFullName;
      appealStatementCopyDetails.participantRoleID = concernRoleID;
      appealStatementCopyDetails.receiptDate = details.receiptDate;
      appealStatementCopyDetails.referenceNumber = details.documentRef;
      appealStatementCopyDetails.submitterParticipantRoleID =
        typeAndStatusAndParticipantRoleDetails.participantRoleID;
      appealStatementCopyDetails.caseID = details.caseID;
      appealStatementCopyDetails.caseParticipantRoleID =
        details.caseParticipantRoleID;
      sendCopyOfStatementToRespondent(appealStatementCopyDetails);
    }

    // Is this statement from a third party or third parties witness
    if (!typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.THIRDPARTY)
      && (behalfOfCodeHW == null
        || !behalfOfCodeHW.behalfOfCode.equals(ONBEHALFOF.THIRDPARTY))) {

      // Not from third party
      // - look up concern role id for third party
      concernRoleID = 0;
      caseParticipantRoleCaseAndTypeKey =
        new CaseParticipantRoleCaseAndTypeKey();
      caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.THIRDPARTY;
      caseParticipantRoleIDDetailsList = caseParticipantRole_eoObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);
      if (!caseParticipantRoleIDDetailsList.dtls.isEmpty()) {

        concernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      }
      // - send copy of statement
      appealStatementCopyDetails = new AppealStatementCopyDetails();
      appealStatementCopyDetails.caseOwner = caseOwnerDetails.userFullName;
      appealStatementCopyDetails.participantRoleID = concernRoleID;
      appealStatementCopyDetails.receiptDate = details.receiptDate;
      appealStatementCopyDetails.referenceNumber = details.documentRef;
      appealStatementCopyDetails.submitterParticipantRoleID =
        typeAndStatusAndParticipantRoleDetails.participantRoleID;
      appealStatementCopyDetails.caseID = details.caseID;
      appealStatementCopyDetails.caseParticipantRoleID =
        details.caseParticipantRoleID;
      sendCopyOfStatementToThirdParty(appealStatementCopyDetails);
    }
    return informationalMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Sends notice to appellant detailing statement insertion
   *
   * @param details
   * The details of the statement being added
   */
  @Override
  public void
    sendCopyOfStatementToAppellant(final AppealStatementCopyDetails details)
      throws AppException, InformationalException {

    if (details.participantRoleID != 0) {
      sendsCopyOfStatement(details);
    }
  }

  // ___________________________________________________________________________
  /**
   * Sends notice to representatives detailing statement insertion
   *
   * @param details
   * The details of the statement being added
   * @param hearingKey
   * The identifier for the hearing
   */
  @Override
  public void sendCopyOfStatementToRepresentatives(
    final AppealStatementCopyDetails details, final HearingKey hearingKey)
    throws AppException, InformationalException {

    // HearingRepresentative objects
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final HearingIDStatusKeyHR hearingIDStatusKeyHR =
      new HearingIDStatusKeyHR();
    HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;

    // Read hearing representative list
    hearingIDStatusKeyHR.hearingID = hearingKey.hearingKey.hearingID;
    hearingIDStatusKeyHR.recordStatus = RECORDSTATUS.NORMAL;
    hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList =
      hearingRepresentativeObj
        .searchActiveHearingRepAndCaseParticipantRoleByHearingID(
          hearingIDStatusKeyHR);

    for (int i =
      0; i < hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
        .size(); i++) {

      // Send copy of statement to each representative
      details.participantRoleID =
        hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
          .item(i).participantRoleID;

      sendsCopyOfStatement(details);
    }
  }

  // ___________________________________________________________________________
  /**
   * Sends notice to respondent detailing statement insertion
   *
   * @param details
   * The details of the statement being added
   */
  @Override
  public void
    sendCopyOfStatementToRespondent(final AppealStatementCopyDetails details)
      throws AppException, InformationalException {

    if (details.participantRoleID != 0) {
      sendsCopyOfStatement(details);
    }
  }

  // ___________________________________________________________________________
  /**
   * Sends notice to third party detailing statement insertion
   *
   * @param details
   * The details of the statement being added
   */
  @Override
  public void
    sendCopyOfStatementToThirdParty(final AppealStatementCopyDetails details)
      throws AppException, InformationalException {

    if (details.participantRoleID != 0) {
      sendsCopyOfStatement(details);
    }
  }

  /**
   * Sends statement copy notice to specified case participant.
   *
   * @param details
   * The details of the statement being added.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void sendsCopyOfStatement(final AppealStatementCopyDetails details)
    throws AppException, InformationalException {

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final NameAddressReadKey submitterNameAddressReadKey =
      new NameAddressReadKey();
    ConcernNameAddressDetails submitterConcernNameAddressDetails;
    final NameAddressReadKey recipientNameAddressReadKey =
      new NameAddressReadKey();
    ConcernNameAddressDetails recipientConcernNameAddressDetails;

    concernRoleKey.concernRoleID = details.participantRoleID;

    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Read submitter name and address.
    submitterNameAddressReadKey.concernRoleID =
      details.submitterParticipantRoleID;
    submitterConcernNameAddressDetails =
      concernRoleObj.readNameAndAddress(submitterNameAddressReadKey);

    // Read recipient name and address.
    recipientNameAddressReadKey.concernRoleID = details.participantRoleID;
    recipientConcernNameAddressDetails =
      concernRoleObj.readNameAndAddress(recipientNameAddressReadKey);

    // Create a task.
    // Set the reason for the task.
    createStandardManualTaskDetails.taskDtls.comments =
      BPOAPPEAL.INV_APPEAL_STATEMENTLETTERTASKSUBJECT.getMessageText();

    // Set the subject for the task.
    createStandardManualTaskDetails.taskDtls.subject =
      BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();

    createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;

    createStandardManualTaskDetails.concerningDtls.caseID = details.caseID;
    createStandardManualTaskDetails.taskDtls.taskDefinitionID =
      kAppealStandardTask;

    workAllocationTaskObj.createTask(createStandardManualTaskDetails);

    // Set details to perform the creation of a communication.
    communicationDetails.addressData =
      recipientConcernNameAddressDetails.addressData;
    communicationDetails.concernRoleID = details.participantRoleID;
    communicationDetails.correspondentConcernRoleID =
      details.submitterParticipantRoleID;
    communicationDetails.correspondentName =
      submitterConcernNameAddressDetails.fullName;

    // BEGIN, CR00202766, MC
    // CorrespondentTypeCode is not a mandatory entity field only set it if
    // the correspondence is going to the primary client.
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(
      caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766

    communicationDetails.documentRefNumber = details.referenceNumber;
    communicationDetails.typeCode = COMMUNICATIONTYPE.LETTER;
    communicationDetails.userName = TransactionInfo.getProgramUser();
    communicationDetails.subjectText =
      BPOAPPEAL.INV_APPEAL_STATEMENTLETTERCOMMUNICATIONSUBJECT
        .getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    communicationDetails.caseID = details.caseID;
    communicationDetails.communicationDate = Date.getCurrentDate();
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;

    // Create the communication.
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.APPEALSTATEMENTLETTER;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;

    // BEGIN, CR00260452, NS
    final Address addressObj = AddressFactory.newInstance();
    final OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = proFormaCommDetails.addressData;
    final boolean addressEmpty =
      addressObj.isEmpty(otherAddressData).emptyInd;

    if (addressEmpty) {
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    }
    // END, CR00260452

    proFormaCommDetails.caseID = details.caseID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID = communicationObj
      .createProFormaReturningID(proFormaCommDetails).communicationID;

    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.APPEALSTATEMENTLETTER;

    // Set data set key and type.
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.STATEMENT_LETTER;
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      details.caseParticipantRoleID;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // ___________________________________________________________________________
  /**
   * Validates a hearing case statement
   *
   * @param details
   * The details of the statement being added
   * @param statusDetails
   * The status details of the hearing case
   */
  @Override
  public void validateStatement(final AppealStatementDetails details,
    final AppealCaseStatusDetails statusDetails)
    throws AppException, InformationalException {

    // CaseParticipantRole entity objects
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRole_eoKey =
      new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    TypeAndStatusAndParticipantRoleDetails typeAndStatusAndParticipantRoleDetails;

    final InformationalManager informationalManager =
      new InformationalManager();

    // hearing case status must be open or active
    if (!statusDetails.statusCode.equals(CASESTATUS.OPEN)
      && !statusDetails.statusCode.equals(CASESTATUS.ACTIVE)
      && !statusDetails.statusCode.equals(CASESTATUS.APPROVED)) {

      throw new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASESTATUSINVALID);

    }

    // description must be entered
    if (details.description.length() == 0) {

      informationalManager.addInformationalMsg(
        new AppException(BPOAPPEAL.ERR_APPEAL_FV_STATEMENTDESCRIPTIONMISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // receipt date must be entered
    if (details.receiptDate.isZero()) {

      informationalManager.addInformationalMsg(
        new AppException(BPOAPPEAL.ERR_APPEAL_FV_STATEMENTRECEIPTDATEMISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // statement document must be entered
    if (details.attachmentName.length() == 0) {

      if (details.documentLocation.length() == 0
        || details.documentRef.length() == 0) {

        informationalManager.addInformationalMsg(
          new AppException(BPOAPPEAL.ERR_APPEAL_FV_STATEMENTDOCUMENTMISSING),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }
    }

    // case participant role id must be entered
    if (details.caseParticipantRoleID == 0) {

      informationalManager.addInformationalMsg(
        new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASEPARTICIPANTMISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Read submitter details
    caseParticipantRole_eoKey.caseParticipantRoleID =
      details.caseParticipantRoleID;
    typeAndStatusAndParticipantRoleDetails = caseParticipantRole_eoObj
      .readTypeAndStatusAndParticipant(caseParticipantRole_eoKey);

    // case participant must be active
    if (!typeAndStatusAndParticipantRoleDetails.recordStatus
      .equals(RECORDSTATUS.NORMAL)) {

      informationalManager.addInformationalMsg(
        new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASEPARTICIPANTINVALID),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // case participant must be appellant, respondent, witness or third
    // party
    if (!typeAndStatusAndParticipantRoleDetails.typeCode
      .equals(CASEPARTICIPANTROLETYPE.APPELLANT)
      && !typeAndStatusAndParticipantRoleDetails.typeCode
        .equals(CASEPARTICIPANTROLETYPE.RESPONDENT)
      && !typeAndStatusAndParticipantRoleDetails.typeCode
        .equals(CASEPARTICIPANTROLETYPE.HEARINGWITNESS)
      && !typeAndStatusAndParticipantRoleDetails.typeCode
        .equals(CASEPARTICIPANTROLETYPE.THIRDPARTY)) {

      informationalManager.addInformationalMsg(
        new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASEPARTICIPANTINVALIDTYPE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /*
   * This method removes a deadline task
   *
   * @param caseID CaseID which identifies the task
   */
  @Override
  public void removeDeadlineTask(final CaseID caseID)
    throws AppException, InformationalException {

    // Work Flow event object
    final curam.util.events.struct.Event closeTaskEvent =
      new curam.util.events.struct.Event();

    closeTaskEvent.eventKey.eventClass = kEventClass;
    closeTaskEvent.eventKey.eventType = kAppealDeadlineTask;
    closeTaskEvent.primaryEventData = caseID.caseID;

    // Raise work flow event to close the existing deadline task.
    curam.util.events.impl.EventService.raiseEvent(closeTaskEvent);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the concern role details for the specified case participant role.
   *
   * @param key
   * Case Participant Role key
   * @return The concern role ID and type
   */
  @Override
  public AppealParticipantRoleDetails
    readConcernRoleDetails(final AppealCaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // Case Participant Role objects
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // Return value
    final AppealParticipantRoleDetails appealParticipantRoleDetails =
      new AppealParticipantRoleDetails();

    // Read details from CaseParticipantRole
    appealParticipantRoleDetails.caseParticipantConcernRoleDetails =
      caseParticipantRole_eoObj
        .readParticipantRoleDetails(key.caseParticipantRoleKey);

    return appealParticipantRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of closed appeals of a specified type for a case.
   *
   * @param key
   * The case identifier and the appeal type.
   *
   * @return The list of closed appeals.
   */
  @Override
  public RelatedAppealByStatusDetailsList
    listAppealByCaseTypeStatus(final AppealListByTypeStatusKey key)
      throws AppException, InformationalException {

    // Users object
    final UsersKey usersKey = new UsersKey();

    // Appeal entity objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealRelatedByTypeStatusKey appealRelatedByTypeStatusKey =
      new AppealRelatedByTypeStatusKey();
    AppealRelatedByTypeStatusDetailsList appealRelatedByTypeStatusDetailsList =
      new AppealRelatedByTypeStatusDetailsList();

    // Decision entity objects
    final curam.appeal.sl.entity.intf.HearingDecision hearingDecisionObj =
      curam.appeal.sl.entity.fact.HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionResolutionCodeDetails hearingDecisionResolutionCodeDetails =
      new HearingDecisionResolutionCodeDetails();

    // Appellant details
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

    // Return details
    final RelatedAppealByStatusDetailsList relatedAppealByStatusDetailsList =
      new RelatedAppealByStatusDetailsList();
    RelatedAppealByStatusDetails relatedAppealByStatusDetails;

    // Get the user name of the current user
    usersKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Read related appeal cases (only those with a Closed status)
    appealRelatedByTypeStatusKey.caseID = key.caseID;
    appealRelatedByTypeStatusKey.appealTypeCode = key.appealTypeCode;
    appealRelatedByTypeStatusKey.statusCode =
      curam.codetable.CASESTATUS.CLOSED;
    appealRelatedByTypeStatusDetailsList = appealObj
      .searchRelatedAppealDetailsByTypeStatus(appealRelatedByTypeStatusKey);

    // For each related appeal case
    for (int i = 0; i < appealRelatedByTypeStatusDetailsList.dtls
      .size(); ++i) {

      // Assign details of each related appeal
      relatedAppealByStatusDetails = new RelatedAppealByStatusDetails();
      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        appealRelatedByTypeStatusDetailsList.dtls
          .item(i).ownerOrgObjectLinkID;
      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      relatedAppealByStatusDetails
        .assign(appealRelatedByTypeStatusDetailsList.dtls.item(i));
      relatedAppealByStatusDetails.ownerFullName =
        caseOwnerDetails.userFullName;
      relatedAppealByStatusDetails.ownerUserName = caseOwnerDetails.userName;
      // END, CR00053295
      // Read decision resolution for each case
      try {

        hearingDecisionCaseKey.caseID =
          appealRelatedByTypeStatusDetailsList.dtls.item(i).caseID;
        hearingDecisionResolutionCodeDetails =
          hearingDecisionObj.readResolutionCodeByCase(hearingDecisionCaseKey);
        relatedAppealByStatusDetails.resolutionCode =
          hearingDecisionResolutionCodeDetails.resolutionCode;

      } catch (final RecordNotFoundException e) {

        relatedAppealByStatusDetails.resolutionCode =
          curam.codetable.HEARINGDECISIONRESOLUTION.NOTDECIDED;

      }

      appealCaseKey.caseID =
        appealRelatedByTypeStatusDetailsList.dtls.item(i).caseID;
      readAppellantDetails = readAppellantDetails(appealCaseKey);
      relatedAppealByStatusDetails.appellantCaseParticipantRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;
      relatedAppealByStatusDetails.appellantName =
        readAppellantDetails.concernRoleNameDetails.concernRoleName;

      // Add to output list
      relatedAppealByStatusDetailsList.relatedAppealByStatusDetails
        .addRef(relatedAppealByStatusDetails);

    }
    // Return details
    return relatedAppealByStatusDetailsList;

  }

  // _____________________________________________________________________________
  /**
   * Resolves the case home page name for all types of appeal case. Note that
   * this method does not resolve the home page for non-appeal case types; this
   * is controlled by the invoking method.
   *
   * @param key
   * Key to read the case home page name.
   * @return the case home page name.
   */
  @Override
  public HomePageName resolveCaseHomePageName(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return variable
    final HomePageName homePageName = new HomePageName();

    // Variables for Appeal business process service layer
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    AppealTypeDetails appealTypeDetails;

    // Case Header entity objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Determine the type of appeal case
    appealCaseIDKey.caseID = key.caseID;
    appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

    // Get parent case details
    caseKey.caseID = key.caseID;
    integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);

    // Determine the home page for a Hearing Case
    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      // Determine if the appeal is on an integrated case
      if (integratedCaseKey.integratedCaseID != 0) {
        homePageName.homePageName =
          Configuration.getProperty(EnvVars.ENV_APPEAL_HEARINGCASEHOMEFORIC);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_HEARINGCASEHOMEFORIC_DEFAULT;
        }
      } else {
        // Appeal is on a standalone case
        homePageName.homePageName =
          Configuration.getProperty(EnvVars.ENV_APPEAL_HEARINGCASEHOME);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_HEARINGCASEHOME_DEFAULT;
        }
      }

      // Determine the home page for a Hearing Review
    } else if (appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.HEARINGREVIEW)) {

      // Determine if the appeal is on an integrated case
      if (integratedCaseKey.integratedCaseID != 0) {
        homePageName.homePageName = Configuration
          .getProperty(EnvVars.ENV_APPEAL_HEARINGREVIEWHOMEFORIC);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_HEARINGREVIEWHOMEFORIC_DEFAULT;
        }
      } else {
        // Appeal is on a stand alone case
        homePageName.homePageName =
          Configuration.getProperty(EnvVars.ENV_APPEAL_HEARINGREVIEWHOME);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_HEARINGREVIEWHOME_DEFAULT;
        }
      }

      // Determine the home page for a Judicial Review
    } else if (appealTypeDetails.appealTypeCode
      .equals(APPEALTYPE.JUDICIALREVIEW)) {

      // Determine if the appeal is on an integrated case
      if (integratedCaseKey.integratedCaseID != 0) {
        homePageName.homePageName = Configuration
          .getProperty(EnvVars.ENV_APPEAL_JUDICIALREVIEWHOMEFORIC);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_JUDICIALREVIEWHOMEFORIC_DEFAULT;
        }
      } else {
        // Appeal is on a standalone case
        homePageName.homePageName =
          Configuration.getProperty(EnvVars.ENV_APPEAL_JUDICIALREVIEWHOME);

        if (homePageName.homePageName == null) {
          homePageName.homePageName =
            EnvVars.ENV_APPEAL_JUDICIALREVIEWHOME_DEFAULT;
        }
      }
    }
    // }

    return homePageName;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve list of cases by owner ID
   *
   * @param key
   * contains the user to list cases by
   *
   * @return the list of the user's cases
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /*
   * The key in the method parameter is unused. The method has no implementation
   * but yet provided, for the customer to override it and customize the
   * functionality.
   */
  public GetCasesByOwnerResult listCaseByCurrentUser(
    final CasesByOwnerKey key) throws AppException, InformationalException {

    return new GetCasesByOwnerResult();

  }

  // ___________________________________________________________________________
  /**
   * Modifies the linked cases for an appeal case updating the appealIndicator
   * to the value specified and inserting a case event of the specified type for
   * each linked case.
   *
   * @param details
   * Contains the appeal caseID, appealIndicator and case event type
   * values.
   */
  @Override
  public void modifyLinkedCases(final ModifyLinkedCaseDetails details)
    throws AppException, InformationalException {

    // CaseEvent object
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // caseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Current Date
    final Date currentDate = Date.getCurrentDate();

    // AppealRelationship object and structs
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();
    curam.appeal.sl.entity.struct.AppealedCaseDetailsList appealedCaseDetailsList;

    // Find all appealed cases associated with the appeal case
    appealCaseID.appealCaseID = details.caseID;
    appealedCaseDetailsList = appealRelationshipObj
      .searchAppealedCaseDetailsByAppealCase(appealCaseID);

    caseAppealIndicatorDetails.appealIndicator = details.appealIndicator;

    for (int i = 0; i < appealedCaseDetailsList.dtls.size(); i++) {

      // Modify each appealed case appeal indicator
      caseHeaderKey.caseID = appealedCaseDetailsList.dtls.item(i).caseID;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);

      // Insert a case event for each appealed case
      caseEventDtls.caseEventID = uniqueIDObj.getNextID();
      caseEventDtls.caseID = appealedCaseDetailsList.dtls.item(i).caseID;
      caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
      caseEventDtls.startDate = currentDate;
      caseEventDtls.statusCode = CASEEVENTSTATUS.DEFAULTCODE;
      caseEventDtls.eventTypeCode = details.eventTypeCode;
      caseEventDtls.relatedID = details.caseID;
      caseEventObj.insert(caseEventDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to return attachment details.
   *
   * @param key
   * contains attachmentID
   *
   * @return attachment details
   */
  @Override
  public ReadAttachmentOut readAttachment(final ReadAttachmentIn key)
    throws AppException, InformationalException {

    // Create return object
    final ReadAttachmentOut readAttachmentOut = new ReadAttachmentOut();

    // BEGIN, CR00226594, FM
    // attachment entity, dtls, key
    final AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls;

    attachmentKey.attachmentID = key.attachmentID;

    // read attachment details if there is an attachment
    if (attachmentKey.attachmentID != 0) {

      attachmentDtls = attachmentObj.read(attachmentKey);

      // populate attachmentDtls in dtls
      readAttachmentOut.attachmentName = attachmentDtls.attachmentName;
      readAttachmentOut.attachmentContents =
        attachmentDtls.attachmentContents;
      readAttachmentOut.attachmentStatus = attachmentDtls.attachmentStatus;
      readAttachmentOut.versionNo = attachmentDtls.versionNo;
    }
    // END, CR00226594

    return readAttachmentOut;
  }

  // ___________________________________________________________________________
  /**
   * Method to determine if a user is a supervisor. In this implementation, a
   * user is a supervisor if they hold a lead position or hold a position that
   * another position reports to.
   *
   * @param details
   * The user name to search on.
   *
   * @return if the user is a supervisor or not.
   */
  @Override
  public IsSupervisorResult isSupervisor(final UserNameDetails details)
    throws AppException, InformationalException {

    // Return structure
    final IsSupervisorResult isSupervisorResult = new IsSupervisorResult();

    // HearingDecision Object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();

    final UserSupervisorKey userSupervisorKey = new UserSupervisorKey();

    userSupervisorKey.userName = details.userName;

    if (hearingDecisionObj
      .searchIsUserSupervisor(userSupervisorKey).count > 0) {
      isSupervisorResult.supervisorInd = true;
    } else {
      isSupervisorResult.supervisorInd = false;
    }

    return isSupervisorResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to Retrieve the deadline date for an appeal.
   *
   * @param details
   * contains the unique caseID.
   *
   * @return the deadline date for the appeal
   */
  @Override
  public DeadlineDate getDeadlineDate(final AppealDeadlineDateDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00284786, DG
    // Return structure
    final DeadlineDate deadlineDate = new DeadlineDate();

    String constraintType = "";
    long caseID = 0;

    if (!details.receivedDate.isZero()) {

      // AppealRelationship variables
      final AppealRelationship appealRelationshipObj =
        AppealRelationshipFactory.newInstance();
      final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
        new curam.appeal.sl.entity.struct.AppealCaseID();

      // Get a list of all cases which are associated with the specified
      // appeal
      // case.
      appealCaseID.appealCaseID = details.caseID;
      final CaseIDList caseIDList =
        appealRelationshipObj.searchCaseIDForAppeal(appealCaseID);

      // Use the first record returned as it is has the earliest deadline
      // date
      if (caseIDList.dtls.size() > 0) {
        caseID = caseIDList.dtls.item(0).caseID;
      }

      // Get the time limit in which the hearing case must be resolved
      if (details.appealType.equals(APPEALTYPE.HEARING)) {

        constraintType = CONSTRAINTTYPE.TIMETOCOMPLETE_HEARINGCASE;
      } else {
        constraintType = CONSTRAINTTYPE.TIMETOCOMPLETE_HEARINGREVIEW;
      }

      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.appealCaseID = details.caseID;
      caseIDAppealCaseIDConstraintType.caseID = caseID;
      caseIDAppealCaseIDConstraintType.constraintType = constraintType;
      final int timeConstraintLength = getTimeConstraintLength(
        caseIDAppealCaseIDConstraintType).numberOfDays;

      // If no time constraint found then throw an exception
      if (timeConstraintLength == 0) {
        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        final curam.util.type.CodeTableItemIdentifier constraintTypeCode =
          new curam.util.type.CodeTableItemIdentifier(
            curam.codetable.CONSTRAINTTYPE.TABLENAME, constraintType);

        ex.arg(constraintTypeCode);
        throw ex;
      }

      deadlineDate.date = details.receivedDate.addDays(timeConstraintLength);
    }

    return deadlineDate;
    // END, CR00284786
  }

  // BEGIN, CR00284786, DG
  // ___________________________________________________________________________
  /**
   * Get the time constraint length for a given case, appeal case and constraint
   * type.
   *
   * @param key
   * The constraint type, case and appeal case identifiers.
   * @return The number of days for the given time constraint on the case.
   */
  @Override
  public TimeConstraintLength
    getTimeConstraintLength(final CaseIDAppealCaseIDConstraintType details)
      throws AppException, InformationalException {

    long appealStageID = 0;
    int constraintLength = 0;

    // Read the case type
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.caseID;
    final CaseTypeCode caseType =
      CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    // BEGIN , CR00302241 CR00302531, DK
    // read the appealID type to check if it is an appeal or a legal action
    // an appeal will use new appeals process, a legal action will use the
    // legacy tables
    final CaseKey appealCaseKey = new CaseKey();

    appealCaseKey.caseID = details.appealCaseID;
    final CaseTypeCode appealCaseType =
      CaseHeaderFactory.newInstance().readCaseTypeCode(appealCaseKey);

    // Get the current appeal stage identifier for this case
    final AppealCaseIDCaseID appealCaseIDCaseID = new AppealCaseIDCaseID();

    appealCaseIDCaseID.appealCaseID = details.appealCaseID;
    appealCaseIDCaseID.caseID = details.caseID;
    if (!appealCaseType.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

      // Legacy case processing for product, issue and IC
      if (caseType.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        appealStageID = ProductAppealProcessFactory.newInstance()
          .getCurrentAppealStageDetails(appealCaseIDCaseID).appealStageID;
      } else if (caseType.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
        appealStageID = IssueAppealProcessFactory.newInstance()
          .getCurrentAppealStageDetails(appealCaseIDCaseID).appealStageID;
      } else if (caseType.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
        appealStageID = IntegratedCaseAppealProcessFactory.newInstance()
          .getCurrentAppealStageDetails(appealCaseIDCaseID).appealStageID;
      } // Check If the case has implemented the Appealable Interface.
      else {
        final AppealableCaseType appealableCaseType = appealableCaseTypeMap
          .get(CASETYPECODEEntry.get(caseType.caseTypeCode));

        if (appealableCaseType != null) {
          appealStageID = AppealableCaseTypeAppealProcessFactory.newInstance()
            .getCurrentAppealStageDetails(appealCaseIDCaseID).appealStageID;
        }
      }
    }
    // Retrieve the time constraint length for the appeal stage
    if (appealStageID != 0) {
      final AppealStageTimeConstraintKeyStruct1 appealStageTimeConstraintKeyStruct1 =
        new AppealStageTimeConstraintKeyStruct1();

      appealStageTimeConstraintKeyStruct1.appealStageConfID = appealStageID;
      appealStageTimeConstraintKeyStruct1.recordStatus = RECORDSTATUS.NORMAL;
      final AppealStageTimeConstraintDtlsStruct1List timeConstraintList =
        AppealStageTimeConstraintFactory.newInstance()
          .searchByAppealStageConfigurationIDStatus(
            appealStageTimeConstraintKeyStruct1);
      Date maxDate = Date.kZeroDate;
      final Date currentDate = Date.getCurrentDate();

      for (final AppealStageTimeConstraintDtlsStruct1 timeConstraintDetails : timeConstraintList.dtls) {
        if (timeConstraintDetails.constraintType
          .equals(details.constraintType)
          && maxDate.before(timeConstraintDetails.fromDate)
          && !currentDate.before(timeConstraintDetails.fromDate)) {
          constraintLength = timeConstraintDetails.numberOfDays;
          maxDate = timeConstraintDetails.fromDate;
        }
      }
    }

    // If no time constraint then check the next stage
    if (constraintLength == 0) {

      // BEGIN, CR00346500, DG
      OrderedAppealStage nextAppealStageDetails = new OrderedAppealStage();

      if (!appealCaseType.caseTypeCode
        .equals(CASETYPECODE.CFSS_LEGALACTION)) {
        // Legacy case processing for product, issue and IC
        if (caseType.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
          nextAppealStageDetails = ProductAppealProcessFactory.newInstance()
            .getNextAppealStageDetails(appealCaseIDCaseID);

        } else if (caseType.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
          nextAppealStageDetails = IssueAppealProcessFactory.newInstance()
            .getNextAppealStageDetails(appealCaseIDCaseID);

        } else if (caseType.caseTypeCode
          .equals(CASETYPECODE.INTEGRATEDCASE)) {
          nextAppealStageDetails = IntegratedCaseAppealProcessFactory
            .newInstance().getNextAppealStageDetails(appealCaseIDCaseID);

        } // Check If the case has implemented the Appealable Interface.
        else {
          final AppealableCaseType appealableCaseType = appealableCaseTypeMap
            .get(CASETYPECODEEntry.get(caseType.caseTypeCode));

          if (appealableCaseType != null) {
            nextAppealStageDetails = AppealableCaseTypeAppealProcessFactory
              .newInstance().getNextAppealStageDetails(appealCaseIDCaseID);
          }
        }
      }

      // If there is no next appeal stage, then this object maybe null
      if (nextAppealStageDetails != null) {
        appealStageID = nextAppealStageDetails.appealStageID;
      }
      // END, CR00346500
      // END, CR00302531, DK
      if (appealStageID != 0) {
        final AppealStageTimeConstraintKeyStruct1 appealStageTimeConstraintKeyStruct1 =
          new AppealStageTimeConstraintKeyStruct1();

        appealStageTimeConstraintKeyStruct1.appealStageConfID = appealStageID;
        appealStageTimeConstraintKeyStruct1.recordStatus =
          RECORDSTATUS.NORMAL;
        final AppealStageTimeConstraintDtlsStruct1List timeConstraintList =
          AppealStageTimeConstraintFactory.newInstance()
            .searchByAppealStageConfigurationIDStatus(
              appealStageTimeConstraintKeyStruct1);
        Date maxDate = Date.kZeroDate;
        final Date currentDate = Date.getCurrentDate();

        for (final AppealStageTimeConstraintDtlsStruct1 timeConstraintDetails : timeConstraintList.dtls) {
          if (timeConstraintDetails.constraintType
            .equals(details.constraintType)
            && maxDate.before(timeConstraintDetails.fromDate)
            && !currentDate.before(timeConstraintDetails.fromDate)) {
            constraintLength = timeConstraintDetails.numberOfDays;
            maxDate = timeConstraintDetails.fromDate;
          }
        }
      }
    }

    // If no time constraint has been found or the appealCaseType is a legal
    // action, then check the legacy data tables
    // (ProductTimeConstraint and IssueTimeConstraint)
    if (constraintLength == 0) {
      try {
        final AppealTimeConstraintKey appealTimeConstraintKey =
          new AppealTimeConstraintKey();

        appealTimeConstraintKey.caseID = details.caseID;
        appealTimeConstraintKey.constraintDate = Date.getCurrentDate();
        appealTimeConstraintKey.constraintType = details.constraintType;
        appealTimeConstraintKey.recordStatus = RECORDSTATUS.NORMAL;
        if (caseType.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
          constraintLength = AppealFactory.newInstance()
            .readTimeConstraintByTypeAndProductCase(
              appealTimeConstraintKey).numberOfDays;
        } else {
          constraintLength = AppealFactory.newInstance()
            .readTimeConstraintByTypeAndIssueConfiguration(
              appealTimeConstraintKey).numberOfDays;
        }
      } catch (final RecordNotFoundException e) {// Do nothing
      }
    }

    final TimeConstraintLength timeConstraintLength =
      new TimeConstraintLength();

    timeConstraintLength.numberOfDays = constraintLength;
    return timeConstraintLength;
  }

  // END, CR00284786

  // ___________________________________________________________________________
  /**
   * Method to check if the appeal was submitted in a timely manner. It is
   * timely if the number of days which have elapsed between the case decision
   * and the appeal receipt is not more than the number of days allowed to
   * request an appeal.
   *
   * @param details
   * contains the unique caseID.
   *
   * @return if the appeal is timely or not.
   */
  @Override
  public IsTimelyResult isTimely(final AppealDeadlineDateDetails details)
    throws AppException, InformationalException {

    // Return structure
    final IsTimelyResult isTimelyResult = new IsTimelyResult();

    // Appeal Time Constraint Objects
    int dateDiffInDays = 0;

    // BEGIN, CR00284786, DG
    // Get the time constraint value
    String constraintType = "";

    isTimelyResult.timelyInd = true;

    if (!details.receivedDate.isZero()
      && !details.appealedDecisionDate.isZero()) {

      // Calculate days elapsed between case decision and appeal receipt
      dateDiffInDays =
        details.receivedDate.subtract(details.appealedDecisionDate);

      if (details.appealType.equals(APPEALTYPE.HEARINGREVIEW)) {
        constraintType = CONSTRAINTTYPE.REQUEST_HEARING_REVIEW;
      } else if (details.appealType.equals(APPEALTYPE.HEARING)) {
        constraintType = CONSTRAINTTYPE.REQUEST_HEARING_CASE;
      } else {
        constraintType = CONSTRAINTTYPE.REQUEST_JUDICIAL_REVIEW;
      }
      // Get the number of days in which a request for
      // a hearing review must be made
      // END HARP 30225
      // BEGIN, CR00269510, ZV

      long appealCaseID = 0;
      final AppealRelationship appealRelationshipObj =
        AppealRelationshipFactory.newInstance();
      final ActiveByAppealCaseAndAppealTypeKey activeByAppealCaseAndAppealTypeKey =
        new ActiveByAppealCaseAndAppealTypeKey();

      activeByAppealCaseAndAppealTypeKey.appealTypeCode = details.appealType;
      activeByAppealCaseAndAppealTypeKey.caseID = details.caseID;
      final AppealCaseIDList appealCaseIDList =
        appealRelationshipObj.searchActiveAppealByCaseAndAppealType(
          activeByAppealCaseAndAppealTypeKey);

      if (appealCaseIDList.dtls.size() > 0) {
        appealCaseID = appealCaseIDList.dtls.item(0).appealCaseID;
      }

      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.appealCaseID = appealCaseID;
      caseIDAppealCaseIDConstraintType.caseID = details.caseID;
      caseIDAppealCaseIDConstraintType.constraintType = constraintType;
      final int timeConstraintLength = getTimeConstraintLength(
        caseIDAppealCaseIDConstraintType).numberOfDays;

      if (timeConstraintLength == 0) {
        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        final CodeTableItemIdentifier constraintTypeCode =
          new CodeTableItemIdentifier(CONSTRAINTTYPE.TABLENAME,
            constraintType);

        ex.arg(constraintTypeCode);
        throw ex;
      }

      // END, CR00269510

      if (dateDiffInDays > timeConstraintLength) {
        isTimelyResult.timelyInd = false;
      }
    }
    // END, CR00284786
    return isTimelyResult;

  }

  // ___________________________________________________________________________
  /**
   * Reads the appeal type of an appeal case.
   *
   * @param key
   * Key to read the appeal type.
   *
   * @return Details of the appeal type.
   */
  @Override
  public curam.appeal.sl.struct.AppealTypeDetails readAppealType(
    final AppealCaseKey key) throws AppException, InformationalException {

    final curam.appeal.sl.struct.AppealTypeDetails appealTypeDetails =
      new curam.appeal.sl.struct.AppealTypeDetails();

    // Appeal Objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Get the appeal type for this caseID
    appealCaseIDKey.caseID = key.caseID;
    appealTypeDetails.appealTypeDetails
      .assign(appealObj.readAppealTypeByCase(appealCaseIDKey));

    return appealTypeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Calculates and returns the overall appeal deadline date for an appeal case
   * based on the currently active and approved appealed cases for that appeal.
   *
   * @param key
   * The caseID of the appeal case.
   * @return The deadline date of the appeal.
   */
  @Override
  public DeadlineDate calculateDeadlineDate(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Appeal Relationship variables
    final curam.appeal.sl.entity.struct.ActiveApprovedCaseKey activeApprovedCaseKey =
      new curam.appeal.sl.entity.struct.ActiveApprovedCaseKey();
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();
    CaseIDAndDeadlineDateList caseIDAndDeadlineDateList;
    final DeadlineDate deadlineDate = new DeadlineDate();

    activeApprovedCaseKey.appealCaseID = key.caseID;

    // Get the earliest deadline date may return more than one record
    caseIDAndDeadlineDateList = appealRelationshipObj
      .searchEarliestDeadlineDetails(activeApprovedCaseKey);

    // BEGIN, CR00021448 ,RKi
    try {
      deadlineDate.date = caseIDAndDeadlineDateList.dtls.item(0).deadlineDate;
    } catch (final Exception e) {// DO NOTHING
    }
    // END, CR00021448

    return deadlineDate;

  }

  // ___________________________________________________________________________
  /**
   * Calculates the overall deadline date for an appeal based on the receipt
   * information for a single appealed case.
   *
   * @param details
   * Receipt information for a single appealed case.
   * @return The deadline date of the appeal.
   * @deprecated Since Curam 6.0 SP2, Replaced with
   * {@link calculateDeadlineDate1} which takes into account time
   * constraints stored on the new AppealStageTimeConstraints
   * entity, As part of the appeals enhancements in v6SP2 time
   * constraints are now stored on the AppealStageTimeConstraints
   * entity. Using the new method calculareDeadlineDate1 will lookup
   * time constraints in new location first before falling back to
   * the legacy tables. See release note: CR00295153.
   */
  @Override
  @Deprecated
  public DeadlineDate
    calculateDeadlineDate(final CalculateAppealDeadlineDateDetails details)
      throws AppException, InformationalException {

    // Variables to calculate the overall deadline date
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();
    DeadlineDate deadlineDate;

    // Get the current deadline date
    deadlineDate = appealedCaseObj.calculateDeadlineDate(details);

    return deadlineDate;

  }

  // ___________________________________________________________________________
  /**
   * This method updates the status of an appeal case.
   *
   * This includes modifying the CaseHeader status, closing the existing
   * CaseStatus record and creating a new CaseStatus for the case.
   *
   * @param dtls
   * The appeal case status details
   */
  @Override
  public void updateCaseStatus(final UpdateAppealCaseStatusDetails dtls)
    throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeaderStatus caseHeaderStatusDetails = new CaseHeaderStatus();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // BEGIN, CR00094409, RKi
    VersionNumberDetails versionNumberDetails = new VersionNumberDetails();

    // Update case header status to "approved"
    caseHeaderKey.caseID = dtls.caseID;
    versionNumberDetails = caseHeaderObj.readVersionNumber(caseHeaderKey);
    caseHeaderStatusDetails.versionNo = versionNumberDetails.versionNo;
    caseHeaderStatusDetails.statusCode = dtls.statusCode;
    // END, CR00094409
    caseHeaderObj.modifyStatus(caseHeaderKey, caseHeaderStatusDetails);

    // Today's date
    final Date currentDate = Date.getCurrentDate();
    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj =
      curam.core.fact.UniqueIDFactory.newInstance();

    // Find and close current CaseStatus record
    final CurrentCaseStatusKey currentCaseStatusKey =
      new CurrentCaseStatusKey();
    final CaseStatusKey caseStatusKey = new CaseStatusKey();
    CaseStatusDtls caseStatusDtls = new CaseStatusDtls();
    // BEGIN, CR00441728, RD
    final CaseStatusEndDateTimeDetails caseStatusEndDateTimeDetails =
      new CaseStatusEndDateTimeDetails();
    // END, CR00441728
    final curam.core.intf.CaseStatus caseStatusObj =
      CaseStatusFactory.newInstance();

    currentCaseStatusKey.caseID = dtls.caseID;
    // BEGIN, CR00236272, AK
    caseStatusDtls =
      caseStatusObj.readCurrentStatusByCaseID1(currentCaseStatusKey);
    // END, CR00236272

    caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;
    // BEGIN, CR00441728, RD
    caseStatusEndDateTimeDetails.endDate = currentDate;
    caseStatusEndDateTimeDetails.endDateTime = currentDate.getDateTime();
    caseStatusEndDateTimeDetails.versionNo = caseStatusDtls.versionNo;
    caseStatusObj.modifyEndDateTime(caseStatusKey,
      caseStatusEndDateTimeDetails);
    // END, CR00441728

    // Insert new open Case Status record
    final CaseStatusDtls newCaseStatusDtls = new CaseStatusDtls();

    newCaseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    newCaseStatusDtls.caseID = dtls.caseID;
    newCaseStatusDtls.startDate = currentDate;
    newCaseStatusDtls.endDate = Date.kZeroDate;
    newCaseStatusDtls.statusCode = dtls.statusCode;
    newCaseStatusDtls.reasonCode = dtls.reasonCode;
    caseStatusObj.insert(newCaseStatusDtls);

  }

  // ___________________________________________________________________________
  /**
   * This method adds the selected appealed case to the appeal If the appealed
   * case is an assessment delivery, it automatically adds the lead product for
   * that assessment to the appeal case also.
   *
   * @param details
   * The details of the case being added
   * @return The appealRelationshipID for the added appealed case.
   */
  @Override
  public AppealRelationshipKey
    addAppealedCase(final AddNewAppealedCaseDetails details)
      throws AppException, InformationalException {

    // Appeal relationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipDtls appealRelationshipDtls =
      new AppealRelationshipDtls();
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();

    // appellant variables
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();
    final AppealCaseKey addAppealCaseKey = new AppealCaseKey();

    // Return object
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();

    // DetermineCaseType object
    final DetermineCaseType determineCaseTypeObj =
      DetermineCaseTypeFactory.newInstance();
    final DetermineCaseTypeKey determineCaseTypeKey =
      new DetermineCaseTypeKey();
    DetermineCaseTypeDtls determineCaseTypeDtls;

    // keys used for other service layer calls
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();
    final AppealDeadlineDateDetails appealDeadlineDateDetails =
      new AppealDeadlineDateDetails();
    final CreateRelationshipLinksDetails createRelationshipLinksDetails =
      new CreateRelationshipLinksDetails();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // validate the details
    validateAddAppealedCase(details);

    // set the timely indicator
    appealDeadlineDateDetails.appealedDecisionDate =
      details.addAppealedCaseInputDetails.effectiveDate;
    appealDeadlineDateDetails.appealType = details.appealTypeCode;
    // BEGIN, CR00269510, ZV
    appealDeadlineDateDetails.caseID = details.implCaseID;
    // END, CR00269510
    appealDeadlineDateDetails.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;

    // BEGIN, CR00049829, RKi
    // Required Objects
    CaseTypeCode caseTypeCode;
    final CaseKey caseKey = new CaseKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final TimelyIssueCaseDetails timelyIssueCaseDetails =
      new TimelyIssueCaseDetails();

    caseKey.caseID = details.implCaseID;
    // read the case type
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    timelyIssueCaseDetails.appealType = details.appealTypeCode;
    timelyIssueCaseDetails.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;
    timelyIssueCaseDetails.issueCaseID = details.implCaseID;
    timelyIssueCaseDetails.appealCaseID = details.appealCaseID;

    // BEGIN, CR00295153, DG
    // calculate the appealed deadline date
    calculateAppealDeadlineDateDetails1.appealTypeCode =
      details.appealTypeCode;
    calculateAppealDeadlineDateDetails1.implCaseID = details.implCaseID;
    calculateAppealDeadlineDateDetails1.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;
    calculateAppealDeadlineDateDetails1.appealCaseID = details.appealCaseID;

    // Calculate the deadline date for the appealed case.
    // if case is of Appeal type then calculate deadline date for appeal
    // case
    // CaseHeader object

    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // BEGIN, CR00078516, RKi
    appealCaseKey.caseID = details.appealCaseID;
    // END, CR00078516

    // insert appeal relationship record for appealed case
    appealRelationshipDtls.assign(details.addAppealedCaseInputDetails);
    appealRelationshipDtls.resolutionCode =
      HEARINGDECISIONRESOLUTION.NOTDECIDED;
    appealRelationshipDtls.registrationDate = currentDate;
    appealRelationshipDtls.receiptNoticeIndicator = false;
    appealRelationshipDtls.recordStatus = RECORDSTATUS.NORMAL;
    appealRelationshipDtls.statusCode = APPEALRELATIONSHIPSTATUS.DEFAULTCODE;
    appealRelationshipDtls.appealCaseID = details.appealCaseID;
    appealRelationshipDtls.caseID = details.implCaseID;
    appealRelationshipDtls.priorAppealCaseID = details.priorAppealCaseID;
    appealRelationshipDtls.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;
    appealRelationshipDtls.appealedDecisionDate =
      details.addAppealedCaseInputDetails.effectiveDate;
    appealRelationshipDtls.timelyIndicator = true;
    appealRelationshipObj.insert(appealRelationshipDtls);

    // create case relationship records
    createRelationshipLinksDetails.appealCaseType = details.appealTypeCode;
    createRelationshipLinksDetails.appealCaseID = details.appealCaseID;
    createRelationshipLinksDetails.appealTypeCode = details.appealTypeCode;
    createRelationshipLinksDetails.caseID = details.implCaseID;
    createRelationshipLinksDetails.priorAppealCaseID =
      details.priorAppealCaseID;
    createRelationshipLinks(createRelationshipLinksDetails);

    // Set the deadline date
    // Note this must be done after the appeal relationship links are
    // created.
    // Otherwise its not possible to read the time constraints for the
    // stage.
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey1 =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    appealRelationshipKey1.appealRelationshipID =
      appealRelationshipDtls.appealRelationshipID;
    final curam.appeal.sl.entity.struct.DeadlineDate deadlineDate1 =
      new curam.appeal.sl.entity.struct.DeadlineDate();

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      appealCaseKey.caseID = details.implCaseID;
      deadlineDate1.deadlineDate = calculateDeadlineDate(appealCaseKey).date;
      appealRelationshipObj.modifyDeadlineDate(appealRelationshipKey1,
        deadlineDate1);
    } else {
      deadlineDate1.deadlineDate = appealedCaseObj
        .calculateDeadlineDate1(calculateAppealDeadlineDateDetails1).date;
      appealRelationshipObj.modifyDeadlineDate(appealRelationshipKey1,
        deadlineDate1);
    }

    // BEGIN, CR00296208, DG
    isTimely(appealDeadlineDateDetails);
    // END, CR00296208

    // BEGIN, CR00443188, SD
    // Find the case type to create task for case owner
    determineCaseTypeKey.caseID = details.implCaseID;
    determineCaseTypeDtls =
      determineCaseTypeObj.getCaseType(determineCaseTypeKey);

    final CreateBenefitTaskAppealedCaseDetails createBenefitTaskAppealedCaseDetails =
      new CreateBenefitTaskAppealedCaseDetails();

    createBenefitTaskAppealedCaseDetails.caseID = details.implCaseID;
    createBenefitTaskAppealedCaseDetails.caseType =
      determineCaseTypeDtls.caseTypeCode;
    createBenefitTaskAppealedCaseDetails.continueBenefitsIndicator =
      details.addAppealedCaseInputDetails.continueBenefitsIndicator;
    createBenefitTask(createBenefitTaskAppealedCaseDetails);
    // END, CR00443188

    // add appellants
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      addAppealCaseKey.caseID = details.appealCaseID;
      appellant.addAppellantsFromAppealCase(addAppealCaseKey, appealCaseKey);
    }

    // BEGIN, CR00021526, RKi
    if (details.addAppealedCaseInputDetails.receiptNoticeIndicator == true) {
      appellant.acknowledgeReceipts(appealCaseKey);
    }
    // END, CR00021526

    // Set return values
    appealRelationshipKey.appealRelationshipID =
      appealRelationshipDtls.appealRelationshipID;

    // BEGIN, CR00052221, RKi
    // While creating an appeal case on an Issue case, the Issue case
    // should be default approved.
    if (CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
      VersionNumberDetails versionNumberDetails;
      final AppealedCaseApproval appealedCaseApproval =
        AppealedCaseApprovalFactory.newInstance();
      AppealModifyReadDetails appealModifyReadDetails;
      final curam.appeal.sl.entity.intf.Appeal appealObj =
        AppealFactory.newInstance();

      caseHeaderKey.caseID = caseKey.caseID;
      appealCaseIDKey.caseID = details.appealCaseID;
      versionNumberDetails = caseHeaderObj.readVersionNumber(caseHeaderKey);
      appealModifyReadDetails =
        appealObj.readDetailsForModify(appealCaseIDKey);
      final AppealedCaseApproveDetails appealedCaseApproveDetails =
        new AppealedCaseApproveDetails();

      appealedCaseApproveDetails.appealRelationshipID =
        appealRelationshipDtls.appealRelationshipID;
      appealedCaseApproveDetails.versionNo = appealRelationshipDtls.versionNo;
      appealedCaseApproveDetails.caseHeaderVersionNo =
        versionNumberDetails.versionNo;
      appealedCaseApproveDetails.appealVersionNo =
        appealModifyReadDetails.versionNo;
      appealedCaseApproval.approve(appealedCaseApproveDetails);
    }

    // END, CR00052221

    return appealRelationshipKey;
  }

  // ___________________________________________________________________________
  /**
   * Creates the relationship records for the appeal.
   *
   * @param details
   * contains the case details
   */
  @Override
  public void
    createAppealRelationships(final CreateAppealRelationshipsDetails details)
      throws AppException, InformationalException {

    // variables to update the appeal indicator
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Case Relationship variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelationshipDtls caseRelationshipDtls =
      new CaseRelationshipDtls();

    // Case Event variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // set the appeal indicator to true on the prior case
    caseHeaderKey.caseID = details.priorAppealCaseID;
    caseAppealIndicatorDetails.appealIndicator = true;
    caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
      caseAppealIndicatorDetails);

    // setup and insert case relationship record
    caseRelationshipDtls.caseRelationshipID = uniqueIDObj.getNextID();
    caseRelationshipDtls.caseID = details.appealCaseID;
    caseRelationshipDtls.relatedCaseID = details.priorAppealCaseID;
    // BEGIN, CR00022666, RKi
    final AppealCaseID appealCaseID = new AppealCaseID();

    appealCaseID.caseID = details.appealCaseID;

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.priorAppealCaseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
      // END, CR00303986

      caseRelationshipDtls.typeCode = CASERELATIONSHIPTYPECODE.ISSUEAPPEAL;
    } else {
      // END, CR00022666
      caseRelationshipDtls.typeCode = CASERELATIONSHIPTYPECODE.APPEALAPPEAL;
    }
    caseRelationshipDtls.reasonCode = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    caseRelationshipDtls.startDate = currentDate;
    caseRelationshipDtls.statusCode = RECORDSTATUS.NORMAL;

    caseRelationshipObj.insert(caseRelationshipDtls);

    // setup and insert case event for prior appeal to say that a decision
    // has
    // been appealed
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.appealCaseID;
    caseEventDtls.eventTypeCode = details.eventTypeCode;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.relatedID = details.appealCaseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates the case participant role records for the appellant
   *
   * @param details
   * contains the appellant details
   */
  @Override
  public CaseParticipantRoleKey
    createAppellantParticipant(final CreateParticipantDetails details)
      throws AppException, InformationalException {

    // CaseParticipantRole variables
    final CaseParticipantRoleDetails caseParticipantRoleDetails =
      new CaseParticipantRoleDetails();

    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRoleDetails.dtls.participantRoleID =
      details.participantRoleID;
    caseParticipantRoleDetails.dtls.caseID = details.appealCaseID;
    caseParticipantRoleDetails.dtls.fromDate =
      curam.util.type.Date.getCurrentDate();
    caseParticipantRoleDetails.dtls.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;

    caseParticipantRoleObj
      .insertCaseParticipantRole(caseParticipantRoleDetails);

    // BEGIN, CR00021086, RKi
    // returning the CaseParticipantRoleKey to insert the primary client to
    // appellant entity while creating a Hearing Case, Hearing Review or
    // Judicial Review.
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID =
      caseParticipantRoleDetails.dtls.caseParticipantRoleID;
    // END, CR00021086

    return caseParticipantRoleKey;
  }

  // ___________________________________________________________________________
  /**
   * Creates the case participant role records for the respondent
   *
   * @param details
   * contains the appellant details
   */
  @Override
  public void
    createRespondentParticipant(final CreateParticipantDetails details)
      throws AppException, InformationalException {

    // CaseParticipantRole variables
    final CaseParticipantRoleDetails caseParticipantRoleDetails =
      new CaseParticipantRoleDetails();
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    caseParticipantRoleDetails.dtls.participantRoleID =
      details.participantRoleID;
    caseParticipantRoleDetails.dtls.caseID = details.appealCaseID;
    caseParticipantRoleDetails.dtls.fromDate =
      curam.util.type.Date.getCurrentDate();
    caseParticipantRoleDetails.dtls.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;

    caseParticipantRoleObj
      .insertCaseParticipantRole(caseParticipantRoleDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates the relationship and records for the assessment delivery
   *
   * @param details
   * contains the case details
   */
  @Override
  public void createLinkToAssessmentDelivery(
    final CreateLinkToAssessmentDeliveryDetails details)
    throws AppException, InformationalException {

    // variables to update the appeal indicator
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Case Relationship variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelationshipDtls caseRelationshipDtls =
      new CaseRelationshipDtls();

    // Case Event variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // set the appeal indicator to true on the assessment delivery case
    caseHeaderKey.caseID = details.caseID;
    caseAppealIndicatorDetails.appealIndicator = true;
    caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
      caseAppealIndicatorDetails);

    // insert CaseRelationship between assessment delivery and appeal case
    caseRelationshipDtls.caseRelationshipID = uniqueIDObj.getNextID();
    caseRelationshipDtls.caseID = details.caseID;
    caseRelationshipDtls.relatedCaseID = details.appealCaseID;
    caseRelationshipDtls.typeCode = CASERELATIONSHIPTYPECODE.ASSESSMENTAPPEAL;
    caseRelationshipDtls.reasonCode = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    caseRelationshipDtls.statusCode = RECORDSTATUS.NORMAL;
    caseRelationshipDtls.startDate = currentDate;
    caseRelationshipObj.insert(caseRelationshipDtls);

    // insert case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.eventTypeCode = details.caseEventType;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.relatedID = details.appealCaseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates the relationship and event records for the product delivery
   *
   * @param details
   * contains the case details
   */
  @Override
  public void createLinkToProductDelivery(
    final CreateLinkToProductDeliveryDetails details)
    throws AppException, InformationalException {

    // variables to update the appeal indicator
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Case Relationship variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelationshipDtls caseRelationshipDtls =
      new CaseRelationshipDtls();

    // Case Event variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // set the appeal indicator to true on the prior case
    caseHeaderKey.caseID = details.caseID;
    caseAppealIndicatorDetails.appealIndicator = true;
    caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
      caseAppealIndicatorDetails);

    // insert CaseRelationship between product delivery and appeal case
    caseRelationshipDtls.caseRelationshipID = uniqueIDObj.getNextID();
    caseRelationshipDtls.caseID = details.caseID;
    caseRelationshipDtls.relatedCaseID = details.appealCaseID;
    caseRelationshipDtls.typeCode = CASERELATIONSHIPTYPECODE.PRODUCTAPPEAL;
    caseRelationshipDtls.reasonCode = CASERELATIONSHIPREASONCODE.LINKEDCASES;
    caseRelationshipDtls.statusCode = RECORDSTATUS.NORMAL;
    caseRelationshipDtls.startDate = currentDate;
    caseRelationshipObj.insert(caseRelationshipDtls);

    // insert case event for product delivery
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.eventTypeCode = details.caseEventType;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.relatedID = details.appealCaseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;

    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates the relationship records between the cases.
   *
   * @param details
   * contains the case details
   */
  @Override
  public void
    createRelationshipLinks(final CreateRelationshipLinksDetails details)
      throws AppException, InformationalException {

    // case relationship objects
    final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
      new CaseRelByCaseIDStatusReasonTypeKey();
    CaseRelationshipDtlsList caseRelationshipDtlsList;
    final curam.core.intf.CaseRelationship caseRelationshipObj =
      curam.core.fact.CaseRelationshipFactory.newInstance();

    // Variables for determining appealed case type
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;

    // structs used to create links
    final CreateLinkToProductDeliveryDetails createLinkToProductDeliveryDetails =
      new CreateLinkToProductDeliveryDetails();
    final CreateLinkToAssessmentDeliveryDetails createLinkToAssessmentDeliveryDetails =
      new CreateLinkToAssessmentDeliveryDetails();
    final CreateAppealRelationshipsDetails createAppealRelationshipsDetails =
      new CreateAppealRelationshipsDetails();

    // the type of appealed event
    String caseEventType;

    // set the type of the case event
    if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      caseEventType = CASEEVENTTYPE.APPEALEDTOHEARINGCASE;
    } else if (details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {

      caseEventType = CASEEVENTTYPE.APPEALEDTOHEARINGREVIEW;
    } else {

      caseEventType = CASEEVENTTYPE.APPEALEDTOJUDICIALREVIEW;
    }

    // Determine the case type of the appealed case. If the appealed case is
    // an assessment delivery then determine the associated product delivery
    // and
    // if one exists create a link to the assessment's product delivery.
    // If the appealed case is not an assessment delivery then create a link
    // the product delivery case being appealed.
    caseKey.caseID = details.caseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      createLinkToAssessmentDeliveryDetails.caseID = details.caseID;
      createLinkToAssessmentDeliveryDetails.appealCaseID =
        details.appealCaseID;
      createLinkToAssessmentDelivery(createLinkToAssessmentDeliveryDetails);

      // determine the product delivery for the assessment delivery
      caseRelByCaseIDStatusReasonTypeKey.caseID = details.caseID;
      caseRelByCaseIDStatusReasonTypeKey.reasonCode =
        CASERELATIONSHIPREASONCODE.LINKEDCASES;
      caseRelByCaseIDStatusReasonTypeKey.statusCode =
        CASERELATIONSHIPSTATUSCODE.DEFAULTCODE;
      caseRelByCaseIDStatusReasonTypeKey.typeCode =
        CASERELATIONSHIPTYPECODE.ASSESSMENTPRODUCT;
      caseRelationshipDtlsList = caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

      // if one found, create the link
      if (caseRelationshipDtlsList.dtls.size() > 0) {

        createLinkToProductDeliveryDetails.caseEventType = caseEventType;
        createLinkToProductDeliveryDetails.caseID =
          caseRelationshipDtlsList.dtls.item(0).relatedCaseID;
        createLinkToProductDeliveryDetails.appealCaseID =
          details.appealCaseID;
        createLinkToProductDelivery(createLinkToProductDeliveryDetails);

      }

    } else {

      createLinkToProductDeliveryDetails.caseEventType = caseEventType;
      createLinkToProductDeliveryDetails.caseID = details.caseID;
      createLinkToProductDeliveryDetails.appealCaseID = details.appealCaseID;
      createLinkToProductDelivery(createLinkToProductDeliveryDetails);

    }

    // If a decision from a prior appeal case is being appealed then create
    // a link between the current appeal case and the prior appeal case.
    if (details.priorAppealCaseID != 0) {

      createAppealRelationshipsDetails.appealCaseID = details.appealCaseID;
      createAppealRelationshipsDetails.priorAppealCaseID =
        details.priorAppealCaseID;
      createAppealRelationshipsDetails.eventTypeCode = caseEventType;
      createAppealRelationships(createAppealRelationshipsDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates adding an appealed case to an appeal
   *
   * @param details
   * The case details entered
   */
  @Override
  public void validateAddAppealedCase(final AddNewAppealedCaseDetails details)
    throws AppException, InformationalException {

    // Case header variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // details returned during validations
    CaseHeaderDtls caseHeaderDtls;

    // Variable to validate the case level
    final ValidateAppealedCaseLevelDetails validateAppealedCaseLevelDetails =
      new ValidateAppealedCaseLevelDetails();

    // Object to create informational messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // validate appeal case ID
    if (details.appealCaseID == 0) {
      throw new AppException(
        curam.message.BPOAPPEAL.ERR_APPEAL_FV_NOAPPEALCASE);
    }

    // BEGIN, CR00021514, RKi
    /*
     * caseHeaderKey.caseID = details.implCaseID; caseHeaderDtls =
     * caseHeaderObj.read(caseHeaderKey); secondConcernRoleId =
     * caseHeaderDtls.concernRoleID;
     *
     * // check type and status of appeal case caseHeaderKey.caseID =
     * details.appealCaseID; caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
     *
     * if (caseHeaderDtls.concernRoleID != secondConcernRoleId) { throw new
     * AppException( BPOAPPEAL.ERR_APPEAL_XRV_APPELLANT_RESPONDENT_INVALID); }
     */
    // END, CR00021514
    // check type and status of appeal case
    caseHeaderKey.caseID = details.appealCaseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (!caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

      throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_WRONGTYPE);

    }

    if (caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)) {

      throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_CLOSED);

    }

    // validate case ID
    if (details.implCaseID == 0) {
      throw new AppException(BPOAPPEAL.ERR_APPEAL_FV_NOCASE);
    }

    // Validate appealed case can be appealed to this level
    validateAppealedCaseLevelDetails.appealTypeCode = details.appealTypeCode;
    validateAppealedCaseLevelDetails.implCaseID = details.implCaseID;
    validateAppealedCaseLevelDetails.priorAppealCaseID =
      details.priorAppealCaseID;
    validateAppealedCaseLevel(validateAppealedCaseLevelDetails);

    // check the prior appeal case
    // If non-zero, then a previous appeal decision is being appealed
    if (details.priorAppealCaseID != 0) {

      caseHeaderKey.caseID = details.priorAppealCaseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      if (!caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
        throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_PRIORCASE);
      }

      // The received date must not be before the end date of the appeal
      // case
      // being appealed.
      if (details.addAppealedCaseInputDetails.dateReceived
        .before(caseHeaderDtls.endDate)) {

        informationalManager.addInformationalMsg(
          new AppException(
            BPOAPPEAL.ERR_APPEAL_XRV_DATERECEIVED_BEFORE_ENDDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }

      // The received date must not be before the registration date of the
      // appeal case being appealed.
      if (details.addAppealedCaseInputDetails.dateReceived
        .before(caseHeaderDtls.registrationDate)) {

        informationalManager.addInformationalMsg(
          new AppException(
            BPOAPPEAL.ERR_APPEAL_XRV_DATERECEIVED_BEFORE_REGISTRATIONDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }

      // the prior appeal must be closed
      if (!caseHeaderDtls.statusCode
        .equals(curam.codetable.CASESTATUS.CLOSED)) {

        informationalManager.addInformationalMsg(
          new AppException(BPOAPPEAL.ERR_APPEAL_XRV_PRIORNOTCLOSED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }

    }

    // Determine if the case is already being appealed is on an active
    // appeal case for the same level of appeal.

    // Validate that the decision is not already being appealed
    final curam.appeal.sl.intf.AppealedCase appealedCaseObj =
      curam.appeal.sl.fact.AppealedCaseFactory.newInstance();
    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();
    CaseAlreadyAppealed caseAlreadyAppealed;

    caseAndPriorAppeal.caseID = details.implCaseID;
    caseAndPriorAppeal.priorAppealCaseID = details.priorAppealCaseID;

    caseAlreadyAppealed =
      appealedCaseObj.isAlreadyAppealed(caseAndPriorAppeal);

    if (caseAlreadyAppealed.appealed) {
      // BEGIN, CR00384148, DG
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(BPOAPPEAL.ERR_APPEAL_XRV_ACTIVECASE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
      // END, CR00384148
    }

    // Check that receipt notice indicator is true
    if (details.addAppealedCaseInputDetails.receiptNoticeIndicator) {

      // Variables to determine the appellant type for the appealed case
      final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

      appealCaseIDKey.caseID = details.appealCaseID;

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates that the role for the participant for the appeal case is valid.
   *
   * @param details
   * The participant role details
   */
  @Override
  public void
    validateParticipantRole(final ValidateParticipantRoleDetails details)
      throws AppException, InformationalException {

    // Participant Validation Objects
    final CaseIDParticipantRoleIDKey caseIDParticipantRoleIDKey =
      new CaseIDParticipantRoleIDKey();
    final ParticipantValidation participantValidationObj =
      ParticipantValidationFactory.newInstance();

    caseIDParticipantRoleIDKey.caseID = details.caseID;
    caseIDParticipantRoleIDKey.participantRoleID = details.participantRoleID;

    // Invoke the relevant validation method depending on the participant
    // role
    // type specified
    if (CASEPARTICIPANTROLETYPE.APPELLANT.equals(details.typeCode)) {
      participantValidationObj.validateAppellant(caseIDParticipantRoleIDKey);
    } else if (CASEPARTICIPANTROLETYPE.RESPONDENT.equals(details.typeCode)) {
      participantValidationObj.validateRespondent(caseIDParticipantRoleIDKey);
    } else if (CASEPARTICIPANTROLETYPE.HEARINGTRANSCRIBER
      .equals(details.typeCode)) {
      participantValidationObj
        .validateTranscriptionRequester(caseIDParticipantRoleIDKey);
    } else if (CASEPARTICIPANTROLETYPE.THIRDPARTY.equals(details.typeCode)) {
      participantValidationObj.validateThirdParty(caseIDParticipantRoleIDKey);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details for an appeal case creation.
   *
   * @param details
   * The appeal case details
   */
  @Override
  public void validateCreateAppealCase(final AppealCreateCaseDetails details)
    throws AppException, InformationalException {

    // Participant Validation Object
    final ValidateParticipantRoleDetails validateParticipantRoleDetails =
      new ValidateParticipantRoleDetails();

    // BEGIN, CR00096787, RKi
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.participantRoleID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd =
      clientMergeObj.isConcernRoleDuplicate(concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      throw new AppException(
        BPOAPPEALCLIENTMERGE.ERR_CREATE_APPEAL_CASE_DUPLICATE_CLIENT);
    }
    // END, CR00096787

    // If a decision from a prior appeal case is being appealed use
    // priorAppealCaseID
    if (details.priorAppealCaseID != 0) {
      validateParticipantRoleDetails.caseID = details.priorAppealCaseID;
    } else {
      validateParticipantRoleDetails.caseID = details.caseID;
    }

    validateParticipantRoleDetails.participantRoleID =
      details.participantRoleID;

    // Set Participant Role Type based on the Appellant Type specified
    if (APPELLANTTYPE.CLAIMANT.equals(details.appellantTypeCode)) {
      validateParticipantRoleDetails.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
    } else {
      validateParticipantRoleDetails.typeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;
    }

    validateParticipantRole(validateParticipantRoleDetails);
  }

  // BEGIN, CR00096605, RKi
  // ___________________________________________________________________________
  /**
   * This method determines if it is valid to appeal the decision to the type of
   * appeal case specified. Validity is determined by both the level of appeal
   * and the underlying product for the appealed case.
   *
   * For example, if a decision (related to an implementation case) from a
   * hearing case which was the first level of appeal is being appealed to a
   * hearing review case, then it must be valid for a hearing review case to be
   * created as the second level of appeal for the implementation case.
   *
   * @param details
   * Details of the appealed case.
   */
  @Override
  public void
    validateAppealedCaseLevel(final ValidateAppealedCaseLevelDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00284786, DG
    // Product Appeal Process Service Layer variables
    final curam.appeal.sl.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.fact.ProductAppealProcessFactory.newInstance();
    curam.appeal.sl.struct.AppealStageType appealStageType = null;
    final StagePositionDetails stagePositionDetails =
      new StagePositionDetails();
    long priorAppealCount = 0;
    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Get the number of previous appeals for the decision being appealed
    // (if any). This gives the current appeal level for the underlying
    // case being appealed.
    caseAndPriorAppeal.caseID = details.implCaseID;
    caseAndPriorAppeal.priorAppealCaseID = details.priorAppealCaseID;

    final CaseKey caseKey = new CaseKey();
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcess =
      IssueAppealProcessFactory.newInstance();
    final curam.appeal.sl.intf.IntegratedCaseAppealProcess icAppealProcess =
      IntegratedCaseAppealProcessFactory.newInstance();
    final IssueStagePositionDetails issueStagePositionDetails =
      new IssueStagePositionDetails();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseKey.caseID = details.implCaseID;
    // read the case type
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // BEGIN, CR00346500, DG
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
      priorAppealCount =
        issueAppealProcess.getNumberPriorAppeals(caseAndPriorAppeal).count;
    } else if (caseTypeCode.caseTypeCode
      .equals(CASETYPECODE.INTEGRATEDCASE)) {
      priorAppealCount =
        issueAppealProcess.getNumberPriorAppeals(caseAndPriorAppeal).count;
    } else if (caseTypeCode.caseTypeCode
      .equals(CASETYPECODE.PRODUCTDELIVERY)) {
      priorAppealCount = productAppealProcessObj
        .getNumberPriorAppeals(caseAndPriorAppeal).count;
    } else {
      final AppealableCaseType appealableCaseType = appealableCaseTypeMap
        .get(CASETYPECODEEntry.get(caseTypeCode.caseTypeCode));

      if (appealableCaseType != null) {
        priorAppealCount =
          issueAppealProcess.getNumberPriorAppeals(caseAndPriorAppeal).count;
      }
    }
    // END, CR00346500

    // if the case is Appeal then increment the prior appeal count to
    // compute the correct index for levels

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {
      priorAppealCount++;
    }

    // Get the casetypeID
    long caseTypeID = 0;
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
      caseHeaderDAO.get(details.implCaseID);
    final CaseConfiguration adminCaseConfiguration =
      caseHeader.getAdminCaseConfiguration();

    if (adminCaseConfiguration != null) {
      caseTypeID = caseHeader.getAdminCaseConfiguration().getID();
    }

    // Validate the process only if there is an associated product
    // No validation is required for standalone assessment cases
    if (caseTypeID != 0) {

      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        stagePositionDetails.productID = caseTypeID;
        stagePositionDetails.startDate = Date.getCurrentDate();
        stagePositionDetails.position = priorAppealCount;
        appealStageType =
          productAppealProcessObj.getStageAtPosition(stagePositionDetails);
      } else {
        issueStagePositionDetails.caseTypeID = caseTypeID;
        issueStagePositionDetails.startDate = Date.getCurrentDate();
        issueStagePositionDetails.position = priorAppealCount;
        appealStageType = AppealableCaseTypeAppealProcessFactory.newInstance()
          .getStageAtPosition(issueStagePositionDetails);

      }

      if (appealStageType == null) {
        // There are no further levels of appeal for this product.
        throw new AppException(
          BPOAPPEAL.ERR_APPEAL_RNFE_APPEALTYPE_NOTDEFINED);
      }

      // Determine if the type of appeal being created is valid for the
      // next
      // stage in the appeal process for the product.
      // If the next valid stage in the appeal process is "any" then any
      // type of
      // appeal case can be created. Otherwise the next valid stage in the
      // appeal
      // process must be the same as the type of appeal being created.
      if (!appealStageType.appealStageType.appealStageType
        .equals(APPEALSTAGEAPPEALTYPE.ANY)
        && !appealStageType.appealStageType.appealStageType
          .equals(details.appealTypeCode)) {

        throw new AppException(
          BPOAPPEAL.ERR_APPEAL_XFV_APPEALTYPE_NOTALLOWED);
      }
    }
    // END, CR00284786
  }

  // END, CR00096605

  // ___________________________________________________________________________
  /**
   * Returns a list of decisions for an appeal case
   *
   * @param key
   * Contains the caseID
   *
   * @return The list of decisions
   */
  @Override
  public DecisionsForAppealCaseDetails listDecisionsForAppealCase(
    final AppealCaseKey key) throws AppException, InformationalException {

    // appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // entity object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // lookup keys
    final AppealCaseStatus appealCaseStatus = new AppealCaseStatus();
    final DecisionsForAppealCaseDetails decisionsForAppealCaseDetails =
      new DecisionsForAppealCaseDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // validate the prior appeal case
    appeal_boObj.validatePriorAppealCase(key);

    // Retrieve the list of decisions for the hearing case.
    appealCaseStatus.appealCaseID = key.caseID;
    decisionsForAppealCaseDetails.caseResolutionCodeList =
      appealRelationshipObj
        .searchActiveDecisionsByAppealCase(appealCaseStatus);

    return decisionsForAppealCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns the case type for the case selected to add to an
   * existing appeal case. This method also validates if a request for appeal
   * related to the selected case can be appealed to the type of appeal case;
   * the level of validation which can be performed depends on the type of the
   * selected case.
   *
   * The selected case can be a previously decided appeal case or an original
   * case within the system. Therefore the level of validation which can be
   * performed depends on the type of the selected case. If a prior appeal case
   * is selected then limited validation can be performed as the decision from
   * that appeal case is unknown at this stage. If an implementation case is
   * selected then it must be valid to directly appeal the case to the an appeal
   * of the specified type.
   *
   * @param details
   * The caseID of the case selected to add to an appeal case.
   * @return The case type of the selected case.
   */
  @Override
  public CaseType resolveAddCaseSelection(final CaseIDAppealTypeCode details)
    throws AppException, InformationalException {

    // Variables for determining and returning the type of the case selected
    final DetermineCaseTypeKey determineCaseTypeKey =
      new DetermineCaseTypeKey();
    final CaseIDCaseTypeAppealType caseIDCaseTypeAppealType =
      new CaseIDCaseTypeAppealType();
    DetermineCaseTypeDtls determineCaseTypeDtls;
    final CaseType caseType = new CaseType();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = details.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Determine the case type for the selected case
    determineCaseTypeKey.caseID = details.caseID;
    determineCaseTypeDtls = curam.core.fact.DetermineCaseTypeFactory
      .newInstance().getCaseType(determineCaseTypeKey);

    // Validate the appealed case selection
    caseIDCaseTypeAppealType.caseID = details.caseID;
    caseIDCaseTypeAppealType.caseType = determineCaseTypeDtls.caseTypeCode;
    caseIDCaseTypeAppealType.appealTypeCode = details.appealTypeCode;
    validateAddCaseSelection(caseIDCaseTypeAppealType);

    caseType.caseType = determineCaseTypeDtls.caseTypeCode;
    return caseType;

  }

  // ___________________________________________________________________________
  /**
   * Validates if it is valid to add the selected case to a an appeal case and
   * also validates that there are no active appeals for the selected case.
   *
   * @param details
   * Contains the caseID, caseType and appealType
   */
  @Override
  public void validateAddCaseSelection(final CaseIDCaseTypeAppealType details)
    throws AppException, InformationalException {

    // Variable to validate the case level
    final ValidateAppealedCaseLevelDetails validateAppealedCaseLevelDetails =
      new ValidateAppealedCaseLevelDetails();

    // Appeal Relationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveByAppealCaseAndAppealTypeKey activeByAppealCaseAndAppealTypeKey =
      new ActiveByAppealCaseAndAppealTypeKey();
    AppealCaseIDList appealCaseIDList;

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Validate that the type of appeal case is valid for the next level of
    // appeal for the decision being appealed.
    validateAppealedCaseLevelDetails.appealTypeCode = details.appealTypeCode;
    validateAppealedCaseLevelDetails.implCaseID = details.caseID;
    validateAppealedCaseLevel(validateAppealedCaseLevelDetails);

    if (details.caseType.equals(curam.codetable.CASETYPECODE.APPEAL)) {

      // Only decisions from closed prior appeal cases can be appealed.
      caseHeaderKey.caseID = details.caseID;
      caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

      if (!caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

        throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_APPEALNOTCLOSED);
      }

    } else {
      // Validate that there are no ACTIVE appeals for the selected case
      // at the same appeal level.
      activeByAppealCaseAndAppealTypeKey.appealTypeCode =
        details.appealTypeCode;
      activeByAppealCaseAndAppealTypeKey.caseID = details.caseID;
      appealCaseIDList =
        appealRelationshipObj.searchActiveAppealByCaseAndAppealType(
          activeByAppealCaseAndAppealTypeKey);

      if (appealCaseIDList.dtls.size() > 0) {
        // BEGIN, CR00384148, DG
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(BPOAPPEAL.ERR_APPEAL_XRV_ACTIVECASE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        // END, CR00384148
      }

    }
  }

  // ___________________________________________________________________________
  /**
   * This method validates whether or not the new deadline date for the appeal
   * is valid or not.
   *
   * @param key
   * Contains the appeal case ID and the deadlineDate
   */
  @Override
  public void validateAppealDeadline(final AppealCaseIDDeadlineDate key)
    throws AppException, InformationalException {

    // Hearing object
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();

    // lookup keys
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();

    // Read the latest scheduled hearing for the appeal case.
    caseAndStatusKey.caseID = key.appealCaseID;
    caseAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;

    // Search for a scheduled hearing
    // The catch does nothing, as it is acceptable to have no hearing
    // scheduled
    try {

      final HearingScheduleDate hearingScheduleDate =
        hearingObj.readLatestScheduledDateByCaseAndStatus(caseAndStatusKey);

      // Cannot add case to appeal as deadline is before the scheduled
      // hearing for the appeal
      if (key.deadlineDate.before(new Date(TimeZoneUtility
        .getTimeZoneAdjustedDateTime(hearingScheduleDate.scheduledDateTime,
          TransactionInfo.getUserTimeZone())))) {

        throw new AppException(
          BPOAPPEAL.ERR_APPEAL_XRV_DEADLINEBEFORESCHEDULED);

      }

    } catch (final RecordNotFoundException e) {// DO NOTHING
    }

  }

  // ___________________________________________________________________________
  /**
   * This method validates the prior appeal case from which a decision is being
   * appealed.
   *
   * @param key
   * Contains the appeal case ID
   */
  @Override
  public void validatePriorAppealCase(final AppealCaseKey key)
    throws AppException, InformationalException {

    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // read status and type
    caseHeaderKey.caseID = key.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)) {

        throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_PRIORNOTCLOSED);
      }

    } else {

      throw new AppException(BPOAPPEAL.ERR_APPEAL_XRV_PRIORNOTAPPEAL);
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to read the details required for creating an appeal case
   *
   * @param key
   * Contains the details needed to perform the read
   *
   * @return The details required for appeal case creation
   */
  @Override
  public ReadForCreateDetails readForCreate(final ReadForCreateKey key)
    throws AppException, InformationalException {

    // Return details
    final ReadForCreateDetails readForCreateDetails =
      new ReadForCreateDetails();

    // Case Header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseReference caseReference;

    // ConcernRole object
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetail;
    ConcernRoleNameTypeAndAlternateID concernRoleNameTypeAndAlternateID;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    if (key.priorAppealCaseID != 0) {

      readForCreateDetails.appealedCaseID = key.priorAppealCaseID;

    } else {

      readForCreateDetails.appealedCaseID = key.caseID;
    }

    caseSearchKey.caseID = key.caseID;

    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    concernRoleKey.concernRoleID = key.participantRoleID;
    concernRoleNameDetail =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    readForCreateDetails.caseReference = caseReference.caseReference;
    readForCreateDetails.displayName = concernRoleNameDetail.concernRoleName;

    // get the display name and type
    concernRoleKey.concernRoleID = key.participantRoleID;
    concernRoleNameTypeAndAlternateID =
      concernRoleObj.readConcernRoleNameTypeAndAlternateID(concernRoleKey);

    readForCreateDetails.participantRoleType =
      concernRoleNameTypeAndAlternateID.concernRoleType;

    return readForCreateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Allows the user to select the participants for the appeal case and
   * indicates if there are active appeal cases of the specified type with the
   * same appellant and respondent
   *
   * @param details
   * The appellant and respondent details
   * @return The participantRoleID and active appeal indicator
   */
  @Override
  public AppellantAndRespondentReturnDetails
    enterAppellantAndRespondent(final AppellantAndRespondentDetails details)
      throws AppException, InformationalException {

    // Appeal Objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Active Appeal case key
    final ActiveAppealCaseKey activeAppealCaseKey = new ActiveAppealCaseKey();

    // Return details
    final AppellantAndRespondentReturnDetails appellantAndRespondentReturnDetails =
      new AppellantAndRespondentReturnDetails();

    // Participant role details for validation
    final ValidateParticipantRoleDetails validateParticipantRoleDetails =
      new ValidateParticipantRoleDetails();

    // CaseParticipantRole objects
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey =
      new curam.core.sl.entity.struct.CaseParticipantRoleKey();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = details.implCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate appellant and respondent
    validateAppellantAndRespondentCombination(details);

    if (details.appellantOrganizationInd) {

      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.ORGANIZATION;
      caseParticipantRoleKey.caseParticipantRoleID =
        details.respondentCaseParticipantRoleID;
      validateParticipantRoleDetails.typeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;

    } else {
      appellantAndRespondentReturnDetails.appellantTypeCode =
        curam.codetable.APPELLANTTYPE.CLAIMANT;
      caseParticipantRoleKey.caseParticipantRoleID =
        details.appellantCaseParticipantRoleID;
      validateParticipantRoleDetails.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;

    }

    // get the participantRoleID
    caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj
      .readCaseIDandParticipantID(caseParticipantRoleKey);

    // validate that the caseParticipantRoleID provided is a valid
    // participant
    // the appealed case.
    if (details.priorAppealCaseID != 0) {
      validateParticipantRoleDetails.caseID = details.priorAppealCaseID;
    } else {
      validateParticipantRoleDetails.caseID = details.implCaseID;
    }

    validateParticipantRoleDetails.participantRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    appeal_boObj.validateParticipantRole(validateParticipantRoleDetails);

    // Set the return value of the participantRoleID
    appellantAndRespondentReturnDetails.participantRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;

    activeAppealCaseKey.appealTypeCode = details.appealTypeCode;
    activeAppealCaseKey.participantRoleID =
      appellantAndRespondentReturnDetails.participantRoleID;
    activeAppealCaseKey.caseParticipantRoleTypeCode =
      validateParticipantRoleDetails.typeCode;

    final int relatedAppealCaseCount =
      appealObj.countActiveByTypeAndParticipantAndRole(
        activeAppealCaseKey).numberOfRecords;

    if (relatedAppealCaseCount > 0) {
      appellantAndRespondentReturnDetails.activeAppealInd = true;
    } else {
      appellantAndRespondentReturnDetails.activeAppealInd = false;
    }

    return appellantAndRespondentReturnDetails;

  }

  // ___________________________________________________________________________
  /**
   * Validates that the participants selected for the appeal case are valid
   * combinations
   *
   * @param details
   * The appellant and respondent details
   */
  @Override
  public void validateAppellantAndRespondentCombination(
    final AppellantAndRespondentDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // The organization cannot be both the appellant and the respondent
    if (details.appellantOrganizationInd
      && details.respondentOrganizationInd) {

      informationalManager.addInformationalMsg(
        new AppException(BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_ORGINDICATOR),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // A participant cannot be specified for both the appellant and
    // the respondent
    if (details.appellantCaseParticipantRoleID != 0
      && details.respondentCaseParticipantRoleID != 0) {

      informationalManager.addInformationalMsg(
        new AppException(
          BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_CASEPARTICIPANT),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } else {

      // Is appellant the organization
      if (details.appellantOrganizationInd) {

        // The appellant cannot be both the organization and a
        // participant
        if (details.appellantCaseParticipantRoleID != 0) {

          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_APPELLANTASBOTH),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }

        // BEGIN, CR CR00065993, NSP
        // A respondent participant must be specified
        if (details.respondentCaseParticipantRoleID == 0
          && !details.respondentOrganizationInd) {

          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_PARTASRESPONDENT),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }
        // END, CR CR00065993

        // Is respondent the organization
      } else if (details.respondentOrganizationInd) {

        // The respondent cannot be both the organization and a
        // participant
        if (details.respondentCaseParticipantRoleID != 0) {

          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_RESPONDENTASBOTH),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }

        // An appellant participant must be specified
        if (details.appellantCaseParticipantRoleID == 0) {

          informationalManager.addInformationalMsg(
            new AppException(BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_APPELLANT),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }
      } else {

        // The organization must be the respondent
        if (details.appellantCaseParticipantRoleID != 0) {

          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_ORGASRESPONDENT),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        } else if (details.respondentCaseParticipantRoleID != 0) {
          // A participant respondent has been specified so the
          // organization
          // should be the appellant
          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_ORGASAPPELLANT),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        } else {
          // An appellant and respondent must be specified
          informationalManager.addInformationalMsg(
            new AppException(
              BPOHEARINGREVIEW.ERR_HEARINGREVIEW_FV_NOAPPELLANTORRESPONDENT),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        }
      }
    }
    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of decisions for appeal cases, of the specified type, where
   * the decision was regarding an appeal for the specified implementation case.
   *
   * @param key
   * The key containing the caseID and appealTypeCode
   *
   * @return The list of decision details for the implementation case
   */
  @Override
  public DecisionForImplCaseDetailsList
    listDecisionsForImplementationCase(final DecisionsForImplCaseKey key)
      throws AppException, InformationalException {

    // Appeal Objects
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();

    // Variables for returning the list of prior appeal decisions
    final ActiveDecisionsByCaseKey activeDecisionsByCaseKey =
      new ActiveDecisionsByCaseKey();
    final DecisionForImplCaseDetailsList decisionForImplCaseDetailsList =
      new DecisionForImplCaseDetailsList();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security for read access
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    activeDecisionsByCaseKey.caseID = key.caseID;
    decisionForImplCaseDetailsList.caseResolutionCodeList =
      appealRelationObj.searchActiveDecisionsByCase(activeDecisionsByCaseKey);

    return decisionForImplCaseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of active appeal cases of a specified type, for the
   * appellant/respondent.
   *
   * @param key
   * Contains the participantRoleID, appealType and appellantType
   * @return The list of active appeals
   */
  @Override
  public ActiveAppealsDetailsList
    listActiveAppealsForParticipantRole(final ParticipantRoleKey key)
      throws AppException, InformationalException {

    // Appeal Objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // Variables for returning list of active appeal cases
    ActiveAppealsDetails activeAppealsDetails;
    final ActiveAppealsDetailsList activeAppealsDetailsList =
      new ActiveAppealsDetailsList();
    ActiveAppealCaseDetailsList activeAppealCaseDetailsList;
    final ActiveAppealCaseKey activeAppealCaseKey = new ActiveAppealCaseKey();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security for read access
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // If the organization is the appellant, set the participant type to be
    // respondent
    if (key.appellantTypeCode
      .equals(curam.codetable.APPELLANTTYPE.ORGANIZATION)) {

      activeAppealCaseKey.caseParticipantRoleTypeCode =
        CASEPARTICIPANTROLETYPE.RESPONDENT;
    } else {
      activeAppealCaseKey.caseParticipantRoleTypeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
    }

    activeAppealCaseKey.appealTypeCode = key.appealTypeCode;
    activeAppealCaseKey.participantRoleID = key.participantRoleID;
    activeAppealCaseDetailsList =
      appealObj.searchActiveByTypeAndParticipantAndRole(activeAppealCaseKey);

    if (activeAppealCaseDetailsList.dtls.size() > 0) {

      for (int i = 0; i < activeAppealCaseDetailsList.dtls.size(); i++) {

        activeAppealsDetails = new ActiveAppealsDetails();

        // BEGIN, CR00053295, RKi
        final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
        CaseOwnerDetails caseOwnerDetails;

        orgObjectLinkKey.orgObjectLinkID =
          activeAppealCaseDetailsList.dtls.item(i).ownerOrgObjectLinkID;
        final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

        caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
        // END, CR00053295

        activeAppealsDetails.appealCaseID =
          activeAppealCaseDetailsList.dtls.item(i).caseID;
        activeAppealsDetails.caseOwner = caseOwnerDetails.userFullName;
        activeAppealsDetails.caseReference =
          activeAppealCaseDetailsList.dtls.item(i).caseReference;
        activeAppealsDetails.status =
          activeAppealCaseDetailsList.dtls.item(i).status;
        activeAppealsDetails.deadlineDate =
          activeAppealCaseDetailsList.dtls.item(i).deadlineDate;
        activeAppealsDetails.receivedDate =
          activeAppealCaseDetailsList.dtls.item(i).receivedDate;

        activeAppealsDetailsList.activeAppealsDetails
          .addRef(activeAppealsDetails);

      }
    }

    return activeAppealsDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns all the appealed cases for the given appealCaseID
   *
   * @param key
   * The appeal caseID
   *
   * @return The list of appealed case details
   */
  @Override
  public AppealedDetailsList listAppealedIssues(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Variables for list maintenance
    final AppealedDetailsList appealedDetailsList = new AppealedDetailsList();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security for read access
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Search for appeals that are related to this case
    appealCaseID.appealCaseID = key.caseID;
    // BEGIN, CR00022785, RKi
    final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
      new AppealCaseIDTYypeRecordStatusDetails();

    // BEGIN, CR00081844, RKi
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // END, CR00081844

    appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
    appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
    appealCaseIDTYypeRecordStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
    appealedDetailsList.appealedCaseDetailsList =
      appealRelationshipObj.searchAppealedIssueCaseDetailsByAppealCase(
        appealCaseIDTYypeRecordStatusDetails);
    // END, CR00022785

    // BEGIN, CR00081844, RKi
    for (int i = 0; i < appealedDetailsList.appealedCaseDetailsList.dtls
      .size(); i++) {

      if (appealedDetailsList.appealedCaseDetailsList.dtls
        .item(i).appealedCaseType.equals(APPEALEDCASETYPE.HEARING)
        || appealedDetailsList.appealedCaseDetailsList.dtls
          .item(i).appealedCaseType.equals(APPEALEDCASETYPE.HEARINGREVIEW)) {

        caseSearchKey.caseID =
          appealedDetailsList.appealedCaseDetailsList.dtls.item(i).caseID;
        final CaseReference caseReference =
          caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

        appealedDetailsList.appealedCaseDetailsList.dtls
          .item(i).caseReference = caseReference.caseReference;
      }
    }
    // END, CR00081844

    // BEGIN, CR00021313, RKi
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final Count count = new Count();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.caseID;
    count.numberOfRecords = appellantObj
      .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;

    if (count.numberOfRecords > 0) {
      // Appellant details
      ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

      appealCaseKey.caseID = key.caseID;
      readAppellantDetails = readAppellantDetails(appealCaseKey);
      appealedDetailsList.multipleAppellants.appellantName =
        readAppellantDetails.concernRoleNameDetails.concernRoleName;
    }
    // END, CR00021313

    return appealedDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns all the appealed cases for the given appealCaseID
   *
   * @param key
   * The appeal caseID
   *
   * @return The list of appealed case details
   */
  @Override
  public AppealedDetailsList listAppealedCases(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Variables for list maintenance
    final AppealedDetailsList appealedDetailsList = new AppealedDetailsList();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security for read access
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // BEGIN, CR00022302, RKi
    final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
      new AppealCaseIDTYypeRecordStatusDetails();

    appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
    appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
    appealCaseIDTYypeRecordStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
    Count count = new Count();

    // BEGIN, CR00081844, RKi
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // END, CR00081844

    count = appealRelationshipObj.countActiveAppealedIssuesOnAppealCase(
      appealCaseIDTYypeRecordStatusDetails);

    // Search for appeals that are related to this case
    appealCaseID.appealCaseID = key.caseID;
    appealedDetailsList.appealedCaseDetailsList =
      appealRelationshipObj.searchIssueAppealedCaseDetailsByAppealCase(
        appealCaseIDTYypeRecordStatusDetails);

    // BEGIN, CR00081844, RKi
    for (int i = 0; i < appealedDetailsList.appealedCaseDetailsList.dtls
      .size(); i++) {

      if (appealedDetailsList.appealedCaseDetailsList.dtls
        .item(i).appealedCaseType.equals(APPEALEDCASETYPE.HEARING)
        || appealedDetailsList.appealedCaseDetailsList.dtls
          .item(i).appealedCaseType.equals(APPEALEDCASETYPE.HEARINGREVIEW)) {

        caseSearchKey.caseID =
          appealedDetailsList.appealedCaseDetailsList.dtls.item(i).caseID;
        final CaseReference caseReference =
          caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

        appealedDetailsList.appealedCaseDetailsList.dtls
          .item(i).caseReference = caseReference.caseReference;
      }
    }
    // END, CR00081844

    // BEGIN, CR00021313, RKi
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.caseID;
    count.numberOfRecords = appellantObj
      .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;

    if (count.numberOfRecords == 1) {
      // Appellant details
      ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

      appealCaseKey.caseID = key.caseID;
      readAppellantDetails = readAppellantDetails(appealCaseKey);
      appealedDetailsList.multipleAppellants.appellantName =
        readAppellantDetails.concernRoleNameDetails.concernRoleName;
    }
    // END, CR00021313

    return appealedDetailsList;
  }

  // BEGIN, CR00247651, GP
  /**
   * Returns all the appealed cases for the given appealCaseID.
   *
   * @param key
   * contains the appeal caseID.
   *
   * @return The list of appealed case details.
   */
  @Override
  public AppealedCaseDetailsList listAppealedCasesForIC(
    final AppealCaseKey key) throws AppException, InformationalException {

    final AppealedCaseDetailsList appealedDetailsList =
      new AppealedCaseDetailsList();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    Count count = new Count();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // Validate appeal case security for read access.
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
      new AppealCaseIDTYypeRecordStatusDetails();
    ReadSummaryDetails readSummaryDetails;
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    curam.appeal.sl.entity.struct.AppealedCaseDetailsList appealedCaseDetailsList =
      new curam.appeal.sl.entity.struct.AppealedCaseDetailsList();
    AppealedCaseDetails1 appealedCaseDtls;

    appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
    appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
    appealCaseIDTYypeRecordStatusDetails.recordStatus = RECORDSTATUS.NORMAL;

    count = appealRelationshipObj.countActiveAppealedIssuesOnAppealCase(
      appealCaseIDTYypeRecordStatusDetails);

    // Search for appeals that are related to this case.
    appealCaseID.appealCaseID = key.caseID;
    appealedCaseDetailsList =
      appealRelationshipObj.searchIssueAppealedCaseDetailsByAppealCase(
        appealCaseIDTYypeRecordStatusDetails);

    for (final AppealedCaseDetails appealedCaseDetails : appealedCaseDetailsList.dtls
      .items()) {

      // BEGIN, CR00267543, MC
      appealedCaseDtls = new AppealedCaseDetails1();
      // END, CR00267543

      if (appealedCaseDetails.appealedCaseType
        .equals(APPEALEDCASETYPE.HEARING)
        || appealedCaseDetails.appealedCaseType
          .equals(APPEALEDCASETYPE.HEARINGREVIEW)) {

        caseSearchKey.caseID = appealedCaseDetails.caseID;
        final CaseReference caseReference =
          caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

        appealedCaseDetails.caseReference = caseReference.caseReference;
      }
      appealedCaseDtls.assign(appealedCaseDetails);

      readSummaryDetails = new ReadSummaryDetails();

      appealRelationshipKey.appealRelationshipID =
        appealedCaseDetails.appealRelationshipID;
      readSummaryDetails =
        appealRelationshipObj.readSummary(appealRelationshipKey);
      appealedCaseDtls.appealVersionNo = readSummaryDetails.appealVersionNo;
      appealedCaseDtls.caseHeaderVersionNo =
        readSummaryDetails.caseHeaderVersionNo;
      appealedCaseDtls.versionNo = readSummaryDetails.versionNo;
      appealedDetailsList.appealedCaseDetailsList.appealedCaseDetailsList
        .addRef(appealedCaseDtls);
    }

    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.caseID;
    count.numberOfRecords = appellantObj
      .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;

    if (1 == count.numberOfRecords) {

      ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

      appealCaseKey.caseID = key.caseID;
      readAppellantDetails = readAppellantDetails(appealCaseKey);
      appealedDetailsList.multipleAppellants.appellantName =
        readAppellantDetails.concernRoleNameDetails.concernRoleName;
    }

    return appealedDetailsList;
  }

  // END, CR00247651

  // ___________________________________________________________________________
  /**
   * Creates receipt notices for any outstanding appealed cases on the appeal
   * and sets the receipt notice indicator for each appealed case
   *
   * @param key
   * Contains the appeal case ID
   */
  @Override
  public void createOutstandingReceiptNotices(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Variables for Appeal and AppealRelationship entities
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();

    // Variables for Appeal and AppealRelationship structs
    AppealTypeDetails appealTypeDetails;
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final ReceiptNotice receiptNotice = new ReceiptNotice();
    final CreateReceiptNoticeDtls createReceiptNoticeDtls =
      new CreateReceiptNoticeDtls();
    AppealedCaseCountDetails appealedCaseCountDetails;
    final ReceiptNoticeKey receiptNoticeKey = new ReceiptNoticeKey();

    // Appellant business objects
    final curam.appeal.sl.intf.Appellant appellant =
      AppellantFactory.newInstance();

    // Variables for different types of Appeal Case
    final HearingCase hearingCaseObj = HearingCaseFactory.newInstance();
    final HearingReview hearingReviewObj = HearingReviewFactory.newInstance();
    final JudicialReview judicialReviewObj =
      JudicialReviewFactory.newInstance();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Count all appealed cases for which receipt notices have not
    // been generated.
    receiptNoticeKey.appealCaseID = key.caseID;
    appealedCaseCountDetails = appealRelationshipObj
      .countOutstandingReceiptNoticesByAppealCase(receiptNoticeKey);

    if (appealedCaseCountDetails.recordCount > 0) {

      // Generate outstanding documentation
      appealCaseIDKey.caseID = key.caseID;
      appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);
      createReceiptNoticeDtls.appealCaseID = key.caseID;

      if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {
        hearingCaseObj.createReceiptNotice(createReceiptNoticeDtls);
      } else if (appealTypeDetails.appealTypeCode
        .equals(APPEALTYPE.HEARINGREVIEW)) {
        hearingReviewObj.createReceiptNotice(createReceiptNoticeDtls);
      } else {
        judicialReviewObj.createReceiptNotice(createReceiptNoticeDtls);
      }

      // Update the receipt notice indicators
      receiptNotice.receiptNoticeIndicator = true;
      appealRelationshipObj
        .modifyOutstandingReceiptNoticeIndicatorByAppealCase(receiptNoticeKey,
          receiptNotice);
    }
    // BEIGN, CR00066571, RKi
    appellant.acknowledgeReceipts(key);
    // END, CR00066571
  }

  // ___________________________________________________________________________
  /**
   * Removes the relationship links for assessment delivery, product delivery
   * and prior appeal case.
   *
   * @param details
   * The relationship details needed for removal of links.
   */
  @Override
  public void
    removeRelationshipLinks(final RemoveRelationshipLinksDetails details)
      throws AppException, InformationalException {

    // Variables for case management
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
      new CaseRelByCaseIDStatusReasonTypeKey();
    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // Variables for removal details
    final RemoveLinkToAssessmentDeliveryDetails removeLinkToAssessmentDeliveryDetails =
      new RemoveLinkToAssessmentDeliveryDetails();
    final RemoveLinkToProductDeliveryDetails removeLinkToProductDeliveryDetails =
      new RemoveLinkToProductDeliveryDetails();
    final RemoveAppealRelationshipDetails removeAppealRelationshipDetails =
      new RemoveAppealRelationshipDetails();
    String caseEventType;

    // Set the event type code according to the type of appeal
    if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      caseEventType = CASEEVENTTYPE.REMOVEDFROMHEARINGCASE;
    } else if (details.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
      caseEventType = CASEEVENTTYPE.REMOVEDFROMHEARINGREVIEW;
    } else {
      caseEventType = CASEEVENTTYPE.REMOVEDFROMJUDICIALREVIEW;
    }

    // If the appeal is of type assessment delivery then remove links to
    // the assessment delivery and any associated links to product delivery,
    // otherwise just remove the links to product delivery.

    if (details.caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {
      removeLinkToAssessmentDeliveryDetails.caseID = details.caseID;
      removeLinkToAssessmentDeliveryDetails.eventTypeCode = caseEventType;
      removeLinkToAssessmentDelivery(removeLinkToAssessmentDeliveryDetails);

      caseRelByCaseIDStatusReasonTypeKey.caseID = details.caseID;
      caseRelByCaseIDStatusReasonTypeKey.typeCode =
        CASERELATIONSHIPTYPECODE.ASSESSMENTPRODUCT;

      caseRelationshipDtlsList = caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

      if (caseRelationshipDtlsList.dtls.size() > 0) {
        for (int i = 0; i < caseRelationshipDtlsList.dtls.size(); i++) {

          removeLinkToProductDeliveryDetails.caseID =
            caseRelationshipDtlsList.dtls.item(i).relatedCaseID;
          removeLinkToProductDeliveryDetails.eventTypeCode = caseEventType;
          removeLinkToProductDelivery(removeLinkToProductDeliveryDetails);
        }
      }
    } else {
      removeLinkToProductDeliveryDetails.caseID = details.caseID;
      removeLinkToProductDeliveryDetails.eventTypeCode = caseEventType;
      removeLinkToProductDelivery(removeLinkToProductDeliveryDetails);
    }

    // If there was a prior appeal the remove that appeal relationship also

    if (details.priorAppealCaseID != 0) {
      removeAppealRelationshipDetails.eventTypeCode = caseEventType;
      removeAppealRelationshipDetails.priorAppealCaseID =
        details.priorAppealCaseID;
      removeAppealRelationship(removeAppealRelationshipDetails);
    }

  }

  // ___________________________________________________________________________
  /**
   * Removes the relationship links for a prior appeal case
   *
   * @param details
   * Contains the prior appeal case ID and the event type code.
   */
  @Override
  protected void
    removeAppealRelationship(final RemoveAppealRelationshipDetails details)
      throws AppException, InformationalException {

    // Variables for Case Management

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Variables for Appeal Relationship entity

    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealCountDetails appealCountDetails;
    final PriorCaseStatus priorCaseStatus = new PriorCaseStatus();

    // Search for active appeals for the same prior appeal

    priorCaseStatus.priorAppealCaseID = details.priorAppealCaseID;
    appealCountDetails = appealRelationshipObj
      .countActiveAppealByPriorAppealCase(priorCaseStatus);

    // If there are no other active appeals for the same prior appeal case
    // then set the appeal indicator to be false for the prior appeal

    if (appealCountDetails.recordCount == 0) {
      caseHeaderKey.caseID = details.priorAppealCaseID;
      caseAppealIndicatorDetails.appealIndicator = false;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);
    }

    // Add a removal event to this case

    caseEventDtls.caseID = details.priorAppealCaseID;
    caseEventDtls.eventTypeCode = details.eventTypeCode;
    caseEventDtls.caseEventID = curam.util.type.UniqueID.nextUniqueID();
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();

    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Removes the relationship links for a product delivery
   *
   * @param details
   * Contains the case ID and event type code.
   */
  @Override
  protected void removeLinkToProductDelivery(
    final RemoveLinkToProductDeliveryDetails details)
    throws AppException, InformationalException {

    // Variables for Case Management
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Variable for unique ID for adding the case event ID
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Variables for Appeal entity
    final CaseStatus caseStatus = new CaseStatus();

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealCountDetails appealCountDetails = new AppealCountDetails();

    // Search for active appeals on the case being removed
    caseStatus.caseID = details.caseID;
    appealCountDetails =
      appealRelationshipObj.countActiveAppealByCase(caseStatus);

    // If there are no active appeals on this case then
    // set the appeal indicator to false
    if (appealCountDetails.recordCount == 0) {
      caseHeaderKey.caseID = details.caseID;
      caseAppealIndicatorDetails.appealIndicator = false;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);
    }

    // Add a case event for the removal of the product delivery
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.eventTypeCode = details.eventTypeCode;
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();

    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Removes the relationship links for an assessment delivery
   *
   * @param details
   * Contains the case ID and event type code.
   */
  @Override
  protected void removeLinkToAssessmentDelivery(
    final RemoveLinkToAssessmentDeliveryDetails details)
    throws AppException, InformationalException {

    // Variables for Case Management
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new CaseAppealIndicatorDetails();
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Variables for Appeal entity
    final CaseStatus caseStatus = new CaseStatus();

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    AppealCountDetails appealCountDetails = new AppealCountDetails();

    // Search for active appeals on the case being removed
    caseStatus.caseID = details.caseID;
    appealCountDetails =
      appealRelationshipObj.countActiveAppealByCase(caseStatus);

    // If there are no active appeals on this case then
    // set the appeal indicator to false
    if (appealCountDetails.recordCount == 0) {
      caseHeaderKey.caseID = details.caseID;
      caseAppealIndicatorDetails.appealIndicator = false;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);
    }

    // Insert a case event for the removal of the assessment delivery
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.eventTypeCode = details.eventTypeCode;
    caseEventDtls.caseEventID = curam.util.type.UniqueID.nextUniqueID();
    caseEventDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseEventDtls.endDate = curam.util.type.Date.getCurrentDate();

    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates a task for the case owner of the appealed case provided. If the
   * case is an assessment delivery case the task is created for the case owner
   * of the product delivery case associated for the assessment if it exists.
   *
   * @param dtls
   * The details for creating a task for the case owner
   */
  @Override
  public void
    createBenefitTask(final CreateBenefitTaskAppealedCaseDetails dtls)
      throws AppException, InformationalException {

    // Task manipulation variables
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // BEGIN, CR00073648, RKi
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final TaskCreateDetails taskCreateDetails = new TaskCreateDetails();
    // END, CR00073648

    // Subject text for the task
    final StringBuffer subjectText = new StringBuffer();

    if (dtls.caseType.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      // Case relationship object
      final curam.core.intf.CaseRelationship caseRelationshipObj =
        curam.core.fact.CaseRelationshipFactory.newInstance();

      // Case Relationship manipulation variables
      final CaseRelByCaseIDStatusReasonTypeKey caseRelByCaseIDStatusReasonTypeKey =
        new CaseRelByCaseIDStatusReasonTypeKey();
      CaseRelationshipDtlsList caseRelationshipDtlsList;

      caseRelByCaseIDStatusReasonTypeKey.caseID = dtls.caseID;
      caseRelByCaseIDStatusReasonTypeKey.reasonCode =
        CASERELATIONSHIPREASONCODE.LINKEDCASES;
      caseRelByCaseIDStatusReasonTypeKey.statusCode =
        CASERELATIONSHIPSTATUSCODE.DEFAULTCODE;
      caseRelByCaseIDStatusReasonTypeKey.typeCode = dtls.caseType;

      // Get product delivery for the assessment case
      caseRelationshipDtlsList = caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelByCaseIDStatusReasonTypeKey);

      if (caseRelationshipDtlsList.dtls.size() > 0) {

        final CaseRelationshipDtls caseRelationshipDtls =
          caseRelationshipDtlsList.dtls.item(0);

        taskCreateDetails.caseID = caseRelationshipDtls.caseID;

      } else {

        taskCreateDetails.caseID = dtls.caseID;
      }

    } else {

      // Case type is not assessment delivery
      taskCreateDetails.caseID = dtls.caseID;
    }

    // Check for continue benefits indicator
    if (dtls.continueBenefitsIndicator) {

      subjectText.append(curam.message.BPOHEARINGCASE.INF_BENEFIT_CONTINUE_YES
        .getMessageText());
      subjectText.append(CuramConst.gkSpace);

    } else {

      subjectText.append(curam.message.BPOHEARINGCASE.INF_BENEFIT_CONTINUE_NO
        .getMessageText());
      subjectText.append(CuramConst.gkSpace);

    }

    createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;
    createStandardManualTaskDetails.taskDtls.subject = subjectText.toString();

    // BEGIN, CR00073648, RKi

    // BEGIN, CR00246044, GP
    taskCreateDetails.subject = subjectText.toString();
    taskCreateDetails.priority = curam.codetable.TASKPRIORITY.NORMAL;

    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    OrgObjectDetails orgObjectDetails = new OrgObjectDetails();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = dtls.caseID;

    // Retrieve the case owner name.
    orgObjectDetails =
      caseUserRoleObj.listOwnerOrgObjectAndUserDetails(caseHeaderKey);

    final CaseOwnerDetails caseOwnerDetails;

    for (final UserNameKey userNameKey : orgObjectDetails.dtls.dtls.items()) {

      // BEGIN, CR00358131, VT
      taskCreateDetails.assigneeType = TARGETITEMTYPE.USER;
      // END, CR00358131
      taskCreateDetails.assignedTo = userNameKey.userName;

      taskManagement.create(taskCreateDetails);
    }
    // END, CR00246044

    // END, CR00073648

  }

  // BEGIN, CR00267114, ZV
  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case.
   *
   * @param key
   * The appeal case to return the decision.
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #readDecisionAndAttachmentList()}
   */
  @Override
  @Deprecated
  public DecisionDetails readDecision(final AppealCaseKey key)
    throws AppException, InformationalException {

    // Return variable
    final DecisionDetails decisionDetails = new DecisionDetails();

    decisionDetails.assign(readDecisionAndAttachmentList(key));

    return decisionDetails;
  }

  // END, CR00267114

  // ___________________________________________________________________________
  /**
   * Determines the product for the supplied case.
   *
   * @param details
   * The caseID
   * @return The productID of the product for the case
   */
  @Override
  public ProductIDDetails getProductForCase(final CaseIDDetails details)
    throws AppException, InformationalException {

    // BEGIN, HARP 43804, QG
    // Return struct
    final ProductIDDetails productIDDetails = new ProductIDDetails();

    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;

    // CaseRelationship variables
    final CaseRelationship caseRelationshipObj =
      CaseRelationshipFactory.newInstance();
    final CaseRelByCaseIDStatusReasonTypeKey caseRelBYCaseIDStatusReasonTypeKey =
      new CaseRelByCaseIDStatusReasonTypeKey();
    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // ProductDelivery variables
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // Get the case type
    caseKey.caseID = details.caseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Check if the case is an assessment delivery
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      caseRelBYCaseIDStatusReasonTypeKey.caseID = details.caseID;
      caseRelBYCaseIDStatusReasonTypeKey.typeCode =
        CASERELATIONSHIPTYPECODE.ASSESSMENTPRODUCT;
      caseRelBYCaseIDStatusReasonTypeKey.reasonCode =
        CASERELATIONSHIPREASONCODE.LINKEDCASES;
      caseRelBYCaseIDStatusReasonTypeKey.statusCode =
        CASERELATIONSHIPSTATUSCODE.DEFAULTCODE;

      // Get the product delivery for the assessment delivery case
      caseRelationshipDtlsList = caseRelationshipObj
        .searchByCaseIDStatusReasonType(caseRelBYCaseIDStatusReasonTypeKey);

      // If exactly one product delivery then use related case ID
      if (caseRelationshipDtlsList.dtls.size() == 1) {

        productDeliveryKey.caseID =
          caseRelationshipDtlsList.dtls.item(0).relatedCaseID;

      } else {

        productDeliveryKey.caseID = details.caseID;
      }

    } else {
      // AppealRelationship object and structs
      final AppealRelationship appealRelationshipObj =
        AppealRelationshipFactory.newInstance();

      final AppealCaseIDOrProductDeliveryID appealCaseIDOrProductDeliveryID =
        new AppealCaseIDOrProductDeliveryID();
      ProductIDDetailsList productIDDetailsList;

      appealCaseIDOrProductDeliveryID.caseID = details.caseID;
      productIDDetailsList =
        appealRelationshipObj.getProductID(appealCaseIDOrProductDeliveryID);
      if (productIDDetailsList.dtls.size() > 0) {
        productIDDetails.productID =
          productIDDetailsList.dtls.item(0).productID;
      }

    }
    // END, HARP 52163

    return productIDDetails;

    // END, HARP 43804
  }

  // ___________________________________________________________________________
  /**
   * This method determines whether or not the underlying product appeal process
   * configuration for the case stipulate that the case can only be appealed at
   * the first level of appeal or whether the case can be appealed at other
   * levels of appeal.
   *
   * @param details
   * The case selected for appeal and the type of appeal to appeal it
   * to.
   *
   * @return Indicator if case can only be appealed at the first appeal level.
   * Note that a negative value here implies that the case can be
   * appealed at other levels of appeal. Indicator if the case be
   * appealed at the first level at all.
   *
   * @throws InformationalException
   * (BPOAPPEAL.ERR_APPEAL_XFV_APPEALTYPE_NOTALLOWED) if no appeals of
   * that type are possible
   */
  @Override
  public CaseAppealLevelDetails
    resolveAppealLevelForCase(final CaseIDAppealTypeCode details)
      throws AppException, InformationalException {

    // Return details
    final CaseAppealLevelDetails caseAppealLevelDetails =
      new CaseAppealLevelDetails();

    // Appeal business process object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Variables for determining the valid appeal stages for a product
    final ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();
    final ProductAndStartDateAndAppealType productAndStartDateAndAppealType =
      new ProductAndStartDateAndAppealType();
    StageFirstLevelDetailsList stageFirstLevelDetailsList =
      new StageFirstLevelDetailsList();

    // Object to create informational messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Case Header entity
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStartDate caseStartDate;

    // BEGIN, CR00284786, DG
    // BEGIN, CR00289538, DK
    final CaseRelationshipCaseIDKey existingRelationSearchKey =
      new CaseRelationshipCaseIDKey();

    existingRelationSearchKey.caseID = details.caseID;
    final CaseRelationshipDtlsList caseRelationshipDtlsList =
      CaseRelationshipFactory.newInstance()
        .searchByCaseID(existingRelationSearchKey);
    ListAppealCaseDetailsCombined appealCaseDetailsCombined;
    Boolean isPriorAppeal = false;

    // END , CR00288841, CR00289538 , DK
    long relatedCaseID = 0;

    if (caseRelationshipDtlsList.dtls.size() > 0) {

      relatedCaseID = caseRelationshipDtlsList.dtls.item(0).caseID;

    }
    // Get Case Type
    CaseTypeCode caseTypeCode = new CaseTypeCode();

    // BEGIN, CR00284786, DG
    if (relatedCaseID != 0) {
      // Read the case type for the related case.
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = relatedCaseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    } else {
      // Otherwise read the case type for the main case.
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = details.caseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    }
    // END, CR00284786

    // Local variables
    int stageFirstLevelDetailsListSize;
    AppealCaseID appealCaseID;

    // BEGIN, CR00284786, DG
    // if (relatedCaseID != 0) {
    if (relatedCaseID != 0 && isCaseTypeAppealable(caseTypeCode)) {
      // Get the start date for the appeal case
      caseHeaderKey.caseID = details.caseID;
      caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);

      // Determine the appeal stages, and whether or not each stage is the
      // first level of appeal, for the product where an appeal case of
      // the type specified can be created.
      productAndStartDateAndAppealType.appealStageAppealTypeCode =
        details.appealTypeCode;
      productAndStartDateAndAppealType.startDate = caseStartDate.startDate;
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        final CaseIDDetails caseIDDetails = new CaseIDDetails();

        caseIDDetails.caseID = relatedCaseID;
        productAndStartDateAndAppealType.productID =
          appealObj.getProductForCase(caseIDDetails).productID;
        stageFirstLevelDetailsList = productAppealProcessObj
          .listStageFirstLevelForAppealType(productAndStartDateAndAppealType);
      } else {
        long caseTypeID = 0;
        final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
          caseHeaderDAO.get(relatedCaseID);
        final CaseConfiguration adminCaseConfiguration =
          caseHeader.getAdminCaseConfiguration();

        if (adminCaseConfiguration != null) {
          caseTypeID = caseHeader.getAdminCaseConfiguration().getID();
        }
        productAndStartDateAndAppealType.productID = caseTypeID;
        stageFirstLevelDetailsList = AppealableCaseTypeAppealProcessFactory
          .newInstance()
          .listStageFirstLevelForAppealType(productAndStartDateAndAppealType);
      }

      if (stageFirstLevelDetailsList == null) {
        caseAppealLevelDetails.firstLevelInd = true;
        caseAppealLevelDetails.firstLevelOnlyInd = true;
      } else {
        stageFirstLevelDetailsListSize =
          stageFirstLevelDetailsList.stageFirstLevelDetails.size();

        if (stageFirstLevelDetailsListSize > 0) {

          if (stageFirstLevelDetailsListSize == 1) {
            // If there is only one appeal stage for the product
            // then the appeal
            // indicator returned should be set to true only if the
            // appeal stage
            // is the first level of appeal for the product.
            // BEGIN , CR00288841 , CR00289538 , DK
            appealCaseID = new AppealCaseID();
            appealCaseID.caseID = details.caseID;
            appealCaseDetailsCombined = new ListAppealCaseDetailsCombined();
            appealCaseDetailsCombined =
              appealObj.listAppealByCaseCombined(appealCaseID);
            // check if there is already an appeal on the case
            if (appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
              .size() > 0) {
              for (int i =
                0; i < appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
                  .size(); i++) {
                if (!appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
                  .item(i).statusCode.equals(CASESTATUS.CANCELED)) {
                  isPriorAppeal = true;
                }
              }
            }
            if (isPriorAppeal) {
              caseAppealLevelDetails.firstLevelOnlyInd = false;
            } else {
              caseAppealLevelDetails.firstLevelOnlyInd = true;
            }
            caseAppealLevelDetails.firstLevelInd =
              stageFirstLevelDetailsList.stageFirstLevelDetails
                .item(0).firstLevelIndicator;
            // END , CR00288841, CR00289538, DK

          } else {
            // BEGIN , CR00288841 , CR00289538 , DK
            appealCaseID = new AppealCaseID();
            appealCaseID.caseID = details.caseID;
            appealCaseDetailsCombined = new ListAppealCaseDetailsCombined();
            appealCaseDetailsCombined =
              appealObj.listAppealByCaseCombined(appealCaseID);
            // check if there is already an appeal on the case
            if (appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
              .size() > 0) {
              for (int i =
                0; i < appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
                  .size(); i++) {
                if (!appealCaseDetailsCombined.relatedAppealDetailsList.relatedAppealDetails
                  .item(i).statusCode.equals(CASESTATUS.CANCELED)) {
                  isPriorAppeal = true;
                }
              }
            }
            if (isPriorAppeal) {
              caseAppealLevelDetails.firstLevelOnlyInd = false;
            } else {
              caseAppealLevelDetails.firstLevelOnlyInd = true;
            }
            // END , CR00288841, CR00289538, DK

            // Determine if the it is valid to create an appeal of
            // the specified
            // type as the first level of appeal.
            caseAppealLevelDetails.firstLevelInd = false;
            for (int i = 0; i < stageFirstLevelDetailsListSize; i++) {
              if (stageFirstLevelDetailsList.stageFirstLevelDetails
                .item(i).firstLevelIndicator) {
                caseAppealLevelDetails.firstLevelInd = true;
                break;
              }
            }
          }
        } else {
          // Cannot create an appeal of the specified type for the
          // product at
          // any level of appeal.
          caseAppealLevelDetails.firstLevelOnlyInd = false;
          caseAppealLevelDetails.firstLevelInd = false;
        }
      } // END, CR00284786

    } // END, HARP 48199
    else {
      // If no product can be determined (e.g. the case being appealed is
      // a standalone assessment delivery) then default the first level
      // only
      // indicator to false. Also default that the appeal request can be
      // created at the first level of appeal.
      caseAppealLevelDetails.firstLevelOnlyInd = false;
      caseAppealLevelDetails.firstLevelInd = true;
    }
    // END, CR00284786, DG

    // Throw informational exceptions, if any
    informationalManager.failOperation();

    return caseAppealLevelDetails;
  }

  /**
   * Check if a given case type is appealable.
   *
   * @param caseTypeCode
   * The case type code.
   * @return A boolean indicating if a case type is appealable.
   */
  private boolean isCaseTypeAppealable(final CaseTypeCode caseTypeCode) {

    boolean isCaseTypeAppealable = false;

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
      || caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)
      || caseTypeCode.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
      isCaseTypeAppealable = true;
    } else {
      final AppealableCaseType appealableCaseType = appealableCaseTypeMap
        .get(CASETYPECODEEntry.get(caseTypeCode.caseTypeCode));

      if (appealableCaseType != null) {
        isCaseTypeAppealable = true;
      }
    }

    return isCaseTypeAppealable;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of appeals for a case.
   *
   * @param key
   * Unique internal reference number for the case
   *
   * @return List of appeals related to the case
   */
  @Override
  public ListAppealCaseDetails
    listAppealByCase(final curam.appeal.sl.struct.AppealCaseID key)
      throws AppException, InformationalException {

    // Case Security objects
    final CaseSecurity caseSecurityObj = CaseSecurityFactory.newInstance();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();
    SecurityResult securityResult;

    // Users object
    final UsersKey usersKey = new UsersKey();

    // Appeal entity objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealRelatedByCaseKey appealRelatedByCaseKey =
      new AppealRelatedByCaseKey();
    AppealRelatedByCaseDetailsList appealRelatedByCaseDetailsList;

    // Decision entity objects
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionResolutionCodeDetails hearingDecisionResolutionCodeDetails =
      new HearingDecisionResolutionCodeDetails();

    // Case Header entity objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // Appeal details
    RelatedAppealDetails relatedAppealDetails;
    final ListAppealCaseDetails listAppealCaseDetails =
      new ListAppealCaseDetails();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Appellant details
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

    // Get the user name of the current user
    usersKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // Check case security for the specified case
    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;
    securityResult =
      caseSecurityObj.authorize(caseSecurityCheckKey, usersKey);

    // Throw error if the user does not have access to this case
    if (!securityResult.result) {
      throw new AppException(
        curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
    }

    // Search for related appeals
    appealRelatedByCaseKey.caseID = key.caseID;
    appealRelatedByCaseDetailsList =
      appealObj.searchAppealByCase(appealRelatedByCaseKey);

    // BEGIN, CR00021291, RKi
    final Count count = new Count();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // END, CR00021291
    // BEGIN CR00080628,PN
    boolean flagForMulAppellantInd = false;

    // END CR00080628
    for (int i = 0; i < appealRelatedByCaseDetailsList.dtls.size(); ++i) {
      // BEGIN, CR00021291, RKi
      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        appealRelatedByCaseDetailsList.dtls.item(i).ownerOrgObjectLinkID;
      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // END, CR00053295
      appealCaseIDKey.caseID =
        appealRelatedByCaseDetailsList.dtls.item(i).caseID;
      count.numberOfRecords = appellantObj
        .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;

      // storing the list details in separate structs depending on the
      // number of
      // appellants on a case.
      if (count.numberOfRecords > 1) {
        final RelatedAppealMulitpleAppellantDetails appealMulitpleAppellantDetails =
          new RelatedAppealMulitpleAppellantDetails();

        appealMulitpleAppellantDetails
          .assign(appealRelatedByCaseDetailsList.dtls.item(i));
        // BEGIN, CR00081117, RKi
        appealMulitpleAppellantDetails.mulOwnerFullName =
          caseOwnerDetails.userFullName;
        appealMulitpleAppellantDetails.mulOwnerUserName =
          caseOwnerDetails.userName;
        // END, CR00081117
        // BEGIN CR00080628,PN
        flagForMulAppellantInd = true;
        // END CR00080628

        try {

          hearingDecisionCaseKey.caseID =
            appealRelatedByCaseDetailsList.dtls.item(i).caseID;
          hearingDecisionResolutionCodeDetails = hearingDecisionObj
            .readResolutionCodeByCase(hearingDecisionCaseKey);
          appealMulitpleAppellantDetails.mulResolutionCode =
            hearingDecisionResolutionCodeDetails.resolutionCode;

        } catch (final RecordNotFoundException e) {

          appealMulitpleAppellantDetails.mulResolutionCode =
            APPEALCASERESOLUTION.NOTDECIDED;
        }

        listAppealCaseDetails.relatedAppealDetailsList.mulAppellantRelatedAppealDetails
          .addRef(appealMulitpleAppellantDetails);

      } else {
        // Assign details of each related appeal
        relatedAppealDetails = new RelatedAppealDetails();
        relatedAppealDetails
          .assign(appealRelatedByCaseDetailsList.dtls.item(i));
        relatedAppealDetails.ownerFullName = caseOwnerDetails.userFullName;
        relatedAppealDetails.ownerUserName = caseOwnerDetails.userName;

        try {

          hearingDecisionCaseKey.caseID =
            appealRelatedByCaseDetailsList.dtls.item(i).caseID;
          hearingDecisionResolutionCodeDetails = hearingDecisionObj
            .readResolutionCodeByCase(hearingDecisionCaseKey);
          relatedAppealDetails.resolutionCode =
            hearingDecisionResolutionCodeDetails.resolutionCode;

        } catch (final RecordNotFoundException e) {

          relatedAppealDetails.resolutionCode =
            APPEALCASERESOLUTION.NOTDECIDED;
        }

        appealCaseKey.caseID =
          appealRelatedByCaseDetailsList.dtls.item(i).caseID;
        readAppellantDetails = readAppellantDetails(appealCaseKey);
        relatedAppealDetails.appellantCaseParticipantRoleID =
          readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;
        relatedAppealDetails.appellantName =
          readAppellantDetails.concernRoleNameDetails.concernRoleName;

        listAppealCaseDetails.relatedAppealDetailsList.relatedAppealDetails
          .addRef(relatedAppealDetails);

      }
      // END, CR00021291
    }
    // BEGIN CR00080628, PN
    if (flagForMulAppellantInd) {
      // set the flag for multipleAppealents
      listAppealCaseDetails.appellantInd = true;
    }
    // END CR00080628
    // Get parent case details
    caseKey.caseID = key.caseID;
    integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);

    listAppealCaseDetails.appealParentCaseDetails.parentCaseID =
      integratedCaseKey.integratedCaseID;

    // Return details
    return listAppealCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of Appeals for a case, with Appeals with multiple
   * Appellants included in it.
   *
   * @param key
   * Unique internal reference number for the case
   *
   * @return Full list of appeals related to the case, including both appeals
   * with single or multiple appellants.
   */
  @Override
  public ListAppealCaseDetailsCombined listAppealByCaseCombined(
    final AppealCaseID key) throws AppException, InformationalException {

    // Case Security objects
    final CaseSecurity caseSecurityObj = CaseSecurityFactory.newInstance();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();
    SecurityResult securityResult;

    // Users object
    final UsersKey usersKey = new UsersKey();

    // Appeal entity objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();
    final AppealRelatedByCaseKey appealRelatedByCaseKey =
      new AppealRelatedByCaseKey();
    AppealRelatedByCaseDetailsList appealRelatedByCaseDetailsList;

    // Decision entity objects
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    HearingDecisionResolutionCodeDetails hearingDecisionResolutionCodeDetails =
      new HearingDecisionResolutionCodeDetails();

    // Case Header entity objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseID;
    IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // Appeal details
    RelatedAppealDetails relatedAppealDetails;
    final ListAppealCaseDetailsCombined listAppealCaseDetails =
      new ListAppealCaseDetailsCombined();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    final AppealCaseID appealCaseID = new AppealCaseID();

    appealCaseID.caseID = key.caseID;
    final AppealCaseIDCaseID appealCaseIDCaseID = new AppealCaseIDCaseID();

    appealCaseIDCaseID.caseID = key.caseID;

    // Variables for determining the next appeal stage
    final ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();
    final curam.appeal.sl.intf.IssueAppealProcess issueAppealProcessObj =
      IssueAppealProcessFactory.newInstance();
    final curam.appeal.sl.intf.IntegratedCaseAppealProcess icAppealProcessObj =
      IntegratedCaseAppealProcessFactory.newInstance();
    curam.appeal.sl.struct.AppealStageType stageType =
      new curam.appeal.sl.struct.AppealStageType();

    // Appellant details
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

    // Get the user name of the current user
    usersKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // Check case security for the specified case
    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;
    securityResult =
      caseSecurityObj.authorize(caseSecurityCheckKey, usersKey);

    // Throw error if the user does not have access to this case
    if (!securityResult.result) {
      throw new AppException(
        curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
    }

    // Search for related appeals
    appealRelatedByCaseKey.caseID = key.caseID;
    appealRelatedByCaseDetailsList =
      appealObj.searchAppealByCase(appealRelatedByCaseKey);

    final Count count = new Count();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    boolean flagForMulAppellantInd = false;

    for (int i = 0; i < appealRelatedByCaseDetailsList.dtls.size(); ++i) {
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        appealRelatedByCaseDetailsList.dtls.item(i).ownerOrgObjectLinkID;
      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      appealCaseIDKey.caseID =
        appealRelatedByCaseDetailsList.dtls.item(i).caseID;
      count.numberOfRecords = appellantObj
        .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;

      // storing the list details in separate structs depending on the
      // number of
      // appellants on a case.
      // Assign details of each related appeal
      relatedAppealDetails = new RelatedAppealDetails();
      relatedAppealDetails
        .assign(appealRelatedByCaseDetailsList.dtls.item(i));
      relatedAppealDetails.ownerFullName = caseOwnerDetails.userFullName;
      relatedAppealDetails.ownerUserName = caseOwnerDetails.userName;

      try {

        hearingDecisionCaseKey.caseID =
          appealRelatedByCaseDetailsList.dtls.item(i).caseID;
        hearingDecisionResolutionCodeDetails =
          hearingDecisionObj.readResolutionCodeByCase(hearingDecisionCaseKey);
        relatedAppealDetails.resolutionCode =
          hearingDecisionResolutionCodeDetails.resolutionCode;

      } catch (final RecordNotFoundException e) {

        relatedAppealDetails.resolutionCode = APPEALCASERESOLUTION.NOTDECIDED;
      }

      appealCaseKey.caseID =
        appealRelatedByCaseDetailsList.dtls.item(i).caseID;
      readAppellantDetails = readAppellantDetails(appealCaseKey);
      relatedAppealDetails.appellantCaseParticipantRoleID =
        readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;
      // BEGIN , CR00287499, CR00352572 , DK
      // if there is more than one appellant, set the field to display multiple
      // appellants.
      if (count.numberOfRecords > 1) {
        flagForMulAppellantInd = true;
        relatedAppealDetails.appellantName =
          curam.appeal.impl.CuramConst.kMultipleAppellants;
      } else {
        // if the appellant details are empty, then the organization is the
        // appellant
        if (readAppellantDetails.concernRoleNameDetails.concernRoleName
          .equals("")) {
          final AllAppealParticipantsKey appealParticipantsKey =
            new AllAppealParticipantsKey();

          appealParticipantsKey.caseID = relatedAppealDetails.appealCaseID;
          final AppealCaseParticipantTabDetailList participantList = appealObj
            .searchAllAppealParticipantTabDetails(appealParticipantsKey);

          for (int j = 0; j < participantList.dtls.size(); j++) {
            if (participantList.dtls.item(j).caseParticipantTypeCode
              .equals(CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER)) {
              relatedAppealDetails.appellantName =
                participantList.dtls.item(j).concernRoleName;
            }
          }
        } // set the appellant name
        else {
          relatedAppealDetails.appellantName =
            readAppellantDetails.concernRoleNameDetails.concernRoleName;
        }
      }
      // END , CR00287499, CR00352572, DK

      // BEGIN, CR00347052,DK
      // Localisable String for the description
      final LocalisableString localisableString =
        new LocalisableString(APPEALOBJECT.INF_APPEAL_OBJECT_DESCRIPTION);

      localisableString.arg(new CodeTableItemIdentifier(APPEALTYPE.TABLENAME,
        relatedAppealDetails.appealTypeCode));
      localisableString.arg(relatedAppealDetails.appealCaseReference);
      // set the home page
      relatedAppealDetails.appealItemHomePageURI =
        curam.appeal.impl.CuramConst.kCaseHomePageURI
          + relatedAppealDetails.appealCaseID;
      relatedAppealDetails.appealDescription =
        localisableString.toClientFormattedText();
      // set the number of items under appeal for the case
      relatedAppealDetails.itemsUnderAppeal =
        listObjectsByAppealCase(appealCaseKey).dtls.size();
      // Set next stage values for creating subsequent stages
      relatedAppealDetails.nextStageHearing = APPEALSTAGEAPPEALTYPE.HEARING;
      relatedAppealDetails.nextStageHearingReview =
        APPEALSTAGEAPPEALTYPE.HEARINGREVIEW;
      relatedAppealDetails.nextStageJudicialReview =
        APPEALSTAGEAPPEALTYPE.JUDICIALREVIEW;
      // Set the Indicators based on the next appeal stage for that item only if
      // the case status is not canceled
      appealCaseIDCaseID.appealCaseID = relatedAppealDetails.appealCaseID;

      // get the next appeal stage depending on the case type
      CaseTypeCode caseTypeCode = new CaseTypeCode();

      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
        stageType =
          productAppealProcessObj.getNextAppealStage(appealCaseIDCaseID);
      } else {
        stageType = AppealableCaseTypeAppealProcessFactory.newInstance()
          .getNextAppealStage(appealCaseIDCaseID);
      }

      if (!relatedAppealDetails.statusCode.equals(CASESTATUS.CANCELED)) {
        if (stageType.appealStageType.appealStageType
          .equals(APPEALSTAGEAPPEALTYPE.HEARING)) {
          relatedAppealDetails.hearingIndicator = true;
        } else if (stageType.appealStageType.appealStageType
          .equals(APPEALSTAGEAPPEALTYPE.HEARINGREVIEW)) {
          relatedAppealDetails.hearingReviewIndicator = true;
        } else if (stageType.appealStageType.appealStageType
          .equals(APPEALSTAGEAPPEALTYPE.JUDICIALREVIEW)) {
          relatedAppealDetails.judicialIndicator = true;
        } // if appeal type is any, set all to true and set the next stages that
        // can be created
        else if (stageType.appealStageType.appealStageType
          .equals(APPEALSTAGEAPPEALTYPE.ANY)) {
          relatedAppealDetails.hearingIndicator = true;
          relatedAppealDetails.hearingReviewIndicator = true;
          relatedAppealDetails.judicialIndicator = true;
        }
      }
      listAppealCaseDetails.relatedAppealDetailsList.relatedAppealDetails
        .addRef(relatedAppealDetails);

    }
    // END,CR00347052,DK
    if (flagForMulAppellantInd) {
      // set the flag for multipleAppealents
      listAppealCaseDetails.appellantInd = true;
    }

    // Get parent case details
    integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);

    listAppealCaseDetails.appealParentCaseDtls.parentCaseID =
      integratedCaseKey.integratedCaseID;

    // Return details
    return listAppealCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of valid case participants of a specified participant role
   * type for a specified appeal case.
   *
   * @param key
   * Contains the CaseID
   *
   * @return List of valid case participants of a specified type
   */
  @Override
  public AppealParticipantDetailsList
    listCaseParticipantsByParticipantRoleType(final CaseIDDetails key,
      final AppealParticipantRoleTypeCode typeCode)
      throws AppException, InformationalException {

    // Case Participant Details List return object
    final AppealParticipantDetailsList appealParticipantDetailsList =
      new AppealParticipantDetailsList();

    // CaseParticipantRole variables
    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    AppealParticipantDetails appealParticipantDetails;
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    // List of valid type codes for Participant Role Type
    HashSet validTypeCodes = new HashSet();

    // Set valid participant type codes based on the inbound type code
    // specified
    if (CASEPARTICIPANTROLETYPE.APPELLANT
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidAppellantTypeCodes;
    } else if (CASEPARTICIPANTROLETYPE.RESPONDENT
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidRespondentTypeCodes;
    } else if (CASEPARTICIPANTROLETYPE.THIRDPARTY
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidThirdPartyTypeCodes;
    }

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
      .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    // Validate case participant role list adding only validate participants
    // to
    // the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      caseParticipantRoleFullDetails =
        viewCaseParticipantRoleDetailsList.dtls.item(i);

      if (validTypeCodes.contains(caseParticipantRoleFullDetails.typeCode)) {
        if (!caseParticipantRoleFullDetails.recordStatus
          .equals(RECORDSTATUS.CANCELLED)) {
          appealParticipantDetails = new AppealParticipantDetails();
          appealParticipantDetails.assign(caseParticipantRoleFullDetails);
          appealParticipantDetailsList.appealParticipantDetails
            .addRef(appealParticipantDetails);
        }
      }
    }

    return appealParticipantDetailsList;

  }

  // START, CR00424038, DM
  // ___________________________________________________________________________
  /**
   * Returns a list of valid case participants/members of a specified
   * participant role
   * type for a specified appeal case.
   *
   * @param key
   * Contains the CaseID
   *
   * @return List of valid case participants of a specified type
   */
  @Override
  public AppealParticipantDetailsList listCaseMembersByParticipantRoleType(
    final CaseIDDetails key, final AppealParticipantRoleTypeCode typeCode)
    throws AppException, InformationalException {

    // Case Participant Details List return object
    final AppealParticipantDetailsList appealParticipantDetailsList =
      new AppealParticipantDetailsList();

    // CaseParticipantRole variables
    CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails;
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    AppealParticipantDetails appealParticipantDetails;
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    // List of valid type codes for Participant Role Type
    HashSet validTypeCodes = new HashSet();

    // Set valid participant type codes based on the inbound type code
    // specified
    if (CASEPARTICIPANTROLETYPE.APPELLANT
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidAppellantTypeCodes;
      // validTypeCodes.add(CASEPARTICIPANTROLETYPE.MEMBER);
    } else if (CASEPARTICIPANTROLETYPE.RESPONDENT
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidRespondentTypeCodes;
      // validTypeCodes.add(CASEPARTICIPANTROLETYPE.MEMBER);
    } else if (CASEPARTICIPANTROLETYPE.THIRDPARTY
      .equalsIgnoreCase(typeCode.typeCode)) {
      validTypeCodes =
        curam.appeal.sl.impl.ParticipantValidation.stValidThirdPartyTypeCodes;
    }

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj
      .listCaseParticipantsForIC(viewCaseParticipantRole_boKey);

    // get the list of case groups members for this case to return them among
    // the valid appellants/respondents
    // CaseParticipantRoleKey caseParticipantRoleKey = new
    // CaseParticipantRoleKey();
    final CaseGroups cgObj = CaseGroupsFactory.newInstance();
    final CaseGroupsReadmultiKey cgKey = new CaseGroupsReadmultiKey();

    cgKey.caseID = key.caseID;
    final CaseGroupsDtlsList cglist = cgObj.searchByCase(cgKey);

    final int cgSize = cglist.dtls.size();
    final Date currentDate = Date.getCurrentDate();

    // Validate case participant role list adding only validate participants
    // to
    // the return object
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      caseParticipantRoleFullDetails =
        viewCaseParticipantRoleDetailsList.dtls.item(i);

      if (!caseParticipantRoleFullDetails.recordStatus
        .equals(RECORDSTATUS.CANCELLED)
        && caseParticipantRoleFullDetails.endReason.isEmpty()) {
        // we are considering participants with valid type codes to be returned
        // by this method
        if (validTypeCodes
          .contains(caseParticipantRoleFullDetails.typeCode)) {
          appealParticipantDetails = new AppealParticipantDetails();
          appealParticipantDetails.assign(caseParticipantRoleFullDetails);
          appealParticipantDetailsList.appealParticipantDetails
            .addRef(appealParticipantDetails);
        } else if (CASEPARTICIPANTROLETYPE.RESPONDENT
          .equalsIgnoreCase(typeCode.typeCode)
          || CASEPARTICIPANTROLETYPE.APPELLANT
            .equalsIgnoreCase(typeCode.typeCode)) {
          // for appellants/respondents, we are also returning any case group
          // members
          for (int j = 0; j < cgSize; j++) {
            // set key ID to concernRoleID from case group
            final long concernRoleID = cglist.dtls.item(j).concernRoleID;

            if (caseParticipantRoleFullDetails.participantRoleID == concernRoleID
              && (cglist.dtls.item(j).endDate == null
                || cglist.dtls.item(j).endDate.isZero()
                || cglist.dtls.item(j).endDate.after(currentDate))) {
              appealParticipantDetails = new AppealParticipantDetails();
              appealParticipantDetails.assign(caseParticipantRoleFullDetails);
              appealParticipantDetailsList.appealParticipantDetails
                .addRef(appealParticipantDetails);
              break;
            }

          }
        }
      }

    }

    return appealParticipantDetailsList;

  }

  // END, CR00424038

  // ___________________________________________________________________________
  /**
   * This is a utility method which will return the caseID and productID for the
   * specified appeal case. If more than one record exists for the specified
   * appeal case the record with the earliest deadline date is returned.
   *
   * @param details
   * Contains the AppealCaseID
   *
   * @return The productID of the product for the case
   */
  @Override
  public CaseIDProductID getCaseIDAndProductIDForAppealCase(
    final AppealCaseID details) throws AppException, InformationalException {

    // Return struct
    final CaseIDProductID caseIDProductID = new CaseIDProductID();

    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;

    // AppealRelationship variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();
    CaseIDList caseIDList;

    // ProductDelivery variables
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // Get the case type
    caseKey.caseID = details.caseID;
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // Check if the case is an Appeal Case
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

      appealCaseID.appealCaseID = details.caseID;

      // Get a list of all cases which are associated with the specified
      // appeal
      // case.
      caseIDList = appealRelationshipObj.searchCaseIDForAppeal(appealCaseID);

      // Use the first record returned as it is has the earliest deadline
      // date
      if (caseIDList.dtls.size() > 0) {
        productDeliveryKey.caseID = caseIDList.dtls.item(0).caseID;

        // Read the product ID
        final CaseIDDetails caseIDDetails = new CaseIDDetails();

        caseIDDetails.caseID = caseIDList.dtls.item(0).caseID;
        final ProductIDDetails productIDDetails =
          getProductForCase(caseIDDetails);

        // BEGIN, CR00021514, RKi
        caseIDProductID.productID = productIDDetails.productID;
        // END, CR00021514
        caseIDProductID.caseID = productDeliveryKey.caseID;
      }

    }

    return caseIDProductID;
  }

  // BEGIN, CR00021313, RKi
  // ___________________________________________________________________________
  /**
   * This method checks if multiple appellants exists on a particular case.
   *
   * @param key
   * Contains the AppealCaseID
   *
   * @return The boolean value indicating multiple appellants on a particular
   * case.
   */

  @Override
  public MultipleAppellantsOnCaseInd multipleAppellantsIndicatorOnCase(
    final AppealCaseKey key) throws AppException, InformationalException {

    // return struct
    final MultipleAppellantsOnCaseInd multipleAppellantsOnCaseInd =
      new MultipleAppellantsOnCaseInd();

    // required variables
    final Count count = new Count();
    final Appellant appellantObj =
      curam.appeal.sl.entity.fact.AppellantFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = key.caseID;

    // gets the number of appellants on a particular case.
    count.numberOfRecords = appellantObj
      .countActiveAppellantsByAppealCaseID(appealCaseIDKey).numberOfRecords;
    if (count.numberOfRecords > 1) {
      multipleAppellantsOnCaseInd.multipleAppellants = true;
    }

    return multipleAppellantsOnCaseInd;
  }

  // END, CR00021313

  // ___________________________________________________________________________
  /**
   * This method lists all appeals for a specified concern role.
   *
   * @param key
   * The unique concernRoleID.
   *
   * @return AppealsForConcernRoleDtlsList The list of details of the appeals
   */
  @Override
  public AppealsForConcernRoleDtlsList
    listAppealForConcernRole(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Return struct
    final AppealsForConcernRoleDtlsList appealsForConcernRoleDtlsList =
      new AppealsForConcernRoleDtlsList();

    // Security variables
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    SecurityResult caseSecurityResult;
    SecurityResult participantSecurityResult;

    // Retrieve the appeal cases for this concern role
    appealsForConcernRoleDtlsList.dtlsList =
      AppealFactory.newInstance().searchAppealsByConcernRoleID(key);

    // Iterate through the list of records to perform security checks
    for (int i = 0; i < appealsForConcernRoleDtlsList.dtlsList.dtls
      .size(); i++) {

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        appealsForConcernRoleDtlsList.dtlsList.dtls
          .item(i).ownerOrgObjectLinkID;
      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).ownerName =
        caseOwnerDetails.userFullName;

      // END, CR00053295

      // Set the case security check key
      caseSecurityCheckKey.caseID =
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

      // Set the participant security check key
      participantKeyStruct.participantID = key.concernRoleID;

      // Perform the case security check
      caseSecurityResult =
        dataBasedSecurity.checkCaseSecurity(caseSecurityCheckKey);

      // Perform the participant security check
      participantSecurityResult =
        dataBasedSecurity.checkParticipantSecurity(participantKeyStruct);

      // If either result is false, it means the user does not have access
      // to
      // read the appeal case details
      if (!participantSecurityResult.result || !caseSecurityResult.result) {

        // Set details to restricted
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseID = 0;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseReference =
          CuramConst.gkRestricted;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).appealType =
          ISSUECONFIGURATIONTYPE.RESTRICTEDACCESS;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).ownerName =
          CuramConst.gkRestricted;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseStatus =
          CASESTATUS.RESTRICTEDACCESS;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).startDate =
          Date.kZeroDate;
      }
    }

    // Return the appeal case details for the concern role
    return appealsForConcernRoleDtlsList;
  }

  // BEGIN, CR00049829, RKi
  // ___________________________________________________________________________
  /**
   * Method to check if the appeal was submitted in a timely manner. It is
   * timely if the number of days which have elapsed between the issue case
   * approval date and the appeal receipt is not more than the number of days
   * allowed to request an appeal.
   *
   * @param details
   * contains the details issueCaseID,appealCaseID,receivedDate and
   * appealType.
   *
   * @return if the appeal is timely or not.
   */
  @Override
  protected IsTimelyResult
    isIssueAppealTimely(final TimelyIssueCaseDetails details)
      throws AppException, InformationalException {

    // BEGIN, CR00284786, DG
    // Appeal Time Constraint Objects
    int dateDiffInDays = 0;
    String constraintType = "";
    int constraintLength = 0;
    // END, CR00284786

    final IsTimelyResult isTimelyResult = new IsTimelyResult();

    isTimelyResult.timelyInd = true;

    // Issue Delivery Objects
    final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

    issueDeliveryKey.caseID = details.issueCaseID;
    final IssueDelivery issueDelivery = IssueDeliveryFactory.newInstance();

    // Resolution Objects
    final Resolution resolutionObj = ResolutionFactory.newInstance();
    ResolutionStatus resolutionStatus;

    resolutionStatus = issueDelivery.readResolutionStatus(issueDeliveryKey);

    if (!details.receivedDate.isZero() && RESOLUTIONSTATUSCODE.APPROVED
      .equals(resolutionStatus.resolutionStatus)) {

      final ResolutionDtls resolutionDtls =
        resolutionObj.readByCaseID(issueDeliveryKey);

      // Calculate days elapsed between appeal receipt and issue case
      // approval
      // date
      dateDiffInDays =
        details.receivedDate.subtract(resolutionDtls.creationDate);

      // BEGIN, CR00284786, DG
      if (details.appealType.equals(APPEALTYPE.HEARINGREVIEW)) {
        constraintType = CONSTRAINTTYPE.REQUEST_HEARING_REVIEW;
      } else if (details.appealType.equals(APPEALTYPE.HEARING)) {
        constraintType = CONSTRAINTTYPE.REQUEST_HEARING_CASE;
      } else {
        constraintType = CONSTRAINTTYPE.REQUEST_JUDICIAL_REVIEW;
      }

      // read the time constraint set for the issue.
      final CaseIDAppealCaseIDConstraintType caseIDAppealCaseIDConstraintType =
        new CaseIDAppealCaseIDConstraintType();

      caseIDAppealCaseIDConstraintType.appealCaseID = details.appealCaseID;
      caseIDAppealCaseIDConstraintType.caseID = details.issueCaseID;
      caseIDAppealCaseIDConstraintType.constraintType = constraintType;
      constraintLength = getTimeConstraintLength(
        caseIDAppealCaseIDConstraintType).numberOfDays;
      // BEGIN, CR00124472, RKi
      if (constraintLength == 0) {

        final AppException ex =
          new AppException(BPOAPPEALCOMMUNICATION.ERR_CONSTRAINT_INVALID);

        final curam.util.type.CodeTableItemIdentifier constraintTypeCode =
          new curam.util.type.CodeTableItemIdentifier(
            curam.codetable.CONSTRAINTTYPE.TABLENAME, constraintType);

        ex.arg(constraintTypeCode);
        throw ex;
      }
      // END, CR00124472

      // compare the time constraint of the issue to the difference in
      // creating
      // the appeal case to issue approval date
      if (dateDiffInDays > constraintLength) {
        isTimelyResult.timelyInd = false;
      }
      // END, CR00284786

    }
    return isTimelyResult;
  }

  // END, CR00049829

  // BEGIN, CR CR00073917, NSP
  // ___________________________________________________________________________
  /**
   * This method lists all appeals for a specified concern role.
   *
   * @param key
   * The unique concernRoleID.
   *
   * @return AppealsForConcernRoleDtlsList The list of details of the appeals
   */
  public AppealsForConcernRoleDtlsList
    listAppealForEmployerConcernRole(final RelationshipConcernRoleIDKey key)
      throws AppException, InformationalException {

    // Return struct
    final AppealsForConcernRoleDtlsList appealsForConcernRoleDtlsList =
      new AppealsForConcernRoleDtlsList();

    // Security variables
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    SecurityResult caseSecurityResult;
    SecurityResult participantSecurityResult;

    // Retrieve the appeal cases for this concern role
    appealsForConcernRoleDtlsList.dtlsList =
      AppealFactory.newInstance().searchAppealsByConcernRoleID(key);

    // Iterate through the list of records to perform security checks
    for (int i = 0; i < appealsForConcernRoleDtlsList.dtlsList.dtls
      .size(); i++) {

      // BEGIN, CR00053295, RKi
      final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
      CaseOwnerDetails caseOwnerDetails;

      orgObjectLinkKey.orgObjectLinkID =
        appealsForConcernRoleDtlsList.dtlsList.dtls
          .item(i).ownerOrgObjectLinkID;
      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).ownerName =
        caseOwnerDetails.userName;
      // END, CR00053295

      // Set the case security check key
      caseSecurityCheckKey.caseID =
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

      // Set the participant security check key
      participantKeyStruct.participantID = key.concernRoleID;

      // Perform the case security check
      caseSecurityResult =
        dataBasedSecurity.checkCaseSecurity(caseSecurityCheckKey);

      // Perform the participant security check
      participantSecurityResult =
        dataBasedSecurity.checkParticipantSecurity(participantKeyStruct);

      // If either result is false, it means the user does not have access
      // to
      // read the appeal case details
      if (!participantSecurityResult.result || !caseSecurityResult.result) {

        // Set details to restricted
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseID = 0;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseReference =
          CuramConst.gkRestricted;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).appealType =
          ISSUECONFIGURATIONTYPE.RESTRICTEDACCESS;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).ownerName =
          CuramConst.gkRestricted;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).caseStatus =
          CASESTATUS.RESTRICTEDACCESS;
        appealsForConcernRoleDtlsList.dtlsList.dtls.item(i).startDate =
          Date.kZeroDate;
      }
    }
    // Return the appeal case details for the participant role
    return appealsForConcernRoleDtlsList;
  }

  // END, CR CR00073917

  // BEGIN, CR00083140, RKi
  // ___________________________________________________________________________
  /**
   * Method to list all appeal types
   *
   * @return a list of all appeal types
   */
  @Override
  public AppealTypes listAllAppealTypes()
    throws AppException, InformationalException {

    // Return struct
    final AppealTypes appealTypes = new AppealTypes();

    // service layer object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      AppealFactory.newInstance();

    // Get the list of all appeal types
    appealTypes.types = appealObj.searchAllAppealTypes();

    return appealTypes;
  }

  // END, CR00083140

  // BEGIN, CR00267114, ZV
  // ___________________________________________________________________________
  /**
   * Returns the overall decision for an appeal case in addition to the list of
   * appealed cases and their resolutions being considered as part of the appeal
   * case. Returns attachment details list associated to decision.
   *
   * @param key
   * The appeal case to return the decision.
   * @return The overall appeal case decision and the list of appealed cases and
   * their resolutions.
   */
  @Override
  public DecisionAndAttachmentListDetails readDecisionAndAttachmentList(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Variables for AppealRelationship entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    AppealResolutionsList appealResolutionsList;

    // Variables for HearingDecision entity
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    OverallDecisionDetails overallDecisionDetails;

    // Variables for HearingDecisionAttachmentLink entity
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();

    // Appeal decision object and structs
    final curam.appeal.sl.intf.AppealDecision appealDecisionObj =
      AppealDecisionFactory.newInstance();
    curam.appeal.sl.struct.AppealResolutionDetails appealResolutionDetails;

    // Return variable
    final DecisionAndAttachmentListDetails decisionDetails =
      new DecisionAndAttachmentListDetails();

    // Retrieve all appealed cases (active) for the appeal case.
    activeApprovedCaseKey.appealCaseID = key.caseID;
    appealResolutionsList = appealRelationshipObj
      .searchActiveResolutionDetailsByAppealCase(activeApprovedCaseKey);

    // Set appealed cases component of return variable.
    decisionDetails.appealResolutionsList = appealResolutionsList;

    // Get the hearing decision details.
    hearingDecisionCaseKey.caseID = key.caseID;
    try {

      // Set the returned decision details.
      overallDecisionDetails =
        hearingDecisionObj.readOverallDecisionByCase(hearingDecisionCaseKey);
      decisionDetails.decisionID = overallDecisionDetails.hearingDecisionID;
      decisionDetails.decisionStatus = overallDecisionDetails.decisionStatus;
      decisionDetails.decisionVersionNo = overallDecisionDetails.versionNo;

      // Calculate the overall resolution code for the appeal case
      appealResolutionDetails = appealDecisionObj.calculateResolution(key);
      decisionDetails.decisionResolutionCode =
        appealResolutionDetails.resolutionCode;

      // Get decision attachments.
      hearingDecisionKey.hearingDecisionID =
        overallDecisionDetails.hearingDecisionID;
      decisionDetails.activeAttachmentDetailsList =
        hearingDecisionAttachmentLinkObj
          .searchAttachmentsByDecision(hearingDecisionKey);

      for (int i = 0; i < decisionDetails.activeAttachmentDetailsList.dtls
        .size(); i++) {
        decisionDetails.activeAttachmentDetailsList.dtls.item(i).externalInd =
          decisionDetails.activeAttachmentDetailsList.dtls
            .item(i).decisionAttachmentType
              .equals(DECISIONATTACHMENTTYPE.EXTERNAL);
      }
    } catch (final RecordNotFoundException e) {

      // Set default decision details if decision is not found.
      decisionDetails.decisionResolutionCode =
        APPEALCASERESOLUTION.NOTDECIDED;
      decisionDetails.decisionStatus = HEARINGDECISIONSTATUS.NOTSTARTED;

    }
    // BEGIN, CR00022431, LK
    final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
      new AppealCaseIDTYypeRecordStatusDetails();

    appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
    appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
    appealCaseIDTYypeRecordStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
    Count count = new Count();

    count = appealRelationshipObj.countActiveAppealedIssuesOnAppealCase(
      appealCaseIDTYypeRecordStatusDetails);

    // Read CaseHeader
    if (count.numberOfRecords >= 1) {
      final curam.appeal.sl.entity.intf.Appeal appeal =
        AppealFactory.newInstance();

      appealCaseIDTYypeRecordStatusDetails.appealCaseID = key.caseID;
      appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
      decisionDetails.AppealManageDecisionDetailsList =
        appeal.readIssueDeliveryDetails(appealCaseIDTYypeRecordStatusDetails);
    }
    // END, CR00022431, LK
    return decisionDetails;
  }

  // END, CR00267114

  // ___________________________________________________________________________
  /**
   * List all of the appeals for each case that is related to an integrated
   * case.
   *
   * @param key
   * Integrated case identifier.
   * @return A list of appeal cases.
   */
  @Override
  public AppealCaseAllDetailsList listAppealCaseDetailsForIC(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Return object
    final AppealCaseAllDetailsList appealCaseDetailsList =
      new AppealCaseAllDetailsList();

    // Get list of related appeals for the IC
    final AppealCaseID appealCaseID = new AppealCaseID();

    appealCaseID.caseID = key.caseID;
    final ListAppealCaseDetailsCombined listAppealCaseDetails =
      listAppealByCaseCombined(appealCaseID);

    for (final RelatedAppealDetails relatedAppealDetails : listAppealCaseDetails.relatedAppealDetailsList.relatedAppealDetails
      .items()) {
      final AppealCaseAllDetails appealCaseAllDetails =
        new AppealCaseAllDetails();

      // Get description
      final LocalisableString localisableString =
        new LocalisableString(APPEALOBJECT.INF_APPEAL_OBJECT_DESCRIPTION);

      localisableString.arg(new CodeTableItemIdentifier(APPEALTYPE.TABLENAME,
        relatedAppealDetails.appealTypeCode));
      localisableString.arg(relatedAppealDetails.appealCaseReference);

      appealCaseAllDetails.appealItemHomePageURI =
        curam.appeal.impl.CuramConst.kCaseHomePageURI
          + relatedAppealDetails.appealCaseID;

      // Set fields
      appealCaseAllDetails.appealCaseID = relatedAppealDetails.appealCaseID;
      appealCaseAllDetails.appealDescription =
        localisableString.toClientFormattedText();
      appealCaseAllDetails.appellantName = relatedAppealDetails.appellantName;
      appealCaseAllDetails.deadlineDate = relatedAppealDetails.deadlineDate;
      appealCaseAllDetails.ownerFullName = relatedAppealDetails.ownerFullName;
      appealCaseAllDetails.resolutionCode =
        relatedAppealDetails.resolutionCode;
      appealCaseAllDetails.statusCode = relatedAppealDetails.statusCode;
      appealCaseAllDetails.appealTypeCode =
        relatedAppealDetails.appealTypeCode;

      // Add to list
      appealCaseDetailsList.dtls.addRef(appealCaseAllDetails);
    }

    // Get list of cases on the IC
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderReadmultiKey1 caseHeaderReadmultiKey1 =
      new CaseHeaderReadmultiKey1();

    caseHeaderReadmultiKey1.integratedCaseID = key.caseID;
    final CaseHeaderReadmultiDetails1List caseHeaderReadmultiDetails1List =
      caseHeaderObj.searchByIntegratedCaseID(caseHeaderReadmultiKey1);

    // For each case on the IC, get the list of appeals for it
    for (final CaseHeaderReadmultiDetails1 caseHeaderDetails : caseHeaderReadmultiDetails1List.dtls
      .items()) {
      appealCaseID.caseID = caseHeaderDetails.caseID;
      final ListAppealCaseDetailsCombined appealCaseDetails =
        listAppealByCaseCombined(appealCaseID);

      // BEGIN , CR00296215 , DK

      for (final RelatedAppealDetails relatedAppealDetails : appealCaseDetails.relatedAppealDetailsList.relatedAppealDetails
        .items()) {
        if (!checkForDuplicates(appealCaseDetailsList,
          relatedAppealDetails)) {
          final AppealCaseAllDetails appealCaseAllDetails =
            new AppealCaseAllDetails();

          // Get description
          final LocalisableString localisableString =
            new LocalisableString(APPEALOBJECT.INF_APPEAL_OBJECT_DESCRIPTION);

          localisableString.arg(new CodeTableItemIdentifier(
            APPEALTYPE.TABLENAME, relatedAppealDetails.appealTypeCode));
          localisableString.arg(relatedAppealDetails.appealCaseReference);

          appealCaseAllDetails.appealItemHomePageURI =
            curam.appeal.impl.CuramConst.kCaseHomePageURI
              + relatedAppealDetails.appealCaseID;

          // Set fields
          appealCaseAllDetails.appealCaseID =
            relatedAppealDetails.appealCaseID;
          appealCaseAllDetails.appealDescription =
            localisableString.toClientFormattedText();
          appealCaseAllDetails.appellantName =
            relatedAppealDetails.appellantName;
          appealCaseAllDetails.deadlineDate =
            relatedAppealDetails.deadlineDate;
          appealCaseAllDetails.ownerFullName =
            relatedAppealDetails.ownerFullName;
          appealCaseAllDetails.ownerUserName =
            relatedAppealDetails.ownerUserName;
          appealCaseAllDetails.resolutionCode =
            relatedAppealDetails.resolutionCode;
          appealCaseAllDetails.statusCode = relatedAppealDetails.statusCode;
          appealCaseAllDetails.appealTypeCode =
            relatedAppealDetails.appealTypeCode;

          // Add to list
          appealCaseDetailsList.dtls.addRef(appealCaseAllDetails);
        }
      }
      // END , CR00296215 , DK
    }

    // Return output
    return appealCaseDetailsList;

  }

  // BEGIN , CR00296215 , DK
  // ___________________________________________________________________________
  /**
   * check for duplicates from the list of appeals returned. If there is more
   * than one items on the appeal case there can be repeated appeals.
   *
   */
  protected Boolean checkForDuplicates(
    final AppealCaseAllDetailsList appealCaseDetailsList,
    final RelatedAppealDetails relatedAppealDetails) {

    final int appealListSize = appealCaseDetailsList.dtls.size();

    // indicator to see if there is a duplicate

    for (int i = 0; i < appealListSize; i++) {
      if (appealCaseDetailsList.dtls
        .item(i).appealCaseID == relatedAppealDetails.appealCaseID) {
        return true;
      }

    }
    return false;
  }

  // END , CR00296215 , DK

  // ___________________________________________________________________________
  /**
   * List all of the objects on an appeal case.
   *
   * @param key
   * Appeal case identifier
   * @return A list of objects on an appeal case.
   */
  @Override
  public AppealObjectDetailsList listObjectsByAppealCase(
    final AppealCaseKey key) throws AppException, InformationalException {

    // Return object list
    final AppealObjectDetailsList appealObjectDetailsList =
      new AppealObjectDetailsList();

    final AppealObject appealObectObj = AppealObjectFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();

    // get all associated with an appeal case
    // BEGIN , CR00295312, DK
    final AppealCaseStatus appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseStatus();

    appealCaseID.appealCaseID = key.caseID;
    // BEGIN, CR00433101, DG
    appealCaseID.recordStatus = RECORDSTATUS.NORMAL;
    final AppealRelationShipDetailsList appealRelationShipDetailsList =
      appealRelationshipObj.searchByAppealCaseAndStatus(appealCaseID);
    // END, CR00433101

    boolean addToList = true;

    // END , CR00295312, DK

    // BEGIN, CR00425681, DG

    // Create a set to store the cases that have objects associated to them.
    // Each appeal relationship record will point to one related case. However
    // where there are objects under appeal on that case, they will have the
    // same case id.
    // Where objects exists, there will be another entry for the case type on it
    // own (i.e.
    // two appeal relationships records will exist). We only want to return one
    // record in
    // such an instance.
    final Set<Long> caseListWithObjectsSet = new TreeSet<Long>();

    for (final AppealRelationShipDetails appealRelationShipDetails : appealRelationShipDetailsList.dtls
      .items()) {
      // Retrieve the objects for this relationship
      final AppealObjectKeyStruct appealObjectKeyStruct =
        new AppealObjectKeyStruct();

      appealObjectKeyStruct.appealRelationshipID =
        appealRelationShipDetails.appealRelationshipID;
      final AppealObjectDtlsStructList appealObjectDtlsStructList =
        appealObectObj.searchByAppealRelationshipID(appealObjectKeyStruct);

      if (!appealObjectDtlsStructList.dtls.isEmpty()) {
        caseListWithObjectsSet.add(appealRelationShipDetails.caseID);
      }
    }
    // END, CR00425681

    // Iterate through all the appeal relationship records
    for (final AppealRelationShipDetails appealRelationShipDetails : appealRelationShipDetailsList.dtls
      .items()) {

      addToList = true;
      appealRelationshipKey.appealRelationshipID =
        appealRelationShipDetails.appealRelationshipID;

      // Retrieve the objects for this relationship
      final AppealObjectKeyStruct appealObjectKeyStruct =
        new AppealObjectKeyStruct();

      appealObjectKeyStruct.appealRelationshipID =
        appealRelationshipKey.appealRelationshipID;
      final AppealObjectDtlsStructList appealObjectDtlsStructList =
        appealObectObj.searchByAppealRelationshipID(appealObjectKeyStruct);

      final ReadSummaryDetails readSummaryDetails =
        appealRelationshipObj.readSummary(appealRelationshipKey);
      final AppealObjectDetails appealObjectDetails =
        new AppealObjectDetails();

      appealObjectDetails.appealVersionNo =
        readSummaryDetails.appealVersionNo;
      appealObjectDetails.caseHeaderVersionNo =
        readSummaryDetails.caseHeaderVersionNo;
      appealObjectDetails.versionNo = readSummaryDetails.versionNo;
      appealObjectDetails.receiptNoticeIndicator =
        appealRelationShipDetails.receiptNoticeIndicator;
      appealObjectDetails.dateReceived =
        appealRelationShipDetails.receivedDate;
      appealObjectDetails.appealRelationshipID =
        appealRelationShipDetails.appealRelationshipID;
      appealObjectDetails.resolutionCode = appealRelationshipObj
        .readResolution(appealRelationshipKey).resolutionCode;
      appealObjectDetails.statusCode = appealRelationShipDetails.statusCode;
      // BEGIN , CR00289874 , DK
      if (readSummaryDetails.priorAppealCaseID == 0) {
        appealObjectDetails.priorAppealIndicator = false;
      } else {
        appealObjectDetails.priorAppealIndicator = true;
      }
      // END , CR00289874 , DK

      String appealObjectType = CuramConst.gkEmpty;

      // BEGIN, CR00297475, DG
      long objectID = 0;

      // Read the object details for the appeal relationship
      if (!appealObjectDtlsStructList.dtls.isEmpty()) {
        appealObjectType = appealObjectDtlsStructList.dtls.get(0).objectType;
        objectID = appealObjectDtlsStructList.dtls.get(0).objectID;

      }
      // Set the Description and Home Page details
      final Appealable appealableInterface =
        appealableMap.get(APPEALOBJECTTYPEEntry.get(appealObjectType));

      if (appealableInterface != null) {

        appealObjectDetails.appealItemHomePageURI =
          appealableInterface.getHomePageURI(
            APPEALOBJECTTYPEEntry.get(appealObjectType), objectID);
        appealObjectDetails.appealObjectDescription = appealableInterface
          .getAppealObjectDescription(
            APPEALOBJECTTYPEEntry.get(appealObjectType), objectID)
          .toClientFormattedText();
        // END, CR00297475
        appealObjectDetails.appealObectType = appealObjectType;
      } else {

        // No object found so use case type instead

        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = appealRelationShipDetails.caseID;
        final CaseTypeCode caseTypeCode =
          CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

        if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
          final ProductDeliveryKey productDeliveryKey =
            new ProductDeliveryKey();

          productDeliveryKey.caseID = appealRelationShipDetails.caseID;
          appealObjectDetails.appealObectType =
            APPEALOBJECTTYPE.PRODUCTDELIVERY;
        } else if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.ISSUE)) {
          final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

          issueDeliveryKey.caseID = appealRelationShipDetails.caseID;
          appealObjectDetails.appealObectType = APPEALOBJECTTYPE.ISSUE;
        } else {
          addToList = false;
        }

        // BEGIN, CR00419063, DG
        // Create the description string
        final LocalisableString localisableString = new LocalisableString(
          APPEALOBJECT.INF_APPEAL_CASE_OBJECT_DESCRIPTION);

        // Get the case header
        final curam.piwrapper.caseheader.impl.CaseHeader caseHeader =
          caseHeaderDAO.get(appealRelationShipDetails.caseID);

        // Set the Case Name in the description
        localisableString.arg(caseHeader.getAdminCaseConfiguration()
          .getCaseConfigurationName().toString());

        // Set the Case Reference in the description
        localisableString.arg(caseHeader.getCaseReference());

        appealObjectDetails.appealItemHomePageURI =
          curam.appeal.impl.CuramConst.kCaseHomePageURI
            + appealRelationShipDetails.caseID;
        appealObjectDetails.appealObjectDescription =
          localisableString.toClientFormattedText();
        // END, CR00419063

        // BEGIN, CR00425681, DG
        // If this case has related objects, then don't add it to the list
        if (caseListWithObjectsSet
          .contains(appealRelationShipDetails.caseID)) {
          addToList = false;
        }
        // END, CR00425681
      }

      // BEGIN, CR00296737, DG
      if (addToList) {
        appealObjectDetailsList.dtls.addRef(appealObjectDetails);
      }
      // END, CR00296737
    }
    // Return details
    return appealObjectDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * List all of the case types that can be configured for appeals.
   *
   * @return A list of all Products/Integrated Cases/Issues that can be can be
   * configured to be appealed..
   */
  @Override
  public AppealableCasesList listAllAppealableCases()
    throws AppException, InformationalException {

    final Product productObj = ProductFactory.newInstance();
    final AdminIntegratedCase adminIntegratedCaseObj =
      AdminIntegratedCaseFactory.newInstance();
    final IssueConfiguration issueConfigurationObj =
      IssueConfigurationFactory.newInstance();

    // Return struct
    final AppealableCasesList appealableCasesList = new AppealableCasesList();

    // List Products
    final AppealableProductsList appealableProductsList =
      productObj.searchAppealableProducts();

    for (final AppealableProducts p : appealableProductsList.dtls) {
      final AppealableCases appealableCases = new AppealableCases();

      appealableCases.caseID = p.productID;
      appealableCases.caseType = CASETYPECODE.PRODUCTDELIVERY;

      // Add the struct to return list
      appealableCasesList.dtls.add(appealableCases);
    }

    // List Integrated Cases
    final AppealableIntegratedCasesList appealableIntegratedCasesList =
      adminIntegratedCaseObj.searchAppealableCases();

    for (final AppealableIntegratedCases a : appealableIntegratedCasesList.dtls) {
      final AppealableCases appealableCases = new AppealableCases();

      appealableCases.caseID = a.adminIntegratedCaseID;
      appealableCases.caseType = CASETYPECODE.INTEGRATEDCASE;

      // Add the struct to return list
      appealableCasesList.dtls.add(appealableCases);
    }

    // List Issue Cases
    final AppealableIssuesList appealableIssuesList =
      issueConfigurationObj.searchAppealableIssues();

    for (final AppealableIssues i : appealableIssuesList.dtls) {
      final AppealableCases appealableCases = new AppealableCases();

      appealableCases.caseID = i.issueConfigurationID;
      appealableCases.caseType = CASETYPECODE.ISSUE;

      // Add the struct to return list
      appealableCasesList.dtls.add(appealableCases);
    }

    // BEGIN, CR00355362, DG
    // For all other case types which have implemented the Appealable Case
    // Type interface

    for (final Entry<CASETYPECODEEntry, AppealableCaseType> appealableCaseType : appealableCaseTypeMap
      .entrySet()) {

      // BEGIN, CR00432134, DG
      // Only check for unknown case types. We have already checked for PD,
      // Issue and IC.
      if (!(CASETYPECODEEntry.PRODUCTDELIVERY.getCode()
        .equals(appealableCaseType.getKey().getCode())
        || CASETYPECODEEntry.ISSUE
          .equals(appealableCaseType.getKey().getCode())
        || CASETYPECODEEntry.INTEGRATEDCASE
          .equals(appealableCaseType.getKey().getCode()))) {

        for (final AppealableCaseTypeDetails appealableCaseTypeItem : appealableCaseType
          .getValue().listAppealableCaseDetails().dtls) {

          // Get the list of appeal case type ID for this case type
          // AppealableCases
          final AppealableCases appealableCases = new AppealableCases();

          appealableCases.caseID = appealableCaseTypeItem.caseTypeID;
          appealableCases.caseType = appealableCaseType.getKey().getCode();

          // Add the struct to return list
          appealableCasesList.dtls.add(appealableCases);
        }
      }
      // END, CR00432134
    }
    // END, CR00355362

    return appealableCasesList;
  }

  // BEGIN ,CR00284371 , DK
  // ___________________________________________________________________________
  /**
   * List all of the related items on an appeal case.
   *
   * @param key
   * Appeal case identifier
   * @return A list of related items on an appeal case.
   */
  @Override
  public AppealAllRelatedDetailsList listAllRelatedByAppealCase(
    final AppealCaseKey key) throws AppException, InformationalException {

    // return struct
    final AppealAllRelatedDetailsList appealAllRelatedDetailsList =
      new AppealAllRelatedDetailsList();

    // list of appeal objects
    AppealObjectDetailsList appealObjectDetailsList =
      new AppealObjectDetailsList();

    appealObjectDetailsList = listObjectsByAppealCase(key);

    // loop through appeal objects and add them to the return list
    for (final AppealObjectDetails appealObjectDetails : appealObjectDetailsList.dtls
      .items()) {

      final AppealAllRelatedDetails appealAllRelatedDetails =
        new AppealAllRelatedDetails();

      appealAllRelatedDetails.assign(appealObjectDetails);
      // BEGIN , CR00289874 , DK
      appealAllRelatedDetails.issueIndicator = false;
      if (appealAllRelatedDetails.appealObectType
        .equals(APPEALOBJECTTYPE.ISSUE)) {
        appealAllRelatedDetails.issueIndicator = true;
      }
      appealAllRelatedDetailsList.dtls.addRef(appealAllRelatedDetails);
    }

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // initialize indicators to false
    appealAllRelatedDetailsList.appealStatusIndicator = false;
    appealAllRelatedDetailsList.hearingStatusIndicator = false;
    appealAllRelatedDetailsList.submittedIndicator = false;
    // set the submitted indicator if the appeal decision has been submitted
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    appealCaseKey.caseID = key.caseID;
    final DecisionAndAttachmentListDetails appealCaseDetails =
      appealObj.readDecisionAndAttachmentList(appealCaseKey);

    if (appealCaseDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.SUBMITTED)
      || appealCaseDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.APPROVED)
      || appealCaseDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.REJECTED)
      || appealCaseDetails.decisionStatus
        .equals(HEARINGDECISIONSTATUS.NOTSTARTED)) {
      appealAllRelatedDetailsList.decisionIndicator = false;
    } else {
      appealAllRelatedDetailsList.decisionIndicator = true;
    }

    if (appealCaseDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {
      appealAllRelatedDetailsList.submittedIndicator = true;
    }

    // set the appeal status indicator if the status is active and the
    // hearing
    // decision has not been submitted
    if (appealObj.readAppealDetails(key).appealReadSummaryDetails.statusCode
      .equals(CASESTATUS.ACTIVE)
      && appealAllRelatedDetailsList.submittedIndicator == false) {
      appealAllRelatedDetailsList.appealStatusIndicator = true;
    }
    // hearing key and hearing case details
    final HearingKey hearingKey = new HearingKey();
    final HearingCaseID hearingCaseID = new HearingCaseID();

    hearingCaseID.caseID = key.caseID;
    final HearingCaseHearingDetailsList hearingCaseHearingDetailsList =
      HearingCaseFactory.newInstance().listHearings(hearingCaseID);

    // loop through the hearing list and check that they are completed
    for (int i =
      0; i < hearingCaseHearingDetailsList.HearingCaseHearingDetails
        .size(); i++) {
      hearingKey.hearingKey.hearingID =
        hearingCaseHearingDetailsList.HearingCaseHearingDetails
          .item(i).hearingID;
      if (HearingFactory.newInstance()
        .getReviewSummaryDetails(hearingKey).typeCode
          .equals(HEARINGTYPE.HEARINGREVIEW)) {
        if (HearingFactory.newInstance()
          .getReviewSummaryDetails(hearingKey).statusCode
            .equals(HEARINGSTATUS.COMPLETED)
          && appealAllRelatedDetailsList.appealStatusIndicator == true
          && appealAllRelatedDetailsList.submittedIndicator == false) {
          appealAllRelatedDetailsList.hearingStatusIndicator = true;
        }
      } else if (HearingFactory.newInstance()
        .getSummaryDetails(hearingKey).statusCode
          .equals(HEARINGSTATUS.COMPLETED)
        && appealAllRelatedDetailsList.appealStatusIndicator == true
        && appealAllRelatedDetailsList.submittedIndicator == false) {
        appealAllRelatedDetailsList.hearingStatusIndicator = true;
      }
    }

    // judicial review check
    final ReadAppealDetails appealDetails =
      appealObj.readAppealDetails(appealCaseKey);

    if (appealDetails.appealReadSummaryDetails.appealTypeCode
      .equals(APPEALTYPE.JUDICIALREVIEW)) {
      appealAllRelatedDetailsList.hearingStatusIndicator = true;
    }

    // END , CR00289874 , DK
    // return list
    return appealAllRelatedDetailsList;
  }

  // END , CR00284371 , DK

  /**
   * Add a list of appeal objects to an existing appeals case.
   *
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "1001,AOT1|2001,AOT2|2002,AOT2" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   *
   * @param details
   * Details of the appeal objects to add to an appeals case.
   */
  @Override
  public void addAppealObjectsToCase(final AddAppealObjectsDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Get the object list
    final StringList objectsList = StringUtil.delimitedText2StringList(
      details.appealObjectsDelimitedList, CuramConst.gkPipeDelimiterChar);

    final AppealObject appealObjectObj = AppealObjectFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealObject appealObject = AppealObjectFactory.newInstance();
    final AppealObjectKeyStruct appealObjectKeyStruct =
      new AppealObjectKeyStruct();
    long objectID = 0;
    String objectType;

    // Validate we have at least one object
    if (objectsList.size() == 0) {
      throw new AppException(BPOAPPEAL.ERR_APPEAL_FV_OBJECT_MISSING);
    }

    // BEGIN, CR00297475, DG
    // Get the caseID
    if (details.caseID == 0) {
      // Read the appeal case header
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = details.appealCaseID;
      details.caseID = CaseHeaderFactory.newInstance()
        .readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;
    }
    // END, CR00297475

    // Get the previous appeal case identifier
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    appealCaseID.appealCaseID = details.appealCaseID;
    final AppealRelationShipDetailsList appealRelationShipDetailsList =
      appealRelationshipObj.searchByAppealCase(appealCaseID);
    long priorAppealCaseID = 0;

    for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
      if (o.caseID == details.caseID) {
        priorAppealCaseID = o.priorAppealCaseID;
        break;
      }
    }

    // Get the deadline date
    final CalculateAppealDeadlineDateDetails1 calculateAppealDeadlineDateDetails1 =
      new CalculateAppealDeadlineDateDetails1();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    appealCaseIDKey.caseID = details.appealCaseID;
    calculateAppealDeadlineDateDetails1.appealTypeCode = AppealFactory
      .newInstance().readAppealTypeByCase(appealCaseIDKey).appealTypeCode;
    calculateAppealDeadlineDateDetails1.implCaseID = details.caseID;
    calculateAppealDeadlineDateDetails1.receivedDate = details.dateReceived;
    calculateAppealDeadlineDateDetails1.appealCaseID = details.appealCaseID;
    final Date deadlineDate = AppealedCaseFactory.newInstance()
      .calculateDeadlineDate1(calculateAppealDeadlineDateDetails1).date;

    // Get the list of appeal relationship records for the previous appeal
    // case
    final AppealCaseStatus appealCaseStatus = new AppealCaseStatus();

    appealCaseStatus.appealCaseID = priorAppealCaseID;
    appealCaseStatus.recordStatus = RECORDSTATUS.NORMAL;
    final AppealRelationShipDetailsList prevAppealRelationshipList =
      appealRelationshipObj.searchByAppealCaseAndStatus(appealCaseStatus);

    // Iterate though the list of appeals object that are to be added
    // to the appeals case. Each appeal object must have completed the
    // previous
    // stage in the appeal process. Otherwise an exception is thrown.
    for (final String object : objectsList.items()) {
      final StringList objectDetails = StringUtil
        .delimitedText2StringList(object, CuramConst.gkCommaDelimiterChar);

      // Each entry should have two elements: objectID and objectType
      if (objectDetails.size() != 2) {
        throw new AppException(
          BPOAPPEAL.ERR_APPEAL_FV_INVALID_OBJECT_DETAILS);
      } else {

        // Get the object identifier and type
        objectID = new Long(objectDetails.get(0));
        objectType = objectDetails.get(1);

        // Validate that this object has completed the previous stage in
        // the
        // appeal process.
        boolean objectCompletedPrevStageInd = false;

        if (prevAppealRelationshipList.dtls.size() == 0) {
          objectCompletedPrevStageInd = true;
        } else {

          for (final AppealRelationShipDetails appealRelationshipDetails : prevAppealRelationshipList.dtls) {

            // Get the list of appeal objects associated with this
            // appeal
            // relationship record
            appealObjectKeyStruct.appealRelationshipID =
              appealRelationshipDetails.appealRelationshipID;
            final AppealObjectDtlsStructList appealObjectDtlsList =
              appealObject
                .searchByAppealRelationshipID(appealObjectKeyStruct);

            // Check if the appeal object was associated with any
            // item on this
            // list
            for (final AppealObjectDtlsStruct appealObjectDetails : appealObjectDtlsList.dtls) {
              if (appealObjectDetails.objectID == objectID
                && appealObjectDetails.objectType.equals(objectType)) {
                objectCompletedPrevStageInd = true;
                break;
              }
            }
          }
        }

        if (!objectCompletedPrevStageInd) {
          final AppException ex = new AppException(
            BPOAPPEAL.ERR_APPEAL_XRV_OBJECT_PREVIOUS_STAGE_NOT_COMPLETE);

          ex.arg(new CodeTableItemIdentifier(
            curam.codetable.APPEALOBJECTTYPE.TABLENAME, objectType));
          informationalManager.addInformationalMsg(ex, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
        } else {
          // Create a new appeal relationship for this object
          final AppealRelationshipDtls appealRelationshipDtls =
            new AppealRelationshipDtls();

          appealRelationshipDtls.appealCaseID = details.appealCaseID;
          appealRelationshipDtls.comments = details.comments;
          appealRelationshipDtls.continueBenefitsIndicator =
            details.continueBenefitsIndicator;
          appealRelationshipDtls.receivedDate = details.dateReceived;
          appealRelationshipDtls.registrationDate = Date.getCurrentDate();
          appealRelationshipDtls.emergencyCode = details.emergencyCode;
          appealRelationshipDtls.reasonCode = details.reasonCode;
          appealRelationshipDtls.receiptMethod = details.receiptMethod;
          appealRelationshipDtls.receiptNoticeIndicator =
            details.receiptNoticeIndicator;
          appealRelationshipDtls.appealedDecisionDate = details.effectiveDate;
          appealRelationshipDtls.recordStatus = RECORDSTATUS.NORMAL;
          appealRelationshipDtls.caseID = details.caseID;
          appealRelationshipDtls.statusCode =
            APPEALRELATIONSHIPSTATUS.DEFAULTCODE;
          appealRelationshipDtls.resolutionCode =
            HEARINGDECISIONRESOLUTION.NOTDECIDED;
          appealRelationshipDtls.timelyIndicator = true;
          appealRelationshipDtls.priorAppealCaseID = priorAppealCaseID;
          appealRelationshipDtls.deadlineDate = deadlineDate;
          appealRelationshipObj.insert(appealRelationshipDtls);

          // Create an AppealObject Record
          final AppealObjectDtls appealObjectDtls = new AppealObjectDtls();

          appealObjectDtls.appealRelationshipID =
            appealRelationshipDtls.appealRelationshipID;
          appealObjectDtls.objectID = objectID;
          appealObjectDtls.objectType = objectType;
          appealObjectObj.insert(appealObjectDtls);
        }
      }
    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  /**
   * Reads the appeal details required for the create appeal screen
   *
   * @param caseIDPriorAppealID
   * The case ID of the case the appeal is created and an optional
   * prior appeal case ID if creating appeals for subsequent stages.
   *
   * @return The details required for creating an appeal.
   */
  @Override
  public ReadForCreateAppealDetails
    readForCreateAppeal(final CaseIDPriorAppealID caseIDPriorAppealID)
      throws AppException, InformationalException {

    // Return Struct
    final ReadForCreateAppealDetails readForCreateAppealDetails =
      new ReadForCreateAppealDetails();

    readForCreateAppealDetails.priorAppealID =
      caseIDPriorAppealID.priorAppealID;

    // case id and appeal case ID.Set appeal case ID to the prior appeal case ID
    final AppealCaseIDCaseID appealCaseIDCaseID = new AppealCaseIDCaseID();

    appealCaseIDCaseID.caseID = caseIDPriorAppealID.caseID;
    appealCaseIDCaseID.appealCaseID =
      readForCreateAppealDetails.priorAppealID;

    // Case Header entity
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // Get Case Type
    caseKey.caseID = caseIDPriorAppealID.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // BEGIN, CR00346500, DG
    // String to put the stage number beside the appeal type
    final LocalisableString appealStageDescription =
      new LocalisableString(APPEALSTAGE.INF_APPEAL_STAGE);

    // Get the next stage for this appeal
    OrderedAppealStage nextAppealStageDetails = null;

    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
      nextAppealStageDetails = ProductAppealProcessFactory.newInstance()
        .getNextAppealStageDetails(appealCaseIDCaseID);
    } else {
      nextAppealStageDetails = AppealableCaseTypeAppealProcessFactory
        .newInstance().getNextAppealStageDetails(appealCaseIDCaseID);
    }
    // If the appeal type is passed in, set it
    if (!(caseIDPriorAppealID.appealType.length() == 0)) {
      readForCreateAppealDetails.appealType = caseIDPriorAppealID.appealType;
    } // else get the next stage from the appeal process configuration
    else {
      readForCreateAppealDetails.appealType =
        nextAppealStageDetails.appealTypeCode;
    }

    // Setup the message
    appealStageDescription.arg(CodeTable.getOneItem(
      APPEALSTAGEAPPEALTYPE.TABLENAME, readForCreateAppealDetails.appealType,
      TransactionInfo.getProgramLocale()));
    appealStageDescription.arg(nextAppealStageDetails.stageSequence);

    // Create the return string
    readForCreateAppealDetails.appealStageNumber =
      appealStageDescription.toClientFormattedText();

    // END, CR00346500

    // if the stage is configured to any, set the anyIndicator to true
    if (readForCreateAppealDetails.appealType
      .equals(APPEALSTAGEAPPEALTYPE.ANY)) {
      readForCreateAppealDetails.anyIndicator = true;
    }

    // BEGIN, CR00433101, DG
    // Set the "Continue Benefits" indicator. This is used to decide if the
    // option to set
    // continue benefits is visible on the client screen
    final AppealableCaseType appealableCaseType = appealableCaseTypeMap
      .get(CASETYPECODEEntry.get(caseTypeCode.caseTypeCode));

    if (appealableCaseType != null) {
      final CaseID caseID = new CaseID();

      caseID.caseID = caseIDPriorAppealID.caseID;
      readForCreateAppealDetails.benefitsIndicator =
        appealableCaseType.isContinueBenefitsEnabled(caseID);
    } else {
      readForCreateAppealDetails.benefitsIndicator = true;
    }
    // END, CR00433101

    return readForCreateAppealDetails;
  }

  /**
   * Create an appeal of type Hearing, Hearing Review or Judicial review
   * depending on what stage the appeal is in
   *
   * @param details
   * The details of the appeal being created.
   *
   * @return The appeal case ID
   */
  @Override
  public AppealCaseKey createAppeal(final CreateAppealDetails details)
    throws AppException, InformationalException {

    // return Struct
    final AppealCaseKey key = new AppealCaseKey();
    // Enter Appellant and respondent details
    final curam.appeal.sl.struct.AppellantAndRespondentDetails appellantAndRespondentDetails =
      new curam.appeal.sl.struct.AppellantAndRespondentDetails();

    appellantAndRespondentDetails.assign(details.appAndResDetails);

    AppellantAndRespondentReturnDetails appellantAndRespondentReturnDetails =
      new AppellantAndRespondentReturnDetails();

    appellantAndRespondentReturnDetails =
      enterAppellantAndRespondent(appellantAndRespondentDetails);
    // if the appeal type is a hearing, then we have to call the
    // createWithAppealObjects method in hearing
    if (details.appealType.equals(APPEALTYPE.HEARING)) {
      HearingCaseSummaryKey summaryKey = new HearingCaseSummaryKey();
      final CreateHearingAndAppealObjectsDetails createHearingAndAppealObjectsDetails =
        new CreateHearingAndAppealObjectsDetails();

      createHearingAndAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.addAppealedCaseInputDetails
        .assign(details);
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.difficultyCode =
        details.difficultyTypeCode;
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appealCaseCreateDetails.appellantTypeCode =
        appellantAndRespondentReturnDetails.appellantTypeCode;
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appealCaseCreateDetails.caseID =
        details.appAndResDetails.implCaseID;

      // Get parent case details
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();
      IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      caseKey.caseID = details.appAndResDetails.implCaseID;
      integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appealCaseCreateDetails.parentCaseID =
        integratedCaseKey.integratedCaseID;
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appealCaseCreateDetails.participantRoleID =
        appellantAndRespondentReturnDetails.participantRoleID;
      createHearingAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appealCaseCreateDetails.priorAppealCaseID =
        details.appAndResDetails.priorAppealCaseID;

      summaryKey = curam.appeal.facade.fact.HearingCaseFactory.newInstance()
        .createWithAppealObjects(createHearingAndAppealObjectsDetails);
      key.caseID = summaryKey.hearingCaseSummaryKey.hearingCaseID;

    } // if the appeal type is a hearing review, then we have to call the
    // createWithAppealObjects method in hearing review
    else if (details.appealType.equals(APPEALTYPE.HEARINGREVIEW)) {
      HearingReviewCaseIDKey summaryKey = new HearingReviewCaseIDKey();
      final CreateHearingReviewAndAppealObjectsDetails createHearingReviewAndAppealObjectsDetails =
        new CreateHearingReviewAndAppealObjectsDetails();

      createHearingReviewAndAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      createHearingReviewAndAppealObjectsDetails.dtls.addAppealedCaseInputDetails
        .assign(details);

      createHearingReviewAndAppealObjectsDetails.dtls.difficultyCode =
        details.difficultyTypeCode;
      createHearingReviewAndAppealObjectsDetails.dtls.appealCaseCreateDetails.appellantTypeCode =
        appellantAndRespondentReturnDetails.appellantTypeCode;
      createHearingReviewAndAppealObjectsDetails.dtls.appealCaseCreateDetails.caseID =
        details.appAndResDetails.implCaseID;
      // Get parent case details
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();
      IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      caseKey.caseID = details.appAndResDetails.implCaseID;
      integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);
      createHearingReviewAndAppealObjectsDetails.dtls.appealCaseCreateDetails.parentCaseID =
        integratedCaseKey.integratedCaseID;
      createHearingReviewAndAppealObjectsDetails.dtls.appealCaseCreateDetails.participantRoleID =
        appellantAndRespondentReturnDetails.participantRoleID;
      createHearingReviewAndAppealObjectsDetails.dtls.appealCaseCreateDetails.priorAppealCaseID =
        details.appAndResDetails.priorAppealCaseID;
      summaryKey = curam.appeal.facade.fact.HearingReviewFactory.newInstance()
        .createWithAppealObjects(createHearingReviewAndAppealObjectsDetails);
      key.caseID = summaryKey.key.caseID;

    } // else the appeal type must be judicial review, then we have to call the
    // createWithObjects method in judicial review
    else {
      JudicialReviewCaseKey_fo summaryKey = new JudicialReviewCaseKey_fo();
      final CreateJudicialReviewAndAppealObjectsDetails createJudicialReviewAndAppealObjectsDetails =
        new CreateJudicialReviewAndAppealObjectsDetails();

      createJudicialReviewAndAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      createJudicialReviewAndAppealObjectsDetails.dtls.addAppealedCaseInputDetails
        .assign(details);
      createJudicialReviewAndAppealObjectsDetails.dtls.difficultyTypeCode =
        details.difficultyTypeCode;
      createJudicialReviewAndAppealObjectsDetails.dtls.appealCreateCaseDetails.appellantTypeCode =
        appellantAndRespondentReturnDetails.appellantTypeCode;
      createJudicialReviewAndAppealObjectsDetails.dtls.appealCreateCaseDetails.caseID =
        details.appAndResDetails.implCaseID;
      // Get parent case details
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();
      IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      caseKey.caseID = details.appAndResDetails.implCaseID;
      integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey);
      createJudicialReviewAndAppealObjectsDetails.dtls.appealCreateCaseDetails.parentCaseID =
        integratedCaseKey.integratedCaseID;
      createJudicialReviewAndAppealObjectsDetails.dtls.appealCreateCaseDetails.participantRoleID =
        appellantAndRespondentReturnDetails.participantRoleID;
      createJudicialReviewAndAppealObjectsDetails.dtls.appealCreateCaseDetails.priorAppealCaseID =
        details.appAndResDetails.priorAppealCaseID;
      summaryKey =
        curam.appeal.facade.fact.JudicialReviewFactory.newInstance()
          .createWithObjects(createJudicialReviewAndAppealObjectsDetails);
      key.caseID = summaryKey.judicialReviewCaseKey.caseID;
    }

    // START, CR00424946, DM
    // now we need to trigger the event announcing an appeal case creation for
    // the purpose of UA messaging handling
    appealEvents.sendOnlineAppealRequestAcceptedEvent(
      appellantAndRespondentReturnDetails.participantRoleID);
    // END, CR00424946

    return key;
  }

  /**
   * This method checks if the specified appeals object is currently active
   * on an appeals case.
   *
   * @param key Appeal object specified identifiers.
   *
   * @return Boolean result to determine if object is active on appeals case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AppealObjectActiveCaseInd
    isObjectOnActiveAppealsCase(final AppealObjectKeyStruct1 key)
      throws AppException, InformationalException {

    // Return details
    final AppealObjectActiveCaseInd appealObjectActiveCaseInd =
      new AppealObjectActiveCaseInd();

    // Appeal Relationship business manipulation objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // Appeal Object business manipulation objects
    final AppealObject appealObjectObj = AppealObjectFactory.newInstance();
    final AppealObjectKeyStruct1 appealObjectKey =
      new AppealObjectKeyStruct1();
    AppealObjectDtlsStruct1List appealObjectList =
      new AppealObjectDtlsStruct1List();

    appealObjectActiveCaseInd.result = false;

    // Get the list of appeal object records
    appealObjectKey.objectID = key.objectID;
    appealObjectKey.objectType = key.objectType;

    appealObjectList =
      appealObjectObj.searchByObjectTypeObjectID(appealObjectKey);

    // For item in the appeal object list, check its corresponding
    // appeal relationship record.
    for (final AppealObjectDtlsStruct1 objectDtls : appealObjectList.dtls
      .items()) {

      // Read the appeal relationship details for the current object
      appealRelationshipKey.appealRelationshipID =
        objectDtls.appealRelationshipID;
      final AppealRelationshipDtls appealRelationshipDtls =
        appealRelationshipObj.read(appealRelationshipKey);

      // Check if relationship is active
      if (!appealRelationshipDtls.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.APPROVED)
        && !appealRelationshipDtls.statusCode
          .equals(APPEALRELATIONSHIPSTATUS.REJECTED)
        && appealRelationshipDtls.recordStatus.equals(RECORDSTATUS.NORMAL)) {

        // Check if the appeal Case is active
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = appealRelationshipDtls.appealCaseID;

        final CaseStatusCode appealCaseStatus =
          caseHeaderObj.readCaseStatus(caseHeaderKey);

        // The appeal case must be either closed or canceled, otherwise the
        // object has a current appeal case.
        if (!(appealCaseStatus.equals(CASESTATUS.CLOSED)
          || appealCaseStatus.equals(CASESTATUS.CANCELED))) {
          appealObjectActiveCaseInd.result = true;
          break;
        }
      }
    }
    return appealObjectActiveCaseInd;
  }

}
