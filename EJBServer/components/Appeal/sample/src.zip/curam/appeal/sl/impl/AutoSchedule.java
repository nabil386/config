/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2005, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealTypeDetails;
import curam.appeal.sl.struct.DetermineNumberOfUsersRequiredDetails;
import curam.appeal.sl.struct.DetermineNumberOfUsersRequiredKey;
import curam.appeal.sl.struct.HearingCaseID;
import curam.appeal.sl.struct.HearingKey;
import curam.appeal.sl.struct.LocationScheduleDetails;
import curam.appeal.sl.struct.LocationScheduleKey;
import curam.appeal.sl.struct.SearchForLocationScheduleKey;
import curam.appeal.sl.struct.SearchForUserScheduleKey;
import curam.appeal.sl.struct.UserScheduleDetails;
import curam.appeal.sl.struct.UserScheduleKey;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.codetable.APPEALTYPE;
import curam.core.fact.LocationFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.SlotAllocationFactory;
import curam.core.sl.intf.SlotAllocation;
import curam.core.sl.struct.DetermineAvailableSlotsDetailsList;
import curam.core.sl.struct.DetermineAvailableSlotsKey;
import curam.core.sl.struct.DisplayUserDailyScheduleDetails;
import curam.core.sl.struct.DisplayUserDailyScheduleKey;
import curam.core.sl.struct.FormatActiveUserDetailsKey;
import curam.core.sl.struct.RetrieveActiveUserDetailsResult;
import curam.core.struct.LocationKey;
import curam.legalaction.entity.fact.LegalActionFactory;
import curam.legalaction.entity.struct.LegalActionKey;
import curam.message.BPOAUTOSCHEDULE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;

/**
 * This process class provides the functionality for Automatic Scheduling
 * of Users within Appeal Hearings.
 * 
 */
public abstract class AutoSchedule implements
  curam.appeal.sl.intf.AutoSchedule {

  // ___________________________________________________________________________
  /**
   * This operation displays a location based schedule for an appeal hearing.
   * 
   * @param key The criteria for a location based schedule.
   * @return The details of the location based schedule.
   */
  @Override
  public LocationScheduleDetails displayLocationSchedule(
    final LocationScheduleKey key) throws AppException,
    InformationalException {

    // Return Variable
    LocationScheduleDetails locationScheduleDetails =
      new LocationScheduleDetails();

    // Auto Schedule Service Layer
    final SearchForLocationScheduleKey searchForLocationScheduleKey =
      new SearchForLocationScheduleKey();
    DetermineNumberOfUsersRequiredDetails determineNumberOfUsersRequiredDetails;
    final DetermineNumberOfUsersRequiredKey determineNumberOfUsersRequiredKey =
      new DetermineNumberOfUsersRequiredKey();

    // Hearing Service Layer
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // If case ID is not specified then use hearing ID to look up case ID
    if (key.appealCaseID == 0 && key.hearingID != 0) {
      hearingKey.hearingKey.hearingID = key.hearingID;
      hearingCaseID = hearingObj.getCase(hearingKey);
    } else if (key.appealCaseID != 0) {
      hearingCaseID = new HearingCaseID();
      hearingCaseID.hearingCaseID.caseID = key.appealCaseID;
    } else {
      // It is an error if neither hearing ID nor case ID is known
      throw new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_HEARINGID_CASEID);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the search parameters
    validateLocationSchedule(key);

    // If searching again then increment the start date by one day
    if (key.searchAgainInd == true) {
      searchForLocationScheduleKey.startDate = key.startDate.addDays(1);
    } else {
      searchForLocationScheduleKey.startDate = key.startDate;
    }

    // Determine minimum number of users needed for the hearing
    determineNumberOfUsersRequiredKey.appealCaseID = key.appealCaseID;
    determineNumberOfUsersRequiredDetails =
      determineNumberOfUsersRequired(determineNumberOfUsersRequiredKey);
    searchForLocationScheduleKey.numUsersRequired =
      determineNumberOfUsersRequiredDetails.numUsersRequired;

    // Search for a vacant schedule
    searchForLocationScheduleKey.jobID = key.jobID;
    searchForLocationScheduleKey.locationID = key.locationID;
    locationScheduleDetails =
      searchForLocationSchedule(searchForLocationScheduleKey);

    return locationScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation displays a schedule for an appeal hearing other than a
   * location based hearing.
   * 
   * @param key The ID for the schedule to be displayed.
   * @return The details of the schedule for the appeal hearing.
   */
  @Override
  public UserScheduleDetails displayUserSchedule(final UserScheduleKey key)
    throws AppException, InformationalException {

    // Return Variable
    UserScheduleDetails userScheduleDetails = new UserScheduleDetails();

    // Appeal Auto Schedule Service Layer Variables
    final SearchForUserScheduleKey searchForUserScheduleKey =
      new SearchForUserScheduleKey();
    DetermineNumberOfUsersRequiredDetails determineNumberOfUsersRequiredDetails;
    final DetermineNumberOfUsersRequiredKey determineNumberOfUsersRequiredKey =
      new DetermineNumberOfUsersRequiredKey();

    // Hearing Service Layer
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // If case ID is not specified then use hearing ID to look up case ID
    if (key.appealCaseID == 0 && key.hearingID != 0) {
      hearingKey.hearingKey.hearingID = key.hearingID;
      hearingCaseID = hearingObj.getCase(hearingKey);
    } else if (key.appealCaseID != 0) {
      hearingCaseID = new HearingCaseID();
      hearingCaseID.hearingCaseID.caseID = key.appealCaseID;
    } else {
      // It is an error if neither hearing ID nor case ID is known
      throw new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_HEARINGID_CASEID);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the search parameters
    validateUserSchedule(key);

    // If searching again then increment the start date by one day
    if (key.searchAgainInd == true) {
      searchForUserScheduleKey.startDate = key.startDate.addDays(1);
    } else {
      searchForUserScheduleKey.startDate = key.startDate;
    }

    if (key.appealCaseID == 0) {
      key.appealCaseID = hearingCaseID.hearingCaseID.caseID;
      determineNumberOfUsersRequiredKey.appealCaseID =
        hearingCaseID.hearingCaseID.caseID;
    }

    // Determine minimum number of users needed for the hearing
    determineNumberOfUsersRequiredKey.appealCaseID = key.appealCaseID;
    determineNumberOfUsersRequiredDetails =
      determineNumberOfUsersRequired(determineNumberOfUsersRequiredKey);
    searchForUserScheduleKey.numUsersRequired =
      determineNumberOfUsersRequiredDetails.numUsersRequired;

    // Search for a vacant schedule
    searchForUserScheduleKey.jobID = key.jobID;
    searchForUserScheduleKey.scheduleConfigMode = key.scheduleConfigMode;
    searchForUserScheduleKey.scheduleConfigType = key.scheduleConfigType;
    userScheduleDetails = searchForUserSchedule(searchForUserScheduleKey);

    return userScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation determines the required number of users for an appeal
   * hearing schedule.
   * 
   * @param key The identity of the appeal case for which the hearing is held.
   * @return The number of users required when scheduling the appeal hearing.
   */
  protected
    DetermineNumberOfUsersRequiredDetails
    determineNumberOfUsersRequired(final DetermineNumberOfUsersRequiredKey key)
      throws AppException, InformationalException {

    // Return Variable
    final DetermineNumberOfUsersRequiredDetails determineNumberOfUsersRequiredDetails =
      new DetermineNumberOfUsersRequiredDetails();

    // Variables for Appeal Business Process Service Layer
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    AppealTypeDetails appealTypeDetails;

    // Begin CR00117296 LP
    final LegalActionKey leagalActionKey = new LegalActionKey();

    leagalActionKey.legalActionID = key.appealCaseID;
    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

    LegalActionFactory.newInstance().read(notFoundIndicator, leagalActionKey);

    // Local Variable
    Integer numberOfUsersRequired;

    if (notFoundIndicator.isNotFound()) {
      // End CR00117296 LP

      // Determine the type of appeal case
      appealCaseKey.caseID = key.appealCaseID;
      appealTypeDetails = appealObj.readAppealType(appealCaseKey);

      // Determine minimum number of users for a Hearing Case
      if (appealTypeDetails.appealTypeDetails.appealTypeCode
        .equals(APPEALTYPE.HEARING)) {

        numberOfUsersRequired =
          curam.util.resources.Configuration
            .getIntProperty(EnvVars.ENV_APPEAL_NUMBEROFUSERS_HEARINGCASE);

        if (numberOfUsersRequired == null) {
          determineNumberOfUsersRequiredDetails.numUsersRequired =
            EnvVars.ENV_APPEAL_NUMBEROFUSERS_HEARINGCASE_DEFAULT;
        } else {
          determineNumberOfUsersRequiredDetails.numUsersRequired =
            numberOfUsersRequired.longValue();
        }

      } // Determine minimum number of users for a Hearing Review
      else if (appealTypeDetails.appealTypeDetails.appealTypeCode
        .equals(APPEALTYPE.HEARINGREVIEW)) {

        numberOfUsersRequired =
          curam.util.resources.Configuration
            .getIntProperty(EnvVars.ENV_APPEAL_NUMBEROFUSERS_HEARINGREVIEW);
        if (numberOfUsersRequired == null) {
          determineNumberOfUsersRequiredDetails.numUsersRequired =
            EnvVars.ENV_APPEAL_NUMBEROFUSERS_HEARINGREVIEW_DEFAULT;
        } else {
          determineNumberOfUsersRequiredDetails.numUsersRequired =
            numberOfUsersRequired.longValue();
        }

      }
    } // Begin CR00117296 LP
    else {
      // Should ENV variables be created for this too. As of now using Appeal
      // hearing case data
      numberOfUsersRequired =
        curam.util.resources.Configuration
          .getIntProperty(EnvVars.ENV_LEGALACTION_HEARING_NUMBEROFUSERS);

      if (numberOfUsersRequired == null) {
        determineNumberOfUsersRequiredDetails.numUsersRequired =
          EnvVars.ENV_LEGALACTION_HEARING_NUMBEROFUSERS_DEFAULT;
      } else {
        determineNumberOfUsersRequiredDetails.numUsersRequired =
          numberOfUsersRequired.longValue();
      }

    }
    // End CR00117296 LP
    return determineNumberOfUsersRequiredDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation searches for a location based schedule.
   * 
   * @param key The search criteria for a location based schedule
   * @return The details of the location based schedule
   */
  protected LocationScheduleDetails searchForLocationSchedule(
    final SearchForLocationScheduleKey key) throws AppException,
    InformationalException {

    // Return Variable
    final LocationScheduleDetails locationScheduleDetails =
      new LocationScheduleDetails();

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Core Slot Allocation Business Process Variables
    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();
    final DetermineAvailableSlotsKey determineAvailableSlotsKey =
      new DetermineAvailableSlotsKey();
    DetermineAvailableSlotsDetailsList determineAvailableSlotsDetailsList;

    // Variable to indicate if suitable availability has been found
    boolean scheduleFound = false;

    // Variables for maximum number of search iterations
    int maxIterations;
    Integer maxIterationsProperty;

    // Determine the maximum number of search iterations
    maxIterationsProperty =
      curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_APPEAL_AUTOSCHEDULE_MAXIMUMITERATIONS);

    // If environment variable not set then use the default value
    if (maxIterationsProperty == null) {

      maxIterations =
        EnvVars.ENV_APPEAL_AUTOSCHEDULE_MAXIMUMITERATIONS_DEFAULT;
    } else {
      // Read value of environment variable for Maximum Iterations
      maxIterations = maxIterationsProperty.intValue();
    }

    // Set up the search parameters
    determineAvailableSlotsKey.effectiveDate = key.startDate;
    determineAvailableSlotsKey.jobID = key.jobID;
    determineAvailableSlotsKey.locationID = key.locationID;
    determineAvailableSlotsKey.numWorkUnits = (int) key.numUsersRequired;

    // Determine availability of slots up to a maximum number of iterations
    for (int i = 0; i < maxIterations; i++) {

      // Search for slots
      determineAvailableSlotsKey.effectiveDate = key.startDate.addDays(i);

      try {
        determineAvailableSlotsDetailsList =
          slotAllocationObj
            .determineAvailableSlots(determineAvailableSlotsKey);
      } catch (final RecordNotFoundException e) {
        determineAvailableSlotsDetailsList =
          new DetermineAvailableSlotsDetailsList();
      }

      // If slots are available then return the slot details for this date
      if (!determineAvailableSlotsDetailsList.dtls.isEmpty()) {
        scheduleFound = true;
        locationScheduleDetails.determineAvailableSlotsDetailsList
          .assign(determineAvailableSlotsDetailsList);
        locationScheduleDetails.scheduleDate =
          determineAvailableSlotsKey.effectiveDate;
        break;
      }
    }

    // If no suitable availability then generate a validation error
    if (scheduleFound == false) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_XRV_NOTFOUND), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

    // BEGIN, CR00285436, MC
    // Read for the location name using the location ID
    final LocationKey locationKey = new LocationKey();

    locationKey.locationID = key.locationID;

    locationScheduleDetails.locationName =
      LocationFactory.newInstance().readLocationName(locationKey).name;
    // END, CR00285436

    return locationScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation searches for a schedule for an appeal hearing.
   * 
   * @param key The search criteria for the schedule
   * @return The details of the schedule for the hearing
   */
  protected UserScheduleDetails searchForUserSchedule(
    final SearchForUserScheduleKey key) throws AppException,
    InformationalException {

    // Return Variable
    final UserScheduleDetails userScheduleDetails = new UserScheduleDetails();

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Core Slot Allocation Business Process Variables
    final SlotAllocation slotAllocationObj =
      SlotAllocationFactory.newInstance();
    DisplayUserDailyScheduleDetails displayUserDailyScheduleDetails;
    final DisplayUserDailyScheduleKey displayUserDailyScheduleKey =
      new DisplayUserDailyScheduleKey();
    RetrieveActiveUserDetailsResult retrieveActiveUserDetailsResult;
    final FormatActiveUserDetailsKey formatActiveUserDetailsKey =
      new FormatActiveUserDetailsKey();

    // Variable to indicate if suitable schedule has been found
    boolean scheduleFound = false;

    // Variables for maximum number of search iterations
    int maxIterations;
    Integer maxIterationsProperty;

    // Determine the maximum number of search iterations
    maxIterationsProperty =
      curam.util.resources.Configuration
        .getIntProperty(EnvVars.ENV_APPEAL_AUTOSCHEDULE_MAXIMUMITERATIONS);

    // If environment variable not set then use the default value
    if (maxIterationsProperty == null) {

      maxIterations =
        EnvVars.ENV_APPEAL_AUTOSCHEDULE_MAXIMUMITERATIONS_DEFAULT;
    } else {
      // Read value of environment variable for Maximum Iterations
      maxIterations = maxIterationsProperty.intValue();
    }

    // Set up the search parameters
    displayUserDailyScheduleKey.effectiveDate = key.startDate;
    displayUserDailyScheduleKey.jobID = key.jobID;
    displayUserDailyScheduleKey.scheduleConfigMode = key.scheduleConfigMode;
    displayUserDailyScheduleKey.scheduleConfigType = key.scheduleConfigType;

    // Determine availability of slots up to a maximum number of iterations
    for (int i = 0; i < maxIterations; i++) {

      // Search for slots
      displayUserDailyScheduleKey.effectiveDate = key.startDate.addDays(i);
      try {
        retrieveActiveUserDetailsResult =
          slotAllocationObj
            .retrieveActiveUserDetails(displayUserDailyScheduleKey);

        if (retrieveActiveUserDetailsResult.activeUserDetailsList.dtls.size() < key.numUsersRequired) {

          continue;
        }

        formatActiveUserDetailsKey.displayUserDailyScheduleKey
          .assign(displayUserDailyScheduleKey);

        formatActiveUserDetailsKey.activeUserDetailsList
          .assign(retrieveActiveUserDetailsResult.activeUserDetailsList);

        displayUserDailyScheduleDetails =
          slotAllocationObj
            .formatActiveUserDetails(formatActiveUserDetailsKey);

      } catch (final RecordNotFoundException e) {
        displayUserDailyScheduleDetails =
          new DisplayUserDailyScheduleDetails();
        scheduleFound = false;
        continue;
      }

      // If slots are available then select the current schedule date
      if (displayUserDailyScheduleDetails.userScheduleData.length() > 0) {

        scheduleFound = true;
        userScheduleDetails.displayUserDailyScheduleDetails
          .assign(displayUserDailyScheduleDetails);
        userScheduleDetails.scheduleDate =
          displayUserDailyScheduleKey.effectiveDate;
        break;
      }
    }

    // If schedule not found then generate an informational message
    if (scheduleFound == false) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_XRV_NOTFOUND), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

    return userScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This operation validates the search criteria for a location based
   * schedule.
   * 
   * @param key The search criteria to be validated
   */
  protected void validateLocationSchedule(final LocationScheduleKey key)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Auto Schedule Service Layer variables
    final UserScheduleKey userScheduleKey = new UserScheduleKey();

    // Validate the location
    if (key.locationID == 0) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_LOCATION_MISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Validate the user details
    userScheduleKey.appealCaseID = key.appealCaseID;
    userScheduleKey.jobID = key.jobID;
    userScheduleKey.startDate = key.startDate;
    userScheduleKey.searchAgainInd = key.searchAgainInd;
    validateUserSchedule(userScheduleKey);

    // Inform user of any and all validation errors
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * This operation validates the search criteria for a user based schedule.
   * 
   * @param key The search criteria to be validated.
   */
  protected void validateUserSchedule(final UserScheduleKey key)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Validate that the start date has been entered
    if (key.startDate.isZero()) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_STARTDATE_MISSING),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } // Validate that the start date is not in the past
    else if (key.startDate.before(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_STARTDATE_PAST),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * This operation confirms the search parameters for a location based
   * schedule.
   * 
   * @param key The search parameters for a location based schedule.
   */
  @Override
  public LocationScheduleKey enterLocationSearchCriteria(
    final LocationScheduleKey key) throws AppException,
    InformationalException {

    // Hearing Service Layer
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // If case ID is not specified then use hearing ID to look up case ID
    if (key.appealCaseID == 0 && key.hearingID != 0) {
      hearingKey.hearingKey.hearingID = key.hearingID;
      hearingCaseID = hearingObj.getCase(hearingKey);
    } else if (key.appealCaseID != 0) {
      hearingCaseID = new HearingCaseID();
      hearingCaseID.hearingCaseID.caseID = key.appealCaseID;
    } else {
      // It is an error if neither hearing ID nor case ID is known
      throw new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_HEARINGID_CASEID);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the search criteria
    validateLocationSchedule(key);

    return key;
  }

  // ___________________________________________________________________________
  /**
   * This operation confirms the search parameters for a user based schedule.
   * 
   * @param key The search parameters for a user based schedule
   */
  @Override
  public UserScheduleKey enterUserSearchCriteria(final UserScheduleKey key)
    throws AppException, InformationalException {

    // Hearing Service Layer
    final Hearing hearingObj = HearingFactory.newInstance();
    HearingCaseID hearingCaseID;
    final HearingKey hearingKey = new HearingKey();

    // If case ID is not specified then use hearing ID to look up case ID
    if (key.appealCaseID == 0 && key.hearingID != 0) {
      hearingKey.hearingKey.hearingID = key.hearingID;
      hearingCaseID = hearingObj.getCase(hearingKey);
    } else if (key.appealCaseID != 0) {
      hearingCaseID = new HearingCaseID();
      hearingCaseID.hearingCaseID.caseID = key.appealCaseID;
    } else {
      // It is an error if neither hearing ID nor case ID is known
      throw new AppException(
        BPOAUTOSCHEDULE.ERR_AUTOSCHEDULE_FV_HEARINGID_CASEID);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingCaseID.hearingCaseID.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the search criteria
    validateUserSchedule(key);

    return key;
  }

}
