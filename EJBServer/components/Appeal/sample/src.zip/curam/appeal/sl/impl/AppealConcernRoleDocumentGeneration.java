/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2006,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.DateResolutionAndCaseRefDetails;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASECOMMUNICATIONTYPE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleDocumentGenerationFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRoleDocumentGeneration;
import curam.core.intf.UniqueID;
import curam.core.intf.Users;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AlternateIDAddressNameAndTypeDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetCaseClosureSupplierKey;
import curam.core.struct.GetCaseEventData;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ProFormaDocumentData;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOAPPEALPROFORMADOCUMENTGENERATION;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;

/**
 * Contains the Appeal specific details of concern role document
 * generation.
 * 
 * @see curam.core.impl.ConcernRoleDocumentGeneration
 */
public abstract class AppealConcernRoleDocumentGeneration extends
  curam.appeal.sl.base.AppealConcernRoleDocumentGeneration {

  // BEGIN, CR00297142, CD
  @Inject
  private CMISAccessInterface cmisAccess;

  /**
   * Add injection.
   */
  protected AppealConcernRoleDocumentGeneration() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00297142
  // ___________________________________________________________________________
  /**
   * Get type, reason and client data.
   * 
   * @param key contains caseID
   * @param documentData ProFormaDocumentData for printing communications
   * @see curam.core.impl.ConcernRoleDocumentGeneration#getCaseClosureClientData
   */
  @Override
  public void getCaseClosureClientData(final GetCaseClosureSupplierKey key,
    final ProFormaDocumentData documentData) throws AppException,
    InformationalException {

    // Decision variables
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    DateResolutionAndCaseRefDetails dateResolutionAndCaseRefDetails;
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();

    // Get description of closure reason - read the decision
    try {

      hearingDecisionCaseKey.caseID = key.caseID;
      dateResolutionAndCaseRefDetails =
        hearingDecisionObj
          .readDateResolutionAndRefByCase(hearingDecisionCaseKey);

      // Return case closure reason
      documentData.caseClosureReason =
        curam.util.type.CodeTable.getOneItem(
          HEARINGDECISIONRESOLUTION.TABLENAME,
          dateResolutionAndCaseRefDetails.resolutionCode);

      documentData.caseClosureDate =
        dateResolutionAndCaseRefDetails.decisionDate;

    } catch (final RecordNotFoundException e) {
      // Case was never closed, so no closure info available

      throw new AppException(

      BPOAPPEALPROFORMADOCUMENTGENERATION.ERR_CASE_NO_CLOSURE_DETAILS);

    }

  }

  // ___________________________________________________________________________
  /**
   * Retrieve the data needed to print a communication
   * 
   * @param key contains ConcernRole ID & caseID
   * @param documentData ProFormaDocumentData for printing communications
   * 
   * @see curam.core.impl.ConcernRoleDocumentGeneration#getCaseEventData
   */
  @Override
  public void getCaseEventData(final GetCaseEventData key,
    final ProFormaDocumentData documentData) throws AppException,
    InformationalException {

    // Case type variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // Concern Role Document Generation variable, for running CORE code
    final ConcernRoleDocumentGeneration concernRoleDocumentGeneration =
      ConcernRoleDocumentGenerationFactory.newInstance();

    // Appeal variables
    final Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // CaseHeader manipulation variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

    // Struct for document generation
    final ConcernRoleDocumentDetails concernRoleDocumentDetails =
      new ConcernRoleDocumentDetails();

    // Concern role object and access structures
    final curam.core.intf.ConcernRole concernRoleObj =
      ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    AlternateIDAddressNameAndTypeDetails alternateIDAddressNameAndTypeDetails;

    // Variables, used to read address information
    final curam.core.intf.Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    final OtherAddressData otherAddressData = new OtherAddressData();

    // Unique ID generation variable
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Users object and access structures
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Variables for insert of Concern Role Communication record
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj =
      ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationDtls concernRoleCommDtls =
      new ConcernRoleCommunicationDtls();

    // XSL details for printing templates
    final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // System user variables
    final curam.core.intf.SystemUser systemUserObj =
      SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Set description of appeal type, which will be printed on the
    // case communication
    documentData.productType =
      curam.util.type.CodeTable.getOneItem(APPEALTYPE.TABLENAME,
        appealObj.readAppealTypeByCase(appealCaseIDKey).appealTypeCode);

    // Pass in the correct date
    documentData.eventDate = key.eventDate;

    // Set the caseID so that the correct user info is retrieved
    documentData.caseID = key.caseID;

    // If there is a concernroleID, get the concern role information
    if (key.concernRoleID != 0) {

      concernRoleKey.concernRoleID = key.concernRoleID;

    } else {

      // Read CaseHeader from database
      caseHeaderKey.caseID = key.caseID;
      readParticipantRoleIDDetails =
        caseHeaderObj.readParticipantRoleID(caseHeaderKey);

      concernRoleKey.concernRoleID =
        readParticipantRoleIDDetails.concernRoleID;
    }

    // Populate the user information

    // Use local instance of ConcernRoleDocumentGeneration
    concernRoleDocumentGeneration.getUserData(documentData);

    // Read the concern role information
    alternateIDAddressNameAndTypeDetails =
      concernRoleObj.readNameAlternateIDAddressAndType(concernRoleKey);

    // Copy concern role information to document data
    documentData.alternateID =
      alternateIDAddressNameAndTypeDetails.primaryAlternateID;
    documentData.concernRoleName =
      alternateIDAddressNameAndTypeDetails.concernRoleName;

    // Copy the concern role type description to document data
    documentData.concernRoleTypeDesc =
      curam.util.type.CodeTable.getOneItem(CONCERNROLETYPE.TABLENAME,
        alternateIDAddressNameAndTypeDetails.concernRoleType);

    // Read address information
    addressKey.addressID =
      alternateIDAddressNameAndTypeDetails.primaryAddressID;
    addressDtls = addressObj.read(addressKey);

    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getLongFormat(otherAddressData);

    documentData.concernRoleAddress = otherAddressData.addressData;

    // Read user information
    systemUserDtls = systemUserObj.getUserDetails();
    usersKey.userName = systemUserDtls.userName;
    addressKey = usersObj.readOrganizationAddress(usersKey);

    // Read organization address information
    addressDtls = addressObj.read(addressKey);

    // Copy concern role address information to document data
    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getAddressStrings(otherAddressData);

    documentData.userAddress = otherAddressData.addressData;

    // Depending on the communication type, print the related template
    if (key.caseCommunicationType.equals(CASECOMMUNICATIONTYPE.CASECREATED)) {

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.CASECREATEDCLIENTCOMMUNICATION;

    } else {

      if (key.caseCommunicationType
        .equals(CASECOMMUNICATIONTYPE.CASESUSPENDED)) {

        xslTemplateIDCodeKey.templateIDCode =
          TEMPLATEIDCODE.CASESUSPENDEDCLIENTCOMMUNICATION;

      } else {

        if (key.caseCommunicationType
          .equals(CASECOMMUNICATIONTYPE.CASEUNSUSPENDED)) {

          xslTemplateIDCodeKey.templateIDCode =
            TEMPLATEIDCODE.CASEUNSUSPENDEDCLIENTCOMMUNICATION;
        }

      }

    }

    // Get the templateID and templateVersion for printDocument
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();
    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
      curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();
    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
      new curam.util.administration.struct.XSLTemplateInstanceKey();

    try {

      xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    } catch (final curam.util.exception.RecordNotFoundException e) {

      final AppException ae =
        new AppException(GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      ae.arg(xslTemplateIDCodeKey.templateIDCode);
      throw ae;
    }

    // Pass in the template id and version number
    concernRoleDocumentDetails.documentID = xslTemplateInstanceKey.templateID;
    concernRoleDocumentDetails.versionNo =
      xslTemplateInstanceKey.templateVersion;
    // END HARP 49771.

    // BEGIN, CR00297142, CD
    // Print the communication
    // Use local instance of ConcernRoleDocumentGeneration
    final ProFormaReturnDocDetails proFormaDtls =
      concernRoleDocumentGeneration.generatePrintAndPreviewXMLDocument(
        concernRoleDocumentDetails, documentData);

    // END, CR00297142

    // Generate unique id for ConcernRoleCommunication
    concernRoleCommDtls.communicationID = uniqueIDObj.getNextID();

    // Set the communication details
    concernRoleCommDtls.caseID = key.caseID;
    concernRoleCommDtls.correspondentConcernRoleID =
      concernRoleKey.concernRoleID;

    concernRoleCommDtls.typeCode = COMMUNICATIONTYPE.LETTER;

    concernRoleCommDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;

    concernRoleCommDtls.communicationDate =
      curam.util.type.Date.getCurrentDate();

    concernRoleCommDtls.statusCode = RECORDSTATUS.NORMAL;

    concernRoleCommDtls.correspondentName = documentData.concernRoleName;
    concernRoleCommDtls.addressID =
      alternateIDAddressNameAndTypeDetails.primaryAddressID;
    concernRoleCommDtls.proFormaInd = true;

    concernRoleCommDtls.proFormaID = xslTemplateInstanceKey.templateID;
    concernRoleCommDtls.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    // END HARP 49771

    concernRoleCommDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;

    systemUserDtls = systemUserObj.getUserDetails();
    concernRoleCommDtls.userName = systemUserDtls.userName;

    // Write a record to the communications table for history purposes
    concernRoleCommunicationObj.insert(concernRoleCommDtls);

    // BEGIN, CR00297142, CD
    if (cmisAccess
      .isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

      // save the contents to the content management system
      cmisAccess.create(concernRoleCommDtls.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
        proFormaDtls.fileDate.copyBytes(), proFormaDtls.fileName,
        CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);

    }
    // END, CR00297142
  }

}
