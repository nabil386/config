/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2004-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealedCaseRejectionFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealedCaseRejection;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealRelationshipKey;
import curam.appeal.sl.entity.struct.AppealedCaseCountDetails;
import curam.appeal.sl.entity.struct.AppealedCaseRejectionDtls;
import curam.appeal.sl.entity.struct.CaseIDTypeAndBenefitsDetails;
import curam.appeal.sl.entity.struct.CaseOwnerStatusAndDeadlineDate;
import curam.appeal.sl.entity.struct.ModifyDeadlineDateDetails;
import curam.appeal.sl.entity.struct.NormalAppealCaseStatus;
import curam.appeal.sl.entity.struct.StatusAndRecordStatus;
import curam.appeal.sl.entity.struct.StatusDetails;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingScheduleFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.HearingSchedule;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealCaseStatusDetails;
import curam.appeal.sl.struct.AppealedCaseApproveDetails;
import curam.appeal.sl.struct.AppealedCaseRejectionDetails;
import curam.appeal.sl.struct.CaseIDDeadlineDate;
import curam.appeal.sl.struct.CreateBenefitTaskAppealedCaseDetails;
import curam.appeal.sl.struct.DeadlineDate;
import curam.appeal.sl.struct.FinalRejectionDetails;
import curam.appeal.sl.struct.RemoveRelationshipLinksDetails;
import curam.appeal.sl.struct.UpdateAppealCaseStatusDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CORRESPONDENT;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.Notification;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.GenerateDocumentDetails1;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseTypeConcernRoleAndConcernRoleType;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.message.BPOAPPEAL;
import curam.message.BPOAPPEALEDCASEAPPROVAL;
import curam.message.BPOAPPEALEDCASEREJECTION;
import curam.message.BPOHEARINGCASEAPPROVAL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the AppealedCaseApproval
 * service layer.
 */
public abstract class AppealedCaseApproval extends
  curam.appeal.sl.base.AppealedCaseApproval {

  // ___________________________________________________________________________
  /*
   * A final rejection of an appealed case removes the appealed case from
   * consideration for an appeal case.
   * 
   * @param dtls The appealed case final rejection details.
   */
  @Override
  protected void rejectFinal(final FinalRejectionDetails dtls)
    throws AppException, InformationalException {

    // HARP, BEGIN 38292, SH
    // Appeal objects
    final Appeal appeal_boObj = AppealFactory.newInstance();

    // Appeal relationship object
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // Variables for rejecting an appealed case
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();
    final StatusAndRecordStatus statusAndRecordStatus =
      new StatusAndRecordStatus();
    final NormalAppealCaseStatus normalAppealCaseStatus =
      new NormalAppealCaseStatus();
    final RemoveRelationshipLinksDetails removeRelationshipLinksDetails =
      new RemoveRelationshipLinksDetails();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    CaseIDTypeAndBenefitsDetails caseIDTypeAndBenefitsDetails;
    curam.appeal.sl.entity.struct.AppealCaseStatusDetails appealCaseStatusDetails;
    AppealedCaseCountDetails appealedCaseCountDetails;

    // Communication helper objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();
    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final CaseID caseID = new CaseID();

    // BEGIN, CR00296080, DG
    // Generate the pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final GenerateDocumentDetails1 generateDocumentDetails =
      new GenerateDocumentDetails1();

    generateDocumentDetails.dataSetPrimaryKey = dtls.appealRelationshipID;
    generateDocumentDetails.documentIDCode =
      curam.codetable.TEMPLATEIDCODE.APPEALEDCASEREJECTIONNOTICE;
    generateDocumentDetails.dataSetType =
      curam.codetable.DATASETTYPE.APPEALED_CASE_REJECTION_NOTICE;
    generateDocumentDetails.creationDate = Date.getCurrentDate();
    // generate the document
    appealProFormaDocumentGenerationObj
      .generateDocument1(generateDocumentDetails);
    // END, CR00296080

    // Set status to canceled and status code to rejected
    appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
    statusAndRecordStatus.statusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    statusAndRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;
    appealRelationshipObj.modifyRecordStatusAndStatusCode(
      appealRelationshipKey, statusAndRecordStatus);

    // Determine case ID type and cont benefits ind
    caseIDTypeAndBenefitsDetails =
      appealRelationshipObj
        .readCaseIDCaseTypeAndContinueBenefits(appealRelationshipKey);

    // Undo relevant relationship links for appealed case
    removeRelationshipLinksDetails.caseID =
      caseIDTypeAndBenefitsDetails.caseID;
    removeRelationshipLinksDetails.caseTypeCode =
      caseIDTypeAndBenefitsDetails.caseType;
    removeRelationshipLinksDetails.priorAppealCaseID = dtls.appealCaseID;
    appeal_boObj.removeRelationshipLinks(removeRelationshipLinksDetails);

    // Reverse benefit discontinuance if needed
    if (!caseIDTypeAndBenefitsDetails.continueBenefitsIndicator) {

      final CreateBenefitTaskAppealedCaseDetails createBenefitTaskAppealedCaseDetails =
        new CreateBenefitTaskAppealedCaseDetails();

      createBenefitTaskAppealedCaseDetails.caseID =
        caseIDTypeAndBenefitsDetails.caseID;
      createBenefitTaskAppealedCaseDetails.caseType =
        caseIDTypeAndBenefitsDetails.caseType;
      createBenefitTaskAppealedCaseDetails.continueBenefitsIndicator = true;

      appeal_boObj.createBenefitTask(createBenefitTaskAppealedCaseDetails);

    }

    // Grab the appealed case status details
    appealCaseStatusDetails =
      appealRelationshipObj
        .readAppealCaseAndAppealStatus(appealRelationshipKey);

    normalAppealCaseStatus.appealCaseID =
      appealCaseStatusDetails.appealCaseID;

    // Count all the active appealed cases for the appeal case
    appealedCaseCountDetails =
      appealRelationshipObj
        .countActiveAppealedCasesByAppealCase(normalAppealCaseStatus);

    appealCaseIDKey.caseID = appealCaseStatusDetails.appealCaseID;

    // Appellant is not the organization
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // get the appellant for the appeal case
    caseParticipantRoleCaseAndTypeKey.caseID =
      appealCaseStatusDetails.appealCaseID;

    /*
     * Get the active participant for the case. There should only be 1 case
     * // participant returned based on the appeals logic, even though the
     * entity
     * // supports multiple participants. We need to check for a single
     * // participant and alert the user that something has gone wrong if
     * multiple
     * // participants are returned.
     */
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check that only 1 participant is returned.
    if (caseParticipantRoleNameDetailsList.dtls.size() <= 0) {

      throw new AppException(
        curam.message.BPOAPPEALEDCASEREJECTION.ERR_APPEALED_CASE_NOPARTICIPANT);

    } else if (caseParticipantRoleNameDetailsList.dtls.size() > 1) {

      throw new AppException(
        curam.message.BPOAPPEALEDCASEREJECTION.ERR_APPEALED_CASE_MULTIPLEPARTICIPANTS);

    }

    // setup and create the communication for the appeal case
    communicationDetails.caseID = appealCaseStatusDetails.appealCaseID;
    communicationDetails.concernRoleID =
      caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;

    communicationDetails.caseID = appealCaseStatusDetails.appealCaseID;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = appealCaseStatusDetails.appealCaseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.concernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = curam.codetable.COMMUNICATIONTYPE.NOTICE;
    communicationDetails.userName = TransactionInfo.getProgramUser();
    communicationDetails.subjectText =
      curam.message.BPOAPPEALEDCASEREJECTION.INF_APPEALED_CASE_REJECT_SUBJECT
        .getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.correspondentConcernRoleID =
      caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
    communicationDetails.correspondentName =
      caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;

    // Create the communication
    final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new curam.util.xml.struct.XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.APPEALEDCASEREJECTIONNOTICE;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
      curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    // BEGIN, CR00124669, RKi
    proFormaCommDetails.assign(communicationDetails);
    // END, CR00124669
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;

    concernRoleKey.concernRoleID =
      caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    communicationObj.createProForma1(proFormaCommDetails);

    // HARP, END 38292

    // Close appeal if case being rejected is last active appealed case
    if (appealedCaseCountDetails.recordCount <= 0) {

      final UpdateAppealCaseStatusDetails updateAppealCaseStatusDetails =
        new UpdateAppealCaseStatusDetails();

      // Set status code to CLOSED and update
      updateAppealCaseStatusDetails.statusCode = CASESTATUS.CLOSED;
      updateAppealCaseStatusDetails.caseID =
        appealCaseStatusDetails.appealCaseID;
      updateAppealCaseStatusDetails.versionNo = dtls.caseHeaderVersionNo;

      appeal_boObj.updateCaseStatus(updateAppealCaseStatusDetails);

      // Remove the task
      caseID.caseID = appealCaseIDKey.caseID;
      appeal_boObj.removeDeadlineTask(caseID);

    }
  }

  // ___________________________________________________________________________
  /*
   * Validates the rejection of an appealed case on an appeal case.
   * 
   * @param appealKey The appeal case identifier for the appealed case being
   * rejected
   * 
   * @param dtls The appealed case rejection details
   */
  @Override
  protected void validateReject(final AppealCaseKey appealKey,
    final AppealedCaseRejectionDetails dtls) throws AppException,
    InformationalException {

    // Variables for reading the status
    StatusAndRecordStatus statusAndRecordStatus = new StatusAndRecordStatus();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();

    // Exceptions Information Manager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // check status of related appeal case
    caseHeaderKey.caseID = appealKey.caseID;
    final CaseStatusCode caseStatusCode =
      caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Appeal case status must be open, approved or active
    if (!caseStatusCode.statusCode.equals(CASESTATUS.OPEN)
      && !caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
      && !caseStatusCode.statusCode.equals(CASESTATUS.APPROVED)) {

      // Cannot approve an appealed case for an inactive appeal case
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASESTATUSINVALID),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    } else {

      appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
      statusAndRecordStatus =
        appealRelationshipObj
          .readStatusAndRecordStatus(appealRelationshipKey);

      if (statusAndRecordStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

        // Cannot reject as the appealed case has being removed from the appeal
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEREJECTION.ERR_APPEAL_XRV_REMOVED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else if (statusAndRecordStatus.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.REJECTED)) {

        // Cannot reject as the appealed case has already being rejected
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEREJECTION.ERR_APPEAL_XRV_REJECTED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else if (!statusAndRecordStatus.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.PENDING_APPROVAL)) {

        // Cannot reject as the appealed case has not being submitted for
        // approval
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEREJECTION.ERR_APPEAL_XRV_SUBMITTED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

    // HARP, END 38292

  }

  // ___________________________________________________________________________
  /*
   * Validates the approval of an appealed case on an appeal case.
   * 
   * @param appealStatusDtls The current status of the appeal case for the
   * appealed case being approved
   * 
   * @param dtls The appealed case approval details
   */
  @Override
  protected void validateApprove(
    final AppealCaseStatusDetails appealStatusDtls,
    final AppealedCaseApproveDetails dtls) throws AppException,
    InformationalException {

    // Appeal relationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();

    // Status and Record Status
    StatusAndRecordStatus statusAndRecordStatus = new StatusAndRecordStatus();

    // Exceptions Information Manager object
    final InformationalManager informationalManager =
      new InformationalManager();

    // Appeal case status must be open or active
    if (!appealStatusDtls.statusCode.equals(CASESTATUS.OPEN)
      && !appealStatusDtls.statusCode.equals(CASESTATUS.ACTIVE)
      && !appealStatusDtls.statusCode.equals(CASESTATUS.APPROVED)) {

      // Cannot approve an appealed case for an inactive appeal case
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEAL.ERR_APPEAL_FV_STATEMENTCASESTATUSINVALID),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    } else {

      appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
      statusAndRecordStatus =
        appealRelationshipObj
          .readStatusAndRecordStatus(appealRelationshipKey);

      if (!statusAndRecordStatus.recordStatus.equals(RECORDSTATUS.NORMAL)) {

        // Cannot approve an appealed case for an inactive appeal case
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEAPPROVAL.ERR_APPEAL_XRV_REMOVED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else if (statusAndRecordStatus.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.REJECTED)) {

        // Cannot approve as the appealed case has being rejected
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEAPPROVAL.ERR_APPEAL_XRV_REJECTED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else if (statusAndRecordStatus.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {

        // Cannot approve as the appealed case has already being approved
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEAPPROVAL.ERR_APPEAL_XRV_APPROVED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      } else if (!statusAndRecordStatus.statusCode
        .equals(APPEALRELATIONSHIPSTATUS.PENDING_APPROVAL)) {

        // Cannot approve as the appealed case has not being submitted for
        // approval
        informationalManager.addInformationalMsg(new AppException(
          BPOAPPEALEDCASEAPPROVAL.ERR_APPEAL_XRV_SUBMITTED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

      }

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /*
   * Rejects the consideration of an appealed case on an appeal case.
   * An appealed case rejection can be final which effectively removes
   * the appealed case from an appeal.
   * 
   * @param dtls The appealed case rejection details including whether or not
   * the rejection is final.
   */
  @Override
  public void reject(final AppealedCaseRejectionDetails dtls)
    throws AppException, InformationalException {

    // Appeal objects
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealedCaseRejection appealedCaseRejectionObj =
      AppealedCaseRejectionFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    // Today's date
    final Date currentDate = curam.util.type.Date.getCurrentDate();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Case Event manipulation variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // Variables for rejecting an appealed case
    CaseOwnerStatusAndDeadlineDate caseOwnerStatusAndDeadlineDate;
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final AppealedCaseRejectionDtls appealedCaseRejectionDetails =
      new AppealedCaseRejectionDtls();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();
    AppealCaseID appealCaseID;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Determine the appealCaseID for the appealed case
    appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
    appealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate appeal case security
    validateSecurityKey.caseID = appealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kApproveSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the reject
    appealCaseKey.caseID = appealCaseID.appealCaseID;
    validateReject(appealCaseKey, dtls);

    // Set variables and insert
    appealedCaseRejectionDetails.appealRelationshipID =
      dtls.appealRelationshipID;
    appealedCaseRejectionDetails.appealedCaseRejectionID =
      uniqueIDObj.getNextID();
    appealedCaseRejectionDetails.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();
    appealedCaseRejectionDetails.rejectionDate = currentDate;
    appealedCaseRejectionDetails.reasonCode = dtls.reasonCode;
    appealedCaseRejectionDetails.reasonText = dtls.reasonText;

    appealedCaseRejectionObj.insert(appealedCaseRejectionDetails);

    if (dtls.finalRejectionIndicator) {

      // Final rejection details
      final FinalRejectionDetails finalRejectionDetails =
        new FinalRejectionDetails();

      finalRejectionDetails.assign(dtls);
      finalRejectionDetails.appealCaseID = appealCaseID.appealCaseID;

      rejectFinal(finalRejectionDetails);

    } else {

      // Update the status code to REJECTED
      final StatusDetails statusDetails = new StatusDetails();

      statusDetails.statusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
      statusDetails.versionNo = dtls.versionNo;

      appealRelationshipObj.modifyStatusCode(appealRelationshipKey,
        statusDetails);

    }

    // check type and status of appeal case
    appealCaseIDKey.caseID = appealCaseID.appealCaseID;
    caseOwnerStatusAndDeadlineDate =
      appealObj.readCaseOwnerStatusAndDeadlineDate(appealCaseIDKey);
    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      caseOwnerStatusAndDeadlineDate.ownerOrgObjectLinkID;
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
    // END, CR00053295

    // A notification is sent to case owner of the appeal case stating that
    // the appealed case has been rejected. A check to ensure current user is
    // not the user to whom the notification is being sent is carried out.
    if (!caseOwnerDetails.userName
      .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

      // Notification variables
      final Notification notificationObj = NotificationFactory.newInstance();

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = appealCaseID.appealCaseID;

      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // StandardManualTask details
      final StandardManualTaskDtls standardManualTaskDtls =
        new StandardManualTaskDtls();

      standardManualTaskDtls.dtls.concerningDtls.caseID =
        appealCaseID.appealCaseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOAPPEALEDCASEREJECTION.INF_APPEALED_CASE_REJECT_SUBJECT
          .getMessageText();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userName;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseHeaderDtls.concernRoleID;

      notificationObj
        .createWorkAllocationNotification(standardManualTaskDtls);

    }

    // Insert the case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = appealCaseID.appealCaseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.APPEALEDCASEREJECTED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.versionNo = dtls.versionNo;

    caseEventObj.insert(caseEventDtls);

  }

  // ___________________________________________________________________________
  /*
   * Approves the consideration of an appealed case on an appeal case.
   * 
   * @param dtls The appealed case approval details.
   */
  @Override
  public void approve(final AppealedCaseApproveDetails dtls)
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final Appeal appeal_boObj = AppealFactory.newInstance();

    // Variables for holding appeal case details
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final StatusDetails statusDetails = new StatusDetails();
    CaseOwnerStatusAndDeadlineDate caseOwnerStatusAndDeadlineDate;
    final AppealCaseStatusDetails appealCaseStatusDtls =
      new AppealCaseStatusDetails();
    AppealCaseID entityAppealCaseID;
    final curam.appeal.sl.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.struct.AppealCaseID();
    DeadlineDate deadlineDate;

    // Hearing Schedule Variables
    final HearingSchedule hearingScheduleObj =
      HearingScheduleFactory.newInstance();

    // Appeal relationship objects
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Case Event manipulation variables
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseTypeConcernRoleAndConcernRoleType caseTypeConcernRoleAndConcernRoleType =
      new CaseTypeConcernRoleAndConcernRoleType();

    // Notification variables
    final curam.core.intf.Notification notificationObj =
      curam.core.fact.NotificationFactory.newInstance();

    // StandardManualTask details
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Today's date
    final Date currentDate = curam.util.type.Date.getCurrentDate();

    final CaseIDDeadlineDate caseIDDeadlineDate = new CaseIDDeadlineDate();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Determine the appealCaseID for the appealed case
    appealRelationshipKey.appealRelationshipID = dtls.appealRelationshipID;
    entityAppealCaseID =
      appealRelationshipObj.readAppealCaseID(appealRelationshipKey);

    // Validate security for approving an appeal case
    validateSecurityKey.caseID = entityAppealCaseID.appealCaseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kApproveSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Determine the appealCaseID for the appealed case
    appealCaseIDKey.caseID = entityAppealCaseID.appealCaseID;

    appealCaseID.caseID = entityAppealCaseID.appealCaseID;
    appealCaseIDKey.caseID = entityAppealCaseID.appealCaseID;

    caseOwnerStatusAndDeadlineDate =
      appealObj.readCaseOwnerStatusAndDeadlineDate(appealCaseIDKey);
    // BEGIN, CR00053295, RKi
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    orgObjectLinkKey.orgObjectLinkID =
      caseOwnerStatusAndDeadlineDate.ownerOrgObjectLinkID;
    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
    // END, CR00053295

    appealCaseStatusDtls.statusCode =
      caseOwnerStatusAndDeadlineDate.statusCode;
    validateApprove(appealCaseStatusDtls, dtls);

    // Update the status code to APPROVED
    statusDetails.statusCode = APPEALRELATIONSHIPSTATUS.APPROVED;
    statusDetails.versionNo = dtls.versionNo;
    appealRelationshipObj.modifyStatusCode(appealRelationshipKey,
      statusDetails);

    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = entityAppealCaseID.appealCaseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.APPEALEDCASEAPPROVED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;

    // Insert the case event
    caseEventObj.insert(caseEventDtls);

    // check type and status of appeal case
    caseHeaderKey.caseID = entityAppealCaseID.appealCaseID;

    caseTypeConcernRoleAndConcernRoleType =
      caseHeaderObj.readCaseTypeConcernRoleAndConcernRoleType(caseHeaderKey);

    // If this is the first appealed case being approved, update the overall
    // appeal case status to 'approved'.
    if (caseOwnerStatusAndDeadlineDate.statusCode.equals(CASESTATUS.OPEN)) {

      // Update appeal case status details
      final UpdateAppealCaseStatusDetails updateAppealCaseStatusDetails =
        new UpdateAppealCaseStatusDetails();

      updateAppealCaseStatusDetails.statusCode = CASESTATUS.APPROVED;
      updateAppealCaseStatusDetails.versionNo = dtls.caseHeaderVersionNo;
      updateAppealCaseStatusDetails.caseID = entityAppealCaseID.appealCaseID;

      appeal_boObj.updateCaseStatus(updateAppealCaseStatusDetails);

      // Create a case event for the appeal case itself
      caseEventDtls.caseEventID = uniqueIDObj.getNextID();
      caseEventDtls.caseID = appealCaseID.caseID;
      caseEventDtls.startDate = currentDate;
      caseEventDtls.endDate = currentDate;
      caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
      caseEventDtls.eventTypeCode = CASEEVENTTYPE.APPEALAPPROVED;
      caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;

      // Insert the case event
      caseEventObj.insert(caseEventDtls);
    }

    // A notification is sent to case owner of the appeal case stating that
    // the appeal case has being approved. A check to ensure current user is
    // not the user to whom the notification is being sent is carried out.
    if (!caseOwnerDetails.userName
      .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

      standardManualTaskDtls.dtls.concerningDtls.caseID =
        caseHeaderKey.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOHEARINGCASEAPPROVAL.INF_HEARING_CASE_APPROVAL_FV_APPROVEHEARINGSUBJECT
          .getMessageText();

      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userName;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseTypeConcernRoleAndConcernRoleType.concernRoleID;

      // BEGIN, CR00053295, RKi
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295
    }

    // Create dead line task for the schedule hearing
    appealCaseID.caseID = entityAppealCaseID.appealCaseID;
    hearingScheduleObj.createScheduleHearingTask(appealCaseID);

    // Recalculate the overall appeal deadline date to determine if the approval
    // of the the appealed case affects the overall appeal deadline.
    appealCaseKey.caseID = appealCaseIDKey.caseID;
    deadlineDate = appeal_boObj.calculateDeadlineDate(appealCaseKey);

    // If the deadline date has changed, update the overall deadline date
    if (!deadlineDate.date
      .equals(caseOwnerStatusAndDeadlineDate.deadlineDate)) {

      // Variables to update deadline date and task details
      final ModifyDeadlineDateDetails modifyDeadlineDateDetails =
        new ModifyDeadlineDateDetails();

      modifyDeadlineDateDetails.deadlineDate = deadlineDate.date;
      modifyDeadlineDateDetails.versionNo = dtls.appealVersionNo;
      appealObj
        .modifyDeadlineDate(appealCaseIDKey, modifyDeadlineDateDetails);

      // A notification is sent to case owner of the appeal case stating
      // that the overall deadline date for the appeal case has changed
      if (!caseOwnerDetails.userName
        .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          caseHeaderKey.caseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          GeneralAppealConstants.kSpace;
        standardManualTaskDtls.dtls.taskDtls.subject =
          BPOAPPEAL.INF_APPEAL_FV_APPEALCASEDEADLINECHANGED.getMessageText();

        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userName;
        standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
          caseTypeConcernRoleAndConcernRoleType.concernRoleID;

        notificationObj
          .createWorkAllocationNotification(standardManualTaskDtls);

      }

      // update the schedule hearing task
      hearingScheduleObj.modifyScheduleHearingTask(appealCaseID);
    }

  }

}
