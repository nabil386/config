/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.DecisionRejectionDtls;
import curam.message.BPODECISIONREJECTION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.type.Date;

/**
 * A history of the rejections of decisions made in hearings.
 */
public abstract class DecisionRejection extends
  curam.appeal.sl.entity.base.DecisionRejection {

  // ___________________________________________________________________________
  /**
   * Generates a unique appealID.
   * 
   * @param details The decision details
   */
  @Override
  protected void preinsert(final DecisionRejectionDtls details)
    throws AppException, InformationalException {

    // Validate the decision details
    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates the decision details
   * 
   * @param details The decision details to be validated
   */
  @Override
  protected void validate(final DecisionRejectionDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // case must be specified
    if (details.caseID == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONREJECTION.ERR_DECISIONREJECTION_FV_CASEMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Date must be provided
    if (details.rejectionDate.equals(Date.kZeroDate)) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONREJECTION.ERR_DECISIONREJECTION_FV_DATEMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Reason must be provided
    if (details.reasonCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONREJECTION.ERR_DECISIONREJECTION_FV_DECISIONREASONMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // User must be provided
    if (details.userName.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISIONREJECTION.ERR_DECISIONREJECTION_FV_USERMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();
  }

}
