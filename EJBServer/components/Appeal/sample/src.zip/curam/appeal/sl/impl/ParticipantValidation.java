/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012, 2016. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.struct.CaseIDParticipantRoleIDKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleAndStatusKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoTypeCodeList;
import curam.message.BPOAPPEAL;
import curam.message.BPOHEARINGTRANSCRIBER;
import curam.message.BPOPARTICIPANTVALIDATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.HashSet;

/**
 * This process class provides methods for validating various types of
 * participants.
 */
@SuppressWarnings(GeneralAppealConstants.kUnchecked)
public abstract class ParticipantValidation extends
  curam.appeal.sl.base.ParticipantValidation {

  // Valid Type Codes for appellant
  public static HashSet stValidAppellantTypeCodes = new HashSet();

  // Valid Type Codes for respondent
  public static HashSet stValidRespondentTypeCodes = new HashSet();

  // Valid Type Codes for Third Party
  public static HashSet stValidThirdPartyTypeCodes = new HashSet();

  // Valid Type Codes for Transcription Requester
  public static HashSet stValidTranscriptionRequesterCodes = new HashSet();

  // ___________________________________________________________________________
  /**
   * Static initialization which populates each HashSet with valid participant
   * type codes.
   */
  static {

    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.DEFAULTCODE);
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.NOMINEE);
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.CARER);
    stValidAppellantTypeCodes
      .add(CASEPARTICIPANTROLETYPE.DEPENDENTCAREPAYMENT);
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.APPELLANT);
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.RESPONDENT);
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.CORRESPONDENT);
    // Begin, 161261, RA
    stValidAppellantTypeCodes.add(CASEPARTICIPANTROLETYPE.MEMBER);
    // End, 161261
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.DEFAULTCODE);
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.NOMINEE);
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.CARER);
    stValidRespondentTypeCodes
      .add(CASEPARTICIPANTROLETYPE.DEPENDENTCAREPAYMENT);
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.APPELLANT);
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.RESPONDENT);
    stValidRespondentTypeCodes.add(CASEPARTICIPANTROLETYPE.CORRESPONDENT);

    stValidThirdPartyTypeCodes.add(CASEPARTICIPANTROLETYPE.DEFAULTCODE);
    stValidThirdPartyTypeCodes.add(CASEPARTICIPANTROLETYPE.EMPLOYER);
    stValidThirdPartyTypeCodes.add(CASEPARTICIPANTROLETYPE.THIRDPARTY);

    stValidTranscriptionRequesterCodes
      .add(CASEPARTICIPANTROLETYPE.HEARINGREPRESENTATIVE);
    stValidTranscriptionRequesterCodes.add(CASEPARTICIPANTROLETYPE.APPELLANT);
    stValidTranscriptionRequesterCodes
      .add(CASEPARTICIPANTROLETYPE.RESPONDENT);
    stValidTranscriptionRequesterCodes
      .add(CASEPARTICIPANTROLETYPE.THIRDPARTY);
  }

  // ___________________________________________________________________________
  /**
   * Validates that the role for the appellant participant is valid.
   * 
   * @param key The participant role details
   */
  @Override
  public void validateAppellant(final CaseIDParticipantRoleIDKey key)
    throws AppException, InformationalException {

    // Case ParticipantRole Objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleAndStatusKey caseIDParticipantRoleAndStatusKey =
      new CaseIDParticipantRoleAndStatusKey();
    CaseParticipantRole_eoTypeCodeList caseParticipantRoleTypeCodeList = null;

    caseIDParticipantRoleAndStatusKey.caseID = key.caseID;
    caseIDParticipantRoleAndStatusKey.participantRoleID =
      key.participantRoleID;
    caseIDParticipantRoleAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get Case Participant Type
    caseParticipantRoleTypeCodeList =
      caseParticipantRoleObj
        .searchTypeByCaseIDParticipantRoleAndStatus(caseIDParticipantRoleAndStatusKey);

    if (caseParticipantRoleTypeCodeList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEAL.ERR_APPEAL_FV_PARTICIPANT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    boolean validRoleType = false;

    // Check Participant type code is valid for an Appellant
    for (int i = 0; i < caseParticipantRoleTypeCodeList.dtls.size(); i++) {
      if (stValidAppellantTypeCodes
        .contains(caseParticipantRoleTypeCodeList.dtls.item(i).typeCode)) {
        validRoleType = true;
        break;
      }
    }

    if (!validRoleType) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOPARTICIPANTVALIDATION.ERR_PARTICIPANT_VALIDATION_FV_INVALID_APPELLANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that the role for the respondent participant is valid.
   * 
   * @param key The participant role details
   */
  @Override
  public void validateRespondent(final CaseIDParticipantRoleIDKey key)
    throws AppException, InformationalException {

    // Case ParticipantRole Objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleAndStatusKey caseIDParticipantRoleAndStatusKey =
      new CaseIDParticipantRoleAndStatusKey();
    CaseParticipantRole_eoTypeCodeList caseParticipantRoleTypeCodeList = null;

    caseIDParticipantRoleAndStatusKey.caseID = key.caseID;
    caseIDParticipantRoleAndStatusKey.participantRoleID =
      key.participantRoleID;
    caseIDParticipantRoleAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get Case Participant Type
    caseParticipantRoleTypeCodeList =
      caseParticipantRoleObj
        .searchTypeByCaseIDParticipantRoleAndStatus(caseIDParticipantRoleAndStatusKey);

    if (caseParticipantRoleTypeCodeList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEAL.ERR_APPEAL_FV_PARTICIPANT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    boolean validRoleType = false;

    // Check Participant type code is valid for a Respondent
    for (int i = 0; i < caseParticipantRoleTypeCodeList.dtls.size(); i++) {
      if (stValidRespondentTypeCodes
        .contains(caseParticipantRoleTypeCodeList.dtls.item(i).typeCode)) {
        validRoleType = true;
        break;
      }
    }

    if (!validRoleType) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOPARTICIPANTVALIDATION.ERR_PARTICIPANT_VALIDATION_FV_INVALID_RESPONDENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that the role for the third party participant is valid.
   * 
   * @param key The participant role details
   */
  @Override
  public void validateThirdParty(final CaseIDParticipantRoleIDKey key)
    throws AppException, InformationalException {

    // Case ParticipantRole Objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleAndStatusKey caseIDParticipantRoleAndStatusKey =
      new CaseIDParticipantRoleAndStatusKey();
    CaseParticipantRole_eoTypeCodeList caseParticipantRoleTypeCodeList = null;

    caseIDParticipantRoleAndStatusKey.caseID = key.caseID;
    caseIDParticipantRoleAndStatusKey.participantRoleID =
      key.participantRoleID;
    caseIDParticipantRoleAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get Case Participant Type
    caseParticipantRoleTypeCodeList =
      caseParticipantRoleObj
        .searchTypeByCaseIDParticipantRoleAndStatus(caseIDParticipantRoleAndStatusKey);

    if (caseParticipantRoleTypeCodeList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEAL.ERR_APPEAL_FV_PARTICIPANT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    boolean validRoleType = false;

    // Check Participant type code is valid for a Third Party
    for (int i = 0; i < caseParticipantRoleTypeCodeList.dtls.size(); i++) {
      if (stValidThirdPartyTypeCodes
        .contains(caseParticipantRoleTypeCodeList.dtls.item(i).typeCode)) {
        validRoleType = true;
        break;
      }
    }

    if (!validRoleType) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOPARTICIPANTVALIDATION.ERR_PARTICIPANT_VALIDATION_FV_INVALID_THIRD_PARTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that the role for the requester participant is valid.
   * 
   * @param key The participant role details
   */
  @Override
  public void validateTranscriptionRequester(
    final CaseIDParticipantRoleIDKey key) throws AppException,
    InformationalException {

    // Case ParticipantRole Objects
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleAndStatusKey caseIDParticipantRoleAndStatusKey =
      new CaseIDParticipantRoleAndStatusKey();
    CaseParticipantRole_eoTypeCodeList caseParticipantRoleTypeCodeList = null;

    caseIDParticipantRoleAndStatusKey.caseID = key.caseID;
    caseIDParticipantRoleAndStatusKey.participantRoleID =
      key.participantRoleID;
    caseIDParticipantRoleAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get Case Participant Type
    caseParticipantRoleTypeCodeList =
      caseParticipantRoleObj
        .searchTypeByCaseIDParticipantRoleAndStatus(caseIDParticipantRoleAndStatusKey);

    if (caseParticipantRoleTypeCodeList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGTRANSCRIBER.ERR_HEARING_TRANSCRIBER_FV_TRANSCRIPT_REQUESTER_NOT_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    boolean validRoleType = false;

    // Check Participant type code is valid for a Transcription Requester
    for (int i = 0; i < caseParticipantRoleTypeCodeList.dtls.size(); i++) {
      if (stValidTranscriptionRequesterCodes
        .contains(caseParticipantRoleTypeCodeList.dtls.item(i).typeCode)) {
        validRoleType = true;
        break;
      }
    }

    if (!validRoleType) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOPARTICIPANTVALIDATION.ERR_PARTICIPANT_VALIDATION_FV_INVALID_REQUESTER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

}
