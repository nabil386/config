/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.AppealedCaseRejectionDtls;
import curam.core.impl.CuramConst;
import curam.message.BPOAPPEALEDCASEREJECTION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * Maintains the individual rejections and their reasons for appealed cases.
 */
public abstract class AppealedCaseRejection extends
  curam.appeal.sl.entity.base.AppealedCaseRejection {

  // ___________________________________________________________________________
  /*
   * Ensures that the insertion of a new AppealedCaseRejection record is valid.
   */
  @Override
  protected void validate(final AppealedCaseRejectionDtls dtls)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Appeal relationship ID must be provided
    if (dtls.appealRelationshipID == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASEREJECTION.ERR_APPEAL_FV_RELATIONSHIPID),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Appeal reason code must be provided
    if (dtls.reasonCode.length() <= 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASEREJECTION.ERR_APPEAL_FV_REASONCODE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // User name must be provided
    if (dtls.userName.length() <= 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASEREJECTION.ERR_APPEAL_FV_USERNAME), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Date must be provided
    if (dtls.rejectionDate.isZero()) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALEDCASEREJECTION.ERR_APPEAL_FV_DATE), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /*
   * Performs the required validation prior to an insert of a new record.
   */
  @Override
  protected void preinsert(final AppealedCaseRejectionDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

}
