/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.struct.HearingCaseIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingIDCaseParticipantRoleIDStatusHR;
import curam.appeal.sl.entity.struct.HearingIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingParticipationAndStatus;
import curam.appeal.sl.entity.struct.HearingRepresentativeCloneDetails;
import curam.appeal.sl.entity.struct.HearingRepresentativeDtls;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDKey;
import curam.appeal.sl.entity.struct.ModifyHearingRepresentativeDetails;
import curam.appeal.sl.entity.struct.ReadHearingRepresentativeDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.BPOHEARINGREPRESENTATIVE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;

/**
 * This process class provides the functionality for the Hearing
 * Representative entity layer.
 * 
 */
public abstract class HearingRepresentative extends
  curam.appeal.sl.entity.base.HearingRepresentative {

  // ___________________________________________________________________________
  /**
   * validate entity data for insert operation
   * 
   * @param dtls the details to validate
   */
  @Override
  protected void validateInsert(final HearingRepresentativeDtls dtls)
    throws AppException, InformationalException {

    validate(dtls);
  }

  // ___________________________________________________________________________
  /**
   * validate entity data for update operation
   * 
   * @param dtls the details to validate
   */

  @Override
  protected void
    validateModify(final ModifyHearingRepresentativeDetails dtls)
      throws AppException, InformationalException {

    // HearingRepresentativeDtls object
    final HearingRepresentativeDtls hearingRepresentativeDtlsObj =
      new HearingRepresentativeDtls();

    hearingRepresentativeDtlsObj.assign(dtls);
    validate(hearingRepresentativeDtlsObj);
  }

  // ___________________________________________________________________________
  /**
   * validate entity data
   * 
   * @param dtls contains the details of the hearing representative
   */
  @Override
  protected void validate(final HearingRepresentativeDtls dtls)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // type must be supplied
    if (dtls.typeCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_TYPEEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }
    // behalf of must be supplied
    if (dtls.behalfOfCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPOHEARINGREPRESENTATIVE.ERR_HEARINGREPRESENTATIVE_FV_BEHALFOFEMPTY),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }
    // invalid fee amount entered
    if (dtls.feeAmount.isNegative()) {

      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOHEARINGREPRESENTATIVE.INF_HEARINGREPRESENTATIVE_FV_FEEAMOUNTINVALID),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);

    }

    // Log all exceptions (if any)
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing representatives
   * 
   * @param key contains the hearingCaseID and the status to search on
   */
  @Override
  protected void
    presearchActiveHearingRepAndCaseParticipantRoleByHearingCaseID(
      final HearingCaseIDStatusKeyHR key) throws AppException,
      InformationalException {

    key.recordStatus = RECORDSTATUS.DEFAULTCODE;
  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing representatives
   * 
   * @param key contains the hearingID and the status to search on
   */
  @Override
  protected void presearchActiveHearingRepAndCaseParticipantRoleByHearingID(
    final HearingIDStatusKeyHR key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.DEFAULTCODE;
  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to count active hearing representatives
   * 
   * @param key contains the hearingID and the status to search on
   */
  @Override
  protected void precountActiveByHearingIDCaseParticipantRoleID(
    final HearingIDCaseParticipantRoleIDStatusHR key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.DEFAULTCODE;
  }

  // ___________________________________________________________________________
  /**
   * sets the recordStatus to search active hearing representatives
   * 
   * @param key contains the hearingID and the status to search on
   */
  protected void presearchActiveByHearingID(final HearingIDStatusKeyHR key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.DEFAULTCODE;
  }

  // ___________________________________________________________________________
  /**
   * ensures validations are performed
   * 
   * @param details the details to validate
   */
  @Override
  protected void preinsert(final HearingRepresentativeDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * ensures validations are performed
   * 
   * @param key contains the representative id of the record being modified
   * @param details the details to validate
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyDetails method.
    protected
    void premodifyDetails(final HearingRepresentativeIDKey key,
      final ModifyHearingRepresentativeDetails details) throws AppException,
      InformationalException {

    validateModify(details);
  }

  // ___________________________________________________________________________
  /**
   * Sets the fields so that all non participants are updated to no-show
   * 
   * @param key contains the hearing ID and the participation code to search on
   * @param details contains the new participation code
   */
  @Override
  protected void premodifyNonParticipation(
    final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    key.participatedCode = HEARINGPARTICIPATION.NOTHELD;
    details.participatedCode = HEARINGPARTICIPATION.NOSHOW;

  }

  // ___________________________________________________________________________
  /**
   * Clones a hearing representative.
   * 
   * @param key The unique identifier of the hearing representative being
   * cloned.
   * @param details The unique identifier of the hearing for which the cloned
   * representative is being created.
   */
  @Override
  public void clone(final HearingRepresentativeIDKey key,
    final HearingKey details) throws AppException, InformationalException {

    // Hearing Representative details
    final curam.appeal.sl.entity.intf.HearingRepresentative hearingRepresentativeObj =
      curam.appeal.sl.entity.fact.HearingRepresentativeFactory.newInstance();
    final HearingRepresentativeDtls hearingRepresentativeDtls =
      new HearingRepresentativeDtls();

    // clone details
    final HearingRepresentativeCloneDetails hearingRepresentativeCloneDetails =
      readCloneDetails(key);

    // assign details for insert
    hearingRepresentativeDtls.behalfOfCode =
      hearingRepresentativeCloneDetails.behalfOfCode;
    hearingRepresentativeDtls.caseParticipantRoleID =
      hearingRepresentativeCloneDetails.caseParticipantRoleID;
    hearingRepresentativeDtls.comments =
      hearingRepresentativeCloneDetails.comments;
    hearingRepresentativeDtls.feeAmount =
      hearingRepresentativeCloneDetails.feeAmount;
    hearingRepresentativeDtls.feeApprovedCode =
      hearingRepresentativeCloneDetails.feeApprovedCode;
    hearingRepresentativeDtls.typeCode =
      hearingRepresentativeCloneDetails.typeCode;
    hearingRepresentativeDtls.hearingID = details.hearingID;

    // set default data
    hearingRepresentativeDtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

    // insert hearing representative
    hearingRepresentativeObj.insert(hearingRepresentativeDtls);

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readDetailsAndName
   */
  @Override
  public ReadHearingRepresentativeDetails read(
    final HearingRepresentativeIDKey key) throws AppException,
    InformationalException {

    return HearingRepresentativeFactory.newInstance().readDetailsAndName(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyDetails
   */
  @Override
  public void modify(final HearingRepresentativeIDKey key,
    final ModifyHearingRepresentativeDetails dtls) throws AppException,
    InformationalException {

    HearingRepresentativeFactory.newInstance().modifyDetails(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyNonParticipation
   */
  @Override
  public void updateNonParticipation(final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    HearingRepresentativeFactory.newInstance().modifyNonParticipation(key,
      details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing representatives are considered when
   * determining the number of representatives for a hearing with a specified
   * participation.
   * 
   * @param key The hearingID, participationCode and recordStatus to read for
   */
  @Override
  protected void precountActiveByHearingAndParticipation(
    final HearingParticipationAndStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

}
