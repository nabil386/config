/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingTranscriptionByStatusKey;
import curam.appeal.sl.entity.struct.HearingTranscriptionRequestDtls;
import curam.appeal.sl.entity.struct.HearingTranscriptionRequestKey;
import curam.appeal.sl.entity.struct.TranscriptionCaseStatusDetails;
import curam.appeal.sl.entity.struct.TranscriptionModifyDetails;
import curam.appeal.sl.entity.struct.TranscriptionRequestCloneDetails;
import curam.appeal.sl.entity.struct.TranscriptionRequestIDKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.message.BPOHEARINGTRANSCRIPTIONREQUEST;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;

public abstract class HearingTranscriptionRequest extends
  curam.appeal.sl.entity.base.HearingTranscriptionRequest {

  // ___________________________________________________________________________
  /**
   * Set the default values for the hearing transcription request details.
   * 
   * @param dtls Hearing Transcription Request details
   */
  @Override
  protected void setDefaults(final HearingTranscriptionRequestDtls dtls)
    throws AppException, InformationalException {

    dtls.recordStatusCode = RECORDSTATUS.NORMAL;
    dtls.dateSentToTranscriber = Date.kZeroDate;
    dtls.dateSentToRequester = Date.kZeroDate;
    dtls.dateDue = Date.kZeroDate;
    dtls.dateReceivedFromTranscriber = Date.kZeroDate;
    dtls.caseAttachmentLinkID = 0;

  }

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Transcription Request Details
   * 
   * @param dtls Hearing Transcription Request details
   */
  protected void validateInsert(final HearingTranscriptionRequestDtls dtls)
    throws AppException, InformationalException {

    // Case Participant Role ID of the Requester must be specified
    if (dtls.requestedByID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_FV_REQUESTEDBYID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the Hearing Transcription Request Details
   * 
   * @param details Hearing Transcription Request details
   */
  @Override
  protected void preinsert(final HearingTranscriptionRequestDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures that record status is set to 'normal'
   * 
   * @param key Hearing transcription key
   */
  protected void prereadActiveByHearingID(
    final HearingTranscriptionByStatusKey key) throws AppException,
    InformationalException {

    key.recordStatusCode = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Clones the Hearing Transcription Request Details
   * 
   * @param key Transcription Request identifier
   * @param dtls Hearing identifier
   */
  @Override
  public void clone(final TranscriptionRequestIDKey key,
    final HearingKeyDetails dtls) throws AppException, InformationalException {

    // Hearing Transcription Request manipulation variables
    TranscriptionRequestCloneDetails transcriptionRequestCloneDetails;
    final HearingTranscriptionRequestDtls hearingTranscriptionRequestDtls =
      new HearingTranscriptionRequestDtls();

    transcriptionRequestCloneDetails = readCloneDetails(key);

    // Map data
    hearingTranscriptionRequestDtls.transcriberID =
      transcriptionRequestCloneDetails.transcriberID;
    hearingTranscriptionRequestDtls.requestedByID =
      transcriptionRequestCloneDetails.requestedByID;
    hearingTranscriptionRequestDtls.dateRequested =
      transcriptionRequestCloneDetails.dateRequested;

    // Set default data
    setDefaults(hearingTranscriptionRequestDtls);

    // Set Hearing identifier
    hearingTranscriptionRequestDtls.hearingID = dtls.hearingID;

    // Insert Hearing Transcription Request record
    insert(hearingTranscriptionRequestDtls);

  }

  // ___________________________________________________________________________
  /**
   * Validates the hearing request transcription modify details
   * 
   * @param key The hearingTranscriptionRequestID
   * @param details Transcription modify details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modifyDetails method.
    protected
    void premodifyDetails(final HearingTranscriptionRequestKey key,
      final TranscriptionModifyDetails details) throws AppException,
      InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates the hearing request transcription modify details by ensuring
   * that the requester is provided
   * 
   * @param details Transcription Modify details
   */
  @Override
  protected void validate(final TranscriptionModifyDetails details)
    throws AppException, InformationalException {

    if (details.requestedByID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGTRANSCRIPTIONREQUEST.ERR_HEARINGTRANSCRIPTIONREQUEST_FV_REQUESTEDBYID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Ensures that the countReceivedTranscriptsByCase method is used correctly.
   * Only completed hearings should be searched for and the
   * dateReceivedFromTranscriber date needs to be initialized so that it is
   * null.
   * 
   * @param key The hearingID, received date and hearing status code
   */
  @Override
  protected void precountReceivedTranscriptsByCase(
    final TranscriptionCaseStatusDetails key) throws AppException,
    InformationalException {

    key.statusCode = HEARINGSTATUS.COMPLETED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that the search for transcription requests for a hearing only
   * returns 'active' records.
   * 
   * @param key The hearingID and recordStatus to read for.
   */
  @Override
  protected void presearchActiveByHearingID(
    final HearingTranscriptionByStatusKey key) throws AppException,
    InformationalException {

    key.recordStatusCode = RECORDSTATUS.NORMAL;
  }

}
