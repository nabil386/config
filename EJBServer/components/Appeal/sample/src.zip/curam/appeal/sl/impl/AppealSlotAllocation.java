/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2006 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.fact.HearingFactory;
import curam.appeal.sl.intf.Hearing;
import curam.appeal.sl.struct.HearingDurationDetails;
import curam.codetable.CASETYPECODE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.sl.struct.DetermineWorkItemKey;
import curam.core.sl.struct.UserWorkItemDetails;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;

/**
 * This process class is an extension of the SlotAllocation class for use in
 * Appeals.
 */
public abstract class AppealSlotAllocation extends
  curam.appeal.sl.base.AppealSlotAllocation {

  // ___________________________________________________________________________
  /**
   * Method to calculate work item duration and number of work units for
   * particular user.
   * 
   * @param determineWorkItemKey - key to to calculate work item duration and
   * number of work units
   * 
   * @return work item duration and number of work units
   */
  @Override
  public UserWorkItemDetails determineNumberOfUnitsAndDurationForUser(
    final DetermineWorkItemKey determineWorkItemKey) throws AppException,
    InformationalException {

    // Work item object
    final UserWorkItemDetails userWorkItemDetails = new UserWorkItemDetails();

    // Hearing objects
    final Hearing hearing_boObj = HearingFactory.newInstance();
    HearingDurationDetails hearingDurationDetails;
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // CaseHeader objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode = new CaseTypeCode();

    // Get default scheduling work item duration
    String strDefaultDuration =
      curam.util.resources.Configuration
        .getProperty(EnvVars.ENV_DEFAULT_SCHEDULING_WORK_ITEM_DURATION);

    if (strDefaultDuration == null) {

      strDefaultDuration =
        curam.core.impl.EnvVars.ENV_DEFAULT_SCHEDULING_WORK_ITEM_DURATION_DEFAULT;

    }

    // Throw an exception if default duration is an invalid number
    try {

      userWorkItemDetails.workItemDuration =
        Integer.parseInt(strDefaultDuration);

    } catch (final NumberFormatException e) {

      throw new AppException(
        curam.message.BPOSLOTALLOCATION.ERR_SLOTALLOCATION_FV_DEFAULT_SCHEDULING_WORK_ITEM_DURATION_INVALID);

    }

    // Assign original details to output
    userWorkItemDetails.userName = determineWorkItemKey.userName;
    userWorkItemDetails.numWorkUnits = determineWorkItemKey.numWorkUnits;

    // Check if related ID is an appeal case
    if (determineWorkItemKey.relatedID != 0) {

      // Case indicator
      boolean caseInd = true;

      caseKey.caseID = determineWorkItemKey.relatedID;

      try {

        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      } catch (final RecordNotFoundException e) {

        caseInd = false;

      }

      // If the related ID refers to a case, check the type
      if (caseInd) {
        // BEGIN CR00117296 LP
        // Use hearing duration details for appeal cases
        if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)
          || caseTypeCode.caseTypeCode.equals(CASETYPECODE.CFSS_LEGALACTION)) {

          // Set appeal case ID
          appealCaseIDKey.caseID = determineWorkItemKey.relatedID;

          // Get duration for hearings
          hearingDurationDetails = hearing_boObj.getDuration(appealCaseIDKey);

          // Set work item details
          userWorkItemDetails.numWorkUnits =
            hearingDurationDetails.numberOfWorkUnits;
          userWorkItemDetails.workItemDuration =
            hearingDurationDetails.duration;

        }
      }
    }

    // Return work item details
    return userWorkItemDetails;

  }

}
