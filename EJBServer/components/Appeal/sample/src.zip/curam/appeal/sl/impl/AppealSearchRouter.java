/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.fact.DatabaseAppealSearchFactory;
import curam.appeal.sl.intf.AppealSearch;
import curam.appeal.sl.struct.AppealSearchKey;
import curam.appeal.sl.struct.AppealSearchResultList;
import curam.codetable.APPELLANTTYPE;
import curam.message.BPOAPPEALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Provides methods which will route appeal searches to the appropriate
 * search engine based on environment settings
 * 
 */
public abstract class AppealSearchRouter extends
  curam.appeal.sl.base.AppealSearchRouter {

  // ___________________________________________________________________________
  /**
   * The information provider search object
   */
  protected static AppealSearch appealSearchObj;

  static {
    // Create database search obj,
    appealSearchObj = DatabaseAppealSearchFactory.newInstance();
  }

  // ___________________________________________________________________________
  /**
   * Performs an appeal search on the appropriate implementation.
   * 
   * @param key Search criteria for the appeal search
   * 
   * @return The details of any records found
   */
  @Override
  public AppealSearchResultList search(final AppealSearchKey key)
    throws AppException, InformationalException {

    // Trim space characters from the beginning and end of search criteria
    key.caseReference = key.caseReference.trim();

    validateSearchCriteria(key);

    return appealSearchObj.search(key);

  }

  // ___________________________________________________________________________
  /**
   * Performs validation on the search criteria specified
   * 
   * @param key Search criteria for the appeal search
   */
  @Override
  protected void validateSearchCriteria(final AppealSearchKey key)
    throws AppException, InformationalException {

    // Check if any search criteria was provided
    if (key.caseReference.length() == 0 && key.appellantID == 0
      && key.respondentID == 0 && key.appellantType.length() == 0
      && key.respondentType.length() == 0 && key.appealType.length() == 0
      && key.hearingDate.isZero() && key.creationDate.isZero()
      && key.status.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOAPPEALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Status must be used in conjunction with another field
    if (key.caseReference.length() == 0 && key.appellantID == 0
      && key.respondentID == 0 && key.appellantType.length() == 0
      && key.respondentType.length() == 0 && key.appealType.length() == 0
      && key.hearingDate.isZero() && key.creationDate.isZero()
      && key.status.length() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_ADDITIONAL_CRITERIA_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

    // Appeal Type must be used in conjunction with another field
    if (key.caseReference.length() == 0 && key.appellantID == 0
      && key.respondentID == 0 && key.appellantType.length() == 0
      && key.respondentType.length() == 0 && key.appealType.length() != 0
      && key.hearingDate.isZero() && key.creationDate.isZero()
      && key.status.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_ADDITIONAL_CRITERIA_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Appellant type of organization must be used in conjunction with another
    // field
    if (key.caseReference.length() == 0 && key.appellantID == 0
      && key.respondentID == 0
      && APPELLANTTYPE.ORGANIZATION.equals(key.appellantType)
      && key.respondentType.length() == 0 && key.appealType.length() == 0
      && key.hearingDate.isZero() && key.creationDate.isZero()
      && key.status.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_ADDITIONAL_CRITERIA_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    // Respondent type of organization must be used in conjunction with another
    // field
    if (key.caseReference.length() == 0 && key.appellantID == 0
      && key.respondentID == 0 && key.appellantType.length() == 0
      && APPELLANTTYPE.ORGANIZATION.equals(key.respondentType)
      && key.appealType.length() == 0 && key.hearingDate.isZero()
      && key.creationDate.isZero() && key.status.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_ADDITIONAL_CRITERIA_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Appellant name must be specified if appellant type is CLIAMANT
    if (APPELLANTTYPE.CLAIMANT.equals(key.appellantType)
      && key.appellantID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_APPELLANT_NAME_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Respondent name must be specified if respondent type is CLIAMANT
    if (APPELLANTTYPE.CLAIMANT.equals(key.respondentType)
      && key.respondentID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_RESPONDENT_NAME_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Appellant type of CLIAMANT must be specified if appellant name is
    // supplied
    if (key.appellantID != 0 && key.appellantType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_APPELLANT_TYPE_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Respondent type of CLIAMANT must be specified if respondent name is
    // supplied
    if (key.respondentID != 0 && key.respondentType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_RESPONDENT_TYPE_REQUIRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Cannot specify an appellant name when the organization is the appellant.
    if (key.appellantID != 0
      && APPELLANTTYPE.ORGANIZATION.equals(key.appellantType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_APPELLANT_PARTICIPANT_AND_APPELLANT_AS_ORGANIZATION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Cannot specify a respondent name when the organization is the respondent.
    if (key.respondentID != 0
      && APPELLANTTYPE.ORGANIZATION.equals(key.respondentType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_RESPONDENT_PARTICIPANT_AND_RESPONDENT_AS_ORGANIZATION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Cannot specify both an appellant name and a respondent name.
    if (key.appellantID != 0 && key.respondentID != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_APPELLANT_AND_RESPONDENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Cannot specify the organization as both the appellant type and the
    // respondent type.
    if (APPELLANTTYPE.ORGANIZATION.equals(key.appellantType)
      && APPELLANTTYPE.ORGANIZATION.equals(key.respondentType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_APPELLANT_AND_RESPONDENT_TYPE_AS_ORGANIZATION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Can only search for hearing dates which are on or after the creation
    // date.
    if (!key.hearingDate.isZero() && !key.creationDate.isZero()) {
      if (key.hearingDate.before(key.creationDate)
        && !key.hearingDate.equals(key.creationDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOAPPEALSEARCH.ERR_APPEAL_SEARCH_FV_INVALID_HEARING_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }
}
