/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import curam.appeal.impl.AppealEvents;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.DecisionRejectionFactory;
import curam.appeal.sl.entity.fact.HearingDecisionAttachmentLinkFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.DecisionRejection;
import curam.appeal.sl.entity.intf.HearingDecision;
import curam.appeal.sl.entity.intf.HearingDecisionAttachmentLink;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.struct.ActiveAppealResolutionKey;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.ActiveDecisionAttachmentsKey;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCountDetails;
import curam.appeal.sl.entity.struct.AppealTypeDetails;
import curam.appeal.sl.entity.struct.AppealedCaseCountDetails;
import curam.appeal.sl.entity.struct.CaseIDAndDeadlineDate;
import curam.appeal.sl.entity.struct.CaseIDAndDeadlineDateList;
import curam.appeal.sl.entity.struct.DecisionRejectionCaseKey;
import curam.appeal.sl.entity.struct.DecisionRejectionDateReasonUserDetails;
import curam.appeal.sl.entity.struct.DecisionRejectionDateReasonUserDetailsList;
import curam.appeal.sl.entity.struct.DecisionRejectionDtls;
import curam.appeal.sl.entity.struct.DecisionRejectionKey;
import curam.appeal.sl.entity.struct.DecisionRejectionSummaryDetails;
import curam.appeal.sl.entity.struct.HearingCaseIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionStatusDetails;
import curam.appeal.sl.entity.struct.HearingDecisionStatusVersionDetails;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;
import curam.appeal.sl.entity.struct.IdAndResolutionDetails;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.struct.AppealDecisionVersionDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.DecisionApprovalIndicatorDetails;
import curam.appeal.sl.struct.DecisionApprovalUserDetails;
import curam.appeal.sl.struct.DecisionRejectionCaseKey_bo;
import curam.appeal.sl.struct.DecisionRejectionDetails;
import curam.appeal.sl.struct.DecisionRejectionListDetails;
import curam.appeal.sl.struct.DecisionRejectionReasonDetails;
import curam.appeal.sl.struct.HearingDecisionCaseDetails;
import curam.appeal.sl.struct.HearingDecisionNotifyDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGDECISIONRESOLUTION;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKPRIORITY;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CloseCaseFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.CloseCase;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.intf.ExternalUserParticipantLink;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleIDDetailsList;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseUserRoleCaseIDKey;
import curam.core.sl.entity.struct.CaseUserRoleDtlsList;
import curam.core.sl.entity.struct.CaseUserRoleSearchByCaseAndStatusAndTypeAndDate;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDtlsList;
import curam.core.sl.entity.struct.OrgObjLinkIDAndCaseUserRoleIDList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.ReadByCaseIDTypeAndStatusKey;
import curam.core.sl.fact.CaseTransactionLogFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.intf.CaseTransactionLog;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CreateStandardManualTaskDetails;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.sl.struct.TaskCreateDetails;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.OwnerID;
import curam.core.struct.UpdateCaseStatusReasonEndKey1;
import curam.core.struct.UserNameDetails;
import curam.core.struct.UsersKey;
import curam.message.BPODECISION;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.workflow.impl.EnactmentService;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;

/**
 * This process class provides the functionality for the Decision Approval
 * service layer.
 * 
 */
public abstract class DecisionApproval extends
  curam.appeal.sl.base.DecisionApproval {

  protected static final short kMinThirdParties = 1;

  // BEGIN, CR00424946, DM
  @Inject
  private AppealEvents appealEvents;

  public DecisionApproval() {

    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00424946

  // ___________________________________________________________________________
  /**
   * This method validates the details of a decision for approval
   * 
   * @param details
   * The details of the decision
   */
  @Override
  protected void validateApprove(
    final curam.appeal.sl.struct.HearingDecisionKey details)
    throws AppException, InformationalException {

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails;

    // Check that the decision has been submitted for approval
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;

    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    hearingDecisionObj.readCase(hearingDecisionKey);

    hearingDecisionStatusDetails =
      hearingDecisionObj.readStatus(hearingDecisionKey);

    // Check that decision has not been already approved
    if (hearingDecisionStatusDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISION.ERR_DECISION_XFV_APPROVAL_ALREADY_APPROVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!hearingDecisionStatusDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISION.ERR_DECISION_FV_APPROVE_WITHOUT_SUBMIT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method validates the details of a decision to be rejected
   * 
   * @param details
   * The details being validated of the case being rejected
   */
  @Override
  protected void validateReject(final DecisionRejectionDetails details)
    throws AppException, InformationalException {

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionStatusDetails hearingDecisionStatusDetails;

    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    // Read the decision status
    try {

      hearingDecisionStatusDetails =
        hearingDecisionObj.readStatus(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(
        curam.message.BPODECISIONAPPROVAL.ERR_FV_REJECT_NODECISION);
    }

    // Check that decision has not already been approved
    if (hearingDecisionStatusDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPODECISION.ERR_DECISION_XFV_REJECT_ALREADY_APPROVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!hearingDecisionStatusDetails.decisionStatus
      .equals(HEARINGDECISIONSTATUS.SUBMITTED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(curam.message.BPODECISION.ERR_DECISION_FV_REJECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method creates a rejected decision
   * 
   * @param details
   * The details of the decision
   */
  @Override
  public void createRejectedDecision(final DecisionRejectionDetails details)
    throws AppException, InformationalException {

    // CaseEvent object
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // DecisionRejection object
    final DecisionRejection decisionRejectionObj =
      DecisionRejectionFactory.newInstance();
    final DecisionRejectionDtls decisionRejectionDtls =
      new DecisionRejectionDtls();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    hearingDecisionCaseKey = hearingDecisionObj.readCase(hearingDecisionKey);

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.DECISIONREJECTED;
    caseEventDtls.startDate = Date.getCurrentDate();

    caseEventDtls.relatedID = hearingDecisionCaseKey.caseID;

    caseEventDtls.caseID = hearingDecisionCaseKey.caseID;

    caseEventObj.insert(caseEventDtls);

    final SystemUser systemUser = SystemUserFactory.newInstance();

    decisionRejectionDtls.reasonCode = details.reasonCode;
    decisionRejectionDtls.reasonText = details.reasonText;
    decisionRejectionDtls.caseID = hearingDecisionCaseKey.caseID;
    decisionRejectionDtls.decisionRejectionID = uniqueIDObj.getNextID();
    decisionRejectionDtls.rejectionDate = Date.getCurrentDate();
    decisionRejectionDtls.userName = systemUser.getUserDetails().userName;
    decisionRejectionDtls.versionNo = details.versionNo;

    decisionRejectionObj.insert(decisionRejectionDtls);

    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    hearingDecisionStatusVersionDetails.decisionStatus =
      HEARINGDECISIONSTATUS.REJECTED;
    hearingDecisionStatusVersionDetails.versionNo = details.versionNo;

    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);
    // BEGIN, CR00050118, RKi
    if (hearingDecisionCaseKey.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final CaseTransactionLog caseTransactionLog =
        CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingDecisionCaseKey.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.APPEALCASE_APPROVED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);
    }
    // END, CR00050118
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of decision rejections
   * 
   * @param key
   * Identifies the case
   * 
   * @return List of decision rejections
   */
  @Override
  public DecisionRejectionListDetails listRejectionReason(
    final DecisionRejectionCaseKey_bo key) throws AppException,
    InformationalException {

    // Return details
    final DecisionRejectionListDetails decisionRejectionListDetails =
      new DecisionRejectionListDetails();

    // Decision Rejection object
    final DecisionRejection decisionRejectionObj =
      DecisionRejectionFactory.newInstance();
    final DecisionRejectionCaseKey decisionRejectionCaseKey =
      new DecisionRejectionCaseKey();
    DecisionRejectionDateReasonUserDetailsList decisionRejectionDateReasonUserDetailsList;
    DecisionRejectionDateReasonUserDetails decisionRejectionDateReasonUserDetails;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = key.decisionRejectionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    decisionRejectionCaseKey.caseID = key.decisionRejectionCaseKey.caseID;
    decisionRejectionDateReasonUserDetailsList =
      decisionRejectionObj.searchByCase(decisionRejectionCaseKey);

    if (decisionRejectionDateReasonUserDetailsList.dtls.size() != 0) {

      decisionRejectionListDetails.decisionRejectionDateReasonUserDetails
        .ensureCapacity(decisionRejectionDateReasonUserDetailsList.dtls
          .size());

      for (int i = 0; i < decisionRejectionDateReasonUserDetailsList.dtls
        .size(); i++) {

        decisionRejectionDateReasonUserDetails =
          new DecisionRejectionDateReasonUserDetails();

        decisionRejectionDateReasonUserDetails.date =
          decisionRejectionDateReasonUserDetailsList.dtls.item(i).date;
        decisionRejectionDateReasonUserDetails.reasonCode =
          decisionRejectionDateReasonUserDetailsList.dtls.item(i).reasonCode;
        decisionRejectionDateReasonUserDetails.userFullName =
          decisionRejectionDateReasonUserDetailsList.dtls.item(i).userFullName;
        decisionRejectionDateReasonUserDetails.userName =
          decisionRejectionDateReasonUserDetailsList.dtls.item(i).userName;
        decisionRejectionDateReasonUserDetails.decisionRejectionID =
          decisionRejectionDateReasonUserDetailsList.dtls.item(i).decisionRejectionID;

        decisionRejectionListDetails.decisionRejectionDateReasonUserDetails
          .addRef(decisionRejectionDateReasonUserDetails);

      }

    }

    return decisionRejectionListDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method notifies an appellant
   * 
   * @param details
   * The details of the appeal case
   */
  @Override
  public void notifyAppellant(final HearingDecisionNotifyDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Todays date
    final Date currentDate = Date.getCurrentDate();

    // Search for active appellants
    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;
    caseParticipantRoleIDDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // BEGIN, CR00021002, RK

    if (caseParticipantRoleIDDetailsList.dtls.size() < kMinThirdParties) {

      return;
    }

    // Send notification to multiple appellant

    communicationDetails.subjectText =
      curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
        .getMessageText();
    communicationDetails.caseID = details.caseID;
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    // BEGIN, CR00236624, GBA
    final long correspondentID =
      CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID;

    // END, CR00236624

    // END, CR00202766
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.communicationDate = currentDate;

    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    final SystemUser systemUser = SystemUserFactory.newInstance();

    communicationDetails.userName = systemUser.getUserDetails().userName;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.APPEALDECISIONNOTICE;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    for (int i = 0; i < caseParticipantRoleIDDetailsList.dtls.size(); i++) {

      communicationDetails.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;

      // BEGIN, CR00236624, GBA
      if (correspondentID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00236624

      // Set the key to read the details
      concernRoleKey.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);
      communicationDetails.correspondentName =
        concernRoleNameDetails.concernRoleName;

      // Create the communication
      proFormaCommDetails.assign(communicationDetails);

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.caseID = details.caseID;

      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALDECISIONNOTICE;

      // Set data set key and type
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.DECISION_NOTICE;
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleIDDetailsList.dtls.item(i).caseParticipantRoleID;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

    // read the case header details to find out who the owner is
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    caseHeaderKey.caseID = details.caseID;

    // BEGIN, CR00303986, SG
    final OwnerID ownerID = caseHeaderObj.readCaseOwner(caseHeaderKey);

    orgObjectLinkKey.orgObjectLinkID = ownerID.ownerOrgObjectLinkID;
    // END, CR00303986

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

    // read the owner details (the task will be assigned to them)
    final UsersKey caseOwnerUserKey = new UsersKey();

    caseOwnerUserKey.userName = caseOwnerDetails.userFullName;

    // Create a task
    // Set the reason for the task
    createStandardManualTaskDetails.taskDtls.comments =
      curam.message.BPODECISION.INF_DECISION_TICKET_SUBJECT.getMessageText();

    createStandardManualTaskDetails.taskDtls.subject =
      curam.message.BPODECISION.INF_DECISION_NOTIFYAPPELLANT.getMessageText();

    // Set the priority for the task
    createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;

    createStandardManualTaskDetails.concerningDtls.caseID = details.caseID;
    createStandardManualTaskDetails.taskDtls.taskDefinitionID =
      curam.appeal.sl.impl.Appeal.kAppealStandardTask;

    // create the task
    workAllocationTaskObj.createTask(createStandardManualTaskDetails);

    // END, CR00021002

  }

  // ___________________________________________________________________________
  /**
   * This method changes the owner of a case
   * 
   * @param details
   * The case concerned
   */
  @Override
  public void notifyCaseOwner(final HearingDecisionCaseDetails details)
    throws AppException, InformationalException {

    // caseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // notification variables
    final Notification notificationObj = NotificationFactory.newInstance();
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    caseHeaderKey.caseID = details.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    orgObjectLinkKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;

    caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

    final SystemUser systemUser = SystemUserFactory.newInstance();

    if (!caseOwnerDetails.userName
      .equals(systemUser.getUserDetails().userName)) {

      final StandardManualTaskDtls standardManualTaskDtls =
        new StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;

      standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseHeaderDtls.concernRoleID;

      standardManualTaskDtls.dtls.taskDtls.subject =
        curam.message.BPODECISION.INF_DECISION_NOTIFYOWNER.getMessageText();

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;

      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
        curam.appeal.sl.impl.Appeal.kAppealNotificationTask;

      // BEGIN, CR00053295, RKi
      // Create notification
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295

    }

  }

  // ___________________________________________________________________________
  /**
   * This method notifies a representative about a hearing
   * 
   * @param details
   */
  @Override
  public void
    notifyRepresentatives(final HearingDecisionNotifyDetails details)
      throws AppException, InformationalException {

    // HearingRepresentative
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingCaseIDStatusKeyHR hearingCaseIDStatusKeyHR =
      new HearingCaseIDStatusKeyHR();
    HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    hearingCaseIDStatusKeyHR.hearingCaseID = details.caseID;
    hearingCaseIDStatusKeyHR.recordStatus = RECORDSTATUS.DEFAULTCODE;
    hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList =
      hearingRepresentativeObj
        .searchActiveHearingRepAndCaseParticipantRoleByHearingCaseID(hearingCaseIDStatusKeyHR);

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode = TEMPLATEIDCODE.APPEALDECISIONNOTICE;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final XSLTemplateUtility xslTemplateUtilityObj =
      XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    if (hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
      .size() != 0) {

      for (int i = 0; i < hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
        .size(); i++) {

        communicationDetails.subjectText =
          curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
            .getMessageText();
        communicationDetails.concernRoleID =
          hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
            .item(i).participantRoleID;
        communicationDetails.caseID = details.caseID;
        communicationDetails.correspondentConcernRoleID =
          hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
            .item(i).participantRoleID;
        // BEGIN, CR00202766, MC
        // correspondentTypeCode is not a mandatory entity field only set it if
        // the
        // correspondence is going to the primary client
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = details.caseID;

        if (CaseHeaderFactory.newInstance().readParticipantRoleID(
          caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
          communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
        }
        // END, CR00202766
        communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
        communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
        communicationDetails.communicationDate = Date.getCurrentDate();

        // Set the key to read the details
        concernRoleKey.concernRoleID =
          hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
            .item(i).participantRoleID;
        concernRoleNameDetails =
          concernRoleObj.readConcernRoleName(concernRoleKey);

        communicationDetails.correspondentName =
          concernRoleNameDetails.concernRoleName;
        communicationDetails.communicationText =
          GeneralAppealConstants.kSpace;
        final SystemUser systemUser = SystemUserFactory.newInstance();

        communicationDetails.userName = systemUser.getUserDetails().userName;

        // Create the communication
        proFormaCommDetails.assign(communicationDetails);
        proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
        proFormaCommDetails.proFormaVersionNo =
          xslTemplateInstanceKey.templateVersion;

        proFormaCommDetails.addressID =
          concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
        // BEGIN, CR00293187, CD
        generateDocumentDetails.communicationID =
          communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALDECISIONNOTICE;

        // Set data set key and type
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.DECISION_NOTICE;
        generateDocumentDetails.dtls.dataSetPrimaryKey =
          hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
            .item(i).caseParticipantRoleID;

        // Generate the document
        appealProFormaDocumentGenerationObj
          .createConcernRoleProFormaDoc(generateDocumentDetails);
        // END, CR00293187

        // Create a task
        // Set the reason for the task
        createStandardManualTaskDetails.taskDtls.comments =
          curam.message.BPODECISION.INF_DECISION_TICKET_SUBJECT
            .getMessageText();

        createStandardManualTaskDetails.taskDtls.subject =
          curam.message.BPODECISION.INF_DECISION_NOTIFYREPRESENTATIVE
            .getMessageText();

        // Set the priority for the task
        createStandardManualTaskDetails.taskDtls.priority =
          TASKPRIORITY.NORMAL;

        createStandardManualTaskDetails.concerningDtls.caseID =
          details.caseID;
        createStandardManualTaskDetails.taskDtls.taskDefinitionID =
          curam.appeal.sl.impl.Appeal.kAppealStandardTask;

        // create the task
        workAllocationTaskObj.createTask(createStandardManualTaskDetails);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * This method notifies third parties of the hearing decision
   * 
   * @param details
   * The details of the case
   */
  @Override
  public void notifyThirdParty(final HearingDecisionNotifyDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;
    caseParticipantRoleIDDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    if (caseParticipantRoleIDDetailsList.dtls.size() >= kMinThirdParties) {
      // BEGIN, CR00098417, RKi
      for (int i = 0; i < caseParticipantRoleIDDetailsList.dtls.size(); i++) {

        communicationDetails.subjectText =
          curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
            .getMessageText();
        communicationDetails.concernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
        communicationDetails.caseID = details.caseID;
        communicationDetails.correspondentConcernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
        // BEGIN, CR00202766, MC
        // correspondentTypeCode is not a mandatory entity field only set it if
        // the
        // correspondence is going to the primary client
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = details.caseID;

        if (CaseHeaderFactory.newInstance().readParticipantRoleID(
          caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
          communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
        }
        // END, CR00202766
        communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
        communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
        communicationDetails.communicationDate = Date.getCurrentDate();

        // Set the key to read the details
        concernRoleKey.concernRoleID =
          caseParticipantRoleIDDetailsList.dtls.item(i).participantRoleID;
        concernRoleNameDetails =
          concernRoleObj.readConcernRoleName(concernRoleKey);

        communicationDetails.correspondentName =
          concernRoleNameDetails.concernRoleName;
        communicationDetails.communicationText =
          GeneralAppealConstants.kSpace;
        final SystemUser systemUser = SystemUserFactory.newInstance();

        communicationDetails.userName = systemUser.getUserDetails().userName;

        // Create the communication
        final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
          new XSLTemplateIDCodeKey();

        xslTemplateIDCodeKey.templateIDCode =
          TEMPLATEIDCODE.APPEALDECISIONNOTICE;
        xslTemplateIDCodeKey.localeIdentifier =
          TransactionInfo.getProgramLocale();

        final XSLTemplateUtility xslTemplateUtilityObj =
          XSLTemplateUtilityFactory.newInstance();

        final XSLTemplateInstanceKey xslTemplateInstanceKey =
          xslTemplateUtilityObj
            .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

        proFormaCommDetails.assign(communicationDetails);

        proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
        proFormaCommDetails.proFormaVersionNo =
          xslTemplateInstanceKey.templateVersion;

        proFormaCommDetails.addressID =
          concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
        // BEGIN, CR00293187, CD
        generateDocumentDetails.communicationID =
          communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

        generateDocumentDetails.dtls.documentIDCode =
          TEMPLATEIDCODE.APPEALDECISIONNOTICE;

        // Set data set key and type
        generateDocumentDetails.dtls.dataSetType =
          DATASETTYPE.DECISION_NOTICE;
        generateDocumentDetails.dtls.dataSetPrimaryKey =
          caseParticipantRoleIDDetailsList.dtls.item(i).caseParticipantRoleID;

        // Generate the document
        appealProFormaDocumentGenerationObj
          .createConcernRoleProFormaDoc(generateDocumentDetails);
        // END, CR00293187

        // Create a task
        // Set the reason for the task
        createStandardManualTaskDetails.taskDtls.comments =
          curam.message.BPODECISION.INF_DECISION_TICKET_SUBJECT
            .getMessageText();

        createStandardManualTaskDetails.taskDtls.subject =
          curam.message.BPODECISION.INF_DECISION_NOTIFYTHIRDPARTY
            .getMessageText();

        // Set the priority for the task
        createStandardManualTaskDetails.taskDtls.priority =
          TASKPRIORITY.NORMAL;

        createStandardManualTaskDetails.concerningDtls.caseID =
          details.caseID;
        createStandardManualTaskDetails.taskDtls.taskDefinitionID =
          curam.appeal.sl.impl.Appeal.kAppealStandardTask;

        // create the task
        workAllocationTaskObj.createTask(createStandardManualTaskDetails);

      }
      // END, CR00098417
    }

  }

  // ___________________________________________________________________________
  /**
   * This method returns decision rejection details
   * 
   * @param key
   * Identifies the decision
   * 
   * @return Decision rejection details
   */
  @Override
  public DecisionRejectionReasonDetails readRejectionReason(
    final curam.appeal.sl.struct.DecisionRejectionKey key)
    throws AppException, InformationalException {

    // Return details
    final DecisionRejectionReasonDetails decisionRejectionReasonDetails =
      new DecisionRejectionReasonDetails();

    // DecisionRejection object
    final DecisionRejection decisionRejectionObj =
      DecisionRejectionFactory.newInstance();
    final DecisionRejectionKey decisionRejectionKey =
      new DecisionRejectionKey();
    DecisionRejectionSummaryDetails decisionRejectionSummaryDetails;

    decisionRejectionKey.decisionRejectionID = key.decisionRejectionID;

    // Read the details
    decisionRejectionSummaryDetails =
      decisionRejectionObj.readSummary(decisionRejectionKey);

    // Assign the details to the return struct
    decisionRejectionReasonDetails.decisionRejectionSummaryDetails =
      decisionRejectionSummaryDetails;

    // Return the details
    return decisionRejectionReasonDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method enables the user to reject a case decision
   * 
   * @param details
   * The details of the case decision
   */
  @Override
  public void reject(final DecisionRejectionDetails details)
    throws AppException, InformationalException {

    // HearingDecision object
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    final DecisionRejectionDetails decisionRejectionDetails =
      new DecisionRejectionDetails();

    // variables to see if user has rights to approve or reject
    final DecisionApprovalUserDetails decisionApprovalUserDetails =
      new DecisionApprovalUserDetails();
    DecisionApprovalIndicatorDetails decisionApprovalIndicatorDetails;

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for approving or rejecting an appeal decision
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(
        curam.message.BPODECISIONAPPROVAL.ERR_FV_REJECT_NODECISION);
    }
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kApproveDecisionSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    decisionRejectionDetails.hearingDecisionID = details.hearingDecisionID;
    decisionRejectionDetails.reasonCode = details.reasonCode;
    decisionRejectionDetails.reasonText = details.reasonText;
    decisionRejectionDetails.versionNo = details.versionNo;

    validateReject(decisionRejectionDetails);

    // check the user has right to reject
    final SystemUser systemUser = SystemUserFactory.newInstance();

    decisionApprovalUserDetails.userName =
      systemUser.getUserDetails().userName;
    decisionApprovalIndicatorDetails =
      userCanApproveCheck(decisionApprovalUserDetails);

    if (!decisionApprovalIndicatorDetails.approvalInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISION.ERR_DECISION_NO_REJECTION_RIGHTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    createRejectedDecision(decisionRejectionDetails);

  }

  // ___________________________________________________________________________
  /**
   * This method determines if a user can approve a decision
   * 
   * @param details
   * The users details
   * 
   * @return Decision approval indicator
   */
  @Override
  public DecisionApprovalIndicatorDetails userCanApproveCheck(
    final DecisionApprovalUserDetails details) throws AppException,
    InformationalException {

    // Return structure
    final DecisionApprovalIndicatorDetails decisionApprovalIndicatorDetails =
      new DecisionApprovalIndicatorDetails();

    // Appeal objects
    final Appeal appealObj = AppealFactory.newInstance();
    final UserNameDetails userNameDetails = new UserNameDetails();

    userNameDetails.userName = details.userName;

    if (appealObj.isSupervisor(userNameDetails).supervisorInd) {
      decisionApprovalIndicatorDetails.approvalInd = true;
    } else {
      decisionApprovalIndicatorDetails.approvalInd = false;
    }

    return decisionApprovalIndicatorDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method notifies an respondent
   * 
   * @param details
   * The details of the hearing decision
   */
  @Override
  public void notifyRespondent(final HearingDecisionNotifyDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Task manipulation variables
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // Todays date
    final Date currentDate = Date.getCurrentDate();

    // Search for active appellants
    caseParticipantRoleCaseAndTypeKey.caseID = details.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;
    caseParticipantRoleIDDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    if (caseParticipantRoleIDDetailsList.dtls.size() == kMinThirdParties) {

      communicationDetails.subjectText =
        curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
          .getMessageText();
      communicationDetails.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.caseID = details.caseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
      communicationDetails.communicationDate = currentDate;

      // Set the key to read the details
      concernRoleKey.concernRoleID =
        caseParticipantRoleIDDetailsList.dtls.item(0).participantRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      communicationDetails.correspondentName =
        concernRoleNameDetails.concernRoleName;
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;
      final SystemUser systemUser = SystemUserFactory.newInstance();

      communicationDetails.userName = systemUser.getUserDetails().userName;

      // Create the communication
      final XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALDECISIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final XSLTemplateUtility xslTemplateUtilityObj =
        XSLTemplateUtilityFactory.newInstance();

      final XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALDECISIONNOTICE;

      // Set data set key and type
      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.DECISION_NOTICE;
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleIDDetailsList.dtls.item(0).caseParticipantRoleID;
      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

      // Create a task
      // Set the reason for the task
      createStandardManualTaskDetails.taskDtls.comments =
        curam.message.BPODECISION.INF_DECISION_TICKET_SUBJECT
          .getMessageText();

      createStandardManualTaskDetails.taskDtls.subject =
        curam.message.BPODECISION.INF_DECISION_NOTIFYRESPONDENT
          .getMessageText();

      // Set the priority for the task
      createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;

      createStandardManualTaskDetails.concerningDtls.caseID = details.caseID;
      createStandardManualTaskDetails.taskDtls.taskDefinitionID =
        curam.appeal.sl.impl.Appeal.kAppealStandardTask;

      // create the task
      workAllocationTaskObj.createTask(createStandardManualTaskDetails);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates or updates an appeal case decision to approved. This results in the
   * overall appeal case being closed.
   * 
   * @param dtls
   * The details for approving an appeal decision
   */
  @Override
  protected void createApprovedDecision(
    final AppealDecisionVersionDetails dtls) throws AppException,
    InformationalException {

    // HearingDecision object and structs
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final HearingDecisionCaseDetails hearingDecisionCaseDetails =
      new HearingDecisionCaseDetails();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();
    final HearingDecisionNotifyDetails hearingDecisionNotifyDetails =
      new HearingDecisionNotifyDetails();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // CaseEvent object
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Appeal objects and structs
    final Appeal appeal_boObj = AppealFactory.newInstance();
    final CaseID caseID = new CaseID();

    // CloseCase object
    final CloseCase closeCaseObj = CloseCaseFactory.newInstance();
    // BEGIN, CR00236272, AK
    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey =
      new UpdateCaseStatusReasonEndKey1();
    // END, CR00236272

    // UniqueID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Get the appeal case id
    hearingDecisionKey.hearingDecisionID =
      dtls.hearingDecisionVersionKey.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(

      curam.message.BPODECISIONAPPROVAL.ERR_FV_APPROVE_NODECISION);
    }

    // Create Case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.DECISIONAPPROVED;
    caseEventDtls.startDate = Date.getCurrentDate();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.caseID = hearingDecisionCaseKey.caseID;

    caseEventObj.insert(caseEventDtls);

    // Notify the case owner
    hearingDecisionCaseDetails.caseID = hearingDecisionCaseKey.caseID;
    notifyCaseOwner(hearingDecisionCaseDetails);

    // Modify the decision status
    hearingDecisionStatusVersionDetails.decisionStatus =
      HEARINGDECISIONSTATUS.APPROVED;
    hearingDecisionStatusVersionDetails.versionNo =
      dtls.hearingDecisionVersionKey.versionNo;
    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);

    // Remove the deadline task
    caseID.caseID = hearingDecisionCaseKey.caseID;
    appeal_boObj.removeDeadlineTask(caseID);

    // Notification details
    hearingDecisionNotifyDetails.caseID = hearingDecisionCaseKey.caseID;
    hearingDecisionNotifyDetails.decisionResolution =
      HEARINGDECISIONRESOLUTION.ACCEPTED;

    // Notify the case representative
    notifyRepresentatives(hearingDecisionNotifyDetails);

    // Notify third parties
    notifyThirdParty(hearingDecisionNotifyDetails);

    // Notify the appellant
    notifyAppellant(hearingDecisionNotifyDetails);

    // Notify the respondent
    notifyRespondent(hearingDecisionNotifyDetails);

    // Update the case status
    updateCaseStatusReasonEndKey.caseID = hearingDecisionCaseKey.caseID;
    updateCaseStatusReasonEndKey.endDate = Date.getCurrentDate();
    updateCaseStatusReasonEndKey.statusCode = CASESTATUS.CLOSED;
    updateCaseStatusReasonEndKey.startDate = Date.getCurrentDate();
    // BEGIN, CR00236272, AK
    closeCaseObj.updateCaseStatus1(updateCaseStatusReasonEndKey);
    // END, CR00236272

    hearingDecisionCaseDetails.caseID = hearingDecisionCaseKey.caseID;
    createImplementationDeadlineTasks(hearingDecisionCaseDetails);

    // BEGIN, CR00050118, RKi
    if (hearingDecisionCaseKey.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final CaseTransactionLog caseTransactionLog =
        CaseTransactionLogFactory.newInstance();

      insertTransactionLogDetails.caseID = hearingDecisionCaseKey.caseID;
      insertTransactionLogDetails.eventTypeCode =
        CASETRANSACTIONEVENTS.APPEALCASE_APPROVED;

      caseTransactionLog.insertTransactionLog(insertTransactionLogDetails);
    }
    // END, CR00050118

    // BEGIN, CR00424946, DM
    // if the appeal decision's resolution is "rejected", then we need to send
    // an "appeal rejected"
    // event for all the appellants on this case
    IdAndResolutionDetails idAndResolutionDetails;

    idAndResolutionDetails =
      hearingDecisionObj.readIDAndResolutionByCase(hearingDecisionCaseKey);

    if (idAndResolutionDetails != null
      && idAndResolutionDetails.resolutionCode
        .equals(APPEALCASERESOLUTION.REJECTED)) {

      // Search for active appellants
      CaseParticipantRoleIDDetailsList caseParticipantRoleIDDetailsList;

      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();
      final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
        new CaseParticipantRoleCaseAndTypeKey();

      caseParticipantRoleCaseAndTypeKey.caseID =
        hearingDecisionCaseKey.caseID;
      caseParticipantRoleCaseAndTypeKey.typeCode =
        CASEPARTICIPANTROLETYPE.APPELLANT;
      caseParticipantRoleIDDetailsList =
        caseParticipantRoleObj
          .searchActiveRoleByCaseAndType(caseParticipantRoleCaseAndTypeKey);

      if (caseParticipantRoleIDDetailsList != null
        && caseParticipantRoleIDDetailsList.dtls != null) {
        for (int i = 0; i < caseParticipantRoleIDDetailsList.dtls.size(); i++) {
          appealEvents
            .sendOnlineAppealRequestDeniedEvent(caseParticipantRoleIDDetailsList.dtls
              .item(i).participantRoleID);
        }
      }

    }
    // END, CR00424946

  }

  // ___________________________________________________________________________
  /**
   * Creates or updates the appeal case decision to submitted.
   * 
   * @param dtls
   * The details for submitting an appeal decision for approval
   */
  @Override
  protected void createSubmittedDecision(
    final AppealDecisionVersionDetails dtls) throws AppException,
    InformationalException {

    // HearingDecision object and structs
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // Case Event object and structs
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // Unique ID object
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Work Allocation object and structs
    final WorkAllocationTask workAllocationTaskObj =
      WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // Get the appeal case id
    hearingDecisionKey.hearingDecisionID =
      dtls.hearingDecisionVersionKey.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(

      curam.message.BPODECISIONAPPROVAL.ERR_FV_SUBMIT_NODECISION);
    }

    // Create case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.caseID = hearingDecisionCaseKey.caseID;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.DECISIONSUBMITTED;
    caseEventDtls.startDate = Date.getCurrentDate();

    caseEventObj.insert(caseEventDtls);

    // Modify the status
    hearingDecisionStatusVersionDetails.decisionStatus =
      HEARINGDECISIONSTATUS.SUBMITTED;
    hearingDecisionStatusVersionDetails.versionNo =
      dtls.hearingDecisionVersionKey.versionNo;
    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);

    // Create a task
    // Set the reason for the task
    createStandardManualTaskDetails.taskDtls.comments =
      curam.message.BPODECISION.INF_DECISION_TICKET_SUBJECT.getMessageText();

    // Set the subject for the task
    createStandardManualTaskDetails.taskDtls.subject =
      curam.message.BPODECISION.INF_DECISION_SUBMITTEDDECISIONCREATED
        .getMessageText();

    // Set the priority for the task
    createStandardManualTaskDetails.taskDtls.priority = TASKPRIORITY.NORMAL;

    createStandardManualTaskDetails.concerningDtls.caseID =
      hearingDecisionCaseKey.caseID;
    createStandardManualTaskDetails.taskDtls.taskDefinitionID =
      curam.appeal.sl.impl.Appeal.kAppealStandardTask;

    // create the task
    workAllocationTaskObj.createTask(createStandardManualTaskDetails);

  }

  // ___________________________________________________________________________
  /**
   * Validates the submission of an appeal case decision for approval.
   * 
   * @param dtls
   * The details for submitting an appeal decision for approval
   */
  @Override
  protected void validateSubmit(final AppealDecisionVersionDetails dtls)
    throws AppException, InformationalException {

    // HearingDecision object and structs
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    HearingDecisionCaseKey hearingDecisionCaseKey;

    // HearingDecision Attachment Link object and structs
    final HearingDecisionAttachmentLink hearingDecisionAttachmentLinkObj =
      HearingDecisionAttachmentLinkFactory.newInstance();
    final ActiveDecisionAttachmentsKey activeDecisionAttachmentsKey =
      new ActiveDecisionAttachmentsKey();
    AppealCountDetails appealCountDetails;

    // AppealRelationship object and structs
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveAppealResolutionKey activeAppealResolutionKey =
      new ActiveAppealResolutionKey();
    AppealedCaseCountDetails appealedCaseCountDetails =
      new AppealedCaseCountDetails();

    // Appeal object and structs
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    AppealTypeDetails appealTypeDetails;

    // CaseUserRole object and structs
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleSearchByCaseAndStatusAndTypeAndDate caseUserRoleSearchByCaseAndStatusAndTypeAndDate =
      new CaseUserRoleSearchByCaseAndStatusAndTypeAndDate();
    // BEGIN, CR00071911, RKi
    OrgObjLinkIDAndCaseUserRoleIDList orgObjLinkIDAndCaseUserRoleIDList;
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00071911

    // Read decision status, appeal case id and appeal case status
    hearingDecisionKey.hearingDecisionID =
      dtls.hearingDecisionVersionKey.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(

      curam.message.BPODECISIONAPPROVAL.ERR_FV_SUBMIT_NODECISION);
    }

    // Check for active decision documents
    activeDecisionAttachmentsKey.hearingDecisionID =
      dtls.hearingDecisionVersionKey.hearingDecisionID;
    appealCountDetails =
      hearingDecisionAttachmentLinkObj
        .countActiveAttachmentsByDecision(activeDecisionAttachmentsKey);

    // Throw exception if there is no active decision document
    if (appealCountDetails.recordCount <= 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISIONAPPROVAL.ERR_FV_DOCUMENTMISSING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Check for any 'not decided' resolutions
    activeAppealResolutionKey.appealCaseID = hearingDecisionCaseKey.caseID;
    activeAppealResolutionKey.resolutionCode =
      HEARINGDECISIONRESOLUTION.NOTDECIDED;
    appealedCaseCountDetails =
      appealRelationshipObj
        .countActiveByAppealCaseAndResolution(activeAppealResolutionKey);

    // Throw exception if there are 'not decided' resolutions
    if (appealedCaseCountDetails.recordCount > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISIONAPPROVAL.ERR_FV_NOTDECIDEDRESOLUTIONSEXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Find the appeal type
    appealCaseIDKey.caseID = hearingDecisionCaseKey.caseID;
    appealTypeDetails = appealObj.readAppealTypeByCase(appealCaseIDKey);

    // Set appropriate user type code
    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {

      caseUserRoleSearchByCaseAndStatusAndTypeAndDate.typeCode =
        CASEUSERROLETYPE.HEARINGOFFICIAL;

    } else {

      caseUserRoleSearchByCaseAndStatusAndTypeAndDate.typeCode =
        CASEUSERROLETYPE.HEARINGREVIEWER;
    }

    // BEGIN, CR00123228, RKi
    boolean userfound = false;

    if (appealTypeDetails.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      final CaseParticipantRole caseParticipantRole =
        CaseParticipantRoleFactory.newInstance();
      final ReadByCaseIDTypeAndStatusKey caseIDTypeAndStatusKey =
        new ReadByCaseIDTypeAndStatusKey();

      caseIDTypeAndStatusKey.caseID = hearingDecisionCaseKey.caseID;
      caseIDTypeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
      caseIDTypeAndStatusKey.typeCode =
        CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;
      final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
        caseParticipantRole
          .readCaseParticipantRolesByTypeCaseIDAndStatus(caseIDTypeAndStatusKey);

      if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {
        // Search for current user in returned list
        if (TransactionInfo.getProgramUserType().equals(
          HEARINGLOCATIONTYPE.EXTERNAL)) {
          final ExternalUserKey externalUserKey = new ExternalUserKey();

          externalUserKey.userName = TransactionInfo.getProgramUser();
          ExternalUserParticipantLinkDtlsList externalUserParticipantLinkDtlsList;
          final ExternalUserParticipantLink externalUserParticipantLink =
            ExternalUserParticipantLinkFactory.newInstance();

          externalUserParticipantLinkDtlsList =
            externalUserParticipantLink.searchByUsername(externalUserKey);

          for (int i = 0; i < externalUserParticipantLinkDtlsList.dtls.size(); i++) {
            for (int j = 0; j < caseParticipantRoleNameDetailsList.dtls
              .size(); j++) {
              if (externalUserParticipantLinkDtlsList.dtls.item(i).participantRoleID == caseParticipantRoleNameDetailsList.dtls
                .item(j).participantRoleID) {
                userfound = true;
                break;
              }
            }
          }
        } else {
          // In case of external official any internal user who has role on
          // the case is allowed to approve the decision on behalf of the
          // external
          // hearing official.
          final CaseUserRoleCaseIDKey caseUserRoleCaseIDKey =
            new CaseUserRoleCaseIDKey();

          caseUserRoleCaseIDKey.caseID = hearingDecisionCaseKey.caseID;
          final CaseUserRoleDtlsList caseUserRoleDtlsList =
            caseUserRoleObj.searchByCaseID(caseUserRoleCaseIDKey);

          for (int i = 0; i < caseUserRoleDtlsList.dtls.size(); i++) {
            orgObjectLinkKey.orgObjectLinkID =
              caseUserRoleDtlsList.dtls.item(i).orgObjectLinkID;

            caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
            if (caseUserRoleDtlsList.dtls.item(i).recordStatus
              .equals(RECORDSTATUS.NORMAL)
              && caseOwnerDetails.userName.equals(TransactionInfo
                .getProgramUser())) {
              userfound = true;
              break;
            }
          }
        }
      }
    }
    // END, CR00123228

    // Find the active user roles for the case
    caseUserRoleSearchByCaseAndStatusAndTypeAndDate.activeDate =
      Date.getCurrentDate();
    caseUserRoleSearchByCaseAndStatusAndTypeAndDate.caseID =
      hearingDecisionCaseKey.caseID;
    // BEGIN, CR00071911, RKi
    orgObjLinkIDAndCaseUserRoleIDList =
      caseUserRoleObj
        .searchActiveRoleByCaseIDDateAndType(caseUserRoleSearchByCaseAndStatusAndTypeAndDate);

    for (int i = 0; i < orgObjLinkIDAndCaseUserRoleIDList.dtls.size(); i++) {

      // BEGIN, CR00071911, RKi
      orgObjectLinkKey.orgObjectLinkID =
        orgObjLinkIDAndCaseUserRoleIDList.dtls.item(i).orgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      if (caseOwnerDetails.userName.equals(TransactionInfo.getProgramUser())) {
        // END, CR00071911

        userfound = true;
        break;
      }
    }

    // Throw exception if current user is not an active role
    if (!userfound) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPODECISIONAPPROVAL.ERR_FV_USERNOTACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Submits an appeal decision for approval. If the user has sufficient
   * approval privileges then the appeal decision is automatically approved;
   * otherwise the decision must be manually approved.
   * 
   * @param dtls
   * The details for submitting an appeal decision for approval
   */
  @Override
  public void submit(final AppealDecisionVersionDetails dtls)
    throws AppException, InformationalException {

    // HearingDecision object and structs
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    HearingDecisionCaseKey hearingDecisionCaseKey;
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();

    // DecisionApprovalUserDetails
    final DecisionApprovalUserDetails decisionApprovalUserDetails =
      new DecisionApprovalUserDetails();
    DecisionApprovalIndicatorDetails decisionApprovalIndicatorDetails;

    // Find the case id
    hearingDecisionKey.hearingDecisionID =
      dtls.hearingDecisionVersionKey.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(

      curam.message.BPODECISIONAPPROVAL.ERR_FV_SUBMIT_NODECISION);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate data
    validateSubmit(dtls);

    // Find user access
    final SystemUser systemUser = SystemUserFactory.newInstance();

    decisionApprovalUserDetails.userName =
      systemUser.getUserDetails().userName;
    decisionApprovalIndicatorDetails =
      userCanApproveCheck(decisionApprovalUserDetails);

    // Check if user has access
    if (decisionApprovalIndicatorDetails.approvalInd) {

      createApprovedDecision(dtls);

    } else {

      createSubmittedDecision(dtls);

    }
  }

  // ___________________________________________________________________________
  /**
   * Approves an appeal decision which has been submitted for approval.
   * 
   * @param details
   * The appeal decision approval details.
   */
  @Override
  public void approve(final AppealDecisionVersionDetails details)
    throws AppException, InformationalException {

    // HearingDecision object and structs
    final HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    HearingDecisionCaseKey hearingDecisionCaseKey;
    final HearingDecisionKey hearingDecisionEntityKey =
      new HearingDecisionKey();
    final curam.appeal.sl.struct.HearingDecisionKey hearingDecisionKey =
      new curam.appeal.sl.struct.HearingDecisionKey();

    // Find the case id
    hearingDecisionEntityKey.hearingDecisionID =
      details.hearingDecisionVersionKey.hearingDecisionID;

    try {

      hearingDecisionCaseKey =
        hearingDecisionObj.readCase(hearingDecisionEntityKey);

    } catch (final RecordNotFoundException e) {

      throw new AppException(

      curam.message.BPODECISIONAPPROVAL.ERR_FV_APPROVE_NODECISION);
    }

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate appeal case security
    validateSecurityKey.caseID = hearingDecisionCaseKey.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kApproveDecisionSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate the decision approval
    hearingDecisionKey.hearingDecisionID =
      details.hearingDecisionVersionKey.hearingDecisionID;
    validateApprove(hearingDecisionKey);

    // Create the approved decision
    createApprovedDecision(details);

  }

  // ___________________________________________________________________________
  /**
   * Creates an Implementation deadline task for the appealed case
   * 
   * @param details
   * The details of the cases
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnchecked)
  public void createImplementationDeadlineTasks(
    final HearingDecisionCaseDetails details) throws AppException,
    InformationalException {

    // Appeal Relationship variables
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    CaseIDAndDeadlineDateList caseIDAndDeadlineDateList;

    CaseIDAndDeadlineDate caseIDAndDeadlineDate;

    // Enactment service Object
    final java.util.List enactmentStructs = new java.util.ArrayList();
    final TaskCreateDetails taskCreateDetails = new TaskCreateDetails();

    // Search for appealed cases
    activeApprovedCaseKey.appealCaseID = details.caseID;

    caseIDAndDeadlineDateList =
      appealRelationshipObj
        .searchDeadlineDetailsByAppealCase(activeApprovedCaseKey);

    for (int i = 0; i < caseIDAndDeadlineDateList.dtls.size(); i++) {

      // create an Implementation Deadline task for each appealed case
      caseIDAndDeadlineDate = caseIDAndDeadlineDateList.dtls.item(i);

      // Set Task CaseID & DeadlineDate
      taskCreateDetails.caseID = caseIDAndDeadlineDate.caseID;
      taskCreateDetails.deadlineDateTime =
        caseIDAndDeadlineDate.deadlineDate.getDateTime();

      enactmentStructs.add(taskCreateDetails);

      // Enact work flow to create the complete hearing task.
      EnactmentService.startProcess(
        curam.appeal.sl.impl.Appeal.kAppealImplementationDeadlineTask,
        enactmentStructs);

    }
  }
}
