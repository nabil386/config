/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2006 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingActivityLinkFactory;
import curam.appeal.sl.entity.intf.HearingActivityLink;
import curam.appeal.sl.entity.struct.HearingActivityIDKey;
import curam.core.struct.Count;
import curam.core.struct.MaintainActivityDetails;
import curam.message.BPOAPPEALMAINTAINACTIVITY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Functions for manipulating activity information and interfacing with the
 * activity object
 * 
 */
public abstract class AppealMaintainActivity extends
  curam.appeal.sl.base.AppealMaintainActivity {

  // ___________________________________________________________________________
  /**
   * Maintains the list of attendees for a specified activity.
   * 
   * Activities related to an appeal case, specifically a scheduled hearing for
   * an appeal case, cannot be managed outside of the appeals module.
   * 
   * @param maintainActivityDetails Activity details information.
   */
  @Override
  public void maintainAttendeesForActivity(
    final MaintainActivityDetails maintainActivityDetails)
    throws AppException, InformationalException {

    // Variables for determining if the activity is related to an appeal case
    final HearingActivityLink hearingActivityLinkObj =
      HearingActivityLinkFactory.newInstance();
    final HearingActivityIDKey hearingActivityIDKey =
      new HearingActivityIDKey();
    Count count;

    // Determine if the activity is related to an appeal case or not; do this by
    // searching for any activityID matches in the HearingActivityLink table.
    hearingActivityIDKey.activityID = maintainActivityDetails.activityID;
    count = hearingActivityLinkObj.countByActivityID(hearingActivityIDKey);

    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALMAINTAINACTIVITY.ERR_APPEALMAINTAINACTIVITY_FV_HEARINGAPPEALLINKEXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);

    }

  }

}
