/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchByCaseRefKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchByHearingDateKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchKey;
import curam.appeal.sl.entity.struct.AppealDatabaseSearchKeyDtls;
import curam.appeal.sl.entity.struct.AppealSearchResultDetailsList;
import curam.appeal.sl.struct.AppealSearchKey;
import curam.appeal.sl.struct.AppealSearchResultDetails;
import curam.appeal.sl.struct.AppealSearchResultList;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.core.impl.CuramConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.ReadmultiMaxException;
import curam.util.type.DateTime;
import java.util.Calendar;

/**
 * Database search for appeal cases
 */
public abstract class DatabaseAppealSearch extends
  curam.appeal.sl.base.DatabaseAppealSearch {

  // ___________________________________________________________________________
  /**
   * Method to perform a search for appeal cases
   * 
   * @param key Search criteria on which the search will be based
   * 
   * @return The details of any records found
   */
  @Override
  public AppealSearchResultList search(final AppealSearchKey key)
    throws AppException, InformationalException {

    // Return Object
    final AppealSearchResultList appealSearchResultList =
      new AppealSearchResultList();

    // Appeal database search Key Details
    AppealDatabaseSearchKeyDtls appealDatabaseSearchKeyDtls =
      new AppealDatabaseSearchKeyDtls();

    // Appeal Entity Obj & Structs
    final Appeal appealObj = AppealFactory.newInstance();
    AppealSearchResultDetailsList appealSearchResultDetailsList =
      new AppealSearchResultDetailsList();

    AppealSearchResultDetails appealSearchResultDetails =
      new AppealSearchResultDetails();
    final AppealDatabaseSearchByCaseRefKey appealDatabaseSearchByCaseRefKey =
      new AppealDatabaseSearchByCaseRefKey();
    final AppealDatabaseSearchByHearingDateKey appealDatabaseSearchByHearingDateKey =
      new AppealDatabaseSearchByHearingDateKey();

    final InformationalManager informationalManager =
      new InformationalManager();

    // If the case reference number is specified no need to process the
    // complicated queries.
    if (key.caseReference.length() != 0) {

      appealDatabaseSearchByCaseRefKey.assign(key);

      appealSearchResultDetailsList =
        appealObj.searchByCaseReference(appealDatabaseSearchByCaseRefKey);

    } else if (!key.hearingDate.isZero()) {

      // Search by hearing date and other values if specified.
      appealDatabaseSearchKeyDtls = calculateAppealKey(key);

      appealDatabaseSearchByHearingDateKey
        .assign(appealDatabaseSearchKeyDtls);

      // Set the Date Range attributes
      final DateTime fromHearingDateTime =
        new DateTime(key.hearingDate.getCalendar());
      final Calendar calendar = key.hearingDate.getCalendar();

      // Add one day to date specified
      calendar.add(Calendar.DATE, 1);
      final DateTime toHearingDateTime = new DateTime(calendar);

      // Set times to Midnight
      fromHearingDateTime.addTime(0, 0, 0);
      toHearingDateTime.addTime(0, 0, 0);

      appealDatabaseSearchByHearingDateKey.fromHearingDateTime =
        fromHearingDateTime;
      appealDatabaseSearchByHearingDateKey.toHearingDateTime =
        toHearingDateTime;

      try {
        appealSearchResultDetailsList =
          appealObj.searchByHearingDate(appealDatabaseSearchByHearingDateKey);
      } catch (final ReadmultiMaxException e) {
        // if number of results exceed the maximum limit
        // pass an informational message to client.
        informationalManager.addInformationalMsg(new AppException(
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }

    } else {
      // Search for appeal cases using various search parameters
      try {
        // BEGIN , CR00289218 , DK
        appealDatabaseSearchKeyDtls = calculateAppealKey(key);
        appealSearchResultDetailsList =
          appealObj.searchAppeal(appealDatabaseSearchKeyDtls);
        // END , CR00289218 , DK

      } catch (final ReadmultiMaxException e) {
        // if number of results exceed the maximum limit
        // pass an informational message to client.
        informationalManager.addInformationalMsg(new AppException(
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      }
    }

    // Process first list Search Results
    if (appealSearchResultDetailsList != null) {
      for (int i = 0; i < appealSearchResultDetailsList.dtls.size(); i++) {
        appealSearchResultDetails = new AppealSearchResultDetails();

        appealSearchResultDetails.assign(appealSearchResultDetailsList.dtls
          .item(i));

        if (CASEPARTICIPANTROLETYPE.APPELLANT
          .equals(appealSearchResultDetailsList.dtls.item(i).participantType)) {

          // Assign Appellant Details
          appealSearchResultDetails.appellantName =
            appealSearchResultDetailsList.dtls.item(i).participantName;
          appealSearchResultDetails.appellantRoleID =
            appealSearchResultDetailsList.dtls.item(i).participantRoleID;
          appealSearchResultDetails.appellantRoleType =
            appealSearchResultDetailsList.dtls.item(i).concernRoleType;

        } else if (CASEPARTICIPANTROLETYPE.RESPONDENT
          .equals(appealSearchResultDetailsList.dtls.item(i).participantType)) {

          // Assign Respondent Details
          appealSearchResultDetails.respondentName =
            appealSearchResultDetailsList.dtls.item(i).participantName;
          appealSearchResultDetails.respondentRoleID =
            appealSearchResultDetailsList.dtls.item(i).participantRoleID;
          appealSearchResultDetails.respondentRoleType =
            appealSearchResultDetailsList.dtls.item(i).concernRoleType;
        }
        appealSearchResultList.appealSearchResultDetails
          .addRef(appealSearchResultDetails);
      }
    }
    // Log all exceptions (if any)
    informationalManager.failOperation();

    return appealSearchResultList;

  }

  // ___________________________________________________________________________

  // BEGIN , CR00289218 , DK
  /**
   * Calculates the details of the database search key based on the key values
   * provided.
   * 
   * @param key Search criteria on which the search will be based
   * 
   * @return Database Search key
   * 
   * 
   * @deprecated Since Curam 6.0 SP1, replaced with
   * {calculateAppealKey(AppealSearchKey)}. See release note: CR00289218.
   */
  @Override
  @Deprecated
  protected AppealDatabaseSearchKey calculateKey(final AppealSearchKey key)
    throws AppException, InformationalException {

    // Return Object
    final AppealDatabaseSearchKey appealDatabaseSearchKey =
      new AppealDatabaseSearchKey();

    // Assign the key values
    appealDatabaseSearchKey.assign(key);

    // If certain parameters are specified set the searchBy indicators
    appealDatabaseSearchKey.searchByAppellant = key.appellantID != 0;
    appealDatabaseSearchKey.searchByRespondent = key.respondentID != 0;
    appealDatabaseSearchKey.searchByAppellantType =
      key.appellantType.length() > 0;
    appealDatabaseSearchKey.searchByRespondentType =
      key.respondentType.length() > 0;
    appealDatabaseSearchKey.searchByAppealType = key.appealType.length() > 0;
    appealDatabaseSearchKey.searchByCreationDate = !key.creationDate.isZero();
    appealDatabaseSearchKey.searchByStatus = key.status.length() > 0;

    return appealDatabaseSearchKey;
  }

  /**
   * Calculates the details of the database search key based on the key values
   * provided.
   * 
   * @param key Search criteria on which the search will be based
   * 
   * @return Database Search key
   */
  @Override
  protected AppealDatabaseSearchKeyDtls calculateAppealKey(
    final AppealSearchKey key) throws AppException, InformationalException {

    // Return Object
    final AppealDatabaseSearchKeyDtls appealDatabaseSearchKeyDtls =
      new AppealDatabaseSearchKeyDtls();

    // Assign the key values
    appealDatabaseSearchKeyDtls.assign(key);

    // If certain parameters are specified set the searchBy indicators
    appealDatabaseSearchKeyDtls.searchByAppellant = key.appellantID != 0;
    appealDatabaseSearchKeyDtls.searchByRespondent = key.respondentID != 0;
    appealDatabaseSearchKeyDtls.searchByAppellantType =
      key.appellantType.length() > 0;
    appealDatabaseSearchKeyDtls.searchByRespondentType =
      key.respondentType.length() > 0;
    appealDatabaseSearchKeyDtls.searchByAppealType =
      key.appealType.length() > 0;
    appealDatabaseSearchKeyDtls.searchByCreationDate =
      !key.creationDate.isZero();
    appealDatabaseSearchKeyDtls.searchByStatus = key.status.length() > 0;

    return appealDatabaseSearchKeyDtls;
  }
  // END , CR00289218 , DK
}
