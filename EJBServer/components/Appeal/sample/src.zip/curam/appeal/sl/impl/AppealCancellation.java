/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software Ltd.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealCancellationFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.fact.HearingRepresentativeFactory;
import curam.appeal.sl.entity.fact.HearingWitnessFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Hearing;
import curam.appeal.sl.entity.intf.HearingRepresentative;
import curam.appeal.sl.entity.intf.HearingWitness;
import curam.appeal.sl.entity.struct.ActiveApprovedCaseKey;
import curam.appeal.sl.entity.struct.ActiveCaseKey;
import curam.appeal.sl.entity.struct.AppealCancellationDtls;
import curam.appeal.sl.entity.struct.AppealCancellationKey;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseIDTYypeRecordStatusDetails;
import curam.appeal.sl.entity.struct.AppealRelationshipKey;
import curam.appeal.sl.entity.struct.BenefitPriorAppealAndCaseTypeDetailsList;
import curam.appeal.sl.entity.struct.CaseAndStatusKey;
import curam.appeal.sl.entity.struct.CaseOwnerDetailsAndAppealCaseList;
import curam.appeal.sl.entity.struct.HearingCaseIDStatusKeyHR;
import curam.appeal.sl.entity.struct.HearingCaseIDStatusKeyHW;
import curam.appeal.sl.entity.struct.HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;
import curam.appeal.sl.entity.struct.HearingScheduleDetails;
import curam.appeal.sl.entity.struct.HearingVersionNumberDetails;
import curam.appeal.sl.entity.struct.HearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList;
import curam.appeal.sl.entity.struct.IssueDeliveryKeyForAppealList;
import curam.appeal.sl.entity.struct.ModifyStatusCodesDetails;
import curam.appeal.sl.entity.struct.ModifyStatusCodesKey;
import curam.appeal.sl.entity.struct.ProductDeliveryKeyForAppealList;
import curam.appeal.sl.entity.struct.ReadAppealCancellationCaseDetails;
import curam.appeal.sl.entity.struct.StatusAndRecordStatus;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.HearingScheduleFactory;
import curam.appeal.sl.intf.AppealProFormaDocumentGeneration;
import curam.appeal.sl.intf.AppealSecurity;
import curam.appeal.sl.intf.HearingSchedule;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.CancelAppealDetails;
import curam.appeal.sl.struct.CancelHearingCaseDetails;
import curam.appeal.sl.struct.CancelHearingCaseKey_bo;
import curam.appeal.sl.struct.CancelHearingReviewDetails_bo;
import curam.appeal.sl.struct.CancelHearingReviewKey;
import curam.appeal.sl.struct.CancelScheduledHearingsKey;
import curam.appeal.sl.struct.CreateBenefitTaskAppealedCaseDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.ModifyCancelCaseDetails;
import curam.appeal.sl.struct.ModifyCancelCaseKey_bo;
import curam.appeal.sl.struct.NotifyCaseOwnerCaseIDKey;
import curam.appeal.sl.struct.NotifyParticipantCaseIDKey;
import curam.appeal.sl.struct.ReadCancelledCaseDetails;
import curam.appeal.sl.struct.ReadCancelledCaseKey_bo;
import curam.appeal.sl.struct.RemoveRelationshipLinksDetails;
import curam.appeal.sl.struct.UpdateAppealCaseStatusDetails;
import curam.appeal.sl.struct.ValidateCaseStatusKey;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CaseEvent;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.Notification;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.CaseUserRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.CaseUserRole;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.CaseUserRoleSearchByCaseAndStatusAndTypeAndDate;
import curam.core.sl.entity.struct.OrgObjLinkIDAndCaseUserRoleIDList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.InsertTransactionLogDetails;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.message.BPOAPPEALCANCELLATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;

/**
 * This process class provides the functionality for the Cancel Hearing Case
 * presentation layer.
 * 
 */
public abstract class AppealCancellation extends
  curam.appeal.sl.base.AppealCancellation {

  // ___________________________________________________________________________
  /**
   * Service layer method to update the appeal cancellation details.
   * 
   * @param key The key of the appeal cancellation
   * @param details The details of the appeal cancellation
   */
  @Override
  public void modify(final ModifyCancelCaseKey_bo key,
    final ModifyCancelCaseDetails details) throws AppException,
    InformationalException {

    // AppealCancellation objects
    final curam.appeal.sl.entity.intf.AppealCancellation appealCancellationObj =
      AppealCancellationFactory.newInstance();
    final AppealCancellationKey appealCancellationKey =
      new AppealCancellationKey();
    ReadAppealCancellationCaseDetails readAppealCancellationCaseDetails;

    // ValidateCaseStatusKey object
    final ValidateCaseStatusKey validateCaseStatusKey =
      new ValidateCaseStatusKey();

    // Read hearing case id
    appealCancellationKey.appealCancellationID =
      key.modifyCancelCaseKey.appealCancellationID;
    readAppealCancellationCaseDetails =
      appealCancellationObj.readCase(appealCancellationKey);

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = readAppealCancellationCaseDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate hearing case status
    validateCaseStatusKey.caseID = readAppealCancellationCaseDetails.caseID;
    validateCaseStatusForModify(validateCaseStatusKey);

    // Modify AppealCancellation
    appealCancellationObj.modify(key.modifyCancelCaseKey,
      details.modifyCancelCaseDetails);
  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to read the details of a canceled hearing case.
   * 
   * @param key The case cancellation id.
   * 
   * @return The details of the canceled hearing case.
   */
  @Override
  public curam.appeal.sl.struct.ReadCancelledCaseDetails read(
    final ReadCancelledCaseKey_bo key) throws AppException,
    InformationalException {

    // AppealCancellation object
    final curam.appeal.sl.entity.intf.AppealCancellation appealCancellationObj =
      AppealCancellationFactory.newInstance();

    // Return structure
    final ReadCancelledCaseDetails readCancelledCaseDetails =
      new ReadCancelledCaseDetails();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = key.readCancelledCaseDetails.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Perform read
    readCancelledCaseDetails.readCancelledCaseKey =
      appealCancellationObj.read(key.readCancelledCaseDetails);

    return readCancelledCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to Notify the appellant of the appeal cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void notifyAppellantOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Retrieve appellant participants
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.APPELLANT;
    caseParticipantRoleNameDetailsList =
      caseParticipantRole
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = key.caseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // Add concern name to communication
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = key.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // ___________________________________________________________________________
  /**
   * This method notifies all relevant case owners of the appeal case
   * cancellation.
   * 
   * This includes the case owner of the appeal case itself and
   * the case owner for each of the appealed cases. Where the appealed case
   * is appealing a decision from a prior appeal case, the case owner for
   * both the prior appeal case and the implementation case are notified.
   * 
   * In all cases, no notification is created if the current user is the
   * the case owner.
   * 
   * @param key The unique identifier of the appeal case being canceled
   */
  @Override
  public void notifyCaseOwner(final NotifyCaseOwnerCaseIDKey key)
    throws AppException, InformationalException {

    // Variables for determining the case owners of cases under appeal
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final ActiveApprovedCaseKey activeApprovedCaseKey =
      new ActiveApprovedCaseKey();
    CaseOwnerDetailsAndAppealCaseList caseOwnerDetailsAndAppealCaseList;

    // Variables for determining the appeal case owner
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Variables for creating notifications
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();
    final curam.core.intf.Notification notificationObj =
      NotificationFactory.newInstance();

    // Determine the current user
    final String currentUser = TransactionInfo.getProgramUser();

    AppException subjectInfo;

    subjectInfo =
      new AppException(
        curam.message.BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_APPEALCANCELED);
    // Initialize the common notification details
    standardManualTaskDtls.dtls.taskDtls.comments =
      GeneralAppealConstants.kSpace;
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
      Appeal.kAppealNotificationTask;

    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails;

    // read maintainCase
    CaseReferenceAndStatusDetails caseReferenceAndStatusDtls =
      new CaseReferenceAndStatusDetails();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = key.caseID;
    caseReferenceAndStatusDtls =
      caseHeaderObj.readCaseReferenceAndStatusByCaseID(caseSearchKey);

    subjectInfo.arg(caseReferenceAndStatusDtls.caseReference);
    standardManualTaskDtls.dtls.taskDtls.subject = subjectInfo.getMessage();

    // Notify the appeal case owner of the cancellation if the current user is
    // not the case owner.
    caseHeaderKey.caseID = key.caseID;
    // BEGIN, CR00053295, RKi
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    caseOwnerDetails = new CaseOwnerDetails();
    caseOwnerDetails = caseUserRole.readOwner(caseHeaderKey);
    // END, CR00053295

    if (!currentUser.equals(caseOwnerDetails.userName)) {
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;
      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userName;
      // BEGIN, CR00053295, RKi
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295
    }

    // Notify the case owners for each appealed case where the underlying
    // product
    // delivery or assessment delivery is being directly appealed. In this
    // instance
    // there will be no prior appeal case involved.
    // Only create the notification if the case owner is not the current user
    activeApprovedCaseKey.appealCaseID = key.caseID;
    caseOwnerDetailsAndAppealCaseList =
      appealRelationshipObj
        .searchActiveCaseOwnerByAppealCase(activeApprovedCaseKey);

    for (int i = 0; i < caseOwnerDetailsAndAppealCaseList.dtls.size(); i++) {
      // BEGIN, CR00053295, RKi

      orgObjectLinkKey.orgObjectLinkID =
        caseOwnerDetailsAndAppealCaseList.dtls.item(i).ownerOrgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName =
        caseOwnerDetails.userName;
      // END, CR00053295
      if (!currentUser
        .equals(caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName)) {
        standardManualTaskDtls.dtls.concerningDtls.caseID =
          caseOwnerDetailsAndAppealCaseList.dtls.item(i).caseID;
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName;

        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      }
    }

    // Where the appealed case is a decision on a previous appeal case, notify
    // the
    // case owners of the prior appeal case for each appealed case. Only create
    // the
    // notification if the case owner is not the current user.
    caseOwnerDetailsAndAppealCaseList =
      appealRelationshipObj
        .searchActivePriorCaseOwnerByAppealCase(activeApprovedCaseKey);

    for (int i = 0; i < caseOwnerDetailsAndAppealCaseList.dtls.size(); i++) {
      // BEGIN, CR00053295, RKi

      orgObjectLinkKey.orgObjectLinkID =
        caseOwnerDetailsAndAppealCaseList.dtls.item(i).ownerOrgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);
      caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName =
        caseOwnerDetails.userName;
      // END, CR00053295
      if (!currentUser
        .equals(caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName)) {
        standardManualTaskDtls.dtls.concerningDtls.caseID =
          caseOwnerDetailsAndAppealCaseList.dtls.item(i).caseID;
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetailsAndAppealCaseList.dtls.item(i).userName;

        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to Notify the Hearing official of the appeal
   * cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void notifyHearingOfficialOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseUserRole object
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleSearchByCaseAndStatusAndTypeAndDate searchKey =
      new CaseUserRoleSearchByCaseAndStatusAndTypeAndDate();
    // BEGIN, CR00071911, RKi
    OrgObjLinkIDAndCaseUserRoleIDList orgObjLinkIDAndCaseUserRoleIDList;
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    // END, CR00071911

    // Notification objects
    final Notification notificationObj = NotificationFactory.newInstance();

    // current Date
    final Date currentDate = Date.getCurrentDate();

    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Retrieve hearing officials
    searchKey.caseID = key.caseID;
    searchKey.typeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
    searchKey.recordStatus = RECORDSTATUS.NORMAL;
    searchKey.activeDate = currentDate;
    // BEGIN, CR00071911, RKi
    orgObjLinkIDAndCaseUserRoleIDList =
      caseUserRoleObj.searchActiveRoleByCaseIDDateAndType(searchKey);
    // END, CR00071911
    if (orgObjLinkIDAndCaseUserRoleIDList.dtls.size() > 0) {

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();

      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
        Appeal.kAppealNotificationTask;
    }

    // BEGIN, CR00071911, RKi
    for (int i = 0; i < orgObjLinkIDAndCaseUserRoleIDList.dtls.size(); i++) {
      orgObjectLinkKey.orgObjectLinkID =
        orgObjLinkIDAndCaseUserRoleIDList.dtls.item(i).orgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // Add concern name to communication
      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;
      // END, CR00071911

      // Create the notification
      notificationObj
        .createWorkAllocationNotification(standardManualTaskDtls);
    }
  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to Notify Hearing Representative of the appeal
   * cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void notifyHearingRepresentativeOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // HearingRepresentative objects
    final HearingRepresentative hearingRepresentativeObj =
      HearingRepresentativeFactory.newInstance();
    final HearingCaseIDStatusKeyHR hearingCaseIDStatusKeyHR =
      new HearingCaseIDStatusKeyHR();
    HearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList;

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Read hearing representatives
    hearingCaseIDStatusKeyHR.hearingCaseID = key.caseID;
    hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList =
      hearingRepresentativeObj
        .searchActiveHearingRepAndCaseParticipantRoleByHearingCaseID(hearingCaseIDStatusKeyHR);

    for (int i = 0; i < hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
      .size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = key.caseID;
      communicationDetails.correspondentConcernRoleID =
        hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
          .item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // Set the key to read the concern details
      concernRoleKey.concernRoleID =
        hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
          .item(i).participantRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // Add concern name to communication
      communicationDetails.correspondentName =
        concernRoleNameDetails.concernRoleName;
      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = key.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingRepresentativeIDCaseParticipantRoleIDParticipantRoleIDList.dtls
          .item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }
  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to Notify Hearing Witnesses of the appeal cancellation
   * 
   * @param caseID The key of the appeal cancellation
   */
  @Override
  protected void notifyHearingWitnessesOfCancellation(
    final NotifyParticipantCaseIDKey caseID) throws AppException,
    InformationalException {

    // HearingWitness objects
    final HearingWitness hearingWitnessObj =
      HearingWitnessFactory.newInstance();
    final HearingCaseIDStatusKeyHW hearingCaseIDStatusKeyHW =
      new HearingCaseIDStatusKeyHW();
    HearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList;

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Read hearing witnesses
    hearingCaseIDStatusKeyHW.hearingCaseID = caseID.caseID;
    hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList =
      hearingWitnessObj
        .searchActiveHearingWitnessAndCaseParticipantRoleByHearingCaseID(hearingCaseIDStatusKeyHW);

    for (int i = 0; i < hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList.dtls
      .size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = caseID.caseID;
      communicationDetails.correspondentConcernRoleID =
        hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList.dtls
          .item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseID.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // Set the key to read the concern details
      concernRoleKey.concernRoleID =
        hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList.dtls
          .item(i).participantRoleID;
      concernRoleNameDetails =
        concernRoleObj.readConcernRoleName(concernRoleKey);

      // Add concern name to communication
      communicationDetails.correspondentName =
        concernRoleNameDetails.concernRoleName;
      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      // BEGIN, CR00095675, RKi
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      // END, CR00095675
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = caseID.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        hearingWitnessIDCaseParticipantRoleIDParticipantRoleIDcList.dtls
          .item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }
  }

  // __________________________________________________________________________
  /**
   * Service Layer method to Notify Interpreters of the appeal cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void notifyInterpretersOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.HEARINGINTERPRETER;

    // search for appellant
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = key.caseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // Add concern name to communication
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = key.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }
  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to Notify the appeal third party of the appeal
   * cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void notifyThirdPartyOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();

    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Retrieve third party participants
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.THIRDPARTY;

    caseParticipantRoleNameDetailsList =
      caseParticipantRole
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = key.caseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;

      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = key.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to validate the case status is not already closed.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  public void validateCaseStatus(final ValidateCaseStatusKey key)
    throws AppException, InformationalException {

    // CaseHeader objects
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Read case status
    caseHeaderKey.caseID = key.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Status cannot be closed
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALCANCELLATION.ERR_APPEAL_CANCELLATION_FV_CASECLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Status cannot be canceled
    if (caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALCANCELLATION.ERR_APPEAL_CANCELLATION_FV_ALREADYCANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Service layer method to cancel a hearing case.
   * 
   * @param key The key of the appeal cancellation
   * @param details The details of the appeal cancellation
   */
  @Override
  public void cancelHearingCase(final CancelHearingCaseKey_bo key,
    final CancelHearingCaseDetails details) throws AppException,
    InformationalException {

    // Variable for details of cancellation for the appeal case
    final CancelAppealDetails cancelAppealDetails = new CancelAppealDetails();

    // Cancel the appealed case
    cancelAppealDetails.cancelReasonCode = details.cancelReasonCode;
    cancelAppealDetails.cancelReasonText = details.cancelReasonText;
    cancelAppealDetails.caseID = key.caseID;
    cancelAppealDetails.caseVersionNo = details.caseVersionNo;

    // Set the appeal type to Hearing Case
    cancelAppealDetails.appealTypeCode = APPEALTYPE.HEARING;

    // Cancel the appeal
    cancel(cancelAppealDetails);

  }

  // ___________________________________________________________________________
  /**
   * Service Layer method to cancel scheduled hearings and notify the relevant
   * participants of the cancellation.
   * 
   * @param key The key of the appeal cancellation
   * @param details The details of the appeal cancellation
   */
  @Override
  public void cancelScheduledHearings(final CancelScheduledHearingsKey key,
    final CancelHearingCaseDetails details) throws AppException,
    InformationalException {

    // Hearing objects
    final Hearing hearingObj = HearingFactory.newInstance();
    final CaseAndStatusKey caseAndStatusKey = new CaseAndStatusKey();
    HearingScheduleDetails hearingScheduleDetails =
      new HearingScheduleDetails();
    final curam.appeal.sl.entity.struct.HearingKey hearingKey =
      new curam.appeal.sl.entity.struct.HearingKey();
    HearingVersionNumberDetails hearingVersionNumberDetails;
    ModifyStatusCodesKey modifyStatusCodesKey;
    ModifyStatusCodesDetails modifyStatusCodesDetails;
    boolean blnScheduledHearingFound;

    // HearingSchedule objects
    final HearingSchedule hearingScheduleObj =
      HearingScheduleFactory.newInstance();

    final AppealCaseID appealCaseID = new AppealCaseID();

    // Work Flow Event Object
    final curam.util.events.struct.Event closeTaskEvent =
      new curam.util.events.struct.Event();

    // Appeal object
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // NotifyParticipantCaseIDKey object
    final NotifyParticipantCaseIDKey notifyParticipantCaseIDKey =
      new NotifyParticipantCaseIDKey();

    // Read scheduled hearings
    caseAndStatusKey.caseID = key.caseID;
    try {
      hearingScheduleDetails =
        hearingObj.readScheduledByCaseID(caseAndStatusKey);
      blnScheduledHearingFound = true;
    } catch (final RecordNotFoundException e) {

      // No scheduled hearing found.
      blnScheduledHearingFound = false;

      // Remove Schedule Hearing Task
      appealCaseID.caseID = key.caseID;
      hearingScheduleObj.removeScheduleHearingTask(appealCaseID);

    }

    // BEGIN, CR00098931, RKi
    notifyParticipantCaseIDKey.caseID = key.caseID;
    // END, CR00098931

    if (blnScheduledHearingFound) {

      // Send notice. This must be done prior to setting the case status to
      // canceled, as the document generation will look for a scheduled
      // status.

      // If Appeal type is case
      if (details.appealTypeCode.equals(APPEALTYPE.HEARING)) {

        // Notify hearing participants of cancellation
        notifyHearingWitnessesOfCancellation(notifyParticipantCaseIDKey);
        notifyHearingRepresentativeOfCancellation(notifyParticipantCaseIDKey);
        notifyInterpretersOfCancellation(notifyParticipantCaseIDKey);
        notifyThirdPartyOfCancellation(notifyParticipantCaseIDKey);
        notifyAppellantOfCancellation(notifyParticipantCaseIDKey);
        notifyHearingOfficialOfCancellation(notifyParticipantCaseIDKey);

      } else {

        // Notify hearing participants of cancellation
        notifyRepresentativeOfHearingReviewCancellation(notifyParticipantCaseIDKey);
        notifyThirdPartyOfHearingReviewCancellation(notifyParticipantCaseIDKey);

        // Retrieve appellant type code
        appealCaseIDKey.caseID = key.caseID;

        // Notify respondent if the organization is the appellant.
        notifyRespondentOfHearingReviewCancellation(notifyParticipantCaseIDKey);

        notifyReviewersOfCancellation(notifyParticipantCaseIDKey);

      }

      // Read hearing version no
      hearingKey.hearingID = hearingScheduleDetails.hearingID;
      hearingVersionNumberDetails = hearingObj.readVersionNumber(hearingKey);

      // Update hearing status
      modifyStatusCodesKey = new ModifyStatusCodesKey();
      modifyStatusCodesDetails = new ModifyStatusCodesDetails();
      modifyStatusCodesKey.caseID = key.caseID;
      modifyStatusCodesKey.statusCode = HEARINGSTATUS.SCHEDULED;
      modifyStatusCodesDetails.statusCode = HEARINGSTATUS.CANCELLED;
      modifyStatusCodesDetails.versionNo =
        hearingVersionNumberDetails.versionNo;
      hearingObj.modifyStatusCodesByHearingCaseAndStatus(
        modifyStatusCodesKey, modifyStatusCodesDetails);

      // Raise work flow event to close the complete hearing tasks
      closeTaskEvent.eventKey.eventClass = Appeal.kEventClass;
      closeTaskEvent.eventKey.eventType =
        Appeal.kAppealCloseCompleteHearingTask;
      closeTaskEvent.primaryEventData = hearingKey.hearingID;

      curam.util.events.impl.EventService.raiseEvent(closeTaskEvent);
    } else { // BEGIN, CR00098931, RKi
      // sending notices to the appellants even if hearings does not exist
      // on the case.
      notifyAppellantOfCancellation(notifyParticipantCaseIDKey);
    }
    // END, CR00098931
  }

  // __________________________________________________________________________
  /**
   * Service layer method to validate hearing case status prior to modification
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  protected void validateCaseStatusForModify(final ValidateCaseStatusKey key)
    throws AppException, InformationalException {

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Read hearing case status
    caseHeaderKey.caseID = key.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Check hearing case status
    if (!caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOAPPEALCANCELLATION.ERR_APPEAL_CANCELLATION_FV_NOTCANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // __________________________________________________________________________
  /**
   * Service layer method to cancel a hearing case.
   * 
   * @param key The key of the appeal cancellation
   * 
   * @param details The details of the appeal cancellation
   */
  @Override
  public void cancelHearingReview(final CancelHearingReviewKey key,
    final CancelHearingReviewDetails_bo details) throws AppException,
    InformationalException {

    // Variable for details of cancellation for the appeal case
    final CancelAppealDetails cancelAppealDetails = new CancelAppealDetails();

    // Get the cancellation details
    cancelAppealDetails.cancelReasonCode =
      details.cancelHearingCaseDetails.cancelReasonCode;
    cancelAppealDetails.cancelReasonText =
      details.cancelHearingCaseDetails.cancelReasonText;
    cancelAppealDetails.caseID = key.cancelHearingCaseKey_bo.caseID;
    cancelAppealDetails.caseVersionNo =
      details.cancelHearingCaseDetails.caseVersionNo;

    // Set appeal type to Hearing Review
    cancelAppealDetails.appealTypeCode = APPEALTYPE.HEARINGREVIEW;

    // Cancel the appeal
    cancel(cancelAppealDetails);

  }

  // __________________________________________________________________________
  /**
   * Service layer method to notify a representative of a hearing cancellation.
   * 
   * @param key The case id of the representative
   */
  @Override
  public void notifyRepresentativeOfHearingReviewCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    notifyHearingRepresentativeOfCancellation(key);

  }

  // __________________________________________________________________________
  /**
   * Service layer method to notify an appellant of a hearing review
   * cancellation.
   * 
   * @param key The case id of the appellant
   */
  @Override
  public void notifyAppellantOfHearingReviewCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    notifyAppellantOfCancellation(key);

  }

  // __________________________________________________________________________
  /**
   * Service layer method to notify a respondent of a hearing review
   * cancellation.
   * 
   * @param key The case id of the respondent
   */
  @Override
  public void notifyRespondentOfHearingReviewCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseParticipantRole object
    final CaseParticipantRole caseParticipantRole =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      new CaseParticipantRoleNameDetailsList();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    // Concern role details
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Appeal pro forma document objects
    final AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      AppealProFormaDocumentGenerationFactory.newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Retrieve appellant participants
    caseParticipantRoleCaseAndTypeKey.caseID = key.caseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      CASEPARTICIPANTROLETYPE.RESPONDENT;
    caseParticipantRoleNameDetailsList =
      caseParticipantRole
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    for (int i = 0; i < caseParticipantRoleNameDetailsList.dtls.size(); i++) {

      // Set details to perform the creation of a communication
      communicationDetails.caseID = key.caseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(i).participantRoleID;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;

      // Add concern name to communication
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(i).concernRoleName;

      communicationDetails.userName = TransactionInfo.getProgramUser();

      // Add subject title to communication
      communicationDetails.subjectText =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;

      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.caseID = key.caseID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // set primary key of the data set to the appellant
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(i).caseParticipantRoleID;

      // Set document code and type
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALCANCELLATIONNOTICE;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.CANCELLATION_NOTICE;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }

  }

  // __________________________________________________________________________
  /**
   * Service layer method to notify reviewers of a hearing cancellation.
   * 
   * @param key The case id key of the reviewer
   */
  @Override
  public void notifyReviewersOfCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    // CaseUserRole object
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final CaseUserRoleSearchByCaseAndStatusAndTypeAndDate searchKey =
      new CaseUserRoleSearchByCaseAndStatusAndTypeAndDate();

    // BEGIN, CR00071911, RKi
    OrgObjLinkIDAndCaseUserRoleIDList orgObjLinkIDAndCaseUserRoleIDList;
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    // END, CR00071911

    // Notification objects
    final Notification notificationObj = NotificationFactory.newInstance();

    // current Date
    final Date currentDate = Date.getCurrentDate();

    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Retrieve hearing reviewers
    searchKey.caseID = key.caseID;
    searchKey.typeCode = CASEUSERROLETYPE.HEARINGREVIEWER;
    searchKey.recordStatus = RECORDSTATUS.NORMAL;
    searchKey.activeDate = currentDate;
    // BEGIN, CR00071911, RKi
    orgObjLinkIDAndCaseUserRoleIDList =
      caseUserRoleObj.searchActiveRoleByCaseIDDateAndType(searchKey);

    if (orgObjLinkIDAndCaseUserRoleIDList.dtls.size() > 0) {
      // END, CR00071911

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;

      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject =
        BPOAPPEALCANCELLATION.INF_APPEAL_CANCELLATION_FV_HEARINGCANCELED
          .getMessageText();

      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID =
        Appeal.kAppealNotificationTask;
    }

    // BEGIN, CR00071911, RKi
    for (int i = 0; i < orgObjLinkIDAndCaseUserRoleIDList.dtls.size(); i++) {
      orgObjectLinkKey.orgObjectLinkID =
        orgObjLinkIDAndCaseUserRoleIDList.dtls.item(i).orgObjectLinkID;
      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // Add concern name to communication
      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;
      // END, CR00071911

      // Create the notification
      notificationObj
        .createWorkAllocationNotification(standardManualTaskDtls);
    }

  }

  // __________________________________________________________________________
  /**
   * Service Layer method to Notify the appeal third party of the hearing
   * review cancellation.
   * 
   * @param key The key of the appeal cancellation
   */
  @Override
  public void notifyThirdPartyOfHearingReviewCancellation(
    final NotifyParticipantCaseIDKey key) throws AppException,
    InformationalException {

    notifyThirdPartyOfCancellation(key);

  }

  // __________________________________________________________________________
  /**
   * Updates case status for the appeal to canceled, creates a case event and
   * inserts records the appeal cancellation reason details.
   * 
   * @param details The appeal case cancellation details
   */
  @Override
  protected void cancelCaseDetails(final CancelAppealDetails details)
    throws AppException, InformationalException {

    // Variables for Appeal service layer
    final UpdateAppealCaseStatusDetails updateAppealCaseStatusDetails =
      new UpdateAppealCaseStatusDetails();
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Variables for Case Management
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();
    final curam.core.intf.UniqueID uniqueIDObj =
      UniqueIDFactory.newInstance();

    // Variables for Appeal Cancellation entity
    final curam.appeal.sl.entity.intf.AppealCancellation appealCancellationObj =
      AppealCancellationFactory.newInstance();
    final AppealCancellationDtls appealCancellationDtls =
      new AppealCancellationDtls();

    // Add a case event for cancellation of the appeal case.
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.startDate = Date.getCurrentDate();
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.CASECANCELED;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventObj.insert(caseEventDtls);

    // Update the case status for cancellation.
    updateAppealCaseStatusDetails.caseID = details.caseID;
    updateAppealCaseStatusDetails.statusCode = CASESTATUS.CANCELED;
    updateAppealCaseStatusDetails.versionNo = details.caseVersionNo;
    updateAppealCaseStatusDetails.reasonCode = details.cancelReasonCode;
    appealObj.updateCaseStatus(updateAppealCaseStatusDetails);

    // Insert an appeal cancellation record for the appeal case being canceled
    appealCancellationDtls.cancelDateTime = DateTime.getCurrentDateTime();
    appealCancellationDtls.cancelReasonCode = details.cancelReasonCode;
    appealCancellationDtls.cancelReasonText = details.cancelReasonText;
    appealCancellationDtls.caseID = details.caseID;
    appealCancellationDtls.cancelUserName = TransactionInfo.getProgramUser();
    appealCancellationObj.insert(appealCancellationDtls);

  }

  // __________________________________________________________________________
  /**
   * Cancels an appeal case.
   * 
   * @param details The appeal case cancellation details.
   */
  @Override
  public void cancel(final CancelAppealDetails details)

  throws AppException, InformationalException {

    // Variables for Appeal Relationship entity
    final ActiveCaseKey activeCaseKey = new ActiveCaseKey();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealRelationshipKey appealRelationshipKey =
      new AppealRelationshipKey();
    BenefitPriorAppealAndCaseTypeDetailsList benefitPriorAppealAndCaseTypeDetailsList =
      new BenefitPriorAppealAndCaseTypeDetailsList();
    final StatusAndRecordStatus statusAndRecordStatus =
      new StatusAndRecordStatus();

    // Variables for Case Management
    final CaseEvent caseEventObj = CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();
    final UniqueID uniqueID = UniqueIDFactory.newInstance();

    // Variables for Appeal service layer
    final curam.appeal.sl.intf.Appeal appealObj = AppealFactory.newInstance();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();
    final CreateBenefitTaskAppealedCaseDetails createBenefitTaskAppealedCaseDetails =
      new CreateBenefitTaskAppealedCaseDetails();
    final RemoveRelationshipLinksDetails removeRelationshipLinksDetails =
      new RemoveRelationshipLinksDetails();
    final CaseID caseID = new CaseID();

    // Variables for AppealCancellation service layer
    final CancelScheduledHearingsKey cancelScheduledHearingsKey =
      new CancelScheduledHearingsKey();
    final CancelHearingCaseDetails cancelHearingCaseDetails =
      new CancelHearingCaseDetails();
    final NotifyCaseOwnerCaseIDKey notifyCaseOwnerIDKey =
      new NotifyCaseOwnerCaseIDKey();
    final ValidateCaseStatusKey validateCaseStatusKey =
      new ValidateCaseStatusKey();

    // Appeal Security business objects
    final AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // NotifyParticipantCaseIDKey object
    final NotifyParticipantCaseIDKey notifyParticipantCaseIDKey =
      new NotifyParticipantCaseIDKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID = details.caseID;
    validateSecurityKey.type =
      curam.appeal.sl.impl.AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate that the case status is not already closed or canceled.
    validateCaseStatusKey.caseID = details.caseID;
    validateCaseStatus(validateCaseStatusKey);

    // Cancel the case header status and the case status.
    cancelCaseDetails(details);

    // If the appeal type is not a Judicial Review
    // then cancel scheduled hearings.
    if (!details.appealTypeCode.equals(APPEALTYPE.JUDICIALREVIEW)) {

      cancelScheduledHearingsKey.caseID = details.caseID;

      cancelHearingCaseDetails.appealTypeCode = details.appealTypeCode;
      cancelHearingCaseDetails.cancelReasonCode = details.cancelReasonCode;
      cancelHearingCaseDetails.cancelReasonText = details.cancelReasonText;
      cancelHearingCaseDetails.caseVersionNo = details.caseVersionNo;

      cancelScheduledHearings(cancelScheduledHearingsKey,
        cancelHearingCaseDetails);
    } else { // BEGIN, CR00098931, RKi
      notifyParticipantCaseIDKey.caseID = details.caseID;
      notifyAppellantOfCancellation(notifyParticipantCaseIDKey);
    }// END, CR00098931

    // Notify the appeal case owner of the cancellation
    notifyCaseOwnerIDKey.caseID = details.caseID;
    notifyCaseOwner(notifyCaseOwnerIDKey);

    // Add an appeal cancellation event for this appeal case
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.caseEventID = uniqueID.getNextID();
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.APPEALCANCELED;
    caseEventDtls.startDate = Date.getCurrentDate();
    caseEventDtls.endDate = Date.getCurrentDate();
    caseEventObj.insert(caseEventDtls);

    // Retrieve all of the active appealed cases on this appeal
    activeCaseKey.appealCaseID = details.caseID;

    benefitPriorAppealAndCaseTypeDetailsList =
      appealRelationshipObj
        .searchActiveBenefitPriorAppealAndCaseTypeByAppealCase(activeCaseKey);

    // If there are any active appealed cases on this appeal
    // then cancel the appeal relationship for each appealed case

    if (benefitPriorAppealAndCaseTypeDetailsList.dtls.size() > 0) {

      for (int i = 0; i < benefitPriorAppealAndCaseTypeDetailsList.dtls
        .size(); i++) {

        // Let the status of the appeal relationship be canceled
        appealRelationshipKey.appealRelationshipID =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).appealRelationshipID;

        statusAndRecordStatus.statusCode =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).statusCode;
        statusAndRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;
        statusAndRecordStatus.versionNo =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).versionNo;

        appealRelationshipObj.modifyRecordStatusAndStatusCode(
          appealRelationshipKey, statusAndRecordStatus);

        // If benefits had been discontinued then start a new benefit task
        if (!benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).continueBenefitsIndicator) {

          createBenefitTaskAppealedCaseDetails.caseID =
            benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).caseID;

          createBenefitTaskAppealedCaseDetails.continueBenefitsIndicator =
            true;

          createBenefitTaskAppealedCaseDetails.caseType =
            benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).caseTypeCode;

          appealObj.createBenefitTask(createBenefitTaskAppealedCaseDetails);
        }

        // Remove any relationship links to this appealed case
        appealCaseKey.caseID =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).caseID;

        removeRelationshipLinksDetails.appealTypeCode =
          details.appealTypeCode;

        removeRelationshipLinksDetails.caseID =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).caseID;

        removeRelationshipLinksDetails.caseTypeCode =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).caseTypeCode;

        removeRelationshipLinksDetails.priorAppealCaseID =
          benefitPriorAppealAndCaseTypeDetailsList.dtls.item(i).priorAppealCaseID;

        appealObj.removeRelationshipLinks(removeRelationshipLinksDetails);
      }
    }

    caseID.caseID = details.caseID;
    // Remove Appeal Deadline Task
    appealObj.removeDeadlineTask(caseID);

    // BEGIN, CR00050710, RKi
    if (details.caseID != 0) {

      // Log Transaction Details
      final InsertTransactionLogDetails insertTransactionLogDetails =
        new InsertTransactionLogDetails();

      final curam.core.sl.intf.CaseTransactionLog caseTransactionLog =
        curam.core.sl.fact.CaseTransactionLogFactory.newInstance();

      final AppealCaseIDTYypeRecordStatusDetails appealCaseIDTYypeRecordStatusDetails =
        new AppealCaseIDTYypeRecordStatusDetails();

      final AppealRelationship appealRelationship =
        AppealRelationshipFactory.newInstance();

      appealCaseIDTYypeRecordStatusDetails.appealCaseID = details.caseID;
      appealCaseIDTYypeRecordStatusDetails.caseTypeCode = CASETYPECODE.ISSUE;
      Count count;

      // counts the no. of issues cases attached to the appeal case.
      count =
        appealRelationship
          .countAppealedIssuesOnAppealCase(appealCaseIDTYypeRecordStatusDetails);

      // Create product item child element and add it to the root
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.caseID = details.caseID;

      // BEGIN, CR00052221, RKi
      ProductDeliveryKeyForAppealList productDeliveryKeyForAppealList;
      IssueDeliveryKeyForAppealList issueDeliveryKeyForAppealList;

      // If at least one issue is attached to the appeal
      if (count.numberOfRecords >= 1) {
        issueDeliveryKeyForAppealList =
          appealRelationship
            .searchIssueCaseByAppeal(appealCaseIDTYypeRecordStatusDetails);
        for (int i = 0; i < issueDeliveryKeyForAppealList.dtls.size(); i++) {
          insertTransactionLogDetails.caseID =
            issueDeliveryKeyForAppealList.dtls.item(i).caseID;
          // Log Appeal Canceled event
          insertTransactionLogDetails.eventTypeCode =
            CASETRANSACTIONEVENTS.APPEAL_CANCELLED;
          caseTransactionLog
            .insertTransactionLog(insertTransactionLogDetails);

        }

      } else {
        // Read ProductDelivery
        productDeliveryKeyForAppealList =
          appealRelationship
            .searchProductDeliveryByAppealCaseID(appealCaseIDTYypeRecordStatusDetails);
        for (int i = 0; i < productDeliveryKeyForAppealList.dtls.size(); i++) {
          insertTransactionLogDetails.caseID =
            productDeliveryKeyForAppealList.dtls.item(i).caseID;
          // Log Appeal Canceled event
          insertTransactionLogDetails.eventTypeCode =
            CASETRANSACTIONEVENTS.APPEAL_CANCELLED;
          caseTransactionLog
            .insertTransactionLog(insertTransactionLogDetails);

        }
      }
      // END, CR00052221

    }
    // END, CR00050710
  }

  // __________________________________________________________________________
  /**
   * Cancels an appeal case for a judicial review.
   * 
   * @param details The appeal case cancellation details.
   */

  @Override
  public void cancelJudicialReview(final CancelAppealDetails details)
    throws AppException, InformationalException {

    // Set the appeal type to Judicial Review
    details.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;

    // Cancel the appeal
    cancel(details);

  }

}
