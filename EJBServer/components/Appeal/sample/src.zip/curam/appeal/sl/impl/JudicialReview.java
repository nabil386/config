/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.appeal.sl.entity.fact.AppealObjectFactory;
import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppellantFactory;
import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.intf.AppealObject;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.Appellant;
import curam.appeal.sl.entity.struct.AllAppealParticipantsKey;
import curam.appeal.sl.entity.struct.AppealCaseIDCaseIDRecordStatus;
import curam.appeal.sl.entity.struct.AppealCaseIDKey;
import curam.appeal.sl.entity.struct.AppealCaseParticipantTabDetailList;
import curam.appeal.sl.entity.struct.AppealDtls;
import curam.appeal.sl.entity.struct.AppealID;
import curam.appeal.sl.entity.struct.AppealIDAndDateDetails;
import curam.appeal.sl.entity.struct.AppealObjectDtlsStructList;
import curam.appeal.sl.entity.struct.AppealObjectKeyStruct;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppellantConcernRoleIDDetails;
import curam.appeal.sl.entity.struct.AppellantDtls;
import curam.appeal.sl.entity.struct.HearingDecisionCaseKey;
import curam.appeal.sl.entity.struct.HearingDecisionDtls;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.HearingDecisionStatusVersionDetails;
import curam.appeal.sl.entity.struct.ReceiptNotice;
import curam.appeal.sl.entity.struct.RecordStatusDetails;
import curam.appeal.sl.entity.struct.TranscriptionCaseStatusDetails;
import curam.appeal.sl.entity.struct.TranscriptionRecordCountDetails;
import curam.appeal.sl.fact.AppealFactory;
import curam.appeal.sl.fact.AppealSecurityFactory;
import curam.appeal.sl.fact.DecisionApprovalFactory;
import curam.appeal.sl.intf.Appeal;
import curam.appeal.sl.struct.AddAppealObjectsDetails;
import curam.appeal.sl.struct.AddNewAppealedCaseDetails;
import curam.appeal.sl.struct.AppealAndAppealedCaseDetails;
import curam.appeal.sl.struct.AppealCaseID;
import curam.appeal.sl.struct.AppealCaseKey;
import curam.appeal.sl.struct.AppealModifyDetails;
import curam.appeal.sl.struct.AppealRelationshipKey;
import curam.appeal.sl.struct.AppealedCaseApproveDetails;
import curam.appeal.sl.struct.CaseIDProductID;
import curam.appeal.sl.struct.CloseJudicialReviewDetails;
import curam.appeal.sl.struct.CreateConcernRoleProFormaDocDtls;
import curam.appeal.sl.struct.CreateJudicialDecisionDetails;
import curam.appeal.sl.struct.CreateJudicialReviewAndAppealObjectsDetails;
import curam.appeal.sl.struct.CreateParticipantDetails;
import curam.appeal.sl.struct.CreateReceiptNoticeDtls;
import curam.appeal.sl.struct.CreateUserRoleDetails;
import curam.appeal.sl.struct.DecisionAttachmentDetails;
import curam.appeal.sl.struct.HearingAppealTypeCode;
import curam.appeal.sl.struct.HearingDecisionCaseDetails;
import curam.appeal.sl.struct.HearingDecisionNotifyDetails;
import curam.appeal.sl.struct.JudicialReviewAddAppealedCaseDetails;
import curam.appeal.sl.struct.JudicialReviewAddCaseDetails;
import curam.appeal.sl.struct.JudicialReviewCaseKey;
import curam.appeal.sl.struct.JudicialReviewCaseSummaryDetails;
import curam.appeal.sl.struct.JudicialReviewCreateDetails;
import curam.appeal.sl.struct.JudicialReviewModifyWithoutDeadlineDetails;
import curam.appeal.sl.struct.JudicialReviewNoticeDetails;
import curam.appeal.sl.struct.JudicialReviewTranscriptDetails;
import curam.appeal.sl.struct.JudicialReviewWithoutDeadlineDetails;
import curam.appeal.sl.struct.ListAppellantConcernRoleIDDetails;
import curam.appeal.sl.struct.NotifyOwnerDetails;
import curam.appeal.sl.struct.ReadAppealDetails;
import curam.appeal.sl.struct.ReadAppealUserDetails;
import curam.appeal.sl.struct.ReadAppellantDetails;
import curam.appeal.sl.struct.UpdateAppealCaseStatusDetails;
import curam.appeal.sl.struct.ValidateSecurityKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.APPEALCASERESOLUTION;
import curam.codetable.APPEALDIFFICULTY;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALTYPE;
import curam.codetable.APPELLANTTYPE;
import curam.codetable.CASECLASSIFICATION;
import curam.codetable.CASEEVENTSTATUS;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASEPRIORITY;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DATASETTYPE;
import curam.codetable.HEARINGDECISIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseEventFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleCaseAndTypeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.fact.CaseTransactionLogFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.intf.CaseTransactionLog;
import curam.core.sl.intf.Communication;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CreateStandardManualTaskDetails;
import curam.core.sl.struct.GenerateDocumentDetails1;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.Count;
import curam.core.struct.VersionNumberDetails;
import curam.message.BPOAPPEALEVENTS;
import curam.message.BPOHEARINGCASE;
import curam.message.BPOJUDICIALREVIEW;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;

/**
 * This process class provides the functionality for the Judicial Review service
 * layer.
 * 
 */
public abstract class JudicialReview extends
  curam.appeal.sl.base.JudicialReview {

  // This constant refers to the number of permitted active
  // related appeal cases.
  protected static final short kRelatedAppeals = 1;

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  public JudicialReview() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Creates an judicial review decision
   * 
   * @param key
   * The details of the decision
   */
  @Override
  public void createDecision(final CreateJudicialDecisionDetails key)
    throws AppException, InformationalException {

    final DecisionAttachmentDetails decisionAttachmentDetails =
      new DecisionAttachmentDetails();

    // HearingDecision entity objects
    final curam.appeal.sl.entity.intf.HearingDecision hearingDecisionObj =
      curam.appeal.sl.entity.fact.HearingDecisionFactory.newInstance();
    final HearingDecisionDtls hearingDecisionDtls = new HearingDecisionDtls();

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate maintenance rights for the appeal case
    validateSecurityKey.caseID = key.createAppealDecisionDetails.caseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Validate input data
    validateDecision(key);

    // Insert attachment
    decisionAttachmentDetails.attachmentContents =
      key.createAppealDecisionDetails.attachmentContents;
    decisionAttachmentDetails.caseID = key.createAppealDecisionDetails.caseID;
    decisionAttachmentDetails.fileLocation =
      key.createAppealDecisionDetails.documentLocation;
    decisionAttachmentDetails.fileReferenceNumber =
      key.createAppealDecisionDetails.documentRef;
    decisionAttachmentDetails.attachmentName =
      key.createAppealDecisionDetails.decisionFile;

    // Insert hearing decision
    hearingDecisionDtls.caseID = key.createAppealDecisionDetails.caseID;
    hearingDecisionDtls.comments = key.createAppealDecisionDetails.comments;
    hearingDecisionDtls.decisionDate =
      key.createAppealDecisionDetails.decisionDate;
    hearingDecisionDtls.resolutionCode =
      key.createAppealDecisionDetails.resolutionCode;
    hearingDecisionDtls.decisionStatus =
      curam.codetable.HEARINGDECISIONSTATUS.INPROGRESS;
    hearingDecisionObj.insert(hearingDecisionDtls);
  }

  // ___________________________________________________________________________
  /**
   * This method generates the court petition notice.
   * 
   * @param key
   * The appeal case ID
   */
  @Override
  public void createPetition(final JudicialReviewCaseKey key)
    throws AppException, InformationalException {

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final GenerateDocumentDetails1 generateDocumentDetails =
      new GenerateDocumentDetails1();

    // set primary key of the data set to appeal case id
    generateDocumentDetails.dataSetPrimaryKey = key.caseID;

    // Set document code and type
    generateDocumentDetails.documentIDCode =
      TEMPLATEIDCODE.APPEALCOURTPETITION;
    generateDocumentDetails.dataSetType = DATASETTYPE.COURT_PETITION;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.creationDate = Date.getCurrentDate();

    // Generate the document
    appealProFormaDocumentGenerationObj
      .generateDocument1(generateDocumentDetails);
    // END, CR00293187

  }

  // ___________________________________________________________________________
  /**
   * This method creates a communication for the appellant participant
   * 
   * @param details
   * Identifies the participant and the case
   */
  public void createReceiptNotice(final JudicialReviewNoticeDetails details)
    throws AppException, InformationalException {

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role objects
    final curam.core.intf.ConcernRole concernRoleObj =
      ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();
    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    // Read the concern role name
    concernRoleKey.concernRoleID = details.appellantParticipantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // Set communication details
    communicationDetails.caseID = details.caseID;
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    communicationDetails.communicationDate = Date.getCurrentDate();
    communicationDetails.correspondentConcernRoleID =
      details.appellantParticipantRoleID;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == details.appellantParticipantRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766;
    communicationDetails.userName = TransactionInfo.getProgramUser();
    communicationDetails.subjectText =
      BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;

    // Create the communication
    final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new curam.util.xml.struct.XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode =
      TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
      curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // set primary key of the data set to the appellant
    generateDocumentDetails.dtls.dataSetPrimaryKey =
      details.caseParticipantRoleID;

    // Set document code and type
    generateDocumentDetails.dtls.documentIDCode =
      TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // ___________________________________________________________________________
  /**
   * This method manages transcripts
   * 
   * @param details
   * The details of the transcripts
   */
  @Override
  public void manageTranscript(final JudicialReviewTranscriptDetails details)
    throws AppException, InformationalException {

    // HearingTransferRequest object
    final curam.appeal.sl.entity.intf.HearingTranscriptionRequest hearingTranscriptionRequestObj =
      curam.appeal.sl.entity.fact.HearingTranscriptionRequestFactory
        .newInstance();
    final TranscriptionCaseStatusDetails transcriptionCaseStatusDetails =
      new TranscriptionCaseStatusDetails();

    TranscriptionRecordCountDetails transcriptionRecordCountDetails =
      new TranscriptionRecordCountDetails();

    // Communication objects
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj =
      curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails =
      new CreateStandardManualTaskDetails();

    // ConcernRole object
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    String strJudicialReviewAutoTranscript;

    strJudicialReviewAutoTranscript =
      curam.util.resources.Configuration
        .getProperty(EnvVars.ENV_APPEAL_JUDICIALREVIEWAUTOTRANSCRIPT);

    if (strJudicialReviewAutoTranscript == null) {

      // set to the default value
      strJudicialReviewAutoTranscript =
        EnvVars.ENV_APPEAL_JUDICIALREVIEWAUTOTRANSCRIPT_DEFAULT;
    }

    // Set the key to read the details
    concernRoleKey.concernRoleID = details.appellantParticipantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // check the environment variable
    if (strJudicialReviewAutoTranscript
      .equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      transcriptionCaseStatusDetails.caseID = details.priorCaseID;
      transcriptionRecordCountDetails =
        hearingTranscriptionRequestObj
          .countReceivedTranscriptsByCase(transcriptionCaseStatusDetails);

      if (transcriptionRecordCountDetails.recordCount > 0) {

        // Appeal pro forma document objects
        final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
          curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
            .newInstance();
        final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
          new CreateConcernRoleProFormaDocDtls();

        // - set communication details
        communicationDetails.concernRoleID =
          details.appellantParticipantRoleID;
        communicationDetails.typeCode = COMMUNICATIONTYPE.LETTER;
        communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
        communicationDetails.communicationDate = Date.getCurrentDate();
        communicationDetails.correspondentConcernRoleID =
          details.appellantParticipantRoleID;
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
        communicationDetails.userName = TransactionInfo.getProgramUser();
        communicationDetails.subjectText =
          BPOJUDICIALREVIEW.INF_TRANSCRIPTION_COMM_SUBJECT.getMessageText();
        communicationDetails.communicationText =
          GeneralAppealConstants.kSpace;
        communicationDetails.correspondentName =
          concernRoleNameDetails.concernRoleName;

        // create communication for appellant
        final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
          new curam.util.xml.struct.XSLTemplateIDCodeKey();

        xslTemplateIDCodeKey.templateIDCode =
          TEMPLATEIDCODE.APPEALTRANSCRIPTLETTER;
        xslTemplateIDCodeKey.localeIdentifier =
          TransactionInfo.getProgramLocale();

        final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
          curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

        final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
          xslTemplateUtilityObj
            .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

        proFormaCommDetails.assign(communicationDetails);
        proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
        proFormaCommDetails.proFormaVersionNo =
          xslTemplateInstanceKey.templateVersion;
        proFormaCommDetails.addressID =
          concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
        // BEGIN, CR00293187, CD
        generateDocumentDetails.communicationID =
          communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

        // - look up appellant of prior case
        caseParticipantRoleCaseAndTypeKey.caseID = details.priorCaseID;
        caseParticipantRoleCaseAndTypeKey.recordStatus = RECORDSTATUS.NORMAL;
        caseParticipantRoleCaseAndTypeKey.typeCode =
          CASEPARTICIPANTROLETYPE.APPELLANT;

        // search for an appellant (only one record expected)
        caseParticipantRoleNameDetailsList =
          caseParticipantRole_eoObj
            .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

        // set primary key of the data set to the appellant of prior case
        generateDocumentDetails.dtls.dataSetPrimaryKey =
          caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;

        // set document code
        generateDocumentDetails.dtls.documentIDCode =
          curam.codetable.TEMPLATEIDCODE.APPEALTRANSCRIPTLETTER;
        // set data type
        generateDocumentDetails.dtls.dataSetType =
          curam.codetable.DATASETTYPE.TRANSCRIPTION_LETTER;

        // Generate the document
        appealProFormaDocumentGenerationObj
          .createConcernRoleProFormaDoc(generateDocumentDetails);
        // END, CR00293187

        createStandardManualTaskDetails.taskDtls.subject =
          curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_TRANSCRIPTSUBJECT
            .getMessageText();

        createStandardManualTaskDetails.taskDtls.comments =
          curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_SENDTRANSCRIPTREASON
            .getMessageText();

      } else {

        createStandardManualTaskDetails.taskDtls.subject =
          curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_TRANSCRIPTSUBJECT
            .getMessageText();

        createStandardManualTaskDetails.taskDtls.comments =
          curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_LETTERCOMMREASON
            .getMessageText();

      }

      // Set the priority for the task
      createStandardManualTaskDetails.taskDtls.priority =
        curam.codetable.TASKPRIORITY.NORMAL;

      // Get the transcript for the previous case.
      createStandardManualTaskDetails.concerningDtls.caseID =
        details.priorCaseID;
      createStandardManualTaskDetails.taskDtls.taskDefinitionID =
        curam.appeal.sl.impl.Appeal.kAppealStandardTask;

      // create the task
      workAllocationTaskObj.createTask(createStandardManualTaskDetails);

    }

  }

  // ___________________________________________________________________________
  /*
   * This method retrieves a summary of a judicial review case.
   * 
   * @param key Unique internal reference number of the judicial review case
   * 
   * @return The details of the judicial review
   */
  @Override
  public JudicialReviewCaseSummaryDetails readSummary(
    final JudicialReviewCaseKey key) throws AppException,
    InformationalException {

    // Return details
    final JudicialReviewCaseSummaryDetails judicialReviewCaseSummaryDetails =
      new JudicialReviewCaseSummaryDetails();

    // Variables for retrieving summary details
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();
    final AppealCaseKey appealCaseKey = new AppealCaseKey();

    // Variables for holding appeal summary details
    final ReadAppealDetails readAppealDetails = new ReadAppealDetails();
    ReadAppealUserDetails readAppealUserDetails = new ReadAppealUserDetails();
    ReadAppellantDetails readAppellantDetails = new ReadAppellantDetails();

    // HearingDecision object
    final curam.appeal.sl.entity.intf.HearingDecision hearingDecisionObj =
      curam.appeal.sl.entity.fact.HearingDecisionFactory.newInstance();
    final HearingDecisionCaseKey hearingDecisionCaseKey =
      new HearingDecisionCaseKey();
    curam.appeal.sl.entity.struct.OverallDecisionDetails overallDecisionDetails;

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for reading an appeal case
    validateSecurityKey.caseID = key.caseID;
    validateSecurityKey.type = AppealSecurity.kReadSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // Get the reference number for the lead case
    appealCaseIDKey.caseID = key.caseID;

    appealCaseKey.caseID = key.caseID;

    readAppealDetails.appealReadSummaryDetails =
      appealObj.readWithoutDeadlineByCase(appealCaseIDKey);

    readAppellantDetails = appeal_boObj.readAppellantDetails(appealCaseKey);

    readAppealUserDetails = appeal_boObj.readOwnerDetails(appealCaseKey);

    // BEGIN, CR00265859, DG
    //
    // Get the respondent details
    //
    // BEGIN, CR00288724, MC
    final AllAppealParticipantsKey appealParticipantsKey =
      new AllAppealParticipantsKey();

    appealParticipantsKey.caseID = key.caseID;

    final AppealCaseParticipantTabDetailList participantList =
      appealObj.searchAllAppealParticipantTabDetails(appealParticipantsKey);

    // END, CR00288724

    for (int i = 0; i < participantList.dtls.size(); i++) {
      if (participantList.dtls.item(i).caseParticipantTypeCode
        .equals(CASEPARTICIPANTROLETYPE.RESPONDENT)) {
        judicialReviewCaseSummaryDetails.respondentParticipantRoleID =
          participantList.dtls.item(i).concernRoleID;
        judicialReviewCaseSummaryDetails.respondentName =
          participantList.dtls.item(i).concernRoleName;
      }
    }

    // If no respondent has been set, then it is the product provider
    if (judicialReviewCaseSummaryDetails.respondentParticipantRoleID == 0) {
      for (int i = 0; i < participantList.dtls.size(); i++) {
        if (participantList.dtls.item(i).caseParticipantTypeCode
          .equals(CASEPARTICIPANTROLETYPE.PRODUCTPROVIDER)) {
          judicialReviewCaseSummaryDetails.respondentParticipantRoleID =
            participantList.dtls.item(i).concernRoleID;
          judicialReviewCaseSummaryDetails.respondentName =
            participantList.dtls.item(i).concernRoleName;
        }
      }
    }

    // END, CR00265859

    // Get the decision details for the case
    try {

      hearingDecisionCaseKey.caseID = key.caseID;
      overallDecisionDetails =
        hearingDecisionObj.readOverallDecisionByCase(hearingDecisionCaseKey);

      judicialReviewCaseSummaryDetails.decisionResolution =
        overallDecisionDetails.resolutionCode;
      judicialReviewCaseSummaryDetails.decisionStatus =
        overallDecisionDetails.decisionStatus;
      judicialReviewCaseSummaryDetails.decisionVersionNo =
        overallDecisionDetails.versionNo;
      judicialReviewCaseSummaryDetails.hearingDecisionID =
        overallDecisionDetails.hearingDecisionID;

    } catch (final curam.util.exception.RecordNotFoundException e) {
      judicialReviewCaseSummaryDetails.decisionStatus =
        HEARINGDECISIONSTATUS.NOTSTARTED;
      judicialReviewCaseSummaryDetails.decisionResolution =
        APPEALCASERESOLUTION.NOTDECIDED;
      // END HARP 37065
      judicialReviewCaseSummaryDetails.attachmentID = 0;
    }

    judicialReviewCaseSummaryDetails
      .assign(readAppealDetails.appealReadSummaryDetails);

    judicialReviewCaseSummaryDetails.appellantParticipantRoleID =
      readAppellantDetails.caseParticipantRoleIDDetails.caseParticipantRoleID;
    judicialReviewCaseSummaryDetails.appellantName =
      readAppellantDetails.concernRoleNameDetails.concernRoleName;
    judicialReviewCaseSummaryDetails.ownerUserName =
      readAppealUserDetails.userName;
    judicialReviewCaseSummaryDetails.ownerFullName =
      readAppealUserDetails.userFullname.fullname;

    // Get PriorAppealCaseID
    // changed readPriorAppealCaseID() to return list
    curam.appeal.sl.entity.struct.PriorAppealCaseDetailsList priorAppealCaseDtlsList;

    appealCaseIDKey.caseID = key.caseID;
    priorAppealCaseDtlsList =
      appealObj.readPriorAppealCaseID(appealCaseIDKey);
    if (priorAppealCaseDtlsList.dtls.size() > 0) {
      judicialReviewCaseSummaryDetails.priorAppealCaseID =
        priorAppealCaseDtlsList.dtls.item(0).priorAppealCaseID;
    }

    // BEGIN, CR00021086, RKi
    // To determine if the judicial review case has single or multiple
    // appellants.
    // Required structs
    AppealID appealID = new AppealID();
    final AppealIDAndDateDetails appealIDAndDateDetails =
      new AppealIDAndDateDetails();
    Count count = new Count();
    final Appellant appellantObj = AppellantFactory.newInstance();

    appealCaseIDKey.caseID = key.caseID;

    // retrieve appealID
    appealID = appealObj.readAppealIDByCase(appealCaseIDKey);
    appealIDAndDateDetails.appealID = appealID.appealID;
    appealIDAndDateDetails.date = Date.getCurrentDate();

    // retrieves the count of appellants existing on a judicial review case
    count =
      appellantObj.countActiveAppellantsByAppealID(appealIDAndDateDetails);
    if (count.numberOfRecords > 1) {
      judicialReviewCaseSummaryDetails.multipleAppellant.multipleAppellants =
        true;
    }
    // END, CR00021086

    // BEGIN, CR00050118, RKi
    final CaseTransactionLog caseTransactionLog =
      CaseTransactionLogFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();

    caseIDKey.caseID = key.caseID;
    judicialReviewCaseSummaryDetails.transactionDtlsList =
      caseTransactionLog.readAllTransactions(caseIDKey);
    // END, CR00050118

    // BEGIN, CR00347279,DK
    // Get the appellants on the case
    final curam.appeal.sl.intf.Appellant appellant =
      curam.appeal.sl.fact.AppellantFactory.newInstance();

    appealCaseKey.caseID = key.caseID;
    final ListAppellantConcernRoleIDDetails appellantDetailsList =
      appellant.getAppellantDetails(appealCaseKey);

    judicialReviewCaseSummaryDetails.courtPetitionInd = true;
    for (final AppellantConcernRoleIDDetails details : appellantDetailsList.listDtls.dtls
      .items()) {
      // court petitions are generated only if organization is Appellant.
      if (details.appellantTypeCode.equals(APPELLANTTYPE.CLAIMANT)) {
        judicialReviewCaseSummaryDetails.courtPetitionInd = false;
      }
    }
    // END, CR00347279,DK

    // Return the details
    return judicialReviewCaseSummaryDetails;

  }

  // ___________________________________________________________________________
  /**
   * Validates the decision details
   * 
   * @param details
   * The details of the decision
   */
  @Override
  protected void
    validateDecision(final CreateJudicialDecisionDetails details)
      throws AppException, InformationalException {

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Read the case status
    caseHeaderKey.caseID = details.createAppealDecisionDetails.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Decisions can only be made for active cases
    if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOJUDICIALREVIEW.ERR_DECISION_FV_CASESTATUS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Attachment must be included
    if (details.createAppealDecisionDetails.decisionFile.length() == 0) {

      if (details.createAppealDecisionDetails.documentLocation.length() == 0
        || details.createAppealDecisionDetails.documentRef.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOJUDICIALREVIEW.ERR_DECISION_FV_DECISIONDOCUMENTMISSING),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies the judicial review details.
   * 
   * @param details
   * The details of the judicial review being modified
   */
  @Override
  public void
    modify(final JudicialReviewModifyWithoutDeadlineDetails details)
      throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Appeal variables
    final AppealModifyDetails appealModifyDetails = new AppealModifyDetails();

    // HearingAppealTypeCode variable
    final HearingAppealTypeCode hearingAppealTypeCode =
      new HearingAppealTypeCode();

    // Update the hearing review
    hearingAppealTypeCode.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;

    appealModifyDetails.appealModifyReadDetails.appealID = details.appealID;
    appealModifyDetails.appealModifyReadDetails.caseHeaderVersionNo =
      details.caseHeaderVersionNo;
    appealModifyDetails.appealModifyReadDetails.caseID = details.caseID;
    appealModifyDetails.appealModifyReadDetails.comments =
      details.appealModifyWithoutDeadlineDetails.comments;
    appealModifyDetails.appealModifyReadDetails.receivedDate =
      details.receivedDate;
    appealModifyDetails.appealModifyReadDetails.versionNo =
      details.appealModifyWithoutDeadlineDetails.versionNo;
    appealModifyDetails.appealModifyReadDetails.difficultyCode =
      APPEALDIFFICULTY.DEFAULTCODE;
    appealObj.modify(appealModifyDetails, hearingAppealTypeCode);

  }

  // ___________________________________________________________________________
  /**
   * Method to read judicial review details for modification
   * 
   * @param key
   * The key of the judicial review being modified
   * 
   * @return The judicial review details
   */
  @Override
  public JudicialReviewWithoutDeadlineDetails readForModify(
    final JudicialReviewCaseKey key) throws AppException,
    InformationalException {

    // Judicial Review without deadline variables.
    final JudicialReviewWithoutDeadlineDetails judicialReviewWithoutDeadlineDetails =
      new JudicialReviewWithoutDeadlineDetails();

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // Read the appeal case
    appealCaseIDKey.caseID = key.caseID;
    judicialReviewWithoutDeadlineDetails.appealWithoutDeadlineDetails =
      appealObj.readWithoutDeadlineForModify(appealCaseIDKey);

    return judicialReviewWithoutDeadlineDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to close the judicial review case.
   * 
   * @param details
   * The key of the judicial review case being closed.
   */
  @Override
  public void close(final CloseJudicialReviewDetails details)
    throws AppException, InformationalException {

    // HearingDecision objects
    final curam.appeal.sl.entity.intf.HearingDecision hearingDecisionObj =
      HearingDecisionFactory.newInstance();
    final HearingDecisionKey hearingDecisionKey = new HearingDecisionKey();
    final HearingDecisionStatusVersionDetails hearingDecisionStatusVersionDetails =
      new HearingDecisionStatusVersionDetails();

    // DecisionApproval objects
    final curam.appeal.sl.intf.DecisionApproval decisionApproval_boObj =
      DecisionApprovalFactory.newInstance();
    final HearingDecisionCaseDetails hearingDecisionCaseDetails =
      new HearingDecisionCaseDetails();

    // CaseEvent objects
    final curam.core.intf.CaseEvent caseEventObj =
      CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj =
      UniqueIDFactory.newInstance();

    // AppealRelationship entity and manipulation variables
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();
    curam.appeal.sl.entity.struct.AppealedCaseDetailsList appealedCaseDetailsList;
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    // caseHeader variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.core.struct.CaseAppealIndicatorDetails caseAppealIndicatorDetails =
      new curam.core.struct.CaseAppealIndicatorDetails();

    // Appeal variables and structs
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final UpdateAppealCaseStatusDetails updateAppealCaseStatusDetails =
      new UpdateAppealCaseStatusDetails();

    final HearingDecisionNotifyDetails hearingDecisionNotifyDetails =
      new HearingDecisionNotifyDetails();

    VersionNumberDetails versionNumberDetails = new VersionNumberDetails();

    // Today's date
    final Date currentDate = Date.getCurrentDate();

    // Validate the details
    validateClose(details);

    // Update decision status to "approved"
    hearingDecisionKey.hearingDecisionID = details.hearingDecisionID;
    hearingDecisionStatusVersionDetails.versionNo = details.decisionVersionNo;
    hearingDecisionStatusVersionDetails.decisionStatus =
      curam.codetable.HEARINGDECISIONSTATUS.APPROVED;
    hearingDecisionObj.modifyStatus(hearingDecisionKey,
      hearingDecisionStatusVersionDetails);

    hearingDecisionNotifyDetails.caseID = details.caseID;
    hearingDecisionNotifyDetails.decisionResolution =
      curam.codetable.HEARINGDECISIONRESOLUTION.ACCEPTED;

    decisionApproval_boObj.notifyAppellant(hearingDecisionNotifyDetails);

    decisionApproval_boObj.notifyRespondent(hearingDecisionNotifyDetails);

    // populate key to read back correct version number
    caseHeaderKey.caseID = details.caseID;

    // return correct version number to allow modify to complete correctly
    versionNumberDetails = caseHeaderObj.readVersionNumber(caseHeaderKey);

    // Update case status to "closed"
    updateAppealCaseStatusDetails.caseID = details.caseID;
    updateAppealCaseStatusDetails.statusCode = CASESTATUS.CLOSED;

    // pass correct version number to modify operation
    updateAppealCaseStatusDetails.versionNo = versionNumberDetails.versionNo;

    appeal_boObj.updateCaseStatus(updateAppealCaseStatusDetails);

    // Insert "Case Closed" event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = details.caseID;
    caseEventDtls.startDate = currentDate;
    caseEventDtls.endDate = currentDate;
    caseEventDtls.statusCode = CASEEVENTSTATUS.COMPLETED;
    caseEventDtls.eventTypeCode = CASEEVENTTYPE.CASECLOSURE;
    caseEventDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    caseEventObj.insert(caseEventDtls);

    // List all the appealed cases associated with the appeal
    appealCaseID.appealCaseID = details.caseID;
    appealedCaseDetailsList =
      appealRelationshipObj
        .searchAppealedCaseDetailsByAppealCase(appealCaseID);

    hearingDecisionCaseDetails.caseID = details.caseID;

    for (int i = 0; i < appealedCaseDetailsList.dtls.size(); i++) {

      // Update appeal indicators and insert "Appeal Decided" event for linked
      // cases for the judicial review case
      caseHeaderKey.caseID = appealedCaseDetailsList.dtls.item(0).caseID;

      // Modify the appeal indicator to false
      caseAppealIndicatorDetails.appealIndicator = false;
      caseHeaderObj.modifyAppealIndicator(caseHeaderKey,
        caseAppealIndicatorDetails);

      caseEventDtls.caseEventID = uniqueIDObj.getNextID();
      caseEventDtls.caseID = appealedCaseDetailsList.dtls.item(0).caseID;
      caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
      caseEventDtls.startDate = currentDate;
      caseEventDtls.endDate = currentDate;
      caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.COMPLETED;
      caseEventDtls.eventTypeCode =
        curam.codetable.CASEEVENTTYPE.APPEALDECIDED;

      // Insert the case event
      caseEventObj.insert(caseEventDtls);

      // Send notification to case owner if necessary
      decisionApproval_boObj.notifyCaseOwner(hearingDecisionCaseDetails);
    }

    // Create task for the case owners to implement the appeal decision
    decisionApproval_boObj
      .createImplementationDeadlineTasks(hearingDecisionCaseDetails);

  }

  // ___________________________________________________________________________
  /**
   * Validates the details when a judicial review is closed
   * 
   * @param details
   * The details of the decision
   */
  @Override
  protected void validateClose(final CloseJudicialReviewDetails details)
    throws AppException, InformationalException {

    // CaseHeader objects
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode;

    // Read the case status
    caseHeaderKey.caseID = details.caseID;
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // A case cannot be closed twice
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)
      || caseStatusCode.statusCode.equals(CASESTATUS.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOJUDICIALREVIEW.ERR_JUDICIALREVIEW_CLOSEINVALIDCASESTATUS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // A decision must be recorded
    if (details.hearingDecisionID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOJUDICIALREVIEW.ERR_JUDICIALREVIEW_CLOSEMISSINGDECISION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new judicial review case
   * 
   * @param details
   * The details of the judicial review to be created
   */
  @Override
  public JudicialReviewCaseKey create(
    final JudicialReviewCreateDetails details) throws AppException,
    InformationalException {

    // Return details
    final JudicialReviewCaseKey judicialReviewCaseKey =
      new JudicialReviewCaseKey();

    // Appeal business object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj =
      curam.core.fact.UniqueIDFactory.newInstance();

    // Case header variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    // CaseStatus object
    final curam.core.intf.CaseStatus caseStatusObj =
      curam.core.fact.CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    // UserRoles
    final CreateUserRoleDetails createUserRoleDetails =
      new CreateUserRoleDetails();

    // Appeal entity object
    final curam.appeal.sl.entity.intf.Appeal appealEntityObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // AppealDtls
    final AppealDtls appealDtls = new AppealDtls();

    // Today's date
    final curam.util.type.Date currentDate =
      curam.util.type.Date.getCurrentDate();

    // Create participant details
    final CreateParticipantDetails createParticipantDetails =
      new CreateParticipantDetails();

    // Variable for adding appealed case details to a judicial review
    final JudicialReviewAddAppealedCaseDetails judicialReviewAddAppealedCaseDetails =
      new JudicialReviewAddAppealedCaseDetails();

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for creating an appeal case
    validateSecurityKey.caseID = details.appealCreateCaseDetails.caseID;
    validateSecurityKey.type = AppealSecurity.kCreateSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // BEGIN, CR00177498, PM
    // court petitions are generated only if organization is Appellant.
    if (details.courtPetitionInd
      && details.appealCreateCaseDetails.appellantTypeCode
        .equals(APPELLANTTYPE.CLAIMANT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOJUDICIALREVIEW.ERR_JUDICIALREVIEW_ORGASAPPELLANT_FORPETITION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    // END, CR00177498

    validateCreate(details);

    // Insert the CaseHeader record for the appeal case
    caseHeaderDtls.caseTypeCode = CASETYPECODE.APPEAL;
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();
    caseHeaderDtls.startDate = currentDate;
    caseHeaderDtls.expectedEndDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.endDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.effectiveDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.registrationDate = currentDate;
    caseHeaderDtls.statusCode = CASESTATUS.ACTIVE;
    caseHeaderDtls.priorityCode = CASEPRIORITY.DEFAULTCODE;
    caseHeaderDtls.classificationCode = CASECLASSIFICATION.DEFAULTCODE;
    caseHeaderDtls.concernRoleID =
      details.appealCreateCaseDetails.participantRoleID;
    caseHeaderDtls.appealIndicator = false;
    // the owner ID is update when the CaseUserRole is created
    caseHeaderDtls.ownerOrgObjectLinkID = 0;

    caseHeaderDtls.caseReference =
      curam.core.sl.fact.CaseFactory.newInstance().getCaseReference(
        caseHeaderDtls).caseReference;
    caseHeaderDtls.receivedDate =
      details.addAppealedCaseInputDetails.dateReceived;

    // BEGIN ,CR00284371 , DK
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.appealCreateCaseDetails.caseID;
    final boolean isIntegratedCaseInd =
      caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode
        .equals(CASETYPECODE.INTEGRATEDCASE);

    if (isIntegratedCaseInd) {
      caseHeaderDtls.integratedCaseID =
        details.appealCreateCaseDetails.caseID;
    } else {
      caseHeaderDtls.integratedCaseID =
        details.appealCreateCaseDetails.parentCaseID;
    }
    // END , CR00284371 , DK

    caseHeaderObj.insert(caseHeaderDtls);

    // Insert the Appeal record
    // appealDtls.appellantTypeCode =
    // details.appealCreateCaseDetails.appellantTypeCode;
    appealDtls.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;
    appealDtls.difficultyCode = APPEALDIFFICULTY.DEFAULTCODE;
    appealDtls.comments = details.addAppealedCaseInputDetails.comments;
    appealDtls.caseID = caseHeaderDtls.caseID;

    appealEntityObj.insert(appealDtls);

    // Create user roles for appeal
    createUserRoleDetails.appealCaseID = caseHeaderDtls.caseID;
    appeal_boObj.createUserRoles(createUserRoleDetails);

    // Create the appellant or respondent case participant role record
    // for the review case
    createParticipantDetails.participantRoleID =
      details.appealCreateCaseDetails.participantRoleID;
    createParticipantDetails.appealCaseID = caseHeaderDtls.caseID;

    if (details.appealCreateCaseDetails.appellantTypeCode
      .equals(APPELLANTTYPE.ORGANIZATION)) {

      appeal_boObj.createRespondentParticipant(createParticipantDetails);

    } else {
      CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey =
        appeal_boObj.createAppellantParticipant(createParticipantDetails);
      // add the appellant to appellant entity
      final Appellant appellantObj = AppellantFactory.newInstance();
      final AppellantDtls appellantDtls = new AppellantDtls();

      appellantDtls.appealID = appealDtls.appealID;
      appellantDtls.caseParticipantRoleID =
        caseParticipantRoleKey.caseParticipantRoleID;
      appellantDtls.appellantTypeCode =
        details.appealCreateCaseDetails.appellantTypeCode;
      appellantDtls.emergencyCode =
        details.addAppealedCaseInputDetails.emergencyCode;
      appellantDtls.comments = details.addAppealedCaseInputDetails.comments;
      appellantDtls.receivedDate =
        details.addAppealedCaseInputDetails.dateReceived;
      appellantDtls.fromDate = Date.getCurrentDate();
      appellantDtls.reasonCode =
        details.addAppealedCaseInputDetails.reasonCode;
      appellantDtls.receiptMethod =
        details.addAppealedCaseInputDetails.receiptMethod;
      appellantDtls.receiptNoticeIndicator =
        details.addAppealedCaseInputDetails.receiptNoticeIndicator;
      appellantObj.insert(appellantDtls);
      // END, CR00021086

    }

    // Insert a CaseStatus record for the judicial review case
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();
    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.endDate = curam.util.type.Date.kZeroDate;
    caseStatusDtls.statusCode = CASESTATUS.ACTIVE;
    caseStatusDtls.startDate = currentDate;

    caseStatusObj.insert(caseStatusDtls);

    // Add the appealed case
    judicialReviewAddAppealedCaseDetails.courtPetitionInd =
      details.courtPetitionInd;
    judicialReviewAddAppealedCaseDetails.addAppealedCaseDetails.addAppealedCaseInputDetails =
      details.addAppealedCaseInputDetails;
    judicialReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID =
      appealDtls.caseID;
    judicialReviewAddAppealedCaseDetails.addAppealedCaseDetails.priorAppealCaseID =
      details.appealCreateCaseDetails.priorAppealCaseID;
    judicialReviewAddAppealedCaseDetails.addAppealedCaseDetails.implCaseID =
      details.appealCreateCaseDetails.caseID;

    addAppealedCase(judicialReviewAddAppealedCaseDetails);

    judicialReviewCaseKey.caseID = caseHeaderDtls.caseID;

    // BEGIN, CR00050710, RKi
    if (appealDtls.caseID != 0) {

      // BEGIN, CR00443340, DG
      // Log Transaction Details
      LocalisableString description =
        new LocalisableString(BPOAPPEALEVENTS.APPEALCREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEAL_CREATED, description,
        details.appealCreateCaseDetails.caseID,
        details.appealCreateCaseDetails.caseID);

      description =
        new LocalisableString(BPOAPPEALEVENTS.APPEALEDTOJUDICIALREVIEW);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.APPEALED_TO_JUDICIAL_REVIEW, description,
        details.appealCreateCaseDetails.caseID,
        details.appealCreateCaseDetails.caseID);

      description =
        new LocalisableString(BPOAPPEALEVENTS.JUDICIALREVIEWCASECREATED);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.HEARING_REVIEW_CASE_CREATED, description,
        appealDtls.caseID, appealDtls.caseID);
      // END, CR00443340
    }
    // END, CR00050710
    return judicialReviewCaseKey;

  }

  // ___________________________________________________________________________
  /**
   * Validates the new judicial review details before creating the case
   * 
   * @param details
   * The details of the judicial review to be validated
   */
  @Override
  public void validateCreate(final JudicialReviewCreateDetails details)
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();

    // Validate the appeal case creation
    appealObj.validateCreateAppealCase(details.appealCreateCaseDetails);

  }

  // ___________________________________________________________________________
  /**
   * Adds an appealed case to the judicial review.
   * 
   * @param details
   * The details required to add an appealed case to a judicial review
   */

  @Override
  protected void addAppealedCase(
    final JudicialReviewAddAppealedCaseDetails details) throws AppException,
    InformationalException {

    // Appeal object
    final curam.appeal.sl.intf.Appeal appeal_boObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // Variables for adding an appealed case
    final JudicialReviewCaseKey judicialReviewCaseKey =
      new JudicialReviewCaseKey();
    final AddNewAppealedCaseDetails addNewAppealedCaseDetails =
      new AddNewAppealedCaseDetails();

    // Notification details of owner
    final NotifyOwnerDetails notifyOwnerDetails = new NotifyOwnerDetails();

    // Appeal details used for creating a receipt
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // AppellantTypeDetails appellantTypeDetails;

    // AppealedCaseApproval object and structs
    final curam.appeal.sl.intf.AppealedCaseApproval appealedCaseApprovalObj =
      curam.appeal.sl.fact.AppealedCaseApprovalFactory.newInstance();
    final AppealedCaseApproveDetails appealedCaseApproveDetails =
      new AppealedCaseApproveDetails();

    // AppealRelationship object and structs
    final curam.appeal.sl.entity.intf.AppealRelationship appealRelationshipObj =
      curam.appeal.sl.entity.fact.AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    curam.appeal.sl.entity.struct.ReadSummaryDetails readSummaryDetails;

    // Get PriorAppealCaseID
    // changed readPriorAppealCaseID() to return list
    curam.appeal.sl.entity.struct.PriorAppealCaseDetailsList priorAppealCaseDtlsList;
    long priorAppealCaseID = details.addAppealedCaseDetails.priorAppealCaseID;

    if (priorAppealCaseID == 0) {
      appealCaseIDKey.caseID = details.addAppealedCaseDetails.implCaseID;
      priorAppealCaseDtlsList =
        appealObj.readPriorAppealCaseID(appealCaseIDKey);
      if (priorAppealCaseDtlsList.dtls.size() > 0) {
        priorAppealCaseID =
          priorAppealCaseDtlsList.dtls.item(0).priorAppealCaseID;
      }
    }

    // Add an appealed case
    addNewAppealedCaseDetails.implCaseID =
      details.addAppealedCaseDetails.implCaseID;
    addNewAppealedCaseDetails.appealCaseID =
      details.addAppealedCaseDetails.appealCaseID;
    addNewAppealedCaseDetails.priorAppealCaseID = priorAppealCaseID;

    addNewAppealedCaseDetails.appealTypeCode = APPEALTYPE.JUDICIALREVIEW;
    addNewAppealedCaseDetails.addAppealedCaseInputDetails =
      details.addAppealedCaseDetails.addAppealedCaseInputDetails;

    // relationship key to get the appealRelationshipID
    final AppealRelationshipKey appealRelationshipKey_bo =
      appeal_boObj.addAppealedCase(addNewAppealedCaseDetails);

    // Get the appealed case details.
    appealRelationshipKey.appealRelationshipID =
      appealRelationshipKey_bo.appealRelationshipID;
    readSummaryDetails =
      appealRelationshipObj.readSummary(appealRelationshipKey);

    // BEGIN, CR00075661, RKi
    // The appealed case is already approved if it is
    // created on an Issue case.
    final AppealCaseID appealCaseID = new AppealCaseID();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final Appeal appeal = AppealFactory.newInstance();

    appealCaseID.caseID = details.addAppealedCaseDetails.appealCaseID;
    final CaseIDProductID caseIDProductID =
      appeal.getCaseIDAndProductIDForAppealCase(appealCaseID);

    // BEGIN, CR00303986, SG
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseIDProductID.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (!CASETYPECODE.ISSUE.equals(caseTypeCode.caseTypeCode)) {
      // END, CR00303986
      // Automatically approve the appealed case only if created on
      // Product Delivery.
      appealedCaseApproveDetails.appealRelationshipID =
        appealRelationshipKey_bo.appealRelationshipID;
      appealedCaseApproveDetails.appealVersionNo =
        readSummaryDetails.appealVersionNo;
      appealedCaseApproveDetails.caseHeaderVersionNo =
        readSummaryDetails.caseHeaderVersionNo;
      appealedCaseApproveDetails.versionNo = readSummaryDetails.versionNo;
      appealedCaseApprovalObj.approve(appealedCaseApproveDetails);
    }
    // END, CR00075661

    // Send notification to case owners
    notifyOwnerDetails.caseID = details.addAppealedCaseDetails.implCaseID;
    notifyOwnerDetails.priorAppealCaseID =
      details.addAppealedCaseDetails.priorAppealCaseID;
    notifyOwnerDetails.appealCaseID =
      details.addAppealedCaseDetails.appealCaseID;
    notifyOwnerAboutReview(notifyOwnerDetails);

    // A receipt notice is being generated for all outstanding appealed cases
    if (details.addAppealedCaseDetails.addAppealedCaseInputDetails.receiptNoticeIndicator) {

      // appeal case details object
      final AppealAndAppealedCaseDetails appealAndAppealedCaseDetails =
        new AppealAndAppealedCaseDetails();

      // set object ID properties
      appealAndAppealedCaseDetails.appealCaseID =
        details.addAppealedCaseDetails.appealCaseID;
      appealAndAppealedCaseDetails.appealRelationshipID =
        appealRelationshipKey_bo.appealRelationshipID;

      createReceiptNotice(appealAndAppealedCaseDetails);

      // create and set record status object
      final AppealCaseIDCaseIDRecordStatus appealCaseIDCaseIDRecordStatus =
        new AppealCaseIDCaseIDRecordStatus();

      appealCaseIDCaseIDRecordStatus.appealCaseID =
        details.addAppealedCaseDetails.appealCaseID;
      appealCaseIDCaseIDRecordStatus.caseID =
        details.addAppealedCaseDetails.implCaseID;
      appealCaseIDCaseIDRecordStatus.recordStatus = RECORDSTATUS.NORMAL;

      // Set receipt notice to true
      final ReceiptNotice receiptNotice = new ReceiptNotice();

      receiptNotice.receiptNoticeIndicator = true;

      appealRelationshipObj.modifyReceiptNoticeIndicator(
        appealCaseIDCaseIDRecordStatus, receiptNotice);
    }

    // Generate a court petition if the organization is the appellant and a
    // court petition has been requested. If the appellant is not the
    // organization then manage any hearing transcription requests.
    appealCaseIDKey.caseID = details.addAppealedCaseDetails.appealCaseID;

    if (details.courtPetitionInd) {

      judicialReviewCaseKey.caseID =
        details.addAppealedCaseDetails.appealCaseID;
      createPetition(judicialReviewCaseKey);

    } else if (details.addAppealedCaseDetails.priorAppealCaseID != 0) {

      // Variables used to populate the transcript details
      final JudicialReviewTranscriptDetails judicialReviewTranscriptDetails =
        new JudicialReviewTranscriptDetails();
      final AppealCaseKey appealCaseKey = new AppealCaseKey();

      appealCaseKey.caseID = details.addAppealedCaseDetails.appealCaseID;

      judicialReviewTranscriptDetails.appellantParticipantRoleID =
        appeal_boObj.readAppellantDetails(appealCaseKey).caseParticipantRoleIDDetails.participantRoleID;
      judicialReviewTranscriptDetails.judicialReviewCaseID =
        details.addAppealedCaseDetails.appealCaseID;
      judicialReviewTranscriptDetails.priorCaseID =
        details.addAppealedCaseDetails.priorAppealCaseID;

      // BEGIN, CR00099031, RKi
      if (judicialReviewTranscriptDetails.appellantParticipantRoleID != 0) {
        manageTranscript(judicialReviewTranscriptDetails);
      }
      // END, CR00099031
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the appealed case details to be added to the judicial review
   * 
   * @param details
   * The details of the appealed case to be validated
   */
  @Override
  public void validateAddAppealedCase(
    final JudicialReviewAddAppealedCaseDetails details) throws AppException,
    InformationalException {

    // Variables for reading appellant type details
    final AppealCaseIDKey appealCaseIDKey = new AppealCaseIDKey();

    // A court petition can only be created when the organization is the
    // appellant on the appeal case. Checking that this is true.
    appealCaseIDKey.caseID = details.addAppealedCaseDetails.appealCaseID;

    if (details.courtPetitionInd) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOJUDICIALREVIEW.ERR_JUDICIALREVIEW_ORGASAPPELLANT_FORPETITION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Notifies the relevant user(s) about the judicial review.
   * 
   * @param details
   * The details required to notify the owners
   */
  @Override
  public void notifyOwnerAboutReview(final NotifyOwnerDetails details)
    throws AppException, InformationalException {

    // CaseHeader details
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Notification variables
    final curam.core.intf.Notification notificationObj =
      curam.core.fact.NotificationFactory.newInstance();

    // StandardManualTask details
    final StandardManualTaskDtls standardManualTaskDtls =
      new StandardManualTaskDtls();

    // Case User Role objects
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();
    final curam.core.sl.intf.CaseUserRole caseUserRole =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    AppException subjectInfo;

    subjectInfo =
      new AppException(
        curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_FV_CASEUNDERAPPEAL);

    // read maintainCase
    CaseReferenceAndStatusDetails caseReferenceAndStatusDtls =
      new CaseReferenceAndStatusDetails();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = details.caseID;
    caseReferenceAndStatusDtls =
      caseHeaderObj.readCaseReferenceAndStatusByCaseID(caseSearchKey);

    subjectInfo.arg(caseReferenceAndStatusDtls.caseReference);

    if (details.priorAppealCaseID != 0) {

      caseHeaderKey.caseID = details.priorAppealCaseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // Owner of hearing case
      orgObjectLinkKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;

      caseOwnerDetails = caseUserRole.readOwnerName(orgObjectLinkKey);

      // A notification is sent to the case owner of the prior appeal case
      // when a decision from a prior appeal case is being appealed. A check
      // to ensure the current user is not the user to whom the notification
      // is being sent is carried out first.
      if (!caseOwnerDetails.userName
        .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

        standardManualTaskDtls.dtls.concerningDtls.caseID =
          details.priorAppealCaseID;

        standardManualTaskDtls.dtls.taskDtls.comments =
          GeneralAppealConstants.kSpace;
        standardManualTaskDtls.dtls.taskDtls.subject =
          subjectInfo.getMessage();
        standardManualTaskDtls.dtls.assignDtls.assignmentID =
          caseOwnerDetails.userFullName;
        standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
          caseHeaderDtls.concernRoleID;

        // BEGIN, CR00053295, RKi
        notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
        // END, CR00053295
      }

    }

    caseHeaderKey.caseID = details.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // A notification is sent to the case owner of the implementation case
    // being appealed.
    if (!caseOwnerDetails.userName
      .equals(curam.util.transaction.TransactionInfo.getProgramUser())) {

      standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;
      standardManualTaskDtls.dtls.taskDtls.comments =
        GeneralAppealConstants.kSpace;
      standardManualTaskDtls.dtls.taskDtls.subject = subjectInfo.getMessage();
      standardManualTaskDtls.dtls.assignDtls.assignmentID =
        caseOwnerDetails.userFullName;
      standardManualTaskDtls.dtls.concerningDtls.participantRoleID =
        caseHeaderDtls.concernRoleID;

      // BEGIN, CR00053295, RKi
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
      // END, CR00053295

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for appeal for all outstanding appealed cases for an appeal case..
   * 
   * @param details
   * Contains the appealCaseID and list of cases being appealed
   */
  @Override
  public void createReceiptNotice(final CreateReceiptNoticeDtls details)
    throws AppException, InformationalException {

    // caseParticipantRole object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();
    CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList;

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // get the appellant for the appeal case
    caseParticipantRoleCaseAndTypeKey.caseID = details.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // get the active participant for the case
    caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check that record is found
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      communicationDetails.caseID = details.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.userName = TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        curam.message.BPOHEARINGCASE.INF_HEARINGCASE_SUBJECTTEXT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      concernRoleObj.readConcernRoleName(concernRoleKey);

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;

      // BEGIN, CR00293187, CD
      // appeal pro forma document objects
      final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
          .newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      generateDocumentDetails.dtls.dataSetPrimaryKey =
        caseParticipantRoleNameDetailsList.dtls.item(0).caseParticipantRoleID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTHEARINGREVIEW;

      generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates the receipt notice which acknowledges the receipt of the request
   * for a single appealed case for an appeal.
   * 
   * @param key
   * The appealed case, and it's corresponding appeal case, for which
   * to generate a receipt notice.
   */
  @Override
  public void createReceiptNotice(final AppealAndAppealedCaseDetails key)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // Get the appellant for the appeal case
    final CaseParticipantRoleCaseAndTypeKey caseParticipantRoleCaseAndTypeKey =
      new CaseParticipantRoleCaseAndTypeKey();

    caseParticipantRoleCaseAndTypeKey.caseID = key.appealCaseID;
    caseParticipantRoleCaseAndTypeKey.typeCode =
      curam.codetable.CASEPARTICIPANTROLETYPE.APPELLANT;

    // Get the active participant for the case
    final CaseParticipantRoleNameDetailsList caseParticipantRoleNameDetailsList =
      caseParticipantRoleObj
        .searchActiveRoleAndNameByCaseAndType(caseParticipantRoleCaseAndTypeKey);

    // Check that record is found
    if (caseParticipantRoleNameDetailsList.dtls.size() > 0) {

      // Communication objects
      final CommunicationDetails communicationDetails =
        new CommunicationDetails();
      final ProFormaCommDetails1 proFormaCommDetails =
        new ProFormaCommDetails1();
      final Communication communicationObj =
        CommunicationFactory.newInstance();

      // Concern role details
      final curam.core.intf.ConcernRole concernRoleObj =
        curam.core.fact.ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // Appeal pro forma document objects
      final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
        curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
          .newInstance();
      final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
        new CreateConcernRoleProFormaDocDtls();

      communicationDetails.caseID = key.appealCaseID;
      communicationDetails.correspondentConcernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      communicationDetails.correspondentName =
        caseParticipantRoleNameDetailsList.dtls.item(0).concernRoleName;
      // BEGIN, CR00202766, MC
      // correspondentTypeCode is not a mandatory entity field only set it if
      // the
      // correspondence is going to the primary client
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.appealCaseID;

      if (CaseHeaderFactory.newInstance()
        .readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
        communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
      }
      // END, CR00202766
      communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
      communicationDetails.userName =
        curam.util.transaction.TransactionInfo.getProgramUser();
      communicationDetails.subjectText =
        curam.message.BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_SUBJECTTEXT
          .getMessageText();
      communicationDetails.communicationText = GeneralAppealConstants.kSpace;

      // Create the communication
      concernRoleKey.concernRoleID =
        caseParticipantRoleNameDetailsList.dtls.item(0).participantRoleID;
      concernRoleObj.readConcernRoleName(concernRoleKey);

      final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
        new curam.util.xml.struct.XSLTemplateIDCodeKey();

      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
      xslTemplateIDCodeKey.localeIdentifier =
        TransactionInfo.getProgramLocale();

      final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
        curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

      final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
        xslTemplateUtilityObj
          .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

      proFormaCommDetails.assign(communicationDetails);
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo =
        xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID =
        concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      // BEGIN, CR00293187, CD
      generateDocumentDetails.communicationID =
        communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

      // Set attributes
      generateDocumentDetails.dtls.dataSetPrimaryKey =
        key.appealRelationshipID;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
      generateDocumentDetails.dtls.dataSetType =
        DATASETTYPE.REQUEST_SINGLE_RECEIPT;

      // Generate the document
      appealProFormaDocumentGenerationObj
        .createConcernRoleProFormaDoc(generateDocumentDetails);
      // END, CR00293187

    }
  }

  // ___________________________________________________________________________
  /**
   * Adds a request for appeal to an existing judicial review case.
   * 
   * @param details
   * The details for the appealed case to add.
   */
  @Override
  public void addCase(final JudicialReviewAddCaseDetails details)
    throws AppException, InformationalException {

    // Appeal Security business objects
    final curam.appeal.sl.intf.AppealSecurity appealSecurityObj =
      AppealSecurityFactory.newInstance();
    final ValidateSecurityKey validateSecurityKey = new ValidateSecurityKey();

    // Validate security for maintaining an appeal case
    validateSecurityKey.caseID =
      details.judicialReviewAddAppealedCaseDetails.addAppealedCaseDetails.appealCaseID;
    validateSecurityKey.type = AppealSecurity.kMaintainSecurityCheck;
    appealSecurityObj.validateSecurity(validateSecurityKey);

    // add the appealed case
    addAppealedCase(details.judicialReviewAddAppealedCaseDetails);

  }

  // BEGIN, CR00021348, RKi
  // ___________________________________________________________________________
  /**
   * This method creates receipt notices for the appellant
   * 
   * @param key
   * identifies the appellant
   */
  @Override
  public void
    createReceiptNoticeForAppellant(final CaseParticipantRoleKey key)
      throws AppException, InformationalException {

    // caseParticipantRole object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // Communication object
    final CommunicationDetails communicationDetails =
      new CommunicationDetails();
    final ProFormaCommDetails1 proFormaCommDetails =
      new ProFormaCommDetails1();
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Concern role details
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Get appeal case ID and participant role ID
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails =
      new CaseIDAndParticipantRoleIDDetails();

    caseIDAndParticipantRoleIDDetails =
      caseParticipantRoleObj.readCaseIDAndParticipantRoleIDDetails(key);

    concernRoleKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // Check that record is found
    communicationDetails.caseID = caseIDAndParticipantRoleIDDetails.caseID;
    communicationDetails.correspondentConcernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;
    communicationDetails.correspondentName =
      concernRoleNameDetails.concernRoleName;
    // BEGIN, CR00202766, MC
    // correspondentTypeCode is not a mandatory entity field only set it if the
    // correspondence is going to the primary client
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    if (CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID == communicationDetails.correspondentConcernRoleID) {
      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;
    }
    // END, CR00202766
    communicationDetails.typeCode = COMMUNICATIONTYPE.NOTICE;
    communicationDetails.userName = TransactionInfo.getProgramUser();
    communicationDetails.subjectText =
      BPOJUDICIALREVIEW.INF_JUDICIALREVIEW_SUBJECTTEXT.getMessageText();
    communicationDetails.communicationText = GeneralAppealConstants.kSpace;

    // Create the communication
    final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey =
      new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // BEGIN, CR CR00069029, NSP
    // create person object
    final Person personObj = PersonFactory.newInstance();
    final SearchCaseKey_fo searchCaseKey_fo = new SearchCaseKey_fo();
    // BEGIN, CR00236272, AK
    SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

    searchCaseKey_fo.casesByConcernRoleIDKey.concernRoleID =
      caseIDAndParticipantRoleIDDetails.participantRoleID;

    // Search whether appellant is associated with the case or not
    searchCaseDetails = personObj.searchCase1(searchCaseKey_fo);
    // END, CR00236272

    final CreateConcernRoleProFormaDocDtls generateDocumentDetails =
      new CreateConcernRoleProFormaDocDtls();

    if (searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.size() >= 1) {

      // appellant is associated with the case, so acknowledge an appeal
      // request with continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEW;
    } else {

      // appellant is not associated with the case, so acknowledge an appeal
      // request with no continue benefits
      xslTemplateIDCodeKey.templateIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEWWITHOUTCONTINUEBENEFITS;
      generateDocumentDetails.dtls.documentIDCode =
        TEMPLATEIDCODE.APPEALRECEIPTJUDICIALREVIEWWITHOUTCONTINUEBENEFITS;
    }
    // END, CR CR00069029
    xslTemplateIDCodeKey.localeIdentifier =
      TransactionInfo.getProgramLocale();

    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj =
      curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    final curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey =
      xslTemplateUtilityObj
        .getLatestTemplateKeyByIDCode(xslTemplateIDCodeKey);

    proFormaCommDetails.assign(communicationDetails);
    proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
    proFormaCommDetails.proFormaVersionNo =
      xslTemplateInstanceKey.templateVersion;
    proFormaCommDetails.addressID =
      concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
    // BEGIN, CR00293187, CD
    generateDocumentDetails.communicationID =
      communicationObj.createProFormaReturningID(proFormaCommDetails).communicationID;

    // appeal pro forma document objects
    final curam.appeal.sl.intf.AppealProFormaDocumentGeneration appealProFormaDocumentGenerationObj =
      curam.appeal.sl.fact.AppealProFormaDocumentGenerationFactory
        .newInstance();

    generateDocumentDetails.dtls.dataSetPrimaryKey =
      key.caseParticipantRoleID;
    generateDocumentDetails.dtls.dataSetType = DATASETTYPE.REQUEST_RECEIPT;

    // Generate the document
    appealProFormaDocumentGenerationObj
      .createConcernRoleProFormaDoc(generateDocumentDetails);
    // END, CR00293187
  }

  // ___________________________________________________________________________
  /**
   * Create a judicial review case with a delimited list of objects.
   * 
   * The string of objects should be in the form: ObjectID,ObjectTypeCode| E.g.
   * "1001,AOT1|2001,AOT2|2002,AOT2" represents three objects passed in. Each
   * object type code must have a corresponding entry in the AppealObjectType
   * codetable and an implementation of the appeal object interface class.
   * 
   * @param details
   * Details of the judicial review case.
   * @return The judicial review case identifier.
   */
  @Override
  public JudicialReviewCaseKey createWithAppealObjects(
    final CreateJudicialReviewAndAppealObjectsDetails details)
    throws AppException, InformationalException {

    // Create the hearing case
    final JudicialReviewCaseKey judicialReviewCaseKey = create(details.dtls);

    //
    // Check for any approved appeal objects on a previous appeal case.
    //
    final AppealObject appealObectObj = AppealObjectFactory.newInstance();
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final curam.appeal.sl.entity.struct.AppealRelationshipKey appealRelationshipKey =
      new curam.appeal.sl.entity.struct.AppealRelationshipKey();
    final curam.appeal.sl.entity.struct.AppealCaseID appealCaseID =
      new curam.appeal.sl.entity.struct.AppealCaseID();

    if (details.dtls.appealCreateCaseDetails.priorAppealCaseID != 0
      && details.appealObjectsDelimitedList.isEmpty()) {

      // Get all the appeal relationship records for the previous case
      appealCaseID.appealCaseID =
        details.dtls.appealCreateCaseDetails.priorAppealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {

        if (o.statusCode.equals(APPEALRELATIONSHIPSTATUS.APPROVED)) {
          // Retrieve the objects for this relationship
          final AppealObjectKeyStruct appealObjectKeyStruct =
            new AppealObjectKeyStruct();

          appealObjectKeyStruct.appealRelationshipID = o.appealRelationshipID;
          final AppealObjectDtlsStructList appealObjectDtlsStructList =
            appealObectObj
              .searchByAppealRelationshipID(appealObjectKeyStruct);

          if (!appealObjectDtlsStructList.dtls.isEmpty()) {
            if (details.appealObjectsDelimitedList.length() != 0) {
              details.appealObjectsDelimitedList +=
                CuramConst.gkPipeDelimiterChar;
            }
            details.appealObjectsDelimitedList +=
              appealObjectDtlsStructList.dtls.get(0).objectID
                + CuramConst.gkComma
                + appealObjectDtlsStructList.dtls.get(0).objectType;

          }

        }
      }
    }

    // If appeal objects have been supplied then add them
    if (details.appealObjectsDelimitedList.length() != 0) {
      // Cancel the Appeal Relationship record created for the related case.
      // This has to be canceled as we are appealing a list of objects
      // on the case instead of the case itself.
      final RecordStatusDetails recordStatusDetails =
        new RecordStatusDetails();

      appealCaseID.appealCaseID = judicialReviewCaseKey.caseID;
      recordStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;
      final AppealRelationShipDetailsList appealRelationshipList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationshipList.dtls) {
        appealRelationshipKey.appealRelationshipID = o.appealRelationshipID;
        recordStatusDetails.versionNo =
          appealRelationshipObj
            .readForModifyAppealedCase(appealRelationshipKey).versionNo;
        appealRelationshipObj.modifyRecordStatus(appealRelationshipKey,
          recordStatusDetails);
      }

      // Add the objects to the case
      final AddAppealObjectsDetails addAppealObjectsDetails =
        new AddAppealObjectsDetails();

      addAppealObjectsDetails.appealObjectsDelimitedList =
        details.appealObjectsDelimitedList;
      addAppealObjectsDetails.appealCaseID = judicialReviewCaseKey.caseID;
      addAppealObjectsDetails.caseID =
        details.dtls.appealCreateCaseDetails.caseID;
      addAppealObjectsDetails.comments =
        details.dtls.addAppealedCaseInputDetails.comments;
      addAppealObjectsDetails.continueBenefitsIndicator =
        details.dtls.addAppealedCaseInputDetails.continueBenefitsIndicator;
      addAppealObjectsDetails.dateReceived =
        details.dtls.addAppealedCaseInputDetails.dateReceived;
      addAppealObjectsDetails.effectiveDate =
        details.dtls.addAppealedCaseInputDetails.effectiveDate;
      addAppealObjectsDetails.emergencyCode =
        details.dtls.addAppealedCaseInputDetails.emergencyCode;
      addAppealObjectsDetails.reasonCode =
        details.dtls.addAppealedCaseInputDetails.reasonCode;
      addAppealObjectsDetails.receiptMethod =
        details.dtls.addAppealedCaseInputDetails.receiptMethod;
      addAppealObjectsDetails.receiptNoticeIndicator =
        details.dtls.addAppealedCaseInputDetails.receiptNoticeIndicator;
      curam.appeal.sl.fact.AppealFactory.newInstance()
        .addAppealObjectsToCase(addAppealObjectsDetails);
    }

    return judicialReviewCaseKey;
  }

}
