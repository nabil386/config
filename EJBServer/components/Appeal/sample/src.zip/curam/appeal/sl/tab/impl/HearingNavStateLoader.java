/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.tab.impl;

import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.struct.HearingKey;
import curam.appeal.sl.entity.struct.HearingStatusDateTypeDetails;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.HEARINGTYPE;
import curam.core.impl.TimeZoneUtility;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import java.util.Map;

/**
 * Determines the actions to display based on the status of the Hearing.
 */
public class HearingNavStateLoader implements DynamicMenuStateLoader {

  // ___________________________________________________________________________
  /**
   * Returns the state of the given list of navigation items.
   * 
   * @param navigation
   * The navigation instance to load states into.
   * @param pageParameters
   * The context information, in our current case it is the page
   * parameters.
   * 
   * @param idsToUpdate
   * The IDs requested by the client to be updated.
   * @return The same navigation instance with the updated states.
   */
  @Override
  public MenuState loadMenuState(final MenuState menuState,
    final Map<String, String> pageParameters, final String[] idsToUpdate) {

    // configure menuState
    final MenuState returnState = menuState;

    final HearingKey hearingKey = new HearingKey();

    hearingKey.hearingID =
      Long.parseLong(pageParameters.get(TabLoaderConst.kHearingID));

    HearingStatusDateTypeDetails hearingStatusDateTypeDetails =
      new HearingStatusDateTypeDetails();

    try {
      hearingStatusDateTypeDetails =
        HearingFactory.newInstance().readStatusAndDateAndType(hearingKey);

    } catch (final Exception e) {
      // Set the actions to be not visible
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(false, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    }

    if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.ADJOURNED)) {
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(false, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    } else if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.CANCELLED)) {
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(false, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    } else if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.COMPLETED)) {
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(false, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    } else if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.CONTINUED)) {
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(false, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    } else if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.RESCHEDULED)) {
      returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      returnState.setEnabled(true, TabLoaderConst.kCompleteID);
      returnState.setEnabled(false, TabLoaderConst.kContinueID);
      returnState.setEnabled(false, TabLoaderConst.kRescheduleID);
    } else if (hearingStatusDateTypeDetails.statusCode
      .equals(HEARINGSTATUS.SCHEDULED)) {
      returnState.setEnabled(true, TabLoaderConst.kAdjournID);
      returnState.setEnabled(true, TabLoaderConst.kCompleteID);

      // BEGIN, CR00332401, PS
      returnState.setEnabled(true, TabLoaderConst.kContinueID);
      // END, CR00332401

      returnState.setEnabled(true, TabLoaderConst.kRescheduleID);

      // BEGIN, CR00358518, PS
      if (new Date(TimeZoneUtility.getTimeZoneAdjustedDateTime(
        hearingStatusDateTypeDetails.scheduledDateTime,
        TransactionInfo.getUserTimeZone())).after(Date.getCurrentDate())) {

        returnState.setEnabled(false, TabLoaderConst.kAdjournID);
      } else {
        returnState.setEnabled(false, TabLoaderConst.kContinueID);
      }
      // END, CR00358518
    }

    // The Add Witness action should not be available for desk based hearings
    if (hearingStatusDateTypeDetails.typeCode.equals(HEARINGTYPE.DESK)) {
      returnState.setEnabled(false, TabLoaderConst.kAddWitnessID);
    }

    return returnState;
  }

}
