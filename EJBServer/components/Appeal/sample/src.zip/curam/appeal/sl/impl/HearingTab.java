/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.HearingFactory;
import curam.appeal.sl.entity.struct.ExternalHearingOfficialContextPanelDetail;
import curam.appeal.sl.entity.struct.ExternalHearingOfficialContextPanelDetailList;
import curam.appeal.sl.entity.struct.HearingAttendeeTabDetailKey;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingOfficialContextPanelDtls;
import curam.appeal.sl.entity.struct.HearingOfficialTabDetail;
import curam.appeal.sl.entity.struct.HearingOfficialTabDetailHearingIDKey;
import curam.appeal.sl.entity.struct.HearingOfficialTabDetailList;
import curam.appeal.sl.struct.HearingTabDetail;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.LinksPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.HEARINGLOCATIONTYPE;
import curam.codetable.HEARINGTYPE;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.HEARINGSTATUSEntry;
import curam.codetable.impl.HEARINGTYPEEntry;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.LocationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.intf.CaseHeader;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.struct.AddressKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseReference;
import curam.core.struct.EmptyIndStruct;
import curam.core.struct.LocationKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.UsersKey;
import curam.message.APPEALTAB;
import curam.message.BPOINCIDENTTAB;
import curam.message.HEARINGCONTEXTPANEL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;

/**
 * Provides methods to access the details required for the Hearing Context
 * panels.
 */
public class HearingTab extends curam.appeal.sl.base.HearingTab {

  /**
   * Reads the details of the scheduled hearing.
   *
   * @param hearingKey HearingKeyDetails The hearingID for the hearing.
   * @return HearingTabDetail The details of the scheduled hearing.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public HearingTabDetail readHearingTabDetail(
    final HearingKeyDetails hearingKey) throws AppException,
    InformationalException {

    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      HearingFactory.newInstance();

    final HearingTabDetail hearingTabDetail = new HearingTabDetail();

    hearingTabDetail.dtls = hearingObj.readHearingTabDetail(hearingKey);

    final TabDetailFormatter tabDetailFormatterObj =
      TabDetailFormatterFactory.newInstance();

    // Read the attendee details for the hearing
    final HearingAttendeeTabDetailKey hearingAttendeeKey =
      new HearingAttendeeTabDetailKey();

    hearingAttendeeKey.hearingID = hearingKey.hearingID;

    hearingTabDetail.attendeeDtls =
      hearingObj.readHearingAttendeeTabDetails(hearingAttendeeKey);

    // Return the sum of the case participant and user attendees
    hearingTabDetail.attendeeDtls.attendeeTotalCount =
      hearingTabDetail.attendeeDtls.participantAttendeeCount
      + hearingTabDetail.attendeeDtls.userAttendeeCount
      + hearingTabDetail.attendeeDtls.serviceSupplierAttendeeCount
      + hearingTabDetail.attendeeDtls.thirdPartyAttendeeCount;

    // Read for the list of hearing officials
    final HearingOfficialTabDetailHearingIDKey hearingOfficialTabDetailKey =
      new HearingOfficialTabDetailHearingIDKey();
    HearingOfficialTabDetailList userHearingOfficialsList =
      new HearingOfficialTabDetailList();

    hearingOfficialTabDetailKey.hearingID = hearingKey.hearingID;

    // The hearing official for a Review is stored with a different role type
    // to the hearing official for a hearing case.
    if (hearingTabDetail.dtls.appealTypeCode.equals(APPEALTYPE.HEARINGREVIEW)) {
      hearingOfficialTabDetailKey.hearingOfficialRoleType =
        CASEUSERROLETYPE.HEARINGREVIEWER;

    } else {
      hearingOfficialTabDetailKey.hearingOfficialRoleType =
        CASEUSERROLETYPE.HEARINGOFFICIAL;
    }

    userHearingOfficialsList =
      hearingObj.searchHearingOfficialTabDetail(hearingOfficialTabDetailKey);

    // Hearing reviewers are only ever users
    hearingOfficialTabDetailKey.hearingOfficialRoleType =
      CASEPARTICIPANTROLETYPE.HEARINGOFFICIAL;

    final ExternalHearingOfficialContextPanelDetailList concernRoleHearingOfficialsList =
      hearingObj
      .searchHearingOfficialParticipantsByHearingID(hearingOfficialTabDetailKey);

    HearingOfficialContextPanelDtls hearingOfficialContextPanelDtls;

    for (int i = 0; i < userHearingOfficialsList.dtls.size(); i++) {

      hearingOfficialContextPanelDtls = new HearingOfficialContextPanelDtls();
      hearingOfficialContextPanelDtls.assign(userHearingOfficialsList.dtls
        .item(i));

      hearingTabDetail.hearingOfficialListDtls
      .addRef(hearingOfficialContextPanelDtls);
    }

    for (int i = 0; i < concernRoleHearingOfficialsList.dtls.size(); i++) {

      hearingOfficialContextPanelDtls = new HearingOfficialContextPanelDtls();
      hearingOfficialContextPanelDtls
      .assign(concernRoleHearingOfficialsList.dtls.item(i));
      hearingTabDetail.hearingOfficialListDtls
      .addRef(hearingOfficialContextPanelDtls);
    }

    final Address addressObj = AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();

    if (hearingTabDetail.dtls.hearingTypeCode.equals(HEARINGTYPE.HOME)
      && hearingTabDetail.dtls.addressID != 0) {
      addressKey.addressID = hearingTabDetail.dtls.addressID;
    } else if (hearingTabDetail.dtls.hearingTypeCode
      .equals(HEARINGTYPE.LOCATION)) {
      if (hearingTabDetail.dtls.locationType
        .equals(HEARINGLOCATIONTYPE.EXTERNAL)) {

        addressKey.addressID =
          hearingTabDetail.dtls.externalPartyOfficeAddressID;
      } else {
        // BEGIN, CR00237008, GBA
        final LocationKey locationKey = new LocationKey();

        locationKey.locationID = hearingTabDetail.dtls.locationID;
        addressKey.addressID =
          LocationFactory.newInstance().read(locationKey).addressID;
        // END, CR00237008
      }

    }
    if (addressKey.addressID != 0) {
      hearingTabDetail.addressData =
        addressObj.readAddressData(addressKey).addressData;
    }

    final LocalisableString appealDescription =
      new LocalisableString(APPEALTAB.INF_HEARING_CASE_TITLE);

    appealDescription.arg(hearingTabDetail.dtls.caseTypeCode);
    if (hearingTabDetail.dtls.appealTypeCode.equals(APPEALTYPE.HEARING)) {
      appealDescription.arg(HEARINGCONTEXTPANEL.INF_HEARING.getMessageText());
    } else {
      appealDescription.arg(hearingTabDetail.dtls.appealTypeCode);
    }
    appealDescription.arg(hearingTabDetail.dtls.caseReference);
    appealDescription.arg(hearingTabDetail.dtls.primaryClientName);

    hearingTabDetail.appealDescription =
      appealDescription.toClientFormattedText();

    hearingTabDetail.contextDescription =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_HEARING_PANEL_TITLE).arg(
        hearingTabDetail.dtls.primaryClientName).toClientFormattedText();

    final ContentPanelBuilder containerPanel =
      ContentPanelBuilder
      .createPanel(GeneralAppealConstants.gkHearingScheduleContainer);

    final ContentPanelBuilder detailsPanel =
      getScheduledHearingDetails(addressKey, hearingTabDetail);

    // Links Panel
    final LinksPanelBuilder linksPanelBuilder =
      LinksPanelBuilder.createLinksPanel(3);

    // Create Content Panel to hold case status
    final ContentPanelBuilder caseStatus =
      ContentPanelBuilder
      .createPanel(GeneralAppealConstants.gkHearingScheduleStatusContent);

    caseStatus.addCodetableItem(hearingTabDetail.dtls.hearingStatusCode,
      GeneralAppealConstants.gkHearingStatusCode,
      GeneralAppealConstants.gkHearingScheduleCaseStatus);
    linksPanelBuilder.addContentPanel(caseStatus);

    // Create a image builder
    final ImageBuilder iconImageBuilder1 =
      ImageBuilder.createImage(GeneralAppealConstants.gkIconInvitedAttendees);

    iconImageBuilder1.setImageResource(CuramConst.gkRendererImages);

    // Add alt text, this is only sample alt text
    final LocalisableString altTextLocalizedMessage =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_NUM_INVITED_ATTENDEES);

    iconImageBuilder1.setImageAltText(altTextLocalizedMessage
      .toClientFormattedText());

    LocalisableString invitedAttendeesString =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_INVITED_ATTENDEES)
    .arg(hearingTabDetail.attendeeDtls.attendeeTotalCount);

    final LinkBuilder linkBuilder =
      LinkBuilder.createLocalizableLink(
        invitedAttendeesString.toClientFormattedText(),
        GeneralAppealConstants.kListAttendeePage);

    linkBuilder.addParameter(GeneralAppealConstants.kHearingId,
      String.valueOf(hearingKey.hearingID));

    // BEGIN ,CR00286835 , DK
    final LocalisableString invitedAttendeesTitle =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_HEARINGATTENDEES_TITLE);

    linkBuilder.addLinkTitle(invitedAttendeesTitle);
    // END ,CR00286835 , DK
    // BEGIN, CR00284715, MC
    if (hearingTabDetail.dtls.hearingTypeCode
      .equals(HEARINGTYPE.HEARINGREVIEW)) {

      // There should only ever be a reviewer on a hearing review hearing
      invitedAttendeesString =
        new LocalisableString(HEARINGCONTEXTPANEL.INF_INVITED_ATTENDEES)
      .arg(CuramConst.gkZero);

      // BEGIN, 179767, AZ - Add "icon-invited-attendees" CSS class.
      // Add the 'disabled' link to the links panel
      linksPanelBuilder.addLinkEntry(iconImageBuilder1,
        invitedAttendeesString.toClientFormattedText(),
        GeneralAppealConstants.gkInvitedAttendeesIcon);
    } else {
      // Add the 'enabled' link to the links panel
      linksPanelBuilder.addLinkEntry(iconImageBuilder1, linkBuilder,
        GeneralAppealConstants.gkInvitedAttendeesIcon);
      // END, 179767
    }
    // END, CR00284715

    // BEGIN, CR00286999, MC
    // Create panel to hold hearing official
    final ContentPanelBuilder hearingScheduleOfficialPanelBuilder =
      ContentPanelBuilder
      .createPanel(GeneralAppealConstants.gkHearingScheduleOfficialPanel);

    final ImageBuilder iconCaseOwner =
      ImageBuilder.createImage(
        GeneralAppealConstants.gkIconHearingParticipant, "");

    iconCaseOwner.setImageResource(CuramConst.gkRendererImages);
    // BEGIN ,CR00286835 , DK
    // Add alt text
    final LocalisableString altTextLocalizedMessage2 =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_HEARINGOFFICIAL_TITLE);

    iconCaseOwner.setImageAltText(altTextLocalizedMessage2
      .toClientFormattedText());
    // END ,CR00286835 , DK
    hearingScheduleOfficialPanelBuilder.addImageItem(iconCaseOwner,
      GeneralAppealConstants.gkIconHearingScheduleOfficial);

    // TODO get hearing official and type (user or external party)
    // not returned in this method at the moment
    // LinkBuilder linkBuilder2 = LinkBuilder.createLink("Sam Sampson",
    // "www.google.com");
    // caseOwnerPanelBuilder.addLinkItem(linkBuilder2,
    // CPMConstants.gkHearingScheduleOfficial);

    // If there are multiple hearing officials display a link to the list only
    if (hearingTabDetail.hearingOfficialListDtls.size() > 1) {

      final LinkBuilder mutipleOfficialsLinkBuilder =
        LinkBuilder.createLink(
          APPEALTAB.INF_MULTIPLEOFFICIALS_TITLE.getMessageText(),
          GeneralAppealConstants.kListAttendeePage);

      mutipleOfficialsLinkBuilder.addParameter(
        GeneralAppealConstants.kHearingId,
        String.valueOf(hearingKey.hearingID));

      final LocalisableString mutipleOfficialsLinkTitle =
        new LocalisableString(APPEALTAB.INF_HEARINGOFFICIAL_TITLE);

      mutipleOfficialsLinkBuilder.addLinkTitle(mutipleOfficialsLinkTitle);

      // BEGIN, 179767, AZ
      // Add "icon-hearing-official" CSS class
      hearingScheduleOfficialPanelBuilder
      .addLinkItem(mutipleOfficialsLinkBuilder,
        GeneralAppealConstants.gkHearingOfficialIcon);
      // END, 179767
    } // If the hearing official is a user link to the user page
    else if (userHearingOfficialsList.dtls.size() > 0) {

      final HearingOfficialTabDetail hearingOfficialDetails =
        userHearingOfficialsList.dtls.item(0);

      final UsersKey usersKey = new UsersKey();

      usersKey.userName = hearingOfficialDetails.hearingOfficialUserName;

      final LinkBuilder userLinkBuilder =
        LinkBuilder.createLink(
          tabDetailFormatterObj.formatUserFullName(usersKey).fullName,
          CuramConst.gkUserDetailsPage);

      userLinkBuilder.openAsModal();
      userLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
        String.valueOf(hearingOfficialDetails.hearingOfficialUserName));

      final LocalisableString userDetails =
        new LocalisableString(BPOINCIDENTTAB.INF_USERDETAILS_TITLE);

      userLinkBuilder.addLinkTitle(userDetails);

      // BEGIN, 179767, AZ
      // Add "icon-hearing-official" CSS class
      hearingScheduleOfficialPanelBuilder.addLinkItem(userLinkBuilder,
        GeneralAppealConstants.gkHearingOfficialIcon);
      // END, 179767
    } // If the hearing official is a participant (e.g. external party for an
    // external hearing)
    else if (concernRoleHearingOfficialsList.dtls.size() > 0) {

      final ExternalHearingOfficialContextPanelDetail hearingOfficialDetails =
        concernRoleHearingOfficialsList.dtls.item(0);

      final LinkBuilder participantLinkBuilder =
        LinkBuilder.createLink(hearingOfficialDetails.concernRoleName,
          CuramConst.gkParticipantHomePage);

      participantLinkBuilder.addParameter(
        CuramConst.gkPageParameterConcernRoleID,
        String.valueOf(hearingOfficialDetails.concernRoleID));

      final LocalisableString hearingOfficialTitle =
        new LocalisableString(APPEALTAB.INF_HEARINGOFFICIAL_TITLE);

      participantLinkBuilder.addLinkTitle(hearingOfficialTitle);
      hearingScheduleOfficialPanelBuilder.addLinkItem(participantLinkBuilder);

    }
    // END, CR00286999

    linksPanelBuilder.addContentPanel(hearingScheduleOfficialPanelBuilder);

    containerPanel.addWidgetItem(detailsPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel,
      GeneralAppealConstants.gkHearingScheduleDetailsPanel);
    containerPanel.addWidgetItem(linksPanelBuilder.getLinksPanel(),
      CuramConst.gkStyle, CuramConst.gkContentPanel,
      GeneralAppealConstants.gkHearingScheduleDetailsLinks);

    hearingTabDetail.hearingTabDetails = containerPanel.toString();

    return hearingTabDetail;
  }

  // ___________________________________________________________________________
  /**
   * Reads the scheduled hearing details to be displayed in details panel
   * (left panel)
   *
   * @return ContentPanelBuilder which contains scheduled hearing details
   */
  protected ContentPanelBuilder getScheduledHearingDetails(
    final AddressKey addressKey, final HearingTabDetail hearingTabDetail)
      throws AppException, InformationalException {

    // Create a content panel using the content panel builder to build the xml
    // required. The id for this content panel is person-details. This should
    // be unique id.
    final ContentPanelBuilder contentPanelBuilder =
      ContentPanelBuilder
      .createPanel(GeneralAppealConstants.gkHearingScheduleDetails);

    contentPanelBuilder.addRoundedCorners();

    // BEGIN, CR00340727, GA
    final LocalisableString hearingType =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_HEARING_SCHEDULE_TYPE);

    hearingType.arg(CodeTable.getOneItem(HEARINGTYPEEntry.TABLENAME,
      hearingTabDetail.dtls.hearingTypeCode,
      TransactionInfo.getProgramLocale()));

    // Add Hearing Schedule Type.
    contentPanelBuilder.addStringItem(
      hearingType.getMessage(TransactionInfo.getProgramLocale()),
      GeneralAppealConstants.gkHearingScheduleName);
    // END, CR00340727

    final curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();
    final OtherAddressData addressDataStr = new OtherAddressData();

    addressDataStr.addressData = hearingTabDetail.addressData;
    EmptyIndStruct emptyIndicator;

    emptyIndicator = addressObj.isEmpty(addressDataStr);

    // TODO uncomment when address map page updated in main
    /*
     * if (!emptyIndicator.emptyInd) {
     *
     * // Add Address
     * ContentPanelBuilder addressBuilder = ContentPanelBuilder
     * .createPanel("tab-details-address");
     *
     * TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory
     * .newInstance();
     * AddressTabDetails addressTabDetails = new AddressTabDetails();
     * addressTabDetails.addressData = hearingTabDetail.addressData;
     *
     * addressBuilder.addStringItem(tabDetailFormatterObj
     * .formatAddress(addressTabDetails).addressString,
     * CuramConst.gkContentAddress);
     *
     * LocalisableString mapString
     * = new LocalisableString(BPOPARTICIPANT.INF_MAP);
     *
     * LinkBuilder linkBuilder =
     * LinkBuilder.createLocalizableLink(mapString.toClientFormattedText(),
     * CuramConst.gkAddressMapPage);
     * linkBuilder
     * .addParameter(CuramConst.gkConcernRoleID,
     * String.valueOf(hearingTabDetail.dtls.concernRoleID));
     * linkBuilder.openAsModal();
     * linkBuilder.setTextResource(CuramConst.gkRendererImages);
     * linkBuilder.addImage(CuramConst.gkIconMap, "");
     *
     * contentPanelBuilder
     * .addWidgetItem(linkBuilder, CuramConst.gkStyle,
     * CuramConst.gkLink, CuramConst.gkContentMap);
     *
     * // Add address to details content panel
     * contentPanelBuilder.addWidgetItem(addressBuilder, "style",
     * "content-panel");
     * }
     */

    // BEGIN, CR00340727, GA
    final LocalisableString relatedAppealCase =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_HEARING_TYPE);

    relatedAppealCase
    .arg(CodeTable.getOneItem(CASETYPECODEEntry.TABLENAME,
      hearingTabDetail.dtls.caseTypeCode,
      TransactionInfo.getProgramLocale()));
    relatedAppealCase.arg(hearingTabDetail.dtls.caseReference);

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CaseReference caseReference = new CaseReference();

    caseReference.caseReference = hearingTabDetail.dtls.caseReference;
    final CaseHeaderDtls caseHeaderDtls =
      caseHeader.readByCaseReference(caseReference);

    final LinkBuilder linkBuilder =
      LinkBuilder.createLink(
        relatedAppealCase.getMessage(TransactionInfo.getProgramLocale()),
        CuramConst.gkCaseHomePage);

    // END, CR00340727

    linkBuilder.addParameter(CuramConst.gkPageParameterCaseID,
      String.valueOf(caseHeaderDtls.caseID));
    final LocalisableString relatedCaseTitle =
      new LocalisableString(HEARINGCONTEXTPANEL.INF_RELATEDCASE_TITLE);

    linkBuilder.addLinkTitle(relatedCaseTitle);

    contentPanelBuilder.addLinkItem(linkBuilder,
      GeneralAppealConstants.gkHearingScheduleReference);

    final ListBuilder listBuilder = ListBuilder.createHorizontalList(2);

    listBuilder.addRow();

    if (HEARINGSTATUSEntry.SCHEDULED.getCode().equals(
      hearingTabDetail.dtls.hearingStatusCode)
      || HEARINGSTATUSEntry.RESCHEDULED.getCode().equals(
        hearingTabDetail.dtls.hearingStatusCode)) {

      // BEGIN, CR00340727, GA
      listBuilder.addEntry(1, 1, new LocalisableString(
        HEARINGCONTEXTPANEL.INF_HEARING_DATE_TIME).arg(HEARINGSTATUSEntry
          .get(hearingTabDetail.dtls.hearingStatusCode)
          .getCodeTableItemIdentifier()));
      listBuilder.addEntry(2, 1, hearingTabDetail.dtls.scheduledDateTime);
      // END, CR00340727
      contentPanelBuilder.addSingleListItem(listBuilder,
        GeneralAppealConstants.gkHearingScheduleTable);

    } else {

      contentPanelBuilder.addCodetableItem(
        hearingTabDetail.dtls.hearingStatusCode,
        GeneralAppealConstants.gkHearingStatusCode,
        GeneralAppealConstants.gkHearingScheduleStatus);
    }

    return contentPanelBuilder;
  }

}
