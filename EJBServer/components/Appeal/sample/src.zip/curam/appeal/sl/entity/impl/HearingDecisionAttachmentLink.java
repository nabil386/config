/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.entity.impl;

import com.google.inject.Inject;
import curam.appeal.sl.entity.struct.ActiveDecisionAttachmentsKey;
import curam.appeal.sl.entity.struct.HearingDecisionAttachmentLinkKey;
import curam.appeal.sl.entity.struct.ReadForDownloadDetails;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

/**
 * This entity maintains all appeal decision attachments for an appeal case.
 * Decision attachments can be either external documents or documents created
 * internally.
 */
public abstract class HearingDecisionAttachmentLink extends
  curam.appeal.sl.entity.base.HearingDecisionAttachmentLink {

  @Inject
  private CMISAccessInterface cmisAccess;

  protected HearingDecisionAttachmentLink() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing decision attachments are considered
   * when counting the number of attachments for a decision.
   * 
   * @param key The criteria for counting the active attachments for a decision.
   */
  @Override
  protected void precountActiveAttachmentsByDecision(
    final ActiveDecisionAttachmentsKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // BEGIN, CR00297084, CD
  @Override
  public ReadForDownloadDetails readForDownload(
    final HearingDecisionAttachmentLinkKey key) throws AppException,
    InformationalException {

    final ReadForDownloadDetails details = super.readForDownload(key);
    final long attachmentID = super.read(key).attachmentID;

    // BEGIN, CR00356127, CD
    // if CMIS is enabled for attachments and if content exists on the CMS for
    // the record in question, call the CMIS API to fetch the content
    if (cmisAccess.isCMISEnabledFor(CMSLINKRELATEDTYPEEntry.ATTACHMENT)
      && cmisAccess.contentExists(attachmentID,
        CMSLINKRELATEDTYPEEntry.ATTACHMENT)) {

      details.attachmentContents =
        cmisAccess.read(attachmentID, CMSLINKRELATEDTYPEEntry.ATTACHMENT).fileContent;
    }
    // END, CR00356127

    return details;
  }
  // END, CR00297084
}
