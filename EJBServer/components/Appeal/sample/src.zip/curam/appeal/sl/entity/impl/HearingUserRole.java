/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingUserRoleFactory;
import curam.appeal.sl.entity.struct.HearingAndStatusKey;
import curam.appeal.sl.entity.struct.HearingAttendeeKey;
import curam.appeal.sl.entity.struct.HearingCaseID;
import curam.appeal.sl.entity.struct.HearingKeyDetails;
import curam.appeal.sl.entity.struct.HearingParticipationAndStatus;
import curam.appeal.sl.entity.struct.HearingUserCloneDetails;
import curam.appeal.sl.entity.struct.HearingUserRoleDtls;
import curam.appeal.sl.entity.struct.HearingUserRoleKey;
import curam.appeal.sl.entity.struct.HearingUserRoleStatusKey;
import curam.appeal.sl.entity.struct.ParticipatedUserKey;
import curam.appeal.sl.entity.struct.UpdateNonParticipationDetails;
import curam.appeal.sl.entity.struct.UpdateNonParticipationKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.HEARINGPARTICIPATION;
import curam.codetable.HEARINGSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.message.BPOHEARINGUSERROLE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;

public abstract class HearingUserRole extends
  curam.appeal.sl.entity.base.HearingUserRole {

  // ___________________________________________________________________________
  /**
   * Validates the Hearing User Role Details
   * 
   * @param dtls Hearing User Role details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  protected void validateInsert(final HearingUserRoleDtls dtls)
    throws AppException, InformationalException {

    // Hearing object and manipulation variables
    final curam.appeal.sl.entity.intf.Hearing hearingObj =
      curam.appeal.sl.entity.fact.HearingFactory.newInstance();
    final HearingAndStatusKey hearingAndStatusKey = new HearingAndStatusKey();
    HearingCaseID hearingCaseID;

    // Hearing ID must be specified
    if (dtls.hearingID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGUSERROLE.ERR_HEARINGUSERROLE_FV_HEARINGID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    hearingAndStatusKey.hearingID = dtls.hearingID;
    hearingAndStatusKey.statusCode = HEARINGSTATUS.SCHEDULED;

    try {
      // Reads to determine if the hearing exists with status 'scheduled'.
      hearingCaseID =
        hearingObj.readCaseByHearingIDAndStatus(hearingAndStatusKey);
    } catch (final RecordNotFoundException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(BPOHEARINGUSERROLE.ERR_HEARINGUSERROLE_FV_HEARING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // CaseUserRoleID must be specified
    if (dtls.caseUserRoleID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .throwWithLookup(
          new AppException(
            BPOHEARINGUSERROLE.ERR_HEARINGUSERROLE_FV_CASEUSERROLEID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Set the default values for the hearing user role details.
   * 
   * @param dtls Hearing User Role details
   */
  @Override
  protected void setDefaults(final HearingUserRoleDtls dtls)
    throws AppException, InformationalException {

    dtls.participatedCode = HEARINGPARTICIPATION.NOTHELD;

  }

  // ___________________________________________________________________________
  /**
   * Validates the Hearing User Role Details
   * 
   * @param details Hearing User Role details
   */
  @Override
  protected void preinsert(final HearingUserRoleDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Performs pre-search functionality to ensure that only active records
   * are retrieved. Also sets the type of user to exclude from the search
   * as attendees are all user types for a hearing except the hearing official.
   * (Note that there are not attendees for a hearing review case)
   * 
   * @param key Contains the hearingID, recordStatus and excludeTypeCode
   */
  @Override
  protected void presearchActiveAttendeesByHearingID(
    final HearingAttendeeKey key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.excludeTypeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;

  }

  // ___________________________________________________________________________
  /**
   * Sets the fields so that all non participants are updated to no-show
   * 
   * @param key contains the hearing ID and the participation code to search on
   * @param details contains the new participation code
   */
  @Override
  protected void premodifyNonParticipation(
    final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    key.participatedCode = HEARINGPARTICIPATION.NOTHELD;
    details.participatedCode = HEARINGPARTICIPATION.NOSHOW;

  }

  // ___________________________________________________________________________
  /**
   * Clones the Hearing User Role Details
   * 
   * @param key Hearing User Role identifier
   * @param dtls Hearing identifier
   */
  @Override
  public void
    clone(final HearingUserRoleKey key, final HearingKeyDetails dtls)
      throws AppException, InformationalException {

    // Hearing User Role manipulation variables
    HearingUserCloneDetails hearingUserCloneDetails;
    final HearingUserRoleDtls hearingUserRoleDtls = new HearingUserRoleDtls();

    // Read clone details
    hearingUserCloneDetails = readCloneDetails(key);

    // Map the details
    hearingUserRoleDtls.caseUserRoleID =
      hearingUserCloneDetails.caseUserRoleID;

    // Set defaults
    setDefaults(hearingUserRoleDtls);

    // Set new hearing identifier
    hearingUserRoleDtls.hearingID = dtls.hearingID;

    // Insert new Hearing User Role
    insert(hearingUserRoleDtls);
  }

  // ___________________________________________________________________________
  /**
   * Ensures that only 'active' HearingUserRole records are retrieved.
   * 
   * @param key HearingID, roleType and statusCode to search for
   */
  @Override
  protected void presearchActiveByHearingIDAndRoletype(
    final HearingUserRoleStatusKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * Performs pre-search functionality to ensure that only 'active'
   * HearingUserRole records are retrieved.
   * 
   * @param key HearingID, roleType and statusCode to search for.
   */
  @Override
  protected void presearchActiveUserNameByHearingIDAndType(
    final HearingUserRoleStatusKey key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // BEGIN, HARP-29409, CG
  // ___________________________________________________________________________
  /**
   * Performs pre-search functionality to ensure that only active records
   * are retrieved. Also sets the type of user to exclude from the search
   * as attendees are all user types for a hearing except the hearing official.
   * (Note that there are not attendees for a hearing review case)
   * 
   * @param key Contains the hearingID, recordStatus and excludeTypeCode
   */
  @Override
  protected void presearchActiveAttendeeNamesByHearingID(
    final HearingAttendeeKey key) throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.excludeTypeCode = CASEUSERROLETYPE.HEARINGOFFICIAL;
  }

  // END, HARP-29409, CG

  // ___________________________________________________________________________
  /**
   * Sets the record status and participation codes, and sets the type codes
   * to exclude in the search
   */
  @Override
  protected void presearchUserParticipation(final ParticipatedUserKey key)
    throws AppException, InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.excludeTypeCode1 = CASEUSERROLETYPE.HEARINGOFFICIAL;
    key.excludeTypeCode2 = CASEUSERROLETYPE.INTERPRETER;
    key.statusCode = HEARINGSTATUS.COMPLETED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures that only active hearing user roles are considered when
   * determining the number of user roles for a hearing with a specified
   * participation.
   * 
   * @param key The hearingID, participationCode and recordStatus to read for
   */
  @Override
  protected void precountActiveByHearingAndParticipation(
    final HearingParticipationAndStatus key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyNonParticipation
   */
  @Override
  public void updateNonParticipation(final UpdateNonParticipationKey key,
    final UpdateNonParticipationDetails details) throws AppException,
    InformationalException {

    HearingUserRoleFactory.newInstance().modifyNonParticipation(key, details);
  }

}
