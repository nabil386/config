/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.struct.ProductAppealProcessDtls;
import curam.appeal.sl.entity.struct.ProductStartDateActiveDetails;
import curam.appeal.sl.impl.KeySets;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.UniqueID;
import curam.core.struct.UniqueIDKeySet;
import curam.message.BPOPRODUCTAPPEALPROCESS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.type.Date;

/**
 * A ProductAppealProcess record is an appeals process definition for a Product.
 * This table holds the definition and it is uniquely identified by the
 * productAppealProcessID, the AppealStage table stores each stage for the
 * process, each stage references the productAppealStageID.
 */
public abstract class ProductAppealProcess extends
  curam.appeal.sl.entity.base.ProductAppealProcess {

  // __________________________________________________________________________
  /**
   * Ensures that only active product appeal process records are considered.
   * Active here means records which have not been canceled.
   * This is controlled using the recordStatus value of NORMAL.
   * 
   * @param key The details for retrieving active product appeal processes.
   */
  @Override
  protected void presearchActiveByProductAndStartDate(
    final ProductStartDateActiveDetails key) throws AppException,
    InformationalException {

    // Ensure that the record status is active i.e. not canceled i.e. normal
    key.recordStatus = RECORDSTATUS.NORMAL;
  }

  // __________________________________________________________________________
  /**
   * This method performs all pre-insert functionality for a new
   * product appeal process record.
   * 
   * @param details The insert details.
   */
  @Override
  protected void preinsert(final ProductAppealProcessDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00272139, PB
    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Ensure that the record status is active i.e. not canceled i.e. normal
    details.recordStatus = RECORDSTATUS.NORMAL;
    details.versionNo = 0;
    uniqueIDKeySet.keySetName = KeySets.KEY_SET_PRODUCTAPPEALPROCESS;
    details.productAppealProcessID =
      uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet);
    // END, CR00272139

    // Validate before inserting
    validateInsert(details);
  }

  // __________________________________________________________________________
  /**
   * Validates the creation of a new product appeal process record.
   * 
   * @param details The insert details.
   */
  @Override
  protected void validateInsert(final ProductAppealProcessDtls details)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Check that the start date is provided
    if (details.startDate.isZero()) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_FV_STARTDATE_MISSING),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    } // Check that the start date is in the present or future
    else if (details.startDate.before(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_FV_STARTDATE_PAST),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Sets record status to always be active before reading for the Process ID
   * 
   * @param key The product ID and nearest start date.
   */
  @Override
  protected void prereadProcessIDByProductAndStartDate(
    final ProductStartDateActiveDetails key) throws AppException,
    InformationalException {

    key.recordStatus = RECORDSTATUS.NORMAL;
  }

}
