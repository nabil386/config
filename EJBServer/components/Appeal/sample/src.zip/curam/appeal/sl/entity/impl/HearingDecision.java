/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2004 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.entity.impl;

import curam.appeal.sl.entity.fact.HearingDecisionFactory;
import curam.appeal.sl.entity.struct.HearingDecisionDtls;
import curam.appeal.sl.entity.struct.HearingDecisionKey;
import curam.appeal.sl.entity.struct.UserSupervisorCount;
import curam.appeal.sl.entity.struct.UserSupervisorKey;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.message.BPODECISION;
import curam.message.BPOORGANISATIONSTRUCTURE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.GeneralConstants;
import curam.util.type.Date;

/**
 * A decision that has been rendered by the organization after a hearing.
 */
public abstract class HearingDecision extends
  curam.appeal.sl.entity.base.HearingDecision {

  /**
   * Validates the hearing decision insert details
   * 
   * @param details the hearing decision insert details
   */
  @Override
  protected void preinsert(final HearingDecisionDtls details)
    throws AppException, InformationalException {

    validate(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the hearing decision modify details
   * 
   * @param details the hearing decision insert details
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  // The key cannot be removed as it will
  // be used by the base modify method.
    protected
    void premodify(final HearingDecisionKey key,
      final HearingDecisionDtls details) throws AppException,
      InformationalException {

    validate(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the hearing decision entity details
   * 
   * @param details the details to validate
   */
  @Override
  public void validate(final HearingDecisionDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Decision status must be specified
    if (details.decisionStatus.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISION.ERR_DECISION_FV_DECISIONSTATUSMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Decision resolution must be specified
    if (details.resolutionCode.length() == 0) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISION.ERR_DECISION_FV_DECISIONRESOLUTIONCODEMISSING),
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    // Decision date must be specified
    if (details.decisionDate.isZero()) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISION.ERR_DECISION_DECISIONDATEEMPTY), GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }
    // Decision date must be not be in the future
    if (details.decisionDate.after(Date.getCurrentDate())) {

      informationalManager.addInformationalMsg(new AppException(
        BPODECISION.ERR_DECISION_VALIDDECISIONDATE), GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError);

    }

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Sets up the key to perform the search for users that are supervisors
   * 
   * @param key contains the parameters to search on -
   */
  @Override
  protected void precountIsUserSupervisor(final UserSupervisorKey key)
    throws AppException, InformationalException {

    // organization structure object
    final OrganisationStructure organisationStructureObj =
      OrganisationStructureFactory.newInstance();

    // Insert the active organization structure id to this position
    // slot availability.
    // Get the active org structure
    OrganisationStructureID organisationStructureID =
      new OrganisationStructureID();
    final OrganisationStructureStatus organisationStructureStatus =
      new OrganisationStructureStatus();

    // Set the active organization structure id.
    try {
      organisationStructureID =
        organisationStructureObj
          .readActiveOrganisationStructureID(organisationStructureStatus);
    } catch (final RecordNotFoundException e) {
      // in case that no active organization structure exists
      throw new AppException(
        BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
    }

    key.organisationStructureID =
      organisationStructureID.organisationStructureID;

    key.currentDate = Date.getCurrentDate();
    key.leadPositionInd = true;
    key.recordStatus = RECORDSTATUS.NORMAL;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by countIsUserSupervisor
   */
  @Override
  public UserSupervisorCount searchIsUserSupervisor(
    final UserSupervisorKey key) throws AppException, InformationalException {

    return HearingDecisionFactory.newInstance().countIsUserSupervisor(key);
  }

}
