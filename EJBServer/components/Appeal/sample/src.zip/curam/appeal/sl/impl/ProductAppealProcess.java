/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2004-2005,2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.appeal.sl.impl;

import curam.appeal.sl.entity.fact.AppealRelationshipFactory;
import curam.appeal.sl.entity.fact.AppealStageFactory;
import curam.appeal.sl.entity.fact.ProductAppealProcessFactory;
import curam.appeal.sl.entity.intf.AppealRelationship;
import curam.appeal.sl.entity.intf.AppealStage;
import curam.appeal.sl.entity.struct.AppealCaseAndCase;
import curam.appeal.sl.entity.struct.AppealCaseID;
import curam.appeal.sl.entity.struct.AppealRelationShipDetails;
import curam.appeal.sl.entity.struct.AppealRelationShipDetailsList;
import curam.appeal.sl.entity.struct.AppealStageDetailsList;
import curam.appeal.sl.entity.struct.AppealStageDtls;
import curam.appeal.sl.entity.struct.AppealStageKey;
import curam.appeal.sl.entity.struct.AppealStageModifyAppealType;
import curam.appeal.sl.entity.struct.AppealStageModifyRecordStatus;
import curam.appeal.sl.entity.struct.AppealTypeAndProcess;
import curam.appeal.sl.entity.struct.PriorAppealCaseID;
import curam.appeal.sl.entity.struct.PriorAppealCaseIDAndCaseIDDetailsList;
import curam.appeal.sl.entity.struct.ProcessIDAndRecordStatus;
import curam.appeal.sl.entity.struct.ProcessRecordStatus;
import curam.appeal.sl.entity.struct.ProcessSummary;
import curam.appeal.sl.entity.struct.ProductAppealProcessDtls;
import curam.appeal.sl.entity.struct.ProductAppealProcessKey;
import curam.appeal.sl.entity.struct.ProductAppealProcessKeyList;
import curam.appeal.sl.entity.struct.ProductStartDateActiveDetails;
import curam.appeal.sl.entity.struct.RecordStatusStartDate;
import curam.appeal.sl.entity.struct.StageAndParentDetailsList;
import curam.appeal.sl.struct.AppealCaseIDCaseID;
import curam.appeal.sl.struct.AppealStageDetails;
import curam.appeal.sl.struct.AppealStageID;
import curam.appeal.sl.struct.AppealStageIDVersionNo;
import curam.appeal.sl.struct.AppealStageType;
import curam.appeal.sl.struct.AppealTypeCount;
import curam.appeal.sl.struct.CaseAndPriorAppeal;
import curam.appeal.sl.struct.CaseIDDetails;
import curam.appeal.sl.struct.CreateStageDetails;
import curam.appeal.sl.struct.ModifyAppealStage;
import curam.appeal.sl.struct.OrderedAppealStage;
import curam.appeal.sl.struct.OrderedAppealStageDetailsList;
import curam.appeal.sl.struct.OrderedAppealStageList;
import curam.appeal.sl.struct.PriorAppealCount;
import curam.appeal.sl.struct.ProcessAndStageDetails;
import curam.appeal.sl.struct.ProcessDetailsList;
import curam.appeal.sl.struct.ProcessIDAndVersionNo;
import curam.appeal.sl.struct.ProcessStartDate;
import curam.appeal.sl.struct.ProductAndStartDateAndAppealType;
import curam.appeal.sl.struct.ProductAppealProcessID;
import curam.appeal.sl.struct.ProductID;
import curam.appeal.sl.struct.ProductIDDetails;
import curam.appeal.sl.struct.ProductIDStartDate;
import curam.appeal.sl.struct.StageFirstLevelDetails;
import curam.appeal.sl.struct.StageFirstLevelDetailsList;
import curam.appeal.sl.struct.StagePositionDetails;
import curam.codetable.APPEALSTAGEAPPEALTYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.message.BPOAPPEALSTAGE;
import curam.message.BPOPRODUCTAPPEALPROCESS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.Date;
import curam.util.type.UniqueID;

/**
 * Provides the business functionality for maintaining and accessing product
 * appeal process definitions for a Product.
 */

public abstract class ProductAppealProcess extends
  curam.appeal.sl.base.ProductAppealProcess {

  // ___________________________________________________________________________
  /**
   * Cancels a product appeal process.
   * 
   * @param details
   * The details for canceling a product appeal process
   */
  @Override
  public void cancel(final ProcessIDAndVersionNo details)
    throws AppException, InformationalException {

    // Entity layer variables for Product Appeal Process
    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();
    final ProcessRecordStatus processRecordStatus = new ProcessRecordStatus();

    // Validate before cancellation.

    validateCancelProcess(details);

    // Set the record status to canceled.

    processRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;

    productAppealProcessKey.productAppealProcessID =
      details.productAppealProcessID;

    processRecordStatus.versionNo = details.versionNo;

    // Update record status of the Product Appeal Process

    productAppealProcessObj.modifyRecordStatus(productAppealProcessKey,
      processRecordStatus);

  }

  // ___________________________________________________________________________
  /**
   * Cancels an appeal stage.
   * 
   * @param details
   * The details for canceling an appeal stage.
   */
  @Override
  public void cancelStage(final AppealStageIDVersionNo details)

  throws AppException, InformationalException {

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();
    final AppealStageKey appealStageKey = new AppealStageKey();

    final AppealStageModifyRecordStatus appealStageModifyRecordStatus =
      new AppealStageModifyRecordStatus();

    // Validate before cancellation

    validateCancelStage(details);

    // Set the record status to be canceled

    appealStageModifyRecordStatus.recordStatus = RECORDSTATUS.CANCELLED;
    appealStageModifyRecordStatus.versionNo = details.versionNo;
    appealStageKey.appealStageID = details.appealStageID;

    // Update record status of the Appeal Stage

    appealStageObj.modifyRecordStatus(appealStageKey,
      appealStageModifyRecordStatus);

  }

  // ___________________________________________________________________________
  /**
   * Creates a new product appeal process for a product with the specified start
   * date.
   * 
   * @param details
   * The product and start date for which to create a new product
   * appeal process definition.
   */
  @Override
  public void create(final ProductIDStartDate details) throws AppException,
    InformationalException {

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessDtls productAppealProcessDtls =
      new ProductAppealProcessDtls();

    // Validate before creation

    validateCreateProcess(details);

    // Add new process for this Product ID with this start date

    productAppealProcessDtls.productID = details.productIDStartDate.productID;
    productAppealProcessDtls.startDate = details.productIDStartDate.startDate;
    productAppealProcessDtls.productAppealProcessID = UniqueID.nextUniqueID();

    productAppealProcessObj.insert(productAppealProcessDtls);

  }

  // ___________________________________________________________________________
  /**
   * Create a new appeal stage for a product appeal process.
   * 
   * @param createStageDetails
   * The details for the appeal stage to create.
   */
  @Override
  public void createStage(final CreateStageDetails createStageDetails)
    throws AppException, InformationalException {

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    final AppealStageDtls appealStageDtls = new AppealStageDtls();

    curam.appeal.sl.entity.struct.AppealStageID appealStageID;

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    // Validate before creating

    validateCreateStage(createStageDetails);

    // Get the stage ID of the last stage in the list for this process,
    // this will be the parent ID of the new stage; if no stages found then
    // this is the first stage in the list and parent ID should be null.

    productAppealProcessKey.productAppealProcessID =
      createStageDetails.productAppealProcessID;

    try {
      appealStageID = appealStageObj.readLastStageID(productAppealProcessKey);

      appealStageDtls.parentAppealStageID = appealStageID.appealStageID;
    } catch (final RecordNotFoundException e) {

      appealStageDtls.parentAppealStageID = 0;
    }

    // Add the new stage to the end of the list

    appealStageDtls.appealStageID = UniqueID.nextUniqueID();

    appealStageDtls.appealTypeCode = createStageDetails.appealTypeCode;

    appealStageDtls.recordStatus = RECORDSTATUS.NORMAL;
    appealStageDtls.versionNo = 0;

    appealStageDtls.productAppealProcessID =
      createStageDetails.productAppealProcessID;

    appealStageObj.insert(appealStageDtls);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of product appeal processes for a product. This list
   * includes the first appeal stage, if any, defined for each process.
   * 
   * @param key
   * The product for which to get all product appeal processes.
   * 
   * @return The list of product appeal process definitions.
   */
  @Override
  public ProcessDetailsList list(final ProductID key) throws AppException,
    InformationalException {

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();

    final curam.appeal.sl.entity.struct.ProductID productID =
      new curam.appeal.sl.entity.struct.ProductID();

    AppealStageType appealStageType;

    final StagePositionDetails stagePositionDetails =
      new StagePositionDetails();

    // Variable for list of Product appeal processes

    final ProcessDetailsList processDetailsList = new ProcessDetailsList();

    // Get list of appeal processes for this Product

    productID.productID = key.productID.productID;
    processDetailsList.processDetailsList =
      productAppealProcessObj.searchByProduct(productID);

    // For each process record, if the first appeal stage is canceled
    // then search for the first active appeal stage

    stagePositionDetails.position = 1;
    stagePositionDetails.productID = key.productID.productID;

    final int numberOfProcesses =
      processDetailsList.processDetailsList.dtls.size();

    for (int i = 0; i < numberOfProcesses; i++) {

      if (processDetailsList.processDetailsList.dtls.item(i).firstStageRecordStatus
        .equals(RECORDSTATUS.CANCELLED)) {

        stagePositionDetails.startDate =
          processDetailsList.processDetailsList.dtls.item(i).startDate;

        appealStageType = getStageAtPosition(stagePositionDetails);

        try {
          processDetailsList.processDetailsList.dtls.item(i).firstStage =
            appealStageType.appealStageType.appealStageType;

        } catch (final java.lang.NullPointerException e) {
          // No active stages; all stages are canceled
          processDetailsList.processDetailsList.dtls.item(i).firstStage = "";
        }
      }
    }

    return processDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns active stages for a process in the correct order.
   * 
   * @param key
   * The product appeal process for which to return appeal stages.
   * @return List of ordered appeal stages including numerical indicator of
   * order sequence.
   */
  @Override
  public OrderedAppealStageList listOrderedActiveStages(
    final ProductAppealProcessID key) throws AppException,
    InformationalException {

    // Variables for ordered list of active stages

    final OrderedAppealStageList orderedAppealStageList =
      new OrderedAppealStageList();

    OrderedAppealStage orderedAppealStage;

    // Variable for domain APPEAL_STAGE_SEQUENCE
    byte appealStageSequence = 1;

    // Variables for domain APPEAL_STAGE_ID
    long nextParentAppealStageID;

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    curam.appeal.sl.entity.struct.AppealStageDetails appealStageDetails;

    AppealStageDetailsList appealStageDetailsList;

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    // Get unsorted list of Product appeal processes

    productAppealProcessKey.productAppealProcessID =
      key.productAppealProcessID;

    appealStageDetailsList =
      appealStageObj.searchProductStages(productAppealProcessKey);

    // First stage in list has a null parent ID

    nextParentAppealStageID = 0;

    // If at least one stage exists then sort the list

    if (appealStageDetailsList.dtls.size() >= 1) {

      for (int i = 0; i < appealStageDetailsList.dtls.size(); i++) {

        // Find the next stage in the list

        orderedAppealStage = new OrderedAppealStage();

        for (int j = 0; j < appealStageDetailsList.dtls.size(); j++) {

          appealStageDetails = appealStageDetailsList.dtls.item(j);

          // If the parent ID matches then have found the next stage

          if (appealStageDetails.parentAppealStageID == nextParentAppealStageID) {

            // If this stage is active then add it to the ordered list

            if (appealStageDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {

              orderedAppealStage.appealStageID =
                appealStageDetails.appealStageID;
              orderedAppealStage.appealTypeCode =
                appealStageDetails.appealTypeCode;

              orderedAppealStage.stageSequence = appealStageSequence;

              orderedAppealStageList.orderedAppealStage
                .addRef(orderedAppealStage);

              appealStageSequence++;
            }

            // Let this be the next parent ID

            nextParentAppealStageID = appealStageDetails.appealStageID;
            break;
          }
        }
      }
    }

    return orderedAppealStageList;

  }

  // ___________________________________________________________________________
  /**
   * Returns all appeal stages for a product appeal process; this includes
   * active and canceled records and the versionNo for each.
   * 
   * @param key
   * The product appeal process for which to get appeal stages.
   * @return Ordered list of appeal stages including versionNo and numerical
   * indicator of order sequence.
   */
  @Override
  public OrderedAppealStageDetailsList listOrderedStages(
    final ProductAppealProcessID key) throws AppException,
    InformationalException {

    // Variables for list of appeal stages

    final OrderedAppealStageDetailsList orderedAppealStageDetailsList =
      new OrderedAppealStageDetailsList();

    curam.appeal.sl.struct.AppealStageDetails orderedAppealStageDetails;

    // Variable for domain APPEAL_STAGE_SEQUENCE
    byte appealStageSequence = 1;

    // Variables for domain APPEAL_STAGE_ID
    long nextParentAppealStageID;

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    curam.appeal.sl.entity.struct.AppealStageDetails appealStageEntityDetails;

    AppealStageDetailsList appealStageDetailsList;

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    // Get unsorted list of Product appeal processes

    productAppealProcessKey.productAppealProcessID =
      key.productAppealProcessID;

    appealStageDetailsList =
      appealStageObj.searchProductStages(productAppealProcessKey);

    // First stage in ordered list has a null parent ID

    nextParentAppealStageID = 0;

    // If at least one stage exists then sort the list

    if (appealStageDetailsList.dtls.size() >= 1) {

      for (int i = 0; i < appealStageDetailsList.dtls.size(); i++) {

        // Find the next stage in the list

        for (int j = 0; j < appealStageDetailsList.dtls.size(); j++) {

          appealStageEntityDetails = appealStageDetailsList.dtls.item(j);

          // If the parent ID matches then have found the next stage

          if (appealStageEntityDetails.parentAppealStageID == nextParentAppealStageID) {

            // Add this stage to the ordered list

            orderedAppealStageDetails = new AppealStageDetails();

            orderedAppealStageDetails.appealStageID =
              appealStageEntityDetails.appealStageID;
            orderedAppealStageDetails.appealTypeCode =
              appealStageEntityDetails.appealTypeCode;
            orderedAppealStageDetails.stageSequence = appealStageSequence;

            orderedAppealStageDetailsList.appealStageDetails
              .addRef(orderedAppealStageDetails);

            // Let this be the next parent ID

            nextParentAppealStageID = appealStageEntityDetails.appealStageID;

            appealStageSequence++;

            break;
          }
        }
      }
    }

    return orderedAppealStageDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Updates the type of appeal for a specified appeal stage.
   * 
   * @param details
   * The details for updating the appeal stage.
   */
  @Override
  public void modifyAppealStageType(final ModifyAppealStage details)
    throws AppException, InformationalException {

    // Variables for Appeal Stage entity layer

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    final AppealStageKey appealStageKey = new AppealStageKey();
    final AppealStageModifyAppealType appealStageModifyType =
      new AppealStageModifyAppealType();

    // Variable for validation details

    final AppealStageID appealStageID = new AppealStageID();

    // Validate before modifying

    appealStageID.appealStageID = details.appealStageID;
    validateModifyStage(appealStageID);

    // Modify at the entity layer

    appealStageKey.appealStageID = details.appealStageID;
    appealStageModifyType.appealTypeCode = details.appealTypeCode;

    appealStageObj.modifyAppealType(appealStageKey, appealStageModifyType);

  }

  // ___________________________________________________________________________
  /**
   * Returns the details for an appeal stage including the its order within the
   * overall product appeal process.
   * 
   * @param key
   * The appeal stage to read.
   * @return The appeal stage details.
   */
  @Override
  public AppealStageDetails readAppealStage(final AppealStageID key)
    throws AppException, InformationalException {

    // Variables for Appeal Stage entity layer

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    final AppealStageKey appealStageKey = new AppealStageKey();
    AppealStageDtls appealStageDtls;

    // Variable for stage details

    final AppealStageDetails appealStageDetails = new AppealStageDetails();

    // Variables for sorted list of active stages

    OrderedAppealStageList orderedAppealStageList;

    OrderedAppealStage orderedAppealStage;

    final ProductAppealProcessID productAppealProcessID =
      new ProductAppealProcessID();

    // Get the product appeal process ID

    appealStageDetails.appealStageID = key.appealStageID;

    appealStageKey.appealStageID = key.appealStageID;
    appealStageDtls = appealStageObj.read(appealStageKey);

    productAppealProcessID.productAppealProcessID =
      appealStageDtls.productAppealProcessID;

    // Get ordered list of stages

    orderedAppealStageList = listOrderedActiveStages(productAppealProcessID);

    // Find appeal type code and stage sequence number for this Appeal Stage ID

    for (int i = 0; i < orderedAppealStageList.orderedAppealStage.size(); i++) {

      orderedAppealStage = orderedAppealStageList.orderedAppealStage.item(i);

      if (orderedAppealStage.appealStageID == key.appealStageID) {
        appealStageDetails.appealTypeCode = orderedAppealStage.appealTypeCode;
        appealStageDetails.stageSequence = orderedAppealStage.stageSequence;
        break;
      }
    }

    return appealStageDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a specified product appeal process including all of
   * it's associated active appeal stages.
   * 
   * @param key
   * The product appeal process to read.
   * @return The product appeal process details including the ordered list of
   * active appeal stages for the process.
   */
  @Override
  public ProcessAndStageDetails readProcessDetails(
    final ProductAppealProcessID key) throws AppException,
    InformationalException {

    // Service Layer Variables

    final ProcessAndStageDetails processAndStageDetails =
      new ProcessAndStageDetails();

    final ProductAppealProcessID productAppealProcessID =
      new ProductAppealProcessID();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    // Get the process details

    productAppealProcessKey.productAppealProcessID =
      key.productAppealProcessID;

    try {
      processAndStageDetails.processSummary =
        productAppealProcessObj.readProcess(productAppealProcessKey);

    } catch (final RecordNotFoundException e) {

      processAndStageDetails.processSummary = new ProcessSummary();
    }

    // Get list of active stages

    productAppealProcessID.productAppealProcessID =
      key.productAppealProcessID;

    processAndStageDetails.orderedAppealStageList =
      listOrderedActiveStages(productAppealProcessID);

    return processAndStageDetails;

  }

  // ___________________________________________________________________________
  /**
   * Validates that a product appeal process can be canceled.
   * 
   * @param details
   * The details for canceling a product appeal process.
   */
  @Override
  protected void validateCancelProcess(final ProcessIDAndVersionNo details)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    RecordStatusStartDate recordStatusStartDate;

    // Get details for validation

    productAppealProcessKey.productAppealProcessID =
      details.productAppealProcessID;

    recordStatusStartDate =
      productAppealProcessObj
        .readStartDateAndStatusDetails(productAppealProcessKey);

    // Check if the process is already canceled

    if (recordStatusStartDate.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            curam.message.BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_XRV_ALREADY_CANCELLED),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if the start date has past

    if (!recordStatusStartDate.startDate.after(Date.getCurrentDate())) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            curam.message.BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_XRV_PAST_STARTDATE),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates that an appeal stage can be canceled.
   * 
   * @param details
   * The details for canceling an appeal stage.
   */
  @Override
  protected void validateCancelStage(final AppealStageIDVersionNo details)
    throws AppException, InformationalException {

    // Variable for validation error messages

    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    RecordStatusStartDate recordStatusStartDate;

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    final AppealStageKey appealStageKey = new AppealStageKey();

    ProcessIDAndRecordStatus processIDAndRecordStatus;

    // Get the stage details for validation

    appealStageKey.appealStageID = details.appealStageID;

    processIDAndRecordStatus =
      appealStageObj.readStatusAndProcessID(appealStageKey);

    // Check if this stage is already canceled

    if (processIDAndRecordStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_ALREADY_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Get the process details for validation

    productAppealProcessKey.productAppealProcessID =
      processIDAndRecordStatus.productAppealProcessID;

    recordStatusStartDate =
      productAppealProcessObj
        .readStartDateAndStatusDetails(productAppealProcessKey);

    // Check if the process is canceled

    if (recordStatusStartDate.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PROCESS_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if the process start date has past
    if (recordStatusStartDate.startDate.before(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PAST_STARTDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates the start date for a product appeal process.
   * 
   * @param details
   * The product appeal process start date to validate.
   */
  @Override
  protected void validateStartDate(final ProcessStartDate details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager =
      new InformationalManager();

    // Check if the process start date has past

    if (!details.processStartDate.after(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_FV_STARTDATE_PAST),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of validation errors

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates the creation of a new appeal stage for a product appeal process.
   * 
   * @param details
   * The appeal stage creation details
   */
  @Override
  protected void validateCreateStage(final CreateStageDetails details)
    throws AppException, InformationalException {

    // Variable for validation error messages

    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    RecordStatusStartDate recordStatusStartDate;

    // Get the process details for validation

    productAppealProcessKey.productAppealProcessID =
      details.productAppealProcessID;

    recordStatusStartDate =
      productAppealProcessObj
        .readStartDateAndStatusDetails(productAppealProcessKey);

    // Check if the process is canceled

    if (recordStatusStartDate.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PROCESS_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check that the start date is in the present or future
    if (recordStatusStartDate.startDate.before(Date.getCurrentDate())) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PAST_STARTDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Validates that an appeal stage can be modified
   * 
   * @param details
   * The appeal stage id of the stage to be modified
   */
  @Override
  protected void validateModifyStage(final AppealStageID details)
    throws AppException, InformationalException {

    // Variable for validation error messages

    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();

    final ProductAppealProcessKey productAppealProcessKey =
      new ProductAppealProcessKey();

    RecordStatusStartDate recordStatusStartDate;

    // Entity layer variables for Appeal Stage

    final AppealStage appealStageObj = AppealStageFactory.newInstance();

    final AppealStageKey appealStageKey = new AppealStageKey();

    ProcessIDAndRecordStatus processIDAndRecordStatus;

    // Get the stage details for validation

    appealStageKey.appealStageID = details.appealStageID;

    processIDAndRecordStatus =
      appealStageObj.readStatusAndProcessID(appealStageKey);

    // Check if this stage is already canceled

    if (processIDAndRecordStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_ALREADY_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Get the process details for validation

    productAppealProcessKey.productAppealProcessID =
      processIDAndRecordStatus.productAppealProcessID;

    recordStatusStartDate =
      productAppealProcessObj
        .readStartDateAndStatusDetails(productAppealProcessKey);

    // Check if the process is canceled

    if (recordStatusStartDate.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PROCESS_CANCELLED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Check if the process start date has past

    if (!recordStatusStartDate.startDate.after(Date.getCurrentDate())) {
      informationalManager.addInformationalMsg(new AppException(
        BPOAPPEALSTAGE.ERR_APPEALSTAGE_XRV_PAST_STARTDATE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors

    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage in a
   * process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage at the requested position or null if none are
   * found.
   */
  @Override
  public AppealStageType getStageAtPosition(final StagePositionDetails key)
    throws AppException, InformationalException {

    // BEGIN, CR00284786, DG
    AppealStageType appealStageType = new AppealStageType();

    final OrderedAppealStage stageDetailsAtPosition =
      getStageDetailsAtPosition(key);

    if (stageDetailsAtPosition != null) {
      appealStageType.appealStageType.appealStageType =
        stageDetailsAtPosition.appealTypeCode;
    } else {
      // existing processing depends on this value being null if no records
      // are found.
      appealStageType = null;
    }
    // END, CR00284786
    return appealStageType;

  }

  // ___________________________________________________________________________
  /**
   * Validates that an appeal process can be created
   * 
   * @param details
   * The product ID and appeal process start date
   */

  @Override
  public void validateCreateProcess(final ProductIDStartDate details)
    throws AppException, InformationalException {

    // Variable for validation error messages
    final InformationalManager informationalManager =
      new InformationalManager();

    // Entity layer variables for Product Appeal Process

    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();

    final ProductStartDateActiveDetails productStartDateActiveDetails =
      new ProductStartDateActiveDetails();
    ProductAppealProcessKeyList productAppealProcessKeyList;

    // Search for existing an active appeal process with the same
    // start date and ProductID

    productStartDateActiveDetails.productID =
      details.productIDStartDate.productID;
    productStartDateActiveDetails.startDate =
      details.productIDStartDate.startDate;

    productAppealProcessKeyList =
      productAppealProcessObj
        .searchActiveByProductAndStartDate(productStartDateActiveDetails);

    // Check that there is no active process with the same start date

    if (productAppealProcessKeyList.dtls.size() > 0) {
      informationalManager
        .addInformationalMsg(
          new AppException(
            curam.message.BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_XRV_ALREADY_EXISTS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
    }

    // Inform user of any and all validation errors
    informationalManager.failOperation();

  }

  // ___________________________________________________________________________
  /**
   * Counts the number of prior appeals on an appealed case
   * 
   * @param key
   * The prior appeal case ID and the implementation case ID.
   * 
   * @return The number of prior appeals.
   */

  @Override
  public PriorAppealCount getNumberPriorAppeals(final CaseAndPriorAppeal key)
    throws AppException, InformationalException {

    // Variables for AppealRelationship Entity

    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();

    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();

    final curam.appeal.sl.entity.struct.PriorAppealCaseID priorAppealCaseID =
      new curam.appeal.sl.entity.struct.PriorAppealCaseID();

    // Variable for number of prior appeal stages

    final PriorAppealCount priorAppealCount = new PriorAppealCount();

    // Start to count the number of prior appeal stages

    priorAppealCount.count = 0;
    priorAppealCaseID.priorAppealCaseID = key.priorAppealCaseID;
    appealCaseAndCase.caseID = key.caseID;

    // Loop until all prior appeal cases have been counted

    while (priorAppealCaseID.priorAppealCaseID != 0) {

      priorAppealCount.count++;

      // BEGIN, CR00297475, DG
      // Get the prior appeal case identifier
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.appealCaseID = priorAppealCaseID.priorAppealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == key.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00297475
    }

    return priorAppealCount;
  }

  // ___________________________________________________________________________
  /**
   * This method returns the number of appeal stages where an appeal of the
   * specified type can be created for a product.
   * 
   * @param details
   * The product to determine the number of appeal stages for, the type
   * of appeal to consider and the start date for determining the
   * active product appeal process.
   * @return The number of appeal stages for a product where an appeal of the
   * specified type can be created.
   */
  @Override
  public AppealTypeCount getNumberAppealStagesForAppealType(
    final ProductAndStartDateAndAppealType details) throws AppException,
    InformationalException {

    // Return Variable
    final AppealTypeCount appealTypeCount = new AppealTypeCount();

    // Entity layer variables for Product Appeal Process
    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();
    final ProductStartDateActiveDetails productStartDateAndActiveDetails =
      new ProductStartDateActiveDetails();
    curam.appeal.sl.entity.struct.ProductAppealProcessID productAppealProcessID =
      new curam.appeal.sl.entity.struct.ProductAppealProcessID();

    // Entity layer variables for Appeal Stage
    final AppealStage appealStageObj = AppealStageFactory.newInstance();
    final AppealTypeAndProcess appealTypeAndProcess =
      new AppealTypeAndProcess();

    // Get the Product Appeal Process ID for this Product ID and Start Date`
    try {
      productStartDateAndActiveDetails.productID = details.productID;
      productStartDateAndActiveDetails.startDate = details.startDate;
      productAppealProcessID =
        productAppealProcessObj
          .readProcessIDByProductAndStartDate(productStartDateAndActiveDetails);
    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for the product
      throw new AppException(
        curam.message.BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_XRV_NO_ACTIVE_PROCESS);
    }

    // Get the number of stages allowed for this Product Appeal Process
    // and Appeal Type Code
    appealTypeAndProcess.appealTypeCode = details.appealStageAppealTypeCode;
    appealTypeAndProcess.anyAppealTypeCode = APPEALSTAGEAPPEALTYPE.ANY;
    appealTypeAndProcess.productAppealProcessID =
      productAppealProcessID.productAppealProcessID;
    appealTypeAndProcess.recordStatus = RECORDSTATUS.NORMAL;

    appealTypeCount.count =
      appealStageObj.countAppealStagesForAppealType(appealTypeAndProcess).numberOfRecords;

    return appealTypeCount;
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of active appeal stages for a product where an appeal of
   * the specified type can be created. For each appeal stage an indicator as to
   * whether or not the stage is first level of appeal for the product is also
   * returned.
   * 
   * @param details
   * The product, date and appeal type to search for
   * @return List of appeal stage identifiers including an indicator for whether
   * or not the stage is the first level of appeal.
   */
  @Override
  public StageFirstLevelDetailsList listStageFirstLevelForAppealType(
    final ProductAndStartDateAndAppealType details) throws AppException,
    InformationalException {

    // Variables for formatting the return and the return variable itself.
    StageFirstLevelDetailsList stageFirstLevelDetailsList =
      new StageFirstLevelDetailsList();
    StageFirstLevelDetails stageFirstLevelDetails;

    // Variables for determining the active product appeal process
    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      curam.appeal.sl.entity.fact.ProductAppealProcessFactory.newInstance();
    final ProductStartDateActiveDetails productStartDateActiveDetails =
      new ProductStartDateActiveDetails();
    final ProductAppealProcessID productAppealProcessID =
      new ProductAppealProcessID();
    StageAndParentDetailsList stageAndParentDetailsList;
    final StagePositionDetails stagePositionDetails =
      new StagePositionDetails();
    AppealStageType appealStageType;

    // Variables for getting the list of active appeal stages for a product
    // appeal process configuration
    final curam.appeal.sl.entity.intf.AppealStage appealStageObj =
      curam.appeal.sl.entity.fact.AppealStageFactory.newInstance();
    final AppealTypeAndProcess appealTypeAndProcess =
      new AppealTypeAndProcess();

    // Determine the active product appeal process configuration for the
    // product.
    try {
      productStartDateActiveDetails.productID = details.productID;
      productStartDateActiveDetails.startDate = details.startDate;
      productAppealProcessID.productAppealProcessID =
        productAppealProcessObj
          .readProcessIDByProductAndStartDate(productStartDateActiveDetails).productAppealProcessID;
    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for the product
      stageFirstLevelDetailsList = null;
    }

    if (stageFirstLevelDetailsList != null) {
      // Get all of the active appeal stages for the product appeal process
      // where
      // the an appeal of the specified type can be created; note that appeal
      // stages configured for "any" type of appeal are also included.
      appealTypeAndProcess.productAppealProcessID =
        productAppealProcessID.productAppealProcessID;
      appealTypeAndProcess.appealTypeCode = details.appealStageAppealTypeCode;
      stageAndParentDetailsList =
        appealStageObj
          .searchActiveStageParentByProcessAndType(appealTypeAndProcess);

      // For each appeal stage determine whether it is the first level of
      // appeal; an
      // appeal stage is the first stage when it has no active parent appeal
      // stage.
      for (int i = 0; i < stageAndParentDetailsList.dtls.size(); i++) {

        stageFirstLevelDetails = new StageFirstLevelDetails();
        stageFirstLevelDetails.appealStageID =
          stageAndParentDetailsList.dtls.item(i).appealStageID;

        // If there is no active parent for an appeal stage then the appeal
        // stage is
        // the first level of appeal for a product.
        if (stageAndParentDetailsList.dtls.item(i).parentAppealStageID == 0) {
          stageFirstLevelDetails.firstLevelIndicator = true;

        } else {
          // If this matches the first active stage then it is a first level of
          // appeal
          stagePositionDetails.position = 0;
          stagePositionDetails.productID = details.productID;
          stagePositionDetails.startDate = details.startDate;
          appealStageType = getStageAtPosition(stagePositionDetails);

          if (appealStageType.appealStageType.appealStageType
            .equals(details.appealStageAppealTypeCode)
            || appealStageType.appealStageType.appealStageType
              .equals(APPEALSTAGEAPPEALTYPE.ANY)) {

            stageFirstLevelDetails.firstLevelIndicator = true;

          } else {

            stageFirstLevelDetails.firstLevelIndicator = false;
          }
        }

        stageFirstLevelDetailsList.stageFirstLevelDetails
          .addRef(stageFirstLevelDetails);
      }

    }

    return stageFirstLevelDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns the next level of appeal for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID
   * @return Next valid appeal stage type
   */
  @Override
  public AppealStageType getNextAppealStage(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // BEGIN, CR00295153, DG
    // Details to return
    final AppealStageType appealStageType = new AppealStageType();
    // BEGIN, CR00296080, DG
    final OrderedAppealStage orderedAppealStage =
      getNextAppealStageDetails(appealCaseIDCaseID);

    if (orderedAppealStage != null) {
      appealStageType.appealStageType.appealStageType =
        orderedAppealStage.appealTypeCode;
    }
    // END, CR00296080
    // END, CR00295153
    return appealStageType;

  }

  // BEGIN, CR00284786, DG
  // ___________________________________________________________________________
  /**
   * Get the details of the current appeal stage for a case.
   * 
   * @param appealCaseIDCaseID
   * The appeal case and case identifiers.
   * @return Details of the current appeal stage for the case.
   */
  @Override
  public OrderedAppealStage getCurrentAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final PriorAppealCaseID priorAppealCaseID = new PriorAppealCaseID();
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();

    // Variables for Appeal service layer
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseIDDetails caseIDDetails = new CaseIDDetails();
    ProductIDDetails productIDDetails;

    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Return Variable
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Retrieve Prior AppealCaseID if it exists. Otherwise this is a new appeal
    // case.
    if (appealCaseIDCaseID.appealCaseID != 0) {

      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;

      // BEGIN, , DK
      // Get the prior appeal case identifier
      final AppealCaseID appealCaseID = new AppealCaseID();

      appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == appealCaseIDCaseID.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }

      // END,
      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

      // Case header variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();
      curam.core.struct.CaseTypeCode caseTypeCode;

      // AppealRelationship object and structs
      PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList;

      caseKey.caseID = appealCaseIDCaseID.appealCaseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      if (priorAppealCount.count == 0
        && caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);
        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if
          // any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);
        }
      }
    }

    // Get the product ID for the implementation case being appealed
    caseIDDetails.caseID = appealCaseIDCaseID.caseID;
    productIDDetails = appealObj.getProductForCase(caseIDDetails);

    // Determine the appeal type for the next stage in the appeal process for
    // the product.
    final StagePositionDetails stagePositionDetails =
      new StagePositionDetails();

    stagePositionDetails.productID = productIDDetails.productID;
    stagePositionDetails.startDate = Date.getCurrentDate();
    stagePositionDetails.position = priorAppealCount.count;
    orderedAppealStage = getStageDetailsAtPosition(stagePositionDetails);

    return orderedAppealStage;
  }

  // ___________________________________________________________________________
  /**
   * Returns the details for a stage in an appeals process; the stage is
   * identified by its sequence position. For example: get 2nd stage details in
   * a process.
   * 
   * @param key
   * Number to identify the position of the required stage. The
   * position starts from 1.
   * @return The appeal stage details at the requested position or null if none
   * are found.
   */
  @Override
  public OrderedAppealStage getStageDetailsAtPosition(
    final StagePositionDetails key) throws AppException,
    InformationalException {

    // Variable for returning the appeal stage
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Variables for getting the current Product Appeal Process
    final curam.appeal.sl.entity.intf.ProductAppealProcess productAppealProcessObj =
      ProductAppealProcessFactory.newInstance();
    final ProductStartDateActiveDetails productStartDateActiveDetails =
      new ProductStartDateActiveDetails();

    // Variables for getting the sorted list of active stages for a product
    // appeal process
    OrderedAppealStageList orderedAppealStageList;
    final ProductAppealProcessID productAppealProcessID =
      new ProductAppealProcessID();

    try {
      // Get the active product appeal process for this product based on the
      // start date provided.
      productStartDateActiveDetails.startDate = key.startDate;
      productStartDateActiveDetails.productID = key.productID;
      productAppealProcessID.productAppealProcessID =
        productAppealProcessObj
          .readProcessIDByProductAndStartDate(productStartDateActiveDetails).productAppealProcessID;
    } catch (final RecordNotFoundException e) {
      // There is no active product appeal process defined for the product
      throw new AppException(
        curam.message.BPOPRODUCTAPPEALPROCESS.ERR_PRODUCTAPPEALPROCESS_XRV_NO_ACTIVE_PROCESS);
    }

    // Get ordered list of stages for the active product appeal process
    orderedAppealStageList = listOrderedActiveStages(productAppealProcessID);

    // BEGIN, CR00095521, RKi
    // BEGIN, CR00096402, RKi
    // Get the appeal stage at the specified position
    if (key.position < orderedAppealStageList.orderedAppealStage.size()) {
      // END, CR00096402
      orderedAppealStage =
        orderedAppealStageList.orderedAppealStage.item((int) key.position);

      // END, CR00095521
    } else {

      // There are no appeal stages defined for the product at the specified
      // position.
      orderedAppealStage = null;
    }

    return orderedAppealStage;
  }

  // END, CR00284786

  // ___________________________________________________________________________
  /**
   * Return the details of next level of appeal for an appeal case.
   * 
   * @param appealCaseIDCaseID
   * Contains the Appeal CaseID and the implementation CaseID
   * @return Details of the next appeal stage on an appeal case.
   */
  @Override
  public OrderedAppealStage getNextAppealStageDetails(
    final AppealCaseIDCaseID appealCaseIDCaseID) throws AppException,
    InformationalException {

    // Details to return
    OrderedAppealStage orderedAppealStage = new OrderedAppealStage();

    // Variables for AppealRelationship Entity
    final AppealRelationship appealRelationshipObj =
      AppealRelationshipFactory.newInstance();
    final AppealCaseAndCase appealCaseAndCase = new AppealCaseAndCase();
    PriorAppealCount priorAppealCount = new PriorAppealCount();

    // Variables for Appeal service layer
    final curam.appeal.sl.intf.Appeal appealObj =
      curam.appeal.sl.fact.AppealFactory.newInstance();
    final CaseIDDetails caseIDDetails = new CaseIDDetails();
    ProductIDDetails productIDDetails;

    final StagePositionDetails stagePositionDetails =
      new StagePositionDetails();
    final CaseAndPriorAppeal caseAndPriorAppeal = new CaseAndPriorAppeal();

    // Retrieve Prior AppealCaseID if it exists
    if (appealCaseIDCaseID.appealCaseID != 0) {
      appealCaseAndCase.caseID = appealCaseIDCaseID.caseID;
      appealCaseAndCase.appealCaseID = appealCaseIDCaseID.appealCaseID;
      // BEGIN, CR00297475, DG
      // Get the prior appeal case identifier
      final PriorAppealCaseID priorAppealCaseID = new PriorAppealCaseID();
      final AppealCaseID appealCaseID1 = new AppealCaseID();

      appealCaseID1.appealCaseID = appealCaseIDCaseID.appealCaseID;
      final AppealRelationShipDetailsList appealRelationShipDetailsList =
        appealRelationshipObj.searchByAppealCase(appealCaseID1);

      for (final AppealRelationShipDetails o : appealRelationShipDetailsList.dtls) {
        if (o.caseID == appealCaseIDCaseID.caseID) {
          priorAppealCaseID.priorAppealCaseID = o.priorAppealCaseID;
          break;
        }
      }
      // END, CR00297475
      // Get the number of previous appeals for the decision being appealed (if
      // any). This gives the current appeal level for the underlying
      // case being appealed.
      caseAndPriorAppeal.caseID = appealCaseIDCaseID.caseID;
      caseAndPriorAppeal.priorAppealCaseID =
        priorAppealCaseID.priorAppealCaseID;
      priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

      // Case header variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();
      curam.core.struct.CaseTypeCode caseTypeCode;

      // AppealRelationship object and structs
      final AppealCaseID appealCaseID = new AppealCaseID();
      PriorAppealCaseIDAndCaseIDDetailsList priorAppealCaseIDAndCaseIDList;

      caseKey.caseID = appealCaseIDCaseID.appealCaseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // When an Appealed case is added to another Appeal case
      // Appealed case may not have a prior appeal case id but the
      // appeal case may have. In such a scenario, Appeal case's
      // stage differs from that of Appealed case. So get the
      // priorAppealCaseId for the Appeal case and determine the
      // correct appeal stage
      if (priorAppealCount.count == 0
        && caseTypeCode.caseTypeCode.equals(CASETYPECODE.APPEAL)) {

        appealCaseID.appealCaseID = appealCaseIDCaseID.appealCaseID;
        priorAppealCaseIDAndCaseIDList =
          appealRelationshipObj
            .searchPriorAppealCaseIDAndCaseIDForAppealCase(appealCaseID);
        if (priorAppealCaseIDAndCaseIDList.dtls.size() > 0
          && priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID != 0) {

          // Get the number of previous appeals for the decision being appealed
          // (if
          // any). This gives the current appeal level for the underlying
          // case being appealed.
          caseAndPriorAppeal.caseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).caseID;
          caseAndPriorAppeal.priorAppealCaseID =
            priorAppealCaseIDAndCaseIDList.dtls.item(0).priorAppealCaseID;
          priorAppealCount = getNumberPriorAppeals(caseAndPriorAppeal);

        }
      }
    }
    // Get the product ID for the implementation case being appealed
    caseIDDetails.caseID = appealCaseIDCaseID.caseID;
    productIDDetails = appealObj.getProductForCase(caseIDDetails);

    // Only increase the count if the appeal case exists
    // Otherwise we are looking for the 1st stage in the appeal
    // process
    if (appealCaseIDCaseID.appealCaseID != 0) {
      priorAppealCount.count++;
    }

    // Determine the appeal type for the next stage in the appeal process for
    // the product.
    stagePositionDetails.productID = productIDDetails.productID;
    stagePositionDetails.startDate = Date.getCurrentDate();
    stagePositionDetails.position = priorAppealCount.count;
    orderedAppealStage = getStageDetailsAtPosition(stagePositionDetails);

    return orderedAppealStage;
  }

}
