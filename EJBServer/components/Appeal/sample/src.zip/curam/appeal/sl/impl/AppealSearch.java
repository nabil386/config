/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.sl.impl;

import curam.appeal.sl.struct.AppealSearchKey;
import curam.appeal.sl.struct.AppealSearchResultList;
import curam.appeal.util.impl.GeneralAppealConstants;
import curam.message.BPOAPPEALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Base Class for Appeal Searches. This class should not be called directly.
 * Instead a reference to an appropriate subclass should be used.
 */
public abstract class AppealSearch extends curam.appeal.sl.base.AppealSearch {

  // ___________________________________________________________________________
  /**
   * Method to perform a search for appeal cases
   * 
   * @param key Search criteria on which the search will be based
   * 
   * @return The details of any records found
   */
  @Override
  @SuppressWarnings(GeneralAppealConstants.kUnused)
  /**
   * The key in the method parameter is unused. The method has
   * no implementation but yet provided, for the customer to
   * override it and customize the functionality.
   */
  public AppealSearchResultList search(final AppealSearchKey key)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
      .throwWithLookup(
        new AppException(BPOAPPEALSEARCH.ERR_APPEALSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    // Should not reach this point without throwing a validation
    return null;

  }
}
