/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.legalaction.facade.impl;

import curam.appeal.facade.struct.HearingScheduleReturnDtls;
import curam.legalaction.facade.struct.HearingLegalActionDetails;
import curam.legalaction.facade.struct.LegalHearingDetails;
import curam.legalaction.facade.struct.LegalHearingKey;
import curam.legalaction.facade.struct.ParentAndLegalCaseKey;
import curam.legalaction.sl.fact.LegalHearingFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * @see curam.legalaction.facade.intf.LegalHearing
 */
public abstract class LegalHearing extends
  curam.legalaction.facade.base.LegalHearing {

  /**
   * {@inheritDoc}
   */
  @Override
  public ParentAndLegalCaseKey createLegalHearing(
    final LegalHearingDetails dtls) throws AppException,
    InformationalException {

    // instance to be returned with legal action of category 'Hearing' caseID
    // and its corresponding parent caseID
    final ParentAndLegalCaseKey parentAndLegalCaseKey =
      new ParentAndLegalCaseKey();
    // instance to create a legal action
    final curam.legalaction.sl.intf.LegalHearing legalHearingObj =
      LegalHearingFactory.newInstance();

    // create legal action hearing
    parentAndLegalCaseKey.key = legalHearingObj.createLegalHearing(dtls.dtls);

    return parentAndLegalCaseKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyLegalHearing(final LegalHearingDetails dtls)
    throws AppException, InformationalException {

    // instance to modify a legal action
    final curam.legalaction.sl.intf.LegalHearing legalHearingObj =
      LegalHearingFactory.newInstance();

    // modify legal action of category 'Hearing'
    legalHearingObj.modifyLegalHearing(dtls.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public HearingLegalActionDetails
    readLegalHearing(final LegalHearingKey key) throws AppException,
      InformationalException {

    // instances to be returned with the legal action of category 'Hearing'
    final HearingLegalActionDetails hearingLegalActionDetails =
      new HearingLegalActionDetails();
    // instance to create a legal action
    final curam.legalaction.sl.intf.LegalHearing legalHearingObj =
      LegalHearingFactory.newInstance();

    // get legal action hearing details
    hearingLegalActionDetails.dtls =
      legalHearingObj.readLegalHearing(key.key);

    return hearingLegalActionDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public
    HearingScheduleReturnDtls
    scheduleExternalLocationHearing(
      final curam.legalaction.facade.struct.ScheduleExternalLocationHearingDetails details)
      throws AppException, InformationalException {

    // Instance to create a legal action
    final curam.legalaction.sl.intf.LegalHearing legalHearingObj =
      LegalHearingFactory.newInstance();
    final HearingScheduleReturnDtls hearingScheduleReturnDtls =
      new HearingScheduleReturnDtls();

    hearingScheduleReturnDtls.hearingScheduleReturnDtls =
      legalHearingObj.scheduleExternalLocationHearing(details.scheduleDtls);

    return hearingScheduleReturnDtls;
  }

}
