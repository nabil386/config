/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.legalaction.facade.impl;

import curam.legalaction.facade.struct.LegalPetitionKey;
import curam.legalaction.facade.struct.ParentAndLegalCaseKey;
import curam.legalaction.facade.struct.PetitionDetails;
import curam.legalaction.facade.struct.PetitionLegalActionDetails;
import curam.legalaction.sl.fact.LegalPetitionFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * @see curam.legalaction.facade.intf.LegalPetition
 */
public class LegalPetition extends
  curam.legalaction.facade.base.LegalPetition {

  /**
   * {@inheritDoc}
   */
  @Override
  public ParentAndLegalCaseKey createPetition(final PetitionDetails dtls)
    throws AppException, InformationalException {

    // instance to create petition
    final curam.legalaction.sl.intf.LegalPetition petitionObj =
      LegalPetitionFactory.newInstance();

    // create petition
    final ParentAndLegalCaseKey parentAndLegalCaseKey =
      new ParentAndLegalCaseKey();

    parentAndLegalCaseKey.key = petitionObj.createPetition(dtls.dtls);
    return parentAndLegalCaseKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyPetition(final PetitionDetails dtls) throws AppException,
    InformationalException {

    // instance to modify petition
    final curam.legalaction.sl.intf.LegalPetition petitionObj =
      LegalPetitionFactory.newInstance();

    // create petition
    petitionObj.modifyPetition(dtls.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public PetitionLegalActionDetails readPetition(final LegalPetitionKey key)
    throws AppException, InformationalException {

    // Instance to return petition details
    final PetitionLegalActionDetails petitionLegalActionDetails =
      new PetitionLegalActionDetails();
    // instance to read petition
    final curam.legalaction.sl.intf.LegalPetition petitionObj =
      LegalPetitionFactory.newInstance();

    // read petition details
    petitionLegalActionDetails.dtls = petitionObj.readPetition(key.key);

    return petitionLegalActionDetails;
  }
}
