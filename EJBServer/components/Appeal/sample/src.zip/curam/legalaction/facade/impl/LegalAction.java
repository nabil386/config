/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.legalaction.facade.impl;

import curam.core.facade.struct.ExternalPartyOfficeSearchKey;
import curam.core.facade.struct.ICClosureDetails;
import curam.core.sl.struct.CaseParticipantRoleKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDRelatedCaseID;
import curam.core.struct.ICClosureDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.legalaction.admin.facade.struct.AdminLegalActionDetails;
import curam.legalaction.admin.facade.struct.AdminLegalActionKey;
import curam.legalaction.admin.sl.fact.AdminLegalActionFactory;
import curam.legalaction.facade.struct.AssociatedCaseDetails;
import curam.legalaction.facade.struct.CaseIDAndConfigLegalID;
import curam.legalaction.facade.struct.ExternalOfficeLocationSearchResult;
import curam.legalaction.facade.struct.ExternalPartyMemberList;
import curam.legalaction.facade.struct.HomePageName;
import curam.legalaction.facade.struct.LegalActionCaseParticipantList;
import curam.legalaction.facade.struct.LegalActionDetails;
import curam.legalaction.facade.struct.LegalActionIDAndCaseParticipantRoleKey;
import curam.legalaction.facade.struct.LegalActionKey;
import curam.legalaction.facade.struct.LegalActionStatementDetails;
import curam.legalaction.facade.struct.LegalActionViewDetails;
import curam.legalaction.facade.struct.LegalActionsByCaseDtlsList;
import curam.legalaction.facade.struct.ParentAndLegalCaseKey;
import curam.legalaction.facade.struct.ParticipantAndLegalCategoryDetails;
import curam.legalaction.facade.struct.ParticipantDetailsAndStatusList;
import curam.legalaction.facade.struct.ParticipantMultiselectDetails;
import curam.legalaction.facade.struct.ParticipantMultiselectViewDetails;
import curam.legalaction.facade.struct.ParticipantStatusDetails;
import curam.legalaction.facade.struct.ParticipantStatusViewDetails;
import curam.legalaction.facade.struct.ViewLegalActionParticipantList;
import curam.legalaction.sl.fact.LegalActionFactory;
import curam.legalaction.sl.fact.LegalActionStatementFactory;
import curam.legalaction.sl.fact.LegalParticipantFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * @see curam.legalaction.facade.intf.LegalAction
 */
public abstract class LegalAction extends
  curam.legalaction.facade.base.LegalAction {

  /**
   * {@inheritDoc}
   */
  @Override
  public ParentAndLegalCaseKey
    createLegalAction(final LegalActionDetails dtls) throws AppException,
      InformationalException {

    final ParentAndLegalCaseKey parentAndLegalCaseKey =
      new ParentAndLegalCaseKey();

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    parentAndLegalCaseKey.key = legalActionObj.createLegalAction(dtls.dtls);
    return parentAndLegalCaseKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantAndLegalCategoryDetails
    listParticipantsLegalActionCategory(final CaseIDAndConfigLegalID key)
      throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final ParticipantAndLegalCategoryDetails participantAndLegalCategoryDetails =
      new ParticipantAndLegalCategoryDetails();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    participantAndLegalCategoryDetails.dtls =
      legalActionObj.listParticipantsLegalActionCategory(key.key);
    return participantAndLegalCategoryDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionsByCaseDtlsList
    listLegalActionsByCaseID(final CaseID key) throws AppException,
      InformationalException {

    TransactionInfo.setInformationalManager();
    final LegalActionsByCaseDtlsList legalActionsByCaseDtlsList =
      new LegalActionsByCaseDtlsList();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionsByCaseDtlsList.dtls =
      legalActionObj.listLegalActionsByCaseID(key);
    return legalActionsByCaseDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelLegalAction(final LegalActionKey key)
    throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionObj.cancelLegalAction(key.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyLegalAction(final LegalActionDetails dtls)
    throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionObj.modifyLegalAction(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionViewDetails readByLegalActionCaseID(final CaseID key)
    throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final LegalActionViewDetails legalActionViewDetails =
      new LegalActionViewDetails();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionViewDetails.dtls = legalActionObj.readByLegalActionCaseID(key);
    return legalActionViewDetails;
  }

  // BEGIN, CR00441076, KRK
  /**
   * {@inheritDoc}
   */
  @Override
  public AdminLegalActionDetails getLegalActionHomePageDetails(
    final CaseIDAndConfigLegalID caseIDAndConfigLegalID) throws AppException,
    InformationalException {

    final AdminLegalActionDetails adminLegalActionDetails =
      new AdminLegalActionDetails();
    final AdminLegalActionKey adminLegalActionKey = new AdminLegalActionKey();

    adminLegalActionKey.key.key.legalActionID =
      caseIDAndConfigLegalID.key.configLegalActionID;

    adminLegalActionDetails.dtls =
      AdminLegalActionFactory.newInstance().readAdminLegalActionDetails(
        adminLegalActionKey.key);

    return adminLegalActionDetails;
  }

  // END, CR00441076

  /**
   * {@inheritDoc}
   */
  @Override
  public InformationalMsgDtlsList addStatement(
    final LegalActionStatementDetails dtls) throws AppException,
    InformationalException {

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalActionStatement legalActionStatementObj =
      LegalActionStatementFactory.newInstance();

    return legalActionStatementObj.addStatement(dtls.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionsByCaseDtlsList
    listLegalActionsForPopup(final CaseID key) throws AppException,
      InformationalException {

    TransactionInfo.setInformationalManager();
    final LegalActionsByCaseDtlsList legalActionsByCaseDtlsList =
      new LegalActionsByCaseDtlsList();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionsByCaseDtlsList.dtls =
      legalActionObj.listLegalActionsForPopup(key);
    return legalActionsByCaseDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ViewLegalActionParticipantList
    listLegalActionCaseParticipantsDetails(final CaseID key)
      throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final ViewLegalActionParticipantList legalActionParticipantList =
      new ViewLegalActionParticipantList();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionParticipantList.dtls =
      legalActionObj.listLegalActionCaseParticipantsDetails(key);
    return legalActionParticipantList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantDetailsAndStatusList readParticipantToModifyStatus(
    final LegalActionIDAndCaseParticipantRoleKey key) throws AppException,
    InformationalException {

    TransactionInfo.setInformationalManager();
    final ParticipantDetailsAndStatusList participantDetailsAndStatusList =
      new ParticipantDetailsAndStatusList();
    final curam.legalaction.sl.intf.LegalParticipant legalParticipantObj =
      LegalParticipantFactory.newInstance();

    participantDetailsAndStatusList.dtls =
      legalParticipantObj.readParticipantToModifyStatus(key.key);
    return participantDetailsAndStatusList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void
    modifyParticipantLegalStatus(final ParticipantStatusDetails dtls)
      throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();

    final curam.legalaction.sl.intf.LegalParticipant legalParticipantObj =
      LegalParticipantFactory.newInstance();

    // modify legal status of a legal participant.
    // legalParticipantObj.modifyParticipantLegalStatus(dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantStatusViewDetails readParticipantStatus(
    final LegalActionIDAndCaseParticipantRoleKey key) throws AppException,
    InformationalException {

    TransactionInfo.setInformationalManager();
    final ParticipantStatusViewDetails participantStatusViewDetails =
      new ParticipantStatusViewDetails();
    final curam.legalaction.sl.intf.LegalParticipant legalParticipantObj =
      LegalParticipantFactory.newInstance();

    participantStatusViewDetails.dtls =
      legalParticipantObj.readParticipantStatus(key.key);
    return participantStatusViewDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyParticipantDetails(
    final ParticipantMultiselectDetails dtls) throws AppException,
    InformationalException {

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalParticipant legalParticipantObj =
      LegalParticipantFactory.newInstance();

    legalParticipantObj.modifyParticipantDetails(dtls.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantMultiselectViewDetails readParticipantDetails(
    final CaseID key) throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final ParticipantMultiselectViewDetails participantMultiselectViewDetails =
      new ParticipantMultiselectViewDetails();
    final curam.legalaction.sl.intf.LegalParticipant legalParticipantObj =
      LegalParticipantFactory.newInstance();

    participantMultiselectViewDetails.dtls =
      legalParticipantObj.readParticipantDetails(key);
    return participantMultiselectViewDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ParticipantAndLegalCategoryDetails listParticipantsAndLegalCategory(
    final CaseID key) throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();
    final ParticipantAndLegalCategoryDetails participantAndLegalCategoryDetails =
      new ParticipantAndLegalCategoryDetails();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    participantAndLegalCategoryDetails.dtls =
      legalActionObj.listParticipantsAndLegalCategory(key);
    return participantAndLegalCategoryDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public HomePageName readHomePageByCaseID(final CaseID key)
    throws AppException, InformationalException {

    final HomePageName homePageName = new HomePageName();

    TransactionInfo.setInformationalManager();
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    homePageName.dtls = legalActionObj.readHomePageByCaseID(key);
    return homePageName;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void associateLegalAction(final AssociatedCaseDetails dtls)
    throws AppException, InformationalException {

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    // Get the home page name of legal action case
    legalActionObj.associateLegalAction(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionsByCaseDtlsList listLegalActionsForAssociation(
    final CaseIDAndConfigLegalID key) throws AppException,
    InformationalException {

    final LegalActionsByCaseDtlsList legalActionsList =
      new LegalActionsByCaseDtlsList();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionsList.dtls =
      legalActionObj.listLegalActionsForAssociation(key.key);
    return legalActionsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionCaseParticipantList listLegalActionsForCaseParticipant(
    final CaseParticipantRoleKey key) throws AppException,
    InformationalException {

    final LegalActionCaseParticipantList participantList =
      new LegalActionCaseParticipantList();
    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    participantList.caseParticipantList =
      legalActionObj.listLegalActionsForCaseParticipant(key);
    return participantList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ExternalOfficeLocationSearchResult searchExternalOfficeLocation(
    final ExternalPartyOfficeSearchKey key) throws AppException,
    InformationalException {

    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();
    final ExternalOfficeLocationSearchResult externalOfficeLocationSearchResult =
      new ExternalOfficeLocationSearchResult();

    final curam.core.sl.struct.ExternalPartyOfficeSearchKey externalPartyOfficeSearchKey =
      new curam.core.sl.struct.ExternalPartyOfficeSearchKey();

    externalPartyOfficeSearchKey.officeSearchKey = key.officeSearchKey;
    externalOfficeLocationSearchResult.list =
      legalActionObj
        .searchExternalOfficeLocation(externalPartyOfficeSearchKey);

    return externalOfficeLocationSearchResult;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void closeCase(final ICClosureDetails details) throws AppException,
    InformationalException {

    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();
    final ICClosureDtls icClosureDtls = new ICClosureDtls();

    icClosureDtls.assign(details);
    legalActionObj.closeCase(icClosureDtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ExternalPartyMemberList listExternalPartyMembers()
    throws AppException, InformationalException {

    // Create BPO Object
    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();
    final ExternalPartyMemberList externalPartyMemberList =
      new ExternalPartyMemberList();

    externalPartyMemberList.list = legalActionObj.listExternalPartyMembers();

    return externalPartyMemberList;
  }

  // BEGIN, CR00143812, GYH
  /**
   * {@inheritDoc}
   */
  @Override
  public void disassociateLegalAction(final CaseIDRelatedCaseID dtls)
    throws AppException, InformationalException {

    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    legalActionObj.disassociateLegalAction(dtls);
  }

  // END, CR00143812

  // BEGIN, CR00293197, KRK
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseID readCaseIDByLegalActionCaseID(final CaseID caseID)
    throws AppException, InformationalException {

    final curam.legalaction.sl.intf.LegalAction legalActionObj =
      LegalActionFactory.newInstance();

    caseID.caseID =
      legalActionObj.readCaseIDByLegalActionCaseID(caseID).caseID;

    return caseID;
  }
  // END, CR00293197
}
