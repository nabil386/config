/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.legalaction.facade.impl;

import curam.legalaction.facade.struct.CancelDecisionAttachmentDetails;
import curam.legalaction.facade.struct.CreateDecisionAttachmentDetails;
import curam.legalaction.facade.struct.DecisionAttachmentForModifyDetails;
import curam.legalaction.facade.struct.DecisionAttachmentKey;
import curam.legalaction.facade.struct.DecisionAttachmentSummaryDetails;
import curam.legalaction.facade.struct.InternalAttachmentDetails;
import curam.legalaction.facade.struct.MSWordTemplateAndDocumentDetails;
import curam.legalaction.facade.struct.ModifyDecisionAttachmentDetails;
import curam.legalaction.facade.struct.ReadForDownloadDetails;
import curam.legalaction.sl.fact.DecisionAttachmentFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * @see curam.legalaction.facade.intf.LegalActionDecisionAttachment
 */
public class LegalActionDecisionAttachment extends
  curam.legalaction.facade.base.LegalActionDecisionAttachment {

  /**
   * {@inheritDoc}
   */
  @Override
  public void createExternal(final CreateDecisionAttachmentDetails dtls)
    throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Create an external legal action decision attachment.
    decisionAttachmentObj.createExternal(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final CancelDecisionAttachmentDetails dtls)
    throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Cancel a decision attachment.
    decisionAttachmentObj.cancel(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyExternal(final ModifyDecisionAttachmentDetails dtls)
    throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Modify an external legal action decision attachment.
    decisionAttachmentObj.modifyExternal(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyMSWord(final InternalAttachmentDetails dtls)
    throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Modify an Microsoft Word legal action decision attachment.
    decisionAttachmentObj.modifyMSWord(dtls.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DecisionAttachmentSummaryDetails readExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    final DecisionAttachmentSummaryDetails decisionAttachmentSummaryDetails =
      new DecisionAttachmentSummaryDetails();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Read an external legal action decision attachment.
    decisionAttachmentSummaryDetails.dtls =
      decisionAttachmentObj.readExternal(key.key);

    return decisionAttachmentSummaryDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DecisionAttachmentForModifyDetails readForModifyExternal(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    final DecisionAttachmentForModifyDetails decisionAttachmentForModifyDetails =
      new DecisionAttachmentForModifyDetails();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // the details, required for modification, for a decision attachment
    // where an external document has been attached.
    decisionAttachmentForModifyDetails.dtls =
      decisionAttachmentObj.readForModifyExternal(key.key);

    return decisionAttachmentForModifyDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public MSWordTemplateAndDocumentDetails readMSWordTemplateAndDocument(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    final MSWordTemplateAndDocumentDetails wordTemplateAndDocumentDetails =
      new MSWordTemplateAndDocumentDetails();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Get the details of for an internally created word document.
    wordTemplateAndDocumentDetails.dtls =
      decisionAttachmentObj.readMSWordTemplateAndDocument(key.key);

    return wordTemplateAndDocumentDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadForDownloadDetails readForDownload(
    final DecisionAttachmentKey key) throws AppException,
    InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    final ReadForDownloadDetails readForDownloadDetails =
      new ReadForDownloadDetails();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.DecisionAttachment decisionAttachmentObj =
      DecisionAttachmentFactory.newInstance();

    // Reads the details of an attachment to be downloaded.
    readForDownloadDetails.dtls =
      decisionAttachmentObj.readForDownload(key.key);

    return readForDownloadDetails;
  }

}
