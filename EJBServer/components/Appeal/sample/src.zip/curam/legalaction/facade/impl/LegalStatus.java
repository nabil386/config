/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.legalaction.facade.impl;

import curam.core.sl.entity.struct.ParticipantRoleIDAndNameDetails;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseParticipantRoleKey;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.legalaction.admin.facade.struct.LegalStatusesForCaseTypeList;
import curam.legalaction.facade.struct.ContextDescription;
import curam.legalaction.facade.struct.LegalStatusConfigInformation;
import curam.legalaction.facade.struct.LegalStatusDetails;
import curam.legalaction.facade.struct.LegalStatusDetailsList;
import curam.legalaction.facade.struct.LegalStatusKey;
import curam.legalaction.sl.fact.LegalStatusFactory;
import curam.legalaction.sl.struct.CaseLegalStatusDetails;
import curam.legalaction.sl.struct.CaseLegalStatusDetailsList;
import curam.message.BPOLEGALSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.resources.GeneralConstants;

/**
 * @see curam.legalaction.facade.intf.LegalStatus
 */
public class LegalStatus extends curam.legalaction.facade.base.LegalStatus {

  /**
   * {@inheritDoc}
   */
  @Override
  public void createLegalStatus(final LegalStatusDetails details)
    throws AppException, InformationalException {

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();

    legalStatusObj.createLegalStatus(details.details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void removeLegalStatus(final LegalStatusKey key)
    throws AppException, InformationalException {

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();

    legalStatusObj.deleteLegalStatus(key.key);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalStatusesForCaseTypeList listLegalStatusesForCaseMember(
    final CaseParticipantRoleKey key) throws AppException,
    InformationalException {

    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();
    final LegalStatusesForCaseTypeList legalStatusesForCaseTypeList =
      new LegalStatusesForCaseTypeList();

    legalStatusesForCaseTypeList.caseTypeList =
      legalStatusObj.listLegalStatusesForCaseMember(key);
    return legalStatusesForCaseTypeList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalStatusDetails
    modifyLegalStatus(final LegalStatusDetails details) throws AppException,
      InformationalException {

    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();
    final LegalStatusDetails modifydetails = new LegalStatusDetails();

    modifydetails.details = legalStatusObj.modifyLegalStatus(details.details);
    return modifydetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalStatusDetails readLegalStatus(final LegalStatusKey key)
    throws AppException, InformationalException {

    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();
    final LegalStatusDetails readdetails = new LegalStatusDetails();

    readdetails.details = legalStatusObj.readLegalStatus(key.key);
    return readdetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalStatusDetailsList listLegalStatusHistory(
    final CaseParticipantRoleKey key) throws AppException,
    InformationalException {

    final LegalStatusDetailsList legalStatusDetailsList =
      new LegalStatusDetailsList();
    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();

    legalStatusDetailsList.detailsList =
      legalStatusObj.listLegalStatusHistory(key);
    return legalStatusDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ContextDescription getContextDescription(
    final CaseParticipantRoleKey key) throws AppException,
    InformationalException {

    final ContextDescription description = new ContextDescription();
    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();

    description.description = legalStatusObj.getContextDescription(key);
    return description;
  }

  // BEGIN, CR00227019, GYH
  /**
   * {@inheritDoc}
   */
  @Override
  public
    void
    createLegalStatusFromCase(
      final curam.legalaction.facade.struct.CaseLegalStatusDetails legalStatusDetails)
      throws AppException, InformationalException {

    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      curam.legalaction.sl.fact.LegalStatusFactory.newInstance();

    legalStatusDetails.details.legalActionID =
      legalStatusDetails.caseLegalActionID;
    legalStatusObj.createLegalStatus(legalStatusDetails.details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalStatusConfigInformation getLSConfigInformationForCaseType(
    final CaseIDKey key) throws AppException, InformationalException {

    final LegalStatusConfigInformation legalStatusConfigInformation =
      new LegalStatusConfigInformation();

    if (!LegalStatusFactory.newInstance().listLegalStatusConfigForCaseType(
      key).statusList.isEmpty()) {
      legalStatusConfigInformation.legalStatusConfigInd = true;
    } else {
      final InformationalMsgDtlsList informationalMsgDtlsList =
        new InformationalMsgDtlsList();
      final InformationalManager informationalManager =
        new InformationalManager();
      final LocalisableString localisableString =
        new LocalisableString(
          BPOLEGALSTATUS.INF_LEGALSTATUS_LEGAL_STATUS_NOT_CONFIGURED_FOR_THIS_CASE_TYPE);

      informationalManager.addInformationalMsg(localisableString,
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);
      final String informationalMsgs[] =
        informationalManager.obtainInformationalAsString();

      for (final String informationalMsg : informationalMsgs) {
        final InformationalMsgDtls informationalMsgDtls =
          new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = informationalMsg;
        informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      legalStatusConfigInformation.msgList.informationalMsgDtlsList =
        informationalMsgDtlsList;
    }
    return legalStatusConfigInformation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public curam.legalaction.admin.sl.struct.LegalStatusesForCaseTypeList
    listLegalStatusConfigForCaseType(final CaseIDKey key)
      throws AppException, InformationalException {

    return LegalStatusFactory.newInstance().listLegalStatusConfigForCaseType(
      key);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseLegalStatusDetailsList listLegalStatusHistoryForCase(
    final CaseIDKey key) throws AppException, InformationalException {

    // Get the list of case members
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList =
      new ViewCaseParticipantRoleDetailsList();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    viewCaseParticipantRoleDetailsList =
      caseParticipantRoleObj
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    // For each case member, find if any special cautions created.
    final CaseLegalStatusDetailsList caseLegalStatusDetailsList =
      new CaseLegalStatusDetailsList();
    final curam.legalaction.sl.intf.LegalStatus legalStatusObj =
      LegalStatusFactory.newInstance();
    LegalStatusDetailsList legalStatusDetailsList =
      new LegalStatusDetailsList();

    for (final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails details : viewCaseParticipantRoleDetailsList.dtls
      .items()) {

      final CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey.key.caseParticipantRoleID =
        details.caseParticipantRoleID;
      // BEGIN, CR00266529, DG
      legalStatusDetailsList = new LegalStatusDetailsList();
      // END, CR00266529
      legalStatusDetailsList.detailsList.legalStatusDetailsList
        .addAll(legalStatusObj.listLegalStatusHistory(caseParticipantRoleKey).legalStatusDetailsList);
      caseLegalStatusDetailsList.list.addAll(populateParticipantName(
        caseParticipantRoleKey, legalStatusDetailsList).list);
    }
    return caseLegalStatusDetailsList;
  }

  /**
   * Populates the participant name for each record of special cautions.
   * 
   * @param specialCautionsList
   * Contains list of special cautions.
   * 
   * @return List of special cautions with participant name.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseLegalStatusDetailsList populateParticipantName(
    final CaseParticipantRoleKey caseParticipantRoleKey,
    final LegalStatusDetailsList legalStatusDetailsList) throws AppException,
    InformationalException {

    final CaseLegalStatusDetailsList caseLegalStatusDetailsList =
      new CaseLegalStatusDetailsList();
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    for (final curam.legalaction.sl.struct.LegalStatusDetails legalStatusDetails : legalStatusDetailsList.detailsList.legalStatusDetailsList
      .items()) {
      final CaseLegalStatusDetails caseLegalStatusDetails =
        new CaseLegalStatusDetails();

      caseLegalStatusDetails.details = legalStatusDetails;
      final curam.core.sl.entity.struct.CaseParticipantRoleKey participantRoleKey =
        new curam.core.sl.entity.struct.CaseParticipantRoleKey();

      participantRoleKey.caseParticipantRoleID =
        caseParticipantRoleKey.key.caseParticipantRoleID;
      final ParticipantRoleIDAndNameDetails participantRoleIDAndNameDetails =
        caseParticipantRoleObj
          .readParticipantRoleIDAndParticpantName(participantRoleKey);

      caseLegalStatusDetails.participantRoleID =
        participantRoleIDAndNameDetails.participantRoleID;
      caseLegalStatusDetails.participantName =
        participantRoleIDAndNameDetails.name;
      caseLegalStatusDetailsList.list.addRef(caseLegalStatusDetails);
    }
    return caseLegalStatusDetailsList;
  }
  // END, CR00227019

}
