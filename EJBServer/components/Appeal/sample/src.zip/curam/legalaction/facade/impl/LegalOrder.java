/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.legalaction.facade.impl;

import curam.legalaction.facade.struct.LegalActionKey;
import curam.legalaction.facade.struct.LegalOrderDetails;
import curam.legalaction.facade.struct.LegalOrderViewDetails;
import curam.legalaction.facade.struct.ParentAndLegalCaseKey;
import curam.legalaction.sl.fact.LegalOrderFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * @see curam.legalaction.facade.intf.LegalOrder
 */
public class LegalOrder extends curam.legalaction.facade.base.LegalOrder {

  /**
   * {@inheritDoc}
   */
  @Override
  public ParentAndLegalCaseKey createLegalOrder(
    final LegalOrderDetails details) throws AppException,
    InformationalException {

    // Create BPO Object
    final curam.legalaction.sl.intf.LegalOrder legalOrderObj =
      LegalOrderFactory.newInstance();
    // Create struct object
    final ParentAndLegalCaseKey parentAndLegalCaseKey =
      new ParentAndLegalCaseKey();

    // Call to createLegalOrder method
    parentAndLegalCaseKey.key =
      legalOrderObj.createLegalOrder(details.legalOrderDtls);

    return parentAndLegalCaseKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionKey modifyLegalOrder(final LegalOrderDetails details)
    throws AppException, InformationalException {

    // Create BPO Object
    final curam.legalaction.sl.intf.LegalOrder legalOrderObj =
      LegalOrderFactory.newInstance();
    // Call to createLegalOrder method
    final LegalActionKey legalActionKey = new LegalActionKey();

    // Call to modifyLegalOrder method
    legalActionKey.dtls =
      legalOrderObj.modifyLegalOrder(details.legalOrderDtls);

    return legalActionKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalOrderViewDetails readLegalOrder(final LegalActionKey key)
    throws AppException, InformationalException {

    // Create BPO Object
    final curam.legalaction.sl.intf.LegalOrder legalOrderObj =
      LegalOrderFactory.newInstance();
    // Call to createLegalOrder method
    final LegalOrderViewDetails legalOrderViewDetails =
      new LegalOrderViewDetails();

    // Call to readLeagalOrderDetails method
    legalOrderViewDetails.details =
      legalOrderObj.readLeagalOrderDetails(key.dtls);

    return legalOrderViewDetails;
  }

}
