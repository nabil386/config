/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.legalaction.facade.impl;

import curam.core.struct.CaseID;
import curam.legalaction.facade.struct.LegalHearingTabDetail;
import curam.legalaction.facade.struct.LegalOrderTabDetail;
import curam.legalaction.facade.struct.LegalPetitionTabDetail;
import curam.legalaction.sl.fact.LegalActionTabFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * @see curam.legalaction.facade.intf.LegalActionTab
 */
public class LegalActionTab extends
  curam.legalaction.facade.base.LegalActionTab {

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalHearingTabDetail readHearingTabDetail(final CaseID caseIDKey)
    throws AppException, InformationalException {

    final LegalHearingTabDetail legalHearingTabDetail =
      new LegalHearingTabDetail();

    legalHearingTabDetail.dtls =
      LegalActionTabFactory.newInstance().readHearingTabDetail(caseIDKey);

    return legalHearingTabDetail;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalOrderTabDetail readOrderTabDetail(final CaseID caseIDKey)
    throws AppException, InformationalException {

    final LegalOrderTabDetail legalOrderTabDetail = new LegalOrderTabDetail();

    legalOrderTabDetail.dtls =
      LegalActionTabFactory.newInstance().readOrderTabDetail(caseIDKey);

    return legalOrderTabDetail;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LegalPetitionTabDetail readPetitionTabDetail(final CaseID caseIDKey)
    throws AppException, InformationalException {

    final LegalPetitionTabDetail legalPetitionTabDetail =
      new LegalPetitionTabDetail();

    legalPetitionTabDetail.dtls =
      LegalActionTabFactory.newInstance().readPetitionTabDetail(caseIDKey);

    return legalPetitionTabDetail;
  }

}
