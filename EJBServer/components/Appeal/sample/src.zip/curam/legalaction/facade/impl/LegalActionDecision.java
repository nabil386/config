/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.legalaction.facade.impl;

import curam.legalaction.facade.struct.LegalActionDecisionAndAttachmentListDetails;
import curam.legalaction.facade.struct.LegalActionDecisionCreateDetails;
import curam.legalaction.facade.struct.LegalActionDecisionDetails;
import curam.legalaction.facade.struct.LegalActionKey;
import curam.legalaction.sl.fact.LegalActionDecisionFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * @see curam.legalaction.facade.intf.LegalActionDecision
 */
public class LegalActionDecision extends
  curam.legalaction.facade.base.LegalActionDecision {

  /**
   * {@inheritDoc}
   */
  @Override
  public void createDecision(final LegalActionDecisionCreateDetails dtls)
    throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalActionDecision legalActionDecisionObj =
      LegalActionDecisionFactory.newInstance();

    // Add final decision to a legal action
    legalActionDecisionObj.createDecision(dtls.dtls);

  }

  // BEGIN, CR00267114, ZV
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public LegalActionDecisionDetails readDecision(final LegalActionKey key)
    throws AppException, InformationalException {

    final LegalActionDecisionDetails legalActionDecisionDetails =
      new LegalActionDecisionDetails();

    legalActionDecisionDetails.assign(readDecisionAndAttachmentList(key));

    return legalActionDecisionDetails;
  }

  // END, CR00267114

  // BEGIN, CR00267114, ZV
  /**
   * {@inheritDoc}
   */
  @Override
  public LegalActionDecisionAndAttachmentListDetails
    readDecisionAndAttachmentList(final LegalActionKey key)
      throws AppException, InformationalException {

    // Set the Informational Manager for having any messages.
    TransactionInfo.setInformationalManager();

    final LegalActionDecisionAndAttachmentListDetails legalActionDecisionDetails =
      new LegalActionDecisionAndAttachmentListDetails();

    // Service Layer Component declaration.
    final curam.legalaction.sl.intf.LegalActionDecision legalActionDecisionObj =
      LegalActionDecisionFactory.newInstance();

    // Read details of legal action decision.
    legalActionDecisionDetails.dtls =
      legalActionDecisionObj.readDecisionAndAttachmentList(key.dtls);

    return legalActionDecisionDetails;
  }
  // END, CR00267114

}
