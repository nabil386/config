/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.evidencebroker.sl.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.BatchStreamHelper;
import curam.core.impl.CuramConst;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.impl.EvidenceBrokerSharingStrategy;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.struct.ApplyChangesEvidenceLists;
import curam.core.sl.infrastructure.struct.EvidenceKey;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.WMInstanceDataDtls;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.NoSuchSchemaException;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.cache.Cache;
import curam.util.cache.CacheManagerEjb;
import curam.util.cache.internal.admin.CacheConfiguration;
import curam.util.cache.internal.admin.ConfigurableCache;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.StringList;
import curam.verification.sl.infrastructure.impl.DeferredVerificationProcessBehaviour;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * This process class provides the functionality for the Shared Evidence service
 * layer.
 */
@Deprecated
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public abstract class EvidenceBroker
  extends curam.evidencebroker.sl.base.EvidenceBroker {

  // BEGIN, CR00343048, GYH
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * A hash map reference of the evidence broker sharing strategy module which
   * is registered in the registry.
   */
  @Deprecated
  @Inject
  protected Map<String, EvidenceBrokerSharingStrategy> evidenceBrokerSharingStrategyMap;

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Reference to a helper class {@link ProcessEvidenceHelper}.
   */
  @Deprecated
  @Inject
  protected ProcessEvidenceHelper processEvidenceHelper;

  // END, CR00343048

  // BEGIN, CR00352039, PB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Finalize evidence list hook object.
   */
  @Deprecated
  @Inject(optional = true)
  protected Map<CASETYPECODEEntry, EvidenceSharingStrategy> evidenceSharingStrategyMap;

  // END, CR00352039

  // BEGIN, CR00377050, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   */
  @Deprecated
  @Inject
  protected EventDispatcherFactory<curam.evidencebroker.sl.event.impl.EvidenceBrokerEvents> evidenceBrokerEvents;

  // END, CR00377050

  // BEGIN, CR00388582, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   */
  @Deprecated
  @Inject
  protected EvidenceBrokerTaskGenerationStrategy evidenceBrokerTaskGenerationStrategy;

  // END, CR00388582

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Default constructor for the class.
   */
  @Deprecated
  public EvidenceBroker() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00188098

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method determines whether a given piece of evidence is configured for
   * evidence sharing, then shares this evidence with the relevant cases.
   *
   * @param evidenceDescriptorKey The ID of the evidence to be shared.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareEvidence(final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // BEGIN, CR00207224, PB.
    // BEGIN, CR00409418, GK
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    wmInstanceDataDtls.evidenceID =
      evidenceDescriptorKey.evidenceDescriptorID;
    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkEvidenceShare);

    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(CuramConst.gkEvidenceShare,
      wmInstanceDetailsList);
    // END, CR00409418
    // END, CR00207224

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is called when a piece of evidence is removed from a case. It
   * determines whether the given piece of evidence is configured for evidence
   * sharing, then shares this evidence with the relevant cases.
   *
   * @param evidenceDescriptorKey The ID of the evidence record to be shared.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void
    shareEvidenceRemoval(final EvidenceDescriptorKey evidenceDescriptorKey)
      throws AppException, InformationalException {

    // BEGIN, CR00207224, PB.
    // BEGIN, CR00409418, GK
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    wmInstanceDataDtls.evidenceID =
      evidenceDescriptorKey.evidenceDescriptorID;
    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkEvidenceRemoval);

    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(CuramConst.gkEvidenceRemoval,
      wmInstanceDetailsList);
    // END, CR00409418
    // END, CR00207224.

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method identifies the case that this participant role has been set up
   * on. It then finds any evidence sharing configurations that are applicable
   * to this new case and shares all of the evidence relevant to this
   * participant role with the new case.
   *
   * @param caseParticipantRoleKey The ID of the new case participant role.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareEvidenceForCaseParticipantCreation(
    final CaseParticipantRoleKey caseParticipantRoleKey)
    throws AppException, InformationalException {

    // BEGIN, CR00207224, PB.
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      CaseParticipantRoleFactory.newInstance().read(caseParticipantRoleKey);

    // BEGIN, CR00409418, GK
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    // Create a new instance data record
    wmInstanceDataDtls.caseID = caseParticipantRoleDtls.caseID;
    wmInstanceDataDtls.caseParticipantRoleID =
      caseParticipantRoleKey.caseParticipantRoleID;

    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkEvidenceForCaseParticipant);

    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(
      CuramConst.gkEvidenceForCaseParticipant, wmInstanceDetailsList);
    // END, CR00409418
    // END, CR00207224

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence sharing, if configured, then shares the evidence
   * with the relevant cases.
   *
   * @param sharedEvidenceDescriptorDetails Contains evidence details received
   * from a remote system to be shared.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareExternalEvidence(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00207224, PB.
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    final BatchStreamHelper batchStreamHelper = new BatchStreamHelper();

    final Blob externalDataBlob = batchStreamHelper
      .encodeBatchParameters(sharedEvidenceDescriptorDetails);
    final curam.evidencebroker.sl.intf.ExternalEvidence externalEvidenceObj =
      curam.evidencebroker.sl.fact.ExternalEvidenceFactory.newInstance();
    final curam.evidencebroker.sl.struct.ExternalEvidenceDtls externalEvidenceDtls =
      new curam.evidencebroker.sl.struct.ExternalEvidenceDtls();

    externalEvidenceDtls.externalEvidenceID = uniqueIDObj.getNextID();
    externalEvidenceDtls.value = externalDataBlob;
    externalEvidenceObj.insert(externalEvidenceDtls);

    // BEGIN, CR00409418, GK
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    // Create a new instance data record

    wmInstanceDataDtls.evidenceID = externalEvidenceDtls.externalEvidenceID;

    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkExternalEvidenceShare);

    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(CuramConst.gkExternalEvidenceShare,
      wmInstanceDetailsList);
    // END, CR00409418.
    // END, CR00207224.

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence removal sharing, if configured, then shares
   * the evidence with the relevant cases.
   *
   * @param sharedEvidenceDescriptorDetails Contains evidence details received
   * from a remote system to be shared.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareExternalEvidenceRemoval(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00207224, PB.
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    final BatchStreamHelper batchStreamHelper = new BatchStreamHelper();

    final Blob externalDataBlob = batchStreamHelper
      .encodeBatchParameters(sharedEvidenceDescriptorDetails);
    final curam.evidencebroker.sl.intf.ExternalEvidence externalEvidenceObj =
      curam.evidencebroker.sl.fact.ExternalEvidenceFactory.newInstance();
    final curam.evidencebroker.sl.struct.ExternalEvidenceDtls externalEvidenceDtls =
      new curam.evidencebroker.sl.struct.ExternalEvidenceDtls();

    externalEvidenceDtls.externalEvidenceID = uniqueIDObj.getNextID();
    externalEvidenceDtls.value = externalDataBlob;
    externalEvidenceObj.insert(externalEvidenceDtls);

    // BEGIN, CR00409418, GK

    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    // Create a new instance data record
    wmInstanceDataDtls.evidenceID = externalEvidenceDtls.externalEvidenceID;

    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkExternalEvidenceRemoval);

    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(CuramConst.gkExternalEvidenceRemoval,
      wmInstanceDetailsList);
    // END, CR00409418
    // END, CR00207224.
  }

  // BEGIN, CR00343048, GYH

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Shares the new/updated/removed evidences with the relevant cases in bulk if
   * evidence sharing is configured for the evidences in process.
   *
   * @param evidenceLists
   * Contains the list of new/updated/removed source evidence lists.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void
    bulkEvidenceSharing(final ApplyChangesEvidenceLists evidenceLists)
      throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    if (!evidenceLists.newAndUpdateList.dtls.isEmpty()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceLists.newAndUpdateList.dtls.item(0).evidenceDescriptorID;
    }
    if (!evidenceLists.removeList.dtls.isEmpty()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceLists.removeList.dtls.item(0).evidenceDescriptorID;
    }

    final CaseKey sourceCaseKey = new CaseKey();
    final long sourceCaseID =
      evidenceDescriptorObj.read(evidenceDescriptorKey).caseID;

    sourceCaseKey.caseID = sourceCaseID;

    // BEGIN, CR00388582, SSK
    final long incomingEvidenceDataStoreID = creatEvidenceDataSource(
      EvidenceBrokerConst.kTargetIncomingEvidenceDataStore,
      EvidenceBrokerConst.kTargetIncomingEvidenceList);

    setTransactionCache(
      EvidenceBrokerConst.kIncomingEvidenceTransactionCacheDatastoreKey,
      incomingEvidenceDataStoreID, sourceCaseID);

    final long inEditEvidenceDataStoreID = creatEvidenceDataSource(
      EvidenceBrokerConst.kTargetInEditEvidenceDataStore,
      EvidenceBrokerConst.kTargetInEditEvidenceList);

    setTransactionCache(
      EvidenceBrokerConst.kInEditEvidenceTransactionCacheDatastoreKey,
      inEditEvidenceDataStoreID, sourceCaseID);
    // END, CR00388582
    // Store the target evidence details in data store
    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance()
        .openDatastore(EvidenceBrokerConst.kTargetEvidenceData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }

    final Entity evidenceSharingDetails =
      datastoreObj.newEntity(EvidenceBrokerConst.kTargetEvidenceData);

    evidenceSharingDetails.setAttribute(
      EvidenceBrokerConst.kTargetEvidenceList, CuramConst.gkEmpty);
    final long datastoreID =
      datastoreObj.addRootEntity(evidenceSharingDetails).getUniqueID();

    // BEGIN, CR00387550, SSK
    // Store the source case ID and target evidence details data store key in
    // transaction local cache which is required to capture the shared evidence
    // details in data store.
    final Cache<String, String> evidenceDataCache =
      CacheManagerEjb.getTransactionLocalCacheGroup()
        .getCache(EvidenceBrokerConst.kEvidenceTransactionCacheDatastoreKey);

    // BEGIN, CR00398028, RPB
    // disable soft references for this cache
    // (curam.cache.transaction-group.EB_DATA_CACHE.timeToIdle needs to be set
    // to 0 as well)
    final CacheConfiguration conf =
      ((ConfigurableCache<String, String>) evidenceDataCache)
        .getConfiguration();

    if (conf.getUseSoftReferences() == null || conf.getUseSoftReferences()) {
      final CacheConfiguration newConf = conf
        .cloneAndUpdate(new CacheConfiguration(null, null, 0L, 0L, false));

      ((ConfigurableCache<String, String>) evidenceDataCache)
        .configure(newConf);
    }
    // END, CR00398028
    evidenceDataCache.put(String.valueOf(sourceCaseID),
      String.valueOf(datastoreID));
    // END, CR00387550

    // BEGIN, CR00352039, PB
    // Get the final evidence sharing list from the hook
    if (null != evidenceSharingStrategyMap
      && !evidenceSharingStrategyMap.isEmpty()) {
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = sourceCaseID;
      final CaseTypeCode caseTypeCode =
        CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

      final EvidenceSharingStrategy evidenceSharingStrategy =
        evidenceSharingStrategyMap
          .get(CASETYPECODEEntry.get(caseTypeCode.caseTypeCode));

      if (null != evidenceSharingStrategy) {
        final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
          evidenceSharingStrategy.finalizeEvidenceListForSharing(
            convertListToEvDescList(evidenceLists));

        final ApplyChangesEvidenceLists applyChangesEvidenceLists =
          convertListToApplyChangesEvdList(evidenceDescriptorDtlsList);

        evidenceLists.assign(applyChangesEvidenceLists);
      }
    }
    // END, CR00352039

    final Provider<DeferredVerificationProcessBehaviour> provider =
      GuiceWrapper.getInjector()
        .getProvider(DeferredVerificationProcessBehaviour.class);

    final DeferredVerificationProcessBehaviour deferredVerificationProcessBehaviourObj =
      provider.get();

    deferredVerificationProcessBehaviourObj
      .beginDeferringVerificationEngineProcess();

    // Share the evidences
    shareEvidences(sourceCaseKey, evidenceLists);
    deferredVerificationProcessBehaviourObj
      .endDeferringVerificationEngineProcess();

    final Entity sharedEvidenceDetails = datastoreObj.readEntity(datastoreID);

    // BEGIN, CR00413936, GK
    final Boolean params[] = curam.evidencebroker.impl.EvidenceBrokerUtils
      .getCachedEvidenceBrokerParams();
    final Boolean considerAutoAcceptance = params[0];
    final Boolean considerAutoActivation = params[1];

    // END, CR00413936

    if (null != sharedEvidenceDetails) {
      final StringList evidenceDescriptorList =
        StringUtil.delimitedText2StringList(
          sharedEvidenceDetails
            .getAttribute(EvidenceBrokerConst.kTargetEvidenceList),
          CuramConst.gkPipeDelimiterChar);

      // Delete the target evidence details stored in data store as have already
      // got target evidence details to be activated.
      sharedEvidenceDetails.delete();

      // BEGIN, CR00413936, GK
      if (!evidenceDescriptorList.isEmpty() && considerAutoAcceptance
        && considerAutoActivation) {

        // Activate evidences
        activateEvidences(evidenceDescriptorList);
      }
      // END, CR00413936

    }

    generateTasks(EvidenceBrokerConst.kTargetIncomingEvidenceDataStore,
      incomingEvidenceDataStoreID,
      EvidenceBrokerConst.kTargetIncomingEvidenceList);
    generateTasks(EvidenceBrokerConst.kTargetInEditEvidenceDataStore,
      inEditEvidenceDataStoreID,
      EvidenceBrokerConst.kTargetInEditEvidenceList);

  }

  // BEGIN, CR00388582, SSK
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Generates Incoming/In-Edit tasks based on the data store name.
   *
   * @param datastoreName The name of the data store.
   *
   * @param datastoreID The unique identifier of data store.
   *
   * @param attributeName The name of the attribute name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  protected void generateTasks(final String datastoreName,
    final long datastoreID, final String attributeName)
    throws AppException, InformationalException {

    Datastore sourceEvidenceDatastore = null;

    try {
      sourceEvidenceDatastore =
        DatastoreFactory.newInstance().openDatastore(datastoreName);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }
    if (sourceEvidenceDatastore != null) {
      final Entity sharedEvidenceDetails =
        sourceEvidenceDatastore.readEntity(Long.valueOf(datastoreID));

      if (null != sharedEvidenceDetails) {
        final StringList evidenceDescriptorList =
          StringUtil.delimitedText2StringList(
            sharedEvidenceDetails.getAttribute(attributeName),
            CuramConst.gkPipeDelimiterChar);

        // Delete the target evidence details stored in data store as
        // have already
        // got target evidence details to be activated.
        sharedEvidenceDetails.delete();

        if (!evidenceDescriptorList.isEmpty()) {
          // Activate evidences
          final EvidenceDescriptor evidenceDescriptorObj =
            EvidenceDescriptorFactory.newInstance();
          CaseHeaderKey caseHeaderKey;
          CaseHeaderDtls targetCaseHeaderDtls;

          if (evidenceBrokerTaskGenerationStrategy
            .determineTaskGenerationForBulkIdenticalEvdSharing(
              evidenceDescriptorList)) {
            final Set<Long> setOfIdenticalIncomingCaseIDs =
              new HashSet<Long>();
            final Set<Long> setOfNonIdenticalIncomingCaseIDs =
              new HashSet<Long>();
            final Set<Long> setOfInEditCaseIDs = new HashSet<Long>();

            for (final String evidenceDescriptor : evidenceDescriptorList
              .items()) {
              final EvidenceDescriptorKey evidenceDescriptorKey =
                new EvidenceDescriptorKey();

              evidenceDescriptorKey.evidenceDescriptorID =
                Long.valueOf(evidenceDescriptor);
              final EvidenceDescriptorDtls evidenceDescriptorDtls =
                evidenceDescriptorObj.read(evidenceDescriptorKey);

              if (EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT
                .equals(evidenceDescriptorDtls.statusCode)) {
                if (setOfIdenticalIncomingCaseIDs
                  .add(evidenceDescriptorDtls.caseID)) {

                  caseHeaderKey = new CaseHeaderKey();
                  caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;

                  final CachedCaseHeader cachedCaseHeaderObj =
                    CachedCaseHeaderFactory.newInstance();

                  targetCaseHeaderDtls =
                    cachedCaseHeaderObj.read(caseHeaderKey);

                  processEvidenceHelper.createEvidenceSynchronizationTask(
                    targetCaseHeaderDtls, evidenceDescriptorDtls, true);

                }
              }
              if (EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT
                .equals(evidenceDescriptorDtls.statusCode)) {
                if (setOfNonIdenticalIncomingCaseIDs
                  .add(evidenceDescriptorDtls.caseID)) {

                  caseHeaderKey = new CaseHeaderKey();
                  caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;

                  final CachedCaseHeader cachedCaseHeaderObj =
                    CachedCaseHeaderFactory.newInstance();

                  targetCaseHeaderDtls =
                    cachedCaseHeaderObj.read(caseHeaderKey);
                  processEvidenceHelper.createEvidenceSynchronizationTask(
                    targetCaseHeaderDtls, evidenceDescriptorDtls, false);

                }
              }

              if (EVIDENCEDESCRIPTORSTATUS.INEDIT
                .equals(evidenceDescriptorDtls.statusCode)) {
                if (setOfInEditCaseIDs.add(evidenceDescriptorDtls.caseID)) {

                  caseHeaderKey = new CaseHeaderKey();
                  caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;

                  final CachedCaseHeader cachedCaseHeaderObj =
                    CachedCaseHeaderFactory.newInstance();

                  targetCaseHeaderDtls =
                    cachedCaseHeaderObj.read(caseHeaderKey);
                  processEvidenceHelper.createEvidenceSynchronizationTask(
                    targetCaseHeaderDtls, evidenceDescriptorDtls, true);

                }
              }
            }
          }

        }
      }
    }
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Creates a data store for the passed data store name and attribute.
   *
   * @param datastoreName
   * Name of the data store.
   *
   * @param attributeName
   * Name of data store attribute.
   *
   * @return The unique data store identifier.
   */

  @Deprecated
  protected long creatEvidenceDataSource(final String datastoreName,
    final String attributeName) {

    Datastore datastoreObj = null;

    try {
      datastoreObj =
        DatastoreFactory.newInstance().openDatastore(datastoreName);
      // EvidenceBrokerConst.kTargetIncomingEvidenceData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }

    final Entity datastoreEntity = datastoreObj.newEntity(datastoreName);

    datastoreEntity.setAttribute(attributeName, // EvidenceBrokerConst.kTargetEvidenceList,
      CuramConst.gkEmpty);
    final long datastoreID =
      datastoreObj.addRootEntity(datastoreEntity).getUniqueID();

    return datastoreID;

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Set the transaction locale cache with the data store identifier and
   * disables the soft references of the cache.
   *
   * @param cacheName
   * The name of cache.
   * @param datastoreID
   * The unique identifier of data store.
   * @param sourceCaseID
   * The source case ID.
   */
  @Deprecated
  protected void setTransactionCache(final String cacheName,
    final long datastoreID, final long sourceCaseID) {

    final Cache<String, String> evidenceDataCache =
      CacheManagerEjb.getTransactionLocalCacheGroup().getCache(cacheName);

    // disable soft references for this cache
    // (curam.cache.transaction-group.EB_DATA_CACHE.timeToIdle needs to be set
    // to 0 as well)
    final CacheConfiguration conf =
      ((ConfigurableCache<String, String>) evidenceDataCache)
        .getConfiguration();

    if (conf.getUseSoftReferences() == null || conf.getUseSoftReferences()) {
      final CacheConfiguration newConf = conf
        .cloneAndUpdate(new CacheConfiguration(null, null, 0L, 0L, false));

      ((ConfigurableCache<String, String>) evidenceDataCache)
        .configure(newConf);
    }
    evidenceDataCache.put(String.valueOf(sourceCaseID),
      String.valueOf(datastoreID));
  }

  // END, CR00388582
  // BEGIN, CR00352039, PB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Converts a list of input evidence to an EvidenceDescriptorDtlsList
   * structure.
   *
   * @param list Evidence list.
   *
   * @return evidence descriptor details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  private EvidenceDescriptorDtlsList
    convertListToEvDescList(final ApplyChangesEvidenceLists list)
      throws AppException, InformationalException {

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();

    for (final EvidenceKey evidenceKey : list.newAndUpdateList.dtls.items()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      final EvidenceDescriptorDtls dtls =
        EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

      evidenceDescriptorDtlsList.dtls.addRef(dtls);
    }

    for (final EvidenceKey evidenceKey : list.removeList.dtls.items()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      final EvidenceDescriptorDtls evidenceDescriptorDtls =
        EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

      evidenceDescriptorDtlsList.dtls.addRef(evidenceDescriptorDtls);
    }

    return evidenceDescriptorDtlsList;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Converts a EvidenceDescriptorDtlsList to an ApplyChangesEvidenceLists
   * structure.
   *
   * @param list Evidence descriptor details list.
   *
   * @return evidence list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  private ApplyChangesEvidenceLists
    convertListToApplyChangesEvdList(final EvidenceDescriptorDtlsList list)
      throws AppException, InformationalException {

    final ApplyChangesEvidenceLists applyChangesEvidenceLists =
      new ApplyChangesEvidenceLists();

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : list.dtls
      .items()) {

      // BEGIN, CR00363249, KH
      final EvidenceKey evidenceKey = new EvidenceKey();

      // END, CR00363249
      evidenceKey.correctionSetID = evidenceDescriptorDtls.correctionSetID;
      evidenceKey.evidenceDescriptorID =
        evidenceDescriptorDtls.evidenceDescriptorID;
      evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      evidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
      evidenceKey.successionID = evidenceDescriptorDtls.successionID;

      if (evidenceDescriptorDtls.statusCode
        .equals(EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode())) {

        applyChangesEvidenceLists.newAndUpdateList.dtls.add(evidenceKey);

      } else if (evidenceDescriptorDtls.statusCode
        .equals(EVIDENCEDESCRIPTORSTATUSEntry.CANCELED.getCode())) {
        applyChangesEvidenceLists.removeList.dtls.add(evidenceKey);
      }
    }
    return applyChangesEvidenceLists;
  }

  // END, CR00352039

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Shares the new/updated/removed evidences with the relevant cases in bulk if
   * evidence sharing is configured for the evidences in process.
   *
   * @param evidenceDescriptorKeyList
   * Contains the list of evidence descriptor IDs.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected void shareEvidences(final CaseKey sourceCaseKey,
    final ApplyChangesEvidenceLists evidenceLists)
    throws AppException, InformationalException {

    final EvidenceBrokerSharingStrategy evidenceBrokerSharingStrategy =
      getEvidenceBrokerSharingStrategy(CachedCaseHeaderFactory.newInstance()
        .readCaseTypeCode(sourceCaseKey).caseTypeCode);
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    // BEGIN, CR00351925, SSK
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();

    // BEGIN, CR00409201, GK
    for (final EvidenceKey evidenceKey : evidenceLists.newAndUpdateList.dtls
      .items()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      final EvidenceDescriptorDtls evidenceDescriptorDtls =
        EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

      evidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);
    }

    // BEGIN, CR00406561, SSK
    final EvidenceBrokerFilters evidenceBrokerFilters =
      new EvidenceBrokerFilters();

    final EvidenceDescriptorDtlsList filteredEvidenceDescriptorDtlsList =
      evidenceBrokerFilters.sortParentChildEvidences(processEvidenceHelper
        .filterEvidenceDescriptorDtlsList(evidenceDescriptorDtlsList));

    // END, CR00409201

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : filteredEvidenceDescriptorDtlsList.dtls) {
      // END, CR00351925
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceDescriptorDtls.evidenceDescriptorID;
      evidenceBrokerSharingStrategy.shareEvidence(evidenceDescriptorKey);
    }

    for (final EvidenceKey evidenceKey : evidenceLists.removeList.dtls
      .items()) {
      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceKey.evidenceDescriptorID;
      evidenceBrokerSharingStrategy
        .shareEvidenceRemoval(evidenceDescriptorKey);
    }

    // BEGIN, CR00377050, RPB
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = sourceCaseKey.caseID;
    evidenceBrokerEvents
      .get(curam.evidencebroker.sl.event.impl.EvidenceBrokerEvents.class)
      .postBulkEvidenceSharing(caseHeaderKey);
    // END, CR00377050
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Activates the given list of evidences.
   *
   * @param evidenceDescriptorList
   * Contains the list of evidence descriptor IDs.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00398028, RPB
  @Deprecated
  protected void activateEvidences(final StringList evidenceDescriptorList)
    throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final Map<Long, EvidenceDescriptorKeyList> caseToEvidenceMap =
      new HashMap<Long, EvidenceDescriptorKeyList>();

    for (final String evidenceDescriptor : evidenceDescriptorList.items()) {
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        Long.valueOf(evidenceDescriptor);
      final Long targetCaseID =
        evidenceDescriptorObj.read(evidenceDescriptorKey).caseID;
      final EvidenceDescriptorKeyList evidenceDescriptorKeyList;

      if (caseToEvidenceMap.containsKey(targetCaseID)) {
        evidenceDescriptorKeyList = caseToEvidenceMap.get(targetCaseID);

      } else {
        evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();
        caseToEvidenceMap.put(targetCaseID, evidenceDescriptorKeyList);
      }
      evidenceDescriptorKeyList.dtls.add(evidenceDescriptorKey);
    }

    for (final Entry<Long, EvidenceDescriptorKeyList> caseToEvidencMapEntry : caseToEvidenceMap
      .entrySet()) {
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = caseToEvidencMapEntry.getKey();
      final EvidenceDescriptorKeyList targetEvidenceDescriptorKeyList =
        caseToEvidencMapEntry.getValue();

      processEvidenceHelper.autoActivateEvidenceOnTargetCase(caseKey,
        targetEvidenceDescriptorKeyList);
    }
  }

  // END, CR00398028

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets an instance of the evidenceBrokerSharingStrategy by the source type.
   *
   * @param sourceType
   * Contains the source type of the case.
   *
   * @return An instance of evidenceBrokerSharingStrategy.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected EvidenceBrokerSharingStrategy getEvidenceBrokerSharingStrategy(
    final String sourceType) throws AppException, InformationalException {

    final EvidenceBrokerSharingStrategy evidenceBrokerSharingStrategy =
      evidenceBrokerSharingStrategyMap.get(sourceType);

    if (null == evidenceBrokerSharingStrategy) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME, sourceType,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          19);
    }
    return evidenceBrokerSharingStrategy;
  }

  // END, CR00343048

  // BEGIN, CR00350046, GYH
  // BEGIN, CR00468541, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Sets the flag 'StopEvidenceSharing' to 'true' to stop the evidence sharing
   * for the INSERT_CASE_PARTICIPANT_ROLE event type. If the broker was
   * triggered from the insertion of a Case Participant Role, the same can be
   * stopped by calling this. It also records the transaction identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  // END, CR00468541
  @Override
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public void stopSharing() throws AppException, InformationalException {

    TransactionInfo.setFacadeScopeObject(
      EvidenceBrokerConst.kStopEvidenceSharing, CuramConst.gkYes);
    TransactionInfo.setFacadeScopeObject(EvidenceBrokerConst.kTransactionID,
      TransactionInfo.getIdentifierForThisThread());
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Clears the flag 'StopEvidenceSharing' and also the recorded transaction
   * identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public void restartSharing() throws AppException, InformationalException {

    TransactionInfo.setFacadeScopeObject(
      EvidenceBrokerConst.kStopEvidenceSharing, CuramConst.gkNo);
    TransactionInfo.setFacadeScopeObject(EvidenceBrokerConst.kTransactionID,
      0);
  }

  // END, CR00350046
}
