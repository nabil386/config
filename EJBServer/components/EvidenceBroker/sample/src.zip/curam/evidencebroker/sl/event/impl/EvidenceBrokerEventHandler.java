/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2013, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.sl.event.impl;

import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.core.events.CASEPARTICIPANTROLE;
import curam.core.events.EVIDENCEBROKER;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.struct.ApplyChangesEvidenceLists;
import curam.core.sl.infrastructure.struct.EvidenceKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.NoSuchSchemaException;
import curam.events.CASE;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringList;
import java.util.ArrayList;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * This event handler listens for events that are of interest to the Evidence
 * Broker. When one of these events is raised, the handler delegates to the
 * appropriate class to allow the evidence to be shared with the relevant
 * case(s) as per the evidence broker configuration information.
 */
@Deprecated
public class EvidenceBrokerEventHandler implements EventHandler, EventFilter {

  // BEGIN, CR00114562, KH
  // BEGIN, CR00112914, CW
  // BEGIN, CR00120758, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method will be called when any event is raised which belongs to a
   * class that this handler is registered against.
   *
   * @param event The event which has been raised.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void eventRaised(final Event event)
    throws AppException, InformationalException {

    if (isEvidenceBrokerEnabled()) {

      final curam.evidencebroker.sl.intf.EvidenceBroker sharedEvidenceObj =
        curam.evidencebroker.sl.fact.EvidenceBrokerFactory.newInstance();

      if (event.eventKey.eventType
        .equals(EVIDENCEBROKER.EVIDENCEACTIVATED.eventType)) {

        // BEGIN, CR00113210, CW
        // The primaryEventData of the event is an evidenceDescriptorID
        final EvidenceDescriptorKey evidenceDescriptorKey =
          new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = event.primaryEventData;

        // BEGIN, CR00119326, KH
        sharedEvidenceObj.shareEvidence(evidenceDescriptorKey);
        // END, CR00113210, CR00119326

      } else if (event.eventKey.eventType
        .equals(EVIDENCEBROKER.EVIDENCEREMOVED.eventType)) {

        // The primaryEventData of the event is the evidenceDescriptorID
        final EvidenceDescriptorKey evidenceDescriptorKey =
          new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = event.primaryEventData;

        // BEGIN, CR00119326, KH
        sharedEvidenceObj.shareEvidenceRemoval(evidenceDescriptorKey);
        // END, CR00119326

        // BEGIN, CR00343048, GYH
      } else if (event.eventKey.eventType
        .equals(EVIDENCEBROKER.BULKEVIDENCEACTIVATED.eventType)) {
        final long datastoreID = event.primaryEventData;

        // BEGIN, CR00398028, RPB
        shareBulkEvidenceDP(datastoreID);
        // END, CR00398028
        // END, CR00343048

      } else if (event.eventKey.eventType
        .equals(CASEPARTICIPANTROLE.INSERT_CASE_PARTICIPANT_ROLE.eventType)) {

        // BEGIN, CR00350046, GYH
        // Check whether evidence sharing should be skipped or not.
        if (!stopEvidenceSharing()) {
          final CaseParticipantRoleKey cprKey = new CaseParticipantRoleKey();

          cprKey.caseParticipantRoleID = event.primaryEventData;

          final CaseParticipantRoleDtls cprDtls =
            CaseParticipantRoleFactory.newInstance().read(cprKey);

          // We will share evidence for the primary client or a new case
          // member
          if (cprDtls.typeCode.equals(CASEPARTICIPANTROLETYPE.PRIMARY)
            || cprDtls.typeCode.equals(CASEPARTICIPANTROLETYPE.MEMBER)) {
            sharedEvidenceObj.shareEvidenceForCaseParticipantCreation(cprKey);
          }
        }
        // END, CR00350046
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method checks whether the event is one that we are interested in.
   *
   * @param event The event which has been raised.
   *
   * @return <code>true</code> if this is an event that we are interested in,
   * <code>false</code> otherwise.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public boolean accept(final Event event)
    throws AppException, InformationalException {

    if (isEvidenceBrokerEnabled()) {

      // BEGIN, CR00118874, CW
      if (event.eventKey.eventClass
        .equals(EVIDENCEBROKER.EVIDENCEACTIVATED.eventClass)
        && event.eventKey.eventType
          .equals(EVIDENCEBROKER.EVIDENCEACTIVATED.eventType)) {
        // Accept evidence activation event for shared evidence
        return true;

      } else if (event.eventKey.eventClass
        .equals(EVIDENCEBROKER.EVIDENCEREMOVED.eventClass)
        && event.eventKey.eventType
          .equals(EVIDENCEBROKER.EVIDENCEREMOVED.eventType)) {
        // Accept evidence removal event for shared evidence
        return true;
      }
      // END, CR00118874
    } else if (event.eventKey.eventClass.equals(CASE.INSERT_CASE.eventClass)
      && event.eventKey.eventType.equals(CASE.INSERT_CASE.eventType)) {

      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method checks the application property to decide whether evidence
   * broker is enabled.
   *
   * @return <code>true</code> if evidence sharing is enabled,
   * <code>false</code> otherwise.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected boolean isEvidenceBrokerEnabled()
    throws AppException, InformationalException {

    String advancedEvidenceSharingEnabled = Configuration
      .getProperty(EnvVars.ENV_ADVANCED_EVIDENCE_SHARING_SHARING_ENABLED);

    if (advancedEvidenceSharingEnabled == null) {
      advancedEvidenceSharingEnabled =
        EnvVars.ENV_ADVANCED_EVIDENCE_SHARING_SHARING_ENABLED_DEFAULT;
    }

    if (advancedEvidenceSharingEnabled.equals(EnvVars.ENV_VALUE_YES)) {
      return false;
    }

    return Configuration
      .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED, Configuration
        .getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED_DEFAULT));
  }

  // END, CR00112914
  // END, CR00114562
  // END, CR00120758

  // BEGIN, CR00343048, GYH
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets the new/updated/removed source evidence details from data store
   * for the given data store identifier.
   *
   * @return The list of new/updated/removed source evidence details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected ApplyChangesEvidenceLists getEvidenceDescriptorsFromDataStore(
    final long datastoreID) throws AppException, InformationalException {

    final ApplyChangesEvidenceLists evidenceLists =
      new ApplyChangesEvidenceLists();
    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance()
        .openDatastore(GeneralConst.kEvidenceSharingData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }

    final Entity evidences = datastoreObj.readEntity(datastoreID);

    if (null != evidences) {
      final StringList newOrUpdatedEvidenceList =
        StringUtil.delimitedText2StringList(
          evidences.getAttribute(GeneralConst.kNewOrUpdatedEvidenceList),
          CuramConst.gkPipeDelimiterChar);

      EvidenceDescriptorKey evidenceDescriptorKey;
      EvidenceKey evidenceKey;
      EvidenceDescriptorDtls evidenceDescriptorDtls;
      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();

      for (final String evidenceDescriptor : newOrUpdatedEvidenceList
        .items()) {
        evidenceDescriptorKey = new EvidenceDescriptorKey();
        evidenceDescriptorKey.evidenceDescriptorID =
          Long.valueOf(evidenceDescriptor);

        evidenceDescriptorDtls =
          evidenceDescriptorObj.read(evidenceDescriptorKey);

        evidenceKey = new EvidenceKey();
        evidenceKey.evidenceDescriptorID =
          evidenceDescriptorDtls.evidenceDescriptorID;
        evidenceKey.correctionSetID = evidenceDescriptorDtls.correctionSetID;
        evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
        evidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
        evidenceLists.newAndUpdateList.dtls.add(evidenceKey);
      }

      final StringList removedEvidenceList =
        StringUtil.delimitedText2StringList(
          evidences.getAttribute(GeneralConst.kRemovedEvidenceList),
          CuramConst.gkPipeDelimiterChar);

      for (final String evidenceDescriptor : removedEvidenceList.items()) {
        evidenceDescriptorKey = new EvidenceDescriptorKey();
        evidenceDescriptorKey.evidenceDescriptorID =
          Long.valueOf(evidenceDescriptor);
        evidenceDescriptorDtls =
          evidenceDescriptorObj.read(evidenceDescriptorKey);

        evidenceKey = new EvidenceKey();
        evidenceKey.evidenceDescriptorID =
          evidenceDescriptorDtls.evidenceDescriptorID;
        evidenceKey.correctionSetID = evidenceDescriptorDtls.correctionSetID;
        evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
        evidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
        evidenceLists.removeList.dtls.add(evidenceKey);
      }
    }
    // Delete the source evidence details stored in data store as have already
    // got source evidence details to be shared.
    evidences.delete();

    return evidenceLists;
  }

  // END, CR00343048

  // BEGIN, CR00350046, GYH
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether evidence sharing should be skipped or not.
   *
   * @return <code>true</code> if evidence sharing should be skipped,
   * <code>false</code> otherwise.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected boolean stopEvidenceSharing()
    throws AppException, InformationalException {

    boolean stopEvidenceBroadcast = false;
    final Object stopEvidenceSharing = TransactionInfo
      .getFacadeScopeObject(EvidenceBrokerConst.kStopEvidenceSharing);

    if (null != stopEvidenceSharing
      && CuramConst.gkYes.equals(stopEvidenceSharing.toString())) {
      final Object transactionID = TransactionInfo
        .getFacadeScopeObject(EvidenceBrokerConst.kTransactionID);

      if (null != transactionID
        && Long.parseLong(transactionID.toString()) == TransactionInfo
          .getIdentifierForThisThread()) {
        stopEvidenceBroadcast = true;
      }
    }
    return stopEvidenceBroadcast;
  }

  // END, CR00350046

  // BEGIN, CR00397427, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method pushes the inserts the data store id information in the
   * deferred process table and triggers the same.
   *
   * @param datastoreID
   * The ID of the data store where the list of evidences is inserted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  protected void shareBulkEvidenceDP(final long datastoreID)
    throws AppException, InformationalException {

    // BEGIN, CR00409418, GK
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    wmInstanceDataDtls.evidenceID = datastoreID;

    // BEGIN, CR00426755, VT
    final Long ebPassthroughID = (Long) TransactionInfo
      .getFacadeScopeObject(GeneralConst.kEBPassthroughID);

    if (null != ebPassthroughID && CuramConst.gkZero != ebPassthroughID) {
      wmInstanceDataDtls.ebPassthroughID = ebPassthroughID.longValue();
    }
    // END, CR00426755

    // Putting the deferred process information in a facade scope object. All
    // deferred processes will be checked and consolidated in the pre commit
    // hook
    // EBDPTransactionCallBackImpl class before calling them.
    ArrayList<WMInstanceDataDtls> wmInstanceDetailsList =
      (ArrayList<WMInstanceDataDtls>) TransactionInfo
        .getFacadeScopeObject(CuramConst.gkEvidenceShareBulk);

    // If facade scope object is not yet available create one.
    if (null == wmInstanceDetailsList) {
      wmInstanceDetailsList = new ArrayList<WMInstanceDataDtls>();
    }
    wmInstanceDetailsList.add(wmInstanceDataDtls);
    TransactionInfo.setFacadeScopeObject(CuramConst.gkEvidenceShareBulk,
      wmInstanceDetailsList);
    // END, CR00409418

  }
  // END, CR00397427

}
