/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012-2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.sl.infrastructure.impl;

import com.google.inject.Inject;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEBROKEREVENTTYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.core.fact.AddressFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceDescriptorID;
import curam.core.sl.infrastructure.entity.struct.CaseIDStatusAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKeyList;
import curam.core.sl.infrastructure.impl.Evidence2Compare;
import curam.core.sl.infrastructure.impl.Evidence2CompareMap;
import curam.core.sl.infrastructure.impl.EvidenceComparisonHelper;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EvidenceAttributeDtls;
import curam.core.sl.infrastructure.struct.EvidenceComparisonData;
import curam.core.sl.infrastructure.struct.EvidenceComparisonDtls;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.sl.struct.EvidenceDescriptorDetails;
import curam.core.sl.struct.EvidenceTypeKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.struct.ExternalCaseHeaderKey;
import curam.core.struct.OtherAddressData;
import curam.evidencebroker.facade.struct.IdenticalEvidenceComparisonData;
import curam.evidencebroker.facade.struct.NonIdenticalEvidenceComparisonData;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.sl.infrastructure.struct.ColumnHighlighter;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.XMLParserCache;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 * This process class provides the functionality for the evidence broker
 * comparison widget. It supplies the information that is displayed.
 */
@Deprecated
public class EvidenceComparisonWidget extends
  curam.evidencebroker.sl.infrastructure.base.EvidenceComparisonWidget {

  // BEGIN, CR00205373, PB
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Default constructor for the class.
   */
  @Deprecated
  public EvidenceComparisonWidget() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00205373
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method returns evidence records in an XML list form for the identical
   * evidence sharing comparison view. The returned list contains the shared
   * evidence record and any active or in-edit records on the case of the same
   * evidence type as the shared evidence record.
   *
   * @param key Contains the unique identifier of the shared evidence record
   * and the unique identifier of the case onto which the record was shared.
   *
   * @return XML list representation of the evidence records for use by the
   * comparison view.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IdenticalEvidenceComparisonData getIdenticalEvidenceComparisonList(
    final CaseIDAndEvidenceDescriptorID key)
    throws AppException, InformationalException {

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;

    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = key.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidenceCaseKey.evidenceKey.evType = evidenceDescriptorDtls.evidenceType;

    final IdenticalEvidenceComparisonData identicalEvidenceComparisonData =
      new IdenticalEvidenceComparisonData();

    // Retrieve the comparison data for identical sharing view
    // BEGIN, CR00205373, PB
    identicalEvidenceComparisonData.comparisonData =
      getComparisonData(evidenceCaseKey, null, true,
        evidenceDescriptorDtls.externalSourceCaseInd).data;
    // END, CR00205373

    return identicalEvidenceComparisonData;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00205373, PB
  /**
   * @param key Contains the case identifier, evidence identifier and evidence
   * type.
   * @param targetType The type of evidence affected by the shared record
   *
   * @return XML list representation of the evidence records (of the target type
   * affected by the shared record)
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceComparisonWidget#getNonIdenticalComparisonData(EvidenceCaseKey key, EvidenceTypeKey targetType, ExternalCaseDetails externalCase)}
   * . New method
   * passes an additional parameter to indicates if the
   * source system is from external system.
   *
   * Method to return a valid XML document for the non identical evidence
   * widget.
   */
  @Deprecated
  @Override
  protected NonIdenticalEvidenceComparisonData getNonIdenticalComparisonData(
    final EvidenceCaseKey key, final EvidenceTypeKey targetType)
    throws AppException, InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Get the Evidence2Compare implementation based on the type
    final Evidence2CompareMap map =
      EvidenceController.getEvidence2CompareMap();
    final Evidence2Compare evidence2Compare =
      map.getEvidenceType(key.evidenceKey.evType);

    final EvidenceComparisonDtls primaryDtls =
      evidence2Compare.getComparisonData(key);

    Document doc = null;

    final DocumentBuilder builder = XMLParserCache.getDocumentBuilder();

    doc = builder.newDocument();

    // Insert the root element node
    final Element docEle = addNonIdenticalRootElement(key, doc);

    // Insert one column for the labels
    final Element colLabelEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    colLabelEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleColLabel);
    docEle.appendChild(colLabelEle);
    final Element colValueEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    docEle.appendChild(colValueEle);

    // <thead>
    final Element theadEle = doc.createElement(EvidenceBrokerConst.kTHead);

    docEle.appendChild(theadEle);

    // <row style="header_top">
    final Element rowAEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowAEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderA);
    theadEle.appendChild(rowAEle);

    // <entry><data></data></entry>
    // Note - Create this generically as it needs to be re-used
    final Element emptyEntry = doc.createElement(EvidenceBrokerConst.kEntry);
    final Element emptyData = doc.createElement(EvidenceBrokerConst.kData);

    emptyEntry.appendChild(emptyData);
    rowAEle.appendChild(emptyEntry);

    // get the incoming case's context description
    final String colHeader =
      BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale);

    // Get the case id for the incoming evidence
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

    final long incomingCaseID = EvidenceDescriptorFactory.newInstance()
      .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).sourceCaseID;

    final CaseIDKey caseIDKey = new CaseIDKey();

    caseIDKey.caseID = incomingCaseID;

    addColumnHeaderEntry(doc, rowAEle, colHeader, caseIDKey);
    // END, CR00122417

    // <tbody>
    final Element tbodyEle = doc.createElement(EvidenceBrokerConst.kTBody);

    docEle.appendChild(tbodyEle);

    for (int i = 0; i < primaryDtls.details.size(); i++) {

      final Element attRow =
        addParticipantNameLabel(primaryDtls.details.item(i), doc, tbodyEle);

      addParticipantNameEntry(primaryDtls.details.item(i), doc, attRow);
    } // end for i

    // "Effective Date" row
    final Element effectiveDateRow = addEffectiveDateLabel(doc, tbodyEle);

    addEffectiveDateEntry(doc, effectiveDateRow, primaryDtls);

    // "Updated By" row
    final Element updatedByRow = addUpdatedByLabel(doc, tbodyEle);

    addUpdatedByEntry(doc, updatedByRow, primaryDtls);

    // "Updated Date Time" row
    final Element updatedDateTimeRow = addUpdatedDateTimeLabel(doc, tbodyEle);

    addUpdatedDateTimeEntry(doc, updatedDateTimeRow, primaryDtls);

    // "Event" row
    final Element eventRow = addEventLabel(doc, tbodyEle);

    // <entry><data domain="SVR_STRING">Pending Removal</data></entry>
    // retrieve the Evidence Event Description code
    // For the incoming record, the event will only ever be new, updated or
    // removed. For existing, it will only be pending removal or blank.
    String eventCode = CuramConst.gkEmpty;

    if (primaryDtls.descriptor.pendingRemovalInd) {
      eventCode = EVIDENCEBROKEREVENTTYPE.REMOVAL;
    } else if (primaryDtls.descriptor.newInd) {
      eventCode = EVIDENCEBROKEREVENTTYPE.NEW;
    } else {
      eventCode = EVIDENCEBROKEREVENTTYPE.UPDATED;
    }

    addEventEntry(doc, eventRow, eventCode);

    // Convert the DOM Document to a String and return
    final StringWriter sw = convertDOMDocumentToString(doc);

    final NonIdenticalEvidenceComparisonData nonIdenticalEvidenceComparisonData =
      new NonIdenticalEvidenceComparisonData();

    nonIdenticalEvidenceComparisonData.nonIdenticalData = sw.toString();

    // Retrieve the comparison data for non identical sharing view
    nonIdenticalEvidenceComparisonData.comparisonData =
      getComparisonData(key, targetType, false).data;

    return nonIdenticalEvidenceComparisonData;
  }

  // END, CR00205373
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method returns evidence records in an XML list form for the non
   * identical evidence sharing comparison view. The returned list contains the
   * shared evidence record and any active or in-edit evidence on the case to
   * which the shared evidence may be relevant.
   *
   * @param key Contains the unique identifier of the shared evidence record
   * and the unique identifier of the case onto which the record was shared.
   * @param targetType The type of evidence affected by the shared evidence.
   *
   * @return XML list representation of the evidence records for use by the
   * comparison view.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public NonIdenticalEvidenceComparisonData
    getNonIdenticalEvidenceComparisonList(
      final CaseIDAndEvidenceDescriptorID key,
      final EvidenceTypeKey targetType)
      throws AppException, InformationalException {

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;

    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = key.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidenceCaseKey.evidenceKey.evType = evidenceDescriptorDtls.evidenceType;
    // BEGIN, CR00205373, PB
    return getNonIdenticalComparisonData(evidenceCaseKey, targetType,
      evidenceDescriptorDtls.externalSourceCaseInd);
    // END, CR00205373
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method takes in an evidence id and type for a shared evidence record
   * and retrieves a list of existing case evidence to compare the record
   * with.
   *
   * @param key Contains the case id, evidence id and type.
   * @param targetType The type of evidence affected by the shared evidence
   * record.
   * @param identical Indicator to determine whether to display the record
   * identified by the key.
   *
   * @return List of evidenceID / type pairs.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  protected EIEvidenceKeyList getRecordsToCompare(final EvidenceCaseKey key,
    final EvidenceTypeKey targetType, final boolean identical)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    // If identical widget, add the shared record to the start of the list
    if (identical) {
      final EIEvidenceKey sharedKey = new EIEvidenceKey();

      sharedKey.evidenceID = key.evidenceKey.evidenceID;
      sharedKey.evidenceType = key.evidenceKey.evType;
      eiEvidenceKeyList.dtls.addRef(sharedKey);
    }

    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

    // Get the correctionSetID for this shared evidence record
    String sharedCorrectionSetID = CuramConst.gkEmpty;

    if (identical) {
      sharedCorrectionSetID = evidenceDescriptorObj
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).correctionSetID;
    }

    // Get a list of active and in edit records
    final CaseIDStatusAndEvidenceTypeKey caseIDStatusAndEvidenceTypeKey =
      new CaseIDStatusAndEvidenceTypeKey();

    caseIDStatusAndEvidenceTypeKey.caseID = key.caseIDKey.caseID;

    if (identical) {
      caseIDStatusAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;
    } else {
      caseIDStatusAndEvidenceTypeKey.evidenceType = targetType.evidenceType;
    }

    caseIDStatusAndEvidenceTypeKey.statusCode =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    final RelatedIDAndEvidenceTypeKeyList activeList = evidenceDescriptorObj
      .searchByCaseIDTypeAndStatus(caseIDStatusAndEvidenceTypeKey);

    caseIDStatusAndEvidenceTypeKey.statusCode =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;

    final RelatedIDAndEvidenceTypeKeyList inEditList = evidenceDescriptorObj
      .searchByCaseIDTypeAndStatus(caseIDStatusAndEvidenceTypeKey);

    // Add the active record whose correctionSetID matches the shared record
    RelatedIDAndEvidenceTypeKey relatedKey = null;

    if (identical) {

      relatedKey = new RelatedIDAndEvidenceTypeKey();
      relatedKey.evidenceType = key.evidenceKey.evType;

      for (final Object currentObj : activeList.dtls) {

        final RelatedIDAndEvidenceTypeKey currentRecord =
          (RelatedIDAndEvidenceTypeKey) currentObj;

        // Get the descriptor for this evidence record
        relatedKey.relatedID = currentRecord.relatedID;

        final String activeCorrectionSetID = evidenceDescriptorObj
          .readByRelatedIDAndType(relatedKey).correctionSetID;

        if (activeCorrectionSetID.equals(sharedCorrectionSetID)) {

          final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

          eiEvidenceKey.evidenceType = key.evidenceKey.evType;
          eiEvidenceKey.evidenceID = currentRecord.relatedID;

          eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
          activeList.dtls.remove(currentRecord);
          break;
        }
      }
    }

    // Add the in edit record whose correctionSetID matches the shared record
    if (identical) {

      for (final Object currentObj : inEditList.dtls) {

        final RelatedIDAndEvidenceTypeKey currentRecord =
          (RelatedIDAndEvidenceTypeKey) currentObj;

        // Get the descriptor for this evidence record
        relatedKey.relatedID = currentRecord.relatedID;

        final String inEditCorrectionSetID = evidenceDescriptorObj
          .readByRelatedIDAndType(relatedKey).correctionSetID;

        if (inEditCorrectionSetID.equals(sharedCorrectionSetID)) {

          final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

          eiEvidenceKey.evidenceType = key.evidenceKey.evType;
          eiEvidenceKey.evidenceID = currentRecord.relatedID;

          eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
          inEditList.dtls.remove(currentRecord);
          break;
        }
      }
    }

    // Add all remaining active records
    for (final Object currentObj : activeList.dtls) {

      final RelatedIDAndEvidenceTypeKey currentRecord =
        (RelatedIDAndEvidenceTypeKey) currentObj;

      final EIEvidenceKey activeKey = new EIEvidenceKey();

      activeKey.evidenceType = key.evidenceKey.evType;
      activeKey.evidenceID = currentRecord.relatedID;

      eiEvidenceKeyList.dtls.addRef(activeKey);
    }

    // Add all remaining in edit records
    for (final Object currentObj : inEditList.dtls) {

      final RelatedIDAndEvidenceTypeKey currentRecord =
        (RelatedIDAndEvidenceTypeKey) currentObj;

      final EIEvidenceKey inEditKey = new EIEvidenceKey();

      inEditKey.evidenceType = key.evidenceKey.evType;
      inEditKey.evidenceID = currentRecord.relatedID;

      eiEvidenceKeyList.dtls.addRef(inEditKey);
    }

    return eiEvidenceKeyList;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00205373, PB
  /**
   * @param key Contains the existing case identifier, incoming evidence
   * identifier and evidence type.
   * @param targetType The type of evidence affected by the incoming evidence
   * record
   * @param identical Indicator to determine whether to display the record
   * identified by the key.
   *
   * @return XML representation of the evidence comparison table.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceComparisonWidget#getComparisonData(EvidenceCaseKey key, EvidenceTypeKey targetType, boolean identical, boolean externalCaseInd)}
   * . New method
   * passes an additional parameter to indicates if the
   * source system is from external system.
   *
   * Method to return a valid XML document for the evidence comparison widget,
   * comparing a shared evidence record with existing records of the same
   * or related type on the same case.
   */
  @Deprecated
  @Override
  protected EvidenceComparisonData getComparisonData(
    final EvidenceCaseKey key, final EvidenceTypeKey targetType,
    final boolean identical) throws AppException, InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Get the Evidence2Compare implementation based on the type
    final Evidence2CompareMap map =
      EvidenceController.getEvidence2CompareMap();
    Evidence2Compare evidence2Compare = null;

    if (identical) {
      evidence2Compare = map.getEvidenceType(key.evidenceKey.evType);
    } else {
      evidence2Compare = map.getEvidenceType(targetType.evidenceType);
    }

    // Create a collection of merge data for all the records
    final ArrayList<EvidenceComparisonDtls> recordsToCompare =
      new ArrayList<EvidenceComparisonDtls>();

    final EIEvidenceKey[] eiEvidenceKeyList =
      getRecordsToCompare(key, targetType, identical).dtls.items();

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey = key.caseIDKey;

    for (final EIEvidenceKey eiEvidenceKey : eiEvidenceKeyList) {
      evidenceCaseKey.evidenceKey.evidenceID = eiEvidenceKey.evidenceID;
      evidenceCaseKey.evidenceKey.evType = eiEvidenceKey.evidenceType;
      recordsToCompare
        .add(evidence2Compare.getComparisonData(evidenceCaseKey));
    }

    recordsToCompare.trimToSize();

    // Used to display an information message and highlight the relevant column
    String message = CuramConst.gkEmpty;
    int highlightIndex = -1;

    // The information message is only used when comparing identical evidence
    if (identical) {
      final ColumnHighlighter columnHighlighter =
        checkForWidgetInformationals(recordsToCompare);

      message = columnHighlighter.displayMessage;
      highlightIndex = (int) columnHighlighter.highlightIndex;
    }

    int numAttributeRows = 0;
    final int numEvidenceCols = recordsToCompare.size();

    if (numEvidenceCols > 0) {
      numAttributeRows = recordsToCompare.get(0).details.size();
    }

    Document doc = null;

    final DocumentBuilder builder = XMLParserCache.getDocumentBuilder();

    doc = builder.newDocument();

    // Insert the root element node
    final Element docEle =
      addComparisonRootElement(key, targetType, identical, doc);

    final Element msgTxtEle =
      doc.createElement(EvidenceBrokerConst.kMessageText);

    docEle.appendChild(msgTxtEle);

    if (!message.equals(CuramConst.gkEmpty)) {
      msgTxtEle.appendChild(doc.createTextNode(message));
    }

    //
    // Define columns
    //

    // insert one column for the labels
    final Element colLabelEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    colLabelEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleColLabel);
    docEle.appendChild(colLabelEle);

    // insert one column for each compared record
    for (int i = 0; i < numEvidenceCols; i++) {

      final Element colEle = doc.createElement(EvidenceBrokerConst.kColSpec);

      docEle.appendChild(colEle);

      if (identical) {
        if (i == 0) {
          // style="shared_evidence"
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColShared);
        }

        if (highlightIndex != -1 && i == highlightIndex) {
          // END, CR00122183
          // If this record has the same correction set ID as the incoming
          // record then an "highlight" style needs to be set.
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColHighlight);
        }
      }
    } // end for i

    if (identical && numEvidenceCols < 2) {
      docEle.appendChild(doc.createElement(EvidenceBrokerConst.kColSpec));
    }

    // <thead>
    final Element theadEle = doc.createElement(EvidenceBrokerConst.kTHead);

    docEle.appendChild(theadEle);

    // <row style="header_top">
    final Element rowAEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowAEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderA);
    theadEle.appendChild(rowAEle);

    // <entry><data></data></entry>
    // Note - Create this generically as it needs to be re-used
    final Element emptyEntry = doc.createElement(EvidenceBrokerConst.kEntry);
    final Element emptyData = doc.createElement(EvidenceBrokerConst.kData);

    emptyEntry.appendChild(emptyData);
    rowAEle.appendChild(emptyEntry);

    final CaseIDKey caseIDKey = new CaseIDKey();

    if (identical) {

      // Get the case id for the incoming evidence
      final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
        new RelatedIDAndEvidenceTypeKey();

      relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
      relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

      final long incomingCaseID = EvidenceDescriptorFactory.newInstance()
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).sourceCaseID;

      // Set the incoming case's context description
      final String incomingContext =
        BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale);

      caseIDKey.caseID = incomingCaseID;
      addColumnHeaderEntry(doc, rowAEle, incomingContext, caseIDKey);
    }

    if (identical || !identical && numEvidenceCols > 0) {
      // END, CR00121087

      // Set the existing case's context description
      final String existingContext =
        BPOEVIDENCEBROKER.INF_LABEL_EXISTING.getMessageText(locale);

      caseIDKey.caseID = key.caseIDKey.caseID;
      addColumnHeaderEntry(doc, rowAEle, existingContext, caseIDKey);
    }

    // <row style="header_bottom">
    final Element rowBEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowBEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderB);
    theadEle.appendChild(rowBEle);

    // insert one empty cell above the labels
    // <entry><data></data></entry>
    final Node emptyCell = emptyEntry.cloneNode(true);

    rowBEle.appendChild(emptyCell);

    // insert one column header for each compared record
    // <entry><data domain="EVIDENCE_DESCRIPTOR_STATUS">EDS2</data></entry>
    for (int i = 0; i < recordsToCompare.size(); i++) {

      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

      final String status = currentRecord.descriptor.statusCode;

      // blank out the incoming, shared record's status
      if (identical && i == 0) {
        rowBEle.appendChild(emptyEntry.cloneNode(true));
      } else {
        addEvidenceStatusEntry(doc, rowBEle, status);
      }
    }
    if (identical && numEvidenceCols < 2) {
      rowBEle.appendChild(emptyEntry.cloneNode(true));
    }

    // <tbody>
    final Element tbodyEle = doc.createElement(EvidenceBrokerConst.kTBody);

    docEle.appendChild(tbodyEle);

    for (int i = 0; i < numAttributeRows; i++) {

      final Element attRow = addParticipantNameLabel(
        recordsToCompare.get(0).details.item(i), doc, tbodyEle);

      for (final Object currentObj : recordsToCompare) {
        final EvidenceComparisonDtls evidenceDtls =
          (EvidenceComparisonDtls) currentObj;

        addParticipantNameEntry(evidenceDtls.details.item(i), doc, attRow);
      }
      if (identical && numEvidenceCols < 2) {
        attRow.appendChild(emptyEntry.cloneNode(true));
      }
    } // end for i

    // "Effective Date" row
    final Element effectiveDateRow = addEffectiveDateLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addEffectiveDateEntry(doc, effectiveDateRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      effectiveDateRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Updated By" row
    final Element updatedByRow = addUpdatedByLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedByEntry(doc, updatedByRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedByRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Updated Date Time" row
    final Element updatedDateTimeRow = addUpdatedDateTimeLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedDateTimeEntry(doc, updatedDateTimeRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedDateTimeRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Event" row
    final Element eventRow = addEventLabel(doc, tbodyEle);

    // <entry><data domain="SVR_STRING">Pending Removal</data></entry>
    for (int i = 0; i < recordsToCompare.size(); i++) {

      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

      // retrieve the Evidence Event Description code
      // For the incoming record, the event will only ever be new, updated or
      // removed. For existing, it will only be pending removal or blank.
      String eventCode = CuramConst.gkEmpty;

      if (identical && i == 0) {
        if (currentRecord.descriptor.pendingRemovalInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.REMOVAL;
        } else if (currentRecord.descriptor.newInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.NEW;
        } else {
          eventCode = EVIDENCEBROKEREVENTTYPE.UPDATED;
        }
      } else if (currentRecord.descriptor.pendingRemovalInd) {
        eventCode = EVIDENCEBROKEREVENTTYPE.PENDINGREMOVAL;
      }

      addEventEntry(doc, eventRow, eventCode);
    }

    if (identical && numEvidenceCols < 2) {
      eventRow.appendChild(emptyEntry.cloneNode(true));
    }

    // Convert the DOM Document to a String and return
    final StringWriter sw = convertDOMDocumentToString(doc);

    final EvidenceComparisonData evidenceComparisonData =
      new EvidenceComparisonData();

    evidenceComparisonData.data = sw.toString();

    return evidenceComparisonData;
  }

  // END, CR00205373
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the non identical root element to the XML document.
   *
   * @param key Contains the case id, evidence id and type.
   * @param doc The XML document for display by the evidence comparison widget.
   *
   * @return The non identical root element.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addNonIdenticalRootElement(final EvidenceCaseKey key,
    final Document doc)
    throws AppException, InformationalException, DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // Insert the root element node
    // <list style="horizontal-list-body-layout" title="My Custom Evidence">
    final Element docEle = doc.createElement(EvidenceBrokerConst.kList);

    doc.appendChild(docEle);

    // Insert a comment in front of the element node
    // <!-- represents incoming shared evidence details -->
    final Comment comment =
      doc.createComment(EvidenceBrokerConst.kComparisonText);

    doc.insertBefore(comment, docEle);

    docEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleList);

    final String title =
      BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale)
        + CuramConst.gkSpace
        + BPOEVIDENCEBROKER.INF_LABEL_EVIDENCE.getMessageText(locale)
        + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
        + CodeTable.getOneItemForUserLocale(CASEEVIDENCE.TABLENAME,
          key.evidenceKey.evType);

    final Element titleEle = doc.createElement(EvidenceBrokerConst.kTitle);

    docEle.appendChild(titleEle);
    final Element dataEle = doc.createElement(EvidenceBrokerConst.kData);

    dataEle.setTextContent(title);
    titleEle.appendChild(dataEle);

    final Element msgTxtEle =
      doc.createElement(EvidenceBrokerConst.kMessageText);

    docEle.appendChild(msgTxtEle);

    return docEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the comparison root element to the XML document.
   *
   * @param key Contains the case id, evidence id and type.
   * @param targetType The type of evidence affected by the incoming evidence
   * record.
   * @param identical Contains <code>true</code> if this is an identical shared
   * evidence record, <code>false</code> otherwise.
   * @param doc The XML document for display by the evidence comparison widget.
   *
   * @return The comparison root element.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addComparisonRootElement(final EvidenceCaseKey key,
    final EvidenceTypeKey targetType, final boolean identical,
    final Document doc)
    throws AppException, InformationalException, DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // Insert the root element node
    // <list style="horizontal-list-body-layout" title="My Custom Evidence">
    final Element docEle = doc.createElement(EvidenceBrokerConst.kList);

    doc.appendChild(docEle);

    // Insert a comment in front of the element node
    // <!-- represents a comparison chart of evidence details -->
    final Comment comment =
      doc.createComment(EvidenceBrokerConst.kComparisonText);

    doc.insertBefore(comment, docEle);

    docEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleList);

    String title = CuramConst.gkEmpty;

    if (!identical) {
      title = BPOEVIDENCEBROKER.INF_LABEL_AFFECTED_BY.getMessageText(locale)
        + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace;
    }

    if (identical) {
      title += CodeTable.getOneItemForUserLocale(CASEEVIDENCE.TABLENAME,
        key.evidenceKey.evType);
    } else {
      title += CodeTable.getOneItemForUserLocale(CASEEVIDENCE.TABLENAME,
        targetType.evidenceType);
    }

    final Element titleEle = doc.createElement(EvidenceBrokerConst.kTitle);

    docEle.appendChild(titleEle);
    final Element dataEle = doc.createElement(EvidenceBrokerConst.kData);

    dataEle.setTextContent(title);
    titleEle.appendChild(dataEle);
    // END, CR00121871
    return docEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method examines the evidence records on the case and determines which
   * information message, if any, will be display by the compare widget. it also
   * identifies the specific evidence column associated with the message so that
   * it can be highlighted by the widget of necessary.
   *
   * @param recordsToCompare The list of evidence to be compared.
   *
   * @return Information about the column affected by the incoming evidence.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected ColumnHighlighter checkForWidgetInformationals(
    final ArrayList<EvidenceComparisonDtls> recordsToCompare)
    throws AppException, InformationalException, DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // Find the index of the record the same correctionSetID. This is needed
    // to correctly set the column style later. However if there are two records
    // with the same correction set id (i.e. For an Active and In Edit record)
    // then no highlighting is set.
    // BEGIN, CR00122183, CD
    int activeHighlightIndex = 0;
    int inEditHighlightIndex = 0;

    final EvidenceDescriptorDetails incomingRecord =
      recordsToCompare.get(0).descriptor;

    // BEGIN, CR00121090, ELG
    // check that there are two records to compare for identical
    // evidence sharing
    String noExistingEvidenceMessage = CuramConst.gkEmpty;

    if (recordsToCompare.size() <= 1) {
      noExistingEvidenceMessage =
        BPOEVIDENCEBROKER.INF_MESSAGE_NO_EVIDENCE_TO_COMPARE_TO
          .getMessageText(locale);
    }
    // END, CR00121090

    // check for existence of an active record
    String activeMsg = CuramConst.gkEmpty;

    for (int i = 1; i < recordsToCompare.size(); i++) {

      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

      // if there are any previous pending operations, no message to be
      // displayed i.e. If the existing active record is pendingUpdate
      // or pendingRemoval !recordsToCompare.get(i).descriptor.
      // pendingRemovalInd && !recordsToCompare.get(i).descriptor.
      // pendingUpdateInd && look for superseded or removed conditions
      if (currentRecord.descriptor.statusCode
        .equals(EVIDENCEDESCRIPTORSTATUS.ACTIVE)
        // BEGIN, CR00122858, CW
        && !currentRecord.descriptor.pendingUpdateInd
        // END, CR00122858
        && incomingRecord.sharedInstanceID == recordsToCompare
          .get(i).descriptor.sharedInstanceID
        && incomingRecord.correctionSetID
          .equals(recordsToCompare.get(i).descriptor.correctionSetID)
        && incomingRecord.effectiveFrom
          .equals(recordsToCompare.get(i).descriptor.effectiveFrom)) {
        if (incomingRecord.pendingRemovalInd) {
          activeMsg =
            BPOEVIDENCEBROKER.INF_MESSAGE_REMOVED.getMessageText(locale);
          activeHighlightIndex = i;
          break;
        } else {
          activeMsg =
            BPOEVIDENCEBROKER.INF_MESSAGE_SUPERSEDE.getMessageText(locale);
          activeHighlightIndex = i;
          break;
        }
      }
    } // end for i

    // check for existence of an in edit record
    String inEditMsg = CuramConst.gkEmpty;

    for (int i = 1; i < recordsToCompare.size(); i++) {

      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

      if (currentRecord.descriptor.statusCode
        .equals(EVIDENCEDESCRIPTORSTATUS.INEDIT)
        && incomingRecord.sharedInstanceID == recordsToCompare
          .get(i).descriptor.sharedInstanceID
        && incomingRecord.effectiveFrom
          .equals(recordsToCompare.get(i).descriptor.effectiveFrom)) {

        if (incomingRecord.pendingRemovalInd) {
          inEditMsg =
            BPOEVIDENCEBROKER.INF_MESSAGE_DISCARDED.getMessageText(locale);
          inEditHighlightIndex = i;
          break;
        }
      }
    } // end for i

    // Used to identify which column (if any) will be highlighted by the widget
    final ColumnHighlighter highlighter = new ColumnHighlighter();

    highlighter.highlightIndex = -1;

    // mutually exclusive
    if (activeMsg.equals(CuramConst.gkEmpty)
      && !inEditMsg.equals(CuramConst.gkEmpty)) {
      highlighter.displayMessage = inEditMsg;
      highlighter.highlightIndex = inEditHighlightIndex;
    } else if (!activeMsg.equals(CuramConst.gkEmpty)
      && inEditMsg.equals(CuramConst.gkEmpty)) {
      highlighter.displayMessage = activeMsg;
      highlighter.highlightIndex = activeHighlightIndex;
      // BEGIN, CR00121090, ELG
    } else if (activeMsg.equals(CuramConst.gkEmpty)
      && inEditMsg.equals(CuramConst.gkEmpty)
      && !noExistingEvidenceMessage.equals(CuramConst.gkEmpty)) {
      highlighter.displayMessage = noExistingEvidenceMessage;
    }
    // END, CR00121090

    return highlighter;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00205373, PB
  /**
   * @param doc The XML document for display by the evidence comparison widget.
   * @param headerEle The column header element of the XML document.
   * @param context The context description to be included in the column header.
   * @param caseIDKey Contains the case ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws DOMException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceComparisonWidget#addColumnHeaderEntry(Document doc, Element headerEle, String context, CaseIDKey caseIDKey, boolean externalCase)
   * )}. New method
   * passes an additional parameter to indicates if the
   * source system is from external system.
   *
   * This method adds the column header to the XML document.
   */
  @Deprecated
  protected void addColumnHeaderEntry(final Document doc,
    final Element headerEle, String context, final CaseIDKey caseIDKey)
    throws AppException, InformationalException, DOMException {

    // Read the product name and case reference
    final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName =
      MaintainCaseFactory.newInstance()
        .readCaseReferenceConcernRoleNameProductNameByCaseID(caseIDKey);

    context =
      context + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
        + caseReferenceProductNameConcernRoleName.productName
        + CuramConst.gkSpace
        + caseReferenceProductNameConcernRoleName.caseReference;

    // <entry><data domain="SVR_STRING">
    // context - <Case Name> <Case ID>
    // </data></entry>
    final Element rowAEntry2Ele =
      doc.createElement(EvidenceBrokerConst.kEntry);

    headerEle.appendChild(rowAEntry2Ele);

    final Element rowAEntry2DataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    rowAEntry2Ele.appendChild(rowAEntry2DataEle);
    rowAEntry2DataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    rowAEntry2DataEle.appendChild(doc.createTextNode(context));
  }

  // END, CR00205373
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the participant name label to the XML document.
   *
   * @param dtls The evidence attribute details.
   * @param doc The XML document for display by the evidence comparison widget.
   * @param tbodyEle The tbody element of the XML document.
   *
   * @return The participant name element.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addParticipantNameLabel(final EvidenceAttributeDtls dtls,
    final Document doc, final Element tbodyEle) throws DOMException {

    // <entry><data domain="SVR_STRING">Name</data></entry>
    final Element attRow = doc.createElement(EvidenceBrokerConst.kRow);

    tbodyEle.appendChild(attRow);

    final Element attLabelEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    attRow.appendChild(attLabelEntryEle);

    final Element attLabelEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    attLabelEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    attLabelEntryRowDataEle.appendChild(doc.createTextNode(dtls.label));
    attLabelEntryEle.appendChild(attLabelEntryRowDataEle);

    return attRow;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the participant name data to the XML document.
   *
   * @param dtls The evidence attribute details.
   * @param doc The XML document for display by the evidence comparison widget.
   * @param nameEle The participant name element of the XML document.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addParticipantNameEntry(final EvidenceAttributeDtls dtls,
    final Document doc, final Element nameEle) throws DOMException {

    // <entry><data domain="SVR_STRING">Pat</data></entry>
    final Element attValueEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    nameEle.appendChild(attValueEntryEle);

    final Element attValueEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    // BEGIN, CR00434151, ZV
    if (dtls.domain.equals(CuramConst.kDomainADDRESS_DATA)) {
      dtls.domain = CuramConst.kDomainSVR_STRING;

      final Address addressObj = AddressFactory.newInstance();
      final OtherAddressData otherAddressData = new OtherAddressData();
      OtherAddressData formattedAddress = new OtherAddressData();

      otherAddressData.addressData = dtls.value;
      try {
        formattedAddress = addressObj.getShortFormat(otherAddressData);
      } catch (final AppException e) {// No address details found. Display empty
        // string
      } catch (final InformationalException e) {// No address details found.
        // Display
        // empty string
      }
      attValueEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
        dtls.domain);
      attValueEntryRowDataEle
        .appendChild(doc.createTextNode(formattedAddress.addressData));
      attValueEntryEle.appendChild(attValueEntryRowDataEle);
    } else {
      attValueEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
        dtls.domain);
      attValueEntryRowDataEle.appendChild(doc.createTextNode(dtls.value));
      attValueEntryEle.appendChild(attValueEntryRowDataEle);
    }
    // END, CR00434151
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the evidence descriptor status data to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param statusEle The descriptor status element of the XML document.
   * @param status Contains the evidence data.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addEvidenceStatusEntry(final Document doc,
    final Element statusEle, final String status) throws DOMException {

    final Element rowBEntryNEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    statusEle.appendChild(rowBEntryNEle);

    final Element rowBEntryNDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    rowBEntryNDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      EvidenceBrokerConst.kDomainEVIDENCE_DESCRIPTOR_STATUS);
    rowBEntryNDataEle.appendChild(doc.createTextNode(status));
    rowBEntryNEle.appendChild(rowBEntryNDataEle);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the effective date label to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param tbodyEle The tbody element of the XML document.
   *
   * @return The effective date element of the XML document.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addEffectiveDateLabel(final Document doc,
    final Element tbodyEle) throws DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // <row style="top_border">
    final Element effectiveDateEle =
      doc.createElement(EvidenceBrokerConst.kRow);

    effectiveDateEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowTopBorder);
    tbodyEle.appendChild(effectiveDateEle);

    // <entry><data domain="SVR_STRING">Effective Date</data></entry>
    final Element effectiveDateLabelEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    effectiveDateEle.appendChild(effectiveDateLabelEntryEle);

    final Element effectiveFromLabelEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    effectiveFromLabelEntryRowDataEle.setAttribute(
      EvidenceBrokerConst.kDomain, CuramConst.kDomainSVR_STRING);
    effectiveFromLabelEntryRowDataEle.appendChild(doc.createTextNode(
      BPOEVIDENCEBROKER.INF_LABEL_EFFECTIVE_FROM.getMessageText(locale)));
    effectiveDateLabelEntryEle.appendChild(effectiveFromLabelEntryRowDataEle);

    return effectiveDateEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the effective date data to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param effectiveDateEle The effective date element of the XML document.
   * @param evidence Contains the evidence data.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addEffectiveDateEntry(final Document doc,
    final Element effectiveDateEle, final EvidenceComparisonDtls evidence)
    throws DOMException {

    // <entry><data domain="SVR_DATE">00010101</data></entry>
    final Element effectiveDateValueEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    effectiveDateEle.appendChild(effectiveDateValueEntryEle);

    final EvidenceComparisonHelper evidenceComparisonHelper =
      new EvidenceComparisonHelper();
    final String effectiveFrom = evidenceComparisonHelper
      .objectToString(evidence.descriptor.effectiveFrom);

    final Element effectiveFromValueEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    effectiveFromValueEntryRowDataEle.setAttribute(
      EvidenceBrokerConst.kDomain, EvidenceBrokerConst.kDomainSVR_DATE);
    effectiveFromValueEntryRowDataEle
      .appendChild(doc.createTextNode(effectiveFrom));
    effectiveDateValueEntryEle.appendChild(effectiveFromValueEntryRowDataEle);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the updated by label to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param tbodyEle The tbody element of the XML document.
   *
   * @return The updated by element of the XML document.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addUpdatedByLabel(final Document doc,
    final Element tbodyEle) throws DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // <row>
    final Element updatedByEle = doc.createElement(EvidenceBrokerConst.kRow);

    tbodyEle.appendChild(updatedByEle);

    // <entry><data domain="SVR_STRING">Updated By</data></entry>
    final Element updatedByLabelEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    updatedByEle.appendChild(updatedByLabelEntryEle);

    final Element updatedByLabelEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    updatedByLabelEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    updatedByLabelEntryRowDataEle.appendChild(doc.createTextNode(
      BPOEVIDENCEBROKER.INF_LABEL_UPDATED_BY.getMessageText(locale)));
    updatedByLabelEntryEle.appendChild(updatedByLabelEntryRowDataEle);
    return updatedByEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the updated by data to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param updatedByEle The updated by element of the XML document.
   * @param evidence Contains the evidence data.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addUpdatedByEntry(final Document doc,
    final Element updatedByEle, final EvidenceComparisonDtls evidence)
    throws DOMException {

    // <entry><data domain="SVR_STRING">Mary Malone</data></entry>
    final Element updatedByValueEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    updatedByEle.appendChild(updatedByValueEntryEle);

    final Element updatedByValueEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    updatedByValueEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    updatedByValueEntryRowDataEle
      .appendChild(doc.createTextNode(evidence.descriptor.updatedBy));
    updatedByValueEntryEle.appendChild(updatedByValueEntryRowDataEle);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the updated date time label to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param tbodyEle The tbody element of the XML document.
   *
   * @return The updated date time element of the XML document.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addUpdatedDateTimeLabel(final Document doc,
    final Element tbodyEle) throws DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // <row>
    final Element updatedDateTimeEle =
      doc.createElement(EvidenceBrokerConst.kRow);

    tbodyEle.appendChild(updatedDateTimeEle);

    // <entry><data domain="SVR_STRING">Updated Date Time</data></entry>
    final Element updatedDateTimeLabelEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    updatedDateTimeEle.appendChild(updatedDateTimeLabelEntryEle);

    final Element updatedDateTimeLabelEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    updatedDateTimeLabelEntryRowDataEle.setAttribute(
      EvidenceBrokerConst.kDomain, CuramConst.kDomainSVR_STRING);
    updatedDateTimeLabelEntryRowDataEle.appendChild(doc.createTextNode(
      BPOEVIDENCEBROKER.INF_LABEL_UPDATED_DATE_TIME.getMessageText(locale)));
    updatedDateTimeLabelEntryEle
      .appendChild(updatedDateTimeLabelEntryRowDataEle);

    return updatedDateTimeEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the updated date time data to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param updatedDateTimeEle The updated date time element of the XML
   * document.
   * @param evidence Contains the evidence data.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addUpdatedDateTimeEntry(final Document doc,
    final Element updatedDateTimeEle, final EvidenceComparisonDtls evidence)
    throws DOMException {

    // <entry><data domain="SVR_DATETIME">20051010T101010</data></entry>
    final SimpleDateFormat iso8601 =
      new SimpleDateFormat(EvidenceBrokerConst.kISO8601Date);

    final java.util.Date javaDate =
      evidence.descriptor.updatedDateTime.getCalendar().getTime();
    final String dateTime = iso8601.format(javaDate);

    final Element updatedDateTimeValueEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    updatedDateTimeEle.appendChild(updatedDateTimeValueEntryEle);

    final Element updatedDateTimeValueEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    updatedDateTimeValueEntryRowDataEle.setAttribute(
      EvidenceBrokerConst.kDomain, EvidenceBrokerConst.kDomainSVR_DATETIME);
    updatedDateTimeValueEntryRowDataEle
      .appendChild(doc.createTextNode(dateTime));
    updatedDateTimeValueEntryEle
      .appendChild(updatedDateTimeValueEntryRowDataEle);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the event label to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param tbodyEle The tbody element of the XML document.
   *
   * @return The event element of the XML document.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected Element addEventLabel(final Document doc, final Element tbodyEle)
    throws DOMException {

    final String locale = TransactionInfo.getProgramLocale();

    // <row>
    final Element eventEle = doc.createElement(EvidenceBrokerConst.kRow);

    tbodyEle.appendChild(eventEle);

    // <entry><data domain="SVR_STRING">Event</data></entry>
    final Element eventLabelEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    eventEle.appendChild(eventLabelEntryEle);

    final Element eventLabelEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    eventLabelEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    eventLabelEntryRowDataEle.appendChild(doc.createTextNode(
      BPOEVIDENCEBROKER.INF_LABEL_EVENT.getMessageText(locale)));
    eventLabelEntryEle.appendChild(eventLabelEntryRowDataEle);

    return eventEle;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This method adds the event data to the XML document.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   * @param eventEle The event element of the XML document.
   * @param eventCode The event type related to the incoming shared evidence.
   *
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addEventEntry(final Document doc, final Element eventEle,
    final String eventCode) throws DOMException {

    final Element eventValueEntryEle =
      doc.createElement(EvidenceBrokerConst.kEntry);

    eventEle.appendChild(eventValueEntryEle);

    final Element eventValueEntryRowDataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    eventValueEntryRowDataEle.setAttribute(EvidenceBrokerConst.kDomain,
      EvidenceBrokerConst.kDomainEVIDENCEEVENTDESC);
    eventValueEntryRowDataEle.appendChild(doc.createTextNode(eventCode));
    eventValueEntryEle.appendChild(eventValueEntryRowDataEle);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * This utility method converts the given XML document to a string.
   *
   * @param doc The XML document for display by the evidence comparison widget.
   *
   * @return A string representation of the given DOM document.
   */
  @Deprecated
  protected StringWriter convertDOMDocumentToString(final Document doc) {

    // set up a transformer
    final TransformerFactory transfac = TransformerFactory.newInstance();
    final StringWriter sw = new StringWriter();
    final StreamResult result = new StreamResult(sw);
    final DOMSource source = new DOMSource(doc);

    try {
      final Transformer trans = transfac.newTransformer();

      trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
        EvidenceBrokerConst.kYes);
      trans.setOutputProperty(OutputKeys.INDENT, EvidenceBrokerConst.kYes);
      trans.transform(source, result);
    } catch (final TransformerConfigurationException transConfigEx) {
      throw new AppRuntimeException(BPOEVIDENCEBROKER.ERR_DATA_CORRUPT);
    } catch (final TransformerException transEx) {
      throw new AppRuntimeException(BPOEVIDENCEBROKER.ERR_DATA_CORRUPT);
    }
    return sw;
  }

  // BEGIN, CR00205373, PB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Adds the column header to the XML document based on remote or source
   * system.
   *
   * @param externalcaseInd Indicator to determine whether the record is
   * received from remote system
   *
   * @param doc XML document for display by the evidence comparison widget.
   * @param headerEle The column header element of the XML document.
   * @param context The context description to be included in the column header.
   * @param caseIDKey Contains the case ID.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws DOMException Generic Exception Signature.
   */
  @Deprecated
  protected void addColumnHeaderEntry(final Document doc,
    final Element headerEle, String context, final CaseIDKey caseIDKey,
    final boolean externalCase)
    throws AppException, InformationalException, DOMException {

    // If the evidence details is been received from remote system, the
    // case details is read from external case header entity, else its read
    // from case header entity.
    if (externalCase) {
      final ExternalCaseHeaderKey externalCaseHeaderKey =
        new ExternalCaseHeaderKey();

      externalCaseHeaderKey.externalCaseID = caseIDKey.caseID;

      final ExternalCaseHeaderDtls externalCaseHeaderDtls =
        ExternalCaseHeaderFactory.newInstance().read(externalCaseHeaderKey);

      if (CuramConst.gkEmpty != externalCaseHeaderDtls.caseType) {

        final CaseTypeEvidence caseTypeEvidence =
          caseTypeEvidenceMap.get(externalCaseHeaderDtls.caseType);

        if (null == caseTypeEvidence) {
          final AppException e = new AppException(
            BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

          e.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            externalCaseHeaderDtls.caseType,
            TransactionInfo.getProgramLocale()));
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              34);
        }
        final String caseSubType = caseTypeEvidence
          .getCaseTypeDescriptionDetails(externalCaseHeaderDtls.caseSubType);

        final StringBuffer contextBuffer = new StringBuffer();

        contextBuffer.append(context);
        contextBuffer.append(CuramConst.gkSpace);
        contextBuffer.append(CuramConst.gkDash);
        contextBuffer.append(CuramConst.gkSpace);
        contextBuffer.append(caseSubType);
        contextBuffer.append(CuramConst.gkSpace);
        contextBuffer.append(externalCaseHeaderDtls.caseNumber);

        context = contextBuffer.toString();
      }
    } else {
      // Read the product name and case reference
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName =
        MaintainCaseFactory.newInstance()
          .readCaseReferenceConcernRoleNameProductNameByCaseID(caseIDKey);

      final StringBuffer contextBuffer = new StringBuffer();

      contextBuffer.append(context);
      contextBuffer.append(CuramConst.gkSpace);
      contextBuffer.append(CuramConst.gkDash);
      contextBuffer.append(CuramConst.gkSpace);
      contextBuffer
        .append(caseReferenceProductNameConcernRoleName.productName);
      contextBuffer.append(CuramConst.gkSpace);
      contextBuffer
        .append(caseReferenceProductNameConcernRoleName.caseReference);

      context = contextBuffer.toString();
    }

    // <entry><data domain="SVR_STRING">
    // context - <Case Name> <Case ID>
    // </data></entry>
    final Element rowAEntry2Ele =
      doc.createElement(EvidenceBrokerConst.kEntry);

    headerEle.appendChild(rowAEntry2Ele);

    final Element rowAEntry2DataEle =
      doc.createElement(EvidenceBrokerConst.kData);

    rowAEntry2Ele.appendChild(rowAEntry2DataEle);
    rowAEntry2DataEle.setAttribute(EvidenceBrokerConst.kDomain,
      CuramConst.kDomainSVR_STRING);
    rowAEntry2DataEle.appendChild(doc.createTextNode(context));

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Returns a valid XML document for the evidence comparison widget,
   * comparing a shared evidence record with existing records of the same or
   * related type on the same case.It also does the comparison for external
   * case received from a remote system.
   *
   * @param externalcaseInd Indicator to determine whether the record is
   * received from remote system.
   *
   * @param key
   * Contains the existing case identifier, incoming evidence
   * identifier and evidence type.
   * @param targetType Contains the evidence type affected by the incoming
   * evidence record.
   * @param identical Indicator to determine whether to display the record
   * identified by the key.
   * @return XML representation of the evidence comparison table.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public EvidenceComparisonData getComparisonData(final EvidenceCaseKey key,
    final EvidenceTypeKey targetType, final boolean identical,
    boolean externalCaseInd) throws AppException, InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Get the Evidence2Compare implementation based on the type
    final Evidence2CompareMap map =
      EvidenceController.getEvidence2CompareMap();
    Evidence2Compare evidence2Compare = null;

    if (identical) {
      evidence2Compare = map.getEvidenceType(key.evidenceKey.evType);
    } else {
      evidence2Compare = map.getEvidenceType(targetType.evidenceType);
    }

    // Create a collection of merge data for all the records
    final ArrayList<EvidenceComparisonDtls> recordsToCompare =
      new ArrayList<EvidenceComparisonDtls>();

    final EIEvidenceKey[] eiEvidenceKeyList =
      getRecordsToCompare(key, targetType, identical).dtls.items();

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey = key.caseIDKey;

    for (final EIEvidenceKey eiEvidenceKey : eiEvidenceKeyList) {
      evidenceCaseKey.evidenceKey.evidenceID = eiEvidenceKey.evidenceID;
      evidenceCaseKey.evidenceKey.evType = eiEvidenceKey.evidenceType;
      recordsToCompare
        .add(evidence2Compare.getComparisonData(evidenceCaseKey));
    }
    recordsToCompare.trimToSize();

    // Used to display an information message and highlight the relevant column
    String message = CuramConst.gkEmpty;
    int highlightIndex = -1;

    // BEGIN, CR00246137, GYH
    // If there is no existing evidence to compare then construct an
    // informational message about the same and return.
    if (identical) {
      final ColumnHighlighter columnHighlighter =
        checkForWidgetInformationals(recordsToCompare);

      message = columnHighlighter.displayMessage;
      highlightIndex = (int) columnHighlighter.highlightIndex;
    } else {
      if (targetType.evidenceType.equals(CuramConst.gkEmpty)) {
        message = BPOEVIDENCEBROKER.INF_MESSAGE_NO_EVIDENCE_TO_COMPARE_TO
          .getMessageText(TransactionInfo.getProgramLocale());
      }
    }
    // END, CR00246137

    int numAttributeRows = 0;
    final int numEvidenceCols = recordsToCompare.size();

    if (numEvidenceCols > 0) {
      numAttributeRows = recordsToCompare.get(0).details.size();
    }

    Document doc = null;

    final DocumentBuilder builder = XMLParserCache.getDocumentBuilder();

    doc = builder.newDocument();

    // Insert the root element node
    final Element docEle =
      addComparisonRootElement(key, targetType, identical, doc);

    final Element msgTxtEle =
      doc.createElement(EvidenceBrokerConst.kMessageText);

    docEle.appendChild(msgTxtEle);

    if (!message.equals(CuramConst.gkEmpty)) {
      msgTxtEle.appendChild(doc.createTextNode(message));
    }

    //
    // Define columns
    //

    // insert one column for the labels
    final Element colLabelEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    colLabelEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleColLabel);
    docEle.appendChild(colLabelEle);

    // insert one column for each compared record
    for (int i = 0; i < numEvidenceCols; i++) {

      final Element colEle = doc.createElement(EvidenceBrokerConst.kColSpec);

      docEle.appendChild(colEle);

      if (identical) {
        if (i == 0) {
          // style="shared_evidence"
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColShared);
        }

        if (highlightIndex != -1 && i == highlightIndex) {
          // END, CR00122183
          // If this record has the same correction set ID as the incoming
          // record then an "highlight" style needs to be set.
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColHighlight);
        }
      }
    } // end for i

    if (identical && numEvidenceCols < 2) {
      docEle.appendChild(doc.createElement(EvidenceBrokerConst.kColSpec));
    }

    // <thead>
    final Element theadEle = doc.createElement(EvidenceBrokerConst.kTHead);

    docEle.appendChild(theadEle);

    // <row style="header_top">
    final Element rowAEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowAEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderA);
    theadEle.appendChild(rowAEle);

    // <entry><data></data></entry>
    // Note - Create this generically as it needs to be re-used
    final Element emptyEntry = doc.createElement(EvidenceBrokerConst.kEntry);
    final Element emptyData = doc.createElement(EvidenceBrokerConst.kData);

    emptyEntry.appendChild(emptyData);
    rowAEle.appendChild(emptyEntry);

    final CaseIDKey caseIDKey = new CaseIDKey();

    if (identical) {

      // Get the case id for the incoming evidence
      final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
        new RelatedIDAndEvidenceTypeKey();

      relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
      relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

      final long incomingCaseID = EvidenceDescriptorFactory.newInstance()
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).sourceCaseID;

      // Set the incoming case's context description
      final String incomingContext =
        BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale);

      caseIDKey.caseID = incomingCaseID;
      addColumnHeaderEntry(doc, rowAEle, incomingContext, caseIDKey,
        externalCaseInd);
    }

    if (identical || !identical && numEvidenceCols > 0) {
      // END, CR00121087

      // Set the existing case's context description
      final String existingContext =
        BPOEVIDENCEBROKER.INF_LABEL_EXISTING.getMessageText(locale);

      caseIDKey.caseID = key.caseIDKey.caseID;
      externalCaseInd = false;
      addColumnHeaderEntry(doc, rowAEle, existingContext, caseIDKey,
        externalCaseInd);
    }

    // BEGIN, CR00246304, GYH
    // When there is an existing evidence to compare then only bottom header
    // should be displayed
    if (identical && recordsToCompare.size() > 1
      || !identical && recordsToCompare.size() > 0) {
      // <row style="header_bottom">
      final Element rowBEle = doc.createElement(EvidenceBrokerConst.kRow);

      rowBEle.setAttribute(EvidenceBrokerConst.kStyle,
        EvidenceBrokerConst.kStyleRowHeaderB);
      theadEle.appendChild(rowBEle);

      // insert one empty cell above the labels
      // <entry><data></data></entry>
      final Node emptyCell = emptyEntry.cloneNode(true);

      rowBEle.appendChild(emptyCell);

      // insert one column header for each compared record
      // <entry><data domain="EVIDENCE_DESCRIPTOR_STATUS">EDS2</data></entry>
      for (int i = 0; i < recordsToCompare.size(); i++) {

        final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

        final String status = currentRecord.descriptor.statusCode;

        // blank out the incoming, shared record's status
        if (identical && i == 0) {
          rowBEle.appendChild(emptyEntry.cloneNode(true));
        } else {
          addEvidenceStatusEntry(doc, rowBEle, status);
        }
      }
      if (identical && numEvidenceCols < 2) {
        rowBEle.appendChild(emptyEntry.cloneNode(true));
      }
    }
    // END, CR00246304

    // <tbody>
    final Element tbodyEle = doc.createElement(EvidenceBrokerConst.kTBody);

    docEle.appendChild(tbodyEle);

    for (int i = 0; i < numAttributeRows; i++) {

      final Element attRow = addParticipantNameLabel(
        recordsToCompare.get(0).details.item(i), doc, tbodyEle);

      for (final Object currentObj : recordsToCompare) {
        final EvidenceComparisonDtls evidenceDtls =
          (EvidenceComparisonDtls) currentObj;

        addParticipantNameEntry(evidenceDtls.details.item(i), doc, attRow);
      }
      if (identical && numEvidenceCols < 2) {
        attRow.appendChild(emptyEntry.cloneNode(true));
      }
    } // end for i

    // "Effective Date" row
    final Element effectiveDateRow = addEffectiveDateLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addEffectiveDateEntry(doc, effectiveDateRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      effectiveDateRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Updated By" row
    final Element updatedByRow = addUpdatedByLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedByEntry(doc, updatedByRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedByRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Updated Date Time" row
    final Element updatedDateTimeRow = addUpdatedDateTimeLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedDateTimeEntry(doc, updatedDateTimeRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedDateTimeRow.appendChild(emptyEntry.cloneNode(true));
    }

    // "Event" row
    final Element eventRow = addEventLabel(doc, tbodyEle);

    // <entry><data domain="SVR_STRING">Pending Removal</data></entry>
    for (int i = 0; i < recordsToCompare.size(); i++) {

      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);

      // retrieve the Evidence Event Description code
      // For the incoming record, the event will only ever be new, updated or
      // removed. For existing, it will only be pending removal or blank.
      String eventCode = CuramConst.gkEmpty;

      if (identical && i == 0) {
        if (currentRecord.descriptor.pendingRemovalInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.REMOVAL;
        } else if (currentRecord.descriptor.newInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.NEW;
        } else {
          eventCode = EVIDENCEBROKEREVENTTYPE.UPDATED;
        }
      } else if (currentRecord.descriptor.pendingRemovalInd) {
        eventCode = EVIDENCEBROKEREVENTTYPE.PENDINGREMOVAL;
      }

      addEventEntry(doc, eventRow, eventCode);
    }

    if (identical && numEvidenceCols < 2) {
      eventRow.appendChild(emptyEntry.cloneNode(true));
    }

    // Convert the DOM Document to a String and return
    final StringWriter sw = convertDOMDocumentToString(doc);

    final EvidenceComparisonData evidenceComparisonData =
      new EvidenceComparisonData();

    evidenceComparisonData.data = sw.toString();

    return evidenceComparisonData;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Returns a valid XML document for the non identical evidence
   * widget.It also does the processing for external case received from a
   * remote system.
   *
   * @param externalcaseInd Indicator to determine whether the record is
   * received from remote system.
   * @param key Contains the case identifier, evidence identifier and evidence
   * type.
   * @param targetType The type of evidence affected by the shared record
   * @return XML list representation of the evidence records (of the target type
   * affected by the shared record)
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public NonIdenticalEvidenceComparisonData getNonIdenticalComparisonData(
    final EvidenceCaseKey key, final EvidenceTypeKey targetType,
    final boolean externalCaseInd)
    throws AppException, InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Get the Evidence2Compare implementation based on the type
    final Evidence2CompareMap map =
      EvidenceController.getEvidence2CompareMap();
    final Evidence2Compare evidence2Compare =
      map.getEvidenceType(key.evidenceKey.evType);

    final EvidenceComparisonDtls primaryDtls =
      evidence2Compare.getComparisonData(key);

    Document doc = null;

    final DocumentBuilder builder = XMLParserCache.getDocumentBuilder();

    doc = builder.newDocument();

    // Insert the root element node
    final Element docEle = addNonIdenticalRootElement(key, doc);

    // Insert one column for the labels
    final Element colLabelEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    colLabelEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleColLabel);
    docEle.appendChild(colLabelEle);
    final Element colValueEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    docEle.appendChild(colValueEle);

    // <thead>
    final Element theadEle = doc.createElement(EvidenceBrokerConst.kTHead);

    docEle.appendChild(theadEle);

    // <row style="header_top">
    final Element rowAEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowAEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderA);
    theadEle.appendChild(rowAEle);

    // <entry><data></data></entry>
    // Note - Create this generically as it needs to be re-used
    final Element emptyEntry = doc.createElement(EvidenceBrokerConst.kEntry);
    final Element emptyData = doc.createElement(EvidenceBrokerConst.kData);

    emptyEntry.appendChild(emptyData);
    rowAEle.appendChild(emptyEntry);

    // get the incoming case's context description
    final String colHeader =
      BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale);

    // Get the case id for the incoming evidence
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

    final long incomingCaseID = EvidenceDescriptorFactory.newInstance()
      .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).sourceCaseID;

    final CaseIDKey caseIDKey = new CaseIDKey();

    caseIDKey.caseID = incomingCaseID;

    addColumnHeaderEntry(doc, rowAEle, colHeader, caseIDKey, externalCaseInd);
    // END, CR00122417

    // <tbody>
    final Element tbodyEle = doc.createElement(EvidenceBrokerConst.kTBody);

    docEle.appendChild(tbodyEle);

    for (int i = 0; i < primaryDtls.details.size(); i++) {

      final Element attRow =
        addParticipantNameLabel(primaryDtls.details.item(i), doc, tbodyEle);

      addParticipantNameEntry(primaryDtls.details.item(i), doc, attRow);
    } // end for i

    // "Effective Date" row
    final Element effectiveDateRow = addEffectiveDateLabel(doc, tbodyEle);

    addEffectiveDateEntry(doc, effectiveDateRow, primaryDtls);

    // "Updated By" row
    final Element updatedByRow = addUpdatedByLabel(doc, tbodyEle);

    addUpdatedByEntry(doc, updatedByRow, primaryDtls);

    // "Updated Date Time" row
    final Element updatedDateTimeRow = addUpdatedDateTimeLabel(doc, tbodyEle);

    addUpdatedDateTimeEntry(doc, updatedDateTimeRow, primaryDtls);

    // "Event" row
    final Element eventRow = addEventLabel(doc, tbodyEle);

    // <entry><data domain="SVR_STRING">Pending Removal</data></entry>
    // retrieve the Evidence Event Description code
    // For the incoming record, the event will only ever be new, updated or
    // removed. For existing, it will only be pending removal or blank.
    String eventCode = CuramConst.gkEmpty;

    if (primaryDtls.descriptor.pendingRemovalInd) {
      eventCode = EVIDENCEBROKEREVENTTYPE.REMOVAL;
    } else if (primaryDtls.descriptor.newInd) {
      eventCode = EVIDENCEBROKEREVENTTYPE.NEW;
    } else {
      eventCode = EVIDENCEBROKEREVENTTYPE.UPDATED;
    }

    addEventEntry(doc, eventRow, eventCode);

    // Convert the DOM Document to a String and return
    final StringWriter sw = convertDOMDocumentToString(doc);

    final NonIdenticalEvidenceComparisonData nonIdenticalEvidenceComparisonData =
      new NonIdenticalEvidenceComparisonData();

    nonIdenticalEvidenceComparisonData.nonIdenticalData = sw.toString();

    // Retrieve the comparison data for non identical sharing view
    nonIdenticalEvidenceComparisonData.comparisonData =
      getComparisonData(key, targetType, false, externalCaseInd).data;

    return nonIdenticalEvidenceComparisonData;
  }

  // END, CR00205373
  // BEGIN, CR00348300, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Returns a valid XML document for the evidence comparison widget, comparing
   * a shared evidence record with existing selected records of the same or
   * related type on the same case.It also does the comparison for external case
   * received from a remote system.
   *
   * @param externalcaseInd
   * Indicator to determine whether the record is received from remote
   * system.
   *
   * @param key
   * Contains the existing case identifier, incoming evidence
   * identifier and evidence type.
   * @param targetType
   * Contains the evidence type affected by the incoming evidence
   * record.
   * @param identical
   * Indicator to determine whether to display the record identified by
   * the key.
   * @param evidencesSelected
   * Tab separated identifiers of the evidence records selected by the
   * user.
   * @return XML representation of the evidence comparison table.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public EvidenceComparisonData getComparisonDataForSelectedItems(
    final EvidenceCaseKey key, final EvidenceTypeKey targetType,
    final boolean identical, boolean externalCaseInd,
    final String evidencesSelected)
    throws AppException, InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Get the Evidence2Compare implementation based on the type
    final Evidence2CompareMap map =
      EvidenceController.getEvidence2CompareMap();
    Evidence2Compare evidence2Compare = null;

    if (identical) {
      evidence2Compare = map.getEvidenceType(key.evidenceKey.evType);
    } else {
      evidence2Compare = map.getEvidenceType(targetType.evidenceType);
    }
    // Create a collection of merge data for all the records
    final ArrayList<EvidenceComparisonDtls> recordsToCompare =
      new ArrayList<EvidenceComparisonDtls>();
    final EIEvidenceKey[] eiEvidenceKeyList =
      getRecordsToCompare(key, targetType, identical).dtls.items();

    final String[] itemsArray =
      evidencesSelected.split(CuramConst.gkTabDelimiter);
    final List<Long> selectedEvidenceIDs = new ArrayList<Long>();

    for (final String item : itemsArray) {
      final Long value = Long.parseLong(item);

      selectedEvidenceIDs.add(value);
    }
    // Keep only the selected entries and the source.
    final List<EIEvidenceKey> selectedEiEvidenceKeyList =
      new ArrayList<EIEvidenceKey>();

    for (final EIEvidenceKey eiEvidenceKey : eiEvidenceKeyList) {
      if (selectedEvidenceIDs.contains(eiEvidenceKey.evidenceID)
        || eiEvidenceKey.evidenceID == key.evidenceKey.evidenceID) {
        final EIEvidenceKey eIEvidenceKey = new EIEvidenceKey();

        eIEvidenceKey.evidenceID = eiEvidenceKey.evidenceID;
        eIEvidenceKey.evidenceType = eIEvidenceKey.evidenceType;
        selectedEiEvidenceKeyList.add(eIEvidenceKey);
      }
    }

    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey = key.caseIDKey;

    for (final EIEvidenceKey eiEvidenceKey : selectedEiEvidenceKeyList) {
      evidenceCaseKey.evidenceKey.evidenceID = eiEvidenceKey.evidenceID;
      evidenceCaseKey.evidenceKey.evType = eiEvidenceKey.evidenceType;
      recordsToCompare
        .add(evidence2Compare.getComparisonData(evidenceCaseKey));
    }
    recordsToCompare.trimToSize();

    // Used to display an information message and highlight the relevant column
    String message = CuramConst.gkEmpty;
    int highlightIndex = -1;

    // If there is no existing evidence to compare then construct an
    // informational message about the same and return.
    if (identical) {
      final ColumnHighlighter columnHighlighter =
        checkForWidgetInformationals(recordsToCompare);

      message = columnHighlighter.displayMessage;
      highlightIndex = (int) columnHighlighter.highlightIndex;
    } else {
      if (targetType.evidenceType.equals(CuramConst.gkEmpty)) {
        message = BPOEVIDENCEBROKER.INF_MESSAGE_NO_EVIDENCE_TO_COMPARE_TO
          .getMessageText(TransactionInfo.getProgramLocale());
      }
    }
    int numAttributeRows = 0;
    final int numEvidenceCols = recordsToCompare.size();

    if (numEvidenceCols > 0) {
      numAttributeRows = recordsToCompare.get(0).details.size();
    }
    Document doc = null;

    final DocumentBuilder builder = XMLParserCache.getDocumentBuilder();

    doc = builder.newDocument();

    // Insert the root element node
    final Element docEle =
      addComparisonRootElement(key, targetType, identical, doc);
    final Element msgTxtEle =
      doc.createElement(EvidenceBrokerConst.kMessageText);

    docEle.appendChild(msgTxtEle);
    if (!message.equals(CuramConst.gkEmpty)) {
      msgTxtEle.appendChild(doc.createTextNode(message));
    }
    //
    // Define columns
    //
    // insert one column for the labels
    final Element colLabelEle =
      doc.createElement(EvidenceBrokerConst.kColSpec);

    colLabelEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleColLabel);
    docEle.appendChild(colLabelEle);

    // insert one column for each compared record
    for (int i = 0; i < numEvidenceCols; i++) {
      final Element colEle = doc.createElement(EvidenceBrokerConst.kColSpec);

      docEle.appendChild(colEle);

      if (identical) {
        if (i == 0) {
          // style="shared_evidence"
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColShared);
        }
        if (highlightIndex != -1 && i == highlightIndex) {
          // If this record has the same correction set ID as the incoming
          // record then an "highlight" style needs to be set.
          colEle.setAttribute(EvidenceBrokerConst.kStyle,
            EvidenceBrokerConst.kStyleColHighlight);
        }
      }
    } // end for i

    if (identical && numEvidenceCols < 2) {
      docEle.appendChild(doc.createElement(EvidenceBrokerConst.kColSpec));
    }

    // <thead>
    final Element theadEle = doc.createElement(EvidenceBrokerConst.kTHead);

    docEle.appendChild(theadEle);

    // <row style="header_top">
    final Element rowAEle = doc.createElement(EvidenceBrokerConst.kRow);

    rowAEle.setAttribute(EvidenceBrokerConst.kStyle,
      EvidenceBrokerConst.kStyleRowHeaderA);
    theadEle.appendChild(rowAEle);

    // <entry><data></data></entry>
    // Note - Create this generically as it needs to be re-used
    final Element emptyEntry = doc.createElement(EvidenceBrokerConst.kEntry);
    final Element emptyData = doc.createElement(EvidenceBrokerConst.kData);

    emptyEntry.appendChild(emptyData);
    rowAEle.appendChild(emptyEntry);
    final CaseIDKey caseIDKey = new CaseIDKey();

    if (identical) {
      // Get the case id for the incoming evidence
      final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
        new RelatedIDAndEvidenceTypeKey();

      relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
      relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;

      final long incomingCaseID = EvidenceDescriptorFactory.newInstance()
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).sourceCaseID;
      // Set the incoming case's context description
      final String incomingContext =
        BPOEVIDENCEBROKER.INF_LABEL_INCOMING.getMessageText(locale);

      caseIDKey.caseID = incomingCaseID;
      addColumnHeaderEntry(doc, rowAEle, incomingContext, caseIDKey,
        externalCaseInd);
    }

    if (identical || !identical && numEvidenceCols > 0) {
      // Set the existing case's context description
      final String existingContext =
        BPOEVIDENCEBROKER.INF_LABEL_EXISTING.getMessageText(locale);

      caseIDKey.caseID = key.caseIDKey.caseID;
      externalCaseInd = false;
      addColumnHeaderEntry(doc, rowAEle, existingContext, caseIDKey,
        externalCaseInd);
    }
    // When there is an existing evidence to compare then only bottom header
    // should be displayed
    if (identical && recordsToCompare.size() > 1
      || !identical && recordsToCompare.size() > 0) {
      // <row style="header_bottom">
      final Element rowBEle = doc.createElement(EvidenceBrokerConst.kRow);

      rowBEle.setAttribute(EvidenceBrokerConst.kStyle,
        EvidenceBrokerConst.kStyleRowHeaderB);
      theadEle.appendChild(rowBEle);

      // insert one empty cell above the labels
      // <entry><data></data></entry>
      final Node emptyCell = emptyEntry.cloneNode(true);

      rowBEle.appendChild(emptyCell);

      // insert one column header for each compared record
      // <entry><data domain="EVIDENCE_DESCRIPTOR_STATUS">EDS2</data></entry>
      for (int i = 0; i < recordsToCompare.size(); i++) {
        final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);
        final String status = currentRecord.descriptor.statusCode;

        // blank out the incoming, shared record's status
        if (identical && i == 0) {
          rowBEle.appendChild(emptyEntry.cloneNode(true));
        } else {
          addEvidenceStatusEntry(doc, rowBEle, status);
        }
      }
      if (identical && numEvidenceCols < 2) {
        rowBEle.appendChild(emptyEntry.cloneNode(true));
      }
    }
    // <tbody>
    final Element tbodyEle = doc.createElement(EvidenceBrokerConst.kTBody);

    docEle.appendChild(tbodyEle);

    for (int i = 0; i < numAttributeRows; i++) {
      final Element attRow = addParticipantNameLabel(
        recordsToCompare.get(0).details.item(i), doc, tbodyEle);

      for (final Object currentObj : recordsToCompare) {
        final EvidenceComparisonDtls evidenceDtls =
          (EvidenceComparisonDtls) currentObj;

        addParticipantNameEntry(evidenceDtls.details.item(i), doc, attRow);
      }
      if (identical && numEvidenceCols < 2) {
        attRow.appendChild(emptyEntry.cloneNode(true));
      }
    } // end for i

    // "Effective Date" row
    final Element effectiveDateRow = addEffectiveDateLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addEffectiveDateEntry(doc, effectiveDateRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      effectiveDateRow.appendChild(emptyEntry.cloneNode(true));
    }
    // "Updated By" row
    final Element updatedByRow = addUpdatedByLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedByEntry(doc, updatedByRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedByRow.appendChild(emptyEntry.cloneNode(true));
    }
    // "Updated Date Time" row
    final Element updatedDateTimeRow = addUpdatedDateTimeLabel(doc, tbodyEle);

    for (final Object currentObj : recordsToCompare) {
      final EvidenceComparisonDtls evidenceDtls =
        (EvidenceComparisonDtls) currentObj;

      addUpdatedDateTimeEntry(doc, updatedDateTimeRow, evidenceDtls);
    }
    if (identical && numEvidenceCols < 2) {
      updatedDateTimeRow.appendChild(emptyEntry.cloneNode(true));
    }
    // "Event" row
    final Element eventRow = addEventLabel(doc, tbodyEle);

    // <entry><data domain="SVR_STRING">Pending Removal</data></entry>
    for (int i = 0; i < recordsToCompare.size(); i++) {
      final EvidenceComparisonDtls currentRecord = recordsToCompare.get(i);
      // retrieve the Evidence Event Description code
      // For the incoming record, the event will only ever be new, updated or
      // removed. For existing, it will only be pending removal or blank.
      String eventCode = CuramConst.gkEmpty;

      if (identical && i == 0) {
        if (currentRecord.descriptor.pendingRemovalInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.REMOVAL;
        } else if (currentRecord.descriptor.newInd) {
          eventCode = EVIDENCEBROKEREVENTTYPE.NEW;
        } else {
          eventCode = EVIDENCEBROKEREVENTTYPE.UPDATED;
        }
      } else if (currentRecord.descriptor.pendingRemovalInd) {
        eventCode = EVIDENCEBROKEREVENTTYPE.PENDINGREMOVAL;
      }
      addEventEntry(doc, eventRow, eventCode);
    }
    if (identical && numEvidenceCols < 2) {
      eventRow.appendChild(emptyEntry.cloneNode(true));
    }
    // Convert the DOM Document to a String and return
    final StringWriter sw = convertDOMDocumentToString(doc);
    final EvidenceComparisonData evidenceComparisonData =
      new EvidenceComparisonData();

    evidenceComparisonData.data = sw.toString();

    return evidenceComparisonData;
  }
  // END, CR00348300
}
