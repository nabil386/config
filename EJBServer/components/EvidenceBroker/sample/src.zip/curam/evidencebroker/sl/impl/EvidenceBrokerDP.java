/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2013, 2014
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */

package curam.evidencebroker.sl.impl;

import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * Provides the functionality for evidence sharing through the deferred process.
 */

@Deprecated
public abstract class EvidenceBrokerDP
  extends curam.evidencebroker.sl.base.EvidenceBrokerDP {

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   */
  @Deprecated
  private final EvidenceBrokerDPTemplate evidenceBrokerDPTemplate =
    new EvidenceBrokerDPTemplate();

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Default constructor for the class.
   */
  @Deprecated
  public EvidenceBrokerDP() {

    // BEGIN, CR00400002, SSK
    GuiceWrapper.getInjector().injectMembers(this);
    // BEGIN, CR00427655, RPB
    /**
     * @deprecated Since 7.0.2.0 functionality has been replaced by component
     * AdvancedEvidenceSharing.
     */
    evidenceBrokerDPTemplate.init(ReflectionConst.evidenceBrokerDPClassName,
      Boolean.TRUE, Boolean.TRUE);
    // END, CR00427655
    // END, CR00400002
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given evidence is configured for evidence sharing, if
   * configured, then shares this evidence with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareEvidence(final long ticketID, final long instDataID,
    final boolean flag) throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvidence(ticketID, instDataID, flag);

  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Identifies the case that this participant role has been set up on. It then
   * finds any evidence sharing configurations that are applicable to this new
   * case and shares all of the evidence relevant to this participant role with
   * the new case.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareEvdForCaseParticipant(final long ticketID,
    final long instDataID, final boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvdForCaseParticipant(ticketID, instDataID,
      flag);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given piece of evidence is configured for evidence
   * removal sharing, if configured, then shares the evidence with the relevant
   * cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareEvidenceRemoval(final long ticketID, final long instDataID,
    final boolean flag) throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvidenceRemoval(ticketID, instDataID, flag);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence sharing, if configured, then shares the evidence
   * with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareExternalEvidence(final long ticketID,
    final long instDataID, final boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareExternalEvidence(ticketID, instDataID,
      flag);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence removal sharing, if configured, then shares the
   * evidence with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareExternalEvidenceRemoval(final long ticketID,
    final long instDataID, final boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareExternalEvidenceRemoval(ticketID,
      instDataID, flag);
  }

  // BEGIN, CR00397427, RPB
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines whether a given set of evidences is configured for evidence
   * sharing, if configured, then shares the evidences with the relevant cases
   * after reading the list of evidences stored in the data store.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The data store instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void shareBulkEvidence(final long ticketID, final long instDataID,
    final boolean flag) throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareBulkEvidence(ticketID, instDataID, flag);
  }
  // END, CR00397427
}
