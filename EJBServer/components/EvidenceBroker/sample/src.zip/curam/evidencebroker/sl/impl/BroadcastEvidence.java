/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.sl.impl;

import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.evidencebroker.sl.struct.EvidenceAutoAcceptanceInd;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * This class contains a hook to allow customers delegate the evidence sharing
 * functionality to their service layer processing. One possible reason for a
 * customer wanting to do that is that the service layer processing may invoke
 * a workflow that initiates other important processing.
 */
@Deprecated
public abstract class BroadcastEvidence
  extends curam.evidencebroker.sl.base.BroadcastEvidence {

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Hook mechanism which allows customers to delegate the evidence broadcast
   * through their own service layer.
   *
   * @param sourceDescriptor The source evidence descriptor
   * @param targetCase The case the evidence is being broadcast to
   * @return The evidence descriptor of the broadcast record on the target case
   */
  @Deprecated
  @Override
  public EvidenceDescriptorDtls processBroadcast(
    final EvidenceDescriptorDtls sourceDescriptor,
    final CaseHeaderDtls targetCase)
    throws AppException, InformationalException {

    return null;
  }

  // BEGIN, CR00206415, PB.
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Hook mechanism which allows customers to delegate the external evidence
   * broadcast through their own service layer.
   *
   * @param descriptorDetails Contains the evidence descriptor details
   * received from remote system.
   * @param targetCase Contains the case the evidence is being broadcast to.
   *
   * @return The evidence descriptor of the broadcast record on the target
   * case.
   */

  @Deprecated
  @Override
  public EvidenceDescriptorDtls processExternalBroadcast(
    final SharedEvidenceDescriptorDetails descriptorDetails,
    final CaseHeaderDtls targetCase)
    throws AppException, InformationalException {

    return null;
  }

  // END, CR00206415.

  // BEGIN, CR00237356, GYH
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Returns true if the evidence being passed has been auto accepted onto the
   * target case else false would be returned.
   *
   * @param sourceDescriptor
   * Contains source evidence descriptor details.
   * @param targetCase
   * Contains the case identifier of the evidence is being broadcast
   * to.
   *
   * @return True would be returned if the evidence being passed has been auto
   * accepted onto the target case else false.
   */
  @Deprecated
  @Override
  public EvidenceAutoAcceptanceInd isAutoAccepted(
    final EvidenceDescriptorDtls sourceDescriptor,
    final CaseHeaderDtls targetCase)
    throws AppException, InformationalException {

    return null;
  }
  // END, CR00237356
}
