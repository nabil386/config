/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.impl;

import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.BPOBROADCASTEVIDENCEREGISTRAR;
import curam.util.exception.AppException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import java.lang.reflect.Method;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * Central class to handle the creation of broadcast evidence hook based on a
 * particular product type.
 */
@Deprecated
public final class BroadcastEvidenceManager {

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Retrieves the map containing a subclass of the BroadcastEvidence class
   * for each case type.
   *
   * @return The map containing a subclass of the BroadcastEvidence class
   * for each case type.
   */
  @Deprecated
  public static BroadcastEvidenceRegistrar.HookMap get() {

    return broadcastEvidenceMap;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * The map containing a subclass of the BroadcastEvidence class for each
   * case type.
   */
  // BEGIN, CR00198200, GYH
  @Deprecated
  protected static BroadcastEvidenceRegistrar.HookMap broadcastEvidenceMap =
    GuiceWrapper.getInjector()
      .getInstance(BroadcastEvidenceRegistrar.HookMap.class);
  // END, CR00198200

  // Static initialization of the Evidence Broadcast Hook Map
  static {

    // Get the value of the evidence broadcast registrars environment
    // variable
    final String registrarsString = Configuration
      .getProperty(EnvVars.ENV_BROADCASTEVIDENCE_REGISTRARS_LIST);

    if (null != registrarsString) {

      // Get comma-separated list of registrar factory class names
      final String registrarFactoryNames[] =
        registrarsString.split(CuramConst.gkComma);

      for (int i = 0; i < registrarFactoryNames.length; i++) {

        final String registrarFactoryName = registrarFactoryNames[i];

        try {
          final Class registrarFactoryClass =
            Class.forName(registrarFactoryName);

          final Method newInstance = registrarFactoryClass
            .getMethod(ReflectionConst.kNewInstance, new Class[0]);

          final Object registrar = newInstance.invoke(null, new Object[0]);

          if (registrar instanceof BroadcastEvidenceRegistrar) {

            final BroadcastEvidenceRegistrar evidenceBroadcastRegistrar =
              (BroadcastEvidenceRegistrar) registrar;

            // Register the Broadcast Evidence Classes
            evidenceBroadcastRegistrar.register();
          }
        } catch (final Exception e) {

          final AppException ae = new AppException(
            BPOBROADCASTEVIDENCEREGISTRAR.ERR_REGISTRAR_ISSUE);

          throw new RuntimeException(ae);
        }
      } // end for i
    }
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets the implementation subclass of the BroadcastEvidence class for the
   * specified case type.
   *
   * @param type The type of the case
   *
   * @return The implementation subclass of the BroadcastEvidence class for
   * the specified product type.
   *
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public static curam.evidencebroker.sl.intf.BroadcastEvidence
    getHook(final String type) throws AppException {

    curam.evidencebroker.sl.intf.BroadcastEvidence result =
      (curam.evidencebroker.sl.intf.BroadcastEvidence) broadcastEvidenceMap
        .createHookInstance(type,
          curam.evidencebroker.sl.intf.BroadcastEvidence.class);

    if (null == result) {
      result =
        curam.evidencebroker.sl.fact.BroadcastEvidenceFactory.newInstance();
    }

    return result;
  }
}
