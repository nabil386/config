/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */

package curam.evidencebroker.ws.publiclayer.bs.impl;

import com.google.inject.Inject;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.OPERATIONNAME;
import curam.codetable.impl.TARGETSYSTEMSTATUSEntry;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.intf.ExternalCaseHeader;
import curam.core.intf.UniqueID;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.infrastructure.impl.WSConvertBSConst;
import curam.core.sl.struct.KeyValuePair;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.ws.convert.utils.impl.ConversionUtil;
import curam.core.ws.convert.utils.impl.ResponseManager;
import curam.ctm.targetsystem.impl.TargetSystem;
import curam.ctm.targetsystem.impl.TargetSystemDAO;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.Trace;
import curam.util.resources.XMLParserCache;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.ParseException;
import java.util.Map;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.apache.logging.log4j.Logger;
import curam.common.util.xml.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Sharing of evidence from the source system is received in the destination
 * system through the web service.
 *
 */
@SuppressWarnings("deprecation")
public abstract class EvdBrokerWebService
  extends curam.evidencebroker.ws.publiclayer.bs.base.EvdBrokerWebService {

  @Inject
  protected TargetSystemDAO targetSystemDAO;

  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  public static final String kWebServiceCategory =
    Trace.kDefaultTraceCategory + CuramConst.gkWebServiceCategory;

  // 258085, BEGIN, BD
  public static final Logger kWebServiceLogger =
    Trace.getLogger(kWebServiceCategory);
  // 258085, END

  /**
   * Default constructor for the class.
   */
  public EvdBrokerWebService() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Receives the inbound evidence share document from the source system.
   *
   * @param document Contains the Inbound DOM document.
   *
   * @return The Outbound response DOM document.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public Document receiveChangeNotification(final Document xmlMessage)
    throws AppException, InformationalException {

    validateDocument(xmlMessage);

    // Retrieve the case type code from the document and pass it to get the
    // case type specific object instance
    final Document responseDocument = processChangeNotification(xmlMessage);

    return responseDocument;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Process the evidence details received from a remote system to a source
   * system.
   *
   * @param document Contains the inbound document
   *
   * @return The response document
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public Document processChangeNotification(final Document document)
    throws AppException, InformationalException {

    // Create the response manager to control the response to each result
    final ResponseManager responseManager = new ResponseManager();

    // Iterate through the document to populate the structs
    final Element root = document.getDocumentElement();

    if (root.getNodeType() == Node.ELEMENT_NODE
      && nodeName(root).equalsIgnoreCase(WSConvertBSConst.kEvidence)) {

      SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails = null;
      ExternalCaseHeaderDtls externalCaseHeaderDtls = null;
      ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

      responseManager.setup(WSConvertBSConst.kEvidenceShare);

      // Iterate through all the details found within the documents list node
      for (Node child = root.getFirstChild(); child != null; child =
        child.getNextSibling()) {

        if (child.getNodeType() == Node.ELEMENT_NODE && nodeName(child)
          .equalsIgnoreCase(WSConvertBSConst.kEvidenceData)) {

          // Set the exception catEntry value, before the try block
          responseManager.addSection();
          try {
            for (Node evidenceDataChild = child
              .getFirstChild(); evidenceDataChild != null; evidenceDataChild =
                evidenceDataChild.getNextSibling()) {

              if (evidenceDataChild.getNodeType() == Node.ELEMENT_NODE) {

                // Check, if the sub element is evidenceDetails
                if (nodeName(evidenceDataChild)
                  .equalsIgnoreCase(WSConvertBSConst.kEvidenceDetails)) {

                  // read the participant details from the document.
                  concernRoleDtls = readParticipantDetails(evidenceDataChild);

                  // BEGIN, CR00295214, ELG
                  // Nothing needs to be done if we do not find the participant.
                  if (concernRoleDtls == null) {
                    break;
                  }
                  // END, CR00295214

                  // Populate the attributes details from the document to
                  // sharedEvidenceDescriptorDetails.
                  sharedEvidenceDescriptorDetails =
                    readSharedEvidenceDescriptorDetails(evidenceDataChild);
                  sharedEvidenceDescriptorDetails.details.participantID =
                    concernRoleDtls.concernRoleID;
                  sharedEvidenceDescriptorDetails.details.externalSourceCaseInd =
                    true;

                  // Populate the details to externalCaseHeaderDtls from the
                  // document and insert the details into externalCaseHeader.
                  externalCaseHeaderDtls =
                    createExternalCaseDetails(evidenceDataChild);
                  sharedEvidenceDescriptorDetails.details.caseID =
                    externalCaseHeaderDtls.externalCaseID;

                  // Set the source system ID
                  sharedEvidenceDescriptorDetails.sourceSystemID =
                    externalCaseHeaderDtls.sourceSystemID;

                } else if (nodeName(evidenceDataChild)
                  .equalsIgnoreCase(WSConvertBSConst.kDataObjects)) {

                  // Populate the attributes details from the document.
                  readDataObjectDetails(evidenceDataChild,
                    sharedEvidenceDescriptorDetails);
                }
              }
            }

            final curam.evidencebroker.sl.intf.EvidenceBroker evidenceBroker =
              curam.evidencebroker.sl.fact.EvidenceBrokerFactory
                .newInstance();

            if (sharedEvidenceDescriptorDetails.operation
              .equals(OPERATIONNAME.CREATE)) {
              evidenceBroker
                .shareExternalEvidence(sharedEvidenceDescriptorDetails);
            } else if (sharedEvidenceDescriptorDetails.operation
              .equals(OPERATIONNAME.REMOVE)) {
              evidenceBroker.shareExternalEvidenceRemoval(
                sharedEvidenceDescriptorDetails);

            }
            // Set the success attribute.
            responseManager.setSuccess(true);
          } catch (final Exception e) {
            kWebServiceLogger.error(e.getLocalizedMessage(), e); // Logger
          }
        }
      }
    }
    return responseManager.getResponseDocument();
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Read the local node name where possible. Otherwise read the node name (i.e.
   * local node name excludes any namespace prefix).
   *
   * @param node Contains the node
   *
   * @return The local node name, the node name or an empty string
   */
  @Deprecated
  protected String nodeName(final Node node) {

    String result = CuramConst.gkEmpty;

    if (node.getLocalName() != null) {
      result = node.getLocalName();
    } else {
      result = node.getNodeName();
    }
    return result;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Read the details from the document node and assign it to shared evidence
   * descriptor details for evidence sharing.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The evidence details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected SharedEvidenceDescriptorDetails
    readSharedEvidenceDescriptorDetails(final Node evidenceDetailsNode)
      throws AppException, InformationalException {

    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorReturnDetails =
      new SharedEvidenceDescriptorDetails();

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      final Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      // Iterate through the document node and get the required details.
      for (Node evidenceDetailChildNode = evidenceDetailsElement
        .getFirstChild(); evidenceDetailChildNode != null; evidenceDetailChildNode =
          evidenceDetailChildNode.getNextSibling()) {

        if (evidenceDetailsNode != null
          && evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
          final Element eDetailChildElement =
            (Element) evidenceDetailChildNode;
          final String eDetailChildValue =
            eDetailChildElement.getFirstChild().getNodeValue().trim();

          if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kCaseType)) {
            sharedEvidenceDescriptorReturnDetails.sourceType =
              eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kReceivedDate)) {
            sharedEvidenceDescriptorReturnDetails.details.effectiveFrom =
              convertToDateFormat(eDetailChildValue);
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kEffectiveDate)) {
            sharedEvidenceDescriptorReturnDetails.details.effectiveFrom =
              convertToDateFormat(eDetailChildValue);
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kSharedinstanceID)) {
            sharedEvidenceDescriptorReturnDetails.details.sharedInstanceID =
              Long.parseLong(eDetailChildValue.trim());
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kEvidenceType)) {
            sharedEvidenceDescriptorReturnDetails.details.evidenceType =
              eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kOperation)) {
            sharedEvidenceDescriptorReturnDetails.operation =
              eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kCaseSubType)) {

            final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap
              .get(sharedEvidenceDescriptorReturnDetails.sourceType);

            if (null == caseTypeEvidence) {
              final AppException e = new AppException(
                BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

              e.arg(CodeTable.getOneItem(CASETYPECODE.TABLENAME,
                sharedEvidenceDescriptorReturnDetails.sourceType,
                TransactionInfo.getProgramLocale()));
              curam.core.sl.infrastructure.impl.ValidationManagerFactory
                .getManager().throwWithLookup(e,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  35);

            }
            sharedEvidenceDescriptorReturnDetails.sourceID =
              caseTypeEvidence.getSubTypeID(eDetailChildValue);

          }
        }
      }
    }
    return sharedEvidenceDescriptorReturnDetails;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Create an external case header record by reading the details from the
   * document received from an external system.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The external case details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected ExternalCaseHeaderDtls
    createExternalCaseDetails(final Node evidenceDetailsNode)
      throws AppException, InformationalException {

    final ExternalCaseHeaderDtls externalCaseHeaderDtls =
      new ExternalCaseHeaderDtls();

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      final Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      // Iterate through the document node and get the required details.
      for (Node evidenceDetailChildNode = evidenceDetailsElement
        .getFirstChild(); evidenceDetailChildNode != null; evidenceDetailChildNode =
          evidenceDetailChildNode.getNextSibling()) {

        if (evidenceDetailsNode != null
          && evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
          final Element eDetailChildElement =
            (Element) evidenceDetailChildNode;
          final String eDetailChildValue =
            eDetailChildElement.getFirstChild().getNodeValue().trim();

          if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kCaseID)) {
            externalCaseHeaderDtls.caseNumber = eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kCaseType)) {
            externalCaseHeaderDtls.caseType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kCaseSubType)) {
            externalCaseHeaderDtls.caseSubType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement)
            .equalsIgnoreCase(WSConvertBSConst.kSourceSystemName)) {
            final String targetSystemName = eDetailChildValue;

            final TargetSystem targetSystem =
              targetSystemDAO.readByTargetSystemNameAndStatus(
                TARGETSYSTEMSTATUSEntry.ACTIVE, targetSystemName);

            externalCaseHeaderDtls.sourceSystemID = targetSystem.getID();
          }
        }
      }
    }
    final ExternalCaseHeader externalCaseHeaderObj =
      ExternalCaseHeaderFactory.newInstance();
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    externalCaseHeaderDtls.externalCaseID = uniqueIDObj.getNextID();
    externalCaseHeaderObj.insert(externalCaseHeaderDtls);

    return externalCaseHeaderDtls;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Read the participant details from the document node received from a remote
   * system.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The participant details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected ConcernRoleDtls
    readParticipantDetails(final Node evidenceDetailsNode)
      throws AppException, InformationalException {

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      final Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      final NodeList nodes = evidenceDetailsElement
        .getElementsByTagName(WSConvertBSConst.kParticipantNumber);
      final String participantNumber =
        nodes.item(0).getFirstChild().getNodeValue().trim();

      final ConcernRoleAlternateReadKey concernRoleAlternateReadKey =
        new ConcernRoleAlternateReadKey();

      concernRoleAlternateReadKey.primaryAlternateID = participantNumber;
      concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.CURRENT;
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      try {
        return concernRoleObj.readByAlternateID(concernRoleAlternateReadKey);
      } catch (final RecordNotFoundException rnfe) {
        return null;
      }

    }
    return null;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Read the evidence data item details from the document node and assign it to
   * shared evidence descriptor details for evidence sharing.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected void readDataObjectDetails(final Node evidenceDetailsNode,
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails) {

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {

      final Element dataObjectsElement = (Element) evidenceDetailsNode;

      for (Node dataItemNode = dataObjectsElement
        .getFirstChild(); dataItemNode != null; dataItemNode =
          dataItemNode.getNextSibling()) {
        if (dataItemNode.getNodeType() == Node.ELEMENT_NODE) {
          final KeyValuePair keyValuePair = new KeyValuePair();

          // Cast the dataItem element from the node.
          final Element dataItemElement = (Element) dataItemNode;

          if (nodeName(dataItemElement)
            .equalsIgnoreCase(WSConvertBSConst.kDataItem)) {

            // Set the data item name.
            keyValuePair.name =
              dataItemElement.getAttribute(WSConvertBSConst.kName);

            if (dataItemElement.getFirstChild() != null && dataItemNode
              .getFirstChild().getNodeType() == Node.TEXT_NODE) {
              // Set the data item value.
              keyValuePair.value =
                dataItemElement.getFirstChild().getNodeValue().trim();
            }
            sharedEvidenceDescriptorDetails.keyList.addRef(keyValuePair);

          }
        }
      }
    }
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Convert the string value to curam date format.
   *
   * @param eDetailChildValue Contains the string date format.
   *
   * @return the curam date format
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  protected Date convertToDateFormat(final String eDetailChildValue)
    throws AppException, InformationalException {

    final ConversionUtil conversionUtil = new ConversionUtil();
    Date date = new Date();

    try {
      date = conversionUtil.toCuramDate(eDetailChildValue);
    } catch (final ParseException pe) {
      final AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_BROKER_INCORRECT_DATE_FORMAT);

      throw appException;
    }
    return date;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Validates the evidence sharing xml document with the schema provided
   * for the inbound web service.
   *
   * @param xmlMessage Contains the inbound DOM document.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public void validateDocument(final Document xmlMessage)
    throws AppException, InformationalException {

    try {
      final Schema schema = getSchema(EvidenceBrokerConst.kSchemaFile);
      final Validator validator = schema.newValidator();

      validator.validate(new DOMSource(xmlMessage));
    } catch (final SAXException e) {
      final AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_SHARING_XML_DOCUMENT_INVALID_WITH_SCHEMA,
        e);

      throw appException;
    } catch (final IOException e) {// Ignore this error as schema file will
      // always be
      // present.
    }
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets the schema file from the file disk for the initial access and stores
   * it in a collection for future access.
   *
   * @param fileName
   * Contains the name of the schema file that needs to be loaded.
   *
   * @return the schema against which the change set xml document would be
   * validated.
   *
   * @throws SAXException
   * Generic Exception Signature.
   */
  @Deprecated
  protected Schema getSchema(final String fileName) throws SAXException {

    // Create a SchemaFactory capable of understanding WXS schema.
    final SchemaFactory factory =
      SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    
    try {          
      //Check input for XXE
      XMLParserCache.checkForXXE(EvdBrokerWebService.class.getClassLoader()
        .getResourceAsStream(fileName));     
      
    } catch (DOMException e) {     
      throw new SAXException(e);
    } catch (IOException e) {   
      throw new SAXException(e);
    }    
    
    final Source schemaContentsAsSource;

    final String schemaStr = getResource(fileName);

    schemaContentsAsSource = new StreamSource(new StringReader(schemaStr));

    final Schema schema = factory.newSchema(schemaContentsAsSource);

    return schema;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   * Gets a resource from the class path as a string reader.
   *
   * @param resourceName
   * The name of the resource to retrieve.
   * @return The file contents as a string.
   */
  @Deprecated
  protected String getResource(final String resourceName) {

    String resource = null;

    try {
      final InputStream inputStream =
        EvdBrokerWebService.class.getResourceAsStream(resourceName);
      final ByteArrayOutputStream out =
        new ByteArrayOutputStream(EvidenceBrokerConst.kByteOutputStreamSize);
      final byte[] buffer = new byte[EvidenceBrokerConst.kByteBufferSize];
      int k = 0;

      while ((k = inputStream.read(buffer)) != -1) {
        out.write(buffer, 0, k);
      }
      resource = out.toString(GeneralConstants.kUTF8);
      inputStream.close();
    } catch (final IOException e) {
      throw new AppRuntimeException(e);
    }

    return resource;
  }

}
