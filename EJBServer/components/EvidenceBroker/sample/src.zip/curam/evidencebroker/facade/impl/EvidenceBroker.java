/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2015. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.facade.impl;

import com.google.inject.Inject;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.EVIDENCECHANGEREASON;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.EVIDENCESHARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SYNCHRONIZATIONACTION;
import curam.codetable.VERIFICATIONSHAREOPTION;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCENATUREEntry;
import curam.core.events.EVIDENCEBROKER;
import curam.core.facade.infrastructure.struct.EvidenceContextDescription;
import curam.core.facade.infrastructure.struct.VerificationDetailsForIncomingEvidence;
import curam.core.facade.infrastructure.struct.VerificationDetailsForIncomingEvidenceList;
import curam.core.facade.infrastructure.struct.VerificationItemProvidedDetailsList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceDescriptorID;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.ChangeUserDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.MostRecentBusinessObjectChangesDetails;
import curam.core.sl.infrastructure.entity.struct.MostRecentBusinessObjectChangesDetailsList;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceVerification;
import curam.core.sl.infrastructure.struct.ECWarningsDtlsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDesc;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDetails;
import curam.core.sl.infrastructure.widgetUtility.impl.StructToXML;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.sl.struct.EvidenceTypeKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.evidence.impl.EvidenceNature;
import curam.evidence.impl.EvidenceTypeNature;
import curam.evidencebroker.facade.struct.CaseIDAndEvidenceTypeDetails;
import curam.evidencebroker.facade.struct.EvidenceSynchronizationViewDetails;
import curam.evidencebroker.facade.struct.EvidenceVerificationItemDetails;
import curam.evidencebroker.facade.struct.IdenticalEvidenceComparisonData;
import curam.evidencebroker.facade.struct.IdenticalEvidenceComparisonDetails;
import curam.evidencebroker.facade.struct.IdenticalEvidenceDetails;
import curam.evidencebroker.facade.struct.IdenticalEvidenceSearchKey;
import curam.evidencebroker.facade.struct.IdenticalEvidenceSynchronizationDetailsList;
import curam.evidencebroker.facade.struct.IdenticalEvidencesListForComparison;
import curam.evidencebroker.facade.struct.NonIdenticalEvidenceComparisonData;
import curam.evidencebroker.facade.struct.SynchronizeEvidenceDetails;
import curam.evidencebroker.facade.struct.SynchronizeEvidenceResult;
import curam.evidencebroker.facade.struct.WizardInfo;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtls;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceSharingConfigKey;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeAction;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeActionList;
import curam.evidencebroker.sl.struct.IncomingEvidenceAndSourceCaseDetailsList;
import curam.evidencebroker.sl.struct.IncomingEvidenceDetails;
import curam.evidencebroker.sl.struct.IncomingEvidenceDetailsList;
import curam.evidencebroker.sl.struct.NonIdenticalEvidenceSynchronizationDetailsList;
import curam.evidencebroker.sl.struct.SharedEvidenceSourceTypeAndSourceIDDetails;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.GENERALCASE;
import curam.message.impl.BPOEVIDENCEBROKERExceptionCreator;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.verification.sl.infrastructure.fact.CurrentPostponedVerificationFactory;
import curam.verification.sl.infrastructure.fact.SharedVERItemProvidedFactory;
import curam.verification.sl.infrastructure.intf.SharedVERItemProvided;
import curam.verification.sl.infrastructure.struct.CurrentPostponedVerificationDtlsList;
import curam.verification.sl.infrastructure.struct.TargetEvidenceDescriptorKey;
import curam.wizardpersistence.impl.WizardPersistentState;
import java.util.Map;

/**
 * @deprecated Since 7.0.2.0 functionality has been replaced by component
 * AdvancedEvidenceSharing.
 *
 * This process class provides all non-administrative evidence broker
 * functionality including the synchronization processing.
 */
@Deprecated
public class EvidenceBroker
  extends curam.evidencebroker.facade.base.EvidenceBroker {

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   */
  @Deprecated
  @Inject
  protected EvidenceVerification evidenceVerification;

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   */
  @Deprecated
  @Inject
  protected Map<EVIDENCENATUREEntry, EvidenceTypeNature> evidenceTypeNatureMap;

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * A reference for {@link EvidenceNature}.
   */
  @Deprecated
  @Inject
  protected EvidenceNature evidenceNature;

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Reference to a helper class {@link ProcessEvidenceHelper}.
   */
  @Deprecated
  @Inject
  protected curam.evidencebroker.sl.impl.ProcessEvidenceHelper processEvidenceHelper;

  // BEGIN, CR00428056, KRK
  /*
   * Holds the value {@value} and this constant is not used in core code.
   */
  protected static final int kUserRead = 1;

  /*
   * Holds the value {@value} and this constant is not used in core code.
   */
  protected static final int kUserMaintain = 2;

  // END, CR00428056

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Default constructor for the class.
   */
  @Deprecated
  public EvidenceBroker() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00119649, KH
  // BEGIN, CR00114664, CW
  // BEGIN, CR00120297, CD
  // BEGIN, CR00120556, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method returns the evidence records for identical evidence sharing
   * comparison view in an XML list form. The returned list contains the shared
   * evidence record and any active or in-edit records of the same evidence type
   * as the shared evidence record that are on the current case. The current
   * case is the case on which evidence is being synchronized.
   *
   * @param key Contains the case identifier and evidence descriptor identifier
   *
   * @return Identical comparison data containing an XML representation of the
   * evidence records for use by the comparison view.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IdenticalEvidenceComparisonData
    getEvidenceForIdenticalComparisonView(
      final CaseIDAndEvidenceDescriptorID key)
      throws AppException, InformationalException {

    return curam.evidencebroker.sl.infrastructure.fact.EvidenceComparisonWidgetFactory
      .newInstance().getIdenticalEvidenceComparisonList(key);
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method returns the evidence records for identical evidence sharing
   * comparison view in an XML list form. The returned list contains the shared
   * evidence record and any active or in-edit records of the same evidence
   * type as the shared evidence record that are on the current case. The
   * current case is the case on which evidence is being synchronized.
   *
   * @param key Contains the case identifier and evidence descriptor identifier
   *
   * @return Non identical evidence data containing an XML representation of
   * the evidence records for use by the comparison view.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public NonIdenticalEvidenceComparisonData
    getEvidenceForNonIdenticalComparisonView(
      final CaseIDAndEvidenceDescriptorID key,
      final EvidenceTypeKey targetType)// BEGIN,
      // CR00121204,
      // VM
      throws AppException, InformationalException {

    return curam.evidencebroker.sl.infrastructure.fact.EvidenceComparisonWidgetFactory
      .newInstance().getNonIdenticalEvidenceComparisonList(key, targetType);
  }

  // END, CR00120297, CR00121204

  // BEGIN, CR00119958, CR00121204 CW, VM
  // BEGIN, CR00236468, GYH
  /**
   * @param synchronizeEvidenceDetails
   * Contains the details for synchronization
   *
   * @return List of validation / informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBroker#acceptIdenticalIncomingEvidence(EvidenceDescriptorKey)}
   * ,
   * {@link EvidenceBroker# rejectIdenticalIncomingEvidence(EvidenceDescriptorKey)}
   * ,
   * {@link EvidenceBroker#confirmResolvedNonIdenticalEvidence(EvidenceDescriptorKey)}
   * , {@link EvidenceBroker#acceptAllIdenticalIncomingEvidence(CaseID)} and
   * {@link EvidenceBroker#rejectAllIdenticalIncomingEvidence(CaseID)}.
   * This method has been deprecated because as part of evidence broker
   * usability changes the list evidence synchronization screen has been
   * enhanced to simple identical and non identical incoming evidence list
   * screens and hence now identical, non identical incoming evidence are
   * processed separately. Also, there is no widget processing is involved.
   * See release note:CR00236468.
   *
   * This method synchronizes the given list of identical or non identical
   * shared evidence records. Each piece of evidence can be either accepted,
   * rejected, resolved or ignored.
   */
  @Override
  @Deprecated
  // END, CR00236468
  public SynchronizeEvidenceResult synchronizeEvidence(
    final SynchronizeEvidenceDetails synchronizeEvidenceDetails)
    throws AppException, InformationalException {

    // Return object
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();

    // Call service layer to synchronize evidence
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance().synchronizeEvidence(synchronizeEvidenceDetails);

    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();

    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {

      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }

    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  // END, CR00114664, CR00119649, CR00120556, CR00121204

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the 'unable to complete
   * synchronization' link from the workflow activity created for identical
   * evidence synchronization. The user has indicated that the work related to
   * the task cannot be completed so the task will be closed and a notification
   * sent to the case supervisor.
   *
   * @param evidenceDescriptorKey Key containing the evidence descriptor ID
   * that is the unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void cannotCompleteIdenticalEvidenceSynchronization(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056
    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.IDENTICAL_EVIDENCE_NOT_SYNCHRONIZED;
    event.primaryEventData = evidenceDescriptorKey.evidenceDescriptorID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the 'synchronization
   * complete' link from the workflow activity created for identical evidence
   * synchronization. The user has indicated that all work related to the task
   * has been completed so the task will be closed.
   *
   * @param evidenceDescriptorKey Key containing the evidence descriptor ID
   * that is the unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void identicalEvidenceSynchronizationComplete(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.IDENTICAL_EVIDENCE_SYNCHRONIZED;
    event.primaryEventData = evidenceDescriptorKey.evidenceDescriptorID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the 'unable to complete
   * synchronization' link from the workflow activity created for non identical
   * evidence synchronization. The user has indicated that the work related to
   * the task cannot be completed so the task will be closed and a notification
   * sent to the case supervisor.
   *
   * @param evidenceDescriptorKey Key containing the evidence descriptor ID that
   * is the unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void cannotCompleteNonIdenticalEvidenceSynchronization(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.NONIDENTICAL_EVIDENCE_NOT_SYNCHRONIZED;
    event.primaryEventData = evidenceDescriptorKey.evidenceDescriptorID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the 'synchronization
   * complete' link from the workflow activity created for non identical
   * evidence synchronization. The user has indicated that all work related to
   * the task has been completed so the task will be closed.
   *
   * @param evidenceDescriptorKey Key containing the evidence descriptor ID
   * that is the unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void nonIdenticalEvidenceSynchronizationComplete(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.NONIDENTICAL_EVIDENCE_SYNCHRONIZED;
    event.primaryEventData = evidenceDescriptorKey.evidenceDescriptorID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the supervisor selects the
   * 'I have resolved all issues' link on the evidence synchronization task
   * that is assigned to the supervisor when the case owner cannot synchronize
   * the evidence record due to unresolved issues. The supervisor has indicated
   * that all issues have been resolved so the task will be closed.
   *
   * @param evidenceDescriptorKey Key containing the evidence descriptor ID
   * that is the unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void supervisorEvidenceSynchronizeTaskComplete(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.SUPERVISOR_SYNCHRONIZE_TASK_COMPLETE;
    event.primaryEventData = evidenceDescriptorKey.evidenceDescriptorID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the
   * 'unable to complete synchronization' link from the workflow activity
   * created for case participant creation evidence synchronization.
   * The task relates to all evidence requiring synchronization on the case.
   * The user has indicated that the work related to the task cannot be
   * completed so the task will be closed and a task sent to the case
   * supervisor.
   *
   * @param caseHeaderKey Key containing the case identifier that is the unique
   * identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void cannotCompleteCaseParticipantCreationSynchronization(
    final CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    if (CuramConst.gkZero != caseHeaderKey.caseID) {

      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.CASE_CREATION_EVIDENCE_NOT_SYNCHRONIZED;
    event.primaryEventData = caseHeaderKey.caseID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the user selects the 'synchronization complete'
   * link from the workflow activity created for case participant creation
   * evidence synchronization. The task relates to all evidence requiring
   * synchronization on the case. The user has indicated that all work related
   * to the task has been completed so the task will be closed.
   *
   * @param caseHeaderKey Key containing the case identifier that is the unique
   * identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void caseParticipantCreationSynchronizationComplete(
    final CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    if (CuramConst.gkZero != caseHeaderKey.caseID) {

      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey = EVIDENCEBROKER.CASE_CREATION_EVIDENCE_SYNCHRONIZED;
    event.primaryEventData = caseHeaderKey.caseID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method is invoked when the supervisor selects the
   * 'I have resolved all issues' link on the case creation evidence
   * synchronization task that is assigned to the supervisor when the case
   * owner cannot synchronize the case creation evidence due to unresolved
   * issues. The supervisor has indicated that all issues have been resolved
   * so the task will be closed.
   *
   * @param caseHeaderKey Key containing the case identifier that is the
   * unique identifier of the task.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  @Override
  public void supervisorCaseParticipantCreationSynchronizeTaskComplete(
    final CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    // BEGIN, CR00428056, KRK
    if (CuramConst.gkZero != caseHeaderKey.caseID) {

      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    // Raise the event to close the task
    final Event event = new Event();

    event.eventKey =
      EVIDENCEBROKER.SUPERVISOR_CASE_CREATION_SYNCHRONIZE_TASK_COMPLETE;
    event.primaryEventData = caseHeaderKey.caseID;

    EventService.raiseEvent(event);
  }

  // END, CR00114568

  // BEGIN, CR00120556, CW
  // BEGIN, CR00236468, GYH
  /**
   * @link EvidenceBroker#listNonIdenticalIncomingEvidence(CaseID)}.
   * This method has been deprecated because as part of evidence broker
   * usability changes the list evidence synchronization screen has been
   * enhanced to simple identical and non identical incoming evidence list
   * screens and hence now identical, non identical incoming evidence are
   * processed separately. Also, there is no widget processing is involved.
   * See release note: CR00236468.
   *
   *
   * This method returns the evidence records for the current case for display
   * on the evidence sharing synchronize screen. The current case is the case
   * on which evidence is being synchronized. The method returns the identical
   * sharing evidence records in XML form for display on the identical sharing
   * evidence widget, and the non identical sharing evidence records in list
   * form for display on the non identical sharing evidence list.
   * @param caseIDKey
   * Key containing the case ID of the current case.
   *
   * @return The evidence details for synchronization display
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBroker#listIdenticalIncomingEvidence(CaseID) and
   */
  @Override
  @Deprecated
  // END, CR00236468
  public EvidenceSynchronizationViewDetails getEvidenceForSynchronizeView(
    final curam.core.facade.struct.CaseID caseIDKey)
    throws AppException, InformationalException {

    // Initialize return object
    final EvidenceSynchronizationViewDetails evidenceSynchronizationViewDetails =
      new EvidenceSynchronizationViewDetails();

    // Retrieve the identical evidence records for the case
    final IdenticalEvidenceSearchKey identicalEvidenceSearchKey =
      new IdenticalEvidenceSearchKey();

    identicalEvidenceSearchKey.caseID = caseIDKey.dtls.caseID;

    final IdenticalEvidenceSynchronizationDetailsList identicalEvidenceSynchronizationDetailsList =
      new IdenticalEvidenceSynchronizationDetailsList();

    // Retrieve the evidence for identical sharing synchronization
    final curam.core.sl.infrastructure.struct.List identicalEvidenceSyncList =
      curam.evidencebroker.sl.infrastructure.fact.EvidenceSynchronizationWidgetFactory
        .newInstance()
        .getIdenticalEvidenceSynchronizationList(identicalEvidenceSearchKey);

    // Identical evidence sharing records are returned to the client in
    // XML format for widget display
    final StructToXML structToXML = new StructToXML();

    // Convert the service layer data to a facade list
    try {
      identicalEvidenceSynchronizationDetailsList.contentXML =
        structToXML.convert(identicalEvidenceSyncList, CuramConst.gkEmpty);
    } catch (final Exception e) {// Do nothing
    }

    // Set the identical evidence records on the return struct
    evidenceSynchronizationViewDetails.identicalEvidenceSynchronizationDetailsList =
      identicalEvidenceSynchronizationDetailsList;

    // Retrieve the non identical evidence records for the case

    final CaseID caseID = new CaseID();

    caseID.caseID = caseIDKey.dtls.caseID;

    final NonIdenticalEvidenceSynchronizationDetailsList nonIdenticalEvidenceSynchronizationDetailsList =
      curam.evidencebroker.sl.infrastructure.fact.EvidenceSynchronizationWidgetFactory
        .newInstance().getNonIdenticalEvidenceSynchronizationList(caseID);

    // Set the non identical evidence records on the return struct
    evidenceSynchronizationViewDetails.nonIdenticalEvidenceSynchronizationDetailsList =
      nonIdenticalEvidenceSynchronizationDetailsList;

    // BEGIN, CR00121427, CW
    // Obtain the context description
    // for the case onto which evidence is being synchronized
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseIDKey.dtls.caseID;

    final curam.core.facade.infrastructure.intf.Evidence evidenceObj =
      curam.core.facade.infrastructure.fact.EvidenceFactory.newInstance();

    final EvidenceContextDescription contextDescription =
      evidenceObj.getContextDescription(caseKey);

    // Set the context description on the return struct
    evidenceSynchronizationViewDetails.contextDescription =
      contextDescription;
    // END, CR00121427

    return evidenceSynchronizationViewDetails;
  }

  // END, CR00120556

  // BEGIN, CR00236468, GYH
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Returns list of identical incoming evidence for a case to accept or
   * reject the incoming evidence onto the case in process.
   *
   * @param key
   * Contains case identifier.
   *
   * @return List of identical incoming evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IncomingEvidenceDetailsList
    listIdenticalIncomingEvidence(final curam.core.facade.struct.CaseID key)
      throws AppException, InformationalException {

    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = key.dtls.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    return curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance().listIncomingEvidence(caseIDAndStatusKey);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Returns list of non identical incoming evidence for a case to accept or
   * reject the incoming evidence onto the case in process.
   *
   * @param key
   * Contains case identifier.
   *
   * @return List of non identical incoming evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IncomingEvidenceDetailsList listNonIdenticalIncomingEvidence(
    final curam.core.facade.struct.CaseID key)
    throws AppException, InformationalException {

    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = key.dtls.caseID;
    caseIDAndStatusKey.statusCode =
      EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    return curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance().listIncomingEvidence(caseIDAndStatusKey);
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Accepts identical incoming evidence onto a case in process. After accepting
   * the incoming evidence, any outstanding incoming evidence tasks which are
   * related to the evidence being accepted would be closed. Also, returns
   * warning
   * messages if there are any warnings during the process of incoming evidence
   * acceptance.
   *
   * @param key
   * Contains evidence descriptor identifier.
   *
   * @return Returns warning messages if there are any warnings during the
   * process of incoming evidence acceptance..
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public SynchronizeEvidenceResult
    acceptIdenticalIncomingEvidence(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndActionKey =
      new EvidenceDescriptorIDAndSynchronizeAction();

    evidenceDescriptorIDAndActionKey.evidenceDescriptorID =
      key.evidenceDescriptorID;
    evidenceDescriptorIDAndActionKey.action = SYNCHRONIZATIONACTION.ACCEPT;
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList =
      new EvidenceDescriptorIDAndSynchronizeActionList();

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(key);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    evidenceDescriptorIDAndActionList.dtlsList
      .addRef(evidenceDescriptorIDAndActionKey);
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .processIncomingEvidence(evidenceDescriptorIDAndActionList);

    // Check if there any warnings and return
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();
    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();
    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }
    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Rejects identical incoming evidence onto a case in process. After
   * successfully rejecting
   * the incoming evidence, any outstanding tasks which are
   * related to the evidence being rejected would be closed. Also, returns
   * warning
   * messages if there are any warnings during the process of incoming evidence
   * rejection.
   *
   * @param key
   * Contains evidence descriptor identifier.
   *
   * @return Returns warning messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public SynchronizeEvidenceResult
    rejectIdenticalIncomingEvidence(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndActionKey =
      new EvidenceDescriptorIDAndSynchronizeAction();

    evidenceDescriptorIDAndActionKey.evidenceDescriptorID =
      key.evidenceDescriptorID;
    evidenceDescriptorIDAndActionKey.action = SYNCHRONIZATIONACTION.REJECT;
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList =
      new EvidenceDescriptorIDAndSynchronizeActionList();

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(key);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    evidenceDescriptorIDAndActionList.dtlsList
      .addRef(evidenceDescriptorIDAndActionKey);
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .processIncomingEvidence(evidenceDescriptorIDAndActionList);

    // Check if there any warnings and return
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();
    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();
    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }
    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Marks the status of non identical incoming evidence as resolved. After
   * successfully updating the status of non incoming evidence as resolved, any
   * outstanding
   * tasks which are related to the evidence being resolved
   * would be closed. Also, returns warning messages if there are any warnings
   * during the process this process.
   *
   * @param key
   * Contains evidence descriptor identifier.
   *
   * @return Returns warning messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public SynchronizeEvidenceResult
    confirmResolvedNonIdenticalEvidence(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndActionKey =
      new EvidenceDescriptorIDAndSynchronizeAction();

    evidenceDescriptorIDAndActionKey.evidenceDescriptorID =
      key.evidenceDescriptorID;
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList =
      new EvidenceDescriptorIDAndSynchronizeActionList();

    // BEGIN, CR00428056, KRK
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(key);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != evidenceDescriptorDtls.caseID) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    evidenceDescriptorIDAndActionList.dtlsList
      .addRef(evidenceDescriptorIDAndActionKey);
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .processIncomingEvidence(evidenceDescriptorIDAndActionList);

    // Check if there any warnings and return
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();
    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();
    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }
    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Accepts all identical incoming evidence onto a case in process. After
   * successfully accepting
   * all incoming evidences, any outstanding tasks which are
   * related to the evidences being accepted would be closed. Also, returns
   * warning
   * messages if there are any warnings during the process of incoming evidence
   * acceptance.
   *
   * @param key
   * Contains case identifier.
   *
   * @return Returns warning messages if there are any warnings during the
   * process of incoming evidence acceptance..
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public SynchronizeEvidenceResult acceptAllIdenticalIncomingEvidence(
    final curam.core.facade.struct.CaseID key)
    throws AppException, InformationalException {

    // Get list of all identical incoming evidence for the given case.
    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    // BEGIN, CR00428056, KRK
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != key.dtls.caseID) {

      caseHeaderKey.caseID = key.dtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    caseIDAndStatusKey.caseID = key.dtls.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    final IncomingEvidenceDetailsList incomingEvidenceDetailsList =
      curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
        .newInstance().listIncomingEvidence(caseIDAndStatusKey);

    // Accept all identical incoming evidence onto a case being passed.
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList =
      new EvidenceDescriptorIDAndSynchronizeActionList();

    for (final IncomingEvidenceDetails incomingEvidenceDetails : incomingEvidenceDetailsList.details
      .items()) {
      final EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndAction =
        new EvidenceDescriptorIDAndSynchronizeAction();

      evidenceDescriptorIDAndAction.evidenceDescriptorID =
        incomingEvidenceDetails.evidenceDescriptorID;
      evidenceDescriptorIDAndAction.action = SYNCHRONIZATIONACTION.ACCEPT;
      evidenceDescriptorIDAndActionList.dtlsList
        .addRef(evidenceDescriptorIDAndAction);
    }
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .processIncomingEvidence(evidenceDescriptorIDAndActionList);

    // Check if there any warnings and return
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();
    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();
    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }
    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Rejects all identical incoming evidence onto a case in process. After
   * successfully rejecting all incoming evidences, any outstanding tasks which
   * are related to the evidence being rejected would be closed. Also, returns
   * warning messages if there are any warnings during the process of incoming
   * evidence rejection.
   *
   * @param key
   * Contains case identifier.
   *
   * @return Returns warning messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public SynchronizeEvidenceResult rejectAllIdenticalIncomingEvidence(
    final curam.core.facade.struct.CaseID key)
    throws AppException, InformationalException {

    // Get list of all identical incoming evidence for the given case.
    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    // BEGIN, CR00428056, KRK
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (CuramConst.gkZero != key.dtls.caseID) {

      caseHeaderKey.caseID = key.dtls.caseID;
      performSecurityChecks(caseHeaderKey, kUserMaintain);
    }
    // END, CR00428056

    caseIDAndStatusKey.caseID = key.dtls.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    final IncomingEvidenceDetailsList incomingEvidenceDetailsList =
      curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
        .newInstance().listIncomingEvidence(caseIDAndStatusKey);

    // Reject all identical incoming evidence and remove from the incoming
    // evidence list.
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList =
      new EvidenceDescriptorIDAndSynchronizeActionList();

    for (final IncomingEvidenceDetails incomingEvidenceDetails : incomingEvidenceDetailsList.details
      .items()) {
      final EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndAction =
        new EvidenceDescriptorIDAndSynchronizeAction();

      evidenceDescriptorIDAndAction.evidenceDescriptorID =
        incomingEvidenceDetails.evidenceDescriptorID;
      // BEGIN, CR00405870, SSK
      evidenceDescriptorIDAndAction.action = SYNCHRONIZATIONACTION.REJECT;
      // END, CR00405870
      evidenceDescriptorIDAndActionList.dtlsList
        .addRef(evidenceDescriptorIDAndAction);
    }
    curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .processIncomingEvidence(evidenceDescriptorIDAndActionList);

    // Check if there any warnings and return
    final SynchronizeEvidenceResult synchronizeEvidenceResult =
      new SynchronizeEvidenceResult();
    final InformationalMsgDtlsList msgDtlsList =
      new InformationalMsgDtlsList();
    final ECWarningsDtlsList warnings =
      EvidenceControllerFactory.newInstance().getWarnings();

    for (int i = 0; i < warnings.dtls.size(); i++) {
      final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

      msgDtls.informationMsgTxt = warnings.dtls.item(i).msg;
      msgDtlsList.dtls.addRef(msgDtls);
    }
    synchronizeEvidenceResult.informationalMsgDtlsList = msgDtlsList;

    return synchronizeEvidenceResult;
  }

  // END, CR00236468
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Lists the verification item provided associated with the incoming evidence.
   *
   * @param evidenceVerificationItemDetails
   * Contains incoming evidence details.
   *
   * @return The list of verification item provided for the incoming evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public VerificationItemProvidedDetailsList
    listVerificationItemProvidedForIncomingEvidence(
      final EvidenceVerificationItemDetails evidenceVerificationItemDetails)
      throws AppException, InformationalException {

    final EvidenceVerificationDetails evidenceVerificationDetails =
      new EvidenceVerificationDetails();

    evidenceVerificationDetails.relatedID =
      evidenceVerificationItemDetails.caseID;
    evidenceVerificationDetails.evidenceDescriptorID =
      evidenceVerificationItemDetails.evidenceDescriptorID;
    evidenceVerificationDetails.vdIEDLinkID =
      evidenceVerificationItemDetails.vDIEDLinkID;

    // BEGIN, CR00426922, KRK
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceVerificationItemDetails.evidenceDescriptorID;
    VerificationItemProvidedDetailsList verificationItemProvidedDetailsList =
      new VerificationItemProvidedDetailsList();

    final CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList =
      CurrentPostponedVerificationFactory.newInstance()
        .searchByEvidenceDescriptorID(evidenceDescriptorKey);

    if (currentPostponedVerificationDtlsList.dtls.isEmpty()) {
      verificationItemProvidedDetailsList =
        evidenceVerification.getVerificationImpl()
          .listVerificationItemProvidedForIncomingEvidence(
            evidenceVerificationDetails);
    }

    return verificationItemProvidedDetailsList;
    // END, CR00426922
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Lists the verifications for the incoming evidence.
   *
   * @param caseIDAndEvidenceTypeDetails
   * Contains the case and evidence type details.
   *
   * @return The list of verifications for the incoming evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public VerificationDetailsForIncomingEvidenceList
    listVerificationsForIncomingEvidence(
      final CaseIDAndEvidenceTypeDetails caseIDAndEvidenceTypeDetails)
      throws AppException, InformationalException {

    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
      new CaseIDAndEvidenceTypeKey();

    // BEGIN, CR00427012, KRK
    VerificationDetailsForIncomingEvidenceList verificationDetailsForIncomingEvidenceList =
      new VerificationDetailsForIncomingEvidenceList();

    caseIDAndEvidenceTypeKey.caseID = caseIDAndEvidenceTypeDetails.caseID;
    caseIDAndEvidenceTypeKey.evidenceType =
      caseIDAndEvidenceTypeDetails.evidenceType;

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      caseIDAndEvidenceTypeDetails.evidenceDescriptorID;

    final CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList =
      CurrentPostponedVerificationFactory.newInstance()
        .searchByEvidenceDescriptorID(evidenceDescriptorKey);

    if (currentPostponedVerificationDtlsList.dtls.isEmpty()) {

      final VerificationDetailsForIncomingEvidenceList verificationDetailsList =
        evidenceVerification.getVerificationImpl()
          .listVerificationsForIncomingEvidence(caseIDAndEvidenceTypeKey,
            evidenceDescriptorKey);

      final EvidenceDescriptorDtls evidenceDescriptorDtls =
        EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

      caseIDAndEvidenceTypeKey.caseID =
        caseIDAndEvidenceTypeDetails.targetCaseID;
      if (StringUtil
        .isNullOrEmpty(caseIDAndEvidenceTypeDetails.targetEvidenceType)) {
        caseIDAndEvidenceTypeKey.evidenceType =
          evidenceDescriptorDtls.evidenceType;
      } else {
        caseIDAndEvidenceTypeKey.evidenceType =
          caseIDAndEvidenceTypeDetails.targetEvidenceType;
      }
      // BEGIN, CR00377613, AKr
      verificationDetailsForIncomingEvidenceList = evidenceVerification
        .getVerificationImpl()
        .checkVerificationRequirementsForTargetCase(caseIDAndEvidenceTypeKey,
          evidenceDescriptorKey, verificationDetailsList);

      final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls =
        getEvidenceBrokerConfig(caseIDAndEvidenceTypeDetails);

      if (VERIFICATIONSHAREOPTION.IF_APPLICABLE
        .equals(evidenceBrokerConfigDtls.shareVerificationsOption)) {
        final VerificationDetailsForIncomingEvidenceList filteredList =
          new VerificationDetailsForIncomingEvidenceList();

        for (final VerificationDetailsForIncomingEvidence verificationDetailsForIncomingEvidence : verificationDetailsForIncomingEvidenceList.dtls
          .items()) {
          if (verificationDetailsForIncomingEvidence.isApplicable) {
            filteredList.dtls.addRef(verificationDetailsForIncomingEvidence);
          }
        }
        return filteredList;
      } else {
        return verificationDetailsForIncomingEvidenceList;
      }
      // END, CR00377613
    } else {
      return verificationDetailsForIncomingEvidenceList;
    }
    // END, CR00427012
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Lists the identical incoming evidence along with verifications.
   *
   * @param caseID Contains the case ID.
   *
   * @return The list of incoming evidence and source case details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IncomingEvidenceAndSourceCaseDetailsList
    listIdenticalIncomingEvidenceWithVerifications(
      final curam.core.facade.struct.CaseID caseID)
      throws AppException, InformationalException {

    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = caseID.dtls.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    return curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .listIncomingEvidenceWithVerificationDetails(caseIDAndStatusKey);
  }

  // BEGIN, CR00348300, RPB

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method returns the evidence records for identical evidence in the form
   * of a multiple selection widget. The returned list contains any active or
   * in-edit records of the same evidence type as the shared evidence record
   * that are on the current case. The current case is the case on which
   * evidence is being synchronized.
   *
   * @param key
   * Contains the case identifier and evidence descriptor identifier.
   *
   * @return List of evidences to be compared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IdenticalEvidencesListForComparison
    getIdenticalEvidencesForComparison(
      final CaseIDAndEvidenceDescriptorID key)
      throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final IdenticalEvidencesListForComparison identicalEvidencesListForComparison =
      new IdenticalEvidencesListForComparison();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);
    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = key.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidenceCaseKey.evidenceKey.evType = evidenceDescriptorDtls.evidenceType;

    final EIEvidenceKey[] eiEvidenceKeyList = processEvidenceHelper
      .getRecordsToCompare(evidenceCaseKey, null, true).dtls.items();

    final long sourceEvidenceID = evidenceDescriptorDtls.relatedID;

    for (final EIEvidenceKey eiEvidenceKey : eiEvidenceKeyList) {
      if (sourceEvidenceID != eiEvidenceKey.evidenceID) {
        final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
          new RelatedIDAndEvidenceTypeKey();

        relatedIDAndEvidenceTypeKey.relatedID = eiEvidenceKey.evidenceID;
        relatedIDAndEvidenceTypeKey.evidenceType = eiEvidenceKey.evidenceType;
        final EvidenceDescriptorDtls evDescriptorDtls = evidenceDescriptorObj
          .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

        evidenceDescriptorKey = new EvidenceDescriptorKey();
        evidenceDescriptorKey.evidenceDescriptorID =
          evDescriptorDtls.evidenceDescriptorID;
        final ChangeUserDetails changeUserDetails =
          EvidenceChangeHistoryFactory.newInstance()
            .readUserForLatestChange(evidenceDescriptorKey);
        final LocalisableString latestActivity =
          new LocalisableString(BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

        latestActivity.arg(changeUserDetails.changeUser);
        latestActivity.arg(changeUserDetails.changeDateTime);
        final EvidenceTypeAndDesc evidenceTypeAndDesc =
          new EvidenceTypeAndDesc();

        evidenceTypeAndDesc.evidenceType = eiEvidenceKey.evidenceType;
        final SuccessionID successionID = new SuccessionID();

        successionID.successionID = evDescriptorDtls.successionID;
        final MostRecentBusinessObjectChangesDetailsList mostRecentBusinessObjectChangesDetailsList =
          evidenceDescriptorObj
            .searchMostRecentBusinessObjectChanges(successionID);
        final int listSize =
          mostRecentBusinessObjectChangesDetailsList.dtls.size();
        MostRecentBusinessObjectChangesDetails changeDetails =
          new MostRecentBusinessObjectChangesDetails();

        if (listSize > 0) {
          changeDetails =
            mostRecentBusinessObjectChangesDetailsList.dtls.iterator().next();
        }

        final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
          processEvidenceHelper.getEvidenceSummaryDetails(eiEvidenceKey);
        final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

        evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
        String changeDescription = null;
        String participantName = CuramConst.gkEmpty;

        // for participant evidence the change reason does not apply
        if (isEvidenceParticipantData(evidenceTypeKey)) {
          final LocalisableString description = new LocalisableString(
            BPOEVIDENCECONTROLLER.INF_DESCRIPTION_PARTICIPANT);

          description.arg(evidenceDescriptorDtls.receivedDate);
          changeDescription = description.toClientFormattedText();

        } else {
          final LocalisableString description =
            new LocalisableString(BPOEVIDENCECONTROLLER.INF_DESCRIPTION);

          description.arg(evidenceDescriptorDtls.receivedDate);
          description
            .arg(new CodeTableItemIdentifier(EVIDENCECHANGEREASON.TABLENAME,
              evidenceDescriptorDtls.changeReason));
          changeDescription = description.toClientFormattedText();
        }

        // Get the participant name and populate to return structure
        if (evidenceDescriptorDtls.participantID != 0) {
          final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

          concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
          participantName = ConcernRoleFactory.newInstance()
            .readConcernRoleName(concernRoleKey).concernRoleName;
        }
        final IdenticalEvidenceDetails identicalEvidenceDetails =
          new IdenticalEvidenceDetails();

        identicalEvidenceDetails.caseMemberName = participantName;
        // BEGIN, CR00367374, CSH
        identicalEvidenceDetails.summary = LocalizableXMLStringHelper
          .toClientFormattedText(eiFieldsForListDisplayDtls.summary);
        // END, CR00367374
        identicalEvidenceDetails.changeDescription = changeDescription;
        identicalEvidenceDetails.latestActivity =
          processEvidenceHelper.getEvidencePeriodUpdateCountAndLatestAct(
            successionID).latestActivity;
        identicalEvidenceDetails.updates = processEvidenceHelper
          .getEvidencePeriodUpdateCountAndLatestAct(successionID).updateCount;
        identicalEvidenceDetails.evidenceID = eiEvidenceKey.evidenceID;
        identicalEvidencesListForComparison.dtls
          .add(identicalEvidenceDetails);
      }
    }
    return identicalEvidencesListForComparison;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Accepts the given list of identical evidence identifiers and persists them
   * to a wizard table and returns the corresponding wizard identifier.
   *
   * @param key
   * Contains identifiers of the selected evidences, separated by tab.
   *
   * @return Wizard information after persisting the input data.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public WizardInfo getSelectedIdenticalEvidencesToWizard(
    final curam.evidencebroker.facade.struct.SelectedEvidenceTab key)
    throws AppException, InformationalException {

    final WizardInfo wizardInfo = new WizardInfo();

    // If the action string is NEXT.
    if (key.actionString.equalsIgnoreCase(CuramConst.NEXT_ACTION)) {
      final String[] itemsArray =
        key.selectedEvidencesList.split(CuramConst.gkTabDelimiter);

      // At least one item must be selected
      if (key.selectedEvidencesList.equalsIgnoreCase(CuramConst.gkEmpty)) {
        final AppException appException = new AppException(
          BPOEVIDENCEBROKER.ERR_EVIDENCE_IDENTICAL_COMPARISON_NO_ITEM_SELECTED);

        throw appException;
      }

      // If the number of items selected is more than the maximum number
      // allowed, throw a validation
      if (itemsArray.length > EvidenceBrokerConst.kMaxNumberOfIdenticalEvidencesForComparison) {
        final AppException appException = BPOEVIDENCEBROKERExceptionCreator
          .ERR_EVIDENCE_IDENTICAL_COMPARISON_MORE_THAN_MAXIMUM_ALLOWED_NUMBER_SELECTED(
            EvidenceBrokerConst.kMaxNumberOfIdenticalEvidencesForComparison
              + CuramConst.gkEmpty);

        throw appException;
      }

      final WizardPersistentState wizardPersistentState =
        new WizardPersistentState();

      // if wizard id is zero, data is fresh and persist in the wizard
      // table.
      if (key.wizardID == 0) {
        wizardInfo.wizardID =
          wizardPersistentState.create(key.selectedEvidencesList);
      } // if wizard id is not zero, user went to the next page and came
      // back. Hence modify the old data from the wizard table to persist the
      // new modified data.
      else {
        wizardInfo.wizardID = key.wizardID;
        wizardPersistentState.modify(key.wizardID, key.selectedEvidencesList);
      }
    }
    return wizardInfo;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets the context details such as type of the evidence being compared.
   *
   * @param key
   * Contains the case identifier and evidence descriptor identifier.
   * @param wizardInfo
   * Contains the wizard identifier.
   *
   * @return Context details such as type of the evidence being compared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IdenticalEvidenceComparisonDetails
    getContextDetailsForIdenticalEvidenceComparison(
      final curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceDescriptorID key,
      final WizardInfo wizardInfo) throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);
    final IdenticalEvidenceComparisonDetails identicalEvidenceComparisonDetails =
      new IdenticalEvidenceComparisonDetails();

    identicalEvidenceComparisonDetails.evidenceTypeCode =
      evidenceDescriptorDtls.evidenceType;
    identicalEvidenceComparisonDetails.numberOfEvidences =
      getIdenticalEvidencesForComparison(key).dtls.size();
    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();

    if (wizardInfo.wizardID != 0) {
      identicalEvidenceComparisonDetails.preSelectedEvidencesList =
        (String) wizardPersistentState.read(wizardInfo.wizardID);
    }
    return identicalEvidenceComparisonDetails;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * This method returns the selected evidence records for identical evidence
   * sharing comparison view in an XML list form. The returned list contains the
   * shared evidence record and selected active or in-edit records of the same
   * evidence type as the shared evidence record that are on the current case.
   * The current case is the case on which evidence is being synchronized.
   *
   * @param wizardInfo
   * Contains the wizard identifier.
   *
   * @param key
   * Contains the case identifier and evidence descriptor identifier.
   * @return Identical comparison data containing an XML representation of the
   * evidence records for use by the comparison view.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IdenticalEvidenceComparisonData
    getSelectedIdenticalEvidenceComparison(final WizardInfo wizardInfo,
      final CaseIDAndEvidenceDescriptorID key)
      throws AppException, InformationalException {

    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();
    final long stateID = wizardInfo.wizardID;
    final String evidencesSelected =
      (String) wizardPersistentState.read(stateID);
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);
    final EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = key.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidenceCaseKey.evidenceKey.evType = evidenceDescriptorDtls.evidenceType;
    final IdenticalEvidenceComparisonData identicalEvidenceComparisonData =
      new IdenticalEvidenceComparisonData();

    identicalEvidenceComparisonData.comparisonData =
      curam.evidencebroker.sl.infrastructure.fact.EvidenceComparisonWidgetFactory
        .newInstance().getComparisonDataForSelectedItems(evidenceCaseKey,
          null, true, evidenceDescriptorDtls.externalSourceCaseInd,
          evidencesSelected).data;
    return identicalEvidenceComparisonData;
  }

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Determines if the evidence type is of type 'Participant Data'.
   *
   * @param key
   * Contains the type of the participant data E.g. Person
   *
   * @return Returns <code>true</code> if the evidence is of type 'Participant
   * Data'. Otherwise <code>false</code>.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  protected boolean isEvidenceParticipantData(final EvidenceTypeKey key)
    throws AppException, InformationalException {

    return evidenceTypeNatureMap
      .get(evidenceNature
        .getEvidenceNatureCode(CASEEVIDENCEEntry.get(key.evidenceType)))
      .isParticipantEvidence(CASEEVIDENCEEntry.get(key.evidenceType));
  }

  // END, CR00348300

  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Lists the non identical incoming evidence with verifications.
   *
   * @param caseID Contains the case ID details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  @Override
  public IncomingEvidenceAndSourceCaseDetailsList
    listNonIdenticalIncomingEvidenceWithVerifications(
      final curam.core.facade.struct.CaseID caseID)
      throws AppException, InformationalException {

    final CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = caseID.dtls.caseID;
    caseIDAndStatusKey.statusCode =
      EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    return curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory
      .newInstance()
      .listIncomingEvidenceWithVerificationDetails(caseIDAndStatusKey);
  }

  // BEGIN, CR00377613, AKr
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Gets the Evidence Broker COnfiguration Details for the passed in evidence
   * and case details.
   *
   * @param caseIDAndEvidenceTypeDetails
   * The details of the source and target evidence and the case.
   *
   * @return the evidence broker configuration details that exist for the pair
   * of evidence details passed in.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationException
   * Generic Exception Signature.
   */
  @Deprecated
  protected EvidenceBrokerConfigDtls getEvidenceBrokerConfig(
    final CaseIDAndEvidenceTypeDetails caseIDAndEvidenceTypeDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00451875, MR
    EvidenceBrokerConfigDtls evidenceBrokerConfigDtls =
      new EvidenceBrokerConfigDtls();
    // END, CR00451875
    final EvidenceSharingConfigKey key = new EvidenceSharingConfigKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDAndEvidenceTypeDetails.targetCaseID;

    final SharedEvidenceSourceTypeAndSourceIDDetails targetTypeAndTargetID =
      processEvidenceHelper.getSharingTargetTypeAndTargetID(
        CaseHeaderFactory.newInstance().read(caseHeaderKey));

    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      new EvidenceDescriptorDtls();

    evidenceDescriptorDtls.caseID = caseIDAndEvidenceTypeDetails.caseID;
    evidenceDescriptorDtls.evidenceType =
      caseIDAndEvidenceTypeDetails.evidenceType;

    final SharedEvidenceSourceTypeAndSourceIDDetails sourceTypeAndSourceID =
      processEvidenceHelper
        .getSharingSourceTypeAndSourceID(evidenceDescriptorDtls);

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      caseIDAndEvidenceTypeDetails.evidenceDescriptorID;
    // BEGIN, CR00379281, AKr
    if (!(EvidenceDescriptorFactory.newInstance()
      .read(evidenceDescriptorKey).statusCode
        .equals(EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT)
      || EvidenceDescriptorFactory.newInstance()
        .read(evidenceDescriptorKey).statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.NONIDENTICALRESOLVED))) {
      key.sharedType = EVIDENCESHARINGTYPE.IDENTICAL;
      key.targetEvidenceType = caseIDAndEvidenceTypeDetails.evidenceType;
    } else {
      key.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;
      key.targetEvidenceType =
        caseIDAndEvidenceTypeDetails.targetEvidenceType;
    }
    // END, CR00379281
    key.targetType = targetTypeAndTargetID.sourceType;
    key.targetID = targetTypeAndTargetID.sourceID;
    key.recordStatus = RECORDSTATUS.NORMAL;
    key.sourceEvidenceType = caseIDAndEvidenceTypeDetails.evidenceType;
    key.sourceType = sourceTypeAndSourceID.sourceType;
    key.sourceID = sourceTypeAndSourceID.sourceID;

    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlslist =
      curam.evidencebroker.sl.fact.EvidenceBrokerConfigAdminFactory
        .newInstance().listSharedSourceAndTargetEvidences(key);

    // BEGIN, CR00451875, MR
    if (1 < evidenceBrokerConfigDtlslist.dtls.size()) {
      final AppException e = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST);

      e.arg(CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        caseIDAndEvidenceTypeDetails.evidenceType,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(e,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } else if (1 == evidenceBrokerConfigDtlslist.dtls.size()) {
      evidenceBrokerConfigDtls = evidenceBrokerConfigDtlslist.dtls.item(0);

    } else if (0 == evidenceBrokerConfigDtlslist.dtls.size()) {

      final SharedVERItemProvided sharedVERItemProvidedObj =
        SharedVERItemProvidedFactory.newInstance();
      final curam.verification.sl.infrastructure.struct.TargetEvidenceDescriptorKey targetEvidenceDescriptorkey =
        new TargetEvidenceDescriptorKey();

      targetEvidenceDescriptorkey.targetEvidenceDescriptorID =
        evidenceDescriptorKey.evidenceDescriptorID;
      final curam.verification.sl.infrastructure.struct.SharedVERItemProvidedDtlsList sharedVERItemProvidedDtlsList =
        sharedVERItemProvidedObj
          .searchByEvidenceDescriptorID(targetEvidenceDescriptorkey);

      if (sharedVERItemProvidedDtlsList.dtls.size() > 0) {
        final String shareVerificationOption =
          sharedVERItemProvidedDtlsList.dtls.item(0).shareVerificationsOption;

        evidenceBrokerConfigDtls.shareVerificationsOption =
          shareVerificationOption;
      }
    }

    return evidenceBrokerConfigDtls;
    // END, CR00451875
  }

  // BEGIN, CR00428056, KRK
  /**
   * @deprecated Since 7.0.2.0 functionality has been replaced by component
   * AdvancedEvidenceSharing.
   *
   * Performs the location and case security checks.
   *
   * @param caseHeaderKey
   * Contains the relevant case ID for which the security checks will
   * be performed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  protected void performSecurityChecks(final CaseHeaderKey caseHeaderKey,
    final int checkSecurityType) throws AppException, InformationalException {

    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = caseHeaderKey.caseID;

    if (kUserRead == checkSecurityType) {
      caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;
    } else {
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;
    }

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
  }
  // END, CR00428056

}
