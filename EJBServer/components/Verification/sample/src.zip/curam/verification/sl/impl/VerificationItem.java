/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.verification.sl.entity.fact.VerificationItemFactory;
import curam.verification.sl.entity.struct.VerificationItemKey;
import curam.verification.sl.struct.CancelVerificationItemDetails;
import curam.verification.sl.struct.CreateVerificationItemDetails;
import curam.verification.sl.struct.ListVerificationItemDetails;
import curam.verification.sl.struct.ListVerificationItemIDAndNameDetails;
import curam.verification.sl.struct.ModifyVerificationItemDetails;
import curam.verification.sl.struct.ReadVerificationItemDetails;


/**
 * This process class provides the functionality for the Verification Item
 * service layer.
 */
public abstract class VerificationItem extends curam.verification.sl.base.VerificationItem {

  // ___________________________________________________________________________
  /**
   * List all Verification Items.
   *
   */
  @Override
  public ListVerificationItemDetails listVerificationItem()
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = curam.verification.sl.entity.fact.VerificationItemFactory.newInstance();

    final ListVerificationItemDetails listVerificationItemDetails = new ListVerificationItemDetails();

    listVerificationItemDetails.listDtls = verificationItemObj.listVerificationItemDetails();

    return listVerificationItemDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a Verification Item record.
   *
   * @param details Verification Item details.
   */
  @Override
  public void cancelVerificationItem(CancelVerificationItemDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = VerificationItemFactory.newInstance();

    // Create and populate the Verification Item key
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    verificationItemKey.verificationItemID = details.cancelDtls.verificationItemID;

    // Cancel a Verification Item.
    verificationItemObj.cancel(verificationItemKey, details.cancelDtls);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification Item record.
   *
   * @param details Verification Item details.
   *
   * @return The unique identifier of the record created.
   */
  @Override
  public VerificationItemKey createVerificationItem(
    CreateVerificationItemDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = VerificationItemFactory.newInstance();

    // Create a Verification Item.
    details.createDtls.dateCreated = Date.getCurrentDate();
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    verificationItemObj.insert(details.createDtls);

    // Create and populate the return struct.
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    verificationItemKey.verificationItemID = details.createDtls.verificationItemID;

    return verificationItemKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verification Item record.
   *
   * @param details Verification Item details.
   */
  @Override
  public void modifyVerificationItem(ModifyVerificationItemDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = VerificationItemFactory.newInstance();

    // Create and populate the Verification Item key.
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    verificationItemKey.verificationItemID = details.modifyDtls.verificationItemID;

    // Modify a Verification Item.
    verificationItemObj.modify(verificationItemKey, details.modifyDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification Item record.
   *
   * @param key Verification Item details.
   *
   * @return Details of the Verification Item record.
   */
  @Override
  public ReadVerificationItemDetails readVerificationItem(
    VerificationItemKey key) throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = VerificationItemFactory.newInstance();

    // Create the return object
    final ReadVerificationItemDetails readVerificationItemDetails = new ReadVerificationItemDetails();

    // Read the Verification Item.
    readVerificationItemDetails.readDtls = verificationItemObj.read(key);

    return readVerificationItemDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads verification item names
   *
   * @return ListVerificationItemIDAndNameDetails
   */
  @Override
  public ListVerificationItemIDAndNameDetails readAllVerificationItemNames()
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItem verificationItemObj = curam.verification.sl.entity.fact.VerificationItemFactory.newInstance();

    final ListVerificationItemIDAndNameDetails listVerificationItemIDAndNameDetails = new ListVerificationItemIDAndNameDetails();

    listVerificationItemIDAndNameDetails.listDtls = verificationItemObj.searchAllActiveVerificationItemNames();
    return listVerificationItemIDAndNameDetails;
  }

}
