/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.sl.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.Hashtable;
import java.util.Map;


/**
 * This class stores the last accessed node for
 * the XML Tree Widget for Rules components.
 *
 */

public final class TreeXMLCacheNode {

  /**
   * Single instance of the TreeXMLNodeCache class.
   */
  protected static TreeXMLCacheNode treeXMLNodeCache;

  /**
   * Synchronized collection to store the Node objects.
   */
  protected final Map lastAccessedNodeCache = new Hashtable();

  /**
   * protected constructor ensures that this class can not be
   * instantiated.
   */
  protected TreeXMLCacheNode() {// Empty protected Constructor
  }

  /**
   * Get the only instance of this class.
   *
   * @return the only instance of TreeXMLNodeCache. Create the instance
   * if it does not exist.
   */
  public static TreeXMLCacheNode getInstance() {

    if (treeXMLNodeCache == null) {
      treeXMLNodeCache = new TreeXMLCacheNode();
    }
    return treeXMLNodeCache;
  }

  /**
   * Gets the TreeNodeDetails from cache or creates a new object if it does not
   * exist in cache.
   *
   * @param nodeID Verification Category Identifier
   *
   * @return TreeXMLNodeDetails object
   *
   * @throws InformationalException If error occurs.
   * @throws AppException If error occurs.
   */
  public TreeXMLNodeDetail getTreeXMLNodeDetails(final Long nodeID)
    throws AppException, InformationalException {

    TreeXMLNodeDetail nodeDetails = (TreeXMLNodeDetail) lastAccessedNodeCache.get(
      nodeID);

    if (nodeDetails == null) {
      nodeDetails = new TreeXMLNodeDetail();
      lastAccessedNodeCache.put(nodeID, nodeDetails);
    }

    return nodeDetails;
  }

}
