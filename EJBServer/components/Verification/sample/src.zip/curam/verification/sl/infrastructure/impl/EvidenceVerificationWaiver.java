/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.verification.sl.infrastructure.impl;


import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;


/**
 * All implementations for the interface Evidence Verification Waiver should
 * be bound using Guice MapBinder class. The key to bind the implementation
 * should be of the format
 * <Case Type Code>.<Case Sub Type Code>.<Evidence Type Code>
 * where
 * - Case Type Code is code from Code Table "CaseTypeCode"
 * - Case Sub Type Code depends on type of case and the codes are from Code
 * Tables like
 * - "ProductCategory" - Integrated Case Type, when Case Type is Integrated
 * Case,
 * - "ProductType" - Product Type when Case Type is Product Delivery Case,
 * - "InvestigateConfigType" - Investigation Configuration Type when Case Type
 * is Investigation Case,
 * - "ScreeningNameCode" - Screening Name Code when Case Type is Screening Case
 * - Evidence Type Code is the code from Code Table "CaseEvidenceTypeCode"
 * - these codes should be separated by period i.e., "."
 * or
 * <Concern Role Type>.<Evidence Type Code>
 * where
 * - Concern Role Type is code from Code Table "ConcernRoleType"
 * - Evidence Type Code is the code from Code Table "CaseEvidenceTypeCode"
 * - these codes should be separated by period i.e., "."
 *
 */
public interface EvidenceVerificationWaiver {

  public void process(final VerificationDtls details,
    final EIEvidenceKey eiEvidenceKey) throws AppException,
      InformationalException;

}
