/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006,2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.NONCASEDATATYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.RecordStatusDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.message.ENTVERIFIABLEDATAITEM;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.UnimplementedException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.struct.SearchAllActiveDependentDataItemNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveItemUtilizationNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationRequirementNamesList;
import curam.verification.sl.entity.struct.SearchAllVerifiableDataItemNamesList;
import curam.verification.sl.entity.struct.SearchAllVerifiableItemEvidenceTypeAndDataItemList;
import curam.verification.sl.entity.struct.VerifiableDataItemCancelDetails;
import curam.verification.sl.entity.struct.VerifiableDataItemDtls;
import curam.verification.sl.entity.struct.VerifiableDataItemIDAndStatusKey;
import curam.verification.sl.entity.struct.VerifiableDataItemIDDateAndRelatedItem;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerifiableDataItemRecordCount;
import curam.verification.sl.entity.struct.VerifiableDateItemEvidenceTypeAndDataItemStatus;
import curam.verification.sl.entity.struct.VerifiableDateItemNameAndStatus;
import curam.verification.sl.entity.struct.VerifiableItemEvidenceTypeRecordCount;
import curam.verification.sl.entity.struct.VerificationCategoryIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.entity.struct.VerificationCategoryStatusDetails;
import curam.verification.sl.entity.struct.VerificationRequirementKeyList;
import curam.verification.sl.infrastructure.entity.struct.VerifiableDataItemIDAndVerStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationRecordCount;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verifiable Data Item record. A Verifiable Data Item record identifies the
 * data item that requires verification
 */
public abstract class VerifiableDataItem extends curam.verification.sl.entity.base.VerifiableDataItem {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Verifiable Data Item details
   */
  @Override
  protected void preinsert(VerifiableDataItemDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Verifiable Data Item identifier
   * @param details Verifiable Data Item details
   */
  @Override
  protected void premodify(VerifiableDataItemKey key,
    VerifiableDataItemDtls details) throws AppException,
      InformationalException {

    validateModify(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the cancel
   *
   * @param key Verifiable Data Item identifier
   * @param details Verifiable Data Item details
   */
  @Override
  protected void precancel(VerifiableDataItemKey key,
    VerifiableDataItemCancelDetails details) throws AppException,
      InformationalException {

    // Validate the cancel details
    validateCancel(details);

    // Set the record status to cancelled
    details.recordStatus = RECORDSTATUS.CANCELLED;
  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void validateDetails(VerifiableDataItemDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    //
    // Name must be entered
    //
    if (details.name.trim().length() == 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_NAME_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    //
    // Evidence Type must be entered
    //
    if (details.evidenceType.trim().length() == 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_EVIDENCE_TYPE_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    //
    // Data Item must be entered
    //
    if (details.dataItem.trim().length() == 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_DATA_ITEM_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verifiable Data Item details before the logical delete
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void validateCancel(VerifiableDataItemCancelDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00102936 ,BD
    // Re-read the database record
    final VerifiableDataItemKey vdiKey = new VerifiableDataItemKey();

    vdiKey.verifiableDataItemID = details.verifiableDataItemID;
    final RecordStatusDetails currentStatus = new RecordStatusDetails();

    currentStatus.recordStatus = read(vdiKey).recordStatus;

    //
    // Record must not be already canceled
    //
    if (currentStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      // END, CR00102396
      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_VERIFIABLE_DATA_ITEM_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // If any associated Verification Requirement records exist the record
    // may not be cancelled

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();
    final VerifiableDataItemIDAndStatusKey verifiableDataItemIDAndStatusKey = new VerifiableDataItemIDAndStatusKey();

    verifiableDataItemIDAndStatusKey.verifiableDataItemID = details.verifiableDataItemID;
    verifiableDataItemIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    final SearchAllActiveVerificationRequirementNamesList searchAllActiveVerificationRequirementNamesList = verificationRequirementObj.searchAllActiveNames(
      verifiableDataItemIDAndStatusKey);

    if (searchAllActiveVerificationRequirementNamesList.dtls.size() > 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_ASSOCIATED_VERIFICATION_REQ_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    //
    // If any associated Verification Item Utilization records exist the record
    // may not be cancelled
    //
    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    final SearchAllActiveItemUtilizationNamesList searchAllActiveItemUtilizationNamesList = verificationItemUtilization.searchAllActiveNames(
      verifiableDataItemIDAndStatusKey);

    ;

    if (searchAllActiveItemUtilizationNamesList.dtls.size() > 0) {

      final AppException appException = new AppException(
        ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_ASSOCIATED_VERIFICATION_ITEM_UTIL_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    //
    // If any associated Dependent Data Item records exist the record
    // may not be cancelled
    //
    final curam.verification.sl.entity.intf.DependentDataItem dependentDataItem = DependentDataItemFactory.newInstance();
    final SearchAllActiveDependentDataItemNamesList searchAllActiveDependentDataItemNamesList = dependentDataItem.searchAllActiveNames(
      verifiableDataItemIDAndStatusKey);

    if (searchAllActiveDependentDataItemNamesList.dtls.size() > 0) {

      final AppException appException = new AppException(
        ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_ASSOCIATED_VERIFICATION_DEPENDENT_DATA_ITEM_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verifiable Data Item details before the data insertion
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void validateInsert(VerifiableDataItemDtls details)
    throws AppException, InformationalException, UnimplementedException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    //
    // The active name must not already be in use
    //

    final VerifiableDateItemNameAndStatus verifiableDateItemNameAndStatus = new VerifiableDateItemNameAndStatus();

    final curam.verification.sl.entity.intf.VerificationCategory verificationCategory = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();
    VerificationCategoryStatusDetails verificationCategoryStatusDetails = new VerificationCategoryStatusDetails();

    verifiableDateItemNameAndStatus.name = details.name;
    verifiableDateItemNameAndStatus.recordStatus = RECORDSTATUS.CANCELLED;
    verifiableDateItemNameAndStatus.verificationCategoryID = details.verificationCategoryID;
    final VerificationCategoryKey verificationCategoryKey = new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID = details.verificationCategoryID;

    verificationCategoryStatusDetails = verificationCategory.readStatusByID(
      verificationCategoryKey);

    if (verificationCategoryStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_VERIFICATION_CATEGORY_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Retrieve a list of all Verifiable Data Item names
    final VerifiableDataItemRecordCount verifiableDataItemRecordCount = countByNameAndStatus(
      verifiableDateItemNameAndStatus);

    // Iterate through the list of Verifiable Data Item names
    if (verifiableDataItemRecordCount.recordCount > 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_NAME_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    final VerifiableDateItemEvidenceTypeAndDataItemStatus verifiableDateItemEvidenceTypeAndDataItemStatus = new VerifiableDateItemEvidenceTypeAndDataItemStatus();

    verifiableDateItemEvidenceTypeAndDataItemStatus.dataItem = details.dataItem;
    verifiableDateItemEvidenceTypeAndDataItemStatus.evidenceType = details.evidenceType;
    verifiableDateItemEvidenceTypeAndDataItemStatus.recordStatus = RECORDSTATUS.CANCELLED;

    // Retrieve a list of all Verifiable Data Items by data item and evidence
    // type
    // The operation ignores records with the supplied record status (no
    // cancelled records returned)
    final VerifiableItemEvidenceTypeRecordCount verifiableItemEvidenceTypeRecordCount = countByEvidenceTypeAndDataItem(
      verifiableDateItemEvidenceTypeAndDataItemStatus);

    // Iterate through the list of Verifiable Data Item names
    if (verifiableItemEvidenceTypeRecordCount.recordCount > 0) {

      final AppException appException = new AppException(
        curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_DATA_ITEM_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verifiable Data Item details before the data modification
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void validateModify(VerifiableDataItemDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00076590, BF
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    // END, CR00076590

    // BEGIN, CR00102936 ,BD
    // Re-read the database record
    final VerifiableDataItemKey vdiKey = new VerifiableDataItemKey();

    vdiKey.verifiableDataItemID = details.verifiableDataItemID;
    final RecordStatusDetails currentStatus = new RecordStatusDetails();

    currentStatus.recordStatus = read(vdiKey).recordStatus;

    // Record must not be already canceled
    if (currentStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      // END, CR00102936

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_VERIFIABLE_DATA_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // The name must not already be in use
    // Retrieve a list of all Verifiable Data Item names.

    final SearchAllVerifiableDataItemNamesList searchAllVerifiableDataItemNamesList = searchAllActiveNameAndID();

    // Iterate through the list of Verifiable Data Item.
    for (int i = 0; i < searchAllVerifiableDataItemNamesList.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (details.verifiableDataItemID
        != searchAllVerifiableDataItemNamesList.dtls.item(i).verifiableDataItemID) {

        // Check that the name does not already exist.
        if (details.name.equals(
          searchAllVerifiableDataItemNamesList.dtls.item(i).name)) {

          final AppException appException = new AppException(
            ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_NAME_ALREADY_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        }
      }
    }

    // A data item of the same evidence type must not already exist.
    // Retrieve a list of all Verifiable Data Item names.

    final SearchAllVerifiableItemEvidenceTypeAndDataItemList searchAllVerifiableItemEvidenceTypeAndDataItem = searchAllActiveEvidenceTypeAndDataItem();

    // Iterate through the list of Verifiable Data Item.
    for (int i = 0; i
      < searchAllVerifiableItemEvidenceTypeAndDataItem.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (details.verifiableDataItemID
        != searchAllVerifiableItemEvidenceTypeAndDataItem.dtls.item(i).verifiableDataItemID) {

        // Check that the Evidence Type does not already exist.
        if (details.evidenceType.equals(
          searchAllVerifiableItemEvidenceTypeAndDataItem.dtls.item(i).evidenceType)) {

          // Check that the dataItem does not already exist.
          if (details.dataItem.equals(
            searchAllVerifiableItemEvidenceTypeAndDataItem.dtls.item(i).dataItem)) {

            final AppException appException = new AppException(
              ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_FV_DATA_ITEM_ALREADY_EXISTS);

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
              appException, CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
          }
        }
      }
    }
    // BEGIN, CR00076590, BF
    // You should not be allowed to modify the data item evidence type from
    // Participant
    // Evidence type to Temporal Evidence Type if a Verification Requirement
    // Usage
    // record exists for Non Case Data Level.
    // Only participant evidence type should be applied to Non Case Data level
    // Get all requirements for the verifiable data item which are active (not
    // cancelled) for current date
    final VerifiableDataItemIDDateAndRelatedItem verifiableDataItemIDDateAndRelatedItem = new VerifiableDataItemIDDateAndRelatedItem();

    verifiableDataItemIDDateAndRelatedItem.relatedItemType = NONCASEDATATYPE.PARTICIPANT;
    verifiableDataItemIDDateAndRelatedItem.recordStatus = RECORDSTATUS.CANCELLED;
    verifiableDataItemIDDateAndRelatedItem.date = Date.getCurrentDate();
    verifiableDataItemIDDateAndRelatedItem.verifiableDataItemID = details.verifiableDataItemID;
    verifiableDataItemIDDateAndRelatedItem.relatedItemID = VERIFICATIONTYPE.NONCASEDATA;

    final VerificationRequirementKeyList verificationRequirementKeyList = verificationRequirementUsage.searchRequirementIDByDataItemIDDateAndRelatedItem(
      verifiableDataItemIDDateAndRelatedItem);

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = details.evidenceType;

    // BEGIN CR00191839
    final boolean isParticipantData = EvidenceControllerFactory.newInstance().isEvidenceParticipantData(
      evidenceTypeKey);

    // END CR00191839

    // If a usage record for Non Case Data Level already exist - throw error to
    // user
    // that the Data Item Evidence Type can not be modified to Temporal evidence
    // in
    // this case.
    if (verificationRequirementKeyList.dtls.size() > 0 && !isParticipantData) {

      final AppException appException = new AppException(
        ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEM_XRV_EDIT_EVIDENCE_TO_TEMPORAL_PARTICIPANT_USAGE_RECORD_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00076590

    // BEGIN,CR00080775,AL
    // perform a count of verifications for the specified verifiableDataItemID
    // that are not cancelled
    // if a verification exists prevent the verifiableDataItemID from being
    // modified.
    final curam.verification.sl.infrastructure.entity.intf.Verification verificationObj = curam.verification.sl.infrastructure.entity.fact.VerificationFactory.newInstance();
    final VerifiableDataItemIDAndVerStatusKey verifiableDataItemIDAndVerStatusKey = new VerifiableDataItemIDAndVerStatusKey();

    verifiableDataItemIDAndVerStatusKey.verifiableDataItemID = details.verifiableDataItemID;
    verifiableDataItemIDAndVerStatusKey.verificationStatus = curam.codetable.VERIFICATIONSTATUS.CANCELLED;
    final VerificationRecordCount verificationRecordCount = verificationObj.countVerificationsForDataItemID(
      verifiableDataItemIDAndVerStatusKey);

    if (verificationRecordCount.recordCount > 0) {

      final AppException appException = new AppException(
        ENTVERIFIABLEDATAITEM.ERR_VERIFIABLEDATAITEMID_XRV_HAS_ASSOCIATED_USAGE_VERIFICATION_APPLICATION_MODIFICATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END,CR00080775

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  /**
   * Assigns Cancelled status to key
   *
   * @param key verification category key
   */
  @Override
  protected void presearchAllActiveNames(
    VerificationCategoryIDAndStatusKey key) throws AppException,
      InformationalException {

    key.recordStatus = RECORDSTATUS.CANCELLED;

  }

}
