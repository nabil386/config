/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.struct.CancelVerificationCategoryDetails;
import curam.verification.sl.struct.CreateVerificationCategoryDetails;
import curam.verification.sl.struct.ListVerificationCategoryDetailsList;
import curam.verification.sl.struct.ModifyVerificationCategoryDetails;
import curam.verification.sl.struct.ReadVerificationCategoryDetails;


/**
 * This process class provides the functionality for the Verification Category
 * service layer.
 */
public abstract class VerificationCategory extends curam.verification.sl.base.VerificationCategory {

  // ___________________________________________________________________________
  /**
   * Cancels a Verification Category record
   *
   * @param cancelDetails Verification Category details
   */
  @Override
  public void cancelVerificationCategory(
    CancelVerificationCategoryDetails cancelDetails) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // Create and populate the Verification Category key
    final VerificationCategoryKey verificationCategoryKey = new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID = cancelDetails.cancelDtls.verificationCategoryID;

    // Cancel a Verification Category record
    verificationCategoryObj.cancel(verificationCategoryKey,
      cancelDetails.cancelDtls);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification Category record
   *
   * @param details Verification Category details
   */
  @Override
  public VerificationCategoryKey createVerificationCategory(
    CreateVerificationCategoryDetails details) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    details.createDtls.dateCreated = Date.getCurrentDate();

    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    // Create a Verification Category record
    verificationCategoryObj.insert(details.createDtls);

    // Create and populate the return struct
    final VerificationCategoryKey verificationCategoryKey = new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID = details.createDtls.verificationCategoryID;

    return verificationCategoryKey;
  }

  // ___________________________________________________________________________
  /**
   * Lists a Verification Category Details
   *
   * @return List Verification Category List details
   */

  @Override
  public ListVerificationCategoryDetailsList listVerificationCategory()
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // create return structure
    final ListVerificationCategoryDetailsList listVerificationCategoryDetailsList = new ListVerificationCategoryDetailsList();

    // get list Verification Category Details
    listVerificationCategoryDetailsList.listDtls = verificationCategoryObj.searchVerificationCategoryListDetails();

    return listVerificationCategoryDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verification Category record
   *
   * @param modifyDetails Verification Category details
   */
  @Override
  public void modifyVerificationCategory(
    ModifyVerificationCategoryDetails modifyDetails) throws AppException,
      InformationalException {

    // create object at entity level
    final curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();
    // Create and populate the Verification Category key
    final VerificationCategoryKey verificationCategoryKey = new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID = modifyDetails.modifyDtls.verificationCategoryID;
    // Create a Verification category record
    verificationCategoryObj.modify(verificationCategoryKey,
      modifyDetails.modifyDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification Category record
   *
   * @param key Verification Category Details
   * @return details Verification Category Details
   */

  @Override
  public ReadVerificationCategoryDetails readVerificationCategory(
    VerificationCategoryKey key) throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // create return structure
    final ReadVerificationCategoryDetails readVerificationCategoryDetails = new ReadVerificationCategoryDetails();

    // Read the Verification Category Record
    readVerificationCategoryDetails.readDtls = verificationCategoryObj.read(key);

    return readVerificationCategoryDetails;

  }

}
