/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.ENTVERIFICATIONITEM;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.struct.ActiveItemUtilizationByVerificationItemIDCountDetails;
import curam.verification.sl.entity.struct.VerificationItemCancelDetails;
import curam.verification.sl.entity.struct.VerificationItemDtls;
import curam.verification.sl.entity.struct.VerificationItemIDAndNameDetailsList;
import curam.verification.sl.entity.struct.VerificationItemIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationItemKey;
import curam.verification.sl.entity.struct.VerificationItemNameAndStatus;
import curam.verification.sl.entity.struct.VerificationItemNameCountDetails;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verification Item record. A Verification Item record is a document or
 * activity that can be used to verify a data item.
 */
public abstract class VerificationItem extends curam.verification.sl.entity.base.VerificationItem {

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item details before the logical delete.
   *
   * @param details Verification Item details.
   */
  @Override
  public void validateCancel(VerificationItemCancelDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Verification Item must not be already canceled.
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_FV_VERIFICATION_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }
    // BEGIN, CR00350044, SSK
    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    final VerificationItemIDAndStatusKey verificationItemIDAndStatusKey = new VerificationItemIDAndStatusKey();

    verificationItemIDAndStatusKey.verificationItemID = details.verificationItemID;
    verificationItemIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;

    // BEGIN, CR00341469, RPB

    ActiveItemUtilizationByVerificationItemIDCountDetails activeItemUtilizationByVerificationItemIDCountDetails = verificationItemUtilization.countAllActiveItemUtilizationByVerificationItemIDInGroup(
      verificationItemIDAndStatusKey);

    // END, CR00350044
    if (activeItemUtilizationByVerificationItemIDCountDetails.recordCount > 0) {
      final AppException appException = new AppException(
        ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_XRV_ASSOCIATED_VERIFICATION_GROUP_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // END, CR00341469

    // Verification Item must not have any active Verification Item
    // Utilizations.
    // TODO: Need to take up this in the next iteration.

    // BEGIN, CR00350044, SSK
    activeItemUtilizationByVerificationItemIDCountDetails = verificationItemUtilization.countAllActiveItemUtilizationByVerificationItemID(
      verificationItemIDAndStatusKey);
    // END, CR00350044

    if (activeItemUtilizationByVerificationItemIDCountDetails.recordCount > 0) {
      final AppException appException = new AppException(
        ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_XRV_ASSOCIATED_VERIFICATION_ITEM_UTILIZATION_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item details before the data insertion.
   *
   * @param details Verification Item details.
   */
  @Override
  public void validateInsert(VerificationItemDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final VerificationItemNameAndStatus verificationItemNameAndStatus = new VerificationItemNameAndStatus();

    verificationItemNameAndStatus.name = details.name;
    verificationItemNameAndStatus.recordStatus = RECORDSTATUS.CANCELLED;

    // Retrieve a list of all Verification Item names.
    final VerificationItemNameCountDetails verificationItemNameCountDetails = countByVerificationItemName(
      verificationItemNameAndStatus);

    // Iterate through the list of Verifiable Data Item names
    if (verificationItemNameCountDetails.count > 0) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_FV_NAME_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item details before being updated.
   *
   * @param details Verification Item details.
   */
  @Override
  public void validateModify(VerificationItemDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled.
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_FV_VERIFICATION_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // The name must not already be in use
    // Retrieve a list of all Verification Item names.
    final VerificationItemIDAndNameDetailsList verificationItemIDAndNameDetailsList = searchAllActiveVerificationItemNames();

    // Iterate through the list of Verification Items.
    for (int i = 0; i < verificationItemIDAndNameDetailsList.dtls.size(); i++) {

      // Do not check the against its own record in the list.
      if (details.verificationItemID
        != verificationItemIDAndNameDetailsList.dtls.item(i).verificationItemID) {

        // Check that the name does not already exist.
        if (details.name.equals(
          verificationItemIDAndNameDetailsList.dtls.item(i).name)) {

          final AppException appException = new AppException(
            ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_FV_NAME_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        }
      }
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion.
   *
   * @param details Verification Item details.
   */
  @Override
  protected void preinsert(VerificationItemDtls details) throws AppException,
      InformationalException {

    validateInsert(details);
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification.
   *
   * @param key Verification Item identifier.
   * @param details Verification Item details.
   */
  @Override
  protected void premodify(VerificationItemKey key,
    VerificationItemDtls details) throws AppException, InformationalException {

    validateModify(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before a logical delete of Verification
   * Item.
   *
   * @param key Verification Item identifier.
   * @param dtls Verification Item details.
   */
  @Override
  protected void precancel(VerificationItemKey key,
    VerificationItemCancelDetails dtls) throws AppException,
      InformationalException {

    validateCancel(dtls);

    // Set the record status to cancelled
    dtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations.
   *
   * @param details Verification Item details.
   */
  @Override
  public void validateDetails(VerificationItemDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Name must be entered
    if (details.name.trim().length() == 0) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_FV_NAME_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

}
