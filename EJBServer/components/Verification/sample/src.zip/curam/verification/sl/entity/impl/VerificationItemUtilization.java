/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONITEMUSAGETYPE;
import curam.core.impl.CuramConst;
import curam.message.ENTVERIFICATIONITEMUTILIZATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.struct.VerifiableDataItemIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationItemUtilizationCancelDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.entity.struct.VerificationItemUtilizationSummaryDetailsList;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verification Item Utilization record. A Verification Item Utilization record
 * identifies what verification items can be used to verify a specific data
 * item.
 */
public abstract class VerificationItemUtilization extends curam.verification.sl.entity.base.VerificationItemUtilization {

  /**
   * Validates the Verification Item Utilization details before the logical
   * delete.
   *
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_VERIFICATION_ITEM_UTILIZATION_CANCELLED}
   * -
   * if this verification item utilization has already been cancelled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateCancel(
    final VerificationItemUtilizationCancelDetails details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_VERIFICATION_ITEM_UTILIZATION_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  /**
   * Validates the Verification Item Utilization details before the data
   * insertion.
   *
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_FV_TODATE_LATER_FROMDATE}
   * -
   * if the To Date is not later than the From Date.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateInsert(final VerificationItemUtilizationDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (!details.toDate.isZero() && details.toDate.before(details.fromDate)) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_TODATE_LATER_FROMDATE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

    // BEGIN, CR00348311, SSK
    if (StringUtil.isNullOrEmpty(details.usageType)) {
      details.usageType = VERIFICATIONITEMUSAGETYPE.SHARED;
    }
    // END, CR00348311

  }

  /**
   * Validates the Verification Item Utilization details before the data
   * modification.
   *
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_FV_TODATE_LATER_OR_EQUAL_TO_FROMDATE}
   * -
   * if the To Date is not later than or equal to the From Date.
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_FV_FROMDATE_MUST_BE_ENTERED}
   * -
   * if the From Date is not entered.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateModify(final VerificationItemUtilizationDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_VERIFICATION_ITEM_UTILIZATION_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    if (details.fromDate == null || details.fromDate.isZero()) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_FROMDATE_MUST_BE_ENTERED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!details.toDate.isZero() && details.toDate.before(details.fromDate)) {
      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_TODATE_LATER_OR_EQUAL_TO_FROMDATE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  /**
   * Ensures validations are performed before the data insertion.
   *
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final VerificationItemUtilizationDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
    validateDetails(details);
  }

  /**
   * Ensures validations are performed before the data modification.
   *
   * @param key
   * Contains the Verification Item Utilization identifier.
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void premodify(final VerificationItemUtilizationKey key,
    final VerificationItemUtilizationDtls details) throws AppException,
      InformationalException {

    validateModify(details);
    validateDetails(details);
  }

  /**
   * Performs the validations common to all operations.
   *
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_XRV_NAME_AND_DETAILS_ALREADY_EXISTS}
   * -
   * if a verification item utilization with the same name and details
   * already exists.
   * @throws InformationalException
   * Generic Exception Signature.
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_FV_WARNING_DAYS_WITHOUT_EXPIRY_DAYS}
   * -
   * if the Warning Days are specified if there are no Expiry Days
   * specified.
   * @throws AppException
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_FV_WARNING_DAYS_GREATER_THAN_OR_EQUAL_TO_EXPIRY_DAYS}
   * -
   * if the number specified for warning days is not less than that
   * specified for expiry days.
   */
  @Override
  public void validateDetails(final VerificationItemUtilizationDtls details)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // The name,level,from date,to date must not already be in use.
    final VerifiableDataItemIDAndStatusKey verifiableDataItemIDSatusKey = new VerifiableDataItemIDAndStatusKey();

    verifiableDataItemIDSatusKey.verifiableDataItemID = details.verifiableDataItemID;
    verifiableDataItemIDSatusKey.recordStatus = RECORDSTATUS.CANCELLED;

    // Retrieve a list of all Verification Item Utilization name,level,from
    // date,to date.
    // BEGIN, CR00350044, SSK
    VerificationItemUtilizationSummaryDetailsList verificationItemUtilizationSummaryDetailsList;

    if (details.verificationGroupID == 0) {
      verificationItemUtilizationSummaryDetailsList = searchAllVerificationItemUtilizationSummary(
        verifiableDataItemIDSatusKey);
    } else {
      verificationItemUtilizationSummaryDetailsList = searchAllVerificationGroupItemUtilizationSummary(
        verifiableDataItemIDSatusKey);
    }
    // END, CR00350044
    // Iterate through the list of Verification Item Utilization
    // names,level,from date,to date.
    for (int i = 0; i
      < verificationItemUtilizationSummaryDetailsList.dtls.size(); i++) {

      // When modifying an existing record make sure not to check the
      // record against itself in the list.
      if (details.verificationItemUtilizationID
        != verificationItemUtilizationSummaryDetailsList.dtls.item(i).verificationItemUtilizationID) {
        if (details.verificationItemID
          == verificationItemUtilizationSummaryDetailsList.dtls.item(i).verificationItemID) {

          // Check that the level does not already exist.
          if (details.verificationLevel.equals(
            verificationItemUtilizationSummaryDetailsList.dtls.item(i).verificationLevel)) {
            if (details.fromDate.equals(
              verificationItemUtilizationSummaryDetailsList.dtls.item(i).fromDate)) {
              if (details.toDate.equals(
                verificationItemUtilizationSummaryDetailsList.dtls.item(i).toDate)) {
                // BEGIN, CR00400972, RPB
                final VerificationItemUtilizationKey key = new VerificationItemUtilizationKey();

                key.verificationItemUtilizationID = verificationItemUtilizationSummaryDetailsList.dtls.item(i).verificationItemUtilizationID;
                final VerificationItemUtilizationDtls verificationItemUtilizationDtls = read(
                  key);

                // BEGIN, CR00408051, AKr
                if (details.verificationGroupID == 0
                  || details.verificationGroupID
                    == verificationItemUtilizationDtls.verificationGroupID) {
                  // END, CR00408051
                  // END, CR00400972
                  final AppException appException = new AppException(
                    ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_XRV_NAME_AND_DETAILS_ALREADY_EXISTS);

                  curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
                    appException, CuramConst.gkEmpty,
                    InformationalElement.InformationalType.kError,
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                    0);
                }
              }
            }
          }
        }
      }
    }

    // BEGIN, CR00227793, NS
    if (CuramConst.gkMinusOne == details.expiryDays && details.warningDays > 0) {
      // END, CR00227793

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_WARNING_DAYS_WITHOUT_EXPIRY_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00227793, NS
    if (CuramConst.gkMinusOne == details.expiryDays
      && details.expiryDateEvent.trim().length() > 0) {
      // END, CR00227793

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_EXPIRY_DAYS_EVENT_WITHOUT_EXPIRY_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.warningDays >= details.expiryDays && details.expiryDays > 0) {

      final AppException appException = new AppException(
        ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_WARNING_DAYS_GREATER_THAN_OR_EQUAL_TO_EXPIRY_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00017770, RK
    // Check if number of expiry days are greater than the days within the
    // period of the verification utilization. i.e. greater than the days
    // between the From and To dates.
    // BEGIN, CR00021537, NK
    if (!details.toDate.isZero()) {
      // END, CR00021537
      final int verRequirementPeriod = details.toDate.subtract(details.fromDate);

      if (details.expiryDays > verRequirementPeriod) {

        final AppException appException = new AppException(
          ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_FV_EXPIRY_DAYS_GREATER_THAN_VERIFICATION_UTILIZATION);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
      // BEGIN, CR00021537, NK
    }
    // END, CR00021537

    // END, CR00017770

    // BEGIN, CR00081175, JPG
    final VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  /**
   * Ensures validations are performed before the cancel
   *
   * @param key
   * Contains the Verification Item Utilization identifier.
   * @param details
   * Contains the Verification Item Utilization details.
   *
   * @throws AppException
   * {@link ENTVERIFICATIONITEMUTILIZATION#ERR_VERIFICATIONITEMUTILIZATION_VERIFICATION_ITEM_UTILIZATION_CANCELLED}
   * -
   * if this verification item utilization has already been cancelled.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void precancel(final VerificationItemUtilizationKey key,
    final VerificationItemUtilizationCancelDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    verificationItemUtilization.validateCancel(details);

    // Verification Category should not be already canceled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATIONITEMUTILIZATION_VERIFICATION_ITEM_UTILIZATION_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // Set the record status to cancelled
    details.recordStatus = RECORDSTATUS.CANCELLED;

  }

  /**
   * Pre search method for searchAllActiveNames.
   *
   * @param key Contains the verifiable data item and status key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected void presearchAllActiveNames(
    final VerifiableDataItemIDAndStatusKey key) throws AppException,
      InformationalException {

    final VerifiableDataItemIDAndStatusKey verifiableDataItemIDAndStatusKey = new VerifiableDataItemIDAndStatusKey();

    verifiableDataItemIDAndStatusKey.verifiableDataItemID = key.verifiableDataItemID;
    key.recordStatus = RECORDSTATUS.CANCELLED;
  }

}
