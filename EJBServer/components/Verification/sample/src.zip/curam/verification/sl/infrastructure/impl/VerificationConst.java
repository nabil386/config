/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2015. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;


import curam.util.ctm.bom.businessobjectidentifier.BusinessObjectIdentifierFactoryImpl;
import curam.util.ctm.bom.businessobjectidentifier.BusinessObjectType;
import curam.verification.sl.entity.intf.DependentDataItem;
import curam.verification.sl.entity.intf.VerifiableDataItem;
import curam.verification.sl.entity.intf.VerificationCategory;
import curam.verification.sl.entity.intf.VerificationGroup;
import curam.verification.sl.entity.intf.VerificationItem;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.intf.VerificationRequirement;
import curam.verification.sl.entity.intf.VerificationRequirementUsage;
import curam.verification.sl.intf.VRRuleClassLink;


/**
 * This class assigns values to the Curam constants
 *
 */
public abstract class VerificationConst {

  public static final long gkDueDateChanged = 1;

  public static final long gkDeadlineElapsed = 2;

  public static final long gkVerificationSatisfied = 3;

  public static final long gkCaseClosed = 3;

  public static final long gkVerificationStatus = 1;

  public static final boolean gkVerificationInFuture = true;

  public static final boolean gkWarningDateIndicator = true;

  public static final String gkVerificationWorkflowName = "VERIFICATIONDUEDATEPROCESSING";

  public static final String gkVerificationEventClass = "Verification";

  // BEGIN, CR 3140, RK
  public static final String gkVerificationItemUtilization = "VERIFICATIONITEMUTILIZATION";

  public static final long gkItemUtilizationWarningDateEmpty = 1;

  public static final long gkItemUtilizationWarningDateInPast = 2;

  public static final long gkItemUtilizationWarningDateInFuture = 3;

  public static final String gkVerificationNotification = "VERIFICATIONNOTIFICATION";

  // END, CR 3140
  // BEGIN, CR00069996, SK
  public static final String kTypeMoney = "curam.util.type.Money";

  public static final String kTypeDate = "curam.util.type.Date";

  public static final String kTypeString = "java.lang.String";

  // END, CR00069996
  // BEGIN, CR00233632, PB
  public static final String kTypeDateTime = "curam.util.type.DateTime";

  public static final String kTypeShort = "short";

  public static final String kTypeInt = "int";

  public static final String kTypeLong = "long";

  public static final String kTypeDouble = "double";

  public static final String kTypeBoolean = "boolean";

  public static final String kTypeBlob = "curam.util.type.Blob";

  // END, CR00233632

  // BEGIN, CR00260487, KR
  // Constants defined for the Verification BOM

  public static final String VERIFICATION_ITEM_UTILIZATION_INFO_SEPARATOR = "#####";

  /**
   * Constant for Verification business object type.
   */
  public static final BusinessObjectType kVerificationBOType = BusinessObjectIdentifierFactoryImpl.get().createBusinessObjectType(
    "Verification");

  /**
   * Constant for verification business object home page name.
   */
  public static final String kVerificationCategoryBOHomePage = "VerificationAdmin_viewVerificationCategories";

  /**
   * Constant for primary key of verification category entity.
   */
  public static final String kVerificationCategoryPrimaryKey = "verificationCategoryID";

  /**
   * XML attribute value for Verification Category table.
   */
  public static final String kVerificationCategoryEntityName = "VerificationCategory";

  /**
   * XML attribute value for Verification Category class.
   */
  public static final Class<VerificationCategory> kVerificationCategoryClass = VerificationCategory.class;

  // BEGIN, CR00357012, PS
  /**
   * Constant for primary key of verification group entity.
   */
  public static final String kVerificationGroupPrimaryKey = "verificationGroupID";

  /**
   * XML attribute value for Verification Group table.
   */
  public static final String kVerificationGroupEntityName = "VerificationGroup";

  /**
   * XML attribute value for Verification Group class.
   */
  public static final Class<VerificationGroup> kVerificationGroupClass = VerificationGroup.class;

  /**
   * Constant for primary key of verification requirement rule class link
   * entity.
   */
  public static final String kVRRuleClassLinkPrimaryKey = "vrCreoleRuleClassLinkID";

  /**
   * XML attribute value for verification requirement rule class link table.
   */
  public static final String kVRRuleClassLinkEntityName = "VRRuleClassLink";

  /**
   * XML attribute value for verification requirement rule class link class.
   */
  public static final Class<VRRuleClassLink> kVRRuleClassLinkClass = VRRuleClassLink.class;

  // END, CR00357012

  /**
   * XML attribute value for Verification Item table.
   */
  public static final String kVerificationItemEntityName = "VerificationItem";

  /**
   * XML attribute value for Verification Category class.
   */
  public static final Class<VerificationItem> kVerificationItemClass = VerificationItem.class;

  /**
   * XML attribute value for Verification Data Item table.
   */
  public static final String kVerifiableDataItemEntityName = "VerifiableDataItem";

  /**
   * XML attribute value for Verifiable Data Item class.
   */
  public static final Class<VerifiableDataItem> kVerifiableDataItemClass = VerifiableDataItem.class;

  /**
   * XML attribute value for Verification Item Utilization table.
   */
  public static final String kVerificationItemUtilizationEntityName = "VerificationItemUtilization";

  /**
   * XML attribute value for Verification Item Utilization class.
   */
  public static final Class<VerificationItemUtilization> kVerificationItemUtilizationClass = VerificationItemUtilization.class;

  /**
   * XML attribute value for Verification Requirement table.
   */
  public static final String kVerificationRequirementEntityName = "VerificationRequirement";

  /**
   * XML attribute value for Verification Requirement class.
   */
  public static final Class<VerificationRequirement> kVerificationRequirementClass = VerificationRequirement.class;

  /**
   * XML attribute value for Dependent Data Item table.
   */
  public static final String kDependentDataItemEntityName = "DependentDataItem";

  /**
   * XML attribute value for Dependent Data Item class.
   */
  public static final Class<DependentDataItem> kDependentDataItemClass = DependentDataItem.class;

  /**
   * XML attribute value for Verification Requirement Usage table.
   */
  public static final String kVerificationRequirementUsageEntityName = "VerificationRequirementUsage";

  /**
   * XML attribute value for Verification Requirement class.
   */
  public static final Class<VerificationRequirementUsage> kVerificationRequirementUsageClass = VerificationRequirementUsage.class;

  /**
   * Constant for primary key of verification data item entity.
   */
  public static final String kVerifiableDataItemPrimaryKey = "verifiableDataItemID";

  /**
   * Constant for primary key of Verification Item Utilization entity.
   */
  public static final String kVerificationItemUtilizationPrimaryKey = "verificationItemUtilizationID";

  /**
   * Constant for primary key of Verification Item entity.
   */
  public static final String kVerificationItemPrimaryKey = "verificationItemID";

  /**
   * Constant for primary key of Verification Requirement entity.
   */
  public static final String kVerificationRequirementPrimaryKey = "verificationRequirementID";

  /**
   * Constant for primary key of Dependent Data Item entity.
   */
  public static final String kDependentDataItemPrimaryKey = "dependentDataItemID";

  /**
   * Constant for primary key of Verification Requirement Usage entity.
   */
  public static final String kVerificationRequirementUsagePrimaryKey = "verificationRequirementUsageID";

  /**
   * Constant for SID for calling the method to create a Dependent Data Item.
   */
  public static final String kCreateDependantDataItemSID = "VerificationAdministration.createDependantDataItem";

  /**
   * Constant for SID for calling the method to create a Verifiable Data Item.
   */
  public static final String kCreateVerifiableDataItemSID = "VerificationAdministration.createVerifiableDataItem";

  /**
   * Constant for SID for calling the method to create a Verification Category.
   */
  public static final String kCreateVerificationCategorySID = "VerificationAdministration.createVerificationCategory";

  /**
   * Constant for SID for calling the method to create a Verification Item.
   */
  public static final String kCreateVerificationItemSID = "VerificationAdministration.createVerificationItem";

  /**
   * Constant for SID for calling the method to create a Verification Item
   * Utilization.
   */
  public static final String kCreateVerificationItemUtilizationSID = "VerificationAdministration.createVerificationItemUtilization";

  /**
   * Constant for SID for calling the method to create a Verification
   * Requirement.
   */
  public static final String kCreateVerificationRequirementSID = "VerificationAdministration.createVerificationRequirement";

  /**
   * Constant for SID for calling the method to create a Verification
   * Requirement Usage.
   */
  public static final String kCreateVerificationRequirementUsageSID = "VerificationAdministration.createVerificationRequirementUsage";

  // BEGIN, CR00357012, KRK
  /**
   * Constant for SID for calling the method to create a Verification
   * Group wizard details.
   */
  public static final String kCreateVGWizardSID = "MaintainVerificationGroup.createVGWizard";

  /**
   * Constant for SID for calling the method to create a Verification item
   * utilization wizard details.
   */
  public static final String kCreateVGItemWizardSID = "MaintainVerificationGroup.createVGItemWizard";

  /**
   * Constant for SID for calling the method to modify a Verification Group.
   */
  public static final String kModifyVerificationGroupSID = "MaintainVerificationGroup.updateVerificationGroup";

  /**
   * Constant for SID for calling the method to modify a Verification Group
   * Utilization Item.
   */
  public static final String kModifyVGItemUtilizationSID = "MaintainVerificationGroup.updateVGItemUtilization";

  /**
   * Constant for SID for calling the method to modify a Verification Group
   * details.
   */
  public static final String kModifyVGItemTabDetailsSID = "MaintainVerificationGroup.updateVGItemTabDetails";

  /**
   * Constant for SID for calling the method to cancel a Verification Group.
   */
  public static final String kCancelVerificationGroupSID = "MaintainVerificationGroup.deleteVerificationGroup";

  /**
   * Constant for SID for calling the method to cancel a Verification Group
   * Utilization.
   */
  public static final String kCancelVGItemUtilizationSID = "MaintainVerificationGroup.deleteVGItemUtilization";

  /**
   * Constant for SID for calling the method to read Verification Item.
   */
  public static final String kReadVerificationGroupItemsSID = "MaintainVerificationGroup.viewVerificationGroupItems";

  /**
   * Constant for SID for calling the method to read Verification Item
   * Utilization.
   */
  public static final String kReadVGItemUtilizationSID = "MaintainVerificationGroup.viewVGItemUtilization";

  /**
   * Constant for SID for calling the method to read Verification Group.
   */
  public static final String kReadVerificationGroupDetailsSID = "MaintainVerificationGroup.viewVerificationGroupDetails";

  /**
   * Constant for SID for calling the method to read Verification Utilization
   * group wizard details.
   */
  public static final String kReadWizardVGDetailsSID = "MaintainVerificationGroup.readWizardVGDetails";

  /**
   * Constant for SID for calling the method to read verification wizard summary
   * details.
   * Names.
   */
  public static final String kReadVGWizardSummarySID = "MaintainVerificationGroup.readVGWizardSummary";

  /**
   * Constant for SID for calling the method to read Verification Item
   * Utilization.
   */
  public static final String kReadVGItemWizardSID = "MaintainVerificationGroup.readVGItemWizard";

  /**
   * Constant for SID for calling the method to list Verification Group
   */
  public static final String kListVerificationGroupsSID = "MaintainVerificationGroup.listVerificationGroups";

  /**
   * Constant for SID for calling the method to list Verification Item.
   */
  public static final String kGetVerificationItemsID = "MaintainVerificationGroup.getAllVerificationItems";

  // END, CR00357012

  /**
   * Constant for SID for calling the method to modify a Dependent Data Item.
   */
  public static final String kModifyDependantDataItemSID = "VerificationAdministration.modifyDependantDataItem";

  /**
   * Constant for SID for calling the method to modify a Verifiable Data Item.
   */
  public static final String kModifyVerifiableDataItemSID = "VerificationAdministration.modifyVerifiableDataItem";

  /**
   * Constant for SID for calling the method to modify a Verification Category.
   */
  public static final String kModifyVerificationCategorySID = "VerificationAdministration.modifyVerificationCategory";

  /**
   * Constant for SID for calling the method to modify a Verification Item.
   */
  public static final String kModifyVerificationItemSID = "VerificationAdministration.modifyVerificationItem";

  /**
   * Constant for SID for calling the method to modify a Verification Item
   * Utilization.
   */
  public static final String kModifyVerificationItemUtilizationSID = "VerificationAdministration.modifyVerificationItemUtilization";

  /**
   * Constant for SID for calling the method to modify a Verification
   * Requirement.
   */
  public static final String kModifyVerificationRequirementSID = "VerificationAdministration.modifyVerificationRequirement";

  /**
   * Constant for SID for calling the method to modify a Verification
   * Requirement Usage.
   */
  public static final String kModifyVerificationRequirementUsageSID = "VerificationAdministration.modifyVerificationRequirementUsage";

  /**
   * Constant for SID for calling the method to cancel a Dependent Data Item.
   */
  public static final String kCancelDependantDataItemSID = "VerificationAdministration.cancelDependantDataItem";

  /**
   * Constant for SID for calling the method to cancel a Verifiable Data Item.
   */
  public static final String kCancelVerifiableDataItemSID = "VerificationAdministration.cancelVerifiableDataItem";

  /**
   * Constant for SID for calling the method to cancel a Verification Category.
   */
  public static final String kCancelVerificationCategorySID = "VerificationAdministration.cancelVerificationCategory";

  /**
   * Constant for SID for calling the method to cancel a Verification Item.
   */
  public static final String kCancelVerificationItemSID = "VerificationAdministration.cancelVerificationItem";

  /**
   * Constant for SID for calling the method to cancel a Verification Item
   * Utilization.
   */
  public static final String kCancelVerificationItemUtilizationSID = "VerificationAdministration.cancelVerificationItemUtilization";

  /**
   * Constant for SID for calling the method to cancel a Verification
   * Requirement.
   */
  public static final String kCancelVerificationRequirementSID = "VerificationAdministration.cancelVerificationRequirement";

  /**
   * Constant for SID for calling the method to cancel a Verification
   * Requirement Usage.
   */
  public static final String kCancelVerificationRequirementUsageSID = "VerificationAdministration.cancelVerificationRequirementUsage";

  /**
   * Constant for SID for calling the method to get XML String For Category
   * Tree.
   */
  public static final String kGetXMLStringForCategoryTreeSID = "VerificationAdministration.getXMLStringForCategoryTree";

  /**
   * Constant for SID for calling the method to get XML String For Tree.
   */
  public static final String kGetXMLStringForTreeSID = "VerificationAdministration.getXMLStringForTree";

  /**
   * Constant for SID for calling the method to list Dependent Data Item.
   */
  public static final String kListDependantDataItemSID = "VerificationAdministration.listDependantDataItem";

  /**
   * Constant for SID for calling the method to list Field SIDs.
   */
  public static final String kListFieldSIDsSID = "VerificationAdministration.listFieldSIDs";

  /**
   * Constant for SID for calling the method to list Integrated Case.
   */
  public static final String kListIntegratedCaseSID = "VerificationAdministration.listIntegratedCase";

  /**
   * Constant for SID for calling the method to list Non Case Type.
   */
  public static final String kListNonCaseTypeSID = "VerificationAdministration.listNonCaseType";

  /**
   * Constant for SID for calling the method to list Product Type.
   */
  public static final String kListProductTypeSID = "VerificationAdministration.listProductType";

  /**
   * Constant for SID for calling the method to list Verification Category.
   */
  public static final String kListVerificationCategorySID = "VerificationAdministration.listVerificationCategory";

  /**
   * Constant for SID for calling the method to list Verification Item.
   */
  public static final String kListVerificationItemSID = "VerificationAdministration.listVerificationItem";

  /**
   * Constant for SID for calling the method to list Verification Item
   * Utilization.
   */
  public static final String kListVerificationItemUtilizationSID = "VerificationAdministration.listVerificationItemUtilization";

  /**
   * Constant for SID for calling the method to list Verification Item
   * Utilization and VersionNo.
   */
  public static final String kListVerificationItemUtilizationAndVersionNoSID = "VerificationAdministration.listVerificationItemUtilizationAndVersionNo";

  /**
   * Constant for SID for calling the method to list Verification Requirement.
   */
  public static final String kListVerificationRequirementSID = "VerificationAdministration.listVerificationRequirement";

  /**
   * Constant for SID for calling the method to list all Verification Item
   * Names.
   */
  public static final String kListAllVerificationItemNamesSID = "VerificationAdministration.readAllVerificationItemNames";

  /**
   * Constant for SID for calling the method to read dependent data item.
   */
  public static final String kReadDependantDataItemSID = "VerificationAdministration.readDependantDataItem";

  /**
   * Constant for SID for calling the method to read dependent data item.
   */
  public static final String kReadDependantDataItemPageContextDescriptionSID = "VerificationAdministration.readDependantDataItemPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verifiable data item.
   */
  public static final String kReadVerifiableDataItemSID = "VerificationAdministration.readVerifiableDataItem";

  /**
   * Constant for SID for calling the method to read Verifiable data item name.
   */
  public static final String kReadVerifiableDataItemNameSID = "VerificationAdministration.readVerifiableDataItemName";

  /**
   * Constant for SID for calling the method to read verifiable data item page
   * context description.
   */
  public static final String kReadVerifiableDataItemPageContextDescriptionSID = "VerificationAdministration.readVerifiableDataItemPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verification category.
   */
  public static final String kReadVerificationCategorySID = "VerificationAdministration.readVerificationCategory";

  /**
   * Constant for SID for calling the method to read Verification category Page
   * Context Description.
   */
  public static final String kReadVerificationCategoryPageContextDescriptionSID = "VerificationAdministration.readVerificationCategoryPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verification Item.
   */
  public static final String kReadVerificationItemSID = "VerificationAdministration.readVerificationItem";

  /**
   * Constant for SID for calling the method to read Verification Item Page
   * Context Description.
   */
  public static final String kReadVerificationItemPageContextDescriptionSID = "VerificationAdministration.readVerificationItemPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verification Item
   * Utilization.
   */
  public static final String kReadVerificationItemUtilizationSID = "VerificationAdministration.readVerificationItemUtilization";

  /**
   * Constant for SID for calling the method to read Verification Item
   * Utilization Page Context Description.
   */
  public static final String kReadVerificationItemUtilizationPageContextDescriptionSID = "VerificationAdministration."
    + "readVerificationItemUtilizationPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verification Requirement.
   */
  public static final String kReadVerificationRequirementSID = "VerificationAdministration.readVerificationRequirement";

  /**
   * Constant for SID for calling the method to read Verification Requirement
   * Page Context Description.
   */
  public static final String kReadVerificationRequirementPageContextDescriptionSID = "VerificationAdministration."
    + "readVerificationRequirementPageContextDescription";

  /**
   * Constant for SID for calling the method to read Verification Requirement
   * Usage.
   */
  public static final String kReadVerificationRequirementUsageSID = "VerificationAdministration.readVerificationRequirementUsage";

  /**
   * Constant for SID for calling the method to read Verification Requirement
   * Usage Page Context Description.
   */
  public static final String kReadVerificationRequirementUsagePageContextDescriptionSID = "VerificationAdministration."
    + "readVerificationRequirementUsagePageContextDescription";

  // BEGIN, CR00333788, AKr
  /**
   * Constants that define the name abstract creole rule set and creole rule
   * classes to be used for the conditional verification.
   */
  public static final String kConditionalVerificationAbstractRuleSetName = "VerificationRuleSet";

  public static final String kConditionalVerificationAbstractRuleClassName = "VerificationDeterminator";

  /**
   * Constant that define the name of the creole rule attribute that will store
   * the client readable form of the creole rule class to be displayed.
   */
  public static final String kConditionalVerificationRuleClassDisplayNameAttribute = "displayName";

  /**
   * Constant that define the name of the creole rule attribute that will store
   * the input parameters required to determine conditional verification.
   */
  public static final String kConditionalVerificationInputParamAttributeName = "verificationDeterminatorParams";

  /**
   * Constant that define the name of the creole rule attribute that will
   * determine the conditional verification requirement.
   */
  public static final String kConditionalVerificationDetermineAttributeName = "determine";

  // END, CR00333778

  // BEGIN, CR00344114, AKr
  public static final String kConditionalVerificationInputParamRuleClassName = "VerificationDeterminatorParams";

  public static final String kConditionalVerificationDataItemNameAttributeName = "verifiableDataItemName";

  public static final String kConditionalVerificationEvidenceDescriptorIDAttributeName = "evidenceDescriptorID";

  public static final String kConditionalVerificationCaseIDAttributeName = "caseID";

  // BEGIN, CR00358053, VKR
  public static final String kConditionalVerificationDisplayRuleDescription = "description";

  // END, CR00358053

  // END, CR00344114

  // BEGIN, CR00417514, AKr
  /**
   * Constant that define the name of the flag to indicate if verification
   * processing has to be
   * postponed on a transaction.
   */
  public static final String kPostponeVerification = "PostponeVerification";

  // END, CR00417514

  // BEGIN, CR00426070, AKr
  /**
   * Constant that says if the transaction that triggers verifications is a
   * Evidence broker
   * deferred process transaction.
   */

  public static final String kIsEvidenceSharingProcess = "IsAnEvidenceSharingProcess";

  // END, CR00426070
  // BEGIN, CR00451715, MR
  public static final String kVerificationConfigurationCacheIdentifier = "VERIFICATION_CONFIGURATION";

  // END, CR00451715
  // BEGIN, CR00452978, GK
  public static final String kIsAddProofWizard = "IsAddProofWizard";
  // END, CR00452978
}
