/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONITEMUSAGETYPE;
import curam.codetable.impl.VERIFICATIONITEMNAMEEntry;
import curam.core.impl.CuramConst;
import curam.message.ENTVERIFICATIONITEM;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.VerificationItem;
import curam.verification.sl.entity.struct.CountActiveRequirementForItemUtilization;
import curam.verification.sl.entity.struct.ItemUtilizationLevelDateStatusAndVerifiableIDDetails;
import curam.verification.sl.entity.struct.SearchByVerificationItem;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationItemDetails;
import curam.verification.sl.entity.struct.VerificationItemKey;
import curam.verification.sl.entity.struct.VerificationItemNameDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationCancelDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.entity.struct.VerificationItemUtilizationUsageDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationUsageDetailsList;
import curam.verification.sl.struct.CreateVerificationItemUtilizationDetails;
import curam.verification.sl.struct.ModifyVerificationItemUtilizationDetails;
import curam.verification.sl.struct.ReadVerificationItemUtilizationDetails;
import curam.verification.sl.struct.VerificationItemUtilizationList;
import curam.verification.sl.struct.VerificationItemUtilizationListAndVersionNo;
import curam.verification.sl.struct.VerificationMessage;
import curam.verification.sl.struct.VerificationMessageList;


/**
 * This process class provides the functionality for the Verification Item
 * Utilization service layer.
 */
public abstract class VerificationItemUtilization extends curam.verification.sl.base.VerificationItemUtilization {

  // ___________________________________________________________________________
  /**
   * Cancels a Verification Item Utilization record
   *
   * @param details Verification Item Utilization details
   */
  @Override
  public VerificationMessageList cancelVerificationItemUtilization(
    VerificationItemUtilizationCancelDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final VerificationMessageList verificationMessageList = new VerificationMessageList();
    // Create and populate the Verification Item Utilization key
    final VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = details.verificationItemUtilizationID;

    // Cancel a Verification Item Utilization record
    verificationItemUtilization.cancel(verificationItemUtilizationKey, details);

    // Create the return object
    final ReadVerificationItemUtilizationDetails readVerificationItemUtilizationDetails = new ReadVerificationItemUtilizationDetails();
    final VerificationItemUtilizationKey key = new VerificationItemUtilizationKey();

    key.verificationItemUtilizationID = details.verificationItemUtilizationID;
    // Read the Verification Item Utilization record
    readVerificationItemUtilizationDetails.readDtls = verificationItemUtilization.read(
      key);

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();
    final ItemUtilizationLevelDateStatusAndVerifiableIDDetails itemUtilizationLevelDateStatusAndVerifiableIDDetails = new ItemUtilizationLevelDateStatusAndVerifiableIDDetails();

    itemUtilizationLevelDateStatusAndVerifiableIDDetails.fromDate = readVerificationItemUtilizationDetails.readDtls.fromDate;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.level = readVerificationItemUtilizationDetails.readDtls.verificationLevel;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.recordStatus = RECORDSTATUS.CANCELLED;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.toDate = readVerificationItemUtilizationDetails.readDtls.toDate;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.verifiableDataItemID = readVerificationItemUtilizationDetails.readDtls.verifiableDataItemID;
    final CountActiveRequirementForItemUtilization countActiveRequirementForItemUtilization = verificationRequirementObj.countActiveRequirements(
      itemUtilizationLevelDateStatusAndVerifiableIDDetails);

    if (countActiveRequirementForItemUtilization.recordCount > 0) {
      final LocalisableString infoMessage1 = new LocalisableString(
        curam.message.ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATION_UTILIZATION_FV_IMPACT_ACTIVE_VERIFICATION_REQUIREMENTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage1, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // The informational must now be converted to a format
      // suitable for return to the client.
      final String[] informationalArray = informationalManager.obtainInformationalAsString();

      // The array of informational strings must be
      // transferred to an array of structs because we
      // cannot return an array of strings directly. Each
      // string goes into one struct

      for (int i = 0; i != informationalArray.length; i++) {
        final VerificationMessage warning = new VerificationMessage();

        warning.message = informationalArray[i];
        verificationMessageList.dtls.addRef(warning);

      }
    }

    return verificationMessageList;

  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification Item Utilization record
   *
   * @param details Verification Item Utilization details
   *
   * @return The unique identifier of the record created
   */
  @Override
  public VerificationItemUtilizationKey createVerificationItemUtilization(
    CreateVerificationItemUtilizationDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    // BEGIN, CR00348467, SSK
    final VerificationItemDetails verificationItemDetails = new VerificationItemDetails();

    verificationItemDetails.verifiableDataItemID = details.createDtls.verifiableDataItemID;
    verificationItemDetails.verificationItemID = details.createDtls.verificationItemID;
    verificationItemDetails.usageType = details.createDtls.usageType;
    validateVerificationItemUsageType(verificationItemDetails);
    // END, CR00348467
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;

    // Create a Verification Item Utilization record
    verificationItemUtilization.insert(details.createDtls);

    // Create and populate the return struct
    final VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = details.createDtls.verificationItemUtilizationID;

    return verificationItemUtilizationKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists a Verification Item Utilization record
   *
   * @param key Verification Item Utilization key
   */
  @Override
  public VerificationItemUtilizationList listVerificationItemUtilization(
    VerifiableDataItemKey key) throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    // create return structure
    final VerificationItemUtilizationList verificationItemUtilizationList = new VerificationItemUtilizationList();

    // get listVerification Item Utilization Details
    verificationItemUtilizationList.listDtls = verificationItemUtilization.searchVerificationItemUtilizationListDetails(
      key);

    return verificationItemUtilizationList;
  }

  // BEGIN, CR00220755, JF
  // ___________________________________________________________________________
  /**
   * Lists a Verification Item Utilization record and versionNo
   *
   * @param key Verification Item Utilization key
   */
  @Override
  public VerificationItemUtilizationListAndVersionNo listVerificationItemUtilizationAndVersionNo(VerifiableDataItemKey key)
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    // create return structure
    final VerificationItemUtilizationListAndVersionNo verificationItemUtilizationListAndVersionNo = new VerificationItemUtilizationListAndVersionNo();

    // get listVerification Item Utilization Details
    verificationItemUtilizationListAndVersionNo.dtls = verificationItemUtilization.searchVerificationItemUtilizationListDetailsAndVersionNo(
      key);

    return verificationItemUtilizationListAndVersionNo;
  }

  // END, CR00220755, JF

  // ___________________________________________________________________________
  /**
   * Modifies a Verification Item Utilization record
   *
   * @param details Verification Item Utilization details
   */
  @Override
  public VerificationMessageList modifyVerificationItemUtilization(
    ModifyVerificationItemUtilizationDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final VerificationMessageList verificationMessageList = new VerificationMessageList();

    // Create and populate the Verification Item Utilization key
    final VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = details.modifyDtls.verificationItemUtilizationID;

    // BEGIN, CR00348467, SSK
    validateVIUsageTypeOnModify(details.modifyDtls);
    // END, CR00348467
    // Modify a Verification Item Utilization record
    verificationItemUtilization.modify(verificationItemUtilizationKey,
      details.modifyDtls);

    // Create the return object
    final ReadVerificationItemUtilizationDetails readVerificationItemUtilizationDetails = new ReadVerificationItemUtilizationDetails();
    final VerificationItemUtilizationKey key = new VerificationItemUtilizationKey();

    key.verificationItemUtilizationID = details.modifyDtls.verificationItemUtilizationID;
    // Read the Verification Item Utilization record
    readVerificationItemUtilizationDetails.readDtls = verificationItemUtilization.read(
      key);

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();
    final ItemUtilizationLevelDateStatusAndVerifiableIDDetails itemUtilizationLevelDateStatusAndVerifiableIDDetails = new ItemUtilizationLevelDateStatusAndVerifiableIDDetails();

    itemUtilizationLevelDateStatusAndVerifiableIDDetails.fromDate = readVerificationItemUtilizationDetails.readDtls.fromDate;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.level = readVerificationItemUtilizationDetails.readDtls.verificationLevel;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.recordStatus = RECORDSTATUS.CANCELLED;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.toDate = readVerificationItemUtilizationDetails.readDtls.toDate;
    itemUtilizationLevelDateStatusAndVerifiableIDDetails.verifiableDataItemID = readVerificationItemUtilizationDetails.readDtls.verifiableDataItemID;
    final CountActiveRequirementForItemUtilization countActiveRequirementForItemUtilization = verificationRequirementObj.countActiveRequirements(
      itemUtilizationLevelDateStatusAndVerifiableIDDetails);

    if (countActiveRequirementForItemUtilization.recordCount > 0) {
      final LocalisableString infoMessage1 = new LocalisableString(
        curam.message.ENTVERIFICATIONITEMUTILIZATION.ERR_VERIFICATION_UTILIZATION_FV_MODIFY_IMPACT_ACTIVE_VERIFICATION_REQUIREMENTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage1, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // The informational must now be converted to a format
      // suitable for return to the client.
      final String[] informationalArray = informationalManager.obtainInformationalAsString();

      // The array of informational strings must be
      // transferred to an array of structs because we
      // cannot return an array of strings directly. Each
      // string goes into one struct

      for (int i = 0; i != informationalArray.length; i++) {
        final VerificationMessage warning = new VerificationMessage();

        warning.message = informationalArray[i];
        verificationMessageList.dtls.addRef(warning);

      }
    }

    return verificationMessageList;
  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification Item Utilization record
   *
   * @param key Verification Item Utilization details
   *
   * @return Details of the Verification Item Utilization record
   */
  @Override
  public ReadVerificationItemUtilizationDetails readVerificationItemUtilization(VerificationItemUtilizationKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    // VerifiableDataItem variables
    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItem = VerifiableDataItemFactory.newInstance();
    final VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    // Verification Item variables
    final curam.verification.sl.entity.intf.VerificationItem verificationItem = curam.verification.sl.entity.fact.VerificationItemFactory.newInstance();
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    // Create the return object
    final ReadVerificationItemUtilizationDetails readVerificationItemUtilizationDetails = new ReadVerificationItemUtilizationDetails();

    // Read the Verification Item Utilization record
    readVerificationItemUtilizationDetails.readDtls = verificationItemUtilization.read(
      key);

    verifiableDataItemKey.verifiableDataItemID = readVerificationItemUtilizationDetails.readDtls.verifiableDataItemID;

    readVerificationItemUtilizationDetails.verifiableDataItemName = verifiableDataItem.readNameByID(verifiableDataItemKey).name;

    verificationItemKey.verificationItemID = readVerificationItemUtilizationDetails.readDtls.verificationItemID;

    readVerificationItemUtilizationDetails.verificationItemName = verificationItem.readNameByID(verificationItemKey).name;

    return readVerificationItemUtilizationDetails;

  }

  // BEGIN, CR00348467, SSK
  /**
   * Validate the verification item utilization usage type. Verification item
   * utilization
   * cannot have different usage type across verification groups and
   * verification item utilization.
   *
   * @param verificationItemDetails
   * Contain verification item utilization details.
   */
  @Override
  public void validateVerificationItemUsageType(
    final VerificationItemDetails verificationItemDetails)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();
    final SearchByVerificationItem searchByVerificationItem = new SearchByVerificationItem();

    searchByVerificationItem.verifiableDataItemID = verificationItemDetails.verifiableDataItemID;
    searchByVerificationItem.verificationItemID = verificationItemDetails.verificationItemID;
    searchByVerificationItem.recordStatus = RECORDSTATUS.NORMAL;
    final VerificationItemUtilizationUsageDetailsList verificationItemUtilizationUsageDetailsList = verificationItemUtilization.searchByVerificationItemAndVerificableDataItem(
      searchByVerificationItem);
    AppException appException;

    final VerificationItem verificationItem = VerificationItemFactory.newInstance();
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    verificationItemKey.verificationItemID = verificationItemDetails.verificationItemID;

    // BEGIN, CR00350224, SSK
    if (StringUtil.isNullOrEmpty(verificationItemDetails.usageType)) {
      verificationItemDetails.usageType = VERIFICATIONITEMUSAGETYPE.SHARED;
    }
    // END, CR00350224
    final VerificationItemNameDetails verificationItemNameDetails = verificationItem.readNameByID(
      verificationItemKey);

    for (final VerificationItemUtilizationUsageDetails verificationItemUtilizationUsageDetails : verificationItemUtilizationUsageDetailsList.dtls) {
      // BEGIN, CR00349524, SSK
      if (!verificationItemUtilizationUsageDetails.usageType.equals(
        verificationItemDetails.usageType)
          && verificationItemDetails.verificationItemUtilizationID
            != verificationItemUtilizationUsageDetails.verificationItemUtilizationID) {
        // END, CR00349524
        appException = new AppException(
          ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_XRV_DIFFERENT_USAGE_TYPE);
        appException.arg(
          VERIFICATIONITEMNAMEEntry.get(verificationItemNameDetails.name).toUserLocaleString());
        ValidationHelper.addValidationError(appException);
        ValidationHelper.failIfErrorsExist();
      }
    }
  }

  /**
   * Validate the verification item utilization usage type on modification.
   * Verification item utilization
   * cannot have different usage type across verification groups and
   * verification item utilization.
   *
   * @param vGItems
   * Contain verification item utilization details.
   */
  protected void validateVIUsageTypeOnModify(
    final VerificationItemUtilizationDtls verificationItemUtilizationDetails)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final ReadVerificationItemUtilizationDetails readVerificationItemUtilizationDetails = new ReadVerificationItemUtilizationDetails();
    final VerificationItemUtilizationKey key = new VerificationItemUtilizationKey();

    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    key.verificationItemUtilizationID = verificationItemUtilizationDetails.verificationItemUtilizationID;
    // Read the Verification Item Utilization record
    readVerificationItemUtilizationDetails.readDtls = verificationItemUtilization.read(
      key);

    final SearchByVerificationItem searchByVerificationItem = new SearchByVerificationItem();

    final VerificationItem verificationItem = VerificationItemFactory.newInstance();
    final VerificationItemKey verificationItemKey = new VerificationItemKey();

    searchByVerificationItem.verifiableDataItemID = verificationItemUtilizationDetails.verifiableDataItemID;
    searchByVerificationItem.verificationItemID = verificationItemUtilizationDetails.verificationItemID;
    searchByVerificationItem.recordStatus = RECORDSTATUS.NORMAL;
    final VerificationItemUtilizationUsageDetailsList verificationItemUtilizationUsageDetailsList = verificationItemUtilization.searchByVerificationItemAndVerificableDataItem(
      searchByVerificationItem);
    AppException appException;

    verificationItemKey.verificationItemID = verificationItemUtilizationDetails.verificationItemID;
    final VerificationItemNameDetails verificationItemNameDetails = verificationItem.readNameByID(
      verificationItemKey);

    for (final VerificationItemUtilizationUsageDetails verificationItemUtilizationUsageDetails : verificationItemUtilizationUsageDetailsList.dtls) {

      if (!verificationItemUtilizationUsageDetails.usageType.equals(
        verificationItemUtilizationDetails.usageType)
          && verificationItemUtilizationUsageDetails.verificationItemUtilizationID
            != verificationItemUtilizationDetails.verificationItemUtilizationID) {
        appException = new AppException(
          ENTVERIFICATIONITEM.ERR_VERIFICATIONITEM_XRV_DIFFERENT_USAGE_TYPE);
        appException.arg(
          VERIFICATIONITEMNAMEEntry.get(verificationItemNameDetails.name).toUserLocaleString());
        ValidationHelper.addValidationError(appException);
        ValidationHelper.failIfErrorsExist();
      }
    }
  }

  // END, CR00348467

}
