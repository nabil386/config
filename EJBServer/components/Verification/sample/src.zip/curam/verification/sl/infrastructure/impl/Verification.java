/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2020. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;

import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTNAME;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFIABLEITEMNAME;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CountDetails;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.CaseIDEvidenceIDTypeStatusesKey;
import curam.core.sl.infrastructure.entity.struct.EvdInstanceObjDtls;
import curam.core.sl.infrastructure.entity.struct.EvdInstanceObjDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorIDRelatedIDAndEvidenceType;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeCaseIDStatusesKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeParticipantIDStatusesKey;
import curam.core.sl.infrastructure.entity.struct.ParticipantIDEvidenceTypeStatusesKey;
import curam.core.sl.infrastructure.entity.struct.ReadRelatedIDParticipantIDAndEvidenceTypeDetails;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.struct.CaseIDAndParticipantRoleIDKey;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndTypeDetails;
import curam.core.struct.CaseReferenceConcernRoleNameCaseTypeAltID;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CaseTypeICTypeAndStartDate;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductNameStructRef;
import curam.core.struct.SecurityResult;
import curam.core.struct.UsersKey;
import curam.message.ENTDEPENDANTDATAITEM;
import curam.message.ENTVERIFICATION;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.message.SEPARATOR;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.verification.impl.VerificationUtilities;
import curam.verification.sl.entity.fact.VerificationItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.VerifiableDataItem;
import curam.verification.sl.entity.intf.VerificationItem;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.intf.VerificationRequirement;
import curam.verification.sl.entity.struct.CommentsDetails;
import curam.verification.sl.entity.struct.ItemUtilizationRequirementKey;
import curam.verification.sl.entity.struct.SearchByVerifiableDataItemIdList;
import curam.verification.sl.entity.struct.SearchByVerifiableDataItemIdListList;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerifiableDataItemSecurityDetails;
import curam.verification.sl.entity.struct.VerificationDetails;
import curam.verification.sl.entity.struct.VerificationItemDtls;
import curam.verification.sl.entity.struct.VerificationItemKey;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationIDMandatoryDetailsList;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.entity.struct.VerificationRequirementIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.entity.struct.VerificationRequirementLevelMandatoryAndDatesDetails;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.struct.CaseIDAndEvdStatusKey;
import curam.verification.sl.infrastructure.entity.struct.CaseIDVerificationStatusKey;
import curam.verification.sl.infrastructure.entity.struct.ItemProvidedIDAndVDIEDLinkIDDetails;
import curam.verification.sl.infrastructure.entity.struct.ReadByVerLinkedIDTypeAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.ReadVerificationStatusLinkedIDandTypeKey;
import curam.verification.sl.infrastructure.entity.struct.SearchByCaseIDConcernRoleAndEvidenceTypeKey;
import curam.verification.sl.infrastructure.entity.struct.SearchByVerLinkedIDTypeAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.SearchByVerifiableDataItemIDKey;
import curam.verification.sl.infrastructure.entity.struct.SearchParticipantCaseVerificationsKey;
import curam.verification.sl.infrastructure.entity.struct.StatusAndVDIEDLinkIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerifiableDataItemName;
import curam.verification.sl.infrastructure.entity.struct.VerificationAndVDIEDLinkDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationAndVDIEDLinkDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationByVerificationLinkedIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationCountAndEvidenceTypeDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationEvidenceDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationEvidenceDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationIDAndStatusDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedListDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationKeyList;
import curam.verification.sl.infrastructure.entity.struct.VerificationLinkedIDAndIsCaseIDKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationRecordCount;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDStatusDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementModifyDueDateDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationStatusDetails;
import curam.verification.sl.infrastructure.fact.OutstandingVerificationAttachmentLinkFactory;
import curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetails;
import curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList;
import curam.verification.sl.infrastructure.struct.CaseIDEvidenceIDAndTypeKey;
import curam.verification.sl.infrastructure.struct.EvidenceAndDataItemNameDetails;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationDetails;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationListDetails;
import curam.verification.sl.infrastructure.struct.ItemProvidedCount;
import curam.verification.sl.infrastructure.struct.ModifyVerificationRequirementDueDateKey;
import curam.verification.sl.infrastructure.struct.OutstandingIndicator;
import curam.verification.sl.infrastructure.struct.ParticipantIDAndEvidenceTypeKey;
import curam.verification.sl.infrastructure.struct.ReadVerificationDueDateDetails;
import curam.verification.sl.infrastructure.struct.VerificationCaseInfo;
import curam.verification.sl.infrastructure.struct.VerificationCountAndEvidenceTypeDetailsList;
import curam.verification.sl.infrastructure.struct.VerificationInfo;
import curam.verification.sl.infrastructure.struct.VerificationInfoList;
import curam.verification.sl.infrastructure.struct.VerificationItemAndUtilization;
import curam.verification.sl.infrastructure.struct.VerificationItemExpiryDate;
import curam.verification.sl.infrastructure.struct.VerificationItemProvidedExpiryDateDetails;
import curam.verification.sl.infrastructure.struct.VerificationItemProvidedExpiryDateDetailsList;
import curam.verification.sl.infrastructure.struct.VerificationItemProvidedInfo;
import curam.verification.sl.infrastructure.struct.VerificationLinkedIDAndRecordStatusCode;
import curam.verification.sl.infrastructure.struct.VerificationRequirementSummaryDetails;
import curam.verification.sl.infrastructure.struct.ViewVerificationDetails;
import curam.verification.sl.struct.VerificationPageContextDetails;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * This class contains methods for fetching verification requirements,
 * determining verification status, modify due date etc.
 */
public class Verification
  extends curam.verification.sl.infrastructure.base.Verification {

  protected static final int kBufSize = 256;

  // BEGIN, CR00222190, ELG
  /**
   * Constant for the separator used in the context description.
   *
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText
   * (TransactionInfo.getProgramLocale())}. Replacement reason -
   * static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note
   * <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00069956, GM
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  protected static final String kSpace = CuramConst.gkSpace;

  private final VerificationUtilities verificationUtilities =
    new VerificationUtilities();

  private final VerificationItem verificationItemObj =
    VerificationItemFactory.newInstance();

  private final VerificationItemUtilization verificationItemUtilizationObj =
    VerificationItemUtilizationFactory.newInstance();

  // END, CR00069956
  // ___________________________________________________________________________
  /**
   * This method reads the verification details. There is a new version of this
   * method - readVerificationDetails1, therefore if there is any change in this
   * method then developer is suggested to visit readVerificationDetails1 as
   * well.
   *
   * @param dtls
   * details about the evidence and VDIEDLinkID
   *
   * @return The verification details
   */
  @Override
  public ViewVerificationDetails
    readVerificationDetails(final EvidenceVerificationDetails dtls)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is a new version of this method - readVerificationDetails1,
    // therefore if there is any change in this
    // method then developer is suggested to visit readVerificationDetails1 as
    // well.
    // END, CR00452604
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    final ViewVerificationDetails viewVerificationDetails =
      new ViewVerificationDetails();

    // verifiable data item variables
    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItem =
      curam.verification.sl.entity.fact.VerifiableDataItemFactory
        .newInstance();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    VerifiableDataItemSecurityDetails verifiableDataItemsecurityDetails =
      new VerifiableDataItemSecurityDetails();
    SecurityResult securityResult = new SecurityResult();

    // BEGIN, CR00017998, KY
    final curam.verification.sl.infrastructure.intf.VerificationItemProvided verificationItemProvidedObj =
      curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
        .newInstance();
    // END, CR00017998

    // BEGIN, CR00018000, KY
    VerificationItemProvidedExpiryDateDetails itemProvidedExpiryDateDetails =
      new VerificationItemProvidedExpiryDateDetails();
    final VerificationItemProvidedExpiryDateDetailsList itemProvidedExpiryDateDetailsList =
      new VerificationItemProvidedExpiryDateDetailsList();
    // END, CR00018000

    final UsersKey userKey = new UsersKey();

    // populate the user name
    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // VerificationRequirement variables
    final VerificationRequirement verificationRequirement =
      VerificationRequirementFactory.newInstance();

    VerificationRequirementSummaryDetails verificationSummaryDetails;

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();
    final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

    vdiedLinkKey.VDIEDLinkID = dtls.vdIEDLinkID;

    final VerificationDtlsList verificationDtlsList =
      verification.readByVDIEDLinkID(vdiedLinkKey);

    // BEGIN, CR00075368, SPD
    // Case header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // END, CR00075368

    final CaseKey caseKey = new CaseKey();
    VerificationDetails verificationDetails;
    VerificationDtls verificationDtls;

    final VerificationRequirementKey verificationRequirementKey =
      new VerificationRequirementKey();

    CaseReferenceAndTypeDetails caseReferenceAndTypeDetails =
      new CaseReferenceAndTypeDetails();

    final EvidenceAndDataItemNameDetails evidenceAndDataItemNameDetails =
      new EvidenceAndDataItemNameDetails();

    // Evidence Description details variables
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorDtls evidenceDescriptorDtls;
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    // comment variable
    final CommentsDetails commentsDetails = new CommentsDetails();

    // BEGIN, CR00021309, NK
    // security variables
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    // END, CR00021309

    // to get the Item Provided list details
    VerificationItemProvidedListDetailsList verificationItemProvidedListDetailsList =
      new VerificationItemProvidedListDetailsList();

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    // BEGIN, CR 3140, RK
    final VerificationItemProvidedKey verificationItemProvidedKey =
      new VerificationItemProvidedKey();
    // END, CR 3140

    final StatusAndVDIEDLinkIDDetails statusAndVDIEDLinkIDDetails =
      new StatusAndVDIEDLinkIDDetails();

    // To get Concern role name and with participant ID
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();
    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // Product Delivery variable to get Product Name
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    // Product Name Struct
    ProductNameStructRef productNameStructRef = new ProductNameStructRef();

    // BEGIN, CR00021309, NK
    // check for participant sensitivity
    // Participant security check variables
    final curam.core.intf.ParticipantSecurityCheck participantSecurityCheckObj =
      curam.core.fact.ParticipantSecurityCheckFactory.newInstance();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();

    securityResult.result = false;

    // BEGIN, CR00075820, POH
    // populate key with passed in evidenceDescriptorID
    evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;

    // read evidence descriptor details
    evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;
    evidenceDescriptorDtls =
      evidenceDescriptorObj.read(evidenceDescriptorKey);

    participantKeyStruct.participantID = evidenceDescriptorDtls.participantID;
    // END, CR00075820

    securityResult =
      participantSecurityCheckObj.authorize(participantKeyStruct, userKey);

    // if the result is false, it means the user does not have access to
    // this case
    if (!securityResult.result) {
      throw new AppException(
        curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
    }
    // END, CR00021309

    for (int i = 0; i < verificationDtlsList.dtls.size(); i++) {
      verificationDtls = verificationDtlsList.dtls.item(i);

      // assign value
      verificationRequirementKey.verificationRequirementID =
        verificationDtls.verificationRequirementID;
      verificationDetails = verificationRequirement
        .readVerificationDetails(verificationRequirementKey);

      // assign level, min items from verification details and
      // due date, verificationStatus from verificationDtls
      verificationSummaryDetails =
        new VerificationRequirementSummaryDetails();

      verificationSummaryDetails.level =
        verificationDetails.verificationLevel;
      verificationSummaryDetails.minimumItems =
        verificationDetails.minimumItems;

      // BEGIN, CR00075875, JPG
      // Added a filter to not process cancelled records
      if (verificationDtls.verificationStatus
        .equals(VERIFICATIONSTATUS.CANCELLED)) {
        continue;
      } else if (verificationDtls.verificationStatus
        .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
        verificationSummaryDetails.dueDate = verificationDtls.dueDate;
        verificationSummaryDetails.dueDateModifiableInd =
          verificationDetails.dueDateModifiableInd;
      } else {
        verificationSummaryDetails.dueDateModifiableInd = false;
      }
      // END, CR00075875
      verificationSummaryDetails.verificationStatus =
        verificationDtls.verificationStatus;
      verificationSummaryDetails.verificationID =
        verificationDtls.verificationID;
      verificationSummaryDetails.mandatory = verificationDetails.mandatory;

      // BEGIN, CR00074026, BF
      // Read the caseID based on the verificationID
      // The caseID is no longer stored on the verification entity -
      // instead a verificationLinkedID & verificationLinkedType (IC, PD or
      // Participant)
      // Reading here for caseID so search for verLinkedType of PD or IC
      // BEGIN, CR00350929, ARM
      if (!verificationDtls.verificationLinkedType
        .equals(VERIFICATIONTYPE.NONCASEDATA)) {
        // END, CR00350929
        caseKey.caseID = verificationDtls.verificationLinkedID;

        caseReferenceAndTypeDetails =
          caseHeaderObj.readCaseReferenceAndTypeByCaseID(caseKey);
        caseReferenceAndTypeDetails =
          caseHeaderObj.readCaseReferenceAndTypeByCaseID(caseKey);

        verificationSummaryDetails.caseReference =
          caseReferenceAndTypeDetails.caseReference;

        CaseTypeICTypeAndStartDate caseTypeICTypeAndStartDate;

        if (caseReferenceAndTypeDetails.caseTypeCode
          .equals(CASETYPECODE.INTEGRATEDCASE)) {

          // read IC Case type
          caseHeaderKey.caseID = verificationDtls.verificationLinkedID;
          caseTypeICTypeAndStartDate =
            caseHeaderObj.readCaseTypeICTypeAndStartDate(caseHeaderKey);
          ctitemKey.code = caseTypeICTypeAndStartDate.integratedCaseType;

          ctitemKey.locale = TransactionInfo.getProgramLocale();
          ctitemKey.tableName = PRODUCTCATEGORY.TABLENAME;
          // BEGIN, CR00163098, JC
          ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
          // END, CR00163098, JC
          verificationSummaryDetails.caseType = ctitem.description;

        } // BEGIN, CR00351546, RPB
        else if (caseReferenceAndTypeDetails.caseTypeCode
          .equals(CASETYPECODE.PRODUCTDELIVERY)) {
          // END, CR00351546

          productDeliveryKey.caseID = verificationDtls.verificationLinkedID;
          productNameStructRef =
            productDeliveryObj.readProductName(productDeliveryKey);

          // convert code to value
          ctitemKey.code = productNameStructRef.name;
          ctitemKey.locale = TransactionInfo.getProgramLocale();
          ctitemKey.tableName = PRODUCTNAME.TABLENAME;
          // BEGIN, CR00163098, JC
          ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
          // END, CR00163098, JC
          verificationSummaryDetails.caseType = ctitem.description;

          // BEGIN, CR00021309, NK
          caseSecurityCheckKey.caseID = verificationDtls.verificationLinkedID;
          caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

          // BEGIN, CR00227042, PM
          final DataBasedSecurityResult dataBasedSecurityResult =
            dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

          if (dataBasedSecurityResult.restricted) {
            // END, CR00227042

            ctitemKey.code = CASETYPECODE.RESTRICTEDACCESS;
            ctitemKey.locale = TransactionInfo.getProgramLocale();
            ctitemKey.tableName = CASETYPECODE.TABLENAME;
            // BEGIN, CR00163098, JC
            ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
            // END, CR00163098, JC
            verificationSummaryDetails.caseType = ctitem.description;
            verificationSummaryDetails.dueDate =
              curam.util.type.Date.kZeroDate;
            verificationSummaryDetails.minimumItems = 0;
          }
          // END, CR00021309
        }
      }
      // END, CR00074026
      viewVerificationDetails.summaryDetailsList
        .addRef(verificationSummaryDetails);

    } // end of for loop

    // fetch Items received details
    statusAndVDIEDLinkIDDetails.vdIEDLinkID = dtls.vdIEDLinkID;
    statusAndVDIEDLinkIDDetails.recordStatus = RECORDSTATUS.NORMAL;

    verificationItemProvidedListDetailsList = verificationItemProvided
      .searchListDetailsByStatusAndVDIEDLinkID(statusAndVDIEDLinkIDDetails);

    // BEGIN, CR 3140, RK

    for (int i = 0; i < verificationItemProvidedListDetailsList.dtls
      .size(); i++) {

      verificationItemProvidedKey.verificationItemProvidedID =
        verificationItemProvidedListDetailsList.dtls
          .item(i).verificationItemProvidedID;

      // BEGIN, CR00017998, KY
      // BEGIN, CR00018000, KY
      itemProvidedExpiryDateDetails =
        new VerificationItemProvidedExpiryDateDetails();
      itemProvidedExpiryDateDetails
        .assign(verificationItemProvidedListDetailsList.dtls.item(i));
      itemProvidedExpiryDateDetails.expiryDate = verificationItemProvidedObj
        .calculateExpiryDate(verificationItemProvidedKey).expiryDate;
      itemProvidedExpiryDateDetailsList.itemProvidedDetails
        .add(itemProvidedExpiryDateDetails);
      // END, CR00018000
      // END, CR00017998
    }

    // END, CR 3140

    vdIEDLinkDtls = vdIEDLinkObj.read(vdiedLinkKey);
    verifiableDataItemKey.verifiableDataItemID =
      vdIEDLinkDtls.verifiableDataItemID;

    commentsDetails.comments = verifiableDataItem
      .readCommentsByDataItemID(verifiableDataItemKey).comments;

    // BEGIN, CR00075820, POH
    // read details from related evidence descriptor
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
      evidenceDescriptorDtls.relatedID;

    // Indicator used to indicate if dealing with participant evidence
    boolean isNonCaseEDForParticipantEvidence = false;

    // determine if verification item provided is being created for participant
    // level evidence
    // Evidence controller variables
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    isNonCaseEDForParticipantEvidence =
      evidenceControllerObj.isNonCaseEDForParticipantEvidence(
        evidenceDescriptorIDRelatedIDAndEvidenceType);
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    final boolean isPDCEvidence =
      evidenceControllerObj.isPDCEvidence(evidenceTypeKey);

    // only read by caseID if dealing with integrated case or product delivery
    if (!isNonCaseEDForParticipantEvidence && !isPDCEvidence) {
      // if product delivery get the integrated case id
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

        evidenceAndDataItemNameDetails.caseID = caseHeaderObj
          .readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;

      } else {

        // BEGIN, CR00075582, RF
        evidenceAndDataItemNameDetails.caseID = dtls.verificationLinkedID;
        // END, CR00075582
      }
    } // BEGIN, CR00080141, AL
    else {
      evidenceAndDataItemNameDetails.caseID = caseKey.caseID;
    }
    // END, CR00080141

    evidenceAndDataItemNameDetails.dataItemName =
      vdIEDLinkObj.readVerifiableDataItemName(vdiedLinkKey).name;

    // Get the participant name
    // evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;
    // evidenceDescriptorDtls =
    evidenceDescriptorObj.read(evidenceDescriptorKey);
    evidenceAndDataItemNameDetails.evidenceStatus =
      evidenceDescriptorDtls.statusCode;

    // get the Concern Role name from Participant ID.
    concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);
    evidenceAndDataItemNameDetails.clientName =
      concernRoleNameDetails.concernRoleName;

    // assign all the structs to return struct
    // BEGIN, CR00018000, KY
    // assign the verification item provided details which has expiry date info
    // also
    viewVerificationDetails.itemProvidedListDetailsList =
      itemProvidedExpiryDateDetailsList;
    // END, CR00018000

    viewVerificationDetails.dtls = evidenceAndDataItemNameDetails;
    viewVerificationDetails.commentDtls = commentsDetails;

    verifiableDataItemsecurityDetails =
      verifiableDataItem.readViewSecurityDetails(verifiableDataItemKey);

    if (verifiableDataItemsecurityDetails.viewSID.length() != 0) {

      securityResult.result =
        curam.util.security.Authorisation.isSIDAuthorised(
          verifiableDataItemsecurityDetails.viewSID, userKey.userName);

      if (!securityResult.result) {

        final AppException appException = new AppException(
          ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_FV_NO_APPROPRIATE_PRIVILEGES);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(appException,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    return viewVerificationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Determines the verification status and updates the verification entity.
   *
   * @param key
   * identifies the VDIEDLink record
   */
  @Override
  public void determineVerificationStatus(final VDIEDLinkKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00079706, CR00080087 POH
    // verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.entity.fact.VerificationFactory
        .newInstance();
    final SearchByCaseIDConcernRoleAndEvidenceTypeKey searchByCaseIDConcernRoleAndEvidenceTypeKey =
      new SearchByCaseIDConcernRoleAndEvidenceTypeKey();
    // END, CR00080087

    // VDIEDLink variables
    final VDIEDLink vDIEDLinkObj = VDIEDLinkFactory.newInstance();
    VDIEDLinkDtls vDIEDLinkDtls = new VDIEDLinkDtls();
    VDIEDLinkIDDtlsList vDIEDLinkIDDtlsList = new VDIEDLinkIDDtlsList();
    final VDIEDLinkIDDtls vDIEDLinkIDDtls = new VDIEDLinkIDDtls();
    final SearchByVerifiableDataItemIDKey searchByVerifiableDataItemIDKey =
      new SearchByVerifiableDataItemIDKey();

    // Evidence descriptor variables
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    // BEGIN, CR00080087, POH
    EvidenceDescriptorDtls evidenceDescriptorDtls =
      new EvidenceDescriptorDtls();
    // END, CR00080087

    // Evidence controller variables
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();
    boolean isEvidenceParticipantData = false;

    // read VDIEDLink details
    vDIEDLinkDtls = vDIEDLinkObj.read(key);

    // BEGIN, CR00080087, POH
    // read evidence descriptor details
    evidenceDescriptorKey.evidenceDescriptorID =
      vDIEDLinkDtls.evidenceDescriptorID;
    evidenceDescriptorDtls =
      evidenceDescriptorObj.read(evidenceDescriptorKey);

    // BEGIN, CR00385944, RPB
    // populate searchByCaseIDConcernRoleAndEvidenceTypeKey
    searchByCaseIDConcernRoleAndEvidenceTypeKey.caseID =
      evidenceDescriptorDtls.caseID;
    searchByCaseIDConcernRoleAndEvidenceTypeKey.concernRoleID =
      evidenceDescriptorDtls.participantID;
    searchByCaseIDConcernRoleAndEvidenceTypeKey.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    // BEGIN, CR00451715, MR
    searchByCaseIDConcernRoleAndEvidenceTypeKey.verificationStatus =
      VERIFICATIONSTATUS.CANCELLED;
    searchByCaseIDConcernRoleAndEvidenceTypeKey.evidenceStatus =
      EVIDENCEDESCRIPTORSTATUS.CANCELED;
    // END, CR00451715
    // END, CR00080087

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    // END, CR00385944

    // determine if the evidence is participant evidence
    isEvidenceParticipantData =
      evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);

    if (isEvidenceParticipantData) {

      // BEGIN, CR00075820, POH
      VerificationDtlsList verificationDtlsList = new VerificationDtlsList();
      final SearchParticipantCaseVerificationsKey searchParticipantCaseVerificationsKey =
        new SearchParticipantCaseVerificationsKey();

      // read all verifications for passed in VDIEDLinkKey
      verificationDtlsList = verificationObj.readByVDIEDLinkID(key);

      // Check if the verifications records are at participant level.
      // Participant level and case level verifications will have their own
      // VDIEDLink entities created, hence only need to check first record in
      // the list to determine if dealing with participant or case level
      // verifications.
      if (verificationDtlsList.dtls.item(0).verificationLinkedType
        .equals(curam.codetable.VERIFICATIONTYPE.NONCASEDATA)) {

        // populate key with VDIEDLinkID passed in as the key for the method.
        vDIEDLinkIDDtls.VDIEDLinkID = key.VDIEDLinkID;

        // add details to key to be passed in
        vDIEDLinkIDDtlsList.dtls.addRef(vDIEDLinkIDDtls);

        // populate key
        searchParticipantCaseVerificationsKey.participantRoleID =
          verificationDtlsList.dtls.item(0).verificationLinkedID;
        searchParticipantCaseVerificationsKey.VDIEDLinkID = key.VDIEDLinkID;
        // pass in table name as want records to be returned at case level and
        // participant level.
        searchParticipantCaseVerificationsKey.verificationLinkedType =
          curam.codetable.RECORDSTATUS.NORMAL;
        // BEGIN, CR00451715, MR
        searchParticipantCaseVerificationsKey.verificationStatus =
          VERIFICATIONSTATUS.CANCELLED;
        // END, CR00451715
        // BEGIN, CR00451715, MR
        // read all verifications relating to the participant that exist at
        // integrated case and product delivery level
        verificationDtlsList =
          verificationObj.searchParticipantCaseVerifications2(
            searchParticipantCaseVerificationsKey);

        // determine the status of the verifications relating to the participant
        // that exist at integrated case and product delivery level
        determineStatus(verificationDtlsList, vDIEDLinkIDDtlsList);
        // END, CR00451715

      } else {

        // populate searchByVerifiableDataItemIDKey
        // BEGIN, CR00385944, RPB
        searchByVerifiableDataItemIDKey.participantID =
          evidenceDescriptorDtls.participantID;
        // END, CR00385944
        searchByVerifiableDataItemIDKey.verifiableDataItemID =
          vDIEDLinkDtls.verifiableDataItemID;

        // read all VDIEDLinks relating to the participant
        vDIEDLinkIDDtlsList =
          vDIEDLinkObj.searchVDIEDLinkByVerifiableDataItemAndParticipantID(
            searchByVerifiableDataItemIDKey);

        final VDIEDLinkIDDtlsList determinsStatusVDIEDLinkIDDtlsList =
          new VDIEDLinkIDDtlsList();

        // returned vDIEDLinkIDDtlsList contains all vDIEDLink's that exist
        // for a participant across all cases and at participant level.
        // Only want VDIEDLink details belong to participant for the case
        // that is currently being process and the participant level VDIEDlink.
        for (int i = 0; i < vDIEDLinkIDDtlsList.dtls.size(); i++) {

          if (vDIEDLinkIDDtlsList.dtls
            .item(i).VDIEDLinkID == key.VDIEDLinkID) {
            determinsStatusVDIEDLinkIDDtlsList.dtls
              .addRef(vDIEDLinkIDDtlsList.dtls.item(i));
          } else {

            // VDIEDLink manipulation variables
            final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

            vDIEDLinkKey.VDIEDLinkID =
              vDIEDLinkIDDtlsList.dtls.item(i).VDIEDLinkID;

            // read evidenceType and evidenceDescriptorID set
            final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
              vDIEDLinkObj
                .readEDIDRelatedIDAndEvidenceTypeByVDIEDLinkID(vDIEDLinkKey);

            boolean isNonCaseEDForParticipantEvidence = false;

            // determine if vDIEDLink is used at participant level
            isNonCaseEDForParticipantEvidence =
              evidenceControllerObj.isNonCaseEDForParticipantEvidence(
                evidenceDescriptorIDRelatedIDAndEvidenceType);

            // if vDIEDLink is used at participant level add to key to be passed
            // into determineStatus method.
            if (isNonCaseEDForParticipantEvidence) {
              determinsStatusVDIEDLinkIDDtlsList.dtls
                .addRef(vDIEDLinkIDDtlsList.dtls.item(i));
            }
          }

        }
        // BEGIN, CR00451715, MR
        // BEGIN, CR00080087, POH
        // read all verifications relating to the participant that exist at
        // the integrated case and product delivery level
        final VerificationDtlsList tempVerificationDtlsList =
          verificationObj.searchByCaseIDConcernRoleAndEvidenceType2(
            searchByCaseIDConcernRoleAndEvidenceTypeKey);

        // END, CR00080087
        determineStatus(tempVerificationDtlsList,
          determinsStatusVDIEDLinkIDDtlsList);
        // END, CR00451715
      }

    } else {

      // populate key with VDIEDLinkID passed in as the key for the method.
      vDIEDLinkIDDtls.VDIEDLinkID = key.VDIEDLinkID;
      vDIEDLinkIDDtlsList.dtls.addRef(vDIEDLinkIDDtls);
      // BEGIN, CR00451715, MR
      // BEGIN, CR00080087, POH
      // read all verifications relating to the participant that exist at
      // the integrated case and product delivery level
      final VerificationDtlsList tempVerificationDtlsList =
        verificationObj.searchByCaseIDConcernRoleAndEvidenceType2(
          searchByCaseIDConcernRoleAndEvidenceTypeKey);

      // END, CR00080087

      // determine the status of the verifications
      determineStatus(tempVerificationDtlsList, vDIEDLinkIDDtlsList);
      // END, CR00451715

    }
    // END, CR00075820
  }

  // BEGIN, CR00075820, POH
  // ___________________________________________________________________________
  /**
   * Determines the verification status for either a participant verification or
   * integrated case/product delivery verification and updates the verification
   * entity.
   *
   * @param dtls
   * Verification Requirement ID Details List
   * @param vDIEDLinkIDDtlsList
   * List of verification requirements requiring verification.
   */
  @Override
  @Deprecated
  public void determineStatus(final VerificationRequirementIDDetailsList dtls,
    final VDIEDLinkIDDtlsList vDIEDLinkIDDtlsList)
    throws AppException, InformationalException {

    final VerificationStatusDeterminator statusDeterminator =
      new VerificationStatusDeterminator(dtls, vDIEDLinkIDDtlsList);

    statusDeterminator.determineStatus();
  }

  // END, CR00075820, CR00079706
  // ___________________________________________________________________________

  // BEGIN, CR00451715, MR
  /**
   * Determines the verification status for either a participant verification or
   * integrated case/product delivery verification and updates the verification
   * entity.
   *
   * @param dtls
   * Verification Requirement ID Details List
   * @param vDIEDLinkIDDtlsList
   * List of verification requirements requiring verification.
   */

  public void determineStatus(final VerificationDtlsList dtls,
    final VDIEDLinkIDDtlsList vDIEDLinkIDDtlsList)
    throws AppException, InformationalException {

    final VerificationStatusDeterminator statusDeterminator =
      new VerificationStatusDeterminator(dtls, vDIEDLinkIDDtlsList);

    statusDeterminator.determineStatus();
  }

  // END, CR00451715

  /**
   * Modifies due date.
   *
   * @param details
   * modification details of the due date
   */
  @Override
  public void
    modifyDueDate(final ModifyVerificationRequirementDueDateKey details)
      throws AppException, InformationalException {

    // Verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    final VerificationKey verificationKey = new VerificationKey();

    verificationKey.verificationID = details.verificationID;
    final VerificationRequirementModifyDueDateDtls verificationRequirementModifyDueDateDtls =
      new VerificationRequirementModifyDueDateDtls();

    verificationRequirementModifyDueDateDtls.dueDate = details.dueDate;

    verification.modifyDueDate(verificationKey,
      verificationRequirementModifyDueDateDtls);

    // Raise the due date changed event
    final Event dueDateChangedEvent = new Event();

    dueDateChangedEvent.eventKey = curam.events.Verification.DueDateChanged;

    dueDateChangedEvent.primaryEventData = details.verificationID;
    dueDateChangedEvent.secondaryEventData =
      VerificationConst.gkDueDateChanged;

    EventService.raiseEvent(dueDateChangedEvent);
  }

  // ___________________________________________________________________________
  /**
   * This method lists all the evidence verification details for the given case
   * ID and evidence type.
   *
   * @param key
   * contains case ID and evidence type to identity the records
   *
   * @return list of evidence verification details
   */
  @Override
  public EvidenceVerificationDetailsList
    listEvidenceVerificationDetails(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // BEGIN, 00032741, DK
    // return struct
    final EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      new EvidenceVerificationDetailsList();
    // END, 00032741

    // Evidence Descriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    // BEGIN, CR00386928, SSK
    final EvidenceTypeCaseIDStatusesKey evidenceTypeCaseIDStatusesKey =
      new EvidenceTypeCaseIDStatusesKey();

    evidenceTypeCaseIDStatusesKey.caseID = key.caseID;
    evidenceTypeCaseIDStatusesKey.evidenceType = key.evidenceType;
    evidenceTypeCaseIDStatusesKey.statusCode1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    evidenceTypeCaseIDStatusesKey.statusCode2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;
    evidenceTypeCaseIDStatusesKey.statusCode3 =
      EVIDENCEDESCRIPTORSTATUS.SUPERSEDED;
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
      filterEvidenceDesriptorToDisplayVerifications(evidenceDescriptor
        .searchByCaseIDEvidenceTypeAndStatus(evidenceTypeCaseIDStatusesKey));

    // BEGIN, CR00264164, JMA
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = key.evidenceType;
    final EvidenceDescriptorDtlsList fullEvidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();

    fullEvidenceDescriptorDtlsList.assign(evidenceDescriptorDtlsList);

    EvidenceDescriptorDtlsList participantEvidenceDescriptorDtlsList;
    EvidenceTypeParticipantIDStatusesKey participantIDEvidenceTypeStatusesKey;

    // Get Participant Evidence verifications
    if (evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey)) {
      for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls) {

        participantIDEvidenceTypeStatusesKey =
          new EvidenceTypeParticipantIDStatusesKey();

        participantIDEvidenceTypeStatusesKey.evidenceType = key.evidenceType;
        participantIDEvidenceTypeStatusesKey.participantID =
          evidenceDescriptorDtls.relatedID;
        participantIDEvidenceTypeStatusesKey.statusCode1 =
          EVIDENCEDESCRIPTORSTATUS.ACTIVE;
        participantIDEvidenceTypeStatusesKey.statusCode2 =
          EVIDENCEDESCRIPTORSTATUS.INEDIT;

        participantEvidenceDescriptorDtlsList =
          evidenceDescriptor.searchByEvidenceTypeParticipantIDAndStatus(
            participantIDEvidenceTypeStatusesKey);

        for (final EvidenceDescriptorDtls particpantEvidenceDescriptor : participantEvidenceDescriptorDtlsList.dtls) {

          fullEvidenceDescriptorDtlsList.dtls
            .addRef(particpantEvidenceDescriptor);
        }
      }
    }

    // BEGIN, 00032741, DK
    final EvidenceVerificationListDetails tempDetailsList =
      retrieveEvidenceVerificationDetails(fullEvidenceDescriptorDtlsList);
    // END, CR00386928
    // BEGIN, CR00075582, RF
    // BEGIN, CR00102105 ,BD
    // read case type to set the verificationLinkedType
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    // END, CR00102105

    // BEGIN, CR00386928, RPB
    final String verificationEntryCode =
      verificationUtilities.getRelatedItemID(caseKey).getCode();

    // END, CR00386928

    for (int i = 0; i < tempDetailsList.verificationDtls.size(); i++) {

      final curam.core.sl.infrastructure.struct.EvidenceVerificationDetails evidenceVerificationDetails =
        new curam.core.sl.infrastructure.struct.EvidenceVerificationDetails();

      // BEGIN, CR00350929, ARM
      // BEGIN, CR00371307, AKr
      // BEGIN, CR00386928, RPB
      evidenceVerificationDetails.verificationLinkedType =
        verificationEntryCode;
      // END, CR00386928
      // END, CR00371307
      // END, CR00350929

      // END, CR00075582
      evidenceVerificationDetails.verificationLinkedID = key.caseID;
      evidenceVerificationDetails.dataItemName =
        tempDetailsList.verificationDtls.item(i).dataItemName;
      evidenceVerificationDetails.evidenceDescriptorID =
        tempDetailsList.verificationDtls.item(i).evidenceDescriptorID;
      evidenceVerificationDetails.relatedID =
        tempDetailsList.verificationDtls.item(i).relatedID;
      evidenceVerificationDetails.summary =
        tempDetailsList.verificationDtls.item(i).summary;
      evidenceVerificationDetails.vdIEDLinkID =
        tempDetailsList.verificationDtls.item(i).vdIEDLinkID;
      evidenceVerificationDetails.verificationStatus =
        tempDetailsList.verificationDtls.item(i).verificationStatus;
      // BEGIN, CR00078288, CH
      evidenceVerificationDetails.evidenceType = key.evidenceType;
      // END, CR00078288

      evidenceVerificationDetailsList.verificationDtls
        .addRef(evidenceVerificationDetails);
    }

    return evidenceVerificationDetailsList;
    // END, 00032741
  }

  // ___________________________________________________________________________
  /**
   * Reads due date for the given verification key.
   *
   * @param key
   * identifies the verification record
   *
   * @return Due date for verification
   */
  @Override
  public ReadVerificationDueDateDetails readDueDate(final VerificationKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    final ReadVerificationDueDateDetails readVerificationDueDateDetails =
      new ReadVerificationDueDateDetails();

    readVerificationDueDateDetails.readDtls = verification.readDueDate(key);
    return readVerificationDueDateDetails;

  }

  // BEGIN, CR00074026, BF
  // ___________________________________________________________________________
  /**
   * Lists All CASE Type verification record. This method should never be used
   * to read verifications for a participant.
   *
   * @param key
   * identifies the case
   * @param indicator
   * indicates outstanding verifications
   *
   * @return The List of all case verifications
   */
  @Override
  public CaseEvidenceVerificationDetailsList listCaseVerificationDetails(
    final CaseKeyStruct key, final OutstandingIndicator indicator)
    throws AppException, InformationalException {

    // END, CR00074026
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    // EvidenceDescriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();

    // VDIEDLink variables
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();
    final VDIEDLink vDIEDLink = VDIEDLinkFactory.newInstance();

    ReadRelatedIDParticipantIDAndEvidenceTypeDetails readRelatedIDParticipantIDAndEvidenceTypeDetails =
      new ReadRelatedIDParticipantIDAndEvidenceTypeDetails();

    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    CaseEvidenceVerificationDetails caseEvidenceVerificationDetails =
      new CaseEvidenceVerificationDetails();

    // BEGIN, CR00074026, BF
    // case header variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    // END, CR00074026

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    // BEGIN, CR00074026, BF
    // Read the caseType and then search for verifications based on the caseType
    caseKey.caseID = key.caseID;
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    // BEGIN, CR00386928, SSK
    final SearchByVerLinkedIDTypeAndStatusKey searchByVerLinkedIDTypeAndStatusKey =
      new SearchByVerLinkedIDTypeAndStatusKey();

    searchByVerLinkedIDTypeAndStatusKey.verificationLinkedID = key.caseID;
    searchByVerLinkedIDTypeAndStatusKey.evidenceDescriptorStatus1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    searchByVerLinkedIDTypeAndStatusKey.evidenceDescriptorStatus2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;
    searchByVerLinkedIDTypeAndStatusKey.evidenceDescriptorStatus3 =
      EVIDENCEDESCRIPTORSTATUS.SUPERSEDED;

    // BEGIN, CR00350929, ARM
    // Set the verificationLinkedType based on the caseType

    searchByVerLinkedIDTypeAndStatusKey.verificationLinkedType =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00386928

    // END, CR00350929

    VerificationAndVDIEDLinkDetailsList verificationAndVDIEDLinkDetailsList;
    final ReadVerificationStatusLinkedIDandTypeKey readVerificationStatusLinkedIDandTypeKey =
      new ReadVerificationStatusLinkedIDandTypeKey();

    readVerificationStatusLinkedIDandTypeKey.verificationLinkedID =
      key.caseID;
    readVerificationStatusLinkedIDandTypeKey.verificationStatus =
      indicator.verificationStatus;
    readVerificationStatusLinkedIDandTypeKey.evidenceDescriptorStatus1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    // BEGIN, CR00085770, MR
    readVerificationStatusLinkedIDandTypeKey.evidenceDescriptorStatus2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;
    // END, CR00085770

    // BEGIN, CR00350929, ARM
    // BEGIN, CR00371307, AKr
    readVerificationStatusLinkedIDandTypeKey.verificationLinkedType =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00350929

    if (indicator.verificationStatus.equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
      verificationAndVDIEDLinkDetailsList =
        verification.searchOutstandingVerAndVDIEDLinkDetailsByLinkedIDandType(
          readVerificationStatusLinkedIDandTypeKey);
    } else {

      // BEGIN, CR00386928, SSK
      verificationAndVDIEDLinkDetailsList =
        filterVerificationEvidenceDetails(verification
          .searchVerificationVDIEDLinkDtlsByVerLinkedIDTypeAndStatus(
            searchByVerLinkedIDTypeAndStatusKey));

    }
    // END, CR00074026

    final Map<Long, Long> existingVerifications = new HashMap<Long, Long>();

    // END, CR00074026
    for (int i = 0; i < verificationAndVDIEDLinkDetailsList.dtls
      .size(); i++) {
      evidenceDescriptorKey.evidenceDescriptorID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).evidenceDescriptorID;

      readRelatedIDParticipantIDAndEvidenceTypeDetails = evidenceDescriptor
        .readRelatedIDParticipantIDAndEvidenceType(evidenceDescriptorKey);

      caseEvidenceVerificationDetails = new CaseEvidenceVerificationDetails();

      // assign the associated verification details to the struct
      // Create Evidence Interface For Evidence Type
      final EvidenceMap map = EvidenceController.getEvidenceMap();
      // BEGIN, CR00059540, POH
      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(
          readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType);

      // Retrieve evidence details for list display
      eiEvidenceKey.evidenceID =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
      eiEvidenceKey.evidenceType =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;

      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

      // BEGIN, CR00244064, CD
      // Summary may now be marked up as client formatted text.
      // Ensure that this assignment keeps to it's original contract.
      eiFieldsForListDisplayDtls.summary = LocalizableXMLStringHelper
        .toPlainText(eiFieldsForListDisplayDtls.summary);
      // END, CR00244064

      // END, CR00059540

      caseEvidenceVerificationDetails.concernRoleID =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID;
      caseEvidenceVerificationDetails.evidence =
        eiFieldsForListDisplayDtls.summary;
      // Read Verifiable Data Item Name
      vDIEDLinkKey.VDIEDLinkID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).VDIEDLinkID;

      // BEGIN, CR00452978, GK
      final VerifiableDataItemName verifiableDataItemName =
        vDIEDLink.readVerifiableDataItemName(vDIEDLinkKey);

      ctitemKey.code = verifiableDataItemName.name;
      caseEvidenceVerificationDetails.verifiableDataItemIDOpt =
        verificationAndVDIEDLinkDetailsList.dtls
          .item(i).verifiableDataItemIDOpt;
      // END, CR00452978
      ctitemKey.locale = TransactionInfo.getProgramLocale();
      ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
      // BEGIN, CR00163098, JC
      ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
      // END, CR00163098, JC
      caseEvidenceVerificationDetails.verifiableDataItemName =
        ctitem.description;
      caseEvidenceVerificationDetails.vDIEDLinkID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).VDIEDLinkID;
      caseEvidenceVerificationDetails.evidenceDescriptorID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).evidenceDescriptorID;
      // BEGIN, CR00452774, GK
      caseEvidenceVerificationDetails.verifiableDataItemIDOpt =
        verificationAndVDIEDLinkDetailsList.dtls
          .item(i).verifiableDataItemIDOpt;
      // END, CR00452774
      // BEGIN, CR00021587, NK
      caseEvidenceVerificationDetails.mandatory =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).mandatory;
      // END, CR00021587

      // System reads Participant Name
      if (readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID != 0) {

        // ConcernRole manipulation variables
        final CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey =
          new CaseIDAndParticipantRoleIDKey();

        final CaseParticipantRole caseParticipantRole =
          CaseParticipantRoleFactory.newInstance();

        caseIDAndParticipantRoleIDKey.caseID = key.caseID;
        caseIDAndParticipantRoleIDKey.participantRoleID =
          readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID;

        caseEvidenceVerificationDetails.caseParticpantRoleID =
          caseParticipantRole
            .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(
              caseIDAndParticipantRoleIDKey).caseParticipantRoleID;

        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID =
          readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID;

        concernRoleNameDetails =
          concernRoleObj.readConcernRoleName(concernRoleKey);

        // Retrieve participant's name
        caseEvidenceVerificationDetails.primaryClient =
          concernRoleNameDetails.concernRoleName;
      }

      // BEGIN, CR00260117, FM
      caseEvidenceVerificationDetails.verificationID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).verificationID;
      // END, CR00260117

      // since status has been updated fetch it again
      final VerificationKey verificationKey = new VerificationKey();

      verificationKey.verificationID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).verificationID;
      caseEvidenceVerificationDetails.verificationStatus = verification
        .readVerificationStatus(verificationKey).verificationStatus;

      final CountDetails documentsSubmittedCount =
        OutstandingVerificationAttachmentLinkFactory.newInstance()
          .countPendingReviewVerificationAttachments(verificationKey);

      caseEvidenceVerificationDetails.documentSubmittedOpt =
        documentsSubmittedCount.numberOfRecords > 0;

      if (caseEvidenceVerificationDetails.verificationStatus
        .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
        caseEvidenceVerificationDetails.dueDate =
          verificationAndVDIEDLinkDetailsList.dtls.item(i).dueDate;
        // BEGIN, CR00439301, AKr
        final CountDetails itemsProvidedCount =
          countItemsProvided(vDIEDLinkKey);

        if (0 < itemsProvidedCount.numberOfRecords) {
          caseEvidenceVerificationDetails.itemProvided = true;
        } else {
          caseEvidenceVerificationDetails.itemProvided = false;
        }
        // END, CR00439301
      }
      // BEGIN, CR00075875, JPG
      if (!caseEvidenceVerificationDetails.verificationStatus
        .equals(VERIFICATIONSTATUS.CANCELLED)) {
        // BEGIN, CR00386928, SSK
        final VerificationDtls verificationDtls =
          verification.read(verificationKey);
        boolean isDuplicateVerifications = true;

        if (Configuration.getBooleanProperty(
          EnvVars.ENV_DUPLICATE_VERIFICATION_FILTERING_ENABLED)) {
          if (existingVerifications
            .containsKey(caseEvidenceVerificationDetails.vDIEDLinkID)
            && existingVerifications.get(
              caseEvidenceVerificationDetails.vDIEDLinkID) == verificationDtls.verificationRequirementID) {
            isDuplicateVerifications = false;

          }
        }

        if (isDuplicateVerifications) {

          existingVerifications.put(
            caseEvidenceVerificationDetails.vDIEDLinkID,
            verificationDtls.verificationRequirementID);
          caseEvidenceVerificationDetailsList.dtls
            .addRef(caseEvidenceVerificationDetails);
        }
        // END, CR00386928

      }
      // END, CR00075875
    }
    return caseEvidenceVerificationDetailsList;
  }

  // BEGIN, CR 3954, RK
  // ___________________________________________________________________________
  /**
   * The isItemsProvided method checks if verification item has been provided
   * for Verification requirements.
   *
   * @param vDIEDLinkKey
   * VDIED link key
   *
   * @return The count of verification items provided
   */
  public ItemProvidedCount isItemsProvided(final VDIEDLinkKey vDIEDLinkKey)
    throws AppException, InformationalException {

    // verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    final ItemProvidedCount itemProvidedCount = new ItemProvidedCount();

    itemProvidedCount.itemsProvidedCount = false;

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    final VerificationItemUtilization verificationItemUtilization =
      VerificationItemUtilizationFactory.newInstance();
    VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    ItemProvidedIDAndVDIEDLinkIDDetails itemProvidedIDAndVDIEDLinkIDKey;
    VerificationItemProvidedIDDetailsList verificationItemProvidedIDDetailsList;

    final VDIEDLink vDIEDLink = VDIEDLinkFactory.newInstance();

    verifiableDataItemKey =
      vDIEDLink.readDataItemIDByVDIEDLinkID(vDIEDLinkKey);

    final VerificationRequirement verificationRequirement =
      VerificationRequirementFactory.newInstance();

    VerificationRequirementIDStatusDetailsList verificationRequirementIDStatusDetailsList =
      new VerificationRequirementIDStatusDetailsList();

    final VerificationRequirementIDAndStatusKey verificationRequirementIDAndStatusKey =
      new VerificationRequirementIDAndStatusKey();

    verificationRequirementIDStatusDetailsList =
      verification.readRequirementIDStatusByVDIEDLinkID(vDIEDLinkKey);

    for (int i = 0; i < verificationRequirementIDStatusDetailsList.dtls
      .size(); i++) {

      verificationRequirementIDAndStatusKey.verificationRequirementID =
        verificationRequirementIDStatusDetailsList.dtls
          .item(i).verificationRequirementID;
      verificationRequirementIDAndStatusKey.recordStatus =
        RECORDSTATUS.CANCELLED;

      final VerificationRequirementLevelMandatoryAndDatesDetails reqtLevelMandatoryAndDatesDetails =
        verificationRequirement.readLevelFromDateTodateAndMandatory(
          verificationRequirementIDAndStatusKey);

      final ItemUtilizationRequirementKey itemUtilizationRequirementKey =
        new ItemUtilizationRequirementKey();

      // populate details for fetching utilization records
      itemUtilizationRequirementKey.verifiableDataItemID =
        verifiableDataItemKey.verifiableDataItemID;
      itemUtilizationRequirementKey.level =
        reqtLevelMandatoryAndDatesDetails.level;

      itemUtilizationRequirementKey.fromDate = Date.getCurrentDate();

      itemUtilizationRequirementKey.toDate = Date.getCurrentDate();

      itemUtilizationRequirementKey.recordStatus = RECORDSTATUS.CANCELLED;

      final VerificationItemUtilizationIDMandatoryDetailsList verificationItemUtilizationIDDetailsList =
        verificationItemUtilization
          .searchAllActiveByVerifiableDataItemIDLevelAndDates(
            itemUtilizationRequirementKey);

      for (int j = 0; j < verificationItemUtilizationIDDetailsList.dtls
        .size(); j++) {

        itemProvidedIDAndVDIEDLinkIDKey =
          new ItemProvidedIDAndVDIEDLinkIDDetails();
        itemProvidedIDAndVDIEDLinkIDKey.VDIEDLinkID =
          vDIEDLinkKey.VDIEDLinkID;
        itemProvidedIDAndVDIEDLinkIDKey.verificationItemUtilizationID =
          verificationItemUtilizationIDDetailsList.dtls
            .item(j).verificationItemUtilizationID;
        itemProvidedIDAndVDIEDLinkIDKey.recordStatus = RECORDSTATUS.CANCELLED;

        try {

          verificationItemProvidedIDDetailsList = verificationItemProvided
            .searhActiveItemProvidedByItemUtilizationIDAndVDIEDLinkID(
              itemProvidedIDAndVDIEDLinkIDKey);

          if (verificationItemProvidedIDDetailsList.dtls.size() > 0) {
            // verification item is provided, so increment the count
            itemProvidedCount.itemsProvidedCount = true;
          }

        } catch (final RecordNotFoundException ex) {// Do nothing
        }

      }
    }

    return itemProvidedCount;
  }

  // END, CR 3954

  // ___________________________________________________________________________
  /**
   * Lists Integrated case Verification requirement records.
   *
   * @param key
   * identifies the case
   *
   * @return The List Of Integrated case verifications
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listIntegratedCaseVerificationDetails(final CaseKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.DEFAULTCODE;
    caseEvidenceVerificationDetailsList
      .assign(listCaseVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists Integrated case outstanding verification record.
   *
   * @param key
   * identifies the case
   *
   * @return The List Of Outstanding Integrated case verification
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listOutstandingIntegratedCaseVerificationDetails(final CaseKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;
    caseEvidenceVerificationDetailsList
      .assign(listCaseVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists a Product delivery Outstanding Verification record.
   *
   * @param key
   * identifies the case
   *
   * @return The List Of Outstanding Product delivery verification
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listPDOutstandingCaseVerificationDetails(final CaseKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;
    caseEvidenceVerificationDetailsList
      .assign(listCaseVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists a Product delivery Verification record.
   *
   * @param key
   * The case ID
   *
   * @return The List Of Product delivery verification
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listProductDeliveryCaseVerificationDetails(final CaseKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.DEFAULTCODE;
    caseEvidenceVerificationDetailsList
      .assign(listCaseVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Integrated Case.
   *
   * @param key
   * identifies the Case Key
   *
   * @return Page title context description for Integrated Case
   */
  @Override
  public VerificationPageContextDetails readICPageContextDescription(
    final CaseKeyStruct key) throws AppException, InformationalException {

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    CaseConcernRoleName caseConcernRoleName = new CaseConcernRoleName();

    final CaseIDKey caseIDKey = new CaseIDKey();

    CaseReferenceConcernRoleNameCaseTypeAltID caseReferenceConcernRoleNameCaseTypeAltID;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    ICHomePageNameAndType icHomePageNameAndType;

    // register the security implementation
    SecurityImplementationFactory.register();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Read caseHeader
    caseKey.caseID = key.caseID;
    caseIDKey.caseID = key.caseID;
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    // Read CaseHeader
    caseReferenceConcernRoleNameCaseTypeAltID = caseHeaderObj
      .readCaseReferenceCaseTypeConcernRoleNameAlternateID(caseIDKey);

    // Create the context description
    final StringBuffer buffer = new StringBuffer(kBufSize);

    buffer.append(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        icHomePageNameAndType.integratedCaseType,
        TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    buffer.append(kSpace);
    buffer.append(icHomePageNameAndType.caseReference);
    // BEGIN, CR00098942, SAI
    buffer.append(kSpace);
    // END, CR00098942

    // BEGIN, CR00222190, ELG
    buffer.append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText(TransactionInfo.getProgramLocale()));
    // END, CR00222190

    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    buffer.append(caseConcernRoleName.concernRoleName);
    buffer.append(kSpace);
    buffer
      .append(caseReferenceConcernRoleNameCaseTypeAltID.primaryAlternateID);

    // Assign it to the return object
    verificationPageContextDetails.description = buffer.toString();

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Product Delivery.
   *
   * @param key
   * identifies the Case Key
   *
   * @return Page title context description for Product Delivery
   */
  @Override
  public VerificationPageContextDetails readPDPageContextDescription(
    final CaseKeyStruct key) throws AppException, InformationalException {

    // Create return object
    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceConcernRoleNameCaseTypeAltID caseReferenceConcernRoleNameCaseTypeAltID;
    // BEGIN, CR00052924, GM
    String productTypeDesc = CuramConst.gkEmpty;
    // END, CR00052924
    final int kBufSize = 256;

    // Create and initialize StringBuffer
    final StringBuffer contextDescription = new StringBuffer(kBufSize);

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read CaseHeader
    caseIDKey.caseID = key.caseID;

    // Read CaseHeader
    caseReferenceConcernRoleNameCaseTypeAltID = caseHeaderObj
      .readCaseReferenceCaseTypeConcernRoleNameAlternateID(caseIDKey);

    if (caseReferenceConcernRoleNameCaseTypeAltID.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)) {

      // ProductDelivery manipulation variables
      final curam.core.intf.ProductDelivery productDeliveryObj =
        curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryTypeDetails productDeliveryTypeDetails;

      // Set key to read productDelivery
      productDeliveryKey.caseID = key.caseID;

      // Read ProductDelivery
      productDeliveryTypeDetails =
        productDeliveryObj.readProductType(productDeliveryKey);

      productTypeDesc = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryTypeDetails.productType,
          TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

    }

    // append the description details
    // BEGIN, CR00222190, ELG
    // BEGIN, CR00098942, SAI
    contextDescription.append(productTypeDesc).append(kSpace)
      .append(caseReferenceConcernRoleNameCaseTypeAltID.caseReference)
      .append(kSpace)
      .append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
        .getMessageText(TransactionInfo.getProgramLocale()))
      .append(caseReferenceConcernRoleNameCaseTypeAltID.concernRoleName)
      .append(kSpace)
      .append(caseReferenceConcernRoleNameCaseTypeAltID.primaryAlternateID);
    // END, CR00098942
    // END, CR00222190
    verificationPageContextDetails.description =
      contextDescription.toString();

    return verificationPageContextDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method reads Page Context Description for View Verification Details.
   *
   * @param details
   * contains verification details
   *
   * @return VerificationPageContextDetails
   */
  @Override
  public VerificationPageContextDetails
    readPageContextDescriptionForViewVerificationDetails(
      final EvidenceVerificationDetails details)
      throws AppException, InformationalException {

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();
    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();
    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();

    final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

    vdiedLinkKey.VDIEDLinkID = details.vdIEDLinkID;

    // convert name code to value
    ctitemKey.code =
      vdIEDLinkObj.readVerifiableDataItemName(vdiedLinkKey).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC
    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns the list of evidence verification details.
   *
   * @param key
   * evidence descriptor key list
   * @return list of evidence verification details
   */
  @Override
  public EvidenceVerificationListDetails
    getEvidenceVerificationDetails(final EvidenceDescriptorKeyList key)
      throws AppException, InformationalException {

    // Evidence Descriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    final EvidenceVerificationListDetails evidenceVerificationDetailsList =
      new EvidenceVerificationListDetails();
    EvidenceVerificationDetails evidenceVerificationDetails =
      new EvidenceVerificationDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    // EIEvidenceKey object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
    final EvidenceMap map = EvidenceController.getEvidenceMap();
    // VDIEDLink variables
    final VDIEDLink vdIEDLink = VDIEDLinkFactory.newInstance();
    VDIEDLinkIDAndDataItemIDDetailsList vdIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    // Verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    VerificationKeyList verificationKeyList;
    boolean verified = false;

    // BEGIN, CR00386928, RPB
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final VerifiableDataItem verifiableDataItem =
      curam.verification.sl.entity.fact.VerifiableDataItemFactory
        .newInstance();

    // END, CR00386928

    // iterate through the evidence descriptors
    for (int i = 0; i < key.dtls.size(); i++) {

      evidenceDescriptorKey.evidenceDescriptorID =
        key.dtls.item(i).evidenceDescriptorID;
      vdIEDLinkIDAndDataItemIDDetailsList =
        vdIEDLink.readByEvidenceDescriptorID(evidenceDescriptorKey);

      // BEGIN, CR00102105 ,BD
      // assign summary
      final EvidenceDescriptorDtls evidenceDescriptDtls =
        evidenceDescriptor.read(evidenceDescriptorKey);

      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(evidenceDescriptDtls.evidenceType);

      eiEvidenceKey.evidenceType = evidenceDescriptDtls.evidenceType;
      // Retrieve evidence details for list display
      eiEvidenceKey.evidenceID = evidenceDescriptDtls.relatedID;

      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

      // BEGIN, CR00244064, CD
      // Summary may now be marked up as client formatted text.
      // Ensure that this assignment keeps to it's original contract.
      eiFieldsForListDisplayDtls.summary = LocalizableXMLStringHelper
        .toPlainText(eiFieldsForListDisplayDtls.summary);
      // read case type to set the verificationLinkedType
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = evidenceDescriptDtls.caseID;

      // BEGIN, CR00102588, BD
      CaseTypeCode caseTypeCode = null;
      // BEGIN, CR00386928, RPB
      String verificationLinkedType = null;

      // If we have a caseID read the case type code.
      if (evidenceDescriptDtls.caseID != 0) {
        // Read CaseHeader
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
        verificationLinkedType =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00386928
      }
      // END, CR00102588
      // END, CR00102105
      // BEGIN, CR00386928, RPB
      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
      final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
        new EvidenceDescriptorIDRelatedIDAndEvidenceType();

      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
        evidenceDescriptDtls.evidenceDescriptorID;
      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
        evidenceDescriptDtls.evidenceType;
      evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
        evidenceDescriptDtls.relatedID;
      boolean isNonCaseEDForParticipantEvidence;

      isNonCaseEDForParticipantEvidence =
        evidenceControllerObj.isNonCaseEDForParticipantEvidence(
          evidenceDescriptorIDRelatedIDAndEvidenceType);
      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType = evidenceDescriptDtls.evidenceType;
      final boolean isPDCEvidence =
        evidenceControllerObj.isPDCEvidence(evidenceTypeKey);

      // END, CR00386928

      // iterate through the VDIEDLink IDs
      for (int j = 0; j < vdIEDLinkIDAndDataItemIDDetailsList.dtls
        .size(); j++) {

        // BEGIN, CR00468469, GK
        final VDIEDLinkKey vdiedLinkIDKey = new VDIEDLinkKey();

        vdiedLinkIDKey.VDIEDLinkID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;

        final VerificationDtlsList verificationDtlsList =
          verification.searchActiveVerificationByVDIEDLinkID(vdiedLinkIDKey);

        // determine the verification status for the data item
        if (verificationDtlsList.dtls.size() == 0) {
          continue;
        } else {
          final VDIEDLinkAndStatusKey vDIEDLinkAndStatus =
            new VDIEDLinkAndStatusKey();

          vDIEDLinkAndStatus.VDIEDLinkID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
          vDIEDLinkAndStatus.verificationStatus =
            VERIFICATIONSTATUS.NOTVERIFIED;
          verificationKeyList =
            verification.searchByVDIEDLinkIDStatus(vDIEDLinkAndStatus);
          verified = verificationKeyList.dtls.size() == 0;
        }
        // END, CR00468469
        evidenceVerificationDetails = new EvidenceVerificationDetails();

        evidenceVerificationDetails.summary =
          eiFieldsForListDisplayDtls.summary;

        // BEGIN, CR 3023, RK
        evidenceVerificationDetails.relatedID =
          evidenceDescriptDtls.relatedID;
        // END, CR 3023

        // BEGIN, CR00075582, RF
        // If participant evidence and not associated with a case
        if (isNonCaseEDForParticipantEvidence || isPDCEvidence) {
          evidenceVerificationDetails.verificationLinkedID =
            evidenceDescriptDtls.participantID;
          evidenceVerificationDetails.verificationLinkedType =
            VERIFICATIONTYPE.NONCASEDATA;

          // Has to be case level verification
        } else if (evidenceDescriptDtls.caseID != 0) {

          evidenceVerificationDetails.verificationLinkedID =
            evidenceDescriptDtls.caseID;

          // BEGIN, CR00350929, ARM
          // BEGIN, CR00371307, AKr
          // BEGIN, CR00386928, RPB
          evidenceVerificationDetails.verificationLinkedType =
            verificationLinkedType;
          // END, CR00386928
          // END, CR00371307
          // END, CR00350929

        }
        // END, CR00075582

        evidenceVerificationDetails.vdIEDLinkID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
        if (verified) {
          evidenceVerificationDetails.verificationStatus =
            VERIFICATIONSTATUS.VERIFIED;
        } else {
          evidenceVerificationDetails.verificationStatus =
            VERIFICATIONSTATUS.NOTVERIFIED;
        }

        // assign dataItemName
        final VerifiableDataItemKey verifiableDataItemKey =
          new VerifiableDataItemKey();

        verifiableDataItemKey.verifiableDataItemID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls
            .item(j).verifiableDataItemID;
        evidenceVerificationDetails.dataItemName =
          verifiableDataItem.readNameByID(verifiableDataItemKey).name;
        evidenceVerificationDetails.evidenceDescriptorID =
          key.dtls.item(i).evidenceDescriptorID;
        evidenceVerificationDetailsList.verificationDtls
          .addRef(evidenceVerificationDetails);

      }

    }
    return evidenceVerificationDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all the verification associated with a evidence of a case.
   *
   * @param key
   * identifies the evidence descriptor and verification records
   *
   * @return Verification requirements for the evidence
   */
  @Override
  public EvidenceVerificationListDetails
    listEvidenceItemVerificationDetails(final CaseIDEvidenceIDAndTypeKey key)
      throws AppException, InformationalException {

    // Evidence Descriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorKeyList evidenceDescriptorKeyList =
      new EvidenceDescriptorKeyList();

    final CaseIDEvidenceIDTypeStatusesKey caseIDEvidenceIDTypeStatusesKey =
      new CaseIDEvidenceIDTypeStatusesKey();

    caseIDEvidenceIDTypeStatusesKey.caseID = key.caseID;
    caseIDEvidenceIDTypeStatusesKey.evidenceID = key.evidenceID;
    caseIDEvidenceIDTypeStatusesKey.evidenceType = key.evidenceType;

    // caseIDEvidenceIDTypeStatusesKey.assign(key);
    caseIDEvidenceIDTypeStatusesKey.statusCode1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    caseIDEvidenceIDTypeStatusesKey.statusCode2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;

    evidenceDescriptorKeyList =
      evidenceDescriptor.searchActiveInEditByCaseIDEvidenceIDAndType(
        caseIDEvidenceIDTypeStatusesKey);

    return getEvidenceVerificationDetails(evidenceDescriptorKeyList);

  }

  // ___________________________________________________________________________
  /**
   * Reads the page context description (data item name) for due date modifiable
   * page.
   *
   * @param key
   * verification key
   *
   * @return Page context details
   */
  @Override
  public VerificationPageContextDetails readPageContextDescriptionForDueDate(
    final VerificationKey key) throws AppException, InformationalException {

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      curam.verification.sl.infrastructure.entity.fact.VerificationFactory
        .newInstance();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // BEGIN, HARP, 61683 RK
    ctitemKey.code =
      verification.readNameByVerificationID(key).verifiableDataItemName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC
    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // BEGIN, CR00018197, KY
  /**
   * This method removes the expired verification items from the list.
   *
   * @param verificationItemProvidedIDDetailsList
   * Contains the list of Verification Items provided to satisfy the
   * verification requirement.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void filterExpiredVerificationItems(
    final VerificationItemProvidedIDDetailsList verificationItemProvidedIDDetailsList)
    throws AppException, InformationalException {

    final VerificationItemProvidedKey verificationItemProvidedKey =
      new VerificationItemProvidedKey();
    final curam.verification.sl.infrastructure.intf.VerificationItemProvided verificationItemProvided =
      curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
        .newInstance();
    VerificationItemExpiryDate expiryDate;

    for (int i = 0; i < verificationItemProvidedIDDetailsList.dtls.size();) {

      verificationItemProvidedKey.verificationItemProvidedID =
        verificationItemProvidedIDDetailsList.dtls
          .item(i).verificationItemProvidedID;

      expiryDate = verificationItemProvided
        .calculateExpiryDate(verificationItemProvidedKey);

      // BEGIN, CR00227793, NS
      if (!Date.kZeroDate.equals(expiryDate.expiryDate)
        && expiryDate.expiryDate.before(Date.getCurrentDate())) {
        // END, CR00227793
        verificationItemProvidedIDDetailsList.dtls.remove(i);
      } else {
        i++;
      }
    }
  }

  // END, CR00018197

  // BEGIN, CR00075582, RF
  // ___________________________________________________________________________
  /**
   * The method <code>listParticipantVerificationDetails</code> lists all the
   * evidence verification details for the given participant ID and evidence
   * type.
   *
   * @param key
   * contains participant ID and evidence type to identity the records
   *
   * @return list of evidence verification details
   *
   * @see ListEvidenceVerificationDetails
   */
  @Override
  public EvidenceVerificationDetailsList
    listParticipantEvidenceVerificationDetails(
      final ParticipantIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // Evidence Descriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorKeyList evidenceDescriptorKeyList =
      new EvidenceDescriptorKeyList();
    final ParticipantIDEvidenceTypeStatusesKey participantIDEvidenceTypeStatusesKey =
      new ParticipantIDEvidenceTypeStatusesKey();

    participantIDEvidenceTypeStatusesKey.participantID = key.participantID;
    participantIDEvidenceTypeStatusesKey.evidenceType = key.evidenceType;
    participantIDEvidenceTypeStatusesKey.statusCode1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    participantIDEvidenceTypeStatusesKey.statusCode2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;

    evidenceDescriptorKeyList =
      evidenceDescriptor.searchActiveInEditByParticipantIDAndType(
        participantIDEvidenceTypeStatusesKey);

    final EvidenceVerificationListDetails tempDetailsList =
      getEvidenceVerificationDetails(evidenceDescriptorKeyList);
    final EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      new EvidenceVerificationDetailsList();

    for (int i = 0; i < tempDetailsList.verificationDtls.size(); i++) {
      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
        new EvidenceDescriptorIDRelatedIDAndEvidenceType();

      final curam.core.sl.infrastructure.struct.EvidenceVerificationDetails evidenceVerificationDetails =
        new curam.core.sl.infrastructure.struct.EvidenceVerificationDetails();

      // read evidence type based on evidence descriptorID
      // EvidenceDescriptor variables

      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
        tempDetailsList.verificationDtls.item(i).evidenceDescriptorID;
      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
        key.evidenceType;
      evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
        tempDetailsList.verificationDtls.item(i).relatedID;

      boolean isNonCaseEDForParticipantEvidence;

      isNonCaseEDForParticipantEvidence =
        evidenceControllerObj.isNonCaseEDForParticipantEvidence(
          evidenceDescriptorIDRelatedIDAndEvidenceType);

      // BEGIN, CR00079093,AL
      // If participant evidence and not associated with a case
      if (isNonCaseEDForParticipantEvidence) {
        evidenceVerificationDetails.verificationLinkedID =
          tempDetailsList.verificationDtls.item(i).verificationLinkedID;
        evidenceVerificationDetails.verificationLinkedType =
          VERIFICATIONTYPE.NONCASEDATA;

        evidenceVerificationDetails.dataItemName =
          tempDetailsList.verificationDtls.item(i).dataItemName;
        evidenceVerificationDetails.evidenceDescriptorID =
          tempDetailsList.verificationDtls.item(i).evidenceDescriptorID;
        evidenceVerificationDetails.relatedID =
          tempDetailsList.verificationDtls.item(i).relatedID;
        evidenceVerificationDetails.summary =
          tempDetailsList.verificationDtls.item(i).summary;
        evidenceVerificationDetails.vdIEDLinkID =
          tempDetailsList.verificationDtls.item(i).vdIEDLinkID;
        evidenceVerificationDetails.verificationStatus =
          tempDetailsList.verificationDtls.item(i).verificationStatus;

        evidenceVerificationDetailsList.verificationDtls
          .add(evidenceVerificationDetails);
      }
      // END, CR00079093,AL

    }

    return evidenceVerificationDetailsList;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  // ___________________________________________________________________________
  /**
   * This method returns a Participant list of outstanding verification details.
   *
   * @param key
   * The participant ID
   * @return The List Of Outstanding Participant verification
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listPOutstandingVerificationDetails(final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;
    caseEvidenceVerificationDetailsList.assign(
      listAllParticipantVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  // ___________________________________________________________________________
  /**
   * This method returns a list of all the verifications for a participant.
   *
   * @param key
   * The participant's ID
   * @return The List of Participant verification
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listParticipantVerificationDetails(final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.DEFAULTCODE;
    caseEvidenceVerificationDetailsList.assign(
      listAllParticipantVerificationDetails(key, outstandingIndicator));

    return caseEvidenceVerificationDetailsList;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  // ___________________________________________________________________________
  /**
   * Lists All Participant Type verification record. This method should never be
   * used to read verifications for a case.
   *
   * @param key
   * identifies the participant
   * @param indicator
   * indicates outstanding verifications
   * @return The List of all participant verifications
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listAllParticipantVerificationDetails(final ParticipantKeyStruct key,
      final OutstandingIndicator indicator)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    // EvidenceDescriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // VDIEDLink variables
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();
    final VDIEDLink vDIEDLink = VDIEDLinkFactory.newInstance();

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();

    CaseEvidenceVerificationDetails caseEvidenceVerificationDetails;

    final UsersKey userKey = new UsersKey();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    ReadRelatedIDParticipantIDAndEvidenceTypeDetails readRelatedIDParticipantIDAndEvidenceTypeDetails =
      new ReadRelatedIDParticipantIDAndEvidenceTypeDetails();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // Populate the user name
    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00301053, ZV
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey =
      new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.participantID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    final DataBasedSecurityResult dataBasedSecurityResult =
      dataBasedSecurity.checkParticipantSecurity(participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    VerificationAndVDIEDLinkDetailsList verificationAndVDIEDLinkDetailsList;
    final ReadVerificationStatusLinkedIDandTypeKey readVerificationStatusLinkedIDandTypeKey =
      new ReadVerificationStatusLinkedIDandTypeKey();

    final ReadByVerLinkedIDTypeAndStatusKey readByVerLinkedIDTypeAndStatusKey =
      new ReadByVerLinkedIDTypeAndStatusKey();

    readByVerLinkedIDTypeAndStatusKey.verificationLinkedID =
      key.participantID;
    readByVerLinkedIDTypeAndStatusKey.evidenceDescriptorStatus1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    readByVerLinkedIDTypeAndStatusKey.evidenceDescriptorStatus2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;
    readByVerLinkedIDTypeAndStatusKey.verificationLinkedType =
      VERIFICATIONTYPE.NONCASEDATA;

    readVerificationStatusLinkedIDandTypeKey.verificationLinkedID =
      key.participantID;
    readVerificationStatusLinkedIDandTypeKey.verificationStatus =
      indicator.verificationStatus;
    readVerificationStatusLinkedIDandTypeKey.evidenceDescriptorStatus1 =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    // BEGIN, CR00085770, MR
    readVerificationStatusLinkedIDandTypeKey.evidenceDescriptorStatus2 =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;
    // END, CR00085770

    readVerificationStatusLinkedIDandTypeKey.verificationLinkedType =
      VERIFICATIONTYPE.NONCASEDATA;

    if (indicator.verificationStatus.equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
      verificationAndVDIEDLinkDetailsList =
        verification.searchOutstandingVerAndVDIEDLinkDetailsByLinkedIDandType(
          readVerificationStatusLinkedIDandTypeKey);
    } else {
      verificationAndVDIEDLinkDetailsList =
        verification.searchVerAndVDIEDLinkDtlsByVerLinkedIDAndType(
          readByVerLinkedIDTypeAndStatusKey);
    }

    for (int i = 0; i < verificationAndVDIEDLinkDetailsList.dtls
      .size(); i++) {
      evidenceDescriptorKey.evidenceDescriptorID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).evidenceDescriptorID;

      readRelatedIDParticipantIDAndEvidenceTypeDetails = evidenceDescriptor
        .readRelatedIDParticipantIDAndEvidenceType(evidenceDescriptorKey);

      caseEvidenceVerificationDetails = new CaseEvidenceVerificationDetails();

      // assign the associated verification details to the struct
      // Create Evidence Interface For Evidence Type
      final EvidenceMap map = EvidenceController.getEvidenceMap();
      // BEGIN, CR00059540, POH
      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(
          readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType);

      // Retrieve evidence details for list display
      eiEvidenceKey.evidenceID =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
      eiEvidenceKey.evidenceType =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;
      // BEGIN, CR00452978, GK
      final String addProofWizard = (String) TransactionInfo
        .getFacadeScopeObject(VerificationConst.kIsAddProofWizard);

      if (null != addProofWizard && CuramConst.gkYes.equals(addProofWizard)) {
        caseEvidenceVerificationDetails.evidence = CuramConst.gkEmpty;
      } else {
        final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
          standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

        // BEGIN, CR00244064, CD
        // Summary may now be marked up as client formatted text.
        // Ensure that this assignment keeps to it's original contract.
        eiFieldsForListDisplayDtls.summary = LocalizableXMLStringHelper
          .toPlainText(eiFieldsForListDisplayDtls.summary);
        // BEGIN, CR00368690, JMA
        caseEvidenceVerificationDetails.evidence =
          eiFieldsForListDisplayDtls.summary;
      }
      // END, CR00452978
      caseEvidenceVerificationDetails.evidenceTypeOpt =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;

      // END, CR00252005

      // END, CR00368690

      // Read Verifiable Data Item Name
      vDIEDLinkKey.VDIEDLinkID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).VDIEDLinkID;

      final VerifiableDataItemName verifiableDataItemName =
        vDIEDLink.readVerifiableDataItemName(vDIEDLinkKey);

      ctitemKey.code = verifiableDataItemName.name;
      caseEvidenceVerificationDetails.verifiableDataItemIDOpt =
        verificationAndVDIEDLinkDetailsList.dtls
          .item(i).verifiableDataItemIDOpt;
      // END, CR00452978
      ctitemKey.locale = TransactionInfo.getProgramLocale();
      ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
      // BEGIN, CR00163098, JC
      ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
      // END, CR00163098, JC
      caseEvidenceVerificationDetails.verifiableDataItemName =
        ctitem.description;
      caseEvidenceVerificationDetails.vDIEDLinkID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).VDIEDLinkID;
      caseEvidenceVerificationDetails.evidenceDescriptorID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).evidenceDescriptorID;

      caseEvidenceVerificationDetails.mandatory =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).mandatory;
      // BEGIN, CR00452774, GK
      caseEvidenceVerificationDetails.verifiableDataItemIDOpt =
        verificationAndVDIEDLinkDetailsList.dtls
          .item(i).verifiableDataItemIDOpt;
      // END, CR00452774

      // System reads Participant Name
      if (readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID != 0) {

        // ConcernRole manipulation variables
        final CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey =
          new CaseIDAndParticipantRoleIDKey();

        final CaseParticipantRole caseParticipantRole =
          CaseParticipantRoleFactory.newInstance();

        // caseIDAndParticipantRoleIDKey.caseID = key.caseID;
        caseIDAndParticipantRoleIDKey.participantRoleID =
          readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID;

        caseEvidenceVerificationDetails.caseParticpantRoleID =
          caseParticipantRole
            .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(
              caseIDAndParticipantRoleIDKey).caseParticipantRoleID;

        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID =
          readRelatedIDParticipantIDAndEvidenceTypeDetails.participantID;

        concernRoleNameDetails =
          concernRoleObj.readConcernRoleName(concernRoleKey);

        // Retrieve participant's name
        caseEvidenceVerificationDetails.primaryClient =
          concernRoleNameDetails.concernRoleName;
      }

      // since status has been updated fetch it again
      final VerificationKey verificationKey = new VerificationKey();

      verificationKey.verificationID =
        verificationAndVDIEDLinkDetailsList.dtls.item(i).verificationID;
      caseEvidenceVerificationDetails.verificationStatus = verification
        .readVerificationStatus(verificationKey).verificationStatus;

      if (caseEvidenceVerificationDetails.verificationStatus
        .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
        caseEvidenceVerificationDetails.dueDate =
          verificationAndVDIEDLinkDetailsList.dtls.item(i).dueDate;
        // BEGIN, CR00439301, AKr
        final CountDetails itemsProvidedCount =
          countItemsProvided(vDIEDLinkKey);

        if (0 < itemsProvidedCount.numberOfRecords) {
          caseEvidenceVerificationDetails.itemProvided = true;
        } else {
          caseEvidenceVerificationDetails.itemProvided = false;
        }
        // END, CR00439301
      }

      // BEGIN, CR00075875, JPG
      // Do not display cancelled records
      if (!caseEvidenceVerificationDetails.verificationStatus
        .equals(VERIFICATIONSTATUS.CANCELLED)) {
        caseEvidenceVerificationDetailsList.dtls
          .addRef(caseEvidenceVerificationDetails);
      }
      // END, CR00075875
    }
    return caseEvidenceVerificationDetailsList;

  }

  // END, CR00075582

  // BEGIN, CR00075875, JPG
  // ___________________________________________________________________________
  /**
   * Method to get the verification status when passed in a VDIEDLink.
   *
   * @param key
   * identifies the VDIEDLink record
   *
   * @return The verification status
   */
  @Override
  public VerificationStatusDetails getVerificationStatus(
    final VDIEDLinkKey key) throws AppException, InformationalException {

    // BEGIN, CR00439301, AKr
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

    vDIEDLinkKey.VDIEDLinkID = key.VDIEDLinkID;
    determineVerificationStatus(vDIEDLinkKey);
    final VerificationStatusDetails verificationStatusDetails =
      new VerificationStatusDetails();

    verificationStatusDetails.verificationStatus =
      VerificationFactory.newInstance().readByVDIEDLinkID(vDIEDLinkKey).dtls
        .item(0).verificationStatus;
    return verificationStatusDetails;
    // END, CR00439301
  }

  // END, CR00075875

  // BEGIN, CR00080087, POH
  // ___________________________________________________________________________
  /**
   * Determines the verification status for a verification relating to
   * participant evidence when either the verification is being viewed, or a
   * verification item provided record is being removed from the verification.
   *
   * @param key
   * identifies the VDIEDLink record
   */
  @Override
  public void determineVerificationStatusForRemoveAndView(
    final VDIEDLinkKey key) throws AppException, InformationalException {

    // verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.entity.fact.VerificationFactory
        .newInstance();

    // VDIEDLink variables
    final VDIEDLinkIDDtlsList vDIEDLinkIDDtlsList = new VDIEDLinkIDDtlsList();
    final VDIEDLinkIDDtls vDIEDLinkIDDtls = new VDIEDLinkIDDtls();

    // populate key with VDIEDLinkID passed in as the key for the method.
    vDIEDLinkIDDtls.VDIEDLinkID = key.VDIEDLinkID;
    vDIEDLinkIDDtlsList.dtls.addRef(vDIEDLinkIDDtls);

    // BEGIN, CR00451715, MR
    final VerificationDtlsList verificationDtlsList =
      verificationObj.searchActiveVerificationByVDIEDLinkID(key);

    // determine the status of the verifications
    determineStatus(verificationDtlsList, vDIEDLinkIDDtlsList);
    // END, CR00451715

  }

  // END, CR00080087

  // BEGIN, CR00109704, MR
  // ___________________________________________________________________________
  /**
   * This method is used to read the evidence verification details.
   *
   * @param key
   * evidence descriptor key
   * @return evidence verification details
   */
  @Override
  public EvidenceVerificationDetails
    readEvidenceVerificationDetails(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Evidence Descriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    EvidenceVerificationDetails evidenceVerificationDetails =
      new EvidenceVerificationDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    // EIEvidenceKey object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
    final EvidenceMap map = EvidenceController.getEvidenceMap();

    // VDIEDLink variables
    final VDIEDLinkKey vdIEDLinkKey = new VDIEDLinkKey();
    final VDIEDLink vdIEDLink = VDIEDLinkFactory.newInstance();
    VDIEDLinkIDAndDataItemIDDetailsList vdIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    // Verification variables
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    VerificationIDAndStatusDetailsList verificationIDAndStatusDetailsList =
      new VerificationIDAndStatusDetailsList();
    boolean verified = false;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;
    vdIEDLinkIDAndDataItemIDDetailsList =
      vdIEDLink.readByEvidenceDescriptorID(evidenceDescriptorKey);

    // assign summary
    final EvidenceDescriptorDtls evidenceDescriptDtls =
      evidenceDescriptor.read(evidenceDescriptorKey);

    final StandardEvidenceInterface standardEvidenceInterface =
      map.getEvidenceType(evidenceDescriptDtls.evidenceType);

    eiEvidenceKey.evidenceType = evidenceDescriptDtls.evidenceType;
    // Retrieve evidence details for list display
    eiEvidenceKey.evidenceID = evidenceDescriptDtls.relatedID;

    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
      standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

    // BEGIN, CR00244064, CD
    // Summary may now be marked up as client formatted text.
    // Ensure that this assignment keeps to it's original contract.
    eiFieldsForListDisplayDtls.summary = LocalizableXMLStringHelper
      .toPlainText(eiFieldsForListDisplayDtls.summary);
    // END, CR00244064

    // read case type to set the verificationLinkedType
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = evidenceDescriptDtls.caseID;

    CaseTypeCode caseTypeCode = null;

    // If we have a caseID read the case type code.
    if (evidenceDescriptDtls.caseID != 0) {
      // Read CaseHeader
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
    }

    // iterate through the VDIEDLink IDs
    for (int j = 0; j < vdIEDLinkIDAndDataItemIDDetailsList.dtls
      .size(); j++) {

      vdIEDLinkKey.VDIEDLinkID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;

      // determine the verification status
      determineVerificationStatusForRemoveAndView(vdIEDLinkKey);

      verificationIDAndStatusDetailsList =
        verification.readEvidenceVerificationDetails(vdIEDLinkKey);
      evidenceVerificationDetails = new EvidenceVerificationDetails();

      // BEGIN, CR00244113, CSH
      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(eiFieldsForListDisplayDtls.summary);

      evidenceVerificationDetails.summary = summary.toClientFormattedText();
      // END, CR00244113

      // determine the verification status for the data item
      if (verificationIDAndStatusDetailsList.dtls.size() == 0) {
        verified = false;
      } else {
        verified = true;
        for (int k = 0; k < verificationIDAndStatusDetailsList.dtls
          .size(); k++) {
          // With the verification of participant evidence a verification can
          // be cancelled We need to filter this from the list returned as
          // cancelled records do not have an affect on verification status
          if (verificationIDAndStatusDetailsList.dtls
            .item(k).verificationStatus
              .equals(VERIFICATIONSTATUS.CANCELLED)) {
            continue;
          }
          verified = verified && verificationIDAndStatusDetailsList.dtls
            .item(k).verificationStatus.equals(VERIFICATIONSTATUS.VERIFIED);
        }
      }

      evidenceVerificationDetails.relatedID = evidenceDescriptDtls.relatedID;

      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
        new EvidenceDescriptorIDRelatedIDAndEvidenceType();

      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
        evidenceDescriptDtls.evidenceDescriptorID;
      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
        evidenceDescriptDtls.evidenceType;
      evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
        evidenceDescriptDtls.relatedID;

      boolean isNonCaseEDForParticipantEvidence;

      isNonCaseEDForParticipantEvidence =
        evidenceControllerObj.isNonCaseEDForParticipantEvidence(
          evidenceDescriptorIDRelatedIDAndEvidenceType);

      // If participant evidence and not associated with a case
      if (isNonCaseEDForParticipantEvidence) {
        evidenceVerificationDetails.verificationLinkedID =
          evidenceDescriptDtls.participantID;
        evidenceVerificationDetails.verificationLinkedType =
          VERIFICATIONTYPE.NONCASEDATA;

        // Has to be case level verification
      } else if (evidenceDescriptDtls.caseID != 0) {

        evidenceVerificationDetails.verificationLinkedID =
          evidenceDescriptDtls.caseID;

        // BEGIN, CR00350929, ARM

        // BEGIN, CR00371307, AKr
        evidenceVerificationDetails.verificationLinkedType =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00371307
        // END, CR00350929
      }

      evidenceVerificationDetails.vdIEDLinkID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;

      if (verified) {
        evidenceVerificationDetails.verificationStatus =
          VERIFICATIONSTATUS.VERIFIED;
      } else {
        evidenceVerificationDetails.verificationStatus =
          VERIFICATIONSTATUS.NOTVERIFIED;
      }

      // assign dataItemName
      final VerifiableDataItemKey verifiableDataItemKey =
        new VerifiableDataItemKey();

      verifiableDataItemKey.verifiableDataItemID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).verifiableDataItemID;
      final VerifiableDataItem verifiableDataItem =
        curam.verification.sl.entity.fact.VerifiableDataItemFactory
          .newInstance();

      evidenceVerificationDetails.dataItemName =
        verifiableDataItem.readNameByID(verifiableDataItemKey).name;

      evidenceVerificationDetails.evidenceDescriptorID =
        key.evidenceDescriptorID;

    }
    return evidenceVerificationDetails;
  }

  // END, CR00109704

  // BEGIN, CR00222660, PF
  /**
   * Returns a list of the verifications for all evidence recorded for a case.
   *
   * @param key
   * The case ID
   *
   * @return The list of verifications
   */
  @Override
  public EvidenceVerificationListDetails
    listEvidenceVerificationDetailsForCase(final CaseKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00375902, ELG
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    // BEGIN, CR00230074, ELG
    final EvdInstanceObjDtlsList evdInstanceObjDtlsList =
      evidenceDescriptorObj.searchAllActiveAndModifiedInstances(key);

    final EvidenceDescriptorKeyList evidenceDescriptorKeyList =
      new EvidenceDescriptorKeyList();

    for (final EvdInstanceObjDtls evdInstanceObjDtls : evdInstanceObjDtlsList.dtls) {

      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evdInstanceObjDtls.evidenceDescriptorID;

      evidenceDescriptorKeyList.dtls.add(evidenceDescriptorKey);

    }
    // END, CR00230074
    // END, CR00375902

    return getEvidenceVerificationDetails(evidenceDescriptorKeyList);
  }

  // END, CR00222660

  // BEGIN, CR00386928, SSK
  /**
   * Retrieves all the details of the evidence verifications
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptors
   *
   * @return The list of evidence verifications details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  public EvidenceVerificationListDetails retrieveEvidenceVerificationDetails(
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList)
    throws AppException, InformationalException {

    final EvidenceVerificationListDetails evidenceVerificationDetailsList =
      new EvidenceVerificationListDetails();
    EvidenceVerificationDetails evidenceVerificationDetails =
      new EvidenceVerificationDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
    final EvidenceMap map = EvidenceController.getEvidenceMap();

    final VDIEDLink vdIEDLink = VDIEDLinkFactory.newInstance();
    VDIEDLinkIDAndDataItemIDDetailsList vdIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    VerificationKeyList verificationKeyList;
    boolean verified = false;

    // BEGIN, CR00386928, RPB
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final VerifiableDataItem verifiableDataItem =
      curam.verification.sl.entity.fact.VerifiableDataItemFactory
        .newInstance();
    // END, CR00386928

    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls;

    for (final EvidenceDescriptorDtls evidenceDescriptDtls : evidenceDescriptorDtlsList.dtls) {

      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceDescriptDtls.evidenceDescriptorID;
      vdIEDLinkIDAndDataItemIDDetailsList =
        vdIEDLink.readByEvidenceDescriptorID(evidenceDescriptorKey);
      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(evidenceDescriptDtls.evidenceType);

      eiEvidenceKey.evidenceType = evidenceDescriptDtls.evidenceType;
      // Retrieve evidence details for list display
      eiEvidenceKey.evidenceID = evidenceDescriptDtls.relatedID;

      eiFieldsForListDisplayDtls =
        standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

      // Summary may now be marked up as client formatted text.
      // Ensure that this assignment keeps to it's original contract.
      eiFieldsForListDisplayDtls.summary = LocalizableXMLStringHelper
        .toPlainText(eiFieldsForListDisplayDtls.summary);
      // read case type to set the verificationLinkedType
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = evidenceDescriptDtls.caseID;

      CaseTypeCode caseTypeCode = null;
      String verificationLinkedType = null;

      // If we have a caseID read the case type code.
      if (evidenceDescriptDtls.caseID != 0) {
        // Read CaseHeader
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);
        verificationLinkedType =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
      }

      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
      final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
        new EvidenceDescriptorIDRelatedIDAndEvidenceType();

      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
        evidenceDescriptDtls.evidenceDescriptorID;
      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
        evidenceDescriptDtls.evidenceType;
      evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
        evidenceDescriptDtls.relatedID;
      boolean isNonCaseEDForParticipantEvidence;

      isNonCaseEDForParticipantEvidence =
        evidenceControllerObj.isNonCaseEDForParticipantEvidence(
          evidenceDescriptorIDRelatedIDAndEvidenceType);
      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType = evidenceDescriptDtls.evidenceType;
      final boolean isPDCEvidence =
        evidenceControllerObj.isPDCEvidence(evidenceTypeKey);

      for (int j = 0; j < vdIEDLinkIDAndDataItemIDDetailsList.dtls
        .size(); j++) {

        // BEGIN, CR00417399, AKr
        final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

        vDIEDLinkKey.VDIEDLinkID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
        if (verification.readByVDIEDLinkID(vDIEDLinkKey).dtls.size() > 0) {
          // END, CR00417399

          final VDIEDLinkAndStatusKey vDIEDLinkAndStatus =
            new VDIEDLinkAndStatusKey();

          vDIEDLinkAndStatus.VDIEDLinkID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
          vDIEDLinkAndStatus.verificationStatus = VERIFICATIONSTATUS.VERIFIED;
          verificationKeyList =
            verification.searchByVDIEDLinkIDStatus(vDIEDLinkAndStatus);

          evidenceVerificationDetails = new EvidenceVerificationDetails();

          evidenceVerificationDetails.summary =
            eiFieldsForListDisplayDtls.summary;

          // determine the verification status for the data item
          if (verificationKeyList.dtls.size() == 0) {
            verified = false;
          } else if (verificationKeyList.dtls.size() > 0) {
            verified = true;
          }
          evidenceVerificationDetails.relatedID =
            evidenceDescriptDtls.relatedID;
          evidenceTypeKey.evidenceType = evidenceDescriptDtls.evidenceType;
          // If participant evidence and not associated with a case
          if (isNonCaseEDForParticipantEvidence || isPDCEvidence) {
            evidenceVerificationDetails.verificationLinkedID =
              evidenceDescriptDtls.participantID;
            evidenceVerificationDetails.verificationLinkedType =
              VERIFICATIONTYPE.NONCASEDATA;

            // Has to be case level verification
          } else if (evidenceDescriptDtls.caseID != 0) {

            evidenceVerificationDetails.verificationLinkedID =
              evidenceDescriptDtls.caseID;
            evidenceVerificationDetails.verificationLinkedType =
              verificationLinkedType;
          }

          evidenceVerificationDetails.vdIEDLinkID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;

          if (verified) {
            evidenceVerificationDetails.verificationStatus =
              VERIFICATIONSTATUS.VERIFIED;
          } else {
            evidenceVerificationDetails.verificationStatus =
              VERIFICATIONSTATUS.NOTVERIFIED;
          }

          final VerifiableDataItemKey verifiableDataItemKey =
            new VerifiableDataItemKey();

          verifiableDataItemKey.verifiableDataItemID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls
              .item(j).verifiableDataItemID;
          evidenceVerificationDetails.dataItemName =
            verifiableDataItem.readNameByID(verifiableDataItemKey).name;
          evidenceVerificationDetails.evidenceDescriptorID =
            evidenceDescriptDtls.evidenceDescriptorID;

          evidenceVerificationDetailsList.verificationDtls
            .addRef(evidenceVerificationDetails);

        }
      }
    }
    return evidenceVerificationDetailsList;
  }

  /**
   * Filters the evidence descriptor list to display the appropriate associated
   * verifications
   *
   * @param evidenceDescriptorDtlsList
   * Contains a list of evidence descriptor in In-Edit, Active and
   * Superseded.
   *
   * @return The list Active and In-Edit evidence descriptor along with its
   * associated superseded evidence descriptor.
   */
  protected EvidenceDescriptorDtlsList
    filterEvidenceDesriptorToDisplayVerifications(
      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList) {

    final EvidenceDescriptorDtlsList filteredEvidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();
    EvidenceDescriptorDtlsList correctionEvidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();
    final Map<String, EvidenceDescriptorDtlsList> correctionRelatedEvidences =
      new HashMap<String, EvidenceDescriptorDtlsList>();

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls) {

      if (correctionRelatedEvidences
        .containsKey(evidenceDescriptorDtls.correctionSetID)) {
        correctionEvidenceDescriptorDtlsList = correctionRelatedEvidences
          .get(evidenceDescriptorDtls.correctionSetID);
        correctionEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);

      } else {
        correctionEvidenceDescriptorDtlsList =
          new EvidenceDescriptorDtlsList();
        correctionEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);
        correctionRelatedEvidences.put(evidenceDescriptorDtls.correctionSetID,
          correctionEvidenceDescriptorDtlsList);
      }

    }

    for (final EvidenceDescriptorDtlsList correctedEvidenceDescriptorDtlsList : correctionRelatedEvidences
      .values()) {
      boolean isValidVerificationEvidence = false;

      for (final EvidenceDescriptorDtls evidenceDescriptorDtls : correctedEvidenceDescriptorDtlsList.dtls) {

        if (EVIDENCEDESCRIPTORSTATUS.ACTIVE
          .equals(evidenceDescriptorDtls.statusCode)
          || EVIDENCEDESCRIPTORSTATUS.INEDIT
            .equals(evidenceDescriptorDtls.statusCode)) {
          isValidVerificationEvidence = true;
          break;
        }

      }
      if (isValidVerificationEvidence) {
        filteredEvidenceDescriptorDtlsList.dtls
          .addAll(correctedEvidenceDescriptorDtlsList.dtls);
      }

    }

    return filteredEvidenceDescriptorDtlsList;
  }

  /**
   * Filters verifications for evidence in In-Edit, Active and Superseded state.
   * Filters the Superseded evidence by checking if corresponding In-Edit and
   * Active evidence exists.
   *
   * @param fullVerificationEvidenceDetailsList
   * Contains the list of evidence descriptor.
   *
   * @return The list of verification details for Active and In-Edit evidence
   * descriptor along with its associated superseded evidence
   * descriptor.
   */
  protected VerificationAndVDIEDLinkDetailsList
    filterVerificationEvidenceDetails(
      final VerificationEvidenceDetailsList fullVerificationEvidenceDetailsList) {

    final VerificationAndVDIEDLinkDetailsList verificationAndVDIEDLinkDetailsList =
      new VerificationAndVDIEDLinkDetailsList();
    final Map<String, VerificationEvidenceDetailsList> setOfVerificationEvidenceDetails =
      new HashMap<String, VerificationEvidenceDetailsList>();
    VerificationEvidenceDetailsList corretionIDRelatedVerificationEvidenceDetailsList;
    VerificationEvidenceDetailsList newVerificationEvidenceDetailsList;

    for (final VerificationEvidenceDetails verificationEvidenceDetails : fullVerificationEvidenceDetailsList.dtls) {

      if (setOfVerificationEvidenceDetails
        .containsKey(verificationEvidenceDetails.correctionSetID)) {
        corretionIDRelatedVerificationEvidenceDetailsList =
          setOfVerificationEvidenceDetails
            .get(verificationEvidenceDetails.correctionSetID);
        corretionIDRelatedVerificationEvidenceDetailsList.dtls
          .add(verificationEvidenceDetails);

      } else {
        newVerificationEvidenceDetailsList =
          new VerificationEvidenceDetailsList();
        newVerificationEvidenceDetailsList.dtls
          .add(verificationEvidenceDetails);
        setOfVerificationEvidenceDetails.put(
          verificationEvidenceDetails.correctionSetID,
          newVerificationEvidenceDetailsList);
      }
    }

    VerificationAndVDIEDLinkDetails verificationAndVDIEDLinkDetails;

    for (final VerificationEvidenceDetailsList verificationEvidenceDetailsList : setOfVerificationEvidenceDetails
      .values()) {
      boolean isValidVerificationEvidence = false;

      for (final VerificationEvidenceDetails verificationEvidenceDetails : verificationEvidenceDetailsList.dtls) {

        if (EVIDENCEDESCRIPTORSTATUS.ACTIVE
          .equals(verificationEvidenceDetails.evidenceStatus)
          || EVIDENCEDESCRIPTORSTATUS.INEDIT
            .equals(verificationEvidenceDetails.evidenceStatus)) {
          isValidVerificationEvidence = true;
          break;
        }

      }
      if (isValidVerificationEvidence) {
        for (final VerificationEvidenceDetails verificationEvidenceDetails : verificationEvidenceDetailsList.dtls) {
          verificationAndVDIEDLinkDetails =
            new VerificationAndVDIEDLinkDetails();
          verificationAndVDIEDLinkDetails.evidenceDescriptorID =
            verificationEvidenceDetails.evidenceDescriptorID;
          verificationAndVDIEDLinkDetails.dueDate =
            verificationEvidenceDetails.dueDate;
          verificationAndVDIEDLinkDetails.mandatory =
            verificationEvidenceDetails.mandatory;
          verificationAndVDIEDLinkDetails.VDIEDLinkID =
            verificationEvidenceDetails.VDIEDLinkID;
          verificationAndVDIEDLinkDetails.verificationID =
            verificationEvidenceDetails.verificationID;
          verificationAndVDIEDLinkDetails.verificationStatus =
            verificationEvidenceDetails.verificationStatus;

          verificationAndVDIEDLinkDetailsList.dtls
            .add(verificationAndVDIEDLinkDetails);
        }
      }

    }
    return verificationAndVDIEDLinkDetailsList;

  }

  // END, CR00386928

  // BEGIN, CR00439301, AKr
  /**
   * Returns a count of active verification items provided for a verifiable data
   * item for an evidence record.
   *
   * @param vDIEDLinkKey
   * The unique identifier of verifiable data item and
   * evidenceDesrcriptor record.
   *
   * @return The count of verification items provided
   */
  @Override
  public CountDetails countItemsProvided(final VDIEDLinkKey vDIEDLinkKey)
    throws AppException, InformationalException {

    final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
      new VDIEDLinkIDAndStatusKey();

    vDIEDLinkIDAndStatusKey.VDIEDLinkID = vDIEDLinkKey.VDIEDLinkID;
    final CountDetails itemsProvidedCount =
      VerificationItemProvidedFactory.newInstance()
        .countActiveItemProvidedByVDIEDLinkID(vDIEDLinkIDAndStatusKey);

    return itemsProvidedCount;
  }

  // END, CR00439301

  // BEGIN, CR00443445, DG
  /**
   * Returns a count of Verification and EvidenceType for a CaseID,
   * VerificationStatus, EvidenceStatus
   *
   * @param CaseIDVerificationStatusKey
   * CaseID, EvidenceStatus and VerificationStatus. Two or three
   * evidence status codes can be passed. The third status field is
   * optional.
   *
   * @return The count of Verification and EvidenceType
   */
  @Override
  public VerificationCountAndEvidenceTypeDetailsList
    listVerificationCountAndEvidenceTypeForCase(
      final CaseIDVerificationStatusKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    curam.verification.sl.infrastructure.entity.struct.VerificationCountAndEvidenceTypeDetailsList resultList;

    // If the third status is not set, then call the standard search method.
    // Otherwise call the extended search.
    if (key.statusCode3.isEmpty()) {
      resultList =
        verification.searchVerificationCountAndEvidenceTypeForCase(key);
    } else {
      resultList = verification
        .searchVerificationCountAndEvidenceTypeForCaseExtended(key);
    }

    final VerificationCountAndEvidenceTypeDetailsList returnList =
      new VerificationCountAndEvidenceTypeDetailsList();

    for (final VerificationCountAndEvidenceTypeDetails dtls : resultList.dtls) {
      returnList.dtls.add(dtls);
    }

    return returnList;
  }

  // END, CR00443445

  // BEGIN, CR00452604, GK
  /**
   * This method reads the verification details without determining the
   * verification status.
   *
   * This method is a new version of readVerificationDetails method, therefore
   * if there is any change in this method then the developer is suggested to
   * visit readVerificationDetails as well.
   *
   * @param dtls
   * details about the evidence and VDIEDLinkID
   *
   * @return The verification details
   */
  @Override
  public ViewVerificationDetails
    readVerificationDetails1(final EvidenceVerificationDetails dtls)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // This method is a new version of readVerificationDetails method, therefore
    // if there is any change in this method
    // then the developer is suggested to visit readVerificationDetails as well.
    // END, CR00452604.
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();
    final ViewVerificationDetails viewVerificationDetails =
      new ViewVerificationDetails();

    // verifiable data item variables
    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItem =
      curam.verification.sl.entity.fact.VerifiableDataItemFactory
        .newInstance();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    VerifiableDataItemSecurityDetails verifiableDataItemsecurityDetails =
      new VerifiableDataItemSecurityDetails();
    SecurityResult securityResult = new SecurityResult();

    final curam.verification.sl.infrastructure.intf.VerificationItemProvided verificationItemProvidedObj =
      curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
        .newInstance();
    VerificationItemProvidedExpiryDateDetails itemProvidedExpiryDateDetails =
      new VerificationItemProvidedExpiryDateDetails();
    final VerificationItemProvidedExpiryDateDetailsList itemProvidedExpiryDateDetailsList =
      new VerificationItemProvidedExpiryDateDetailsList();
    final UsersKey userKey = new UsersKey();

    // populate the user name
    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // VerificationRequirement variables
    final VerificationRequirement verificationRequirement =
      VerificationRequirementFactory.newInstance();

    VerificationRequirementSummaryDetails verificationSummaryDetails;

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();
    final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

    vdiedLinkKey.VDIEDLinkID = dtls.vdIEDLinkID;

    final VerificationDtlsList verificationDtlsList =
      verification.readByVDIEDLinkID(vdiedLinkKey);

    // Case header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseKey caseKey = new CaseKey();
    VerificationDetails verificationDetails;
    VerificationDtls verificationDtls;

    final VerificationRequirementKey verificationRequirementKey =
      new VerificationRequirementKey();

    CaseReferenceAndTypeDetails caseReferenceAndTypeDetails =
      new CaseReferenceAndTypeDetails();

    final EvidenceAndDataItemNameDetails evidenceAndDataItemNameDetails =
      new EvidenceAndDataItemNameDetails();

    // Evidence Description details variables
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorDtls evidenceDescriptorDtls;
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    // comment variable
    final CommentsDetails commentsDetails = new CommentsDetails();

    // security variables
    final DataBasedSecurity dataBasedSecurity =
      SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey =
      new CaseSecurityCheckKey();

    // to get the Item Provided list details
    VerificationItemProvidedListDetailsList verificationItemProvidedListDetailsList =
      new VerificationItemProvidedListDetailsList();

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();
    final VerificationItemProvidedKey verificationItemProvidedKey =
      new VerificationItemProvidedKey();
    final StatusAndVDIEDLinkIDDetails statusAndVDIEDLinkIDDetails =
      new StatusAndVDIEDLinkIDDetails();
    // To get Concern role name and with participant ID
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();
    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // Product Delivery variable to get Product Name
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    // Product Name Struct
    ProductNameStructRef productNameStructRef = new ProductNameStructRef();

    // check for participant sensitivity
    // Participant security check variables
    final curam.core.intf.ParticipantSecurityCheck participantSecurityCheckObj =
      curam.core.fact.ParticipantSecurityCheckFactory.newInstance();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();

    securityResult.result = false;

    // populate key with passed in evidenceDescriptorID
    evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;

    // read evidence descriptor details
    evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;
    evidenceDescriptorDtls =
      evidenceDescriptorObj.read(evidenceDescriptorKey);
    participantKeyStruct.participantID = evidenceDescriptorDtls.participantID;
    securityResult =
      participantSecurityCheckObj.authorize(participantKeyStruct, userKey);
    // if the result is false, it means the user does not have access to
    // this case
    if (!securityResult.result) {
      throw new AppException(
        curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
    }
    for (int i = 0; i < verificationDtlsList.dtls.size(); i++) {
      verificationDtls = verificationDtlsList.dtls.item(i);
      // assign value
      verificationRequirementKey.verificationRequirementID =
        verificationDtls.verificationRequirementID;
      verificationDetails = verificationRequirement
        .readVerificationDetails(verificationRequirementKey);
      // assign level, min items from verification details and
      // due date, verificationStatus from verificationDtls
      verificationSummaryDetails =
        new VerificationRequirementSummaryDetails();

      verificationSummaryDetails.level =
        verificationDetails.verificationLevel;
      verificationSummaryDetails.minimumItems =
        verificationDetails.minimumItems;

      // Added a filter to not process cancelled records
      if (verificationDtls.verificationStatus
        .equals(VERIFICATIONSTATUS.CANCELLED)) {
        continue;
      } else if (verificationDtls.verificationStatus
        .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
        verificationSummaryDetails.dueDate = verificationDtls.dueDate;
        verificationSummaryDetails.dueDateModifiableInd =
          verificationDetails.dueDateModifiableInd;
      } else {
        verificationSummaryDetails.dueDateModifiableInd = false;
      }
      verificationSummaryDetails.verificationStatus =
        verificationDtls.verificationStatus;
      verificationSummaryDetails.verificationID =
        verificationDtls.verificationID;
      verificationSummaryDetails.mandatory = verificationDetails.mandatory;

      // Read the caseID based on the verificationID
      // The caseID is no longer stored on the verification entity -
      // instead a verificationLinkedID & verificationLinkedType (IC, PD or
      // Participant)
      // Reading here for caseID so search for verLinkedType of PD or IC
      if (!verificationDtls.verificationLinkedType
        .equals(VERIFICATIONTYPE.NONCASEDATA)) {
        caseKey.caseID = verificationDtls.verificationLinkedID;

        caseReferenceAndTypeDetails =
          caseHeaderObj.readCaseReferenceAndTypeByCaseID(caseKey);
        caseReferenceAndTypeDetails =
          caseHeaderObj.readCaseReferenceAndTypeByCaseID(caseKey);

        verificationSummaryDetails.caseReference =
          caseReferenceAndTypeDetails.caseReference;

        CaseTypeICTypeAndStartDate caseTypeICTypeAndStartDate;

        if (caseReferenceAndTypeDetails.caseTypeCode
          .equals(CASETYPECODE.INTEGRATEDCASE)) {

          // read IC Case type
          caseHeaderKey.caseID = verificationDtls.verificationLinkedID;
          caseTypeICTypeAndStartDate =
            caseHeaderObj.readCaseTypeICTypeAndStartDate(caseHeaderKey);
          ctitemKey.code = caseTypeICTypeAndStartDate.integratedCaseType;

          ctitemKey.locale = TransactionInfo.getProgramLocale();
          ctitemKey.tableName = PRODUCTCATEGORY.TABLENAME;
          ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
          verificationSummaryDetails.caseType = ctitem.description;

        } else if (caseReferenceAndTypeDetails.caseTypeCode
          .equals(CASETYPECODE.PRODUCTDELIVERY)) {

          productDeliveryKey.caseID = verificationDtls.verificationLinkedID;
          productNameStructRef =
            productDeliveryObj.readProductName(productDeliveryKey);
          // convert code to value
          ctitemKey.code = productNameStructRef.name;
          ctitemKey.locale = TransactionInfo.getProgramLocale();
          ctitemKey.tableName = PRODUCTNAME.TABLENAME;
          ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
          verificationSummaryDetails.caseType = ctitem.description;
          caseSecurityCheckKey.caseID = verificationDtls.verificationLinkedID;
          caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;
          final DataBasedSecurityResult dataBasedSecurityResult =
            dataBasedSecurity.checkCaseSecurity1(caseSecurityCheckKey);

          if (dataBasedSecurityResult.restricted) {
            ctitemKey.code = CASETYPECODE.RESTRICTEDACCESS;
            ctitemKey.locale = TransactionInfo.getProgramLocale();
            ctitemKey.tableName = CASETYPECODE.TABLENAME;
            ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
            verificationSummaryDetails.caseType = ctitem.description;
            verificationSummaryDetails.dueDate =
              curam.util.type.Date.kZeroDate;
            verificationSummaryDetails.minimumItems = 0;
          }
        }
      }
      viewVerificationDetails.summaryDetailsList
        .addRef(verificationSummaryDetails);
    } // end of for loop

    // fetch Items received details
    statusAndVDIEDLinkIDDetails.vdIEDLinkID = dtls.vdIEDLinkID;
    statusAndVDIEDLinkIDDetails.recordStatus = RECORDSTATUS.NORMAL;
    verificationItemProvidedListDetailsList = verificationItemProvided
      .searchListDetailsByStatusAndVDIEDLinkID(statusAndVDIEDLinkIDDetails);
    for (int i = 0; i < verificationItemProvidedListDetailsList.dtls
      .size(); i++) {
      verificationItemProvidedKey.verificationItemProvidedID =
        verificationItemProvidedListDetailsList.dtls
          .item(i).verificationItemProvidedID;
      itemProvidedExpiryDateDetails =
        new VerificationItemProvidedExpiryDateDetails();
      itemProvidedExpiryDateDetails
        .assign(verificationItemProvidedListDetailsList.dtls.item(i));
      itemProvidedExpiryDateDetails.expiryDate = verificationItemProvidedObj
        .calculateExpiryDate(verificationItemProvidedKey).expiryDate;
      itemProvidedExpiryDateDetailsList.itemProvidedDetails
        .add(itemProvidedExpiryDateDetails);
    }

    vdIEDLinkDtls = vdIEDLinkObj.read(vdiedLinkKey);
    verifiableDataItemKey.verifiableDataItemID =
      vdIEDLinkDtls.verifiableDataItemID;

    commentsDetails.comments = verifiableDataItem
      .readCommentsByDataItemID(verifiableDataItemKey).comments;

    // read details from related evidence descriptor
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
      evidenceDescriptorDtls.relatedID;

    // Indicator used to indicate if dealing with participant evidence
    boolean isNonCaseEDForParticipantEvidence = false;

    // determine if verification item provided is being created for participant
    // level evidence
    // Evidence controller variables
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    isNonCaseEDForParticipantEvidence =
      evidenceControllerObj.isNonCaseEDForParticipantEvidence(
        evidenceDescriptorIDRelatedIDAndEvidenceType);
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    final boolean isPDCEvidence =
      evidenceControllerObj.isPDCEvidence(evidenceTypeKey);

    // only read by caseID if dealing with integrated case or product delivery
    if (!isNonCaseEDForParticipantEvidence && !isPDCEvidence) {
      // if product delivery get the integrated case id
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

        evidenceAndDataItemNameDetails.caseID = caseHeaderObj
          .readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;

      } else {

        evidenceAndDataItemNameDetails.caseID = dtls.verificationLinkedID;
      }
    } else {
      evidenceAndDataItemNameDetails.caseID = caseKey.caseID;
    }

    evidenceAndDataItemNameDetails.dataItemName =
      vdIEDLinkObj.readVerifiableDataItemName(vdiedLinkKey).name;

    // Get the participant name
    // evidenceDescriptorKey.evidenceDescriptorID = dtls.evidenceDescriptorID;
    // evidenceDescriptorDtls =
    evidenceDescriptorObj.read(evidenceDescriptorKey);
    evidenceAndDataItemNameDetails.evidenceStatus =
      evidenceDescriptorDtls.statusCode;
    // get the Concern Role name from Participant ID.
    concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);
    evidenceAndDataItemNameDetails.clientName =
      concernRoleNameDetails.concernRoleName;
    // assign all the structs to return struct
    // assign the verification item provided details which has expiry date info
    // also
    viewVerificationDetails.itemProvidedListDetailsList =
      itemProvidedExpiryDateDetailsList;
    viewVerificationDetails.dtls = evidenceAndDataItemNameDetails;
    viewVerificationDetails.commentDtls = commentsDetails;

    verifiableDataItemsecurityDetails =
      verifiableDataItem.readViewSecurityDetails(verifiableDataItemKey);
    if (verifiableDataItemsecurityDetails.viewSID.length() != 0) {
      securityResult.result =
        curam.util.security.Authorisation.isSIDAuthorised(
          verifiableDataItemsecurityDetails.viewSID, userKey.userName);

      if (!securityResult.result) {

        final AppException appException = new AppException(
          ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_FV_NO_APPROPRIATE_PRIVILEGES);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(appException,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    return viewVerificationDetails;
  }

  // END, CR00452604

  // BEGIN, CR00451895, MKM
  /**
   * Returns the count of Outstanding Verification for a CaseID where the
   * evidence status is ACTIVE and INEDIT.
   *
   * @param CaseIDKey
   * The Case ID.
   *
   * @return The count of OutstandingVerification.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public VerificationRecordCount getOutstandingVerificationCountForCase(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {

    final CaseIDAndEvdStatusKey caseIDAndEvdStatusKey =
      new CaseIDAndEvdStatusKey();
    VerificationRecordCount verificationRecordCount =
      new VerificationRecordCount();
    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      VerificationFactory.newInstance();

    caseIDAndEvdStatusKey.caseID = caseIDKey.caseID;
    verificationRecordCount =
      verification.countOutstandingVerificationForCase(caseIDAndEvdStatusKey);

    return verificationRecordCount;
  }
  // END CR00451895

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationInfoList listVerificationsForVerificationLinkedID(
    final VerificationLinkedIDAndIsCaseIDKey key)
    throws AppException, InformationalException {

    final VerificationLinkedIDAndRecordStatusCode vlIDKey =
      new VerificationLinkedIDAndRecordStatusCode();
    vlIDKey.verificationLinkedID = key.verificationLinkedID;
    vlIDKey.recordStatusCode = RECORDSTATUS.NORMAL;

    CaseHeaderDtls caseheader = null;
    if (key.isCaseID) {
      final CaseHeaderKey caseKey = new CaseHeaderKey();
      caseKey.caseID = key.verificationLinkedID;
      caseheader = CaseHeaderFactory.newInstance().read(caseKey);
    }

    final VerificationByVerificationLinkedIDDetailsList verifications =
      VerificationFactory.newInstance()
        .searchVerificationsByVerificationLinkedIDAndRecordStatusCode(
          vlIDKey);

    return buildVerificationInfoList(caseheader, verifications);
  }

  /**
   * Calls the VerificationAdaptor to convert from a flat list to a structured
   * list of Verifications, and also adds further attributes to the returned
   * list.
   *
   * @param caseheader
   * The corresponding CaseHeader object for the verifications. if the
   * verifications belong to a case rather than a concern role.
   * @param verifications
   * An unstructured list of verifications for a case or concern role.
   * @return A structured list of the verifications, including further details
   * of the verification.
   * @throws AppException
   * Generic exception signature.
   * @throws InformationalException
   * Generic exception signature.
   *
   */
  private VerificationInfoList buildVerificationInfoList(
    final CaseHeaderDtls caseheader,
    final VerificationByVerificationLinkedIDDetailsList verifications)
    throws AppException, InformationalException {

    final VerificationAdaptor verificationAdaptor = new VerificationAdaptor();

    final VerificationInfoList result =
      verificationAdaptor.convertToStructuredList(verifications);

    for (final VerificationInfo vInfo : result.data) {

      // Map Concern Details
      if (caseheader != null) {
        final VerificationCaseInfo caseInfo = new VerificationCaseInfo();
        vInfo.verificationCaseInfo = caseInfo.assign(caseheader);
      }

      final ConcernRoleKey crKey = new ConcernRoleKey();
      crKey.concernRoleID = vInfo.relatedPerson.concernRoleID;

      final ConcernRoleNameDetails concern =
        ConcernRoleFactory.newInstance().readConcernRoleName(crKey);
      vInfo.relatedPerson.concernRoleName = concern.concernRoleName;

      // Map Evidence Details
      // evidence free text needs to be retrieved
      final EvidenceMap map = EvidenceController.getEvidenceMap();
      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(vInfo.evidenceType);
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
      eiEvidenceKey.evidenceID = vInfo.relatedEvidenceID;
      eiEvidenceKey.evidenceType = vInfo.evidenceType;

      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
        standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

      vInfo.evidenceSummary = LocalizableXMLStringHelper
        .toPlainText(eiFieldsForListDisplayDtls.summary);

      // further details for the VerificationItemProvided records - expiry date
      // and added by user's full name:
      final curam.verification.sl.infrastructure.intf.VerificationItemProvided verificationItemProvidedObj =
        curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
          .newInstance();
      final VerificationItemProvidedKey verificationItemProvidedKey =
        new VerificationItemProvidedKey();

      for (final VerificationItemProvidedInfo itemProvided : vInfo.verificationItemsProvided) {
        final UsersKey ukey = new UsersKey();
        ukey.userName = itemProvided.verificationItemProvidedAddedByUser;
        itemProvided.verificationItemProvidedAddedByUserFullName =
          UserAccessFactory.newInstance().getFullName(ukey).fullname;

        verificationItemProvidedKey.verificationItemProvidedID =
          itemProvided.verificationItemProvidedID;
        itemProvided.verificationItemProvidedExpiryDate =
          verificationItemProvidedObj
            .calculateExpiryDate(verificationItemProvidedKey).expiryDate;
      }

      // get the list of related VerifictaionItemUtilization/requiredProof
      // records
      final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization =
        VerificationItemUtilizationFactory.newInstance();

      final VerifiableDataItemKey verifiableDataItemKey =
        new VerifiableDataItemKey();
      verifiableDataItemKey.verifiableDataItemID = vInfo.verifiableDataItemID;
      final SearchByVerifiableDataItemIdListList itemUtilizationList =
        verificationItemUtilization
          .searchAllItemUtilizationByVerifiableDataItemID(
            verifiableDataItemKey);

      // get further VerifictionItemUtilization details and VerificationItems
      // for each entry in the list
      for (final SearchByVerifiableDataItemIdList itemUtilization : itemUtilizationList.dtls) {
        if (!itemUtilization.recordStatus
          .equalsIgnoreCase(RECORDSTATUSEntry.CANCELLED.getCode())) {

          final VerificationItemUtilizationKey itemUtilzationKey =
            new VerificationItemUtilizationKey();
          itemUtilzationKey.verificationItemUtilizationID =
            itemUtilization.verificationItemUtilizationID;
          final VerificationItemUtilizationDtls verificationItemUtilzationDtls =
            verificationItemUtilizationObj.read(itemUtilzationKey);
          final VerificationItemKey verificationItemKey =
            new VerificationItemKey();
          verificationItemKey.verificationItemID =
            itemUtilization.verificationItemID;
          final VerificationItemDtls verificationItem =
            verificationItemObj.read(verificationItemKey);

          final VerificationItemAndUtilization utilizationDetails =
            new VerificationItemAndUtilization();
          utilizationDetails.verificationItemUtilizationID =
            verificationItemUtilzationDtls.verificationItemUtilizationID;
          utilizationDetails.verificationGroupId =
            verificationItemUtilzationDtls.verificationGroupID;
          utilizationDetails.verificationItemUtilizationMandatory =
            verificationItemUtilzationDtls.mandatory;
          utilizationDetails.verificationItemUtilizationUsageType =
            verificationItemUtilzationDtls.usageType;
          utilizationDetails.fromDate =
            verificationItemUtilzationDtls.fromDate;
          utilizationDetails.toDate = verificationItemUtilzationDtls.toDate;
          utilizationDetails.verificationItemName = verificationItem.name;
          utilizationDetails.verificationItemType = verificationItem.type;

          vInfo.verificationItemAndUtilization.addRef(utilizationDetails);

        }
      }

    }

    // Inflight verifications should be removed from the returned list
    return filterInflightVerifications(result);

  }

  /**
   * Filters out verifications that are associated with Evidence that is 'In
   * Flight'
   *
   * When AES runs to copy Evidence over from one case to another it also copies
   * any Verifications associated. Since the Evidence has not been accepted onto
   * the record yet it will still have one of the 'In Flight' statuses. The
   * Verifications associated with this Evidence should not be included in the
   * return list
   *
   * This method iterates through the list of Verifications and records the ones
   * which have an Evidence status code which is NOT one of the four standard
   * ones (ACTIVE, INEDIT, SUPERSEDED, CANCELLED). Records included in this list
   * are then removed from the main set.
   *
   * @param verificationsInfoList List of verifications
   * @return List of verifications with 'inflight' ones removed
   */
  private VerificationInfoList filterInflightVerifications(
    final VerificationInfoList verificationsInfoList) {

    final ArrayList<VerificationInfo> inflightVerifications =
      new ArrayList<VerificationInfo>();

    final ArrayList<String> validStatusCodes = new ArrayList<String>();
    validStatusCodes.add(EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode());
    validStatusCodes.add(EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode());
    validStatusCodes.add(EVIDENCEDESCRIPTORSTATUSEntry.SUPERSEDED.getCode());
    validStatusCodes.add(EVIDENCEDESCRIPTORSTATUSEntry.CANCELED.getCode());

    for (final VerificationInfo verificationInfo : verificationsInfoList.data) {

      if (!validStatusCodes.contains(verificationInfo.evidenceStatus)) {
        inflightVerifications.add(verificationInfo);
      }
    }

    verificationsInfoList.data.removeAll(inflightVerifications);

    return verificationsInfoList;
  }

}
