/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2005-2006, 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;


import curam.codetable.VERIFIABLEITEMNAME;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.IntegratedCaseFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.IntegratedCase;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.TaskManagementUtilityFactory;
import curam.core.sl.intf.Communication;
import curam.core.sl.intf.TaskManagementUtility;
import curam.core.sl.struct.DateTimeInSecondsKey;
import curam.core.sl.struct.RecordedCommDetails1;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ICClosureDtls;
import curam.message.DUEDATEWORKFLOW;
import curam.util.administration.fact.CodeTableAdminFactory;
import curam.util.administration.intf.CodeTableAdmin;
import curam.util.administration.struct.CodeTableItemDetails;
import curam.util.administration.struct.CodeTableItemUniqueKey;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.VerificationRequirement;
import curam.verification.sl.entity.struct.VerificationRequirementDtls;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.intf.Verification;
import curam.verification.sl.infrastructure.entity.struct.CaseIDDetails;
import curam.verification.sl.infrastructure.entity.struct.ReadByVerIDAndVerLinkedTypeKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationDueDateAndWarningDays;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import curam.verification.sl.infrastructure.struct.CalculateDueDate;
import curam.verification.sl.infrastructure.struct.WarningDate;


// BEGIN, CR00279801, DJ
/**
 * Due days specifies the number of days after a particular event , a
 * verification should fall due. Warning days specifies how many days prior
 * notice a case worker will receive before the verification due date. If no
 * warning date is specified, a case worker will not receive any warning before
 * the verification due date.
 * This process class is for calculating the due date and warning days for the
 * verification. Due date processing uses Curam workflow. This also manages
 * client communication information and case closure functionality.
 */
// END, CR00279801

public abstract class ProcessVerificationDueDate extends curam.verification.sl.infrastructure.base.ProcessVerificationDueDate {

  /**
   * This to check the due days
   *
   * @param key identifies Verification record
   * @exception AppException, InformationException
   */

  @Override
  public CalculateDueDate calculateDueDate(VerificationKey key)
    throws AppException, InformationalException {

    // DueDate Object
    final CalculateDueDate calculateDueDate = new CalculateDueDate();
    final Verification verification = VerificationFactory.newInstance();
    final Date currentDate = Date.getCurrentDate();

    VerificationDueDateAndWarningDays verificationDueDateAndWarningDays = new VerificationDueDateAndWarningDays();

    // reading VerificationDueDate and Warning Days by VerificationID
    verificationDueDateAndWarningDays = verification.readVerificationDueDateAndWarningDysByVerificationID(
      key);

    // case Due Date default true
    calculateDueDate.futureDateIndicator = true;

    if (verificationDueDateAndWarningDays.dueDate.before(currentDate.addDays(1))) {

      calculateDueDate.futureDateIndicator = false;

      // BEGIN, CR00021355, NK
      final Verification verificationObj = VerificationFactory.newInstance();
      final VerificationKey verificationKey = new VerificationKey();
      VerificationDtls verificationDtls = new VerificationDtls();

      verificationKey.verificationID = key.verificationID;

      verificationDtls = verificationObj.read(verificationKey);

      final VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();
      VerificationRequirementDtls verificationRequirementDtls;
      final VerificationRequirement verificationRequirement = VerificationRequirementFactory.newInstance();

      verificationRequirementKey.verificationRequirementID = verificationDtls.verificationRequirementID;

      verificationRequirementDtls = verificationRequirement.read(
        verificationRequirementKey);
      if (verificationRequirementDtls.dueDateEventType.trim().length() > 0) {
        // raise workflow event for the event type specified
        final Event workflowEvent = new Event();

        // BEGIN CR00051283, NRV
        // BEGIN,HARP 66655,TV
        workflowEvent.eventKey = curam.events.Verification.DueDate;
        // END,HARP 66655
        // END CR00051283

        workflowEvent.primaryEventData = key.verificationID;

        EventService.raiseEvent(workflowEvent);
      }

      // END, CR00021355

    }
    return calculateDueDate;
  }

  /**
   * This to calculateWarningDate for future or Past
   *
   * @param key identifies Verification record
   * @exception AppException, InformationalException
   */
  @Override
  public WarningDate calculateWarningDate(VerificationKey key)
    throws AppException, InformationalException {

    final VerificationKey verificationKey = new VerificationKey();
    final WarningDate WarningDateObj = new WarningDate();
    final Verification verification = VerificationFactory.newInstance();
    final TaskManagementUtility taskManagementUtilityObj = TaskManagementUtilityFactory.newInstance();
    final DateTimeInSecondsKey dateTimeInSecondsKey = new DateTimeInSecondsKey();
    final Date currentDate = Date.getCurrentDate();

    VerificationDueDateAndWarningDays verificationDueDateAndWarningDays = new VerificationDueDateAndWarningDays();

    verificationKey.verificationID = key.verificationID;

    // reading VerificationDueDate and Warning Days by VerificationID
    verificationDueDateAndWarningDays = verification.readVerificationDueDateAndWarningDysByVerificationID(
      key);
    WarningDateObj.warningDateIndicator = false;
    WarningDateObj.warningDateDeadline = 0;
    WarningDateObj.verificationStatus = VerificationConst.gkDeadlineElapsed;
    WarningDateObj.dueDate = verificationDueDateAndWarningDays.dueDate;
    dateTimeInSecondsKey.dateTime = verificationDueDateAndWarningDays.dueDate.getDateTime();
    WarningDateObj.dueDateDeadline = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;

    if (verificationDueDateAndWarningDays.warningDays != 0) {

      WarningDateObj.warningDate = verificationDueDateAndWarningDays.dueDate.addDays(
        -verificationDueDateAndWarningDays.warningDays);

      dateTimeInSecondsKey.dateTime = WarningDateObj.warningDate.getDateTime();
      WarningDateObj.warningDateDeadline = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;

      if (!WarningDateObj.warningDate.before(currentDate.addDays(1))) {

        // Case warning date in future
        WarningDateObj.warningDateIndicator = true;
      }
    }

    return WarningDateObj;
  }

  /**
   * This method is to closeCase by passing VerificationKey
   *
   * @param key verification key
   * @exception AppException, InformationalException
   */
  @Override
  public void closeCase(VerificationKey key) throws AppException,
      InformationalException {

    CaseIDDetails caseIDDetails = new CaseIDDetails();
    // System User variables.
    final Verification verification = VerificationFactory.newInstance();

    // BEGIN, CR00074026, BF
    // Read the caseID based on the verificationID
    // The caseID is no longer stored on the verification entity -
    // instead a verificationLinkedID & verificationLinkedType (IC, PD or
    // Participant) This readCaseID always sets the verificationLinkedType to
    // Participant to ensure the the search checks for all types that are not
    // participant i.e. case
    final ReadByVerIDAndVerLinkedTypeKey readByVerIDAndVerLinkedTypeKey = new ReadByVerIDAndVerLinkedTypeKey();

    readByVerIDAndVerLinkedTypeKey.verificationID = key.verificationID;
    caseIDDetails = verification.readCaseID(readByVerIDAndVerLinkedTypeKey);
    // END, CR00074026
    // IntegratedCase manipulation variables
    final IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();
    final ICClosureDtls icClosureDtls = new ICClosureDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign details to close the case
    icClosureDtls.caseID = caseIDDetails.caseID;
    icClosureDtls.priority = curam.codetable.CASEPRIORITY.HIGH;
    icClosureDtls.reasonCode = curam.codetable.CASECANCELREASON.MANUAL;
    icClosureDtls.sensitivityCode = curam.codetable.SENSITIVITY.MINIMUM;
    icClosureDtls.versionNo = 1;

    // Call IntegratedCase BPO to close the case
    try {

      integratedCaseObj.closeIntegratedCase(icClosureDtls);

    } catch (final Exception e) {// do Nothing
    }
  }

  /**
   * The sendCommunication method stores the client communication information
   * in communication.
   *
   * @param key Verification Key
   *
   * @exception AppException, InformationalException
   */
  @Override
  public void sendCommunication(VerificationKey key) throws AppException,
      InformationalException {

    CaseIDDetails caseIDDetails = new CaseIDDetails();
    final Verification verification = VerificationFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final Date currentDate = Date.getCurrentDate();

    // Communication service layer object
    final Communication communicationObj = CommunicationFactory.newInstance();

    // Create concernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // BEGIN, CR00237138, NS
    final RecordedCommDetails1 recordedCommDetails = new RecordedCommDetails1();
    // END, CR00237138

    // BEGIN, CR00074026, BF
    // Read the caseID based on the verificationID
    // The caseID is no longer stored on the verification entity -
    // instead a verificationLinkedID & verificationLinkedType (IC, PD or
    // Participant) This readCaseID always sets the verificationLinkedType to
    // Participant to ensure the the search checks for all types that are not
    // participant i.e. case
    final ReadByVerIDAndVerLinkedTypeKey readByVerIDAndVerLinkedTypeKey = new ReadByVerIDAndVerLinkedTypeKey();

    readByVerIDAndVerLinkedTypeKey.verificationID = key.verificationID;
    caseIDDetails = verification.readCaseID(readByVerIDAndVerLinkedTypeKey);
    // END, CR00074026
    caseHeaderKey.caseID = caseIDDetails.caseID;

    CaseHeaderDtls caseHeaderDtls;

    // Read the case header
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read concernRole entity
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    recordedCommDetails.correspondentParticipantRoleID = concernRoleDtls.concernRoleID;
    recordedCommDetails.caseID = caseIDDetails.caseID;
    recordedCommDetails.correspondentName = concernRoleDtls.concernRoleName;
    recordedCommDetails.communicationDate = currentDate;
    recordedCommDetails.communicationDirection = curam.codetable.COMMUNICATIONDIRECTION.OUTGOING;
    recordedCommDetails.communicationTypeCode = curam.codetable.COMMUNICATIONTYPE.LETTER;
    recordedCommDetails.correspondentType = curam.codetable.CORRESPONDENT.CLIENT;
    recordedCommDetails.methodTypeCode = curam.codetable.COMMUNICATIONMETHOD.HARDCOPY;

    // BEGIN, CR00279801, DJ
    final CodeTableAdmin codeTableAdminObj = CodeTableAdminFactory.newInstance();
    final CodeTableItemUniqueKey codeTableItemUniqueKey = new CodeTableItemUniqueKey();
    CodeTableItemDetails codeTableItemDetails = new CodeTableItemDetails();

    codeTableItemUniqueKey.code = verification.readNameByVerificationID(key).verifiableDataItemName;
    codeTableItemUniqueKey.locale = TransactionInfo.getProgramLocale();
    codeTableItemUniqueKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    codeTableItemDetails = codeTableAdminObj.readCTIDetailsForLocaleOrLanguage(
      codeTableItemUniqueKey);
    // END, CR00279801

    LocalisableString communicationSubject = new LocalisableString(
      DUEDATEWORKFLOW.INF_VERIFICATION_WORKFLOW_COMMUNICATION_SUBJECT);

    // BEGIN, CR00279801, DJ
    communicationSubject.arg(codeTableItemDetails.description);
    communicationSubject.arg(caseHeaderDtls.caseReference);
    // END, CR00279801

    // BEGIN, CR00163659, CL
    recordedCommDetails.subject = communicationSubject.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659

    communicationSubject = new LocalisableString(
      DUEDATEWORKFLOW.INF_VERIFICATION_WORKFLOW_COMMUNICATION_TEXT);
    communicationSubject.arg(
      verification.readVerificationDueDateAndWarningDysByVerificationID(key).dueDate);

    // BEGIN, CR00163659, CL
    recordedCommDetails.communicationText = communicationSubject.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659

    // BEGIN, CR00237138, NS
    communicationObj.createRecordedCommunication1(recordedCommDetails);
    // END, CR00237138

  }

  /**
   * The deadLineExpired method triggers the CloseCase Event
   * or DeadlineElapsed Event
   *
   * @param key
   * @exception AppException, InformationalException
   */
  @Override
  public void deadLineExpired(VerificationKey key) throws AppException,
      InformationalException {

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    // read caseHeader
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseReferenceAndStatusDetails caseReferenceAndStatusDetails;
    CaseIDDetails caseIDDetails = new CaseIDDetails();
    final Verification verification = VerificationFactory.newInstance();

    // BEGIN, CR00074026, BF
    // Read the caseID based on the verificationID
    // The caseID is no longer stored on the verification entity -
    // instead a verificationLinkedID & verificationLinkedType (IC, PD or
    // Participant)This readCaseID always sets the verificationLinkedType to
    // Participant to ensure the the search checks for all types that are not
    // participant i.e. case
    final ReadByVerIDAndVerLinkedTypeKey readByVerIDAndVerLinkedTypeKey = new ReadByVerIDAndVerLinkedTypeKey();

    readByVerIDAndVerLinkedTypeKey.verificationID = key.verificationID;
    caseIDDetails = verification.readCaseID(readByVerIDAndVerLinkedTypeKey);
    // END, CR00074026
    caseSearchKey.caseID = caseIDDetails.caseID;

    caseReferenceAndStatusDetails = caseHeaderObj.readCaseReferenceAndStatusByCaseID(
      caseSearchKey);

    if (caseReferenceAndStatusDetails.statusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {
      // If Verification Workflow exist, Raise the workflow closeCase Event
      final Event dueDateChangedEvent = new Event();

      // BEGIN, CR00059934, MPB
      // Replaced event Class and event Type data files with actual event files
      dueDateChangedEvent.eventKey = curam.events.Verification.CaseClosed;
      // END, CR00059934, MPB

      dueDateChangedEvent.primaryEventData = caseIDDetails.caseID;
      dueDateChangedEvent.secondaryEventData = VerificationConst.gkCaseClosed;

      EventService.raiseEvent(dueDateChangedEvent);

    } else {
      // raise workflow event for DeadLine Expired
      final Event dueDateExpiredEvent = new Event();

      // BEGIN, CR00059934, MPB
      // Replaced event Class and event Type data files with actual event files

      dueDateExpiredEvent.eventKey = curam.events.Verification.DueDateElapsed;
      // END, CR00059934, MPB

      dueDateExpiredEvent.primaryEventData = key.verificationID;
      dueDateExpiredEvent.secondaryEventData = VerificationConst.gkDeadlineElapsed;

      EventService.raiseEvent(dueDateExpiredEvent);

      // BEGIN, CR00021355, NK
      final Date currentDate = Date.getCurrentDate();
      VerificationDueDateAndWarningDays verificationDueDateAndWarningDays = new VerificationDueDateAndWarningDays();

      // reading VerificationDueDate and Warning Days by VerificationID
      verificationDueDateAndWarningDays = verification.readVerificationDueDateAndWarningDysByVerificationID(
        key);

      if (verificationDueDateAndWarningDays.dueDate.before(currentDate)) {

        final Verification verificationObj = VerificationFactory.newInstance();
        final VerificationKey verificationKey = new VerificationKey();
        VerificationDtls verificationDtls = new VerificationDtls();

        verificationKey.verificationID = key.verificationID;

        verificationDtls = verificationObj.read(verificationKey);

        final VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();
        VerificationRequirementDtls verificationRequirementDtls;
        final VerificationRequirement verificationRequirement = VerificationRequirementFactory.newInstance();

        verificationRequirementKey.verificationRequirementID = verificationDtls.verificationRequirementID;

        verificationRequirementDtls = verificationRequirement.read(
          verificationRequirementKey);
        if (verificationRequirementDtls.dueDateEventType.trim().length() > 0) {
          // raise workflow event for the event type specified
          final Event workflowEvent = new Event();

          // BEGIN CR00051283, NRV
          // BEGIN,HARP 66655,TV
          workflowEvent.eventKey = curam.events.Verification.DueDate;
          // END,HARP 66655
          // END, CR00051283

          workflowEvent.primaryEventData = key.verificationID;

          EventService.raiseEvent(workflowEvent);
        }
      }
      // END, CR00021355
    }

  }
}
