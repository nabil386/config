/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2005,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.NONCASEDATATYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REVERIFICATIONMODE;
import curam.codetable.VERIFIABLEITEMNAME;
import curam.codetable.VERIFICATIONDUEDATEFROM;
import curam.codetable.VERIFICATIONLEVEL;
import curam.codetable.VERIFICATIONPOSTPONEDON;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.VERIFIABLEITEMNAMEEntry;
import curam.codetable.impl.VERIFICATIONITEMNAMEEntry;
import curam.codetable.impl.VERIFICATIONLEVELEntry;
import curam.codetable.impl.VERIFICATIONSTATUSEntry;
import curam.core.facade.infrastructure.struct.VerificationDetailsForIncomingEvidence;
import curam.core.facade.infrastructure.struct.VerificationDetailsForIncomingEvidenceList;
import curam.core.facade.infrastructure.struct.VerificationItemProvidedDetails;
import curam.core.facade.infrastructure.struct.VerificationItemProvidedDetailsList;
import curam.core.facade.struct.ListClientRoleKey;
import curam.core.facade.struct.ListPDClientRoleDetails;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.ReadByTypeAndCaseIDKey;
import curam.core.sl.fact.AttachmentFactory;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.impl.NotificationWDOStruct;
import curam.core.sl.impl.ProcessPostponedVItem;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndStatusCodeKey;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndStatuses;
import curam.core.sl.infrastructure.entity.struct.CaseIDParticipantIDStatusCode;
import curam.core.sl.infrastructure.entity.struct.CaseIDParticipantRoleTypesStatusCode;
import curam.core.sl.infrastructure.entity.struct.CaseRelatedIDTypeStatusKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorIDRelatedIDAndEvidenceType;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeParticipantIDStatusesKey;
import curam.core.sl.infrastructure.entity.struct.ParticipantIDStatusAndDateKey;
import curam.core.sl.infrastructure.entity.struct.ReadEvidenceTypeParticipantDetails;
import curam.core.sl.infrastructure.entity.struct.ReadEvidenceTypeParticipantDetailsList;
import curam.core.sl.infrastructure.entity.struct.ReadRelatedIDParticipantIDAndEvidenceTypeDetails;
import curam.core.sl.infrastructure.entity.struct.RelatedIDStatusAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.SharedInstanceIDCaseIDStatusCodes;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.BusinessObjectKey;
import curam.core.sl.infrastructure.struct.CaseEvidenceVerificationDetails;
import curam.core.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDisplayDetails;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDisplayDetailsList;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseKey;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AttachmentKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderReadmultiDetails1;
import curam.core.struct.CaseHeaderReadmultiDetails1List;
import curam.core.struct.CaseHeaderReadmultiKey1;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDAndProductTypeDetails;
import curam.core.struct.CaseIDAndProductTypeDetailsList;
import curam.core.struct.CaseIDAndTypeCodeDetails;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CaseTypeICTypeAndStartDate;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleIDList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.message.BPOVERIFICATIONCONST;
import curam.message.ENTAPPLYCHANGES;
import curam.message.ENTVERIFICATION;
import curam.message.ENTVERIFICATIONCONTROLLER;
import curam.message.INFORMATIONALMESSAGE;
import curam.message.SEPARATOR;
import curam.message.VERIFICATIONWAIVER;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.message.CatEntry;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;
import curam.util.workflow.impl.EnactmentService;
import curam.verification.evidence.impl.VerificationEvidenceFactory;
import curam.verification.evidence.impl.VerificationEvidenceInterface;
import curam.verification.facade.infrastructure.struct.CaseEvidenceVerificationDisplayDetails;
import curam.verification.facade.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList;
import curam.verification.impl.VerificationUtilities;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.DependentDataItem;
import curam.verification.sl.entity.intf.VerifiableDataItem;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.intf.VerificationRequirement;
import curam.verification.sl.entity.struct.DataItemRelatedItemAndStatusDetails;
import curam.verification.sl.entity.struct.EvidenceTypeAndRelatedItemTypeDetails;
import curam.verification.sl.entity.struct.ReadReqUsageRelatedItemType;
import curam.verification.sl.entity.struct.ReverificationModeRequirementIDDetails;
import curam.verification.sl.entity.struct.ReverificationModeRequirementIDDetailsList;
import curam.verification.sl.entity.struct.SearchDueDaysDueDateFromAndRequirementID;
import curam.verification.sl.entity.struct.SearchDueDaysDueDateFromAndRequirementIDList;
import curam.verification.sl.entity.struct.UtlizationExpiryWarningAndDateFrom;
import curam.verification.sl.entity.struct.UtlizationExpiryWarningAndDateFromList;
import curam.verification.sl.entity.struct.VerifiableDataItemAndStatusKey;
import curam.verification.sl.entity.struct.VerifiableDataItemDataItemNameAndIDDetails;
import curam.verification.sl.entity.struct.VerifiableDataItemDataItemNameAndIDDetailsList;
import curam.verification.sl.entity.struct.VerifiableDataItemDetails;
import curam.verification.sl.entity.struct.VerifiableDataItemDtls;
import curam.verification.sl.entity.struct.VerifiableDataItemEvidenceTypeAndStatus;
import curam.verification.sl.entity.struct.VerifiableDataItemIDDateAndRelatedItem;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.entity.struct.VerificationRequirementDtls;
import curam.verification.sl.entity.struct.VerificationRequirementIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.entity.struct.VerificationRequirementKeyList;
import curam.verification.sl.entity.struct.VerificationRequirementLevelMandatoryAndDatesDetails;
import curam.verification.sl.fact.ConditionalVerificationResultFactory;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationWaiverFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.Verification;
import curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.intf.VerificationWaiver;
import curam.verification.sl.infrastructure.entity.struct.CaseIDDetails;
import curam.verification.sl.infrastructure.entity.struct.CaseIDVerificationStatusKey;
import curam.verification.sl.infrastructure.entity.struct.DataItemIDAndDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorIDAndVerStatusKey;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorIDDetails;
import curam.verification.sl.infrastructure.entity.struct.ItemCount;
import curam.verification.sl.infrastructure.entity.struct.MandatoryVerificationDetails;
import curam.verification.sl.infrastructure.entity.struct.MandatoryVerificationDetailsList;
import curam.verification.sl.infrastructure.entity.struct.ReadByEvdDescriptionIDCaseIDKey;
import curam.verification.sl.infrastructure.entity.struct.ReadByVDIEDLinkAndVerLinkedIDTypeKey;
import curam.verification.sl.infrastructure.entity.struct.ReadByVDIEDLinkIDReqIDVerLinkIDandType;
import curam.verification.sl.infrastructure.entity.struct.ReadByVerIDAndVerLinkedTypeKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndDataItemIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDMandatoryAndRelatedItemKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDMandatoryKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDRequirementIDAndCaseIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentSummaryDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentSummaryDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationCountAndEvidenceTypeDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDStatusDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationStatusDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverEDParticipantCaseIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverEDParticipantCaseIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverKey;
import curam.verification.sl.infrastructure.fact.CurrentPostponedVerificationFactory;
import curam.verification.sl.infrastructure.fact.MaintainVerificationWaiverFactory;
import curam.verification.sl.infrastructure.fact.SharedVERItemProvidedFactory;
import curam.verification.sl.infrastructure.intf.MaintainVerificationWaiver;
import curam.verification.sl.infrastructure.struct.ContainsInd;
import curam.verification.sl.infrastructure.struct.CreateVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.CurrentPostponedVerificationDtls;
import curam.verification.sl.infrastructure.struct.CurrentPostponedVerificationDtlsList;
import curam.verification.sl.infrastructure.struct.CurrentPostponedVerificationKey;
import curam.verification.sl.infrastructure.struct.ErrorMessageDetails;
import curam.verification.sl.infrastructure.struct.EvidenceTypeAndParticipantDetailsListDetails;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationDetails;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationListDetails;
import curam.verification.sl.infrastructure.struct.ModifyVerificationRequirementDueDateKey;
import curam.verification.sl.infrastructure.struct.OutstandingIndicator;
import curam.verification.sl.infrastructure.struct.ParticipantIDVerifiableDataItemIDKey;
import curam.verification.sl.infrastructure.struct.ReadVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.ReadVerificationAttachmentLinkKey;
import curam.verification.sl.infrastructure.struct.ReadVerificationItemProvidedDetails;
import curam.verification.sl.infrastructure.struct.RequirementUsageDetails;
import curam.verification.sl.infrastructure.struct.RequirementUsageDetailsList;
import curam.verification.sl.infrastructure.struct.SharedVERItemProvidedDtls;
import curam.verification.sl.infrastructure.struct.SharedVERItemProvidedDtlsList;
import curam.verification.sl.infrastructure.struct.SourceVDIEDLinkIDKey;
import curam.verification.sl.infrastructure.struct.VerifiableDataItemAndRequirementIDDetails;
import curam.verification.sl.infrastructure.struct.VerifiableDataItemRelatedIDAndTypeKey;
import curam.verification.sl.infrastructure.struct.VerificationCountAndEvidenceTypeDetailsList;
import curam.verification.sl.infrastructure.struct.VerificationICTypeAndRelatedItemDetails;
import curam.verification.sl.infrastructure.struct.ViewVerificationDetails;
import curam.verification.sl.infrastructure.struct.WMVerificationDetails;
import curam.verification.sl.struct.ConditionalVerificationResultFetcherDtls;
import curam.verification.sl.struct.ConditionalVerificationResultFetcherInputDtls;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The VerificationController class provides a number of methods to verify the
 * data captured as case evidence. It determines if, any of the evidence entered
 * requires verification for the case.
 */

public class VerificationController
  extends curam.verification.sl.infrastructure.base.VerificationController
  implements VerificationInterface {

  // variables to build the error message in perform verification

  // BEGIN, CR00222190, ELG
  /**
   * Constant for the separator used in the context description.
   *
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText
   * (TransactionInfo.getProgramLocale())}. Replacement reason -
   * static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note
   * <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00069956, GM
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00222190

  // BEGIN, CR00098942, SAI
  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00098942

  // BEGIN, CR00222190, ELG
  /**
   * Constant for the coma used in the error messages.
   *
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
   * .getMessageText(TransactionInfo.getProgramLocale())}.
   * Replacement reason - static variables/constants cannot
   * reference TransactionInfo.getProgramLocale(). See release
   * note <CR00219408>.
   */
  @Deprecated
  protected static final String kComma = // BEGIN, CR00163471, JC
    INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION.getMessageText();

  // END, CR00163471, JC
  // END, CR00222190
  // END, CR00069956
  // BEGIN, CR00349499, ARM
  VerificationUtilities verificationUtilities = new VerificationUtilities();

  // END, CR00349499

  // BEGIN, CR00354770, KH
  @Inject
  private VerificationHook verificationEngineHook;

  // BEGIN, CR00430109, AKr
  @Inject(optional = true)
  private ProcessPostponedVItem processVerificationItem;

  // END, CR00430109

  // ___________________________________________________________________________
  /**
   * Add injection.
   */
  public VerificationController() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00354770

  // ___________________________________________________________________________
  /**
   * This verifyOnInsert method determine if, any of the evidence entered
   * requires verification for the case.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param eiEvidenceInsertDtls
   * EIEvidence insert details
   */
  @Override
  public void verifyOnInsert(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceInsertDtls eiEvidenceInsertDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00438738, AKr
    if (!(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT
      .equals(evidenceDescriptorDtls.statusCode)
      || EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT
        .equals(evidenceDescriptorDtls.statusCode))) {

      final Provider<DeferredVerificationProcessBehaviour> provider =
        GuiceWrapper.getInjector()
          .getProvider(DeferredVerificationProcessBehaviour.class);

      final DeferredVerificationProcessBehaviour deferredVerificationProcessBehaviourObj =
        provider.get();

      if (deferredVerificationProcessBehaviourObj.isVerificationDeferred()) {
        deferredVerificationProcessBehaviourObj
          .queueEvidenceForDeferredProcessing(evidenceDescriptorDtls);

      } else {

        // BEGIN, CR00417631, MV
        if (TransactionInfo.getFacadeScopeObject(
          VerificationConst.kPostponeVerification) != null
          // BEGIN, CR00426070, AKr
          && TransactionInfo
            .getFacadeScopeObject(VerificationConst.kPostponeVerification)
            .equals(true)) {
          if (TransactionInfo.getFacadeScopeObject(
            VerificationConst.kIsEvidenceSharingProcess) != null
            && TransactionInfo.getFacadeScopeObject(
              VerificationConst.kIsEvidenceSharingProcess).equals(true)) {
            // BEGIN, CR00427025, MV
            insertCurrentPostponedVerification(evidenceDescriptorDtls,
              evidenceDescriptorDtls, VERIFICATIONPOSTPONEDON.SHARING);
          } else {
            insertCurrentPostponedVerification(evidenceDescriptorDtls,
              evidenceDescriptorDtls, VERIFICATIONPOSTPONEDON.INSERT);
            // END, CR00427025
          }
          // END, CR00426070
          return;
        }
        // END, CR00417631

        executeVerifyOnInsert(evidenceDescriptorDtls, eiEvidenceInsertDtls);
      }
      // END, CR00438738
    }

  }

  // ___________________________________________________________________________
  // BEGIN, CR00191839, ND
  /**
   * This dataItemExists method checks if the given data item exists in the
   * EvidenceObject and its value is not empty.
   *
   * @param dataItem
   * Data item to compare
   * @param evidenceObject
   * EvidenceObject having the evidence data items
   * @param evidenceType
   * Evidence type (codetable code) of the specified evidence
   * object.
   * @throws InformationalException
   * @throws AppException
   */
  protected boolean dataItemExists(final String dataItem,
    final Object evidenceObject, final String evidenceType)
    throws AppException, InformationalException {

    // BEGIN, CR00213416, GYH
    return !VerificationEvidenceFactory
      .newInstance(CASEEVIDENCEEntry.get(evidenceType))
      .isFieldEmpty(dataItem, evidenceObject, evidenceType);
    // END, CR00213416
  }

  // END, CR00191839, ND

  // ___________________________________________________________________________
  /**
   * This verifyOnModify method determine if, any of the evidence modified
   * requires verification.
   *
   * @param evidenceDescriptorDtls
   * The existing Evidence descriptor details
   * @param newEvidenceDescriptorDtls
   * The changed Evidence descriptor details
   * @param eiEvidenceModifyDtls
   * EIEvidence modify details
   * @param eiEvidenceReadDtls
   * EIEvidence read details
   */
  @Override
  public void verifyOnModify(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00438738, AKr
    if (!(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT
      .equals(newEvidenceDescriptorDtls.statusCode)
      || EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT
        .equals(newEvidenceDescriptorDtls.statusCode))) {
      // BEGIN, CR00417631, MV
      if (TransactionInfo
        .getFacadeScopeObject(VerificationConst.kPostponeVerification) != null
        && TransactionInfo
          .getFacadeScopeObject(VerificationConst.kPostponeVerification)
          .equals(true)) {
        // BEGIN, CR00427025, MV
        insertCurrentPostponedVerification(newEvidenceDescriptorDtls,
          evidenceDescriptorDtls, VERIFICATIONPOSTPONEDON.UPDATE);
        // END, CR00427025
        return;
      }
      // END, CR00417631

      executeVerifyOnModify(evidenceDescriptorDtls, newEvidenceDescriptorDtls,
        eiEvidenceModifyDtls, eiEvidenceReadDtls);
    }
    // END, CR00438738

  }

  public void executeVerifyOnModify(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    // Populate the evidenceType key
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    // Check if participant evidence
    boolean isEvidenceParticipantData = false;

    isEvidenceParticipantData =
      evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);

    // If there is no caseID on the evidence descriptor we are
    // dealing with participant evidence at the participant level
    if (evidenceDescriptorDtls.caseID != 0) {

      if (isEvidenceParticipantData) {

        // It is a participant evidence descriptor at the case level
        if (evidenceDescriptorDtls.statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.ACTIVE)) {

          processActiveParticipantEvidenceVerifications(
            newEvidenceDescriptorDtls, evidenceDescriptorDtls,
            eiEvidenceModifyDtls, eiEvidenceReadDtls);

        } else if (evidenceDescriptorDtls.statusCode
          .equals(EVIDENCEDESCRIPTORSTATUS.INEDIT)) {

          processInEditEvidenceVerification(evidenceDescriptorDtls,
            eiEvidenceModifyDtls, eiEvidenceReadDtls);
        }

      } else {
        // BEGIN, CR00406381, RD
        final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
        final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

        caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
        final CaseHeaderDtls caseHeaderDtls =
          caseHeaderObj.read(caseHeaderKey);

        if (CASETYPECODEEntry.INTEGRATEDCASE.getCode()
          .equals(caseHeaderDtls.caseTypeCode)) {
          final CaseHeaderReadmultiKey1 caseHeaderReadmultiKey1 =
            new CaseHeaderReadmultiKey1();

          caseHeaderReadmultiKey1.integratedCaseID =
            evidenceDescriptorDtls.caseID;
          final CaseHeaderReadmultiDetails1List caseHeaderReadmultiDetails1List =
            caseHeaderObj.searchByIntegratedCaseID(caseHeaderReadmultiKey1);

          for (final CaseHeaderReadmultiDetails1 caseHeaderReadmultiDetails1 : caseHeaderReadmultiDetails1List.dtls
            .items()) {

            final ListPDClientRoleDetails listPDClientRoleDetails =
              listCaseMembers(caseHeaderReadmultiDetails1.caseID);

            if (!isEvidenceDescriptorRelatedToCaseMember(
              listPDClientRoleDetails,
              evidenceDescriptorDtls.participantID)) {
              continue;
            }

            // BEGIN, CR00430109, AKr
            final EvidenceDescriptorDtls evidenceDescriptorDtlsForPD =
              new EvidenceDescriptorDtls();

            evidenceDescriptorDtlsForPD.assign(newEvidenceDescriptorDtls);
            evidenceDescriptorDtlsForPD.caseID =
              caseHeaderReadmultiDetails1.caseID;
            // It is a temporal evidence descriptor
            // If Active, insert new record
            if (EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode()
              .equals(evidenceDescriptorDtls.statusCode)) {

              processActiveEvidenceVerification(evidenceDescriptorDtlsForPD,
                eiEvidenceModifyDtls, eiEvidenceReadDtls);
              // END, CR00430109

            } else if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode()
              .equals(evidenceDescriptorDtls.statusCode)) {

              processInEditEvidenceVerification(evidenceDescriptorDtls,
                eiEvidenceModifyDtls, eiEvidenceReadDtls);
            }
          }
          // BEGIN, CR00406429, RD
          // BEGIN, CR00407031, RD
          // It is a temporal evidence descriptor
          // If Active, insert new record
          if (EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode()
            .equals(evidenceDescriptorDtls.statusCode)) {

            processActiveEvidenceVerification(newEvidenceDescriptorDtls,
              eiEvidenceModifyDtls, eiEvidenceReadDtls);

          } else if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode()
            .equals(evidenceDescriptorDtls.statusCode)) {

            processInEditEvidenceVerification(evidenceDescriptorDtls,
              eiEvidenceModifyDtls, eiEvidenceReadDtls);
          }
          // END, CR00407031
          // END, CR00406429
        } else {
          // It is a temporal evidence descriptor
          // If Active, insert new record
          if (EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode()
            .equals(evidenceDescriptorDtls.statusCode)) {

            processActiveEvidenceVerification(newEvidenceDescriptorDtls,
              eiEvidenceModifyDtls, eiEvidenceReadDtls);

          } else if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode()
            .equals(evidenceDescriptorDtls.statusCode)) {

            processInEditEvidenceVerification(evidenceDescriptorDtls,
              eiEvidenceModifyDtls, eiEvidenceReadDtls);
          }
        }
        // END, CR00406381
      }
    } else {
      // Verify at the participant level
      verifyOnModifyForParticipantData(evidenceDescriptorDtls,
        eiEvidenceModifyDtls, eiEvidenceReadDtls);
    }

  }

  // ___________________________________________________________________________
  /**
   * This processInEditEvidenceVerification method processes the in edit
   * evidence verification for the case.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   * @param eiEvidenceReadDtls
   * previous evidence details
   */
  public void processInEditEvidenceVerification(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    // Populate the evidenceType key
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    final VDIEDLinkKey vdIEDLinkKey = new VDIEDLinkKey();

    final VerificationItemProvided verificationItemProvidedObj =
      VerificationItemProvidedFactory.newInstance();

    final StringBuffer informationalMessage = new StringBuffer();
    int dataItemAdded = 0;

    ItemCount itemCount = new ItemCount();

    // check if any verification records are not inserted
    evidenceDescriptorKey = new EvidenceDescriptorKey();
    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    final VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkDtlsList =
      vdIEDLinkObj.readByEvidenceDescriptorID(evidenceDescriptorKey);

    if (vDIEDLinkDtlsList.dtls.size() == 0) {
      // check if any verification requirements exists, if so insert
      // records
      // insertInEditEvidenceVerification(evidenceDescriptorDtls,
      // eiEvidenceModifyDtls, eiEvidenceReadDtls);
      final EIEvidenceInsertDtls eiEvidenceInsertDtls =
        new EIEvidenceInsertDtls();

      eiEvidenceInsertDtls.evidenceObject =
        eiEvidenceModifyDtls.evidenceObject;
      eiEvidenceInsertDtls.parentKey = eiEvidenceModifyDtls.parentKey;
      verifyOnInsert(evidenceDescriptorDtls, eiEvidenceInsertDtls);
      return;
    }

    // BEGIN, CR00021618, NK
    // Check if any new usages have been added to the requirements
    checkUsagesForVerificationRequirements(evidenceDescriptorDtls);
    // END, 225258, AT
    // END, CR00021618

    VDIEDLinkIDAndDataItemIDDetailsList vdIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    vdIEDLinkIDAndDataItemIDDetailsList =
      vdIEDLinkObj.readByEvidenceDescriptorID(evidenceDescriptorKey);

    // BEGIN, CR00386928, RD
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();
    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    final DependentDataItem dependentDataItemObj =
      DependentDataItemFactory.newInstance();
    final curam.verification.sl.infrastructure.entity.intf.Verification verificationObj =
      VerificationFactory.newInstance();
    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();
    VerificationRequirementDtls verificationRequirementDtls;
    VerificationDtlsList verificationDtlsList;
    final VerificationRequirementKey requirementKey =
      new VerificationRequirementKey();
    final VerificationKey verificationKey = new VerificationKey();

    // END, CR00386928

    for (int i = 0; i < vdIEDLinkIDAndDataItemIDDetailsList.dtls
      .size(); i++) {

      vdIEDLinkKey.VDIEDLinkID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(i).vDIEDLinkID;

      itemCount.recordCount = 0;
      itemCount =
        verificationItemProvidedObj.countItemsByVDIEDLinkID(vdIEDLinkKey);

      if (itemCount.recordCount <= 0) {
        continue;
      }

      // Read the list of data items for the evidence type
      verifiableDataItemKey.verifiableDataItemID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(i).verifiableDataItemID;

      // check the data item in verification data item details list
      verifiableDataItemDataItemNameAndIDDetails = verifiableDataItemObj
        .searchDataItemNameAndIDByVerifiableDataItem(verifiableDataItemKey);

      verifiableDataItemDataItemNameAndIDDetailsList.dtls
        .addRef(verifiableDataItemDataItemNameAndIDDetails);

      // BEGIN, CR00021355, NK
      // BEGIN, CR00191839, ND
      if (!checkDataItemInList(evidenceDescriptorDtls.evidenceType,
        eiEvidenceModifyDtls, eiEvidenceReadDtls,
        verifiableDataItemDataItemNameAndIDDetailsList)) {
        // END, CR00191839, ND

        // If data item is not present in verifiable data item list then
        // check
        // the data item in dependent data item.
        verifiableDataItemDataItemNameAndIDDetailsList = dependentDataItemObj
          .searchDataItemNameAndIDByVerifiableDataItem(verifiableDataItemKey);

        // BEGIN, CR00191839, ND
        if (!checkDataItemInList(evidenceDescriptorDtls.evidenceType,
          eiEvidenceModifyDtls, eiEvidenceReadDtls,
          verifiableDataItemDataItemNameAndIDDetailsList)) {
          // END, CR00191839, ND
          // END, CR00021355
          continue;
        }
      }

      // Add data item name to informational message
      if (dataItemAdded == 0) {

        informationalMessage.append(readCodeTableItemDescription(
          verifiableDataItemDataItemNameAndIDDetails.name,
          VERIFIABLEITEMNAME.TABLENAME));
      } else {
        // BEGIN, CR00071077, GM
        informationalMessage.append(
          // BEGIN, CR00163471, JC
          INFORMATIONALMESSAGE.INF_COMMA_SPACE_INFORMATIONAL_DESCRIPTION
            .getMessageText(TransactionInfo.getProgramLocale()));
        // END, CR00163471, JC
        // END, CR00071077

        informationalMessage.append(readCodeTableItemDescription(
          verifiableDataItemDataItemNameAndIDDetails.name,
          VERIFIABLEITEMNAME.TABLENAME));

      }

      dataItemAdded++;

      // BEGIN, CR00021355, NK
      // create value changed workflow event (for each related
      // verification
      // requirement that has an event defined)
      // pass following values to workflow -> (Customer should have access
      // to)
      // (a) Evidence entered
      // (b) the verification requirement
      // (c) the user who made the change
      // (d) the old and new value (list in case of dependent data item)

      verificationDtlsList = verificationObj.readByVDIEDLinkID(vdIEDLinkKey);

      for (int j = 0; j < verificationDtlsList.dtls.size(); j++) {

        // Read VerificationRequirement to check if it has value changed
        // event
        // defined.
        requirementKey.verificationRequirementID =
          verificationDtlsList.dtls.item(j).verificationRequirementID;

        verificationRequirementDtls =
          verificationRequirementObj.read(requirementKey);

        if (verificationRequirementDtls.valueChangedEventType.trim()
          .length() > 0) {

          verificationKey.verificationID =
            verificationDtlsList.dtls.item(j).verificationID;
          raiseEvent(verificationKey,
            verificationRequirementDtls.valueChangedEventType);
        }
      }
      // END, CR00021355
    }

    // BEGIN, CR00021237, NK
    updateDueDate(evidenceDescriptorDtls, eiEvidenceModifyDtls);
    // END, CR00021237

    // Create the informational message for data items which requires
    // verifications
    final CatEntry catEntry =
      ENTVERIFICATIONCONTROLLER.ERR_VERIFICATIONCONTROLLER_MODIFY_IN_EDIT_EVIDENCE_VERIFIABLE_DATA_ITEM_INFORMATIONAL;

    createInformational(catEntry, informationalMessage);

  }

  // BEGIN, CR00021237, NK
  // __________________________________________________________________________
  /**
   * This method updates the due date in verification when the received date
   * is updated in evidence when the due date from is selected as Evidence
   * Received in the verification requirement in the administration.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   */

  public void updateDueDate(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls)
    throws AppException, InformationalException {

    if (!evidenceDescriptorDtls.receivedDate
      .equals(eiEvidenceModifyDtls.descriptor.receivedDate)) {

      // Evidence Descriptor variables
      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evidenceDescriptorDtls.evidenceDescriptorID;

      // verification variables
      VerificationDtlsList verificationDtlsList = new VerificationDtlsList();
      final Verification verificationObj = VerificationFactory.newInstance();
      final curam.verification.sl.infrastructure.impl.Verification verification =
        new curam.verification.sl.infrastructure.impl.Verification();

      // Verification Requirement variables
      final VerificationRequirement verificationRequirement =
        VerificationRequirementFactory.newInstance();
      final VerificationRequirementKey verificationRequirementKey =
        new VerificationRequirementKey();
      SearchDueDaysDueDateFromAndRequirementID dueDaysDueDateFromAndRequirementID =
        new SearchDueDaysDueDateFromAndRequirementID();

      verificationDtlsList =
        verificationObj.searchVerificationRequirementByEvidenceDescriptor(
          evidenceDescriptorKey);

      for (int j = 0; j < verificationDtlsList.dtls.size(); j++) {

        // reads the verification requirement details for the data items
        // list
        verificationRequirementKey.verificationRequirementID =
          verificationDtlsList.dtls.item(j).verificationRequirementID;
        dueDaysDueDateFromAndRequirementID = verificationRequirement
          .readDueDaysDueDateFrom(verificationRequirementKey);

        // updates the due date only if due date from is set to received
        // evidence in verification requirement.
        if (dueDaysDueDateFromAndRequirementID.dueDateFrom
          .equals(VERIFICATIONDUEDATEFROM.RECEIVEDEVIDENCE)) {

          final int dueDays = dueDaysDueDateFromAndRequirementID.dueDays;
          final Date dueDate =
            eiEvidenceModifyDtls.descriptor.receivedDate.addDays(dueDays);

          final ModifyVerificationRequirementDueDateKey modifyVerificationRequirementDueDateKey =
            new ModifyVerificationRequirementDueDateKey();

          modifyVerificationRequirementDueDateKey.verificationID =
            verificationDtlsList.dtls.item(j).verificationID;
          modifyVerificationRequirementDueDateKey.dueDate = dueDate;

          // updates the due date in the verification
          verification.modifyDueDate(modifyVerificationRequirementDueDateKey);
        }
      }
    }
  }

  // END, CR00021237

  // BEGIN, CR00021618, NK
  // ___________________________________________________________________________
  /**
   * This checkUsagesForVerificationRequirements method checks if any new
   * verification requirement usages are defined for the verification
   * requirements, if so, inserts verification records for those usages.
   *
   * The in-edit version heere only inserts if the mode is ALWAYS REVERIFY.
   *
   * @param evidenceDescriptorDtls
   * evidence descriptor details
   */
  @Override
  protected void checkUsagesForVerificationRequirements(
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    final Verification verification = VerificationFactory.newInstance();
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage =
      curam.verification.sl.entity.fact.VerificationRequirementUsageFactory
        .newInstance();

    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseTypeICTypeAndStartDate caseTypeICTypeAndStartDate =
      new CaseTypeICTypeAndStartDate();
    final curam.core.struct.IntegratedCaseTypeStruct integratedCaseTypeStruct =
      new curam.core.struct.IntegratedCaseTypeStruct();

    VerificationRequirementIDStatusDetailsList verificationRequirementIDStatusDetailsList =
      new VerificationRequirementIDStatusDetailsList();

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    ReadReqUsageRelatedItemType readReqUsageRelatedItemType =
      new ReadReqUsageRelatedItemType();
    VerificationRequirementKeyList verificationRequirementKeyList =
      new VerificationRequirementKeyList();

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    final VDIEDLinkKey vdIEDLinkKey = new VDIEDLinkKey();
    VDIEDLinkIDAndDataItemIDDetailsList vdIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    // Read based on vdiedLinkID, verificationLinkedID
    // and verificaitonLinkedType
    final ReadByVDIEDLinkAndVerLinkedIDTypeKey readByVDIEDLinkAndVerLinkedIDTypeKey =
      new ReadByVDIEDLinkAndVerLinkedIDTypeKey();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    CaseTypeCode caseTypeCode;

    // Check for new requirements and usages for Verifiable data item and
    // if new requirements usages have been added then add new verifications
    // for them to the case
    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    vdIEDLinkIDAndDataItemIDDetailsList =
      vdIEDLinkObj.readByEvidenceDescriptorID(evidenceDescriptorKey);

    // BEGIN, CR00076353,AL
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // populate EvidenceDescriptorIDRelatedIDAndEvidenceType
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    // populate evidenceTypeKey
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;

    // Check if Participant Level evidence and participant Evidence
    // Descriptor (i.e. caseID is not set on evidence descriptor)
    final boolean isEvidenceParticpantDataParticipantEDOnly =
      evidenceControllerObj.isNonCaseEDForParticipantEvidence(
        evidenceDescriptorIDRelatedIDAndEvidenceType);
    // BEGIN, CR00371725, AKr
    final boolean isPDCEvidence =
      evidenceControllerObj.isPDCEvidence(evidenceTypeKey);
    boolean isParticipantDataCase = false;

    if (evidenceDescriptorDtls.caseID != 0) {
      caseKey.caseID = evidenceDescriptorDtls.caseID;
      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      if (CASETYPECODEEntry.PARTICIPANTDATACASE.getCode()
        .equals(caseTypeCode.caseTypeCode)) {
        isParticipantDataCase = true;
      }
    }
    if (isEvidenceParticpantDataParticipantEDOnly
      || isPDCEvidence && isParticipantDataCase) {
      // END, CR00371725
      readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedType =
        VERIFICATIONTYPE.NONCASEDATA;
      readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedID =
        evidenceDescriptorDtls.participantID;
      // BEGIN, CR00386292, AKr
      verificationUtilities
        .reverifyParticipantVerificationsOnCase(evidenceDescriptorDtls);
      // END, CR00386292

    } else {
      // BEGIN, CR00349499, ARM

      readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedID =
        evidenceDescriptorDtls.caseID;
      // Set the verificationLinkedType based on the caseType
      // BEGIN, CR00351546, RPB
      // BEGIN, CR00371307, AKr
      readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedType =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00371307
      // END, CR00349499
    }

    for (int i = 0; i < vdIEDLinkIDAndDataItemIDDetailsList.dtls
      .size(); i++) {

      vdIEDLinkKey.VDIEDLinkID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(i).vDIEDLinkID;

      readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID =
        vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(i).vDIEDLinkID;

      verificationRequirementIDStatusDetailsList =
        verification.searchReqIDAndVerStatusByVDIEDLinkIDVerLinkedIDAndType(
          readByVDIEDLinkAndVerLinkedIDTypeKey);

      // It is a product delivery or a integrated case
      // BEGIN, CR00371725, AKr
      if (!(isEvidenceParticpantDataParticipantEDOnly
        || isParticipantDataCase)) {
        // END, CR00371725
        // BEGIN, CR00349499, ARM
        // BEGIN, CR00351546, RPB
        if (caseTypeICTypeAndStartDate.integratedCaseType != null
          && !CuramConst.gkEmpty
            .equals(caseTypeICTypeAndStartDate.integratedCaseType)) {
          // END, CR00351546
          integratedCaseTypeStruct.integratedCaseType =
            caseTypeICTypeAndStartDate.integratedCaseType;
        }
        // Get all requirements for the verifiable data item which are
        // active
        // (not cancelled) for current date
        final VerifiableDataItemIDDateAndRelatedItem verifiableDataItemIDDateAndRelatedItem =
          new VerifiableDataItemIDDateAndRelatedItem();

        verifiableDataItemIDDateAndRelatedItem.recordStatus =
          RECORDSTATUS.CANCELLED;
        verifiableDataItemIDDateAndRelatedItem.date = Date.getCurrentDate();
        verifiableDataItemIDDateAndRelatedItem.verifiableDataItemID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        // BEGIN, CR00074026, BF
        // BEGIN, CR00349499, ARM
        // BEGIN, CR00371307, AKr
        verifiableDataItemIDDateAndRelatedItem.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(caseKey);
        verifiableDataItemIDDateAndRelatedItem.relatedItemID =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00371307
        // END, CR00349499
        // END, CR00074026

        verificationRequirementKeyList = verificationRequirementUsage
          .searchRequirementIDByDataItemIDDateAndRelatedItem(
            verifiableDataItemIDDateAndRelatedItem);
        // END, CR00074026

        // check for each verification requirement, if verification
        // record is
        // present. If not present, insert new record.
        for (int j = 0; j < verificationRequirementKeyList.dtls.size(); j++) {

          boolean recordFound = false;

          for (int k = 0; k < verificationRequirementIDStatusDetailsList.dtls
            .size(); k++) {

            if (verificationRequirementKeyList.dtls.item(
              j).verificationRequirementID == verificationRequirementIDStatusDetailsList.dtls
                .item(k).verificationRequirementID) {

              recordFound = true;
              if (verificationRequirementIDStatusDetailsList.dtls
                .item(k).verificationStatus
                  .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
                isConditionalVerificationResultChanged(
                  verificationRequirementIDStatusDetailsList.dtls
                    .item(k).verificationRequirementID,
                  vdIEDLinkIDAndDataItemIDDetailsList.dtls
                    .item(i).verifiableDataItemID,
                  evidenceDescriptorDtls,
                  readByVDIEDLinkAndVerLinkedIDTypeKey);
              }
              break;
            }
          }

          // if record not found, insert record
          if (!recordFound) {

            final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
              new VerifiableDataItemAndRequirementIDDetails();

            verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
              vdIEDLinkIDAndDataItemIDDetailsList.dtls
                .item(i).verifiableDataItemID;
            verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
              verificationRequirementKeyList.dtls
                .item(j).verificationRequirementID;

            // BEGIN, CR00468469, AP
            final NotFoundIndicator nfIndicator = new NotFoundIndicator();
            final VDIEDLinkDtls vdIEDLinkDtls =
              vdIEDLinkObj.read(nfIndicator, vdIEDLinkKey);

            if (!nfIndicator.isNotFound()) {

              insertVerification(evidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                verificationICTypeAndRelatedItemDetails);
            }
            // END, CR00468469

          }
        }

        final CaseIDAndTypeCodeDetails caseIDAndTypeCodeDetails =
          new CaseIDAndTypeCodeDetails();
        CaseIDAndProductTypeDetailsList caseIDAndProductTypeDetailsList =
          new CaseIDAndProductTypeDetailsList();

        caseIDAndTypeCodeDetails.caseID = evidenceDescriptorDtls.caseID;
        caseIDAndTypeCodeDetails.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

        caseIDAndProductTypeDetailsList = caseHeaderObj
          .searchCaseIDAndProductTypeByIntCaseID(caseIDAndTypeCodeDetails);

        for (int j = 0; j < caseIDAndProductTypeDetailsList.dtls
          .size(); j++) {

          // BEGIN, CR00074026, BF
          // BEGIN, CR00364576, RB
          caseKey.caseID =
            caseIDAndProductTypeDetailsList.dtls.item(j).caseID;
          // END, CR00364576
          caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

          // Read based on vdiedLinkID, verificationLinkedID
          // and verificaitonLinkedType
          readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedID =
            caseKey.caseID;

          // Set the verificationLinkedType based on the caseType
          // BEGIN, CR00349499, ARM
          // BEGIN, CR00371307, AKr
          readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedType =
            verificationUtilities.getRelatedItemID(caseKey).getCode();
          // END, CR00371307
          // END, CR00349499
          readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls.item(i).vDIEDLinkID;

          verificationRequirementIDStatusDetailsList = verification
            .searchReqIDAndVerStatusByVDIEDLinkIDVerLinkedIDAndType(
              readByVDIEDLinkAndVerLinkedIDTypeKey);
          // END, CR00074026

          // change the caseID in evidence descriptor to PD caseID
          // temporarily
          final CaseKey caseID = new CaseKey();

          caseID.key.caseID = evidenceDescriptorDtls.caseID;
          evidenceDescriptorDtls.caseID =
            caseIDAndProductTypeDetailsList.dtls.item(j).caseID;

          readReqUsageRelatedItemType = new ReadReqUsageRelatedItemType();
          readReqUsageRelatedItemType.relatedItemType =
            verificationUtilities.getRelatedItemTypeCode(caseKey);

          // Get all requirements for the verifiable data item which
          // are active
          // (not cancelled) for current date

          verifiableDataItemIDDateAndRelatedItem.relatedItemType =
            readReqUsageRelatedItemType.relatedItemType;
          verifiableDataItemIDDateAndRelatedItem.recordStatus =
            RECORDSTATUS.CANCELLED;
          verifiableDataItemIDDateAndRelatedItem.date = Date.getCurrentDate();
          verifiableDataItemIDDateAndRelatedItem.verifiableDataItemID =
            vdIEDLinkIDAndDataItemIDDetailsList.dtls
              .item(i).verifiableDataItemID;
          // BEGIN, CR00074026, BF
          // BEGIN, CR00349499, ARM
          // BEGIN, CR00371307, AKr
          verifiableDataItemIDDateAndRelatedItem.relatedItemID =
            verificationUtilities.getRelatedItemID(caseKey).getCode();
          // END, CR00371307
          // END, CR00349499
          // END, CR00074026
          verificationRequirementKeyList = verificationRequirementUsage
            .searchRequirementIDByDataItemIDDateAndRelatedItem(
              verifiableDataItemIDDateAndRelatedItem);

          // check for each verification requirement, if verification
          // record is
          // present. If not present, insert new record.
          for (int k = 0; k < verificationRequirementKeyList.dtls
            .size(); k++) {

            boolean recordFound = false;

            // BEGIN, CR00414065, RD
            for (int l =
              0; l < verificationRequirementIDStatusDetailsList.dtls
                .size(); l++) {
              // END, CR00414065

              if (verificationRequirementKeyList.dtls.item(
                k).verificationRequirementID == verificationRequirementIDStatusDetailsList.dtls
                  .item(l).verificationRequirementID) {

                recordFound = true;
                break;
              }
            }

            // if record not found, insert record
            if (!recordFound) {

              final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
                new VerifiableDataItemAndRequirementIDDetails();

              verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
                vdIEDLinkIDAndDataItemIDDetailsList.dtls
                  .item(i).verifiableDataItemID;
              verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
                verificationRequirementKeyList.dtls
                  .item(k).verificationRequirementID;

              // BEGIN, CR00468469, AP
              final NotFoundIndicator notFoundIndicator =
                new NotFoundIndicator();
              final VDIEDLinkDtls vdIEDLinkDtls =
                vdIEDLinkObj.read(notFoundIndicator, vdIEDLinkKey);

              if (!notFoundIndicator.isNotFound()) {
                // BEGIN, CR00414065, RD
                final ListPDClientRoleDetails listPDClientRoleDetails =
                  listCaseMembers(
                    caseIDAndProductTypeDetailsList.dtls.item(j).caseID);

                if (isEvidenceDescriptorRelatedToCaseMember(
                  listPDClientRoleDetails,
                  evidenceDescriptorDtls.participantID)) {
                  insertVerification(evidenceDescriptorDtls,
                    verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                    verificationICTypeAndRelatedItemDetails);
                }
              }
              // END, CR00468469

              // END, CR00414065
            }
          }

          // revert the case id to IC case Id
          evidenceDescriptorDtls.caseID = caseID.key.caseID;
        }
      } else {

        // It is a participant level evidence descriptor
        final VerifiableDataItemIDDateAndRelatedItem verifiableDataItemIDDateAndRelatedItem =
          new VerifiableDataItemIDDateAndRelatedItem();

        verifiableDataItemIDDateAndRelatedItem.relatedItemType =
          NONCASEDATATYPE.PARTICIPANT;
        verifiableDataItemIDDateAndRelatedItem.relatedItemID =
          VERIFICATIONTYPE.NONCASEDATA;
        verifiableDataItemIDDateAndRelatedItem.recordStatus =
          RECORDSTATUS.CANCELLED;
        verifiableDataItemIDDateAndRelatedItem.date = Date.getCurrentDate();
        verifiableDataItemIDDateAndRelatedItem.verifiableDataItemID =
          vdIEDLinkIDAndDataItemIDDetailsList.dtls
            .item(i).verifiableDataItemID;

        verificationRequirementKeyList = verificationRequirementUsage
          .searchRequirementIDByDataItemIDDateAndRelatedItem(
            verifiableDataItemIDDateAndRelatedItem);

        // Check for new verification requirements usages
        for (int j = 0; j < verificationRequirementKeyList.dtls.size(); j++) {

          boolean recordFound = false;

          for (int k = 0; k < verificationRequirementIDStatusDetailsList.dtls
            .size(); k++) {

            if (verificationRequirementKeyList.dtls.item(
              j).verificationRequirementID == verificationRequirementIDStatusDetailsList.dtls
                .item(k).verificationRequirementID) {

              recordFound = true;
              break;
            }
          }

          // if record not found, insert record
          if (!recordFound) {

            final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
              new VerifiableDataItemAndRequirementIDDetails();

            verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
              vdIEDLinkIDAndDataItemIDDetailsList.dtls
                .item(i).verifiableDataItemID;
            verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
              verificationRequirementKeyList.dtls
                .item(j).verificationRequirementID;

            // BEGIN, CR00468469, AP
            final NotFoundIndicator nfIndicator = new NotFoundIndicator();
            final VDIEDLinkDtls vdIEDLinkDtls =
              vdIEDLinkObj.read(nfIndicator, vdIEDLinkKey);

            if (!nfIndicator.isNotFound()) {
              insertVerification(evidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                verificationICTypeAndRelatedItemDetails);
            }
            // END, CR00468469

          }
        }
      }
    }

  }

  // END, CR00021618

  // ___________________________________________________________________________
  /**
   * This insertInEditEvidenceVerification method checks if any new
   * verification requirements are defined for the verifiable data item, if
   * so, inserts the VDIEDLink and Verification records.
   *
   * @param evidenceDescriptorDtls
   * EvidenceDescriptor details
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   * @param eiEvidenceReadDtls
   * previous evidence details
   */
  public void insertInEditEvidenceVerification(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    // VerifiableDataItem variables
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();

    final VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    // Set the verificationLinkedType based on the caseType
    // BEGIN, CR00349499, ARM
    // BEGIN, CR00371307, AKr
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = evidenceDescriptorDtls.caseID;
    verificationICTypeAndRelatedItemDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    verificationICTypeAndRelatedItemDetails.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00349499
    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    // BEGIN, CR00349499, ARM
    evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
      verificationICTypeAndRelatedItemDetails.relatedItemType;
    // END, CR00349499
    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();
    verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);

    for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
      .size(); i++) {

      // Insert VDIEDLink
      insertVDIEDLink(evidenceDescriptorDtls, vdIEDLinkDtls,
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i));

      // Insert Verification
      insertVerification(evidenceDescriptorDtls,
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i),
        vdIEDLinkDtls, verificationICTypeAndRelatedItemDetails);
    }
  }

  // ___________________________________________________________________________
  /**
   * This checkDataItemInList method check the value of corresponding
   * attribute in the custom object.
   *
   * @param evidenceType
   * Evidence type of the record being verified
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   * @param dataItemDetailsList
   * data item details list
   */
  // BEGIN, CR00191839, ND
  protected boolean checkDataItemInList(final String evidenceType,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls,
    final VerifiableDataItemDataItemNameAndIDDetailsList dataItemDetailsList)
    throws AppException, InformationalException {

    boolean dataItemPresent = false;
    boolean fieldEmpty = false;
    boolean prevFieldEmpty = false;

    String dataItem = CuramConst.gkEmpty;

    // For each data item in the list, check the value of the corresponding
    // attribute in the custom object and make sure that it has been
    // populate
    // during the insert before creating a verification for it.
    for (int i = 0; i < dataItemDetailsList.dtls.size(); i++) {

      dataItem = dataItemDetailsList.dtls.item(i).dataItem;
      fieldEmpty = false;

      // BEGIN, CR00213416, GYH
      final VerificationEvidenceInterface evidenceImplObject =
        VerificationEvidenceFactory
          .newInstance(CASEEVIDENCEEntry.get(evidenceType));

      // END, CR00213416

      fieldEmpty = evidenceImplObject.isFieldEmpty(dataItem,
        eiEvidenceModifyDtls.evidenceObject, evidenceType);

      prevFieldEmpty = evidenceImplObject.isFieldEmpty(dataItem,
        eiEvidenceReadDtls.evidenceObject, evidenceType);

      // If both are empty then we don't have to do anything
      // If one of them is empty raise event and display message
      if (!fieldEmpty && prevFieldEmpty || fieldEmpty && !prevFieldEmpty) {

        dataItemPresent = true;
        break;
      } // If both are not empty and values are different then raise event
      // and display message
      else if (!fieldEmpty && !prevFieldEmpty) {

        if (evidenceImplObject.compareFields(dataItem,
          eiEvidenceModifyDtls.evidenceObject,
          eiEvidenceReadDtls.evidenceObject, evidenceType)) {

          dataItemPresent = true;
          break;
        }
      }
    }

    return dataItemPresent;
  }

  // END, CR00191839, ND

  // ___________________________________________________________________________
  /**
   * This checkDataItemInList method check the value of corresponding
   * attribute in the custom object.
   *
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   * @param eiEvidenceReadDtls
   * EIEvidence read details
   * @param dataItemDetailsList
   * data item details list
   *
   * @return true if the value matches
   *
   * @deprecated Since Curam 6.0, This method operates only on static
   * evidence. Not part of the {@link VerificationInterface} and
   * should really be a private method as it contains logic
   * internal to this class.
   */
  @Deprecated
  public boolean checkDataItemInList(
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls,
    final VerifiableDataItemDataItemNameAndIDDetailsList dataItemDetailsList)
    throws AppException, InformationalException {

    boolean dataItemPresent = false;
    boolean fieldEmpty = false;
    boolean prevFieldEmpty = false;

    // BEGIN, CR00071012, GM
    String dataItem = CuramConst.gkEmpty;

    // END, CR00071012

    // For each data item in the list, check the value of the corresponding
    // attribute in the custom object and make sure that it has been
    // populate
    // during the insert before creating a verification for it.
    for (int i = 0; i < dataItemDetailsList.dtls.size(); i++) {

      dataItem = dataItemDetailsList.dtls.item(i).dataItem;
      fieldEmpty = false;

      try {

        final Field fl = eiEvidenceModifyDtls.evidenceObject.getClass()
          .getDeclaredField(dataItem);

        fieldEmpty = isFieldEmpty(fl, eiEvidenceModifyDtls.evidenceObject);

        // BEGIN, CR00021355, NK
        prevFieldEmpty = isFieldEmpty(fl, eiEvidenceReadDtls.evidenceObject);

        // If both are empty then we don't have to do anything
        // If one of them is empty raise event and display message
        if (!fieldEmpty && prevFieldEmpty || fieldEmpty && !prevFieldEmpty) {

          dataItemPresent = true;
          break;
        } // If both are not empty and values are different then raise
        // event
        // and display message
        else if (!fieldEmpty && !prevFieldEmpty) {

          if (compareFields(fl, eiEvidenceModifyDtls.evidenceObject,
            eiEvidenceReadDtls.evidenceObject)) {

            dataItemPresent = true;
            break;
          }
        }
        // END, CR00021355
      } catch (final NoSuchFieldException e) {// do nothing
      } catch (final IllegalArgumentException e) {// do nothing
      }
    }

    return dataItemPresent;

  }

  // ___________________________________________________________________________
  /**
   * This processActiveEvidenceVerification method process active evidence
   * verification and inserts the new verification for the new in edit
   * evidence.
   *
   * @param newEvidenceDescriptorDtls
   * The details of the evidence
   * @param eiEvidenceModifyDtls
   * EIEvidence modified details
   * @param eiEvidenceReadDtls
   * previous evidence details
   */
  public void processActiveEvidenceVerification(
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    // Creates new In Edit evidence Record - create new verification record
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();

    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    final VerifiableDataItemEvidenceTypeAndStatus verifiableDataItemEvidenceTypeAndStatus =
      new VerifiableDataItemEvidenceTypeAndStatus();

    final VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    final VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();

    // BEGIN, CR00022902, KY
    ReverificationModeRequirementIDDetailsList reverificationModeRequirementIDDetailsList =
      new ReverificationModeRequirementIDDetailsList();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();

    final DataItemRelatedItemAndStatusDetails dataItemRelatedItemAndStatusDetails =
      new DataItemRelatedItemAndStatusDetails();

    // BEGIN, CR00191839, ND
    // BEGIN, CR00213416, GYH
    final VerificationEvidenceInterface verificationEvidenceImpl =
      VerificationEvidenceFactory.newInstance(
        CASEEVIDENCEEntry.get(newEvidenceDescriptorDtls.evidenceType));
    // END, CR00213416
    // END, CR00191839, ND

    // BEGIN, CR00071012, GM
    String reverificationMode = CuramConst.gkEmpty;
    String dataItem = CuramConst.gkEmpty;
    // END, CR00071012
    boolean dataItemChanged = false;
    boolean dependentDataItemChanged = false;
    int dataItemAdded = 0;
    final StringBuffer informationalMessage = new StringBuffer();

    // END, CR00022902

    verifiableDataItemEvidenceTypeAndStatus.evidenceType =
      newEvidenceDescriptorDtls.evidenceType;
    verifiableDataItemEvidenceTypeAndStatus.recordStatus =
      RECORDSTATUS.NORMAL;

    // BEGIN, CR00074026, BF
    // BEGIN, CR00350929, ARM
    // BEGIN, CR00371307, AKr
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = newEvidenceDescriptorDtls.caseID;
    verificationICTypeAndRelatedItemDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    verificationICTypeAndRelatedItemDetails.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00350929
    // END, CR00074026
    // BEGIN, CR00022902, KY
    // Read the list of data items which has requirements for the evidence
    // type
    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      newEvidenceDescriptorDtls.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();

    // if the case type is Product Delivery, then read the product type to
    // fetch the data items which has requirements for the evidence type
    evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);

    // END, CR00022902

    verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);

    // BEGIN, CR00386928, RD
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
      new VerifiableDataItemAndRequirementIDDetails();
    final DataItemIDAndDescriptorDetails dataItemIDAndDescriptorDetails =
      new DataItemIDAndDescriptorDetails();
    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDependentDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();
    final DependentDataItem dependentDataItemObj =
      DependentDataItemFactory.newInstance();

    // END, CR00386908

    for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
      .size(); i++) {

      dataItem =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).dataItem;
      final Long verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      // BEGIN, CR00191839, ND
      if (!dataItemExists(dataItem, eiEvidenceModifyDtls.evidenceObject,
        newEvidenceDescriptorDtls.evidenceType)) {
        continue;
      }
      // END, CR00191839, ND

      verifiableDataItemKey.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      dataItemRelatedItemAndStatusDetails.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      // BEGIN, CR00022902, KY
      // BEGIN, CR00350929, ARM
      // BEGIN, CR00371307, AKr
      dataItemRelatedItemAndStatusDetails.relatedItemType =
        evidenceTypeAndRelatedItemTypeDetails.relatedItemType;
      dataItemRelatedItemAndStatusDetails.relatedItemID =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00371307
      // END, CR00350929
      // END, CR00022902
      // END, CR00074026
      dataItemRelatedItemAndStatusDetails.recordStatus =
        RECORDSTATUS.CANCELLED;

      reverificationModeRequirementIDDetailsList = verificationRequirementObj
        .searchAllByVerifiableDataItemID(dataItemRelatedItemAndStatusDetails);

      verifiableDataItemDataItemNameAndIDDetails =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i);

      boolean verifyDataItem = false;

      verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      // Insert VDIEDLink
      boolean isVdiedLinkInserted = false;

      // BEGIN, CR00364576, RB
      // check if a VDI/ED Link already exists for the verifiable data
      // item
      dataItemIDAndDescriptorDetails.evidenceDescriptorID =
        newEvidenceDescriptorDtls.evidenceDescriptorID;
      dataItemIDAndDescriptorDetails.verifiableDataItemID =
        verifiableDataItemAndRequirementIDDetails.verifiableDataItemID;
      VDIEDLinkDtls retrivedVdiedLinkDtls = null;

      try {
        retrivedVdiedLinkDtls = VDIEDLinkFactory.newInstance()
          .readVDIEDLinkDtlsByDataItemAndDescriptorID(
            dataItemIDAndDescriptorDetails);

        // use the existing link rather than creating a new one
        vdIEDLinkDtls.assign(retrivedVdiedLinkDtls);

        // a link has already been inserted
        isVdiedLinkInserted = true;
      } catch (final RecordNotFoundException e) {// ignore
      }
      // END, CR00364576

      for (int j = 0; j < reverificationModeRequirementIDDetailsList.dtls
        .size(); j++) {

        final ReverificationModeRequirementIDDetails reverificationModeRequirementIDDetails =
          reverificationModeRequirementIDDetailsList.dtls.item(j);

        final ConditionalVerificationResultFetcherInputDtls conditionalVerificationResultFetcherInputDtls =
          new ConditionalVerificationResultFetcherInputDtls();

        conditionalVerificationResultFetcherInputDtls.evidenceDescriptorID =
          newEvidenceDescriptorDtls.evidenceDescriptorID;
        conditionalVerificationResultFetcherInputDtls.verifiableDataItemID =
          verifiableDataItemID;
        conditionalVerificationResultFetcherInputDtls.verificationRequirementID =
          reverificationModeRequirementIDDetails.verificationRequirementID;
        final NotFoundIndicator conditionalVerificationResultNFInd =
          new NotFoundIndicator();

        final ConditionalVerificationResultFetcherDtls conditionalVerificationResultDtls =
          ConditionalVerificationResultFactory.newInstance().readResult(
            conditionalVerificationResultNFInd,
            conditionalVerificationResultFetcherInputDtls);

        final boolean conditionalVerificationApplicable =
          isConditionalVerificationApplicable(
            reverificationModeRequirementIDDetails.verificationRequirementID,
            verifiableDataItemID, newEvidenceDescriptorDtls);

        if (!conditionalVerificationApplicable) {
          checkUsagesForVerificationRequirements(newEvidenceDescriptorDtls);

          continue;
        }

        final boolean hasExistingVerification = hasExistingVerification(
          eiEvidenceReadDtls, verifiableDataItemAndRequirementIDDetails);

        reverificationMode = reverificationModeRequirementIDDetailsList.dtls
          .item(j).reverificationMode;
        verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
          reverificationModeRequirementIDDetailsList.dtls
            .item(j).verificationRequirementID;

        if (reverificationMode.equals(REVERIFICATIONMODE.NEVERREVERIFY)) {

          boolean isDuplicateInsertionAllowed = true;

          if (Configuration.getBooleanProperty(
            EnvVars.ENV_PREVENTING_DUPLICATE_VERIFICATION_INSERTION)) {
            isDuplicateInsertionAllowed =
              !isDuplicateVerification(newEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);
          }

          if (isDuplicateInsertionAllowed) {
            // BEGIN, RTC227254, AT
            if (hasExistingVerification) {
              if (!isVdiedLinkInserted) {
                insertVDIEDLinkRecord(newEvidenceDescriptorDtls,
                  vdIEDLinkDtls, verifiableDataItemDataItemNameAndIDDetails);
                isVdiedLinkInserted = true;
              }
              cloneExistingVerification(newEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, eiEvidenceReadDtls,
                vdIEDLinkDtls);
            } else {
              if (!isVdiedLinkInserted) {
                insertVDIEDLinkRecord(newEvidenceDescriptorDtls,
                  vdIEDLinkDtls, verifiableDataItemDataItemNameAndIDDetails);
                isVdiedLinkInserted = true;
              }
              insertVerification(newEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                verificationICTypeAndRelatedItemDetails);
            }
            // END, RTC227254, AT

          }
        } else if (reverificationMode
          .equals(REVERIFICATIONMODE.REVERIFYALWAYS)) {
          // BEGIN, CR00386928, SSK
          boolean isDuplicateInsertionAllowed = true;

          // Insert Verification

          if (Configuration.getBooleanProperty(
            EnvVars.ENV_PREVENTING_DUPLICATE_VERIFICATION_INSERTION)) {
            isDuplicateInsertionAllowed =
              !isDuplicateVerification(newEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);
          }
          if (isDuplicateInsertionAllowed) {
            if (!isVdiedLinkInserted) {
              insertVDIEDLinkRecord(newEvidenceDescriptorDtls, vdIEDLinkDtls,
                verifiableDataItemDataItemNameAndIDDetails);
              isVdiedLinkInserted = true;
            }
            insertVerification(newEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
              verificationICTypeAndRelatedItemDetails);

            // BEGIN, CR00364576, RB
            final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

            vdiedLinkKey.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;
            curam.verification.sl.infrastructure.fact.VerificationFactory
              .newInstance()
              .determineVerificationStatusForRemoveAndView(vdiedLinkKey);
            // END CR00364576

            verifyDataItem = true;
          }

          // END, CR00386928
        } else {

          // Check if a value has been modified
          dependentDataItemChanged = false;

          dataItem = verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).dataItem;

          // BEGIN, CR00191839, ND
          dataItemChanged = verificationEvidenceImpl
            .checkDataItemValueChanged(dataItem, eiEvidenceModifyDtls,
              eiEvidenceReadDtls, newEvidenceDescriptorDtls.evidenceType);
          // END, CR00191839, ND

          if (!dataItemChanged) {

            // Get all dependent data items by verifiable data item
            verifiableDependentDataItemDataItemNameAndIDDetailsList =
              dependentDataItemObj
                .searchDataItemNameAndIDByVerifiableDataItem(
                  verifiableDataItemKey);

            for (int k =
              0; k < verifiableDependentDataItemDataItemNameAndIDDetailsList.dtls
                .size(); k++) {

              dataItem =
                verifiableDependentDataItemDataItemNameAndIDDetailsList.dtls
                  .item(k).dataItem;

              // BEGIN, CR00191839, ND
              dataItemChanged = verificationEvidenceImpl
                .checkDataItemValueChanged(dataItem, eiEvidenceModifyDtls,
                  eiEvidenceReadDtls, newEvidenceDescriptorDtls.evidenceType);
              // END, CR00191839, ND

              if (dataItemChanged) {
                dependentDataItemChanged = true;
              }
            }
          }

          if (dataItemChanged || dependentDataItemChanged) {

            // BEGIN, CR00021355, NK
            // Insert Verification
            if (!isVdiedLinkInserted) {
              insertVDIEDLinkRecord(newEvidenceDescriptorDtls, vdIEDLinkDtls,
                verifiableDataItemDataItemNameAndIDDetails);
              isVdiedLinkInserted = true;
            }
            insertVerification(newEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
              verificationICTypeAndRelatedItemDetails);
            // END, CR00021355
            verifyDataItem = true;
          } else // Check if its called from dependency manager, the trigger is
          // not the actual evidence change but
          // some other precedent for the conditional verification.
          if (newEvidenceDescriptorDtls.evidenceDescriptorID == eiEvidenceReadDtls.descriptor.evidenceDescriptorID) {
            if (!conditionalVerificationResultNFInd.isNotFound()
              && !conditionalVerificationResultDtls.verificationResult) {

              // BEGIN, RTC 252460, AT
              boolean isDuplicateInsertionAllowed = true;
              if (Configuration.getBooleanProperty(
                EnvVars.ENV_PREVENTING_DUPLICATE_VERIFICATION_INSERTION)) {
                isDuplicateInsertionAllowed =
                  !isDuplicateVerification(newEvidenceDescriptorDtls,
                    verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);
              }
              if (isDuplicateInsertionAllowed) {
                if (!isVdiedLinkInserted) {
                  insertVDIEDLinkRecord(newEvidenceDescriptorDtls,
                    vdIEDLinkDtls,
                    verifiableDataItemDataItemNameAndIDDetails);
                  isVdiedLinkInserted = true;
                }
                insertVerification(newEvidenceDescriptorDtls,
                  verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                  verificationICTypeAndRelatedItemDetails);
                verifyDataItem = true;
              }
              // END, RTC 252460, AT
            } else {
              // It means this is a new verification configuration, ignore it
              // when invoked from

              // dependency manager.
              continue;
            }
          } else {
            // BEGIN, RTC227254, AT
            boolean isDuplicateInsertionAllowedOrNotApplicable = true;

            if (Configuration.getBooleanProperty(
              EnvVars.ENV_PREVENTING_DUPLICATE_VERIFICATION_INSERTION)) {
              isDuplicateInsertionAllowedOrNotApplicable =
                !isDuplicateVerification(newEvidenceDescriptorDtls,
                  verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);
            }

            if (isDuplicateInsertionAllowedOrNotApplicable) {

              // True only if there are conditional rules and they
              // return true or if there are no conditional rules configured.
              final boolean isConditionalResultTrueOrNotApplicable =
                isConditionalVerificationResultTrueOrNotApplicable(
                  reverificationModeRequirementIDDetails.verificationRequirementID,
                  verifiableDataItemID, newEvidenceDescriptorDtls);

              // True if either conditional result is false or there are no
              // conditional rules configured.
              final boolean isConditionalResultFalseOrNotApplicable =
                isConditionalVerificationApplicable(
                  reverificationModeRequirementIDDetails.verificationRequirementID,
                  verifiableDataItemID, newEvidenceDescriptorDtls);

              /*
               * We get here when it is reverify if changed but there is no
               * change to data item or dependent data item.
               * The logic below determines whether to clone the existing
               * verification if there is one, insert a new one, or do nothing.
               */
              if (hasExistingVerification) {

                if (isConditionalResultFalseOrNotApplicable) {
                  if (!isVdiedLinkInserted) {

                    insertVDIEDLinkRecord(newEvidenceDescriptorDtls,
                      vdIEDLinkDtls,
                      verifiableDataItemDataItemNameAndIDDetails);
                    isVdiedLinkInserted = true;

                  }

                  cloneExistingVerification(newEvidenceDescriptorDtls,
                    verifiableDataItemAndRequirementIDDetails,
                    eiEvidenceReadDtls, vdIEDLinkDtls);
                }
              } else if (isConditionalResultTrueOrNotApplicable) {

                if (!isVdiedLinkInserted) {

                  insertVDIEDLinkRecord(newEvidenceDescriptorDtls,
                    vdIEDLinkDtls,
                    verifiableDataItemDataItemNameAndIDDetails);
                  isVdiedLinkInserted = true;

                }
                insertVerification(newEvidenceDescriptorDtls,
                  verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                  verificationICTypeAndRelatedItemDetails);
              }

            }
            // END, RTC227254, AT
          }
        }
      }
      if (verifyDataItem) {

        // Add data item name to informational message
        if (dataItemAdded != 0) {
          // BEGIN, CR00071077, GM
          informationalMessage.append(
            // BEGIN, CR00163471, JC
            INFORMATIONALMESSAGE.INF_COMMA_SPACE_INFORMATIONAL_DESCRIPTION
              .getMessageText(TransactionInfo.getProgramLocale()));
          // END, CR00163471, JC
          // END, CR00071077
        }
        informationalMessage.append(readCodeTableItemDescription(
          verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).name,
          VERIFIABLEITEMNAME.TABLENAME));

        dataItemAdded++;
      }
    }

    // BEGIN, WI179814, YF
    // Call check usages method only if a verifiable data item has been changed
    if (dataItemChanged || dependentDataItemChanged)

    {
      // BEGIN, CR00364576, RB
      checkUsagesForVerificationRequirements(newEvidenceDescriptorDtls);
      // END, CR00364576
    }
    // END, WI179814, YF

    // Create the informational message for data items which requires
    // verifications
    final curam.util.message.CatEntry catEntry =
      ENTVERIFICATIONCONTROLLER.ERR_VERIFICATIONCONTROLLER_MODIFY_IN_EDIT_EVIDENCE_VERIFIABLE_DATA_ITEM_INFORMATIONAL;

    createInformational(catEntry, informationalMessage);
  }

  protected boolean hasExistingVerification(
    final EIEvidenceReadDtls eiEvidenceReadDtls,
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails) {

    boolean hasExistingVerification = false;

    try {

      final DataItemIDAndDescriptorDetails descriptor =
        new DataItemIDAndDescriptorDetails();
      descriptor.evidenceDescriptorID =
        eiEvidenceReadDtls.descriptor.evidenceDescriptorID;
      descriptor.verifiableDataItemID =
        verifiableDataItemAndRequirementIDDetails.verifiableDataItemID;
      final VDIEDLinkDtls dtls = VDIEDLinkFactory.newInstance()
        .readVDIEDLinkDtlsByDataItemAndDescriptorID(descriptor);
      final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();
      vdiedLinkKey.VDIEDLinkID = dtls.VDIEDLinkID;
      final VerificationDtlsList verificationDtlsList =
        VerificationFactory.newInstance().readByVDIEDLinkID(vdiedLinkKey);
      if (!verificationDtlsList.dtls.isEmpty()) {
        hasExistingVerification = true;
      }
    } catch (final Exception e) {
      hasExistingVerification = false;
    }
    return hasExistingVerification;
  }

  boolean insertVDIEDLinkRecord(
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final VDIEDLinkDtls vdIEDLinkDtls,
    final VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails)
    throws AppException, InformationalException {

    insertVDIEDLink(newEvidenceDescriptorDtls, vdIEDLinkDtls,
      verifiableDataItemDataItemNameAndIDDetails);
    return true;
  }

  // BEGIN, CR 3140, RK
  // ___________________________________________________________________________
  /**
   * This raiseEvent method raises the verification item utilization
   * expiration event.
   *
   * @param utlizationExpiryWarningAndDateFrom
   * verification item utilization expiry and warning date details.
   * @param verificationItemProvidedKey
   * The verification details
   */
  public void raiseEvents(
    final UtlizationExpiryWarningAndDateFrom utlizationExpiryWarningAndDateFrom,
    final VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {

    final List<Object> enactmentStruct = new ArrayList<Object>();
    final VerificationItemUtilizationKey verificationItemUtilizationKey =
      new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID =
      utlizationExpiryWarningAndDateFrom.verificationItemUtilizationID;

    enactmentStruct.add(verificationItemUtilizationKey);
    enactmentStruct.add(verificationItemProvidedKey);

    EnactmentService.startProcess(
      VerificationConst.gkVerificationItemUtilization, enactmentStruct);
  }

  // END, CR 3140

  // BEGIN, CR 3140, RK
  // ___________________________________________________________________________
  /**
   * This checkExpiryAndWarningForVerification method checks the verification
   * item expiry and warning date.
   *
   * @param vDIEDLinkKey
   * VDIED link details.
   *
   * @return The list of warnings
   */
  public UtlizationExpiryWarningAndDateFromList
    checkExpiryAndWarningForVerification(final VDIEDLinkKey vDIEDLinkKey)
      throws AppException, InformationalException {

    final VerificationItemUtilization verificationItemUtilization =
      VerificationItemUtilizationFactory.newInstance();
    final Verification verification = VerificationFactory.newInstance();

    UtlizationExpiryWarningAndDateFromList utlizationExpiryWarningAndDateFromList =
      new UtlizationExpiryWarningAndDateFromList();

    // Verification requirement variables
    final VerificationRequirement verificationrequirement =
      VerificationRequirementFactory.newInstance();

    VerificationRequirementIDDetailsList verificationRequirementIDDetailsList =
      new VerificationRequirementIDDetailsList();

    verificationRequirementIDDetailsList =
      verification.readAllVerificationRequirementsByVDIEDLink(vDIEDLinkKey);

    for (int i = 0; i < verificationRequirementIDDetailsList.dtls
      .size(); i++) {

      final VerificationRequirementIDAndStatusKey verificationRequirementIDAndStatusKey =
        new VerificationRequirementIDAndStatusKey();

      verificationRequirementIDAndStatusKey.verificationRequirementID =
        verificationRequirementIDDetailsList.dtls
          .item(i).verificationRequirementID;

      verificationRequirementIDAndStatusKey.recordStatus =
        RECORDSTATUS.CANCELLED;

      final VerificationRequirementLevelMandatoryAndDatesDetails reqtLevelMandatoryAndDatesDetails =
        verificationrequirement.readLevelFromDateTodateAndMandatory(
          verificationRequirementIDAndStatusKey);

      utlizationExpiryWarningAndDateFromList = verificationItemUtilization
        .readUtilDetailsByReqDetails(reqtLevelMandatoryAndDatesDetails);

    }

    return utlizationExpiryWarningAndDateFromList;
  }

  // END, CR 3140

  // ___________________________________________________________________________
  /**
   * This cloneExistingVerification method clones the existing verification.
   *
   * @param newEvidenceDescriptorDtls
   * new evidence details
   * @param verifiableDataItemRequirementIDDetails
   * verifiable data item requirement ID details
   * @param eiEvidenceReadDtls
   * previous evidence details
   * @param vdIEDLinkDtls
   * VDIED link details.
   */
  public void cloneExistingVerification(
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemRequirementIDDetails,
    final EIEvidenceReadDtls eiEvidenceReadDtls,
    final VDIEDLinkDtls vdIEDLinkDtls)
    throws AppException, InformationalException {

    final Verification verificationObj = VerificationFactory.newInstance();
    final VerificationDtls verificationDtls = new VerificationDtls();

    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID =
      verifiableDataItemRequirementIDDetails.verifiableDataItemID;

    VDIEDLinkDtls vdIEDLinkCloneDtls = new VDIEDLinkDtls();

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    boolean isEvidenceParticipantData = false;
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = newEvidenceDescriptorDtls.evidenceType;

    isEvidenceParticipantData =
      evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);

    // If this is participant evidence read the evidence descriptor
    // ID from the evidence descriptor. If it is temporal evidence
    // read it from the readDetails struct
    if (isEvidenceParticipantData) {
      final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();

      final DataItemIDAndDescriptorDetails dataItemIDAndDescriptorDetails =
        new DataItemIDAndDescriptorDetails();

      dataItemIDAndDescriptorDetails.evidenceDescriptorID =
        newEvidenceDescriptorDtls.evidenceDescriptorID;
      dataItemIDAndDescriptorDetails.verifiableDataItemID =
        verifiableDataItemKey.verifiableDataItemID;

      vdIEDLinkCloneDtls =
        vdIEDLinkObj.readVDIEDLinkDtlsByDataItemAndDescriptorID(
          dataItemIDAndDescriptorDetails);
    } else {
      vdIEDLinkCloneDtls =
        readVDIEDCloneDetails(verifiableDataItemKey, eiEvidenceReadDtls);
    }

    // Assign the VDIED link details
    VerificationDtls verificationClonedDtls = new VerificationDtls();

    final VDIEDLinkIDRequirementIDAndCaseIDDetails vdIEDLinkIDRequirementIDAndCaseIDDetails =
      new VDIEDLinkIDRequirementIDAndCaseIDDetails();

    vdIEDLinkIDRequirementIDAndCaseIDDetails.VDIEDLinkID =
      vdIEDLinkCloneDtls.VDIEDLinkID;
    vdIEDLinkIDRequirementIDAndCaseIDDetails.caseID =
      newEvidenceDescriptorDtls.caseID;
    vdIEDLinkIDRequirementIDAndCaseIDDetails.verificationRequirementID =
      verifiableDataItemRequirementIDDetails.verificationRequirementID;

    if (evidenceControllerObj.isPDCEvidence(evidenceTypeKey)) {
      verificationClonedDtls = readVerificationCloneDetailsForPDCEvidence(
        newEvidenceDescriptorDtls.participantID,
        vdIEDLinkIDRequirementIDAndCaseIDDetails);
    } else {
      verificationClonedDtls = readVerificationCloneDetails(
        vdIEDLinkIDRequirementIDAndCaseIDDetails);

    }

    // BEGIN, CR00074026, BF
    // To get the caseID of the verification entity we have to ensure that
    // the linkedType is of type CASE and not Participant. This method
    // BEGIN, CR00350929, ARM
    if (!verificationClonedDtls.verificationLinkedType
      .equals(VERIFICATIONTYPE.NONCASEDATA)) {
      verificationDtls.verificationLinkedID =
        newEvidenceDescriptorDtls.caseID;
    }
    // END, CR00350929
    // END, CR00074026

    verificationDtls.assign(verificationClonedDtls);
    verificationDtls.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;
    verificationDtls.dueDate = verificationClonedDtls.dueDate;

    verificationObj.insert(verificationDtls);

    // Assign verification item provided details to new record
    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();
    VerificationItemProvidedDtls verificationItemProvidedDtls =
      new VerificationItemProvidedDtls();

    VerificationItemProvidedDtlsList verificationItemProvidedClonedDtlsList =
      new VerificationItemProvidedDtlsList();

    final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
      new VDIEDLinkIDAndStatusKey();

    vDIEDLinkIDAndStatusKey.VDIEDLinkID = vdIEDLinkCloneDtls.VDIEDLinkID;
    vDIEDLinkIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    verificationItemProvidedClonedDtlsList = verificationItemProvided
      .searchByVDIEDLinkIDAndStatus(vDIEDLinkIDAndStatusKey);

    // iterate through each of the record and clone it
    for (int i = 0; i < verificationItemProvidedClonedDtlsList.dtls
      .size(); i++) {

      verificationItemProvidedDtls =
        verificationItemProvidedClonedDtlsList.dtls.item(i);

      // We may already have done this if the requirement is configured against
      // more than one case
      if (hasVerificationItemProvidedDetailsBeenCloned(
        vdIEDLinkDtls.VDIEDLinkID,
        verificationItemProvidedDtls.verificationItemUtilizationID)) {
        continue;
      }

      // insert cloned VDIEDLinkID attribute value, other values remain
      // same
      verificationItemProvidedDtls.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;

      final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey2 =
        new VDIEDLinkIDAndStatusKey();

      vDIEDLinkIDAndStatusKey2.VDIEDLinkID = vdIEDLinkCloneDtls.VDIEDLinkID;
      vDIEDLinkIDAndStatusKey2.recordStatus = RECORDSTATUS.NORMAL;

      verificationItemProvided.insert(verificationItemProvidedDtls);
    }

  }

  private boolean hasVerificationItemProvidedDetailsBeenCloned(
    final long vdiedLinkID, final long verificationItemUtilizationID)
    throws AppException, InformationalException {

    final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
      new VDIEDLinkIDAndStatusKey();

    vDIEDLinkIDAndStatusKey.VDIEDLinkID = vdiedLinkID;
    vDIEDLinkIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    final VerificationItemProvidedDtlsList verificationItemProvidedClonedDtlsList =
      VerificationItemProvidedFactory.newInstance()
        .searchByVDIEDLinkIDAndStatus(vDIEDLinkIDAndStatusKey);

    for (final VerificationItemProvidedDtls dtls : verificationItemProvidedClonedDtlsList.dtls) {
      if (dtls.verificationItemUtilizationID == verificationItemUtilizationID) {
        return true;
      }
    }
    return false;
  }

  // ___________________________________________________________________________
  /**
   * This readVDIEDCloneDetails method read VDIEDLink details to clone.
   *
   * @param verifiableDataItemKey
   * verifiable data item key
   * @param eiEvidenceReadDtls
   * previous evidence details
   *
   * @return The VDIEDLink details
   */
  public VDIEDLinkDtls readVDIEDCloneDetails(
    final VerifiableDataItemKey verifiableDataItemKey,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    VDIEDLinkDtls dtls = new VDIEDLinkDtls();

    final DataItemIDAndDescriptorDetails dataItemIDAndDescriptorDetails =
      new DataItemIDAndDescriptorDetails();

    dataItemIDAndDescriptorDetails.evidenceDescriptorID =
      eiEvidenceReadDtls.descriptor.evidenceDescriptorID;
    dataItemIDAndDescriptorDetails.verifiableDataItemID =
      verifiableDataItemKey.verifiableDataItemID;

    dtls = vdIEDLinkObj.readVDIEDLinkDtlsByDataItemAndDescriptorID(
      dataItemIDAndDescriptorDetails);

    return dtls;
  }

  // ___________________________________________________________________________

  /**
   * This readVerificationCloneDetails method clones the Verification details
   * for PDC evidence.
   *
   * @param participantID long
   * @param vdIEDLinkIDRequirementIDAndCaseIDDetails
   * VDIEDLink and case id details
   *
   * @return The Verification details.
   */
  private VerificationDtls readVerificationCloneDetailsForPDCEvidence(
    final long participantID,
    final VDIEDLinkIDRequirementIDAndCaseIDDetails vdIEDLinkIDRequirementIDAndCaseIDDetails)
    throws AppException, InformationalException {

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    caseKey.caseID = vdIEDLinkIDRequirementIDAndCaseIDDetails.caseID;
    final String verificationLinkType =
      verificationUtilities.getRelatedItemID(caseKey).getCode();

    vdIEDLinkIDRequirementIDAndCaseIDDetails.caseID = participantID;

    return readVerificationCloneDetails(verificationLinkType,
      vdIEDLinkIDRequirementIDAndCaseIDDetails);

  }

  /**
   * This readVerificationCloneDetails method clones the Verification details.
   *
   * @param vdIEDLinkIDRequirementIDAndCaseIDDetails
   * VDIEDLink and case id details
   *
   * @return The Verification details.
   */
  public VerificationDtls readVerificationCloneDetails(
    final VDIEDLinkIDRequirementIDAndCaseIDDetails vdIEDLinkIDRequirementIDAndCaseIDDetails)
    throws AppException, InformationalException {

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
    caseKey.caseID = vdIEDLinkIDRequirementIDAndCaseIDDetails.caseID;
    final String verificationLinkType =
      verificationUtilities.getRelatedItemID(caseKey).getCode();

    return readVerificationCloneDetails(verificationLinkType,
      vdIEDLinkIDRequirementIDAndCaseIDDetails);

  }

  /**
   * This readVerificationCloneDetails method clones the Verification details.
   *
   * @param verificationLinkType String
   * @param vdIEDLinkIDRequirementIDAndCaseIDDetails
   * VDIEDLink and case id details
   *
   * @return The Verification details.
   */
  private VerificationDtls readVerificationCloneDetails(
    final String verificationLinkType,
    final VDIEDLinkIDRequirementIDAndCaseIDDetails vdIEDLinkIDRequirementIDAndCaseIDDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00074026, BF
    final ReadByVDIEDLinkIDReqIDVerLinkIDandType readByVDIEDLinkIDReqIDVerLinkIDandType =
      new ReadByVDIEDLinkIDReqIDVerLinkIDandType();

    readByVDIEDLinkIDReqIDVerLinkIDandType.VDIEDLinkID =
      vdIEDLinkIDRequirementIDAndCaseIDDetails.VDIEDLinkID;
    readByVDIEDLinkIDReqIDVerLinkIDandType.verificationRequirementID =
      vdIEDLinkIDRequirementIDAndCaseIDDetails.verificationRequirementID;
    readByVDIEDLinkIDReqIDVerLinkIDandType.verificationLinkedType =
      verificationLinkType;
    readByVDIEDLinkIDReqIDVerLinkIDandType.verificationLinkedID =
      vdIEDLinkIDRequirementIDAndCaseIDDetails.caseID;

    return VerificationFactory.newInstance()
      .readVerificationDetails(readByVDIEDLinkIDReqIDVerLinkIDandType);
    // END, CR00074026

  }

  // ___________________________________________________________________________
  /**
   * This checkDataItemValueChanged method check the value of verifiable data
   * item with the previous value.
   *
   * @param dataItem
   * The data item
   * @param eiEvidenceModifyDtls
   * EIEvidence modify details
   * @param eiEvidenceReadDtls
   * EIEvidence read details
   *
   * @return true if the item is verified
   *
   * @deprecated Since Curam 6.0, Replaced with
   * {@link VerificationEvidenceInterface#checkDataItemValueChanged(String, EIEvidenceModifyDtls, EIEvidenceReadDtls, String)}
   * . This method operates on static evidence only.
   */
  @Deprecated
  public boolean checkDataItemValueChanged(final String dataItem,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    try {

      final Field fl = eiEvidenceModifyDtls.evidenceObject.getClass()
        .getDeclaredField(dataItem);

      final Object modified = fl.get(eiEvidenceModifyDtls.evidenceObject);

      final Object previous = fl.get(eiEvidenceReadDtls.evidenceObject);

      if (modified != null) {

        return !modified.equals(previous);
      } else {

        return !(previous == null);
      }

    } catch (final IllegalAccessException e) {// do nothing
    } catch (final NoSuchFieldException e) {// do nothing
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * This readCodeTableItemDescription method reads the description of code
   * table code.
   *
   * @param codeName
   * code table code
   * @param codeTablelName
   * code table name
   *
   * @return the description of code table code
   */
  public String readCodeTableItemDescription(final String codeName,
    final String codeTablelName) throws AppException, InformationalException {

    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();

    ctitemKey.code = codeName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = codeTablelName;

    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    return ctitem.description;
  }

  // ___________________________________________________________________________
  /**
   * Inserts new VDIEDLink record for the verifiable data item and evidence
   * descriptor.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param vdIEDLinkDtls
   * VDIED link details
   * @param verifiableDataItemDataItemNameAndIDDetails
   * Verifiable data item, name and ID details
   */

  @Override
  public void insertVDIEDLink(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final VDIEDLinkDtls vdIEDLinkDtls,
    final VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails)
    throws AppException, InformationalException {

    // Insert into VDIEDLink
    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();

    vdIEDLinkDtls.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    vdIEDLinkDtls.verifiableDataItemID =
      verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID;

    // BEGIN, CR00468613, GK
    final DataItemIDAndDescriptorDetails keyObj =
      new DataItemIDAndDescriptorDetails();

    keyObj.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
    keyObj.verifiableDataItemID =
      verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID;
    VDIEDLinkDtls vdiedLinkRecord = null;

    try {
      vdiedLinkRecord =
        vdIEDLinkObj.readVDIEDLinkDtlsByDataItemAndDescriptorID(keyObj);
    } catch (final RecordNotFoundException ae) {// do nothing
    }
    if (null == vdiedLinkRecord) {
      vdIEDLinkObj.insert(vdIEDLinkDtls);
    } else {
      vdIEDLinkDtls.VDIEDLinkID = vdiedLinkRecord.VDIEDLinkID;
    }
    // END, CR00468613
  }

  // ___________________________________________________________________________
  /**
   * Inserts new verification record for the verifiable data item and VDIED
   * Link.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param verifiableDataItemDataItemNameAndIDDetails
   * Verifiable data item, name and ID details
   * @param vdIEDLinkDtls
   * VDIED link details
   * @param verificationICTypeAndRelatedItemDetails
   * Related item details
   */
  public void insertVerification(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails,
    final VDIEDLinkDtls vdIEDLinkDtls,
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00076353,AL
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // populate EvidenceDescriptorIDRelatedIDAndEvidenceType
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    boolean nonCaseData = false;

    // Check if Participant Level evidence and participant Evidence
    // Descriptor
    // (i.e. caseID is not set on evidence descriptor)

    nonCaseData = evidenceControllerObj.isNonCaseEDForParticipantEvidence(
      evidenceDescriptorIDRelatedIDAndEvidenceType);

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    final boolean isPDCEvidence =
      evidenceControllerObj.isPDCEvidence(evidenceTypeKey);
    // END, CR00076353

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    SearchDueDaysDueDateFromAndRequirementIDList searchDueDaysDueDateFromAndRequirementIDList =
      new SearchDueDaysDueDateFromAndRequirementIDList();

    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKey =
      new VerifiableDataItemAndStatusKey();

    verifiableDataItemAndStatusKey.verifiableDataItemID =
      verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID;
    verifiableDataItemAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    verifiableDataItemAndStatusKey.relatedItemID =
      verificationICTypeAndRelatedItemDetails.relatedItemID;
    verifiableDataItemAndStatusKey.relatedItemType =
      verificationICTypeAndRelatedItemDetails.relatedItemType;

    verifiableDataItemAndStatusKey.currentDate = Date.getCurrentDate();

    // search data items for integrated case type
    searchDueDaysDueDateFromAndRequirementIDList = verificationRequirementObj
      .searchRequirementsByDataItemIDAndRelatedItemID(
        verifiableDataItemAndStatusKey);

    // Insert into Verification
    final Verification verificationObj = VerificationFactory.newInstance();
    final VerificationDtls verificationDtls = new VerificationDtls();

    // BEGIN, CR00074026, BF
    // Case header variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    CaseTypeCode caseTypeCode = null;
    boolean isParticpantDataCase = false;

    if (evidenceDescriptorDtls.caseID != 0) {
      caseKey.caseID = evidenceDescriptorDtls.caseID;

      caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      if (CASETYPECODEEntry.PARTICIPANTDATACASE.getCode()
        .equals(caseTypeCode.caseTypeCode)) {
        isParticpantDataCase = true;
      }
    }

    // BEGIN, CR00076353,AL
    // if non case Data - Participant evidence - Participant evidence
    // descriptor
    // (for participant evidence Descriptors caseID is null)
    if (nonCaseData || isPDCEvidence && isParticpantDataCase) {
      verificationDtls.verificationLinkedType = VERIFICATIONTYPE.NONCASEDATA;
    } else {
      // Integrated case or product delivery
      // BEGIN, CR00350929, ARM
      verificationDtls.verificationLinkedType =
        verificationICTypeAndRelatedItemDetails.relatedItemID;
    }

    // END, CR00350929
    // END, CR00076353

    // Populate verification details struct to insert the details in to
    // Verification
    // BEGIN, CR00076353,AL
    if (nonCaseData || isPDCEvidence && isParticpantDataCase) {
      verificationDtls.verificationLinkedID =
        evidenceDescriptorDtls.participantID;
    } else {
      verificationDtls.verificationLinkedID = evidenceDescriptorDtls.caseID;
    }
    // END, CR00076353

    // END, HARP CR00074026
    for (int i = 0; i < searchDueDaysDueDateFromAndRequirementIDList.dtls
      .size(); i++) {

      verificationDtls.verificationRequirementID =
        searchDueDaysDueDateFromAndRequirementIDList.dtls
          .item(i).verificationRequirementID;

      // BEGIN, CR00333778 , AKr
      if (isConditionalVerificationApplicable(
        verificationDtls.verificationRequirementID,
        verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID,
        evidenceDescriptorDtls)) {
        // END, CR00333778 , AKr
        verificationDtls.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;
        verificationDtls.dueDate = calculateDueDate(evidenceDescriptorDtls,
          searchDueDaysDueDateFromAndRequirementIDList.dtls.item(i));

        verificationDtls.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;

        verificationObj.insert(verificationDtls);

        // BEGIN, CR00021355, NK
        final VerificationRequirementKey verificationRequirementKey =
          new VerificationRequirementKey();
        VerificationRequirementDtls verificationRequirementDtls;
        final VerificationRequirement verificationRequirement =
          VerificationRequirementFactory.newInstance();

        verificationRequirementKey.verificationRequirementID =
          searchDueDaysDueDateFromAndRequirementIDList.dtls
            .item(i).verificationRequirementID;
        verificationRequirementDtls =
          verificationRequirement.read(verificationRequirementKey);

        final curam.verification.sl.infrastructure.entity.struct.VerificationKey verificationKey =
          new curam.verification.sl.infrastructure.entity.struct.VerificationKey();

        verificationKey.verificationID = verificationDtls.verificationID;
        if (verificationRequirementDtls.vrAddedEventType.trim()
          .length() > 0) {
          raiseEvent(verificationKey,
            verificationRequirementDtls.vrAddedEventType);
        }
        // END, CR00021355

        // BEGIN, CR00230589, JS
        // This event will always be raised regardless of the
        // Verification
        // Requirement's configuration. The decision was made not to
        // re-use the
        // VerificationAdded event as this is optional, whereas we
        // always want
        // the
        // processing triggered by this event to be executed. Customers
        // wishing
        // to
        // use the VerificationAdded event should examine the processing
        // performed
        // by the VerficationInserted handler to ensure there is no
        // duplication
        // of
        // processing.
        raiseEvent(verificationKey,
          curam.events.Verification.VerificationInserted.eventType);
        // END, CR00230589

        // Raise the verification insertion workflow event
        if (!verificationDtls.dueDate.isZero()) {
          raiseWorkflowEvent(verificationDtls);
        }

      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Inserts new verification record for the verifiable data item and
   * Verification Requirement.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param verifiableDataItemAndRequirementIDDetails
   * Verifiable data item ID and ID details
   * @param vdIEDLinkDtls
   * VDIED link details
   * @param verificationICTypeAndRelatedItemDetails
   * The related item details
   *
   * @return verification key
   */
  public VerificationKey insertVerification(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails,
    final VDIEDLinkDtls vdIEDLinkDtls,
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00076353,AL
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // populate EvidenceDescriptorIDRelatedIDAndEvidenceType
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    boolean nonCaseData = false;

    // Check if Participant Level evidence and participant Evidence
    // Descriptor
    // (i.e. caseID is not set on evidence descriptor)

    nonCaseData = evidenceControllerObj.isNonCaseEDForParticipantEvidence(
      evidenceDescriptorIDRelatedIDAndEvidenceType);

    // END, CR00076353

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID =
      new SearchDueDaysDueDateFromAndRequirementID();

    final VerificationRequirementKey verificationRequirementKey =
      new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID =
      verifiableDataItemAndRequirementIDDetails.verificationRequirementID;

    // search data items for integrated case type
    searchDueDaysDueDateFromAndRequirementID = verificationRequirementObj
      .readDueDaysDueDateFrom(verificationRequirementKey);

    // Insert into Verification
    final Verification verificationObj = VerificationFactory.newInstance();
    final VerificationDtls verificationDtls = new VerificationDtls();

    // Populate verification details struct to insert the details in to
    // Verification
    // BEGIN, CR00074026, BF
    // Case header variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Check if Participant Level evidence and participant Evidence
    // Descriptor
    // (i.e. caseID is not set on evidence descriptor)

    nonCaseData = evidenceControllerObj.isNonCaseEDForParticipantEvidence(
      evidenceDescriptorIDRelatedIDAndEvidenceType);
    // BEGIN, CR00388286, AKr
    if (!nonCaseData) {

      caseKey.caseID = evidenceDescriptorDtls.caseID;
      final CaseTypeCode caseTypeCode =
        caseHeaderObj.readCaseTypeCode(caseKey);

      if (CASETYPECODEEntry.PARTICIPANTDATACASE.getCode()
        .equals(caseTypeCode.caseTypeCode)) {
        nonCaseData = true;
      }
    }
    // END, CR00388286

    // BEGIN, CR00076353,AL
    // if non case Data - Participant evidence - Participant evidence
    // descriptor
    // (for participant evidence Descriptors caseID is null)
    if (nonCaseData) {
      verificationDtls.verificationLinkedType = VERIFICATIONTYPE.NONCASEDATA;
    } else {

      caseKey.caseID = evidenceDescriptorDtls.caseID;
      // BEGIN, CR00350929, ARM
      // BEGIN, CR00371307, AKr
      verificationDtls.verificationLinkedType =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00371307
      // END, CR00350929
    }
    // END, CR00076353

    // Populate verification details struct to insert the details in to
    // Verification
    // BEGIN, CR00076353,AL
    if (nonCaseData) {
      verificationDtls.verificationLinkedID =
        evidenceDescriptorDtls.participantID;
    } else {
      verificationDtls.verificationLinkedID = evidenceDescriptorDtls.caseID;
    }
    // END, CR00076353
    // END, HARP CR00074026
    // BEGIN, CR00467947, GK
    final VerificationKey verificationKey = new VerificationKey();

    verificationDtls.verificationRequirementID =
      searchDueDaysDueDateFromAndRequirementID.verificationRequirementID;
    if (isConditionalVerificationApplicable(
      verificationDtls.verificationRequirementID,
      verifiableDataItemAndRequirementIDDetails.verifiableDataItemID,
      evidenceDescriptorDtls)) {
      // END, CR00467947
      verificationDtls.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;
      verificationDtls.dueDate = calculateDueDate(evidenceDescriptorDtls,
        searchDueDaysDueDateFromAndRequirementID);

      verificationDtls.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;
      verificationObj.insert(verificationDtls);

      // BEGIN, CR00021355, NK

      // BEGIN, CR00021498, NK
      verificationKey.verificationID = verificationDtls.verificationID;
      // END, CR00021498
      VerificationRequirementDtls verificationRequirementDtls;
      final VerificationRequirement verificationRequirement =
        VerificationRequirementFactory.newInstance();

      verificationRequirementDtls =
        verificationRequirement.read(verificationRequirementKey);

      verificationKey.verificationID = verificationDtls.verificationID;

      if (verificationRequirementDtls.vrAddedEventType.trim().length() > 0) {
        raiseEvent(verificationKey,
          verificationRequirementDtls.vrAddedEventType);
      }

      verificationKey.verificationID = verificationDtls.verificationID;
      // END, CR00021355

      // Raise the verification insertion workflow event
      if (!verificationDtls.dueDate.isZero()) {
        raiseWorkflowEvent(verificationDtls);
      }
      // BEGIN, CR00467947, GK
    }
    // END, CR00467947

    // BEGIN, CR00021355, NK
    return verificationKey;
    // END, CR00021355
  }

  // ___________________________________________________________________________
  /**
   * Inserts new verification records for the verifiable data items for the
   * product deliveries present in the integrated case.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details
   * @param verifiableDataItemsForIC
   * Verifiable data items require verification for IC
   * @param vdIEDLinkDtls
   * VDIED link details
   * @param eiEvidenceInsertDtls
   * EIEvidence insert details
   * @param informationalMessage
   * The informational message
   */
  public void insertVerificationForProductDelivery(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final ArrayList<String> verifiableDataItemsForIC,
    final VDIEDLinkDtls vdIEDLinkDtls,
    final EIEvidenceInsertDtls eiEvidenceInsertDtls,
    final StringBuffer informationalMessage)
    throws AppException, InformationalException {

    // Get all product deliveries present in the integrated case.
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseIDAndTypeCodeDetails caseIDAndTypeCodeDetails =
      new CaseIDAndTypeCodeDetails();
    CaseIDAndProductTypeDetailsList caseIDAndProductTypeDetailsList =
      new CaseIDAndProductTypeDetailsList();

    // BEGIN, CR00022902, KY
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    final ProductDelivery productDeliveryObj =
      ProductDeliveryFactory.newInstance();

    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();
    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    // END, CR00022902, KY

    caseIDAndTypeCodeDetails.caseID = evidenceDescriptorDtls.caseID;
    caseIDAndTypeCodeDetails.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

    // BEGIN, CR00022287, TV
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
    final long originalCaseID = evidenceDescriptorDtls.caseID;

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {
      caseIDAndTypeCodeDetails.caseID = caseHeaderDtls.integratedCaseID;
      final CaseIDAndProductTypeDetails caseIDAndProductTypeDetails =
        new CaseIDAndProductTypeDetails();

      caseIDAndProductTypeDetails.caseID = caseHeaderKey.caseID;
      productDeliveryKey.caseID = caseHeaderKey.caseID;

      caseIDAndProductTypeDetails.productType =
        productDeliveryObj.readProductType(productDeliveryKey).productType;
      caseIDAndProductTypeDetailsList.dtls
        .addRef(caseIDAndProductTypeDetails);

    } else {
      // fetch all Product delivery details added to the IC
      caseIDAndProductTypeDetailsList = caseHeaderObj
        .searchCaseIDAndProductTypeByIntCaseID(caseIDAndTypeCodeDetails);
    }

    // END CR00022287

    // Check if, any data items in the product delivery requires
    // verification.

    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // BEGIN, CR00071012, GM
    String dataItem = CuramConst.gkEmpty;
    // END, CR00071012
    boolean fieldEmpty = false;
    boolean dataItemExistsForIC = false;

    // BEGIN, CR00076353,AL
    // check if participant evidence
    // populate evidenceTypeKey
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    // Check if Participant Level evidence
    // BEGIN,CR00077795,AL
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final boolean isEvidenceParticipantData =
      evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);

    // END,CR00077795,AL
    // END, CR00076353

    for (int i = 0; i < caseIDAndProductTypeDetailsList.dtls.size(); i++) {

      caseKey.caseID = caseIDAndProductTypeDetailsList.dtls.item(i).caseID;

      // BEGIN, CR00414065, RD
      final ListPDClientRoleDetails listPDClientRoleDetails =
        listCaseMembers(caseKey.caseID);

      if (!isEvidenceDescriptorRelatedToCaseMember(listPDClientRoleDetails,
        evidenceDescriptorDtls.participantID)) {
        continue;
      }
      // END, CR00414065

      // BEGIN, CR00379191, AKr
      evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
        caseIDAndProductTypeDetailsList.dtls.item(i).productType;
      // END, CR00379191
      verifiableDataItemDataItemNameAndIDDetailsList =
        verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
          evidenceTypeAndRelatedItemTypeDetails);
      productDeliveryKey.caseID =
        caseIDAndProductTypeDetailsList.dtls.item(i).caseID;
      verificationICTypeAndRelatedItemDetails.relatedItemType =
        evidenceTypeAndRelatedItemTypeDetails.relatedItemType;
      // BEGIN, CR00379191, AKr
      verificationICTypeAndRelatedItemDetails.relatedItemID =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00379191
      for (int j = 0; j < verifiableDataItemDataItemNameAndIDDetailsList.dtls
        .size(); j++) {

        dataItem = verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(j).dataItem;
        fieldEmpty = false;

        // BEGIN, CR00191839, ND
        // BEGIN, CR00213416, GYH
        fieldEmpty = VerificationEvidenceFactory
          .newInstance(
            CASEEVIDENCEEntry.get(evidenceDescriptorDtls.evidenceType))
          .isFieldEmpty(dataItem, eiEvidenceInsertDtls.evidenceObject,
            evidenceDescriptorDtls.evidenceType);
        // END, CR00213416
        // END, CR00191839, ND

        dataItemExistsForIC =
          checkDataItemExistsForIC(dataItem, verifiableDataItemsForIC);

        // Assigning the product delivery case ID to evidence descriptor
        // case
        // ID as the same evidence descriptor is passed to Insert
        // Verification
        // and VDIED link methods. After verification insertion the
        // caseID
        // need to reassign back to evidence descriptor (Integrated
        // case)
        // case ID.
        evidenceDescriptorDtls.caseID =
          caseIDAndProductTypeDetailsList.dtls.item(i).caseID;

        // BEGIN, CR00076353,AL
        // check to see is case level verifications required
        // case level verifications only required if greater than non
        // case
        // data (Participant) verification level

        final VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey =
          new VerifiableDataItemRelatedIDAndTypeKey();

        verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(j).verifiableDataItemID;

        verifiableDataItemRelatedIDAndTypeKey.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(caseKey);

        // BEGIN, CR00350929, ARM
        // BEGIN, CR00371307, AKr

        verifiableDataItemRelatedIDAndTypeKey.relatedItemID =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00371307
        // END, CR00350929
        // Case level verifications not required if participant level
        // verification exist of equal or higher verification level

        final boolean isCaseLevelVerificationRequired =
          isCaseLevelVerificationRequired(
            verifiableDataItemRelatedIDAndTypeKey);

        // END, CR00076353

        if (!fieldEmpty && dataItemExistsForIC) {

          // BEGIN, CR00076353,AL
          // If temporal evidence or if participant evidence and
          // product
          // delivery level verification required then insert
          // verifications

          if (!isEvidenceParticipantData
            || isEvidenceParticipantData && isCaseLevelVerificationRequired) {

            // Insert verification for the data items
            insertVerification(evidenceDescriptorDtls,
              verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(j),
              vdIEDLinkDtls, verificationICTypeAndRelatedItemDetails);
          }
          // END, CR00076353

        } else if (!fieldEmpty) {

          // BEGIN, CR00076353,AL
          // If temporal evidence or if participant evidence and
          // product
          // delivery level verification required then insert
          // verifications
          if (!isEvidenceParticipantData
            || isEvidenceParticipantData && isCaseLevelVerificationRequired) {

            // Creating new VDIEDLink details object
            final VDIEDLinkDtls vdIEDLinkNewDtls = new VDIEDLinkDtls();

            // Insert VDIEDLink and Verification for the data item
            insertVDIEDLink(evidenceDescriptorDtls, vdIEDLinkNewDtls,
              verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(j));

            insertVerification(evidenceDescriptorDtls,
              verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(j),
              vdIEDLinkNewDtls, verificationICTypeAndRelatedItemDetails);

            verifiableDataItemsForIC.add(dataItem);

            if (vdIEDLinkDtls.VDIEDLinkID == 0) {

              vdIEDLinkDtls.VDIEDLinkID = vdIEDLinkNewDtls.VDIEDLinkID;
            }

            if (informationalMessage.toString().trim().length() == 0) {

              informationalMessage.append(readCodeTableItemDescription(
                verifiableDataItemDataItemNameAndIDDetailsList.dtls
                  .item(j).name,
                VERIFIABLEITEMNAME.TABLENAME));
            } else {
              // BEGIN, CR00071077, GM
              informationalMessage.append(
                // BEGIN, CR00163471, JC
                INFORMATIONALMESSAGE.INF_COMMA_SPACE_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale()));
              // END, CR00163471, JC
              // END, CR00071077
              informationalMessage.append(readCodeTableItemDescription(
                verifiableDataItemDataItemNameAndIDDetailsList.dtls
                  .item(j).name,
                VERIFIABLEITEMNAME.TABLENAME));
            }
          } // END, CR00076353
        }
      }

    }

    // reassigning back the integrated case ID to evidence descriptor
    evidenceDescriptorDtls.caseID = caseIDAndTypeCodeDetails.caseID;

    // BEGIN, CR00022287, TV
    evidenceDescriptorDtls.caseID = originalCaseID;
    // END CR00022287

  }

  // ___________________________________________________________________________
  /**
   * Check if the verifiable data item already exists in integrated case.
   *
   * @param dataItem
   * Verifiable data item in product delivery
   * @param verifiableDataItemsForIC
   * Verifiable data items need to verify for IC.
   *
   * @return true if the verifiable data item already exists in integrated
   * case
   */
  public boolean checkDataItemExistsForIC(final String dataItem,
    final ArrayList<String> verifiableDataItemsForIC) {

    boolean dataItemExists = false;

    for (int i = 0; i < verifiableDataItemsForIC.size(); i++) {

      if (dataItem.equals(verifiableDataItemsForIC.get(i))) {

        dataItemExists = true;
        break;
      }
    }

    return dataItemExists;
  }

  // ___________________________________________________________________________
  /**
   * Raise the workflow event for evidence insertion.
   *
   * @param verificationDtls
   * The verification details
   */

  @Override
  public void raiseWorkflowEvent(final VerificationDtls verificationDtls)
    throws AppException, InformationalException {

    // create the enactment struct for workflow
    final List<Object> enactmentStruct = new ArrayList<Object>();

    final NotificationWDOStruct notificationWDOStruct =
      new NotificationWDOStruct();

    // create and populate the verification workflow manager details
    final WMVerificationDetails wmVerificationDetails =
      new WMVerificationDetails();

    wmVerificationDetails.verificationID = verificationDtls.verificationID;
    wmVerificationDetails.verificationSatisified =
      VerificationConst.gkVerificationSatisfied;
    wmVerificationDetails.dueDateChanged = VerificationConst.gkDueDateChanged;
    wmVerificationDetails.deadlineElapsed =
      VerificationConst.gkDeadlineElapsed;
    wmVerificationDetails.verificationStatus =
      VerificationConst.gkVerificationStatus;
    wmVerificationDetails.verificationInFuture =
      VerificationConst.gkVerificationInFuture;
    wmVerificationDetails.warningDateIndicator =
      VerificationConst.gkWarningDateIndicator;

    final curam.verification.sl.infrastructure.entity.struct.VerificationKey verificationKey =
      new curam.verification.sl.infrastructure.entity.struct.VerificationKey();
    final curam.core.struct.CaseSearchKey caseSearchKey =
      new curam.core.struct.CaseSearchKey();
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    verificationKey.verificationID = verificationDtls.verificationID;

    final curam.verification.sl.infrastructure.entity.intf.Verification verification =
      curam.verification.sl.infrastructure.entity.fact.VerificationFactory
        .newInstance();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    ctitemKey.code = verification
      .readNameByVerificationID(verificationKey).verifiableDataItemName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    CaseIDDetails caseIDDetails = new CaseIDDetails();

    // BEGIN, CR00074026, BF
    // Read the caseID based on the verificationID
    // The caseID is no longer stored on the verification entity -
    // instead a verificationLinkedID & verificationLinkedType (IC, PD or
    // Participant). This readCaseID always sets the verificationLinkedType
    // to
    // Participant to ensure the the search checks for all types that are
    // not
    // participant i.e. case
    final ReadByVerIDAndVerLinkedTypeKey readByVerIDAndVerLinkedTypeKey =
      new ReadByVerIDAndVerLinkedTypeKey();

    readByVerIDAndVerLinkedTypeKey.verificationID =
      verificationKey.verificationID;
    caseIDDetails = verification.readCaseID(readByVerIDAndVerLinkedTypeKey);
    // END, CR00074026

    // set the key to read case reference
    caseSearchKey.caseID = caseIDDetails.caseID;
    // read case reference
    final curam.core.struct.CaseReference caseReference =
      caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    wmVerificationDetails.CaseID = caseIDDetails.caseID;
    wmVerificationDetails.caseReference = caseReference.caseReference;
    wmVerificationDetails.verificationName = ctitem.description;
    wmVerificationDetails.dueDate = verificationDtls.dueDate;

    enactmentStruct.add(wmVerificationDetails);

    notificationWDOStruct.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();
    enactmentStruct.add(notificationWDOStruct);

    EnactmentService.startProcess(
      VerificationConst.gkVerificationWorkflowName, enactmentStruct);

  }

  // ___________________________________________________________________________
  /**
   * This method constructs the informational message to display the data item
   * names which requires verification.
   *
   * @param catEntry
   * The message catalog entry to be used.
   * @param informationalMessage
   * Informational message to display on page
   */
  public void createInformational(final CatEntry catEntry,
    final StringBuffer informationalMessage)
    throws AppException, InformationalException {

    if (informationalMessage.toString().trim().length() == 0) {
      return;
    }

    // BEGIN, CR00407031, RD
    final TransactionType transactionType =
      curam.util.transaction.TransactionInfo.getTransactionType();

    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PREVENT_VERIFICATION_WARNINGS_IN_BATCH_OR_DEFERRED_PROCESS)
      && (TransactionType.kBatch.equals(transactionType)
        || TransactionType.kDeferred.equals(transactionType))) {
      return;

    } else {
      // Get the informational manager
      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();

      final AppException appException = new AppException(catEntry);

      // BEGIN, CR00052924, GM
      informationalManager.addInformationalMsg(appException,
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);
      // END, CR00052924
      appException.arg(informationalMessage.toString());
    }
    // END, CR00407031

  }

  // BEGIN, CR CR00080088, BF
  // ___________________________________________________________________________
  /**
   * The calculateDueDate method calculates the verification due date. This
   * method should only be ever called when calculating due dates for case
   * verifications and not participant verifications at participant level. If
   * this method is called for participant verifications at participant level
   * it will just return.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details.
   * @param searchDueDaysDueDateFromAndRequirementID
   * Due days, due date from and requirement ID.
   *
   * @return the verification due date
   */

  @Override
  public Date calculateDueDate(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID)
    throws AppException, InformationalException {

    int dueDays = 0;
    Date dueDate = Date.kZeroDate;

    dueDays = searchDueDaysDueDateFromAndRequirementID.dueDays;

    // If its participant evidence and caseID is not set then the calculate
    // due date is not relevant so just set to zero date and return.
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.relatedID =
      evidenceDescriptorDtls.relatedID;

    final boolean isEvidenceParticpantDataParticipantEDOnly =
      evidenceControllerObj.isNonCaseEDForParticipantEvidence(
        evidenceDescriptorIDRelatedIDAndEvidenceType);

    if (dueDays == 0 || isEvidenceParticpantDataParticipantEDOnly) {

      dueDate = Date.kZeroDate;
      // END, CR CR00080088
    } else if (searchDueDaysDueDateFromAndRequirementID.dueDateFrom
      .equals(VERIFICATIONDUEDATEFROM.INSERTEVIDENCE)) {

      // Set the due date to current date plus number of due days
      dueDate = Date.getCurrentDate().addDays(dueDays);
    } else if (searchDueDaysDueDateFromAndRequirementID.dueDateFrom
      .equals(VERIFICATIONDUEDATEFROM.RECEIVEDEVIDENCE)) {

      // set the due date to evidence descriptors received date plus
      // number of
      // due days
      dueDate = evidenceDescriptorDtls.receivedDate.addDays(dueDays);
    } else if (searchDueDaysDueDateFromAndRequirementID.dueDateFrom
      .equals(VERIFICATIONDUEDATEFROM.CASECREATED)) {

      // set the due date to case start date plus number of due days
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      CaseStartDate caseStartDate = new CaseStartDate();

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);

      dueDate = caseStartDate.startDate.addDays(dueDays);
    }

    return dueDate;
  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field for empty.
   *
   * @param fl
   * Field to check for empty.
   * @param object
   * Object containing field value.
   *
   * @return true if the field is empty
   *
   * @deprecated Since Curam 6.0, Operates only on static evidence. Please use
   * {@link VerificationEvidenceInterface#isFieldEmpty(String, Object, String)}
   * instead.
   */
  @Deprecated
  public boolean isFieldEmpty(final Field fl, final Object object) {

    try {
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeMoney)) {
        // BEGIN, CR00069996, SK
        final Money money = (Money) fl.get(object);

        return isFieldEmpty(money);
      }
      // BEGIN, CR00077795, AL
      if (fl.getType().getName().equals(VerificationConst.kTypeDate)) {
        // BEGIN, CR00077795, AL
        final Date date = (Date) fl.get(object);

        return isFieldEmpty(date);
      }
      // BEGIN, CR00077795, AL
      if (fl.getType().getName().equals(VerificationConst.kTypeString)) {
        // BEGIN, CR00077795, AL
        final String string = (String) fl.get(object);

        return isFieldEmpty(string);
      }

      // BEGIN, CR00233632, PB
      if (fl.getType().getName().equals(VerificationConst.kTypeDateTime)) {
        final DateTime dateTime = (DateTime) fl.get(object);

        return isFieldEmpty(dateTime);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeInt)) {
        final int i = (Integer) fl.get(object);

        return isFieldEmpty(i);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeLong)) {
        final long l = (Long) fl.get(object);

        return isFieldEmpty(l);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeShort)) {
        final short k = (Short) fl.get(object);

        return isFieldEmpty(k);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeDouble)) {
        final Double d = (Double) fl.get(object);

        return isFieldEmpty(d);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeBoolean)) {
        final boolean b = (Boolean) fl.get(object);

        return isFieldEmpty(b);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeBlob)) {
        final Blob blob = (Blob) fl.get(object);

        return isFieldEmpty(blob);
      }
      // END, CR00233632
    } catch (final IllegalAccessException e) {// do nothing
    }

    return false;

  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type money for empty.
   *
   * @param money
   * field of type money
   *
   * @return true if the money field is empty
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #isFieldEmpty(Field, Object)}.
   */
  @Deprecated
  public boolean isFieldEmpty(final Money money) {

    if (money.getValue() == 0) {

      return true;
    }

    return false;
  }

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * This method compares the value of two fields of the same type, where the
   * type is specified as a field.
   *
   * @param fl
   * Field to compare the values.
   * @param object1
   * first object containing field value.
   * @param object2
   * second object containing field value.
   *
   * @return true if the fields are not identical.
   *
   * @deprecated Since Curam 6.0, Operates only on static evidence. Please use
   * {@link VerificationEvidenceInterface#compareFields(String, Object, Object, String)
   * )} instead.
   */
  @Deprecated
  public boolean compareFields(final Field fl, final Object object1,
    final Object object2) {

    try {
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeMoney)) {
        // END, CR00069996
        final Money money1 = (Money) fl.get(object1);
        final Money money2 = (Money) fl.get(object2);

        return compareField(money1, money2);
      }
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeDate)) {
        // END, CR00069996
        final Date date1 = (Date) fl.get(object1);
        final Date date2 = (Date) fl.get(object2);

        return compareField(date1, date2);
      }
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeString)) {
        // END, CR00069996
        final String string1 = (String) fl.get(object1);
        final String string2 = (String) fl.get(object2);

        return compareField(string1, string2);
      }
      // BEGIN, CR00233632, PB
      if (fl.getType().getName().equals(VerificationConst.kTypeDateTime)) {
        final DateTime dateTime1 = (DateTime) fl.get(object1);
        final DateTime dateTime2 = (DateTime) fl.get(object2);

        return compareField(dateTime1, dateTime2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeShort)) {
        final short s1 = (Short) fl.get(object1);
        final short s2 = (Short) fl.get(object2);

        return compareField(s1, s2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeInt)) {
        final int i1 = (Integer) fl.get(object1);
        final int i2 = (Integer) fl.get(object2);

        return compareField(i1, i2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeLong)) {
        final long l1 = (Long) fl.get(object1);
        final long l2 = (Long) fl.get(object2);

        return compareField(l1, l2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeDouble)) {
        final double d1 = (Double) fl.get(object1);
        final double d2 = (Double) fl.get(object2);

        return compareField(d1, d2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeBoolean)) {
        final boolean b1 = (Boolean) fl.get(object1);
        final boolean b2 = (Boolean) fl.get(object2);

        return compareField(b1, b2);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeBlob)) {
        final Blob blob1 = (Blob) fl.get(object1);
        final Blob blob2 = (Blob) fl.get(object2);

        return compareField(blob1, blob2);
      }
      // END, CR00233632

    } catch (final IllegalAccessException e) {// do nothing
    }

    return false;
  }

  // END, CR00021355

  // ___________________________________________________________________________
  /**
   * The compare field method compares the two dates for equality.
   *
   * @param date1
   * date to compare with other date field
   * @param date2
   * date to compare with other date field
   *
   * @return true if the strings are not identical.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #compareFields(Field, Object, Object)}.
   */
  @Deprecated
  public boolean compareField(final Date date1, final Date date2) {

    // BEGIN, CR00282100, AKr
    if (date1.compareTo(date2) != 0) {
      // END, CR00282100
      return true;
    }

    return false;
  }

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two money fields for equality.
   *
   * @param money1
   * money to compare with other money field
   * @param money2
   * money to compare with other money field
   *
   * @return true if the strings are not identical.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #compareFields(Field, Object, Object)}.
   */
  @Deprecated
  public boolean compareField(final Money money1, final Money money2) {

    if (money1.getValue() != money2.getValue()) {

      return true;
    }

    return false;
  }

  // END, CR00021355

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two strings for equality.
   *
   * @param string1
   * string to compare with other string field
   * @param string2
   * string to compare with other string field
   *
   * @return true if the strings are not identical.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #compareFields(Field, Object, Object)}.
   */
  @Deprecated
  public boolean compareField(final String string1, final String string2) {

    if (!string1.trim().equalsIgnoreCase(string2.trim())) {

      return true;
    }

    return false;
  }

  // END, CR00021355

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type date for empty.
   *
   * @param date
   * field of type date
   *
   * @return true if the date is empty.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #isFieldEmpty(Field, Object)}.
   */
  @Deprecated
  public boolean isFieldEmpty(final Date date) {

    if (date.isZero()) {

      return true;
    }

    return false;
  }

  // BEGIN, CR00108051,GM
  // BEGIN, CR00233632, PB
  /**
   * The isFieldEmpty method checks the field of type date time for empty.
   *
   * @param date
   * date/time field of type date time
   *
   * @return true if the date/time is empty.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #isFieldEmpty(Field, Object)}.
   */
  @Deprecated
  public boolean isFieldEmpty(final DateTime date) {

    if (date.isZero()) {
      // END, CR00233632
      return true;
    }

    return false;
  }

  // END CR00108051

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type string for empty.
   *
   * @param string
   * field of type string
   *
   * @return true if the string is empty.
   *
   * @deprecated Since Curam 6.0, Should not be part of the public interface
   * of this class. Should really be a private method as it is
   * used internally by {@link #isFieldEmpty(Field, Object)}.
   */
  @Deprecated
  public boolean isFieldEmpty(final String string) {

    if (string.trim().length() == 0) {

      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * This method checks for verification details while adding Product Delivery
   * to the Integrated Case. It inserts the verifications into database that
   * are not added
   *
   * This method insert verifications for temporal evidence.
   *
   * @param ICCaseKey
   * integrated case key
   * @param pdKey
   * product delivery key
   */
  @Override
  public void createProductDeliveryVerifications(
    final IntegratedCaseKey ICCaseKey, final ProductDeliveryKey pdKey)
    throws AppException, InformationalException {

    // EvidenceDescriptor variables
    ReadEvidenceTypeParticipantDetailsList evidTypeParticipantDetailsList =
      new ReadEvidenceTypeParticipantDetailsList();
    final ReadEvidenceTypeParticipantDetailsList filteredList =
      new ReadEvidenceTypeParticipantDetailsList();
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();
    final EvidenceDescriptor evidenceDescriptor =
      curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory
        .newInstance();

    // VDIEDLink variables
    final VDIEDLink vDIEDLink = VDIEDLinkFactory.newInstance();
    VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();
    final Verification verification = VerificationFactory.newInstance();
    VerificationRequirementIDStatusDetailsList verificationRequirementIDStatusDetailsList =
      new VerificationRequirementIDStatusDetailsList();

    // Verification Requirement variables
    VerificationRequirementKey verificationRequirementKey =
      new VerificationRequirementKey();

    ContainsInd containsInd;

    VerificationRequirementKeyList verificationRequirementKeyList =
      new VerificationRequirementKeyList();
    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirement =
      VerificationRequirementFactory.newInstance();

    // VerifiableDataItem variables
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    VerifiableDataItemDetails verifiableDataItemDetails =
      new VerifiableDataItemDetails();
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();
    final RequirementUsageDetailsList requirementUsageDetailsList =
      new RequirementUsageDetailsList();

    // BEGIN, CR00380884, MV
    final CaseIDAndStatuses caseIDAndStatus = new CaseIDAndStatuses();

    caseIDAndStatus.statusCode1 = EVIDENCEDESCRIPTORSTATUS.SUPERSEDED;
    caseIDAndStatus.statusCode2 = EVIDENCEDESCRIPTORSTATUS.CANCELED;
    caseIDAndStatus.caseID = ICCaseKey.integratedCaseID;
    evidTypeParticipantDetailsList = evidenceDescriptor
      .searchEvidenceDetailsByCaseIDAndStatuses(caseIDAndStatus);
    // END, CR00380884

    // BEGIN, CR00414065, RD
    final ListPDClientRoleDetails listPDClientRoleDetails =
      listCaseMembers(pdKey.caseID);

    // END, CR00414065

    // BEGIN,CR00077149,AL
    // loop through evidence list - if participant evidence continue to next
    // item in list - do not continue further processing
    // if temporal evidence continue processing and create verification
    // details
    for (int m = 0; m < evidTypeParticipantDetailsList.dtls.size(); m++) {

      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      // populate EvidenceDescriptorIDRelatedIDAndEvidenceType
      final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
        new EvidenceDescriptorIDRelatedIDAndEvidenceType();

      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
        evidTypeParticipantDetailsList.dtls.item(m).evidenceType;
      evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
        evidTypeParticipantDetailsList.dtls.item(m).evidenceDescriptorID;

      final boolean isEvidenceParticpantDataParticipantEDOnly =
        evidenceControllerObj.isNonCaseEDForParticipantEvidence(
          evidenceDescriptorIDRelatedIDAndEvidenceType);

      if (isEvidenceParticpantDataParticipantEDOnly) {
        continue;
      }

      // Verification Requirement Usage details
      final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage =
        curam.verification.sl.entity.fact.VerificationRequirementUsageFactory
          .newInstance();
      final ReadReqUsageRelatedItemType readReqUsageRelatedItemType =
        new ReadReqUsageRelatedItemType();

      final curam.core.intf.ProductDelivery productDelivery =
        curam.core.fact.ProductDeliveryFactory.newInstance();
      final curam.core.struct.ProductDeliveryTypeDetails productDeliveryTypeDetails =
        new ProductDeliveryTypeDetails();

      productDeliveryTypeDetails.productType =
        productDelivery.readProductType(pdKey).productType;

      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();

      caseKey.caseID = pdKey.caseID;
      readReqUsageRelatedItemType.relatedItemType =
        verificationUtilities.getRelatedItemTypeCode(caseKey);

      verificationRequirementKeyList = verificationRequirementUsage
        .readRequirementDetailsByRelatedItemType(readReqUsageRelatedItemType);

      for (int i = 0; i < verificationRequirementKeyList.dtls.size(); i++) {

        // BEGIN,CR00080614,AL
        final RequirementUsageDetails requirementUsageDetails =
          new RequirementUsageDetails();

        // END, CR00080614
        verificationRequirementKey =
          verificationRequirementKeyList.dtls.item(i);

        // BEGIN, CR00021237, NK
        // END, CR00021237

        requirementUsageDetails.verificationRequirementID =
          verificationRequirementKeyList.dtls
            .item(i).verificationRequirementID;
        verifiableDataItemDetails = verificationRequirement
          .readVerifiableDataItemDetails(verificationRequirementKey);

        requirementUsageDetails.verifiableDataItemID =
          verifiableDataItemDetails.verifiableDataItemID;
        requirementUsageDetails.verifiableDataItemName =
          verifiableDataItemDetails.verifiableDataItemName;
        requirementUsageDetails.evidenceType =
          verifiableDataItemDetails.evidenceType;

        requirementUsageDetailsList.dtls.addRef(requirementUsageDetails);
      }

      // filter the evidence descriptor list

      boolean evidenceTypeFound = false;

      for (int i = 0; i < evidTypeParticipantDetailsList.dtls.size(); i++) {
        evidenceTypeFound = false;
        for (int j = 0; j < requirementUsageDetailsList.dtls.size(); j++) {
          if (evidTypeParticipantDetailsList.dtls.item(i).evidenceType
            .equals(requirementUsageDetailsList.dtls.item(j).evidenceType)) {
            evidenceTypeFound = true;
            break;
          }
        }
        if (evidenceTypeFound
          // BEGIN, CR00414065, RD
          && isEvidenceDescriptorRelatedToCaseMember(listPDClientRoleDetails,
            evidTypeParticipantDetailsList.dtls.item(i).participantID)) {
          // END, CR00414065
          filteredList.dtls
            .addRef(evidTypeParticipantDetailsList.dtls.item(i));
        }
      }

      // Participant ID and VerifiableDataItem Key to buildErrorMessage
      final ParticipantIDVerifiableDataItemIDKey participantIDVerifiableDataItemIDKey =
        new ParticipantIDVerifiableDataItemIDKey();

      final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
        new VerificationICTypeAndRelatedItemDetails();

      // BEGIN, CR00074026, BF
      // Read based on vdiedLinkID, verificationLinkedID &
      // verificaitonLinkedType
      final ReadByVDIEDLinkAndVerLinkedIDTypeKey readByVDIEDLinkAndVerLinkedIDTypeKey =
        new ReadByVDIEDLinkAndVerLinkedIDTypeKey();

      for (int i = 0; i < filteredList.dtls.size(); i++) {

        evidenceDescriptorKey.evidenceDescriptorID =
          filteredList.dtls.item(i).evidenceDescriptorID;
        vDIEDLinkIDAndDataItemIDDetailsList =
          vDIEDLink.readByEvidenceDescriptorID(evidenceDescriptorKey);

        if (vDIEDLinkIDAndDataItemIDDetailsList.dtls.size() == 0) {

          // insert Verification details
          insertVerification(evidenceDescriptorKey);
        }

        for (int j = 0; j < vDIEDLinkIDAndDataItemIDDetailsList.dtls
          .size(); j++) {

          vDIEDLinkKey.VDIEDLinkID =
            vDIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
          readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID =
            vDIEDLinkIDAndDataItemIDDetailsList.dtls.item(j).vDIEDLinkID;
          readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedID =
            pdKey.caseID;
          // Searching based on Product delivery key so set the
          // verificationLinkedType to product delivery
          readByVDIEDLinkAndVerLinkedIDTypeKey.verificationLinkedType =
            verificationUtilities.getRelatedItemTypeCode(caseKey);

          verificationRequirementIDStatusDetailsList = verification
            .searchReqIDAndVerStatusByVDIEDLinkIDVerLinkedIDAndType(
              readByVDIEDLinkAndVerLinkedIDTypeKey);
          // END, CR00074026
          for (int k = 0; k < requirementUsageDetailsList.dtls.size(); k++) {

            if (filteredList.dtls.item(i).evidenceType
              .equals(requirementUsageDetailsList.dtls.item(k).evidenceType)
              && vDIEDLinkIDAndDataItemIDDetailsList.dtls.item(
                j).verifiableDataItemID == requirementUsageDetailsList.dtls
                  .item(k).verifiableDataItemID) {

              verificationRequirementKey.verificationRequirementID =
                requirementUsageDetailsList.dtls
                  .item(k).verificationRequirementID;

              boolean buildMessage = false;

              containsInd = containsRequirement(
                verificationRequirementIDStatusDetailsList,
                verificationRequirementKey);

              if (!containsInd.contains) {

                // insert verification to Verification table
                final EvidenceDescriptorDtls evidenceDescriptorDtls =
                  evidenceDescriptor.read(evidenceDescriptorKey);
                final VDIEDLinkDtls vdIEDLinkDtls =
                  vDIEDLink.read(vDIEDLinkKey);

                verifiableDataItemKey.verifiableDataItemID =
                  vdIEDLinkDtls.verifiableDataItemID;

                final VerifiableDataItemDtls verifiableDataItemDtls =
                  verifiableDataItem.read(verifiableDataItemKey);

                // BEGIN, CR00074026, BF
                // BEGIN, CR00350929, ARM
                // BEGIN, CR00371307, AKr
                verificationICTypeAndRelatedItemDetails.relatedItemID =
                  verificationUtilities.getRelatedItemID(caseKey).getCode();
                // END, CR00371307
                // END, CR00350929
                verificationICTypeAndRelatedItemDetails.relatedItemType =
                  verificationUtilities.getRelatedItemTypeCode(caseKey);
                // END, CR00074026
                evidenceDescriptorDtls.caseID = pdKey.caseID;

                final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
                  new VerifiableDataItemAndRequirementIDDetails();

                verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
                  verifiableDataItemDtls.verifiableDataItemID;
                verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
                  requirementUsageDetailsList.dtls
                    .item(k).verificationRequirementID;

                final boolean conditionalVerificationApplicable =
                  isConditionalVerificationApplicable(
                    verifiableDataItemAndRequirementIDDetails.verificationRequirementID,
                    verifiableDataItemDtls.verifiableDataItemID,
                    evidenceDescriptorDtls);

                if (!conditionalVerificationApplicable) {
                  continue;
                }

                // BEGIN, CR00021355, NK
                VerificationKey verificationKey = new VerificationKey();

                verificationKey = insertVerification(evidenceDescriptorDtls,
                  verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls,
                  verificationICTypeAndRelatedItemDetails);

                // BEGIN, RTC 273436
                final VerificationDtlsList verificationDtlsList =
                  new VerificationDtlsList();
                final VerificationDtls verificationDtls =
                  VerificationFactory.newInstance().read(verificationKey);
                verificationDtlsList.dtls.add(verificationDtls);

                final VDIEDLinkIDDtlsList vDIEDLinkIDDtlsList =
                  new VDIEDLinkIDDtlsList();
                final VDIEDLinkIDDtls vDIEDLinkIDDtls = new VDIEDLinkIDDtls();
                vDIEDLinkIDDtls.VDIEDLinkID = vDIEDLinkKey.VDIEDLinkID;
                vDIEDLinkIDDtlsList.dtls.addRef(vDIEDLinkIDDtls);

                final VerificationStatusDeterminator statusDeterminator =
                  new VerificationStatusDeterminator(verificationDtlsList,
                    vDIEDLinkIDDtlsList);

                statusDeterminator.determineStatus();
                // END, RTC 273436

                if (verification
                  .readVerificationStatus(verificationKey).verificationStatus
                    .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
                  buildMessage = true;
                }
                // END, CR00021355

                // raiseWorkflowEvent();
                buildMessage = true;
              }

              if (containsInd.verificationStatus
                .equals(VERIFICATIONSTATUS.NOTVERIFIED) || buildMessage) {

                participantIDVerifiableDataItemIDKey.participantID =
                  filteredList.dtls.item(i).participantID;
                participantIDVerifiableDataItemIDKey.verifiableDataItemID =
                  vDIEDLinkIDAndDataItemIDDetailsList.dtls
                    .item(j).verifiableDataItemID;
                final ErrorMessageDetails errorMessageDetails =
                  buildMessage(participantIDVerifiableDataItemIDKey);
                final StringBuffer errMessage =
                  new StringBuffer(errorMessageDetails.errorMessage);

                final curam.util.message.CatEntry catEntry =
                  ENTVERIFICATIONCONTROLLER.ERR_VERIFICATIONCONTROLLER_DATA_ITEMS_REQUIRE_VERIFICATION_INFORMATIONAL;

                createInformational(catEntry, errMessage);

              }
            }
          } // for loop k
        } // for loop j
      } // for loop i

      // insert verification details for evidence records
      // that did not have verification records
      // BEGIN, CR00380884, MV
      caseIDAndStatus.caseID = pdKey.caseID;
      evidTypeParticipantDetailsList = evidenceDescriptor
        .searchEvidenceDetailsByCaseIDAndStatuses(caseIDAndStatus);
      // END, CR00380884

      for (int i = 0; i < evidTypeParticipantDetailsList.dtls.size(); i++) {

        evidenceTypeFound = false;
        for (int j = 0; j < requirementUsageDetailsList.dtls.size(); j++) {

          if (evidTypeParticipantDetailsList.dtls.item(i).evidenceType
            .equals(requirementUsageDetailsList.dtls.item(j).evidenceType)) {
            evidenceTypeFound = true;
            break;
          }
        }

        if (!evidenceTypeFound) { // insert verification details
          evidenceDescriptorKey.evidenceDescriptorID = // BEGIN,
            // CR00061127,
            // AC
            evidTypeParticipantDetailsList.dtls.item(i).evidenceDescriptorID;
          // END, CR00061127
          insertVerification(evidenceDescriptorKey);
        }
      } // END,CR00077149
    }
  }

  // ___________________________________________________________________________
  /**
   * This performs verification for each Participant IDs Checks the
   * Verification Status and Builds Error Message Common to Both Apply Changes
   * and Verify Product Details verification.
   *
   * @param details
   * contains information on evidence type, participant details
   */
  @Override
  public void performVerification(
    final EvidenceTypeAndParticipantDetailsListDetails details)
    throws AppException, InformationalException {

    ReadEvidenceTypeParticipantDetailsList readEvidenceTypeParticipantDetailsList =
      new ReadEvidenceTypeParticipantDetailsList();

    readEvidenceTypeParticipantDetailsList = details.listDtls;

    // Verification variables
    final Verification verification = VerificationFactory.newInstance();

    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkIDAndDataItemIDDetailsList =
      new VDIEDLinkIDAndDataItemIDDetailsList();

    // VDIEDLink variables
    final VDIEDLink vDIEDlink = VDIEDLinkFactory.newInstance();
    final VDIEDLinkIDMandatoryKey vDIEDLinkIDMandatoryKey =
      new VDIEDLinkIDMandatoryKey();

    MandatoryVerificationDetailsList mandatoryVerificationDetailsList =
      new MandatoryVerificationDetailsList();
    ReadEvidenceTypeParticipantDetails readEvidenceTypeParticipantDetails =
      new ReadEvidenceTypeParticipantDetails();

    MandatoryVerificationDetails mandatoryVerificationDetails =
      new MandatoryVerificationDetails();

    // VerifiableDataItem variables
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();

    // BEGIN, CR00071012, GM
    String errorMessage = CuramConst.gkEmpty;
    // END, CR00071012

    final AppException appException = new AppException(
      ENTAPPLYCHANGES.ERR_UNSATISFIED_MANDATORY_VERIFICATION_REQUIREMENT);

    // concern role variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // BEGIN, CR00354770, KH
    final Verification verificationEntityObj =
      VerificationFactory.newInstance();
    final CachedCaseHeader cachedCaseHeaderObj =
      CachedCaseHeaderFactory.newInstance();
    // END, CR00354770

    // BEGIN, CR00426157, MV
    CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList =
      null;

    // To iterate through readEvidenceTypeParticipantDetailsList
    for (int j = 0; j < readEvidenceTypeParticipantDetailsList.dtls
      .size(); j++) {

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();

      evidenceDescriptorKey.evidenceDescriptorID =
        readEvidenceTypeParticipantDetailsList.dtls
          .item(j).evidenceDescriptorID;
      readEvidenceTypeParticipantDetails =
        readEvidenceTypeParticipantDetailsList.dtls.item(j);
      currentPostponedVerificationDtlsList =
        CurrentPostponedVerificationFactory.newInstance()
          .searchByEvidenceDescriptorID(evidenceDescriptorKey);
      final EvidenceDescriptorDtls evidenceDescriptorDtls =
        evidenceDescriptorObj.read(evidenceDescriptorKey);

      if (null != currentPostponedVerificationDtlsList
        && 0 < currentPostponedVerificationDtlsList.dtls.size()) {

        final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

        eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
        eiEvidenceKey.evidenceType =
          readEvidenceTypeParticipantDetails.evidenceType;
        final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
          EvidenceControllerFactory.newInstance()
            .getEvidenceSummaryDetails(eiEvidenceKey);

        // BEGIN, CR00427012, KRK
        final AppException e = new AppException(
          BPOVERIFICATIONCONST.INF_EVIDENCE_POSTPONED_ARENOT_ACTIVATED)
            .arg(LocalizableXMLStringHelper
              .toPlainText(eiFieldsForListDisplayDtls.summary)
              .replace(CuramConst.gkDotChar, CuramConst.gkSpaceChar).trim());

        // END, CR00427012

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(e, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
        break;
      }
      // END, CR00426157

      vDIEDLinkIDAndDataItemIDDetailsList =
        vDIEDlink.readByEvidenceDescriptorID(evidenceDescriptorKey);

      // BEGIN,CR00077795,AL
      // populate evidenceTypeKey
      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType =
        readEvidenceTypeParticipantDetailsList.dtls.item(j).evidenceType;

      // BEGIN,CR00077795,AL
      final EvidenceControllerInterface evidenceControllerObj =
        (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      final boolean isParticipantData =
        evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);
      // BEGIN, CR00358503, AKr
      final boolean isPDCEvidence =
        evidenceControllerObj.isPDCEvidence(evidenceTypeKey);

      // END, CR00358503
      // END,CR00077795,AL

      // if participant evidence and no case level verifications exist
      // check to see if participant level verifications exist
      // if participant level verifications exist throw validation message
      if (isParticipantData
        && vDIEDLinkIDAndDataItemIDDetailsList.dtls.size() == 0) {

        // retrieve related ID of integrated case evidence descriptor
        final EvidenceDescriptorDtls evidenceDescriptorDtlsForCase =
          evidenceDescriptorObj.read(evidenceDescriptorKey);

        performParticipantVerification(evidenceDescriptorDtlsForCase);

      } // End of if participant evidence and no case level verifications
      // exist
      // END,CR00077795

      final VerificationKey verificationKey = new VerificationKey();

      // to iterated VDIEDLinkAndDataItemIDDetailsList
      for (int k = 0; k < vDIEDLinkIDAndDataItemIDDetailsList.dtls
        .size(); k++) {

        vDIEDLinkIDMandatoryKey.VDIEDLinkID =
          vDIEDLinkIDAndDataItemIDDetailsList.dtls.item(k).vDIEDLinkID;

        mandatoryVerificationDetailsList = verification
          .searchMandatoryVerificationRequirementsAndVerificationStatus(
            vDIEDLinkIDMandatoryKey);

        for (int i = 0; i < mandatoryVerificationDetailsList.dtls
          .size(); i++) {

          mandatoryVerificationDetails =
            mandatoryVerificationDetailsList.dtls.item(i);

          // BEGIN, CR00260117, FM
          verificationKey.verificationID =
            mandatoryVerificationDetails.verificationID;
          final MaintainVerificationWaiver verificationWaiverObj =
            MaintainVerificationWaiverFactory.newInstance();

          final VerificationWaiverDtlsList verificationWaiverDtlsList =
            verificationWaiverObj
              .listCurrentActiveByVerificationID(verificationKey);

          // BEGIN, CR00354770, KH
          // Retrieve the case details so we can check the case status
          final ReadByVerIDAndVerLinkedTypeKey verKey =
            new ReadByVerIDAndVerLinkedTypeKey();

          verKey.verificationID = mandatoryVerificationDetails.verificationID;

          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          // BEGIN, CR00358503, AKr
          if (isPDCEvidence) {
            caseHeaderKey.caseID =
              evidenceDescriptorObj.read(evidenceDescriptorKey).caseID;
          } else {
            caseHeaderKey.caseID =
              verificationEntityObj.readCaseID(verKey).caseID;
          }
          // END, CR00358503

          final CaseHeaderDtls caseDetails =
            cachedCaseHeaderObj.read(caseHeaderKey);

          /*
           * Evidence on Closed or Suspended cases should not be
           * verified. We also call out to the hook point to allow
           * custom processing to skip the verification for case
           * evidence.
           */
          if (verificationWaiverDtlsList.dtls.isEmpty()
            && mandatoryVerificationDetails.verificationStatus
              .equals(VERIFICATIONSTATUS.NOTVERIFIED)
            // BEGIN, CR00358503, AKr
            && !caseDetails.caseTypeCode
              .equals(CASETYPECODE.PARTICIPANTDATACASE)
            // END, CR00358503
            && !caseDetails.statusCode.equals(CASESTATUS.CLOSED)
            && !caseDetails.statusCode.equals(CASESTATUS.SUSPENDED)
            && !verificationEngineHook.skipVerificationCheck(caseHeaderKey,
              evidenceDescriptorKey)) {
            // END, CR00260117, CR00354770

            concernRoleKey.concernRoleID =
              readEvidenceTypeParticipantDetails.participantID;
            concernRoleNameDetails =
              concernRoleObj.readConcernRoleName(concernRoleKey);

            if (errorMessage.length() != 0) {

              // BEGIN, CR00222190, ELG
              errorMessage = errorMessage
                + INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale());
              // END, CR00222190

              errorMessage = errorMessage + kSpace;
            }

            errorMessage = concernRoleNameDetails.concernRoleName;

            // BEGIN, CR00222190, ELG
            errorMessage =
              errorMessage + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
                .getMessageText(TransactionInfo.getProgramLocale());
            // END, CR00222190

            errorMessage = errorMessage + kSpace;

            verifiableDataItemKey.verifiableDataItemID =
              vDIEDLinkIDAndDataItemIDDetailsList.dtls
                .item(k).verifiableDataItemID;

            final String verifiableItemNameCode =
              verifiableDataItem.readNameByID(verifiableDataItemKey).name;

            errorMessage = errorMessage + readCodeTableItemDescription(
              verifiableItemNameCode, VERIFIABLEITEMNAME.TABLENAME);

          } // END OF ELSE
        } // END OF FOR
      } // end of K for

      if (errorMessage.length() != 0) {

        appException.arg(errorMessage);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      } // end of if
    } // end of j for loop
  }

  // ___________________________________________________________________________
  /**
   * This method verifies the Product delivery verifications.
   *
   * @param key
   * identifies the record
   */
  @Override
  public void verifyPDVerifications(final CaseKey key)
    throws AppException, InformationalException {

    final CaseIDAndStatusCodeKey caseIDAndStatusCodeKey =
      new CaseIDAndStatusCodeKey();

    // EvidenceDescriptor variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    ReadEvidenceTypeParticipantDetailsList readEvidenceTypeParticipantDetailsList =
      new ReadEvidenceTypeParticipantDetailsList();
    final EvidenceTypeAndParticipantDetailsListDetails evidenceTypeAndParticipantDetailsListDetails =
      new EvidenceTypeAndParticipantDetailsListDetails();

    // CaseHeader variables
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // read integrated case ID
    caseKey.caseID = key.key.caseID;
    caseHeader.readIntegratedCaseIDByCaseID(caseKey);
    caseIDAndStatusCodeKey.caseID =
      caseHeader.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;

    caseIDAndStatusCodeKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    final CaseIDParticipantRoleTypesStatusCode caseIDParticipatnRoleTypesStatusCode =
      new CaseIDParticipantRoleTypesStatusCode();

    caseIDParticipatnRoleTypesStatusCode.caseID =
      caseHeader.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;
    caseIDParticipatnRoleTypesStatusCode.caseParticipantRoleType1 =
      CASEPARTICIPANTROLETYPE.MEMBER;
    caseIDParticipatnRoleTypesStatusCode.caseParticipantRoleType2 =
      CASEPARTICIPANTROLETYPE.PRIMARY;
    caseIDParticipatnRoleTypesStatusCode.evidenceDescStatus =
      EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    caseIDParticipatnRoleTypesStatusCode.productCaseID = key.key.caseID;

    // get the Participant details list
    readEvidenceTypeParticipantDetailsList =
      evidenceDescriptor.searchActiveByCaseIDPDParticipantRoleTypes(
        caseIDParticipatnRoleTypesStatusCode);

    evidenceTypeAndParticipantDetailsListDetails.listDtls =
      readEvidenceTypeParticipantDetailsList;

    // Passing the details to performVerification to check the verification
    // status
    // BEGIN, CR00379191, AKr
    checkMandatoryVerificationsForPD(
      evidenceTypeAndParticipantDetailsListDetails, caseKey);
    // END, CR00379191

    // BEGIN, CR00414265, AKr
    final boolean usePDWaiversForIC = Configuration
      .getBooleanProperty(EnvVars.ENV_CONSIDER_PRODUCTID_FOR_IC_WAIVERS);

    if (usePDWaiversForIC) {
      final ConcernRoleIDList concernRoleIDList =
        verificationUtilities.getAdditionalCaseParticipants(caseKey);

      for (final ConcernRoleID concernRoleID : concernRoleIDList.dtls) {
        final CaseIDParticipantIDStatusCode caseIDParticipantIDStatusCode =
          new CaseIDParticipantIDStatusCode();

        caseIDParticipantIDStatusCode.caseID = caseIDAndStatusCodeKey.caseID;
        caseIDParticipantIDStatusCode.participantID =
          concernRoleID.concernRoleID;
        final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
          evidenceDescriptor
            .searchActiveByCaseIDParticipantID(caseIDParticipantIDStatusCode);

        for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls) {
          final ReadEvidenceTypeParticipantDetails details =
            new ReadEvidenceTypeParticipantDetails();

          details.evidenceDescriptorID =
            evidenceDescriptorDtls.evidenceDescriptorID;
          details.evidenceType = evidenceDescriptorDtls.evidenceType;
          details.participantID = evidenceDescriptorDtls.participantID;
          evidenceTypeAndParticipantDetailsListDetails.listDtls.dtls
            .addRef(details);
        }
      }
      checkICVerificationsforPD(evidenceTypeAndParticipantDetailsListDetails,
        caseKey);
    }
    // END, CR00414265
    // BEGIN, CR000018571, VM
    checkForInformationals();
    // END, CR00018571
    // END HARP 62331
  }

  // ___________________________________________________________________________
  /**
   * To check Mandatory Verification is satisfied before the associated
   * evidence is activated.
   *
   * @param key
   * identifies the records
   * @param list
   * evidence key list
   */
  @Override
  public void verifyStatus(final CaseKey key, final EIEvidenceKeyList list)
    throws AppException, InformationalException {

    // Evidence variables
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    ReadEvidenceTypeParticipantDetailsList readEvidenceTypeParticipantDetailsList =
      new ReadEvidenceTypeParticipantDetailsList();
    final EvidenceTypeAndParticipantDetailsListDetails evidenceTypeAndParticipantDetailsListDetails =
      new EvidenceTypeAndParticipantDetailsListDetails();

    // BEGIN, CR00350138, RPB
    // To iterate EIEvidenceKeyList
    for (int i = 0; i < list.dtls.size(); i++) {
      final CaseRelatedIDTypeStatusKey caseRelatedIDTypeStatusKey =
        new CaseRelatedIDTypeStatusKey();

      caseRelatedIDTypeStatusKey.caseID = key.key.caseID;
      caseRelatedIDTypeStatusKey.evidenceType =
        list.dtls.item(i).evidenceType;
      caseRelatedIDTypeStatusKey.relatedID = list.dtls.item(i).evidenceID;
      caseRelatedIDTypeStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
      readEvidenceTypeParticipantDetailsList = evidenceDescriptor
        .searchEvidenceByCaseRelatedIDTypeStatus(caseRelatedIDTypeStatusKey);
      evidenceTypeAndParticipantDetailsListDetails.listDtls =
        readEvidenceTypeParticipantDetailsList;
      // END, CR00350138
      // Passing the Participant details to performVerification to verify
      // the
      // verification status.
      performVerification(evidenceTypeAndParticipantDetailsListDetails);
    } // end of i for loop

  }// end of Verify Status

  // ___________________________________________________________________________
  /**
   * Checks if usage list contains the requirement key passed.
   *
   * @param verificationRequirementIDStatusDetailsList
   * The usage list
   * @param verificationRequirementKey
   * contains requirement id to be searched in the usage list
   *
   * @return An indicator which is true if the list passed in contained the
   * specified requirement key.
   */
  @Override
  public ContainsInd containsRequirement(
    final VerificationRequirementIDStatusDetailsList verificationRequirementIDStatusDetailsList,
    final VerificationRequirementKey verificationRequirementKey)
    throws AppException, InformationalException {

    final ContainsInd containsInd = new ContainsInd();

    containsInd.contains = false;

    for (int i = 0; i < verificationRequirementIDStatusDetailsList.dtls
      .size(); i++) {

      if (verificationRequirementIDStatusDetailsList.dtls.item(
        i).verificationRequirementID == verificationRequirementKey.verificationRequirementID) {

        containsInd.contains = true;

        containsInd.verificationStatus =
          verificationRequirementIDStatusDetailsList.dtls
            .item(i).verificationStatus;

      }
    }

    return containsInd;
  }

  // ___________________________________________________________________________
  /**
   * Inserts the verification for the newly added product delivery.
   *
   * @param key
   * evidence descriptor key
   */
  @Override
  public void insertVerification(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    // Get the EvidenceInterface based on the evidenceType
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();
    final EIEvidenceKey eievidenceKey = new EIEvidenceKey();
    final EvidenceMap map = EvidenceController.getEvidenceMap();
    final EIEvidenceInsertDtls eiEvidenceInsertDtls =
      new EIEvidenceInsertDtls();
    EvidenceDescriptorDtls evidenceDescriptorDtls =
      new EvidenceDescriptorDtls();

    // To do insert Verification
    evidenceDescriptorDtls = evidenceDescriptor.read(key);
    eievidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    eievidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;

    // BEGIN, CR00059540, POH
    final StandardEvidenceInterface standardEvidenceInterface =
      map.getEvidenceType(evidenceTypeKey.evidenceType);

    eiEvidenceInsertDtls.evidenceObject =
      standardEvidenceInterface.readEvidence(eievidenceKey);
    // END, CR00059540

    verifyOnInsert(evidenceDescriptorDtls, eiEvidenceInsertDtls);

  }

  // ___________________________________________________________________________
  /**
   * This builds informational message.
   *
   * @param key
   * contains details required to build an informational
   *
   * @return The informational message
   */
  @Override
  public ErrorMessageDetails
    buildMessage(final ParticipantIDVerifiableDataItemIDKey key)
      throws AppException, InformationalException {

    final StringBuffer errorMessage = new StringBuffer();

    // concern role variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // VerifiableDataItem variables
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();

    concernRoleKey.concernRoleID = key.participantID;
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    if (errorMessage.length() != 0) {

      // BEGIN, CR00222190, ELG
      errorMessage
        .append(INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
          .getMessageText(TransactionInfo.getProgramLocale()));
      // END, CR00222190

      errorMessage.append(kSpace);

    }

    errorMessage.append(concernRoleNameDetails.concernRoleName);
    // BEGIN, CR00222190, ELG
    errorMessage.append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText(TransactionInfo.getProgramLocale()));
    // END, CR00222190
    errorMessage.append(kSpace);

    verifiableDataItemKey.verifiableDataItemID = key.verifiableDataItemID;
    final String verifiableItemNameCode =
      verifiableDataItem.readNameByID(verifiableDataItemKey).name;

    errorMessage.append(readCodeTableItemDescription(verifiableItemNameCode,
      VERIFIABLEITEMNAME.TABLENAME));

    final ErrorMessageDetails errorMessageDetails = new ErrorMessageDetails();

    errorMessageDetails.errorMessage = errorMessage.toString();

    return errorMessageDetails;

  }

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * The method raises events for the specified event type.
   *
   * @param verificationKey
   * The Verification key
   * @param eventType
   * The event type
   */

  @Override
  public void raiseEvent(
    final curam.verification.sl.infrastructure.entity.struct.VerificationKey verificationKey,
    final String eventType) throws AppException, InformationalException {

    // raise workflow event for the event type specified
    final Event workflowEvent = new Event();

    workflowEvent.eventKey.eventClass =
      VerificationConst.gkVerificationEventClass;
    workflowEvent.eventKey.eventType = eventType;
    workflowEvent.primaryEventData = verificationKey.verificationID;

    EventService.raiseEvent(workflowEvent);
  }

  // END, CR00021355

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * When evidence is deleted, event is triggered.
   *
   * @param key
   * EvidenceDescriptor key
   */
  @Override
  public void verifyOnRemoval(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00427051, AKr
    final CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList =
      CurrentPostponedVerificationFactory.newInstance()
        .searchByEvidenceDescriptorID(key);
    final CurrentPostponedVerificationKey currentPostponedVerificationKey =
      new CurrentPostponedVerificationKey();

    for (final CurrentPostponedVerificationDtls currentPostponedVerificationDtls : currentPostponedVerificationDtlsList.dtls
      .items()) {
      currentPostponedVerificationKey.currentPostponedVerificationID =
        currentPostponedVerificationDtls.currentPostponedVerificationID;
      CurrentPostponedVerificationFactory.newInstance()
        .remove(currentPostponedVerificationKey);
    }
    // END, CR00427051
    // if no verification record don't raise event
    if (VDIEDLinkFactory.newInstance().readByEvidenceDescriptor(key).dtls
      .size() == 0) {

      return;
    }

    // BEGIN, CR00059934, MPB
    // Replaced event Class and event Type data files with event files

    // Trigger evidence deleted event
    final Event evidenceDeletedEvent = new Event();

    evidenceDeletedEvent.eventKey = curam.events.Verification.EvidenceDeleted;
    evidenceDeletedEvent.primaryEventData = key.evidenceDescriptorID;

    // END, CR00059934, MPB

    EventService.raiseEvent(evidenceDeletedEvent);
  }

  // END, CR00021355

  // BEGIN, CR00018571, VM
  // ___________________________________________________________________________
  /**
   * Localized function for checking if the Informational Manager contains
   * errors and / or fatal errors. The failOperation is called in these
   * instances which will render the errors on the client.
   */
  @Override
  public void checkForInformationals()
    throws AppException, InformationalException {

    // BEGIN, CR00071012, GM
    // BEGIN, CR00220422, PF
    final LinkedList<InformationalElement> list = TransactionInfo
      .getInformationalManager().getMessagesForField(CuramConst.gkEmpty);

    // END, CR00071012

    for (int i = 0; i < list.size(); i++) {

      final InformationalElement element = list.get(i);

      // END, CR00220422

      if (element.getInformationalType()
        .equals(InformationalElement.InformationalType.kError)
        || element.getInformationalType()
          .equals(InformationalElement.InformationalType.kFatalError)) {

        TransactionInfo.getInformationalManager().failOperation();
      }

    }

  }

  // END, CR00018571

  /**
   * Operation to list Verification items for an Evidence Workspace.
   *
   * @param key
   * Key containing the caseID and evidenceType
   *
   * @return EvidenceVerificationListDetails
   */
  @Override
  public EvidenceVerificationDetailsList
    listVerificationForEvidenceWorkspace(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    return curam.verification.sl.infrastructure.fact.VerificationFactory
      .newInstance().listEvidenceVerificationDetails(key);
  }

  // BEGIN, CR00242523, CSH
  /**
   * Operation to list Outstanding Verification items for an Evidence
   * Workspace.
   *
   * @param key
   * Key containing the caseID and evidenceType
   *
   * @return EvidenceVerificationListDetails
   */
  @Override
  public EvidenceVerificationDetailsList
    listOutstandingVerificationForEvidenceWorkspace(
      final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    EvidenceVerificationDetailsList outstandingVerificationList =
      new EvidenceVerificationDetailsList();

    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    outstandingVerificationList =
      verificationObj.listEvidenceVerificationDetails(key);

    for (int i = 0; i < outstandingVerificationList.verificationDtls
      .size(); i++) {
      // BEGIN, CR00349192, PB
      if (VERIFICATIONSTATUSEntry.VERIFIED.getCode()
        .equals(outstandingVerificationList.verificationDtls
          .item(i).verificationStatus)) {
        // END, CR00349192
        outstandingVerificationList.verificationDtls.remove(i);
        i--;
      }
    }

    return outstandingVerificationList;
  }

  // END, CR00242523

  // BEGIN, CR00075875, JPG
  // ___________________________________________________________________________
  /**
   * Method to verify modifications of participant data at the participant
   * level. This method can not be used to verify modifications of participant
   * data at the integrated case or product delivery level.
   *
   * @param evidenceDescriptorDtls
   * - This evidence descriptor is related to participant data at
   * the participant level only. It has no caseID.
   * @param eiEvidenceModifyDtls
   * - EIEvidence modify details
   */
  protected void verifyOnModifyForParticipantData(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    VerificationStatusDetails verificationStatusDetails =
      new VerificationStatusDetails();

    // Check to see if any new requirement usages have been added since
    // the evidence was last inserted or modified
    checkUsagesForVerificationRequirements(evidenceDescriptorDtls);

    // check if any verification records are not inserted
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    final VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkDtlsList =
      vdIEDLinkObj.readByEvidenceDescriptorID(evidenceDescriptorKey);

    if (vDIEDLinkDtlsList.dtls.size() == 0) {
      // check if any verification requirements exists, if so insert
      // records
      // insertInEditEvidenceVerification(evidenceDescriptorDtls,
      // eiEvidenceModifyDtls, eiEvidenceReadDtls);
      final EIEvidenceInsertDtls eiEvidenceInsertDtls =
        new EIEvidenceInsertDtls();

      eiEvidenceInsertDtls.evidenceObject =
        eiEvidenceModifyDtls.evidenceObject;
      eiEvidenceInsertDtls.parentKey = eiEvidenceModifyDtls.parentKey;
      verifyOnInsert(evidenceDescriptorDtls, eiEvidenceInsertDtls);
      return;
    }

    // BEGIN, CR00386928, RD
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();
    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();
    final DependentDataItem dependentDataItemObj =
      DependentDataItemFactory.newInstance();
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();
    final VDIEDLinkDtls vDIEDLinkDtls = new VDIEDLinkDtls();

    // END, CR00386928

    for (int i = 0; i < vDIEDLinkDtlsList.dtls.size(); i++) {

      vDIEDLinkKey.VDIEDLinkID = vDIEDLinkDtlsList.dtls.item(i).vDIEDLinkID;

      verificationStatusDetails =
        verification.getVerificationStatus(vDIEDLinkKey);

      // if the evidence was verified we want to reverify. We cancel the
      // old
      // verification and insert a new one. If it was not verified we do
      // nothing
      if (verificationStatusDetails.verificationStatus
        .equals(VERIFICATIONSTATUS.VERIFIED)) {

        // BEGIN, CR00081175, JPG
        // Read the list of data items for the evidence type
        verifiableDataItemKey.verifiableDataItemID =
          vDIEDLinkDtlsList.dtls.item(i).verifiableDataItemID;

        // check the data item in verification data item details list
        verifiableDataItemDataItemNameAndIDDetails = verifiableDataItemObj
          .searchDataItemNameAndIDByVerifiableDataItem(verifiableDataItemKey);

        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .addRef(verifiableDataItemDataItemNameAndIDDetails);

        // BEGIN, CR00191839, ND
        if (!checkDataItemInList(evidenceDescriptorDtls.evidenceType,
          eiEvidenceModifyDtls, eiEvidenceReadDtls,
          verifiableDataItemDataItemNameAndIDDetailsList)) {
          // END, CR00191839 , ND

          // If data item is not present in verifiable data item list
          // then check
          // the data item in dependent data item.
          verifiableDataItemDataItemNameAndIDDetailsList =
            dependentDataItemObj.searchDataItemNameAndIDByVerifiableDataItem(
              verifiableDataItemKey);

          // BEGIN, CR00191839, ND
          if (!checkDataItemInList(evidenceDescriptorDtls.evidenceType,
            eiEvidenceModifyDtls, eiEvidenceReadDtls,
            verifiableDataItemDataItemNameAndIDDetailsList)) {
            // END, CR00191839, ND
            continue;
          }
        }
        // END, CR00081175

        verificationICTypeAndRelatedItemDetails.relatedItemID =
          VERIFICATIONTYPE.NONCASEDATA;
        verificationICTypeAndRelatedItemDetails.relatedItemType =
          NONCASEDATATYPE.PARTICIPANT;

        vDIEDLinkDtls.evidenceDescriptorID =
          evidenceDescriptorDtls.evidenceDescriptorID;
        vDIEDLinkDtls.VDIEDLinkID =
          vDIEDLinkDtlsList.dtls.item(i).vDIEDLinkID;
        vDIEDLinkDtls.verifiableDataItemID =
          vDIEDLinkDtlsList.dtls.item(i).verifiableDataItemID;

        reVerifyAtParticipantLevel(vDIEDLinkDtls,
          verificationICTypeAndRelatedItemDetails, evidenceDescriptorDtls);

      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to reVerify at the participant level. This method is called during
   * the modify. It cancels any old verifications associated with participant
   * evidence. It also cancels any verification items provided. A new
   * verification is then inserted and is pointed to by the same VDILink.
   *
   * @param dtls
   * - VDIEDLinkDtls for the participant evidence in question
   *
   * @param verificationICTypeAndRelatedItemDetails
   * - Contains the relatedID and relatedType
   *
   * @param evidenceDescriptorDtls
   * - The evidence descriptor for the participant evidence we are
   * dealing with
   */
  @Override
  protected void reVerifyAtParticipantLevel(final VDIEDLinkDtls dtls,
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails,
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final Verification verificationObj = VerificationFactory.newInstance();
    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

    vDIEDLinkKey.VDIEDLinkID = dtls.VDIEDLinkID;

    // BEGIN,

    // The VDILINK key you are passing in is for the participant evidence
    // descriptor for the data item in question.
    final VerificationDtlsList verificationDtlsList =
      verificationObj.searchActiveVerificationByVDIEDLinkID(vDIEDLinkKey);
    final VerificationStatusDetails verificationStatusDtls =
      new VerificationStatusDetails();
    final VerificationItemProvided verificationItemProvidedObj =
      VerificationItemProvidedFactory.newInstance();
    VerificationItemProvidedDtlsList verificationItemProvidedClonedDtlsList =
      new VerificationItemProvidedDtlsList();
    final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
      new VDIEDLinkIDAndStatusKey();
    final VerificationItemProvidedDtls verificationItemProvidedDtls =
      new VerificationItemProvidedDtls();
    final VerificationItemProvidedKey verificationItemProvidedKey =
      new VerificationItemProvidedKey();

    // END, RD

    for (int i = 0; i < verificationDtlsList.dtls.size(); i++) {

      // Set the status
      verificationStatusDtls.verificationStatus =
        VERIFICATIONSTATUS.CANCELLED;

      // Set the key for the cancelled record
      final VerificationKey verificationkey = new VerificationKey();

      verificationkey.verificationID =
        verificationDtlsList.dtls.item(i).verificationID;

      verificationObj.modifyVerificationStatus(verificationkey,
        verificationStatusDtls);
    }

    // Cancel and verification items provided related to the above
    // verification

    vDIEDLinkIDAndStatusKey.VDIEDLinkID = dtls.VDIEDLinkID;
    vDIEDLinkIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    verificationItemProvidedClonedDtlsList = verificationItemProvidedObj
      .searchByVDIEDLinkIDAndStatus(vDIEDLinkIDAndStatusKey);

    for (int k = 0; k < verificationItemProvidedClonedDtlsList.dtls
      .size(); k++) {

      // Create modified status struct
      verificationItemProvidedDtls
        .assign(verificationItemProvidedClonedDtlsList.dtls.item(k));

      verificationItemProvidedDtls.recordStatus = RECORDSTATUS.CANCELLED;

      // Populate verification Item Provided Key
      verificationItemProvidedKey.verificationItemProvidedID =
        verificationItemProvidedClonedDtlsList.dtls
          .item(k).verificationItemProvidedID;

      verificationItemProvidedObj.modify(verificationItemProvidedKey,
        verificationItemProvidedDtls);

    }

    // Insert a new verification for the participant evidence that has been
    // modified
    final VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();

    verifiableDataItemDataItemNameAndIDDetails.dataItem = null;
    verifiableDataItemDataItemNameAndIDDetails.name = null;
    verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID =
      dtls.verifiableDataItemID;

    final VDIEDLinkDtls vDIEDLinkDtls = new VDIEDLinkDtls();

    vDIEDLinkDtls.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    vDIEDLinkDtls.VDIEDLinkID = dtls.VDIEDLinkID;
    vDIEDLinkDtls.verifiableDataItemID = dtls.verifiableDataItemID;

    insertVerification(evidenceDescriptorDtls,
      verifiableDataItemDataItemNameAndIDDetails, vDIEDLinkDtls,
      verificationICTypeAndRelatedItemDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to verify modifications of participant data at the case and
   * product delivery levels. This method can not be used to verify
   * modifications of participant data at the participant level.
   *
   * @param ineditEvidenceDescriptorDtls
   * - This evidence descriptor is related to participant evidence
   * entity record.
   * @param activeEvidenceDescriptorDtls
   * - This evidence descriptor is related to participant evidence
   * snapshot
   * @param eiEvidenceModifyDtls
   * - EIEvidence modify details
   * @param eiEvidenceReadDtls
   * - EIEvidence read details from the evidence before it was
   * modified
   */

  protected void processActiveParticipantEvidenceVerifications(
    final EvidenceDescriptorDtls ineditEvidenceDescriptorDtls,
    final EvidenceDescriptorDtls activeEvidenceDescriptorDtls,
    final EIEvidenceModifyDtls eiEvidenceModifyDtls,
    final EIEvidenceReadDtls eiEvidenceReadDtls)
    throws AppException, InformationalException {

    // Creates new Active evidence Record - create new verification record
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();

    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    final VerifiableDataItemEvidenceTypeAndStatus verifiableDataItemEvidenceTypeAndStatus =
      new VerifiableDataItemEvidenceTypeAndStatus();

    final VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    // This will hold the newly created vdIEDLinkDtls
    // for the active evidence (snapshot)
    final VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();
    VDIEDLinkDtls ineditVDIEDLinkDtls = new VDIEDLinkDtls();

    // Case header variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    new CaseIDAndProductTypeDetails();

    ReverificationModeRequirementIDDetailsList reverificationModeRequirementIDDetailsList =
      new ReverificationModeRequirementIDDetailsList();

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();

    final DataItemRelatedItemAndStatusDetails dataItemRelatedItemAndStatusDetails =
      new DataItemRelatedItemAndStatusDetails();

    // BEGIN, CR00191839, ND
    // BEGIN, CR00213416, GYH
    final VerificationEvidenceInterface verificationEvidenceImpl =
      VerificationEvidenceFactory.newInstance(
        CASEEVIDENCEEntry.get(ineditEvidenceDescriptorDtls.evidenceType));
    // END, CR00213416
    // END, CR00191839, ND

    String reverificationMode = CuramConst.gkEmpty;
    String dataItem = CuramConst.gkEmpty;

    boolean dataItemChanged = false;
    boolean dependentDataItemChanged = false;

    verifiableDataItemEvidenceTypeAndStatus.evidenceType =
      ineditEvidenceDescriptorDtls.evidenceType;
    verifiableDataItemEvidenceTypeAndStatus.recordStatus =
      RECORDSTATUS.NORMAL;

    // BEGIN, CR00350929, ARM
    // Perform check on case type instead of integrated cases only
    // BEGIN, CR00371307, AKr
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = ineditEvidenceDescriptorDtls.caseID;
    caseHeaderKey.caseID = ineditEvidenceDescriptorDtls.caseID;
    verificationICTypeAndRelatedItemDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    verificationICTypeAndRelatedItemDetails.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00350929

    // Read the list of data items which has requirements for the evidence
    // type
    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      ineditEvidenceDescriptorDtls.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();
    evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
      verificationICTypeAndRelatedItemDetails.relatedItemType;

    verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);

    // BEGIN, CR00386928, RD
    VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey =
      new VerifiableDataItemRelatedIDAndTypeKey();
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails =
      new VerifiableDataItemAndRequirementIDDetails();
    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDependentDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();
    final DependentDataItem dependentDataItemObj =
      DependentDataItemFactory.newInstance();

    // END, CR00386928

    for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
      .size(); i++) {

      dataItem =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).dataItem;

      // If the data item has not been modified or does not exist on this
      // entity
      // BEGIN, CR00191839, ND
      if (!dataItemExists(dataItem, eiEvidenceModifyDtls.evidenceObject,
        ineditEvidenceDescriptorDtls.evidenceType)) {
        continue;
      }
      // END, CR00191839, ND

      verifiableDataItemKey.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      dataItemRelatedItemAndStatusDetails.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      // BEGIN, CR00350929, ARM
      // BEGIN, CR00371307, AKr
      dataItemRelatedItemAndStatusDetails.relatedItemType =
        verificationUtilities.getRelatedItemTypeCode(caseKey);
      dataItemRelatedItemAndStatusDetails.relatedItemID =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00371307

      // END, CR00350929

      boolean isCaseLevelVerificationRequired;

      verifiableDataItemRelatedIDAndTypeKey =
        readVerifiableDataItemRelatedIDAndType(caseHeaderKey);

      verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      isCaseLevelVerificationRequired = isCaseLevelVerificationRequired(
        verifiableDataItemRelatedIDAndTypeKey);

      // The participant level is higher than the case level so we do not
      // want
      // to throw the reverify at the case level
      if (!isCaseLevelVerificationRequired) {
        continue;
      }

      dataItemRelatedItemAndStatusDetails.recordStatus =
        RECORDSTATUS.CANCELLED;

      reverificationModeRequirementIDDetailsList = verificationRequirementObj
        .searchAllByVerifiableDataItemID(dataItemRelatedItemAndStatusDetails);

      verifiableDataItemDataItemNameAndIDDetails =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i);

      verifiableDataItemAndRequirementIDDetails.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;

      // Insert VDIEDLink for the active evidence descriptor
      insertVDIEDLink(activeEvidenceDescriptorDtls, vdIEDLinkDtls,
        verifiableDataItemDataItemNameAndIDDetails);

      for (int j = 0; j < reverificationModeRequirementIDDetailsList.dtls
        .size(); j++) {

        reverificationMode = reverificationModeRequirementIDDetailsList.dtls
          .item(j).reverificationMode;

        verifiableDataItemAndRequirementIDDetails.verificationRequirementID =
          reverificationModeRequirementIDDetailsList.dtls
            .item(j).verificationRequirementID;

        if (reverificationMode.equals(REVERIFICATIONMODE.NEVERREVERIFY)) {

          // This method copies the verifications and verification
          // items
          // provided to the active record from the in edit. The
          // reason for this
          // is because the active is a snapshot and does not have a
          // history.
          // The records on the in edit are then cancelled.
          ineditVDIEDLinkDtls =
            createVerificationsForActiveParticipantEvidence(
              ineditEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);

          // The verifications and verification items provided are now
          // cloned
          // for the in edit evidence which points to the participant
          // entity.
          cloneExistingVerification(activeEvidenceDescriptorDtls,
            verifiableDataItemAndRequirementIDDetails, eiEvidenceReadDtls,
            ineditVDIEDLinkDtls);

        } else if (reverificationMode
          .equals(REVERIFICATIONMODE.REVERIFYALWAYS)) {

          ineditVDIEDLinkDtls =
            createVerificationsForActiveParticipantEvidence(
              ineditEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);

          // Insert Verification
          insertVerification(ineditEvidenceDescriptorDtls,
            verifiableDataItemAndRequirementIDDetails, ineditVDIEDLinkDtls,
            verificationICTypeAndRelatedItemDetails);

        } else {

          // Check if a value has been modified
          dependentDataItemChanged = false;

          dataItem = verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).dataItem;

          // BEGIN, CR00191839, ND
          dataItemChanged = verificationEvidenceImpl
            .checkDataItemValueChanged(dataItem, eiEvidenceModifyDtls,
              eiEvidenceReadDtls, ineditEvidenceDescriptorDtls.evidenceType);
          // END, CR00191839, ND

          if (!dataItemChanged) {

            // Get all dependent data items by verifiable data item
            verifiableDependentDataItemDataItemNameAndIDDetailsList =
              dependentDataItemObj
                .searchDataItemNameAndIDByVerifiableDataItem(
                  verifiableDataItemKey);

            for (int k =
              0; k < verifiableDependentDataItemDataItemNameAndIDDetailsList.dtls
                .size(); k++) {

              dataItem =
                verifiableDependentDataItemDataItemNameAndIDDetailsList.dtls
                  .item(k).dataItem;

              // BEGIN, CR00191839, ND
              dataItemChanged =
                verificationEvidenceImpl.checkDataItemValueChanged(dataItem,
                  eiEvidenceModifyDtls, eiEvidenceReadDtls,
                  ineditEvidenceDescriptorDtls.evidenceType);
              // END, CR00191839, ND

              if (dataItemChanged) {

                dependentDataItemChanged = true;
              }
            }

          }

          if (dataItemChanged || dependentDataItemChanged) {

            ineditVDIEDLinkDtls =
              createVerificationsForActiveParticipantEvidence(
                ineditEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);

            // Insert Verification
            insertVerification(ineditEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, ineditVDIEDLinkDtls,
              verificationICTypeAndRelatedItemDetails);

          } else {

            ineditVDIEDLinkDtls =
              createVerificationsForActiveParticipantEvidence(
                ineditEvidenceDescriptorDtls,
                verifiableDataItemAndRequirementIDDetails, vdIEDLinkDtls);

            // BEGIN, CR00080502, JPG
            cloneExistingVerification(activeEvidenceDescriptorDtls,
              verifiableDataItemAndRequirementIDDetails, eiEvidenceReadDtls,
              ineditVDIEDLinkDtls);
            // END, CR00080502
          }

        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to return the relatedID and type for a caseID.
   *
   * @param key
   * - The caseID of the product delivery or integrated case in
   * question
   */
  @Override
  protected VerifiableDataItemRelatedIDAndTypeKey
    readVerifiableDataItemRelatedIDAndType(final CaseHeaderKey key)
      throws AppException, InformationalException {

    // Populate the key needed to compare the levels of case and participant
    // Verification
    final VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey =
      new VerifiableDataItemRelatedIDAndTypeKey();

    // BEGIN, CR00350929, ARM
    // BEGIN, CR00371307, AKr
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseID;
    verifiableDataItemRelatedIDAndTypeKey.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    verifiableDataItemRelatedIDAndTypeKey.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00350929
    return verifiableDataItemRelatedIDAndTypeKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to clone existing verifications for participant evidence from the
   * In Edit participant evidence to the Active participant Evidence. This is
   * required because after the modify the active record is simply a snapshot
   * of the participant evidence before it was modified. No verifications
   * point to it.
   *
   * @param evidenceDescriptorDtls
   * - This evidence descriptor is related to participant evidence.
   * @param verifiableDataItemRequirementIDDetails
   * - Contains the verifiable data item identifier
   * @param activeVDIEDLinkDtls
   * - EIEvidence read details from the evidence before it was
   * modified
   */
  @Override
  protected VDIEDLinkDtls createVerificationsForActiveParticipantEvidence(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemRequirementIDDetails,
    final VDIEDLinkDtls activeVDIEDLinkDtls)
    throws AppException, InformationalException {

    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID =
      verifiableDataItemRequirementIDDetails.verifiableDataItemID;

    // This returns the VDIEDLinkDtls for the in edit participant evidence
    // descriptor which is associated with the participant entity in
    // question
    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    VDIEDLinkDtls ineditVDIEDLinkDtls = new VDIEDLinkDtls();

    final DataItemIDAndDescriptorDetails dataItemIDAndDescriptorDetails =
      new DataItemIDAndDescriptorDetails();

    dataItemIDAndDescriptorDetails.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    dataItemIDAndDescriptorDetails.verifiableDataItemID =
      verifiableDataItemKey.verifiableDataItemID;

    ineditVDIEDLinkDtls =
      vdIEDLinkObj.readVDIEDLinkDtlsByDataItemAndDescriptorID(
        dataItemIDAndDescriptorDetails);

    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

    vDIEDLinkKey.VDIEDLinkID = ineditVDIEDLinkDtls.VDIEDLinkID;

    // Read for any verification records associated with the in edit
    // evidence VDIEDLink
    final Verification verificationObj = VerificationFactory.newInstance();
    final VerificationDtlsList verificationDtlsList =
      verificationObj.readByVDIEDLinkID(vDIEDLinkKey);

    for (int i = 0; i < verificationDtlsList.dtls.size(); i++) {

      if (verificationDtlsList.dtls.item(i).verificationStatus
        .equals(VERIFICATIONSTATUS.CANCELLED)) {
        continue;
      }

      final VerificationDtls verificationDtls = new VerificationDtls();

      // Copy the verification details
      verificationDtls.assign(verificationDtlsList.dtls.item(i));

      // Set the VDIEDLinkID on the new record to be that of the
      // VDIEDLink record passed in which is the new VDIEDLink
      // Created for the snapshot record
      verificationDtls.VDIEDLinkID = activeVDIEDLinkDtls.VDIEDLinkID;

      // Insert the the copied verification which is now associated with
      // the snapshot evidence. This is pointed to by the Active evidence
      // descriptor
      final VerificationKey verificationKey = new VerificationKey();

      verificationObj.insert(verificationDtls);

      verificationKey.verificationID = verificationDtls.verificationID;

      // Set the status on the in edit verification to cancelled
      final VerificationKey oldVerificationKey = new VerificationKey();

      oldVerificationKey.verificationID =
        verificationDtlsList.dtls.item(i).verificationID;

      // Set the status
      final VerificationStatusDetails verificationStatusDetails =
        new VerificationStatusDetails();

      verificationStatusDetails.verificationStatus =
        VERIFICATIONSTATUS.CANCELLED;

      verificationObj.modifyVerificationStatus(oldVerificationKey,
        verificationStatusDetails);

    }

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
      new VDIEDLinkIDAndStatusKey();

    vDIEDLinkIDAndStatusKey.VDIEDLinkID = ineditVDIEDLinkDtls.VDIEDLinkID;
    vDIEDLinkIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    final VerificationItemProvidedDtlsList verificationItemProvidedDtlsList =
      verificationItemProvided
        .searchByVDIEDLinkIDAndStatus(vDIEDLinkIDAndStatusKey);

    // iterate through each of the record and update its VDIEDLinkID to
    // point
    // to the VDIEDLinkID record associated with the active snapshot
    // evidence
    // descriptor
    for (int i = 0; i < verificationItemProvidedDtlsList.dtls.size(); i++) {

      VerificationItemProvidedDtls verificationItemProvidedDtls =
        new VerificationItemProvidedDtls();

      verificationItemProvidedDtls
        .assign(verificationItemProvidedDtlsList.dtls.item(i));

      // Set the VDIEDLinkID of the new record to the VDIEDLinkID of the
      // VDIEDLink record that was created and associated with the active
      // evidence descriptor
      verificationItemProvidedDtls.VDIEDLinkID =
        activeVDIEDLinkDtls.VDIEDLinkID;

      verificationItemProvided.insert(verificationItemProvidedDtls);

      // Set the status on the in edit verificationItemProvided to
      // cancelled
      final VerificationItemProvidedKey oldVerificationItemProvidedKey =
        new VerificationItemProvidedKey();

      // Create the modified record with a status of cancelled
      verificationItemProvidedDtls = new VerificationItemProvidedDtls();
      verificationItemProvidedDtls
        .assign(verificationItemProvidedDtlsList.dtls.item(i));
      verificationItemProvidedDtls.recordStatus = RECORDSTATUS.CANCELLED;

      // Populate the key of the record to be cancelled
      oldVerificationItemProvidedKey.verificationItemProvidedID =
        verificationItemProvidedDtlsList.dtls
          .item(i).verificationItemProvidedID;

      verificationItemProvided.modify(oldVerificationItemProvidedKey,
        verificationItemProvidedDtls);

    }

    return ineditVDIEDLinkDtls;
  }

  // END, CR00075875

  // BEGIN, CR00076353,AL
  // ___________________________________________________________________________
  /**
   * Localized function for checking if case level verification required. A
   * search is performed to return participant level verification for the
   * specified verification data item, and for the specified relatedItemID and
   * relatedItemType (case or product delivery). If the verification level of
   * the specified relatedItemID and relatedItemType (case or product
   * delivery) is greater than the participant verification level value true
   * is returned, otherwise false.
   *
   * @param verifiableDataItemRelatedIDAndTypeKey
   * verifiableDataItemRelatedIDAndTypeKey key - relatedItemID
   * relatedItemType
   *
   * verifiableDataItemID
   *
   * @return boolean - true / false
   */
  protected boolean isCaseLevelVerificationRequired(
    final VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    // participant
    SearchDueDaysDueDateFromAndRequirementIDList participantLevelVerificationRequirementsList =
      new SearchDueDaysDueDateFromAndRequirementIDList();

    // case
    SearchDueDaysDueDateFromAndRequirementIDList caseLevelVerificationRequirementsList =
      new SearchDueDaysDueDateFromAndRequirementIDList();

    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForParticipant =
      new VerifiableDataItemAndStatusKey();

    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForCase =
      new VerifiableDataItemAndStatusKey();

    // Participant parameters - verifiableDataItemAndStatusKeyForParticipant
    verifiableDataItemAndStatusKeyForParticipant.verifiableDataItemID =
      verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID;
    verifiableDataItemAndStatusKeyForParticipant.recordStatus =
      RECORDSTATUS.CANCELLED;
    verifiableDataItemAndStatusKeyForParticipant.relatedItemID =
      VERIFICATIONTYPE.NONCASEDATA;
    verifiableDataItemAndStatusKeyForParticipant.relatedItemType =
      NONCASEDATATYPE.PARTICIPANT;

    verifiableDataItemAndStatusKeyForParticipant.currentDate =
      Date.getCurrentDate();

    // search data items for participant type
    participantLevelVerificationRequirementsList = verificationRequirementObj
      .searchRequirementsByDataItemIDAndRelatedItemID(
        verifiableDataItemAndStatusKeyForParticipant);

    // Case parameter - verifiableDataItemAndStatusKeyForCase
    verifiableDataItemAndStatusKeyForCase.verifiableDataItemID =
      verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID;
    verifiableDataItemAndStatusKeyForCase.recordStatus =
      RECORDSTATUS.CANCELLED;
    verifiableDataItemAndStatusKeyForCase.relatedItemID =
      verifiableDataItemRelatedIDAndTypeKey.relatedItemID;
    verifiableDataItemAndStatusKeyForCase.relatedItemType =
      verifiableDataItemRelatedIDAndTypeKey.relatedItemType;

    verifiableDataItemAndStatusKeyForCase.currentDate = Date.getCurrentDate();

    // search data items for integrated case type
    caseLevelVerificationRequirementsList = verificationRequirementObj
      .searchRequirementsByDataItemIDAndRelatedItemID(
        verifiableDataItemAndStatusKeyForCase);

    // BEGIN, CR00077149,AL
    // ensure lists have at least one record
    if (caseLevelVerificationRequirementsList.dtls.size() > 0
      && participantLevelVerificationRequirementsList.dtls.size() > 0) {

      return true;

    } // if case level verification exists & no participant level
    // verifications
    // exists, return true, case level verifications required
    else if (caseLevelVerificationRequirementsList.dtls.size() > 0
      && participantLevelVerificationRequirementsList.dtls.size() == 0) {
      return true;
    }

    return false;
    // END, CR00077149
  }

  protected boolean isCaseLevelVerificationRequired(
    final VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey,
    final Long verifiableDataItemID,
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    // participant
    SearchDueDaysDueDateFromAndRequirementIDList participantLevelVerificationRequirementsList =
      new SearchDueDaysDueDateFromAndRequirementIDList();

    // case
    SearchDueDaysDueDateFromAndRequirementIDList caseLevelVerificationRequirementsList =
      new SearchDueDaysDueDateFromAndRequirementIDList();

    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForParticipant =
      new VerifiableDataItemAndStatusKey();

    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForCase =
      new VerifiableDataItemAndStatusKey();

    // Participant parameters - verifiableDataItemAndStatusKeyForParticipant
    verifiableDataItemAndStatusKeyForParticipant.verifiableDataItemID =
      verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID;
    verifiableDataItemAndStatusKeyForParticipant.recordStatus =
      RECORDSTATUS.CANCELLED;
    verifiableDataItemAndStatusKeyForParticipant.relatedItemID =
      VERIFICATIONTYPE.NONCASEDATA;
    verifiableDataItemAndStatusKeyForParticipant.relatedItemType =
      NONCASEDATATYPE.PARTICIPANT;

    verifiableDataItemAndStatusKeyForParticipant.currentDate =
      Date.getCurrentDate();

    // search data items for participant type
    participantLevelVerificationRequirementsList = verificationRequirementObj
      .searchRequirementsByDataItemIDAndRelatedItemID(
        verifiableDataItemAndStatusKeyForParticipant);

    // Case parameter - verifiableDataItemAndStatusKeyForCase
    verifiableDataItemAndStatusKeyForCase.verifiableDataItemID =
      verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID;
    verifiableDataItemAndStatusKeyForCase.recordStatus =
      RECORDSTATUS.CANCELLED;
    verifiableDataItemAndStatusKeyForCase.relatedItemID =
      verifiableDataItemRelatedIDAndTypeKey.relatedItemID;
    verifiableDataItemAndStatusKeyForCase.relatedItemType =
      verifiableDataItemRelatedIDAndTypeKey.relatedItemType;

    verifiableDataItemAndStatusKeyForCase.currentDate = Date.getCurrentDate();

    // search data items for integrated case type
    caseLevelVerificationRequirementsList = verificationRequirementObj
      .searchRequirementsByDataItemIDAndRelatedItemID(
        verifiableDataItemAndStatusKeyForCase);

    // BEGIN, CR00077149,AL
    // ensure lists have at least one record
    if (caseLevelVerificationRequirementsList.dtls.size() > 0
      && participantLevelVerificationRequirementsList.dtls.size() > 0) {
      // code table variables
      final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
        CodeTableFactory.newInstance();

      final CTItemKey caseitemKey1 = new CTItemKey();
      CTItem caseitem1 = new CTItem();

      caseitemKey1.code =
        caseLevelVerificationRequirementsList.dtls.item(0).verificationLevel;
      caseitemKey1.locale = TransactionInfo.getProgramLocale();
      caseitemKey1.tableName = VERIFICATIONLEVEL.TABLENAME;
      // BEGIN, CR00163098, JC
      caseitem1 = codeTableInterface.getOneItemForUserLocale(caseitemKey1);
      // END, CR00163098, JC

      final CTItemKey partitemKey1 = new CTItemKey();
      CTItem partitem1 = new CTItem();

      partitemKey1.code = participantLevelVerificationRequirementsList.dtls
        .item(0).verificationLevel;
      partitemKey1.locale = TransactionInfo.getProgramLocale();
      partitemKey1.tableName = VERIFICATIONLEVEL.TABLENAME;
      // BEGIN, CR00163098, JC
      partitem1 = codeTableInterface.getOneItemForUserLocale(partitemKey1);
      // END, CR00163098, JC

      final int caseLevel = Integer.parseInt(caseitem1.description);
      final int partLevel = Integer.parseInt(partitem1.description);

      if (caseLevel > partLevel) {
        return true;
      }

      return false;

    } // if case level verification exists & no participant level
    // verifications
    // exists, return true, case level verifications required
    else if (caseLevelVerificationRequirementsList.dtls.size() > 0
      && participantLevelVerificationRequirementsList.dtls.size() == 0) {

      // BEGIN, CR00333346 SR
      final SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID =
        caseLevelVerificationRequirementsList.dtls.get(0);
      final long verificationRequirementID =
        searchDueDaysDueDateFromAndRequirementID.verificationRequirementID;

      final boolean conditionalVerificationApplicable =
        isConditionalVerificationApplicable(verificationRequirementID,
          verifiableDataItemID, evidenceDescriptorDtls);

      return conditionalVerificationApplicable;
      // END, CR00333346
    }

    return false;
    // END, CR00077149
  }

  // END, CR00076353

  // BEGIN,CR00077795,AL
  // ___________________________________________________________________________
  /**
   * This performs verification for each Participant Evidence Checks the
   * Verification Status and Builds Error Message Common to Both Apply Changes
   * and Verify Product Details verification.
   *
   * @param evidenceDescriptorDtls
   * contains information on evidence type, evidenceDescriptorID
   */
  protected void performParticipantVerification(
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    final VDIEDLink vDIEDlink = VDIEDLinkFactory.newInstance();

    // Verification variables
    final Verification verification = VerificationFactory.newInstance();

    String errorMessage = CuramConst.gkEmpty;

    final AppException appException = new AppException(
      curam.message.ENTAPPLYCHANGES.ERR_UNSATISFIED_MANDATORY_VERIFICATION_REQUIREMENT_FOR_PARTICIPANT);

    // concern role variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();

    // VerifiableDataItem variables
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();

    // Populate the relatedIDStatusAndEvidenceTypeKey
    final RelatedIDStatusAndEvidenceTypeKey relatedIDStatusAndEvidenceTypeKey =
      new RelatedIDStatusAndEvidenceTypeKey();

    relatedIDStatusAndEvidenceTypeKey.relatedID =
      evidenceDescriptorDtls.relatedID;
    relatedIDStatusAndEvidenceTypeKey.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    relatedIDStatusAndEvidenceTypeKey.statusCode =
      EVIDENCEDESCRIPTORSTATUS.INEDIT;

    // BEGIN,CR00079599,AL
    // read for participant only evidence descriptors - evidence descriptors
    // where caseID is null
    EvidenceDescriptorDtls evidenceDescriptorDtlsForParticipant = null;

    try {
      // read for participant only evidence descriptors - evidence
      // descriptors
      // where caseID is null
      evidenceDescriptorDtlsForParticipant =
        evidenceDescriptorObj.readNonCaseByRelatedIDStatusAndType(
          relatedIDStatusAndEvidenceTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return;
    }
    // END,CR00079599

    if (evidenceDescriptorDtlsForParticipant.evidenceDescriptorID != 0) {

      final EvidenceDescriptorKey evidenceDescriptorKeyForParticipant =
        new EvidenceDescriptorKey();

      final VDIEDLinkIDMandatoryKey vDIEDLinkIDMandatoryKeyForParticipant =
        new VDIEDLinkIDMandatoryKey();

      VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkIDAndDataItemIDDetailsListForParticipant =
        new VDIEDLinkIDAndDataItemIDDetailsList();

      MandatoryVerificationDetailsList mandatoryVerificationDetailsListForParticipant =
        new MandatoryVerificationDetailsList();

      MandatoryVerificationDetails mandatoryVerificationDetailsForParticipant =
        new MandatoryVerificationDetails();

      evidenceDescriptorKeyForParticipant.evidenceDescriptorID =
        evidenceDescriptorDtlsForParticipant.evidenceDescriptorID;

      vDIEDLinkIDAndDataItemIDDetailsListForParticipant = vDIEDlink
        .readByEvidenceDescriptorID(evidenceDescriptorKeyForParticipant);

      final VerificationKey verificationKey = new VerificationKey();

      // to iterated vDIEDLinkIDAndDataItemIDDetailsListForParticipant
      for (int m =
        0; m < vDIEDLinkIDAndDataItemIDDetailsListForParticipant.dtls
          .size(); m++) {

        vDIEDLinkIDMandatoryKeyForParticipant.VDIEDLinkID =
          vDIEDLinkIDAndDataItemIDDetailsListForParticipant.dtls
            .item(m).vDIEDLinkID;

        mandatoryVerificationDetailsListForParticipant = verification
          .searchMandatoryVerificationRequirementsAndVerificationStatus(
            vDIEDLinkIDMandatoryKeyForParticipant);

        for (int n =
          0; n < mandatoryVerificationDetailsListForParticipant.dtls
            .size(); n++) {

          mandatoryVerificationDetailsForParticipant =
            mandatoryVerificationDetailsListForParticipant.dtls.item(n);

          // BEGIN, CR00260117, FM
          verificationKey.verificationID =
            mandatoryVerificationDetailsForParticipant.verificationID;
          final MaintainVerificationWaiver verificationWaiverObj =
            MaintainVerificationWaiverFactory.newInstance();

          final VerificationWaiverDtlsList verificationWaiverDtlsList =
            verificationWaiverObj
              .listCurrentActiveByVerificationID(verificationKey);

          if (verificationWaiverDtlsList.dtls.isEmpty()
            && mandatoryVerificationDetailsForParticipant.verificationStatus
              .equals(VERIFICATIONSTATUS.NOTVERIFIED)) {
            // END, CR00260117

            concernRoleKey.concernRoleID =
              evidenceDescriptorDtls.participantID;
            concernRoleNameDetails =
              concernRoleObj.readConcernRoleName(concernRoleKey);

            if (errorMessage.length() != 0) {

              // BEGIN, CR00222190, ELG
              errorMessage = errorMessage
                + INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale());
              // END, CR00222190

              errorMessage = errorMessage + kSpace;

            }

            // BEGIN, CR00260117, FM
            errorMessage =
              errorMessage + concernRoleNameDetails.concernRoleName;
            // END, CR00260117
            // BEGIN, CR00222190, ELG
            errorMessage =
              errorMessage + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
                .getMessageText(TransactionInfo.getProgramLocale());
            // END, CR00222190
            errorMessage = errorMessage + kSpace;

            verifiableDataItemKey.verifiableDataItemID =
              vDIEDLinkIDAndDataItemIDDetailsListForParticipant.dtls
                .item(m).verifiableDataItemID;

            final String verifiableItemNameCode =
              verifiableDataItem.readNameByID(verifiableDataItemKey).name;

            errorMessage = errorMessage + readCodeTableItemDescription(
              verifiableItemNameCode, VERIFIABLEITEMNAME.TABLENAME);

          } // END OF If waiver empty and not verified mandatory
            // verifications
        } // END OF FOR loop on mandatory verifications
      } // end of m for vDIEDLinkIDAndDataItemIDDetailsListForParticipant
    }
    if (errorMessage.length() != 0) {
      appException.arg(errorMessage);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } // end of if
  }

  // BEGIN, CR00388286, AKr
  /**
   * Checks for mandatory outstanding verifications on the case for each
   * Participant Evidence and throws a validation is any exist. This is called
   * during the activation of the case.
   *
   * @param viewCaseParticipantRoleDetailsList
   * Case Participant Role Details List
   * @param caseID
   * The identifier of the case, which is being activated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void performParticipantVerificationOnCase(
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList,
    final long caseID) throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    final VDIEDLink vDIEDlink = VDIEDLinkFactory.newInstance();
    final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();
    final Verification verification = VerificationFactory.newInstance();
    String errorMessage = CuramConst.gkEmpty;
    final AppException appException = new AppException(
      curam.message.ENTAPPLYCHANGES.ERR_UNSATISFIED_MANDATORY_VERIFICATION_REQUIREMENT);
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails =
      new ConcernRoleNameDetails();
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList;

    for (final CaseParticipantRole_eoFullDetails caseParticipantRole_eoFullDetails : viewCaseParticipantRoleDetailsList.dtls
      .items()) {
      concernRoleKey.concernRoleID =
        caseParticipantRole_eoFullDetails.participantRoleID;
      final ConcernRoleTypeDetails concernRoleTypeDetails =
        ConcernRoleFactory.newInstance().readConcernRoleType(concernRoleKey);

      if (Configuration.getBooleanProperty(EnvVars.ENV_PDC_ENABLED)
        && (CONCERNROLETYPE.PERSON
          .equals(concernRoleTypeDetails.concernRoleType)
          || CONCERNROLETYPE.PROSPECTPERSON
            .equals(concernRoleTypeDetails.concernRoleType))) {

        final CaseIDParticipantIDStatusCode caseIDParticipantIDStatusCode =
          new CaseIDParticipantIDStatusCode();

        caseIDParticipantIDStatusCode.participantID =
          caseParticipantRole_eoFullDetails.participantRoleID;
        caseIDParticipantIDStatusCode.statusCode =
          EVIDENCEDESCRIPTORSTATUS.ACTIVE;
        caseIDParticipantIDStatusCode.caseID = PDCUtilFactory.newInstance()
          .getPDCCaseIDCaseParticipantRoleID(concernRoleKey).caseID;
        evidenceDescriptorDtlsList = EvidenceDescriptorFactory.newInstance()
          .searchActiveByCaseIDParticipantID(caseIDParticipantIDStatusCode);
      } else {
        final ParticipantIDStatusAndDateKey participantIDStatusAndDateKey =
          new ParticipantIDStatusAndDateKey();

        participantIDStatusAndDateKey.participantID =
          caseParticipantRole_eoFullDetails.participantRoleID;

        try {
          final ParticipantKeyStruct participantKey =
            new ParticipantKeyStruct();

          participantKey.participantID =
            caseParticipantRole_eoFullDetails.participantRoleID;
          evidenceDescriptorDtlsList = evidenceDescriptorObj
            .searchAllParticipantEvidences(participantKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          return;
        }
      }
      for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls) {
        VerificationDtlsList mandatoryVerificationDetailsList =
          new VerificationDtlsList();
        final ReadByEvdDescriptionIDCaseIDKey readByEvdDescriptionIDCaseIDKey =
          new ReadByEvdDescriptionIDCaseIDKey();

        readByEvdDescriptionIDCaseIDKey.evidenceDescriptorID =
          evidenceDescriptorDtls.evidenceDescriptorID;
        readByEvdDescriptionIDCaseIDKey.verificationLinkedID = caseID;
        mandatoryVerificationDetailsList =
          verification.searchVerificationByCaseIDEvdDescID(
            readByEvdDescriptionIDCaseIDKey);
        for (final VerificationDtls mandatoryVerificationDetails : mandatoryVerificationDetailsList.dtls
          .items()) {
          final VerificationKey verificationKey = new VerificationKey();

          verificationKey.verificationID =
            mandatoryVerificationDetails.verificationID;
          final VerificationWaiverDtlsList verificationWaiverDtlsList =
            MaintainVerificationWaiverFactory.newInstance()
              .listCurrentActiveByVerificationID(verificationKey);

          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = caseID;
          final CachedCaseHeader cachedCaseHeaderObj =
            CachedCaseHeaderFactory.newInstance();
          final CaseHeaderDtls caseDetails =
            cachedCaseHeaderObj.read(caseHeaderKey);
          final EvidenceDescriptorKey evidenceDescriptorKey =
            new EvidenceDescriptorKey();

          evidenceDescriptorKey.evidenceDescriptorID =
            evidenceDescriptorDtls.evidenceDescriptorID;

          /*
           * Evidence on Closed or Suspended cases should not be
           * verified. We also call out to the hook point to allow
           * custom processing to skip the verification for case
           * evidence.
           */
          if (verificationWaiverDtlsList.dtls.isEmpty()
            && mandatoryVerificationDetails.verificationStatus
              .equals(VERIFICATIONSTATUS.NOTVERIFIED)
            && !caseDetails.statusCode.equals(CASESTATUS.CLOSED)
            && !caseDetails.statusCode.equals(CASESTATUS.SUSPENDED)
            && !verificationEngineHook.skipVerificationCheck(caseHeaderKey,
              evidenceDescriptorKey)) {
            concernRoleKey.concernRoleID =
              caseParticipantRole_eoFullDetails.participantRoleID;
            concernRoleNameDetails =
              concernRoleObj.readConcernRoleName(concernRoleKey);
            if (errorMessage.length() != 0) {
              errorMessage = errorMessage
                + INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale());
              errorMessage = errorMessage + kSpace;
            }
            errorMessage =
              errorMessage + concernRoleNameDetails.concernRoleName;
            errorMessage =
              errorMessage + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
                .getMessageText(TransactionInfo.getProgramLocale());
            errorMessage = errorMessage + kSpace;
            vdiedLinkKey.VDIEDLinkID =
              mandatoryVerificationDetails.VDIEDLinkID;
            verifiableDataItemKey.verifiableDataItemID =
              vDIEDlink.read(vdiedLinkKey).verifiableDataItemID;
            final String verifiableItemNameCode =
              verifiableDataItem.readNameByID(verifiableDataItemKey).name;

            errorMessage = errorMessage + readCodeTableItemDescription(
              verifiableItemNameCode, VERIFIABLEITEMNAME.TABLENAME);
          }
        }
      }
      if (errorMessage.length() != 0) {
        appException.arg(errorMessage);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // END, CR00388286

  // BEGIN, CR00256171, POB
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listOutstandingVerificationsForEvidenceDescriptor(
      final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // listOutstandingVerificationsForEvidenceDescriptor1. Therefore
    // if there is any change in this method then developer should also visit -
    // listOutstandingVerificationsForEvidenceDescriptor1.
    // END, CR00452604

    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();

    final EvidenceDescriptorKeyList descriptorKeyList =
      new EvidenceDescriptorKeyList();

    descriptorKeyList.dtls.add(key);

    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().getEvidenceVerificationDetails(descriptorKeyList);

    // Populate the due date
    for (int i = 0; i < evidenceVerificationListDetails.verificationDtls
      .size(); i++) {

      if (evidenceVerificationListDetails.verificationDtls
        .item(i).verificationStatus.equals(VERIFICATIONSTATUS.VERIFIED)) {
        continue;
      }

      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationListDetails.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationListDetails.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listOutstandingVerificationsForBusinessObject(final BusinessObjectKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // listOutstandingVerificationsForBusinessObject1. Therefore, if there
    // is any change in this method then developer should also visit -
    // listOutstandingVerificationsForBusinessObject1.
    // END, CR00452604

    final EvidenceVerificationDisplayDetailsList detailsList =
      listVerificationsForBusinessObject(key);

    for (int i = 0; i < detailsList.list.size(); i++) {

      if (detailsList.list.item(i).verificationStatus
        .equals(VERIFICATIONSTATUS.VERIFIED)) {

        detailsList.list.remove(i);
        i--;
      }
    }

    return detailsList;
  }

  // END, CR00256171

  // BEGIN, CR00220422, PF
  // BEGIN, CR00222660, PF
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listVerificationsForBusinessObject(final BusinessObjectKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // listVerificationsForBusinessObject1. Therefore, if there
    // is any change in this method then developer should also visit -
    // listOutstandingVerificationsForBusinessObject1.
    // END, CR00452604

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = key.evidenceSuccessionID;
    // BEGIN, CR00386928, SSK
    final EvidenceDescriptorDtlsList fullEvidenceDescriptorDtlsList =
      filterEvidences(evidenceDescriptor.searchBySuccessionID(successionID));

    // BEGIN, CR00264164, JMA
    if (!fullEvidenceDescriptorDtlsList.dtls.isEmpty()) {
      // Get Participant evidence descriptor to check for Participant
      // Evidence
      // verifications

      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      // use first item in list, each item in list has same related id
      // and evidence type
      evidenceTypeKey.evidenceType =
        fullEvidenceDescriptorDtlsList.dtls.item(0).evidenceType;

      if (evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey)) {

        final EvidenceTypeParticipantIDStatusesKey participantIDEvidenceTypeStatusesKey =
          new EvidenceTypeParticipantIDStatusesKey();

        participantIDEvidenceTypeStatusesKey.evidenceType =
          evidenceTypeKey.evidenceType;
        participantIDEvidenceTypeStatusesKey.participantID =
          fullEvidenceDescriptorDtlsList.dtls.item(0).relatedID;
        participantIDEvidenceTypeStatusesKey.statusCode1 =
          EVIDENCEDESCRIPTORSTATUS.ACTIVE;
        participantIDEvidenceTypeStatusesKey.statusCode2 =
          EVIDENCEDESCRIPTORSTATUS.INEDIT;
        participantIDEvidenceTypeStatusesKey.statusCode3 =
          EVIDENCEDESCRIPTORSTATUS.SUPERSEDED;

        final EvidenceDescriptorDtlsList participantEvidenceDescriptorDtlsList =
          evidenceDescriptor.searchByEvidenceTypeParticipantIDAndStatus(
            participantIDEvidenceTypeStatusesKey);

        for (final EvidenceDescriptorDtls participantEvidenceDescriptorDtls : participantEvidenceDescriptorDtlsList.dtls) {
          fullEvidenceDescriptorDtlsList.dtls
            .addRef(participantEvidenceDescriptorDtls);
        }

      }
    }

    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance()
        .retrieveEvidenceVerificationDetails(fullEvidenceDescriptorDtlsList);

    // END, CR00386928
    // END, CR00264164

    // Populate the due date
    for (int i = 0; i < evidenceVerificationListDetails.verificationDtls
      .size(); i++) {
      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationListDetails.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationListDetails.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  // ___________________________________________________________________________
  /**
   * Checks if usage list contains the requirement key passed.
   *
   * There is another version of this method -
   * listVerificationsForCaseAndEvidence1. Therefore,
   * if there is any change made to this method, then developer should also
   * revisit
   *
   *
   * listVerificationsForCaseAndEvidence1.
   *
   * @param verificationRequirementIDStatusDetailsList
   * The usage list
   * @param verificationRequirementKey
   * contains requirement id to be searched in the usage list
   *
   * @return An indicator which is true if the list passed in contained the
   * specified requirement key.
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listVerificationsForCaseAndEvidence(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00452604, GK
    // There is another version of this method -
    // listVerificationsForCaseAndEvidence1. Therefore,
    // if there is any change made to this method, then developer should also
    // revisit
    // listVerificationsForCaseAndEvidence1.
    // END, CR00452604

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseID;
    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();

    curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      new curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList();

    evidenceVerificationDetailsList =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().listEvidenceVerificationDetails(key);

    // Populate the due date
    for (int i = 0; i < evidenceVerificationDetailsList.verificationDtls
      .size(); i++) {

      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationDetailsList.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationDetailsList.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  // END, CR00245529

  // BEGIN, CR00256171, POB
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseEvidenceVerificationDetailsList
    listOutstandingVerificationsForCase(final CaseIDKey key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList detailsList =
      listVerificationsForCase(key);

    for (int i = 0; i < detailsList.dtls.size(); i++) {

      if (detailsList.dtls.item(i).verificationStatus
        .equals(VERIFICATIONSTATUS.VERIFIED)) {

        detailsList.dtls.remove(i);
        i--;
      }
    }
    return detailsList;
  }

  // END, CR00256171

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00222660, PF
  @Override
  public CaseEvidenceVerificationDetailsList listVerificationsForCase(
    final CaseIDKey key) throws AppException, InformationalException {

    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      new CaseEvidenceVerificationDetailsList();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseID;
    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().listEvidenceVerificationDetailsForCase(caseKey);

    for (final EvidenceVerificationDetails evidenceVerificationDetails : evidenceVerificationListDetails.verificationDtls) {
      final CaseEvidenceVerificationDetails caseEvidenceVerificationDetails =
        new CaseEvidenceVerificationDetails();

      caseEvidenceVerificationDetails.caseID =
        evidenceVerificationDetails.caseID;
      caseEvidenceVerificationDetails.dataItemName =
        evidenceVerificationDetails.dataItemName;
      caseEvidenceVerificationDetails.evidenceDescriptorID =
        evidenceVerificationDetails.evidenceDescriptorID;
      caseEvidenceVerificationDetails.relatedID =
        evidenceVerificationDetails.relatedID;
      caseEvidenceVerificationDetails.summary =
        evidenceVerificationDetails.summary;
      caseEvidenceVerificationDetails.vdIEDLinkID =
        evidenceVerificationDetails.vdIEDLinkID;
      caseEvidenceVerificationDetails.verificationLinkedID =
        evidenceVerificationDetails.verificationLinkedID;
      caseEvidenceVerificationDetails.verificationLinkedType =
        evidenceVerificationDetails.verificationLinkedType;
      caseEvidenceVerificationDetails.verificationStatus =
        evidenceVerificationDetails.verificationStatus;

      caseEvidenceVerificationDetailsList.dtls
        .add(caseEvidenceVerificationDetails);
    }

    return caseEvidenceVerificationDetailsList;
    // END, CR00222660
  }

  // END, CR00222660
  // END, CR00220422
  // BEGIN, CR00233632, PB
  /**
   * Checks the field of type short for empty.
   *
   * @param s
   * Contains the field of type short.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final short s) {

    return CuramConst.gkZero == s;
  }

  /**
   * Checks the field of type int for empty.
   *
   * @param i
   * Contains the field of type int.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final int i) {

    return CuramConst.gkZero == i;
  }

  /**
   * Checks the field of type long for empty.
   *
   * @param l
   * Contains the field of type long.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final long l) {

    return l == 0;
  }

  /**
   * Checks the field of type double for empty.
   *
   * @param d
   * Contains the field of type double.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final double d) {

    return CuramConst.gkDoubleZero == d;
  }

  /**
   * Checks the field of type boolean for empty.
   *
   * @param b
   * Contains the field of type boolean.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final boolean b) {

    return !b;
  }

  /**
   * Checks the field of type Blob for empty.
   *
   * @param blob
   * Contains the field of type Blob.
   *
   * @return The boolean value indicating field is empty or not.
   */
  public boolean isFieldEmpty(final Blob blob) {

    return CuramConst.gkZero == blob.length();
  }

  /**
   * Compares the two DateTime fields for equals.
   *
   * @param dateTime1
   * Contains the dateTime to compare with other dateTime field.
   * @param dateTime2
   * Contains the dateTime to compare with other dateTime field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final DateTime dateTime1,
    final DateTime dateTime2) {

    return !dateTime1.after(dateTime2) || !dateTime1.before(dateTime2);
  }

  /**
   * Compares the two short field for equals.
   *
   * @param s1
   * Contains the short to compare with other short field.
   * @param s2
   * Contains the short to compare with other short field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final short s1, final short s2) {

    return s1 != s2;
  }

  /**
   * Compares the two integers for equals.
   *
   * @param i1
   * Contains the integer to compare with other integer field.
   * @param i2
   * Contains the integer to compare with other integer field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final int i1, final int i2) {

    return i1 != i2;
  }

  /**
   * Compares the two long fields for equals.
   *
   * @param l1
   * Contains the long to compare with other long field.
   * @param l2
   * Contains the long to compare with other long field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final long l1, final long l2) {

    return l1 != l2;
  }

  /**
   * Compares the two double fields for equals.
   *
   * @param d1
   * Contains the double to compare with other double field.
   * @param d2
   * Contains the double to compare with other double field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final double d1, final double d2) {

    return d1 != d2;
  }

  /**
   * Compares the two boolean fields for equals.
   *
   * @param b1
   * Contains the boolean to compare with other boolean field.
   * @param b2
   * Contains the boolean to compare with other boolean field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final boolean b1, final boolean b2) {

    return b1 != b2;
  }

  /**
   * Compares the two blob fields for equals.
   *
   * @param blob1
   * Contains the blob to compare with other blob field.
   * @param blob2
   * Contains the blob to compare with other blob field.
   *
   * @return The boolean value indicating fields are equal or not.
   */
  public boolean compareField(final Blob blob1, final Blob blob2) {

    return !blob1.equals(blob2);
  }

  // END, CR00233632

  /**
   * Returns true if the conditional results is true or not applicable, false
   * otherwise.
   *
   * @param verificationRequirementID Long ID
   * @param verifiableDataItemID Long ID
   * @param evidenceDescriptorDtls EvidenceDescriptorDtls
   *
   * @return Boolean result.
   */
  boolean isConditionalVerificationApplicable(
    final long verificationRequirementID, final Long verifiableDataItemID,
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final ConditionalVerificationRulesInvoker.Result[] results =
      new ConditionalVerificationRulesInvoker.Result[]{
        ConditionalVerificationRulesInvoker.Result.TRUE,
        ConditionalVerificationRulesInvoker.Result.NOT_APPLICABLE };

    return isConditionalVerificationResultMatchingOneOrMoreInList(
      verificationRequirementID, verifiableDataItemID, evidenceDescriptorDtls,
      results);
  }

  /**
   * Returns true if the conditional result is true or there are no rules
   * configured, false otherwise.
   *
   * @param verificationRequirementID Long ID
   * @param verifiableDataItemID Long ID
   * @param evidenceDescriptorDtls EvidenceDescriptorDtls
   *
   * @return Boolean result.
   */
  private boolean isConditionalVerificationResultTrueOrNotApplicable(
    final long verificationRequirementID, final Long verifiableDataItemID,
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final ConditionalVerificationRulesInvoker.Result[] results =
      new ConditionalVerificationRulesInvoker.Result[]{
        ConditionalVerificationRulesInvoker.Result.TRUE,
        ConditionalVerificationRulesInvoker.Result.NOT_APPLICABLE };

    return isConditionalVerificationResultMatchingOneOrMoreInList(
      verificationRequirementID, verifiableDataItemID, evidenceDescriptorDtls,
      results);
  }

  /**
   * Returns true if the result matches one passed in.
   *
   * @param verificationRequirementID Long ID
   * @param verifiableDataItemID Long ID
   * @param evidenceDescriptorDtls EvidenceDescriptorDtls
   * @param results Array of ConditionalVerificationRulesInvoker.Result to match
   * against.
   * @return Boolean result
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isConditionalVerificationResultMatchingOneOrMoreInList(
    final long verificationRequirementID, final Long verifiableDataItemID,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final ConditionalVerificationRulesInvoker.Result... results)
    throws AppException, InformationalException {

    final VerificationRequirementKey verificationRequirementKey =
      new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID =
      verificationRequirementID;

    final ConditionalVerificationRulesInvoker invoker = GuiceWrapper
      .getInjector().getInstance(ConditionalVerificationRulesInvoker.class);

    invoker.setVerificationRequirementKey(verificationRequirementKey);
    final ConditionalVerificationRulesInvoker.Result conditionalVerificationResult =
      invoker.invoke(verifiableDataItemID, evidenceDescriptorDtls);

    for (final ConditionalVerificationRulesInvoker.Result resultToMatch : results) {
      if (conditionalVerificationResult.equals(resultToMatch)) {
        return true;
      }
    }
    return false;
  }

  // BEGIN, CR00400972, RPB
  /**
   * Checks if the result of conditional verification has changed. If yes, it
   * removes the outstanding verification
   *
   * along with the associated verification waiver and the VDIED Link.
   *
   * @param evidenceDescriptorDtls The details of the evidence
   * @param readByVDIEDLinkAndVerLinkedIDTypeKey The details of the related
   * VDIED Link
   * @param verifiableDataItemID The unique identifier of the verifiable data
   * item
   * @param verificationRequirementID The unique identifier of the verification
   * requirement.
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  // END, CR00400972

  private void isConditionalVerificationResultChanged(
    final long verificationRequirementID, final long verifiableDataItemID,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final ReadByVDIEDLinkAndVerLinkedIDTypeKey readByVDIEDLinkAndVerLinkedIDTypeKey)
    throws AppException, InformationalException {

    if (!isConditionalVerificationApplicable(verificationRequirementID,
      verifiableDataItemID, evidenceDescriptorDtls)) {
      final VerificationKey verificationKey = new VerificationKey();

      // BEGIN, CR00400972, RPB
      final Verification verificationObj = VerificationFactory.newInstance();
      final VerificationWaiver verificationWaiverObj =
        VerificationWaiverFactory.newInstance();
      final VerificationWaiverKey verificationWaiverKey =
        new VerificationWaiverKey();
      // BEGIN, CR00468469, AP
      final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

      vdiedLinkKey.VDIEDLinkID =
        readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID;
      final VerificationDtlsList verificationRecordList =
        verificationObj.readByVDIEDLinkID(vdiedLinkKey);

      for (final VerificationDtls verificationRecord : verificationRecordList.dtls) {

        verificationKey.verificationID = verificationRecord.verificationID;

        final VerificationWaiverDtlsList verificationWaiverDtlsList =
          verificationWaiverObj.searchByVerificationID(verificationKey);

        for (final VerificationWaiverDtls verificationWaiverDtls : verificationWaiverDtlsList.dtls
          .items()) {
          verificationWaiverKey.verificationWaiverID =
            verificationWaiverDtls.verificationWaiverID;
          verificationWaiverObj.remove(verificationWaiverKey);
        }

        verificationObj.remove(verificationKey);
      }
      // END, CR00468469

      // END, CR00400972

      // BEGIN, CR00442355, AKr
      final VDIEDLinkKey vDIEDLinkKeyObj = new VDIEDLinkKey();

      vDIEDLinkKeyObj.VDIEDLinkID =
        readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID;
      final VerificationItemProvidedDtlsList verificationItemProvidedDtlsList =
        VerificationItemProvidedFactory.newInstance()
          .searchByVDIEDLinkID(vDIEDLinkKeyObj);

      for (final VerificationItemProvidedDtls verificationItemProvidedDtls : verificationItemProvidedDtlsList.dtls) {
        final VerificationItemProvidedKey verificationItemProvidedKey =
          new VerificationItemProvidedKey();

        verificationItemProvidedKey.verificationItemProvidedID =
          verificationItemProvidedDtls.verificationItemProvidedID;
        VerificationItemProvidedFactory.newInstance()
          .remove(verificationItemProvidedKey);
      }
      // END, CR00442355

      final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID =
        readByVDIEDLinkAndVerLinkedIDTypeKey.VDIEDLinkID;

      VDIEDLinkFactory.newInstance().remove(vDIEDLinkKey);
    }
  }

  // BEGIN, CR00343380, RPB
  /**
   * Shares the verification items already present in the source case with the
   * target case also.
   *
   * @param targetEvidenceDescriptorDtls
   * Evidence descriptor details for the target case.
   */
  @Override
  public void shareVerificationItems(
    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Get the verification items necessary for the target case
    final CaseEvidenceVerificationDisplayDetailsList targetCaseVerificationItems =
      getVerifiableDataItems(targetEvidenceDescriptorDtls, false);

    // Get the verification items necessary for the source case
    // Get the source case evidence descriptor details for this target
    // evidence descriptor.
    final EvidenceDescriptor evidenceDescriptor =
      curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory
        .newInstance();
    final SharedInstanceIDCaseIDStatusCodes sharedInstanceIDCaseIDStatusCodes =
      new SharedInstanceIDCaseIDStatusCodes();

    sharedInstanceIDCaseIDStatusCodes.caseID =
      targetEvidenceDescriptorDtls.sourceCaseID;
    sharedInstanceIDCaseIDStatusCodes.sharedInstanceID =
      targetEvidenceDescriptorDtls.sharedInstanceID;
    sharedInstanceIDCaseIDStatusCodes.statusCode1 =
      EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode();
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList =
      evidenceDescriptor.searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceIDCaseIDStatusCodes);
    EvidenceDescriptorDtls sourceEvidenceDescriptor = null;

    // There can be only one source evidence descriptor.
    if (sourceEvidenceDescriptorDtlsList.dtls.size() > 0) {
      sourceEvidenceDescriptor = sourceEvidenceDescriptorDtlsList.dtls.get(0);
    }

    if (null != sourceEvidenceDescriptor) {
      final CaseEvidenceVerificationDisplayDetailsList sourceCaseVerificationItems =
        getVerifiableDataItems(sourceEvidenceDescriptor, true);

      final CaseEvidenceVerificationDisplayDetailsList commonVerificationItems =
        getCommonVerifications(targetCaseVerificationItems,
          sourceCaseVerificationItems);

      // If there are any common verification items that are already
      // available in the source, create a verification item utilization
      // for the target case also.
      createVerificationItemProvided(targetEvidenceDescriptorDtls,
        commonVerificationItems);
    }
  }

  /**
   * Gets the verifications common among the source and the target case
   * verification items.
   *
   * @param targetCaseVerificationItems
   * Target case verification items.
   * @param sourceCaseVerificationItems
   * Source case verification items.
   *
   * @return Common verification items.
   * @throws AppException
   * @throws InformationalException
   */
  protected CaseEvidenceVerificationDisplayDetailsList getCommonVerifications(
    final CaseEvidenceVerificationDisplayDetailsList targetCaseVerificationItems,
    final CaseEvidenceVerificationDisplayDetailsList sourceCaseVerificationItems)
    throws AppException, InformationalException {

    final CaseEvidenceVerificationDisplayDetailsList commonVerificationItems =
      new CaseEvidenceVerificationDisplayDetailsList();
    final VDIEDLink vdiedLinkObj = VDIEDLinkFactory.newInstance();

    // Compare source and target verification Items, get all the common
    // verification items
    for (final CaseEvidenceVerificationDisplayDetails sourceCaseVerificationDisplayDetails : sourceCaseVerificationItems.dtls
      .items()) {
      for (final CaseEvidenceVerificationDisplayDetails targetCaseVerificationDisplayDetails : targetCaseVerificationItems.dtls
        .items()) {
        // BEGIN, CR00377613, AKr
        final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

        vdiedLinkKey.VDIEDLinkID =
          sourceCaseVerificationDisplayDetails.vDIEDLinkID;
        final long sourceVDIEDlinkId = vdiedLinkObj
          .readDataItemIDByVDIEDLinkID(vdiedLinkKey).verifiableDataItemID;

        vdiedLinkKey.VDIEDLinkID =
          targetCaseVerificationDisplayDetails.vDIEDLinkID;
        final long targetVDIEDlinkId = vdiedLinkObj
          .readDataItemIDByVDIEDLinkID(vdiedLinkKey).verifiableDataItemID;

        if (sourceVDIEDlinkId == targetVDIEDlinkId) {
          commonVerificationItems.dtls
            .addRef(sourceCaseVerificationDisplayDetails);
        }
        // END, CR00377613
      }
    }
    return commonVerificationItems;
  }

  /**
   * Creates a verification item provide record for the given target source
   * evidence descriptor.
   *
   * @param targetEvidenceDescriptorDtls
   * Target case evidence descriptor.
   * @param commonVerificationItems
   * Verification items that are common between the source and the
   * target items.
   *
   * @return Common verification items.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void createVerificationItemProvided(
    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls,
    final CaseEvidenceVerificationDisplayDetailsList commonVerificationItems)
    throws AppException, InformationalException {

    final VDIEDLink vdIEDLinkObj = VDIEDLinkFactory.newInstance();
    final curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvided =
      curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory
        .newInstance();

    for (final CaseEvidenceVerificationDisplayDetails commonVerificationItem : commonVerificationItems.dtls
      .items()) {

      // If item is provided, get the link id and get the verification
      // provided details for this evidence descriptor.
      final VDIEDLinkIDAndStatusKey vDIEDLinkIDAndStatusKey =
        new VDIEDLinkIDAndStatusKey();

      vDIEDLinkIDAndStatusKey.VDIEDLinkID =
        commonVerificationItem.vDIEDLinkID;
      vDIEDLinkIDAndStatusKey.recordStatus =
        RECORDSTATUSEntry.NORMAL.getCode();
      final VerificationItemProvidedDtlsList verificationItemProvidedDtlsList =
        verificationItemProvided
          .searchByVDIEDLinkIDAndStatus(vDIEDLinkIDAndStatusKey);

      // BEGIN, CR00406334, SSK
      final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID = commonVerificationItem.vDIEDLinkID;
      // END, CR00406334

      for (final VerificationItemProvidedDtls vipDtls : verificationItemProvidedDtlsList.dtls
        .items()) {
        // Get the link record for the target evidence descriptor
        // and insert a record in the verification provided table.
        final EvidenceDescriptorKey evidenceDescriptorKey =
          new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID =
          targetEvidenceDescriptorDtls.evidenceDescriptorID;
        final VDIEDLinkIDAndDataItemIDDetailsList vDIEDLinkIDAndDataItemIDDetailsListTarget =
          vdIEDLinkObj.readByEvidenceDescriptorID(evidenceDescriptorKey);

        // BEGIN, CR00351179, LKS
        // BEGIN, CR00406334, SSK
        for (final VDIEDLinkIDAndDataItemIDDetails dtls : vDIEDLinkIDAndDataItemIDDetailsListTarget.dtls) {
          if (dtls.verifiableDataItemID == vdIEDLinkObj
            .readDataItemIDByVDIEDLinkID(vDIEDLinkKey).verifiableDataItemID) {
            final VerificationItemProvidedKey verificationItemProvidedKey =
              new VerificationItemProvidedKey();

            verificationItemProvidedKey.verificationItemProvidedID =
              vipDtls.verificationItemProvidedID;

            vipDtls.VDIEDLinkID = dtls.vDIEDLinkID;
            // END, CR00406334
            vipDtls.verificationItemProvidedID = 0;
            verificationItemProvided.insert(vipDtls);

            // To get the Attachment details list.
            final VerificationAttachmentLink verificationAttachmentLink =
              VerificationAttachmentLinkFactory.newInstance();
            final VerificationAttachmentSummaryDetailsList verificationAttachmentSummaryDetailsList =
              verificationAttachmentLink
                .searchAttachmentByVerificationItemProvided(
                  verificationItemProvidedKey);

            for (final VerificationAttachmentSummaryDetails verificationAttachmentSummaryDetails : verificationAttachmentSummaryDetailsList.dtls) {
              final ReadVerificationAttachmentLinkKey readVerificationAttachmentLinkKey =
                new ReadVerificationAttachmentLinkKey();

              readVerificationAttachmentLinkKey.verificationAttachmentLinkID =
                verificationAttachmentSummaryDetails.verificationAttachmentLinkID;

              final curam.verification.sl.infrastructure.intf.VerificationAttachmentLink vAttachmentLink =
                curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory
                  .newInstance();
              final ReadVerificationAttachmentLinkDetails readVerificationAttachmentLinkDetails =
                vAttachmentLink.readVerificationAttachmentLink(
                  readVerificationAttachmentLinkKey);

              final CreateVerificationAttachmentLinkDetails createVerificationAttachmentLinkDetails =
                new CreateVerificationAttachmentLinkDetails();

              createVerificationAttachmentLinkDetails.createLinkDtls.description =
                verificationAttachmentSummaryDetails.description;
              createVerificationAttachmentLinkDetails.createLinkDtls.verificationItemProvidedID =
                vipDtls.verificationItemProvidedID;
              createVerificationAttachmentLinkDetails.createAttachmentDtls =
                readVerificationAttachmentLinkDetails.readAttachmentDtls;

              // BEGIN, CR00399910, MV
              if (CuramConst.gkNo.equalsIgnoreCase(Configuration.getProperty(
                EnvVars.ENV_PREVENT_DUPLICATE_VERIFICATION_ITEM_ATTACHMENT))) {
                vAttachmentLink.createVerificationAttachmentLink(
                  createVerificationAttachmentLinkDetails);
              } else if (CuramConst.gkYes
                .equalsIgnoreCase(Configuration.getProperty(
                  EnvVars.ENV_PREVENT_DUPLICATE_VERIFICATION_ITEM_ATTACHMENT))) {
                createVerificationAttachmentLinkDetails.createLinkDtls.attachmentID =
                  readVerificationAttachmentLinkDetails.readAttachmentDtls.attachmentID;
                createVerificationAttachmentLinkDetails.createLinkDtls.recordStatus =
                  RECORDSTATUS.DEFAULTCODE;
                verificationAttachmentLink.insert(
                  createVerificationAttachmentLinkDetails.createLinkDtls);
              }
              // END, CR00399910
            }

            vDIEDLinkKey.VDIEDLinkID = vipDtls.VDIEDLinkID;

            final curam.verification.sl.infrastructure.intf.Verification verification =
              curam.verification.sl.infrastructure.fact.VerificationFactory
                .newInstance();

            verification
              .determineVerificationStatusForRemoveAndView(vDIEDLinkKey);
          }
          // END, CR00351179
        }
      }
    }
  }

  /**
   * Gets all the verifiable data items for the give evidence descriptor.
   *
   * @param evidenceDescriptorDtls
   * Evidence descriptor details.
   * @param isSourceCase
   * Indicates if the case is a source case.
   *
   * @return Details containing the verifiable data items.
   */
  // Get all the verifiable data item ids for the evidence
  protected CaseEvidenceVerificationDisplayDetailsList getVerifiableDataItems(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final boolean isSourceCase) throws AppException, InformationalException {

    // Read the list of verification items for the given case
    final CaseEvidenceVerificationDisplayDetailsList caseEvidenceVerificationDisplayDetailsList =
      new CaseEvidenceVerificationDisplayDetailsList();
    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    if (!isSourceCase) {
      outstandingIndicator.verificationStatus =
        VERIFICATIONSTATUS.NOTVERIFIED;
    } else {
      outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.VERIFIED;
    }
    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    caseKeyStruct.caseID = evidenceDescriptorDtls.caseID;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    final ReadByTypeAndCaseIDKey readByTypeAndCaseIDKey =
      new ReadByTypeAndCaseIDKey();

    readByTypeAndCaseIDKey.caseID = evidenceDescriptorDtls.caseID;
    readByTypeAndCaseIDKey.typeCode = CASEPARTICIPANTROLETYPE.MEMBER;

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList =
      caseParticipantRoleObj.searchByTypeAndCaseID(readByTypeAndCaseIDKey);
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails =
      caseHeaderObj.readParticipantRoleID(caseHeaderKey);
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    caseParticipantRoleDtls.participantRoleID =
      readParticipantRoleIDDetails.concernRoleID;
    caseParticipantRoleDtlsList.dtls.add(caseParticipantRoleDtls);
    final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      verificationObj.listCaseVerificationDetails(caseKeyStruct,
        outstandingIndicator);

    for (final CaseParticipantRoleDtls caseParticipantRoleDetails : caseParticipantRoleDtlsList.dtls
      .items()) {
      participantKeyStruct.participantID =
        caseParticipantRoleDetails.participantRoleID;
      final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList participantList =
        verificationObj
          .listPOutstandingVerificationDetails(participantKeyStruct);

      for (final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetails verificationDetails : participantList.dtls) {
        verificationDetails.concernRoleID =
          caseParticipantRoleDetails.participantRoleID;
        caseEvidenceVerificationDetailsList.dtls.addRef(verificationDetails);
      }
    }
    CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails;
    VerificationWaiver verificationWaiverObj;
    EvidenceDescriptorIDDetails evidenceDescriptorIDDetails;
    VerificationWaiverEDParticipantCaseIDDetailsList verificationWaiverList;
    EvidenceDescriptor evidenceDescriptorObj;
    EvidenceDescriptorKey edKey;

    for (final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetails details : caseEvidenceVerificationDetailsList.dtls) {

      caseEvidenceVerificationDisplayDetails =
        new CaseEvidenceVerificationDisplayDetails();
      caseEvidenceVerificationDisplayDetails.caseParticipantRoleID =
        details.caseParticpantRoleID;
      caseEvidenceVerificationDisplayDetails.concernRoleID =
        details.concernRoleID;
      caseEvidenceVerificationDisplayDetails.contextDescription =
        details.contextDescription;
      caseEvidenceVerificationDisplayDetails.dueDate = details.dueDate;
      caseEvidenceVerificationDisplayDetails.evidence = details.evidence;
      caseEvidenceVerificationDisplayDetails.evidenceDescriptorID =
        details.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.itemProvided =
        details.itemProvided;
      caseEvidenceVerificationDisplayDetails.primaryClient =
        details.primaryClient;
      caseEvidenceVerificationDisplayDetails.verificationStatus =
        details.verificationStatus;
      caseEvidenceVerificationDisplayDetails.verifiableDataItemName =
        details.verifiableDataItemName;
      caseEvidenceVerificationDisplayDetails.vDIEDLinkID =
        details.vDIEDLinkID;
      caseEvidenceVerificationDisplayDetails.verificationID =
        details.verificationID;
      caseEvidenceVerificationDisplayDetails.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          caseEvidenceVerificationDisplayDetails.verificationStatus,
          TransactionInfo.getProgramLocale());
      if (details.mandatory) {
        verificationWaiverObj = VerificationWaiverFactory.newInstance();
        evidenceDescriptorIDDetails = new EvidenceDescriptorIDDetails();
        evidenceDescriptorIDDetails.evidenceDescriptorID =
          details.evidenceDescriptorID;
        verificationWaiverList = verificationWaiverObj
          .searchByEvidenceDescriptorID(evidenceDescriptorIDDetails);
        for (final VerificationWaiverEDParticipantCaseIDDetails waiverDetails : verificationWaiverList.dtls
          .items()) {
          if (Date.getCurrentDate().before(waiverDetails.endDate)
            && Date.getCurrentDate().after(waiverDetails.startDate)
            || Date.getCurrentDate().equals(waiverDetails.endDate)
            || Date.getCurrentDate().equals(waiverDetails.startDate)) {
            caseEvidenceVerificationDisplayDetails.mandatory =
              VERIFICATIONWAIVER.TEXT_MANDATORY_VERIFICATION_WITH_WAIVER
                .getMessageText(TransactionInfo.getProgramLocale());
          } else {
            caseEvidenceVerificationDisplayDetails.mandatory =
              VERIFICATIONWAIVER.TEXT_MANDATORY_VERIFICATION
                .getMessageText(TransactionInfo.getProgramLocale());
          }
        }
      }

      evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      edKey = new EvidenceDescriptorKey();
      edKey.evidenceDescriptorID =
        caseEvidenceVerificationDisplayDetails.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.evidenceType =
        evidenceDescriptorObj
          .readRelatedIDParticipantIDAndEvidenceType(edKey).evidenceType;
      caseEvidenceVerificationDisplayDetailsList.dtls
        .add(caseEvidenceVerificationDisplayDetails);
    }
    return caseEvidenceVerificationDisplayDetailsList;
  }

  // END, CR00343380

  /**
   * Checks if verification requirement exists for a case.
   *
   * @param caseIDAndEvidenceTypeKey
   * Contains case and evidence type details.
   * @param evidenceDescriptorKey
   * Contains the evidence descriptor details.
   *
   * @return True if verification requirement exists for a case, false
   * otherwise.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public boolean checkIfVerificationRequirementsExistsForCase(
    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey,
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = caseIDAndEvidenceTypeKey.evidenceType;

    // VerifiableDataItem variables
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();

    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndEvidenceTypeKey.caseID;

    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      caseIDAndEvidenceTypeKey.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);

    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();
    verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);

    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    // BEGIN, CR00350929, ARM
    // BEGIN, CR00371307, AKr
    verificationICTypeAndRelatedItemDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    verificationICTypeAndRelatedItemDetails.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();
    // END, CR00371307
    // END, CR00350929
    String dataItem = CuramConst.gkEmpty;

    boolean verificationrequirementsExists = false;

    final EvidenceDescriptor evidenceDescriptor =
      curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory
        .newInstance();

    // For each data item in the list, check the value of the corresponding
    // attribute in the custom object and make sure that it has been
    // populate
    // during the insert before creating a verification for it.
    for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
      .size(); i++) {

      dataItem =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).dataItem;

      final ReadRelatedIDParticipantIDAndEvidenceTypeDetails readRelatedIDParticipantIDAndEvidenceTypeDetails =
        EvidenceDescriptorFactory.newInstance()
          .readRelatedIDParticipantIDAndEvidenceType(evidenceDescriptorKey);
      final EvidenceMap map = EvidenceController.getEvidenceMap();
      final StandardEvidenceInterface standardEvidenceInterface =
        map.getEvidenceType(evidenceTypeKey.evidenceType);
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
      eiEvidenceKey.evidenceType =
        readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;
      // if evidence object has the data item as a field and it is not
      // empty,
      // then insert the verification requirement record
      // BEGIN, CR00191839, ND
      // BEGIN, CR00359853, SK
      Object evidenceObject;

      try {
        evidenceObject =
          standardEvidenceInterface.readEvidence(eiEvidenceKey);
      } catch (final RecordNotFoundException rnfe) {
        evidenceObject = new Object();
      }
      if (VerificationEvidenceFactory
        .newInstance(CASEEVIDENCEEntry.get(evidenceTypeKey.evidenceType))
        .isFieldEmpty(dataItem, evidenceObject,
          evidenceTypeKey.evidenceType)) {

        continue;
      }
      // END, CR00359853

      final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
        VerificationRequirementFactory.newInstance();

      final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKey =
        new VerifiableDataItemAndStatusKey();

      verifiableDataItemAndStatusKey.verifiableDataItemID =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).verifiableDataItemID;
      verifiableDataItemAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
      verifiableDataItemAndStatusKey.relatedItemID =
        verificationICTypeAndRelatedItemDetails.relatedItemID;
      verifiableDataItemAndStatusKey.relatedItemType =
        verificationICTypeAndRelatedItemDetails.relatedItemType;

      verifiableDataItemAndStatusKey.currentDate = Date.getCurrentDate();

      // search data items for integrated case type
      final SearchDueDaysDueDateFromAndRequirementIDList searchDueDaysDueDateFromAndRequirementIDList =
        verificationRequirementObj
          .searchRequirementsByDataItemIDAndRelatedItemID(
            verifiableDataItemAndStatusKey);

      // /////////////////////////////////////////////////////////////////
      if (searchDueDaysDueDateFromAndRequirementIDList.dtls.size() > 0) {
        verificationrequirementsExists = true;
      }
      // BEGIN, CR00350224, SSK
      if (!verificationrequirementsExists) {
        final EvidenceDescriptorDtls evidenceDescriptorDtls =
          evidenceDescriptor.read(evidenceDescriptorKey);

        for (final SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID : searchDueDaysDueDateFromAndRequirementIDList.dtls) {
          verificationrequirementsExists =
            isConditionalVerificationApplicable(
              searchDueDaysDueDateFromAndRequirementID.verificationRequirementID,
              verifiableDataItemAndStatusKey.verifiableDataItemID,
              evidenceDescriptorDtls);
        }
      }

    }
    // END, CR00350224
    return verificationrequirementsExists;
  }

  /**
   * Lists the verifications for incoming evidence.
   *
   * @param caseIDAndEvidenceTypeKey
   * Contains the case ID and evidence type details.
   *
   * @return The list of verifications for incoming evidence.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public VerificationDetailsForIncomingEvidenceList
    listVerificationsForIncomingEvidence(
      final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey)
      throws AppException, InformationalException {

    final EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      listVerificationForEvidenceWorkspace(caseIDAndEvidenceTypeKey);
    final VerificationDetailsForIncomingEvidenceList verificationDetailsForIncomingEvidenceList =
      new VerificationDetailsForIncomingEvidenceList();
    VerificationDetailsForIncomingEvidence detailsForIncomingEvidence;
    VerificationDtlsList verificationDtlsList;
    EvidenceDescriptorDtls evidenceDescriptorDtls;
    VerificationRequirementKey verificationRequirementKey;

    for (final curam.core.sl.infrastructure.struct.EvidenceVerificationDetails evidenceVerificationDetails : evidenceVerificationDetailsList.verificationDtls) {
      detailsForIncomingEvidence =
        new VerificationDetailsForIncomingEvidence();

      detailsForIncomingEvidence.dataItemName =
        evidenceVerificationDetails.dataItemName;
      detailsForIncomingEvidence.status =
        evidenceVerificationDetails.verificationStatus;
      detailsForIncomingEvidence.sourceEvidenceDescriptorID =
        evidenceVerificationDetails.evidenceDescriptorID;
      detailsForIncomingEvidence.vDIEDLinkID =
        evidenceVerificationDetails.vdIEDLinkID;
      final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID = evidenceVerificationDetails.vdIEDLinkID;
      verificationDtlsList =
        VerificationFactory.newInstance().readByVDIEDLinkID(vDIEDLinkKey);

      for (final VerificationDtls verificationDtls : verificationDtlsList.dtls) {
        verificationRequirementKey = new VerificationRequirementKey();

        verificationRequirementKey.verificationRequirementID =
          verificationDtls.verificationRequirementID;

        evidenceDescriptorDtls = new EvidenceDescriptorDtls();
        evidenceDescriptorDtls.evidenceDescriptorID =
          evidenceVerificationDetails.evidenceDescriptorID;
        evidenceDescriptorDtls.evidenceType =
          evidenceVerificationDetails.evidenceType;
        evidenceDescriptorDtls.caseID =
          evidenceVerificationDetails.verificationLinkedID;
      }

      verificationDetailsForIncomingEvidenceList.dtls
        .addRef(detailsForIncomingEvidence);
    }

    return verificationDetailsForIncomingEvidenceList;
  }

  /**
   * Lists the verification item provided for incoming evidence.
   *
   * @param evidenceVerificationDetails
   * Contains the details of incoming evidence.
   *
   * @return The list of verification item provided.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public VerificationItemProvidedDetailsList
    listVerificationItemProvidedForIncomingEvidence(
      final curam.core.sl.infrastructure.struct.EvidenceVerificationDetails evidenceVerificationDetails)
      throws AppException, InformationalException {

    // BEGIN, CR00429088, AKr
    final SourceVDIEDLinkIDKey sourceVDIEDLinkIDKey =
      new SourceVDIEDLinkIDKey();

    sourceVDIEDLinkIDKey.sourceVDIEDLinkID =
      evidenceVerificationDetails.vdIEDLinkID;
    final SharedVERItemProvidedDtlsList sharedVERItemProvidedDtlsList =
      SharedVERItemProvidedFactory.newInstance()
        .searchByVDIEDLinkID(sourceVDIEDLinkIDKey);
    final VerificationItemProvidedDetailsList verificationItemProvidedDetailsList =
      new VerificationItemProvidedDetailsList();
    VerificationItemProvidedDetails verificationItemProvidedDetails;
    VerificationItemProvidedKey verificationItemProvidedKey;
    VerificationAttachmentLinkKey verificationAttachmentLinkKey;
    AttachmentKey attachmentKey;
    ReadVerificationItemProvidedDetails verificationItemProvidedDtls;

    for (final SharedVERItemProvidedDtls sharedVERItemProvidedDtls : sharedVERItemProvidedDtlsList.dtls
      .items()) {
      verificationItemProvidedDetails = new VerificationItemProvidedDetails();

      verificationItemProvidedKey = new VerificationItemProvidedKey();

      verificationItemProvidedKey.verificationItemProvidedID =
        sharedVERItemProvidedDtls.verificationItemProvidedID;
      verificationItemProvidedDtls =
        curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
          .newInstance()
          .readVerificationItemProvided(verificationItemProvidedKey);
      final VerificationItemUtilizationKey verificationItemUtilizationItemKey =
        new VerificationItemUtilizationKey();

      verificationItemUtilizationItemKey.verificationItemUtilizationID =
        sharedVERItemProvidedDtls.verificationItemUtilizationID;
      final VerificationItemUtilizationDtls verificationItemUtilizationDtls =
        VerificationItemUtilizationFactory.newInstance()
          .read(verificationItemUtilizationItemKey);
      final String verificationItemName =
        VerificationItemUtilizationFactory.newInstance()
          .readVerificationItemName(verificationItemUtilizationItemKey).name;

      verificationItemProvidedDetails.verificationItemProvidedID =
        verificationItemProvidedDtls.readDtls.verificationItemProvidedID;
      verificationItemProvidedDetails.expiryDate =
        curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory
          .newInstance()
          .calculateExpiryDate(verificationItemProvidedKey).expiryDate;
      verificationItemProvidedDetails.verificationItemName =
        VERIFICATIONITEMNAMEEntry.get(verificationItemName)
          .toUserLocaleString();
      verificationItemProvidedDetails.addedByUser =
        verificationItemProvidedDtls.readDtls.addedByUser;
      verificationItemProvidedDetails.receivedDate =
        verificationItemProvidedDtls.readDtls.dateReceived;
      verificationItemProvidedDetails.levelDescription =
        VERIFICATIONLEVELEntry
          .get(verificationItemUtilizationDtls.verificationLevel)
          .toUserLocaleString();
      // END, CR00429088
      if (!verificationItemProvidedDtls.attachmentList.dtls.isEmpty()) {

        for (final VerificationAttachmentSummaryDetails verificationAttachmentSummaryDetails : verificationItemProvidedDtls.attachmentList.dtls) {
          verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();
          verificationAttachmentLinkKey.verificationAttachmentLinkID =
            verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
          verificationItemProvidedDetails.attachementID =
            VerificationAttachmentLinkFactory.newInstance()
              .read(verificationAttachmentLinkKey).attachmentID;
          if (verificationItemProvidedDetails.attachementID != 0) {
            attachmentKey = new AttachmentKey();
            attachmentKey.attachmentID =
              verificationItemProvidedDetails.attachementID;
            verificationItemProvidedDetails.verificationAttachementName =
              AttachmentFactory.newInstance()
                .readAttachment(attachmentKey).attachmentName;
            if (!StringUtil.isNullOrEmpty(
              verificationItemProvidedDetails.verificationAttachementName)) {
              verificationItemProvidedDetails.verificationAttachmentLinkID =
                verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
              break;
            }
          }
        }
      }
      verificationItemProvidedDetailsList.dtls
        .addRef(verificationItemProvidedDetails);
    }
    return verificationItemProvidedDetailsList;
  }

  public void executeVerifyOnInsert(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EIEvidenceInsertDtls eiEvidenceInsertDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00076353,AL
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // populate EvidenceDescriptorIDRelatedIDAndEvidenceType
    final EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType =
      new EvidenceDescriptorIDRelatedIDAndEvidenceType();

    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;

    // populate evidenceTypeKey
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;

    // Check if Participant Level evidence and participant Evidence
    // Descriptor (i.e. caseID is not set on evidence descriptor)

    final boolean isEvidenceParticpantDataParticipantEDOnly =
      evidenceControllerObj.isNonCaseEDForParticipantEvidence(
        evidenceDescriptorIDRelatedIDAndEvidenceType);

    // BEGIN,CR00077795,AL
    final boolean isEvidenceParticipantData =
      evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey);
    // END,CR00077795,AL
    boolean isPDCEvidenceData = false;

    if (!isEvidenceParticipantData) {
      isPDCEvidenceData =
        evidenceControllerObj.isPDCEvidence(evidenceTypeKey);
    }
    // END, CR00076353

    final StringBuffer informationalMessage = new StringBuffer();

    // VerifiableDataItem variables
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();

    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();

    VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      new VerifiableDataItemDataItemNameAndIDDetailsList();

    // List to store the verifiable data items for integrated case
    // BEGIN, CR00220422, PF
    final ArrayList<String> verifiableDataItemsForIC =
      new ArrayList<String>();
    // END, CR00220422

    // Case header variables
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseTypeICTypeAndStartDate caseTypeICTypeAndStartDate =
      new CaseTypeICTypeAndStartDate();

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    // BEGIN, CR00343313, PB
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // BEGIN, CR00360337, SSK
    boolean isParticipantDataCase = false;

    if (evidenceDescriptorDtls.caseID != 0) {
      caseKey.caseID = evidenceDescriptorDtls.caseID;
      final CaseTypeCode caseTypeCode = caseHeader.readCaseTypeCode(caseKey);

      if (CASETYPECODEEntry.PARTICIPANTDATACASE.getCode()
        .equals(caseTypeCode.caseTypeCode)) {
        isParticipantDataCase = true;
      }
      // END, CR00360337
    }
    // END, CR00343313

    // BEGIN, CR00076353,AL
    // check if not participant evidence descriptor - participant evidence
    // descriptor caseID not set
    if (!isEvidenceParticpantDataParticipantEDOnly) {
      // read IC Case type
      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      caseTypeICTypeAndStartDate =
        caseHeader.readCaseTypeICTypeAndStartDate(caseHeaderKey);
    }
    // END, CR00076353

    // Read the list of data items which has requirements for the evidence
    // type
    final VerifiableDataItemDataItemNameAndIDDetails verifiableDataItemDataItemNameAndIDDetails =
      new VerifiableDataItemDataItemNameAndIDDetails();

    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      evidenceDescriptorDtls.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;

    // BEGIN, CR00076353,AL
    if (isEvidenceParticpantDataParticipantEDOnly) {
      evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
        NONCASEDATATYPE.PARTICIPANT;
    } else {
      // BEGIN, CR00371609, AKr
      evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
        verificationUtilities.getRelatedItemTypeCode(caseKey);
      // END, CR00371609
    }
    // END, CR00076353

    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();
    verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);

    final VDIEDLinkDtls vdIEDLinkDtls = new VDIEDLinkDtls();
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    // BEGIN, CR00074026 BF,CR00076353,AL
    if (isEvidenceParticpantDataParticipantEDOnly) {
      verificationICTypeAndRelatedItemDetails.relatedItemID =
        VERIFICATIONTYPE.NONCASEDATA;
      evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
        NONCASEDATATYPE.PARTICIPANT;
    } else {
      // BEGIN, CR00349499, ARM
      // BEGIN, CR00371609, AKr
      verificationICTypeAndRelatedItemDetails.relatedItemType =
        verificationUtilities.getRelatedItemTypeCode(caseKey);
      verificationICTypeAndRelatedItemDetails.relatedItemID =
        verificationUtilities.getRelatedItemID(caseKey).getCode();
      // END, CR00371609
      // END, CR00349499
    }
    // END, CR00074026, CR00076353
    // BEGIN, CR00071012, GM
    String dataItem = CuramConst.gkEmpty;
    // END, CR00071012
    int dataItemAdded = 0;

    // BEGIN, CR00386928, RD
    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();
    final VerifiableDataItemRelatedIDAndTypeKey verifiableDataItemRelatedIDAndTypeKey =
      new VerifiableDataItemRelatedIDAndTypeKey();
    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForParticipant =
      new VerifiableDataItemAndStatusKey();
    final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKeyForCase =
      new VerifiableDataItemAndStatusKey();

    // END, CR00386928

    // For each data item in the list, check the value of the corresponding
    // attribute in the custom object and make sure that it has been
    // populate
    // during the insert before creating a verification for it.
    for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
      .size(); i++) {

      dataItem =
        verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).dataItem;

      // if evidence object has the data item as a field and it is not
      // empty,
      // then insert the verification requirement record
      // BEGIN, CR00191839, ND
      if (!dataItemExists(dataItem, eiEvidenceInsertDtls.evidenceObject,
        evidenceDescriptorDtls.evidenceType)) {
        continue;
      }

      // END CR00191839, ND
      boolean conditionalVerificationApplicableAtleastOnce = false;
      final boolean isCaseLevelVerificationRequired = false;

      // BEGIN,CR00076353 AL
      // check if participant evidence & case level evidence descriptor
      // BEGIN, CR00360337, SSK
      if ((isEvidenceParticipantData || isPDCEvidenceData)
        && !(isEvidenceParticpantDataParticipantEDOnly
          || isPDCEvidenceData && isParticipantDataCase)) {

        verifiableDataItemRelatedIDAndTypeKey.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        // BEGIN, CR00349499, ARM
        // BEGIN, CR00371609, AKr
        verifiableDataItemRelatedIDAndTypeKey.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(caseKey);
        verifiableDataItemRelatedIDAndTypeKey.relatedItemID =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00371609
        // END, CR00349499

        verifiableDataItemDataItemNameAndIDDetails.dataItem =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).dataItem;
        verifiableDataItemDataItemNameAndIDDetails.name =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).name;
        verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        // Insert the VDIEDLink
        insertVDIEDLink(evidenceDescriptorDtls, vdIEDLinkDtls,
          verifiableDataItemDataItemNameAndIDDetails);

        verificationICTypeAndRelatedItemDetails.relatedItemID =
          verifiableDataItemRelatedIDAndTypeKey.relatedItemID;

        verificationICTypeAndRelatedItemDetails.verificationICTypeCheck =
          true;
        // Create the required verification records for the data item
        insertVerification(evidenceDescriptorDtls,
          verifiableDataItemDataItemNameAndIDDetails, vdIEDLinkDtls,
          verificationICTypeAndRelatedItemDetails);

        // As participant level verification exists for the same data
        // item
        // with a higher level do not add case level verification

      } else {

        // BEGIN, CR00333346 SR

        // Participant parameters -
        // verifiableDataItemAndStatusKeyForParticipant
        verifiableDataItemAndStatusKeyForParticipant.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        verifiableDataItemAndStatusKeyForParticipant.recordStatus =
          RECORDSTATUS.CANCELLED;
        verifiableDataItemAndStatusKeyForParticipant.relatedItemID =
          VERIFICATIONTYPE.NONCASEDATA;
        verifiableDataItemAndStatusKeyForParticipant.relatedItemType =
          NONCASEDATATYPE.PARTICIPANT;

        verifiableDataItemAndStatusKeyForParticipant.currentDate =
          Date.getCurrentDate();

        final SearchDueDaysDueDateFromAndRequirementIDList participantLevelVerificationRequirementsList =
          verificationRequirementObj
            .searchRequirementsByDataItemIDAndRelatedItemID(
              verifiableDataItemAndStatusKeyForParticipant);

        if (participantLevelVerificationRequirementsList.dtls.size() > 0) {

          for (final SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID : participantLevelVerificationRequirementsList.dtls) {

            final boolean conditionalVerificationApplicable =
              isConditionalVerificationApplicable(
                searchDueDaysDueDateFromAndRequirementID.verificationRequirementID,
                verifiableDataItemDataItemNameAndIDDetailsList.dtls
                  .item(i).verifiableDataItemID,
                evidenceDescriptorDtls);

            if (conditionalVerificationApplicable) {
              conditionalVerificationApplicableAtleastOnce = true;
              break;
            } else {
              continue;
            }
          }
        } else {

          // This is applicable for case.
          verifiableDataItemAndStatusKeyForCase.verifiableDataItemID =
            verifiableDataItemDataItemNameAndIDDetailsList.dtls
              .item(i).verifiableDataItemID;
          verifiableDataItemAndStatusKeyForCase.recordStatus =
            RECORDSTATUS.CANCELLED;
          // BEGIN, CR00349499, ARM
          verifiableDataItemAndStatusKeyForCase.relatedItemType =
            evidenceTypeAndRelatedItemTypeDetails.relatedItemType;
          verifiableDataItemAndStatusKeyForCase.relatedItemID =
            verificationUtilities.getRelatedItemID(caseKey).getCode();
          // END, CR00349499
          verifiableDataItemAndStatusKeyForCase.currentDate =
            Date.getCurrentDate();

          final SearchDueDaysDueDateFromAndRequirementIDList caseLevelVerificationRequirementsList =
            verificationRequirementObj
              .searchRequirementsByDataItemIDAndRelatedItemID(
                verifiableDataItemAndStatusKeyForCase);

          for (final SearchDueDaysDueDateFromAndRequirementID searchDueDaysDueDateFromAndRequirementID : caseLevelVerificationRequirementsList.dtls) {

            final boolean conditionalVerificationApplicable =
              isConditionalVerificationApplicable(
                searchDueDaysDueDateFromAndRequirementID.verificationRequirementID,
                verifiableDataItemDataItemNameAndIDDetailsList.dtls
                  .item(i).verifiableDataItemID,
                evidenceDescriptorDtls);

            if (conditionalVerificationApplicable) {
              conditionalVerificationApplicableAtleastOnce = true;
              break;
            } else {
              continue;
            }
          }
        }

        // END, CR00333346
        // BEGIN, CR00406334, SSK
        verifiableDataItemDataItemNameAndIDDetails.dataItem =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).dataItem;
        verifiableDataItemDataItemNameAndIDDetails.name =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).name;
        verifiableDataItemDataItemNameAndIDDetails.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        // END, CR00406334

        if (conditionalVerificationApplicableAtleastOnce) {

          // Insert the VDIEDLink
          insertVDIEDLink(evidenceDescriptorDtls, vdIEDLinkDtls,
            verifiableDataItemDataItemNameAndIDDetails);
          // BEGIN, CR00074026 BF, CR00076353,AL
          if (isEvidenceParticpantDataParticipantEDOnly
            || isPDCEvidenceData) {
            verificationICTypeAndRelatedItemDetails.relatedItemID =
              VERIFICATIONTYPE.NONCASEDATA;
            verificationICTypeAndRelatedItemDetails.relatedItemType =
              NONCASEDATATYPE.PARTICIPANT;
          } else {
            // BEGIN, CR00349499, ARM
            // BEGIN, CR00351546, RPB
            if (caseTypeICTypeAndStartDate.integratedCaseType != null
              && !CuramConst.gkEmpty
                .equals(caseTypeICTypeAndStartDate.integratedCaseType)) {
              // END, CR00351546
              verificationICTypeAndRelatedItemDetails.verificationICTypeCheck =
                true;
            }
            // BEGIN, CR00371609, AKr
            verificationICTypeAndRelatedItemDetails.relatedItemType =
              verificationUtilities.getRelatedItemTypeCode(caseKey);
            verificationICTypeAndRelatedItemDetails.relatedItemID =
              verificationUtilities.getRelatedItemID(caseKey).getCode();
            // END, CR00371609
            // END, CR00349499
          }
        }
        // END, CR00074026, CR00076353
        // BEGIN, CR00371725, AKr
        if (!caseTypeICTypeAndStartDate.caseTypeCode
          .equals(CASETYPECODE.PRODUCTDELIVERY)) {
          // Create the required verification records for the data
          // item
          insertVerification(evidenceDescriptorDtls,
            verifiableDataItemDataItemNameAndIDDetails, vdIEDLinkDtls,
            verificationICTypeAndRelatedItemDetails);
        }
        // END, CR00371725
      }
      // END,CR00076353 AL
      if (conditionalVerificationApplicableAtleastOnce
        || isCaseLevelVerificationRequired) {
        if (dataItemAdded != 0) {
          // BEGIN, CR00071077, GM
          informationalMessage.append(
            // BEGIN, CR00163471, JC
            INFORMATIONALMESSAGE.INF_COMMA_SPACE_INFORMATIONAL_DESCRIPTION
              .getMessageText(TransactionInfo.getProgramLocale()));
          // END, CR00163471, JC
          // END, CR00071077

        }

        informationalMessage.append(readCodeTableItemDescription(
          verifiableDataItemDataItemNameAndIDDetailsList.dtls.item(i).name,
          VERIFIABLEITEMNAME.TABLENAME));

        dataItemAdded++;
        // BEGIN,CR00076353 AL
        // if Integrated Case level all to array list
        // verifiableDataItemsForIC
        if (!isEvidenceParticpantDataParticipantEDOnly) {
          verifiableDataItemsForIC.add(dataItem);
        }
        // END,CR00076353 AL
      }
    }

    // Insert the verification for data items for the product deliveries if,
    // any
    // product delivery is already present in the integrated case.
    // BEGIN,CR00076353 AL
    if (!isEvidenceParticpantDataParticipantEDOnly) {
      insertVerificationForProductDelivery(evidenceDescriptorDtls,
        verifiableDataItemsForIC, vdIEDLinkDtls, eiEvidenceInsertDtls,
        informationalMessage);
    }
    // END,CR00076353 AL

    // Create the informational message for data items which requires
    // verifications
    final curam.util.message.CatEntry catEntry =
      ENTVERIFICATIONCONTROLLER.ERR_VERIFICATIONCONTROLLER_INSERT_VERIFICATION_VERIFIABLE_DATA_ITEM_INFORMATIONAL;

    createInformational(catEntry, informationalMessage);

  }

  @Override
  public void triggerVerificationOnPendingEvidenceRecords(
    final Set<EvidenceDescriptorDtls> evidenceRecords)
    throws AppException, InformationalException {

    for (final EvidenceDescriptorDtls item : evidenceRecords) {

      // BEGIN, CR00417631, MV
      if (TransactionInfo
        .getFacadeScopeObject(VerificationConst.kPostponeVerification) != null
        && TransactionInfo
          .getFacadeScopeObject(VerificationConst.kPostponeVerification)
          .equals(true)) {
        // BEGIN, CR00427025, MV
        insertCurrentPostponedVerification(item, item,
          VERIFICATIONPOSTPONEDON.SHARING);
        // END, CR00427025
        return;
      }
      // END, CR00417631

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = item.relatedID;
      eiEvidenceKey.evidenceType = item.evidenceType;

      final EIEvidenceInsertDtls eiEvidenceInsertDtls =
        new EIEvidenceInsertDtls();

      eiEvidenceInsertDtls.descriptor = new EvidenceDescriptorInsertDtls();
      eiEvidenceInsertDtls.parentKey = new EIEvidenceKey();

      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();

      final StandardEvidenceInterface evidenceObj =
        curam.core.sl.infrastructure.impl.EvidenceController.getEvidenceMap()
          .getEvidenceType(item.evidenceType);

      evidenceDescriptorKey.evidenceDescriptorID = item.evidenceDescriptorID;

      eiEvidenceInsertDtls.descriptor.assign(item);
      eiEvidenceInsertDtls.descriptor.caseID = item.caseID;
      eiEvidenceInsertDtls.descriptor.newInd = true;

      final Object evidence = evidenceObj.readEvidence(eiEvidenceKey);

      eiEvidenceInsertDtls.evidenceObject = evidence;

      executeVerifyOnInsert(item, eiEvidenceInsertDtls);
      if (item.caseID != 0) {
        // BEGIN, CR00430109, AKr
        // BEGIN, CR00429088, AKr
        if (null != processVerificationItem) {
          processVerificationItem.processPostponedVerificationItem(item);
          // END, CR00429088
        }
        // END, CR00430109

      }
    }
  }

  // BEGIN, CR00372534, AKr
  /**
   * Gets the list of verifications that are applicable for sharing to the
   * target case.
   *
   * @param caseIDAndEvidenceTypeKey
   * Contains case and evidence type details.
   * @param evidenceDescriptorKey
   * Contains the evidence descriptor details.
   * @param verificationDetailsList
   * The list of verifications from the source case.
   *
   * @return The details of verifications applicable to the target case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public VerificationDetailsForIncomingEvidenceList
    checkVerificationRequirementsForTargetCase(
      final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey,
      final EvidenceDescriptorKey evidenceDescriptorKey,
      final VerificationDetailsForIncomingEvidenceList verificationDetailsList)
      throws AppException, InformationalException {

    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();
    final VerificationDetailsForIncomingEvidenceList verificationDetailsForIncomingEvidenceList =
      new VerificationDetailsForIncomingEvidenceList();
    final VerifiableDataItem verifiableDataItemObj =
      VerifiableDataItemFactory.newInstance();
    final EvidenceTypeAndRelatedItemTypeDetails evidenceTypeAndRelatedItemTypeDetails =
      new EvidenceTypeAndRelatedItemTypeDetails();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseIDAndEvidenceTypeKey.caseID;
    evidenceTypeKey.evidenceType = caseIDAndEvidenceTypeKey.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.evidenceType =
      caseIDAndEvidenceTypeKey.evidenceType;
    evidenceTypeAndRelatedItemTypeDetails.recordStatus =
      RECORDSTATUS.CANCELLED;
    evidenceTypeAndRelatedItemTypeDetails.relatedItemType =
      verificationUtilities.getRelatedItemTypeCode(caseKey);
    evidenceTypeAndRelatedItemTypeDetails.currentDate = Date.getCurrentDate();

    final VerifiableDataItemDataItemNameAndIDDetailsList verifiableDataItemDataItemNameAndIDDetailsList =
      verifiableDataItemObj.searchDataItemByTypeAndRelatedItemType(
        evidenceTypeAndRelatedItemTypeDetails);
    final VerificationICTypeAndRelatedItemDetails verificationICTypeAndRelatedItemDetails =
      new VerificationICTypeAndRelatedItemDetails();

    verificationICTypeAndRelatedItemDetails.relatedItemType =
      evidenceTypeAndRelatedItemTypeDetails.relatedItemType;
    verificationICTypeAndRelatedItemDetails.relatedItemID =
      verificationUtilities.getRelatedItemID(caseKey).getCode();

    String dataItem = CuramConst.gkEmpty;
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorDtls evidenceDescriptorDtls =
      evidenceDescriptor.read(evidenceDescriptorKey);
    VerificationDetailsForIncomingEvidence verificationDetailsForIncomingEvidenceNew;
    final EvidenceMap map = EvidenceController.getEvidenceMap();
    final ReadRelatedIDParticipantIDAndEvidenceTypeDetails readRelatedIDParticipantIDAndEvidenceTypeDetails =
      evidenceDescriptor
        .readRelatedIDParticipantIDAndEvidenceType(evidenceDescriptorKey);
    final StandardEvidenceInterface standardEvidenceInterface =
      map.getEvidenceType(evidenceTypeKey.evidenceType);
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID =
      readRelatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
    eiEvidenceKey.evidenceType =
      readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;
    Object evidenceObject;
    final VerificationRequirement verificationRequirementObj =
      VerificationRequirementFactory.newInstance();

    try {
      evidenceObject = standardEvidenceInterface.readEvidence(eiEvidenceKey);
    } catch (final RecordNotFoundException rnfe) {
      evidenceObject = new Object();
    }

    for (final VerificationDetailsForIncomingEvidence verificationDetailsForIncomingEvidence : verificationDetailsList.dtls) {
      // BEGIN, CR00377613, AKr
      boolean isApplicableForTargetCase = false;

      verificationDetailsForIncomingEvidenceNew =
        new VerificationDetailsForIncomingEvidence();
      // BEGIN, CR00379281, AKr
      verificationDetailsForIncomingEvidenceNew
        .assign(verificationDetailsForIncomingEvidence);
      // END, CR00379281
      for (int i = 0; i < verifiableDataItemDataItemNameAndIDDetailsList.dtls
        .size(); i++) {

        dataItem = verifiableDataItemDataItemNameAndIDDetailsList.dtls
          .item(i).dataItem;
        if (VerificationEvidenceFactory
          .newInstance(CASEEVIDENCEEntry.get(evidenceTypeKey.evidenceType))
          .isFieldEmpty(dataItem, evidenceObject,
            evidenceTypeKey.evidenceType)) {

          continue;
        }

        final VerifiableDataItemAndStatusKey verifiableDataItemAndStatusKey =
          new VerifiableDataItemAndStatusKey();

        verifiableDataItemAndStatusKey.verifiableDataItemID =
          verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID;
        verifiableDataItemAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
        verifiableDataItemAndStatusKey.relatedItemID =
          verificationICTypeAndRelatedItemDetails.relatedItemID;
        verifiableDataItemAndStatusKey.relatedItemType =
          verificationICTypeAndRelatedItemDetails.relatedItemType;
        verifiableDataItemAndStatusKey.currentDate = Date.getCurrentDate();

        final SearchDueDaysDueDateFromAndRequirementIDList searchDueDaysDueDateFromAndRequirementIDList =
          verificationRequirementObj
            .searchRequirementsByDataItemIDAndRelatedItemID(
              verifiableDataItemAndStatusKey);

        if (searchDueDaysDueDateFromAndRequirementIDList.dtls.size() > 0) {

          final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

          vdiedLinkKey.VDIEDLinkID =
            verificationDetailsForIncomingEvidence.vDIEDLinkID;
          final long incomingVerifiableDataItemId =
            VDIEDLinkFactory.newInstance()
              .readDataItemIDByVDIEDLinkID(vdiedLinkKey).verifiableDataItemID;

          if (verifiableDataItemDataItemNameAndIDDetailsList.dtls
            .item(i).verifiableDataItemID == incomingVerifiableDataItemId) {
            // BEGIN WI108233, YF
            isApplicableForTargetCase = isConditionalVerificationApplicable(
              searchDueDaysDueDateFromAndRequirementIDList.dtls
                .item(0).verificationRequirementID,
              verifiableDataItemAndStatusKey.verifiableDataItemID,
              evidenceDescriptorDtls);

            break;
            // END WI108233, YF
          }
        }
      }
      verificationDetailsForIncomingEvidenceNew.isApplicable =
        isApplicableForTargetCase;
      verificationDetailsForIncomingEvidenceNew.dataItemName =
        VERIFIABLEITEMNAMEEntry
          .get(verificationDetailsForIncomingEvidence.dataItemName)
          .toUserLocaleString();
      verificationDetailsForIncomingEvidenceNew.status =
        VERIFICATIONSTATUSEntry
          .get(verificationDetailsForIncomingEvidence.status)
          .toUserLocaleString();

      verificationDetailsForIncomingEvidenceList.dtls
        .addRef(verificationDetailsForIncomingEvidenceNew);
    }
    // END, CR00377613
    return verificationDetailsForIncomingEvidenceList;

  }

  /**
   * Lists the verifications for incoming evidence.
   *
   * @param caseIDAndEvidenceTypeKey
   * Contains the case ID and evidence type details.
   *
   * @return The list of verifications for incoming evidence.
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public VerificationDetailsForIncomingEvidenceList
    listVerificationsForIncomingEvidence(
      final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey,
      final EvidenceDescriptorKey evidenceDesckey)
      throws AppException, InformationalException {

    final VerificationDetailsForIncomingEvidenceList returnList =
      new VerificationDetailsForIncomingEvidenceList();

    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorDtls evidenceDescDtls =
      evidenceDescriptor.read(evidenceDesckey);

    final EvidenceDescriptorDtlsList evidenceDescDtlsList = evidenceDescriptor
      .readByCaseIDAndEvidenceType(caseIDAndEvidenceTypeKey);

    final EvidenceDescriptorKeyList descriptorKeyList =
      new EvidenceDescriptorKeyList();

    for (final EvidenceDescriptorDtls evidenceDtls : evidenceDescDtlsList.dtls) {
      if (evidenceDtls.sharedInstanceID == evidenceDescDtls.sharedInstanceID) {
        final EvidenceDescriptorKey key = new EvidenceDescriptorKey();

        key.evidenceDescriptorID = evidenceDtls.evidenceDescriptorID;
        descriptorKeyList.dtls.add(key);
      }
    }

    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().getEvidenceVerificationDetails(descriptorKeyList);

    for (final EvidenceVerificationDetails evidenceVerificationDtls : evidenceVerificationListDetails.verificationDtls) {
      final VerificationDetailsForIncomingEvidence verificationDtlsForIncomingEvidence =
        new VerificationDetailsForIncomingEvidence();

      verificationDtlsForIncomingEvidence.dataItemName =
        evidenceVerificationDtls.dataItemName;
      verificationDtlsForIncomingEvidence.status =
        evidenceVerificationDtls.verificationStatus;
      verificationDtlsForIncomingEvidence.sourceEvidenceDescriptorID =
        evidenceVerificationDtls.evidenceDescriptorID;
      verificationDtlsForIncomingEvidence.vDIEDLinkID =
        evidenceVerificationDtls.vdIEDLinkID;

      returnList.dtls.addRef(verificationDtlsForIncomingEvidence);
    }
    return returnList;
  }

  // END, CR00372534

  // BEGIN, CR00414265, AKr
  protected void checkICVerificationsforPD(
    final EvidenceTypeAndParticipantDetailsListDetails details,
    final curam.core.struct.CaseKey caseKey)
    throws AppException, InformationalException {

    final ReadEvidenceTypeParticipantDetailsList readEvidenceTypeParticipantDetailsList =
      details.listDtls;
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();
    final VerificationKey verificationKey = new VerificationKey();
    final MaintainVerificationWaiver verificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    MandatoryVerificationDetailsList mandatoryVerificationDetailsListForIC;
    VDIEDLinkIDMandatoryAndRelatedItemKey vDIEDLinkIDMandatoryAndRelatedItemKey;
    String errorMessage = CuramConst.gkEmpty;
    final AppException appException = new AppException(
      ENTAPPLYCHANGES.ERR_UNSATISFIED_MANDATORY_VERIFICATION_REQUIREMENT);
    EvidenceDescriptorKey evidenceDescriptorKey;
    VDIEDLinkAndDataItemIDDetailsList vdiedLinkAndDataItemIDDetailsList;
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = caseKey.caseID;
    final long productID = ProductDeliveryFactory.newInstance()
      .readProductID(productDeliveryKey).productID;

    for (final ReadEvidenceTypeParticipantDetails evidencedetails : readEvidenceTypeParticipantDetailsList.dtls) {

      evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evidencedetails.evidenceDescriptorID;
      vdiedLinkAndDataItemIDDetailsList = VDIEDLinkFactory.newInstance()
        .readByEvidenceDescriptor(evidenceDescriptorKey);

      for (final VDIEDLinkAndDataItemIDDetails vdiedLinkAndDataItemIDDetails : vdiedLinkAndDataItemIDDetailsList.dtls) {

        vDIEDLinkIDMandatoryAndRelatedItemKey =
          new VDIEDLinkIDMandatoryAndRelatedItemKey();
        vDIEDLinkIDMandatoryAndRelatedItemKey.mandatory = true;
        vDIEDLinkIDMandatoryAndRelatedItemKey.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(caseKey);
        vDIEDLinkIDMandatoryAndRelatedItemKey.VDIEDLinkID =
          vdiedLinkAndDataItemIDDetails.vdIEDLinkID;

        final curam.core.struct.CaseKey icCaseKey =
          new curam.core.struct.CaseKey();

        icCaseKey.caseID = CaseHeaderFactory.newInstance()
          .readIntegratedCaseIDByCaseID(caseKey).integratedCaseID;
        vDIEDLinkIDMandatoryAndRelatedItemKey.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(icCaseKey);
        mandatoryVerificationDetailsListForIC = VerificationFactory
          .newInstance().searchMandatoryVerificationDetailsForPD(
            vDIEDLinkIDMandatoryAndRelatedItemKey);

        boolean skipVerification = false;

        for (final MandatoryVerificationDetails mandatoryVerificationDetails : mandatoryVerificationDetailsListForIC.dtls) {
          verificationKey.verificationID =
            mandatoryVerificationDetails.verificationID;
          final VerificationWaiverDtlsList verificationWaiverDtlsList =
            verificationWaiverObj
              .listCurrentActiveByVerificationID(verificationKey);

          for (final VerificationWaiverDtls waiverDtls : verificationWaiverDtlsList.dtls
            .items()) {
            if (waiverDtls.productID == productID) {
              skipVerification = true;
            }
          }
          if (mandatoryVerificationDetails.verificationStatus
            .equals(VERIFICATIONSTATUS.NOTVERIFIED) && !skipVerification
            && !verificationEngineHook.skipVerificationCheck(caseHeaderKey,
              evidenceDescriptorKey)) {
            final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

            concernRoleKey.concernRoleID = evidencedetails.participantID;
            final ConcernRoleNameDetails concernRoleNameDetails =
              ConcernRoleFactory.newInstance()
                .readConcernRoleName(concernRoleKey);

            if (errorMessage.length() != 0) {

              errorMessage = errorMessage
                + INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale());
              errorMessage = errorMessage + kSpace;
            }
            errorMessage =
              errorMessage + concernRoleNameDetails.concernRoleName;

            errorMessage =
              errorMessage + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
                .getMessageText(TransactionInfo.getProgramLocale());
            errorMessage = errorMessage + kSpace;

            verifiableDataItemKey.verifiableDataItemID =
              vdiedLinkAndDataItemIDDetails.verifiableDataItemID;
            final String verifiableItemNameCode =
              verifiableDataItem.readNameByID(verifiableDataItemKey).name;

            errorMessage = errorMessage + readCodeTableItemDescription(
              verifiableItemNameCode, VERIFIABLEITEMNAME.TABLENAME);
          }
        }
      }
    }
    if (errorMessage.length() != 0) {

      appException.arg(errorMessage);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // END, CR00414265

  // BEGIN, CR00372669, AKr
  /**
   * Checks if any outstanding mandatory verifications, configured for the
   * product delivery, exists for the list of evidences passed in.
   *
   * @param details
   * Contains information on evidence type, participant details.
   * @param caseKey
   * The identifier of the product delivery case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void checkMandatoryVerificationsForPD(
    final EvidenceTypeAndParticipantDetailsListDetails details,
    final curam.core.struct.CaseKey caseKey)
    throws AppException, InformationalException {

    final ReadEvidenceTypeParticipantDetailsList readEvidenceTypeParticipantDetailsList =
      details.listDtls;
    final VerifiableDataItemKey verifiableDataItemKey =
      new VerifiableDataItemKey();
    final VerifiableDataItem verifiableDataItem =
      VerifiableDataItemFactory.newInstance();
    final VerificationKey verificationKey = new VerificationKey();
    final CachedCaseHeader cachedCaseHeaderObj =
      CachedCaseHeaderFactory.newInstance();
    final MaintainVerificationWaiver verificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();
    final ReadByVerIDAndVerLinkedTypeKey verKey =
      new ReadByVerIDAndVerLinkedTypeKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    MandatoryVerificationDetailsList mandatoryVerificationDetailsList;
    VDIEDLinkIDMandatoryAndRelatedItemKey vDIEDLinkIDMandatoryAndRelatedItemKey;
    String errorMessage = CuramConst.gkEmpty;
    final AppException appException = new AppException(
      ENTAPPLYCHANGES.ERR_UNSATISFIED_MANDATORY_VERIFICATION_REQUIREMENT);
    EvidenceDescriptorKey evidenceDescriptorKey;
    VDIEDLinkAndDataItemIDDetailsList vdiedLinkAndDataItemIDDetailsList;

    for (final ReadEvidenceTypeParticipantDetails evidencedetails : readEvidenceTypeParticipantDetailsList.dtls) {

      evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID =
        evidencedetails.evidenceDescriptorID;
      vdiedLinkAndDataItemIDDetailsList = VDIEDLinkFactory.newInstance()
        .readByEvidenceDescriptor(evidenceDescriptorKey);

      for (final VDIEDLinkAndDataItemIDDetails vdiedLinkAndDataItemIDDetails : vdiedLinkAndDataItemIDDetailsList.dtls) {

        vDIEDLinkIDMandatoryAndRelatedItemKey =
          new VDIEDLinkIDMandatoryAndRelatedItemKey();
        vDIEDLinkIDMandatoryAndRelatedItemKey.mandatory = true;
        vDIEDLinkIDMandatoryAndRelatedItemKey.relatedItemType =
          verificationUtilities.getRelatedItemTypeCode(caseKey);
        vDIEDLinkIDMandatoryAndRelatedItemKey.VDIEDLinkID =
          vdiedLinkAndDataItemIDDetails.vdIEDLinkID;
        mandatoryVerificationDetailsList = VerificationFactory.newInstance()
          .searchMandatoryVerificationDetailsForPD(
            vDIEDLinkIDMandatoryAndRelatedItemKey);

        for (final MandatoryVerificationDetails mandatoryVerificationDetails : mandatoryVerificationDetailsList.dtls) {

          verificationKey.verificationID =
            mandatoryVerificationDetails.verificationID;
          // BEGIN, CR00414065, RD
          final VerificationDtls verificationDtls =
            VerificationFactory.newInstance().read(verificationKey);
          // END, CR00414065
          // BEGIN, CR00453596, GK
          final VerificationWaiverDtlsList verificationWaiverDtlsList =
            verificationWaiverObj
              .listCurrentActiveByVerificationID(verificationKey);

          // END, CR00453596

          verKey.verificationID = mandatoryVerificationDetails.verificationID;
          caseHeaderKey.caseID = caseKey.caseID;

          final CaseHeaderDtls caseDetails =
            cachedCaseHeaderObj.read(caseHeaderKey);

          /*
           * Evidence on Closed or Suspended cases should not be
           * verified. We also call out to the hook point to allow
           * custom processing to skip the verification for case
           * evidence.
           */
          if (verificationWaiverDtlsList.dtls.isEmpty()
            && mandatoryVerificationDetails.verificationStatus
              .equals(VERIFICATIONSTATUS.NOTVERIFIED)
            && !caseDetails.statusCode.equals(CASESTATUS.CLOSED)
            && !caseDetails.statusCode.equals(CASESTATUS.SUSPENDED)
            && !verificationEngineHook.skipVerificationCheck(caseHeaderKey,
              evidenceDescriptorKey)
              // BEGIN, CR00414065, RD
              & verificationDtls.verificationLinkedID == caseKey.caseID
          // END, CR00414065
          ) {

            final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

            concernRoleKey.concernRoleID = evidencedetails.participantID;
            final ConcernRoleNameDetails concernRoleNameDetails =
              ConcernRoleFactory.newInstance()
                .readConcernRoleName(concernRoleKey);

            if (errorMessage.length() != 0) {

              errorMessage = errorMessage
                + INFORMATIONALMESSAGE.INF_COMMA_INFORMATIONAL_DESCRIPTION
                  .getMessageText(TransactionInfo.getProgramLocale());
              errorMessage = errorMessage + kSpace;
            }
            // BEGIN, CR00441169, MV
            errorMessage =
              errorMessage + concernRoleNameDetails.concernRoleName;
            errorMessage = errorMessage + kSpace;
            // END, CR00441169
            errorMessage =
              errorMessage + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
                .getMessageText(TransactionInfo.getProgramLocale());
            errorMessage = errorMessage + kSpace;

            verifiableDataItemKey.verifiableDataItemID =
              vdiedLinkAndDataItemIDDetails.verifiableDataItemID;
            final String verifiableItemNameCode =
              verifiableDataItem.readNameByID(verifiableDataItemKey).name;

            errorMessage = errorMessage + readCodeTableItemDescription(
              verifiableItemNameCode, VERIFIABLEITEMNAME.TABLENAME);
          }
        }
      }
    }

    if (errorMessage.length() != 0) {

      appException.arg(errorMessage);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // BEGIN, CR00388286, AKr
    // Participant evidence verifications on case.
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey =
      new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = caseKey.caseID;
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList =
      curam.core.sl.fact.CaseParticipantRoleFactory.newInstance()
        .viewCaseMemberList(viewCaseParticipantRole_boKey);

    performParticipantVerificationOnCase(viewCaseParticipantRoleDetailsList,
      caseKey.caseID);
    // END, CR00388286
  }

  // BEGIN, CR00386292, AKr

  /**
   * Creates required verifications on the case members' participant evidences
   * that are applied at the case level.
   *
   * @param concernRoleIDList
   * The list of IDs of the case members.
   * @param caseID
   * The unique identifier of the case on which verifications has
   * to be created.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public void verifyParticipantEvidencesForCase(
    final ConcernRoleIDList concernRoleIDList, final CaseID caseID)
    throws AppException, InformationalException {

    verificationUtilities.verifyParticipantEvidenceForCase(concernRoleIDList,
      caseID);

  }

  // END, CR00386292

  // END, CR00372669

  /**
   * Filters evidences in Active, In-Edit and Superseded evidences.
   *
   * @param fullEvidenceDescriptorDtlsList
   * Contains list of evidence descriptors.
   *
   * @return The list of filtered evidences in Active, In-Edit and Superseded
   * status.
   */
  protected EvidenceDescriptorDtlsList filterEvidences(
    final EvidenceDescriptorDtlsList fullEvidenceDescriptorDtlsList) {

    final EvidenceDescriptorDtlsList filteredEvidenceDescriptorDtlsList =
      new EvidenceDescriptorDtlsList();

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : fullEvidenceDescriptorDtlsList.dtls) {
      final EVIDENCEDESCRIPTORSTATUSEntry evidencedescriptorstatusEntry =
        EVIDENCEDESCRIPTORSTATUSEntry.get(evidenceDescriptorDtls.statusCode);

      if (EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALINEDIT
        .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALDISCARDED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREJECTED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREMOVALACCEPTED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALINEDIT
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALRESOLVED
          .equals(evidencedescriptorstatusEntry)
        || EVIDENCEDESCRIPTORSTATUSEntry.CANCELED
          .equals(evidencedescriptorstatusEntry)) {
        continue;
      }

      filteredEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);

    }
    return filteredEvidenceDescriptorDtlsList;
  }

  /**
   * Checks if the duplicate verification exists.
   *
   * @param verifiableDataItemAndRequirementIDDetails
   * Contains verifiable data items and requirement details.
   * @param vdIEDLinkDtls
   * Contains verification evidence descriptor link details.
   *
   * @return true if the duplicate verification exists, false otherwise.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature.
   */

  protected boolean isDuplicateVerification(
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final VerifiableDataItemAndRequirementIDDetails verifiableDataItemAndRequirementIDDetails,
    final VDIEDLinkDtls vdIEDLinkDtls)
    throws AppException, InformationalException {

    final VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();
    vDIEDLinkKey.VDIEDLinkID = vdIEDLinkDtls.VDIEDLinkID;

    final VerificationDtlsList verificationDtlsList =
      VerificationFactory.newInstance().readByVDIEDLinkID(vDIEDLinkKey);

    for (final VerificationDtls verificationDtls : verificationDtlsList.dtls) {

      if (verificationDtls.verificationRequirementID == verifiableDataItemAndRequirementIDDetails.verificationRequirementID) {

        if (verificationDtls.verificationLinkedType
          .equals(VERIFICATIONTYPE.NONCASEDATA)
          || verificationDtls.verificationLinkedID == newEvidenceDescriptorDtls.caseID) {

          return true;

        }
      }
    }

    return false;

  }

  // BEGIN, CR00414065, RD

  /**
   * Retrieves the list of case members for a case.
   *
   * @param caseID The unique identifier of a case.
   * @return The case members of the case.
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  protected ListPDClientRoleDetails listCaseMembers(final long caseID)
    throws AppException, InformationalException {

    final ListClientRoleKey listClientRoleKey = new ListClientRoleKey();

    listClientRoleKey.caseID = caseID;

    final ListPDClientRoleDetails listPDClientRoleDetails =
      filterOnlyCaseMembers(curam.core.facade.fact.ProductDeliveryFactory
        .newInstance().listClientRole(listClientRoleKey));

    // Get all the other members in the case who are not members and who is not
    // primary client.
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = caseID;
    final ConcernRoleIDList concernRoleIDList =
      verificationUtilities.getAdditionalCaseParticipants(caseKey);

    for (final ConcernRoleID concernRoleID : concernRoleIDList.dtls.items()) {
      final CaseParticipantRole_eoFullDetails caseParticipantRole_eoFullDetails =
        new CaseParticipantRole_eoFullDetails();

      caseParticipantRole_eoFullDetails.participantRoleID =
        concernRoleID.concernRoleID;
      listPDClientRoleDetails.caseParticipantRoleList
        .addRef(caseParticipantRole_eoFullDetails);
    }

    return listPDClientRoleDetails;
  }

  /**
   * Filter the list only for primary and case members only.
   *
   * @param listClientRole The not filtered list which contains all the case
   * participants in a product delivery case.
   *
   * @return The filtered list with only members of type primary and member.
   */
  protected ListPDClientRoleDetails
    filterOnlyCaseMembers(final ListPDClientRoleDetails listClientRole) {

    final ListPDClientRoleDetails listPDClientRoleDetails =
      new ListPDClientRoleDetails();

    for (final CaseParticipantRole_eoFullDetails casePartiRole_eoFullDetails : listClientRole.caseParticipantRoleList
      .items()) {

      if (CASEPARTICIPANTROLETYPE.PRIMARY
        .equals(casePartiRole_eoFullDetails.typeCode)
        || CASEPARTICIPANTROLETYPE.MEMBER
          .equals(casePartiRole_eoFullDetails.typeCode)) {
        listPDClientRoleDetails.caseParticipantRoleList
          .addRef(casePartiRole_eoFullDetails);
      }
    }
    return listPDClientRoleDetails;
  }

  /**
   * Checks whether the participant who is part of the evidence belongs to case.
   *
   * @param listICClientRoleDetails1 The list of case members.
   * @param evidenceDescriptorParticipantRoleID The participant role ID for whom
   * the evidence is added.
   * @return True or False corresponding on whether the participant is a case
   * member or not.
   */
  protected boolean isEvidenceDescriptorRelatedToCaseMember(
    final ListPDClientRoleDetails listPDClientRoleDetails,
    final long evidenceDescriptorParticipantRoleID) {

    boolean isEvidenceDescriptorRelatedToCaseMember = false;

    for (final CaseParticipantRole_eoFullDetails caseParticipantRole_eoFullDetails : listPDClientRoleDetails.caseParticipantRoleList
      .items()) {
      if (caseParticipantRole_eoFullDetails.participantRoleID == evidenceDescriptorParticipantRoleID) {
        isEvidenceDescriptorRelatedToCaseMember = true;
        break;
      }

    }
    return isEvidenceDescriptorRelatedToCaseMember;
  }

  // END, CR00414065

  // BEGIN, CR00417631, MV
  /**
   * Insert the record in to CurrentPostponedVerification table.
   *
   * @param newEvidenceDescriptorDtls
   * @param postponedOn The business process on which the evidence is postponed
   * - insert/update/Sharing
   *
   *
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  // BEGIN, CR00427025, MV
  protected void insertCurrentPostponedVerification(
    final EvidenceDescriptorDtls newEvidenceDescriptorDtls,
    final EvidenceDescriptorDtls oldEvidenceDescriptorDtls,
    final String postponedOn) throws AppException, InformationalException {

    // END, CR00427025

    // BEGIN, CR00426070, AKr
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID =
      newEvidenceDescriptorDtls.evidenceDescriptorID;

    final CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList =
      CurrentPostponedVerificationFactory.newInstance()
        .searchByEvidenceDescriptorID(evidenceDescriptorKey);

    if (currentPostponedVerificationDtlsList.dtls.size() > 0) {
      return;
    }
    // END, CR00426070
    final CurrentPostponedVerificationDtls currentPostponedVerificationDtls =
      new CurrentPostponedVerificationDtls();

    currentPostponedVerificationDtls.caseID =
      newEvidenceDescriptorDtls.caseID;
    currentPostponedVerificationDtls.evidenceDescriptorID =
      newEvidenceDescriptorDtls.evidenceDescriptorID;
    // BEGIN, CR00427025, MV
    currentPostponedVerificationDtls.oldEvidenceDescriptorID =
      oldEvidenceDescriptorDtls.evidenceDescriptorID;
    // END, CR00427025
    currentPostponedVerificationDtls.postponedByUser =
      TransactionInfo.getProgramUser();
    currentPostponedVerificationDtls.postponedOn = postponedOn;
    CurrentPostponedVerificationFactory.newInstance()
      .insert(currentPostponedVerificationDtls);
  }

  // END, CR00417631

  // BEGIN, CR00417399, AKr
  /**
   * Removes the outstanding verifications and the corresponding verification
   * waiver records for the
   * evidence reference passed in. When a evidence is superseded, the associated
   * outstanding verification is removed
   * to prevent it from affecting any other further processing that considers
   * outstanding verifications.
   *
   * @param EvidenceDescriptorDtls The details of the evidence descriptor that
   * is being superseded.
   *
   *
   *
   *
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public void removeVerificationForSuperseededEvidence(
    final EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    final EvidenceDescriptorIDAndVerStatusKey evidenceDescriptorIDAndVerStatusKey =
      new EvidenceDescriptorIDAndVerStatusKey();
    final Verification verificationObj = VerificationFactory.newInstance();

    evidenceDescriptorIDAndVerStatusKey.evidenceDescriptorID =
      evidenceDescriptorDtls.evidenceDescriptorID;
    final VerificationDtlsList verificationDtlsList =
      verificationObj.searchOutstandingVerificationsByEvidenceDescriptorID(
        evidenceDescriptorIDAndVerStatusKey);
    final VerificationWaiver verificationWaiverObj =
      VerificationWaiverFactory.newInstance();
    VerificationKey verificationKey;
    VerificationWaiverKey verificationWaiverKey;
    VerificationWaiverDtlsList verificationWaiverDtlsList;

    for (final VerificationDtls verificationDtls : verificationDtlsList.dtls
      .items()) {
      verificationKey = new VerificationKey();
      verificationKey.verificationID = verificationDtls.verificationID;
      verificationWaiverDtlsList =
        verificationWaiverObj.searchByVerificationID(verificationKey);

      for (final VerificationWaiverDtls verificationWaiverDtls : verificationWaiverDtlsList.dtls
        .items()) {
        verificationWaiverKey = new VerificationWaiverKey();
        verificationWaiverKey.verificationWaiverID =
          verificationWaiverDtls.verificationWaiverID;
        verificationWaiverObj.remove(verificationWaiverKey);
      }
      verificationObj.remove(verificationKey);
    }
  }

  // END, CR00417399

  // BEGIN, CR00456443, DG
  /**
   * {@inheritDoc}
   */
  @Override
  public Map<String, Integer>
    listOutstandingVerificationAndEvidenceTypeForCase(final CaseIDKey key,
      final boolean includeSharedEvidence)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final CaseIDVerificationStatusKey verificationKey =
      new CaseIDVerificationStatusKey();

    verificationKey.caseID = key.caseID;
    verificationKey.statusCode1 = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    verificationKey.statusCode2 = EVIDENCEDESCRIPTORSTATUS.INEDIT;

    if (includeSharedEvidence) {
      verificationKey.statusCode3 = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    }
    verificationKey.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;

    final VerificationCountAndEvidenceTypeDetailsList verificationList =
      verificationObj
        .listVerificationCountAndEvidenceTypeForCase(verificationKey);

    final Map<String, Integer> eviTypeAndVerCountMap =
      new HashMap<String, Integer>();

    for (final VerificationCountAndEvidenceTypeDetails dtls : verificationList.dtls) {
      eviTypeAndVerCountMap.put(dtls.evidenceType, dtls.recordCount);
    }
    return eviTypeAndVerCountMap;
  }

  // END, CR00456443

  // BEGIN, CR00452380, GK
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listOutstandingVerificationsForEvidenceDescriptor1(
      final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();

    final EvidenceDescriptorKeyList descriptorKeyList =
      new EvidenceDescriptorKeyList();

    descriptorKeyList.dtls.add(key);

    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().getEvidenceVerificationDetails(descriptorKeyList);

    // Populate the due date
    for (int i = 0; i < evidenceVerificationListDetails.verificationDtls
      .size(); i++) {

      if (evidenceVerificationListDetails.verificationDtls
        .item(i).verificationStatus.equals(VERIFICATIONSTATUS.VERIFIED)) {
        continue;
      }

      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationListDetails.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails1(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationListDetails.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listOutstandingVerificationsForBusinessObject1(
      final BusinessObjectKey key)
      throws AppException, InformationalException {

    final EvidenceVerificationDisplayDetailsList detailsList =
      listVerificationsForBusinessObject1(key);

    for (int i = 0; i < detailsList.list.size(); i++) {

      if (detailsList.list.item(i).verificationStatus
        .equals(VERIFICATIONSTATUS.VERIFIED)) {

        detailsList.list.remove(i);
        i--;
      }
    }

    return detailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listVerificationsForBusinessObject1(final BusinessObjectKey key)
      throws AppException, InformationalException {

    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();
    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = key.evidenceSuccessionID;
    final EvidenceDescriptorDtlsList fullEvidenceDescriptorDtlsList =
      filterEvidences(evidenceDescriptor.searchBySuccessionID(successionID));

    if (!fullEvidenceDescriptorDtlsList.dtls.isEmpty()) {
      // Get Participant evidence descriptor to check for Participant
      // Evidence
      // verifications

      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      // use first item in list, each item in list has same related id
      // and evidence type
      evidenceTypeKey.evidenceType =
        fullEvidenceDescriptorDtlsList.dtls.item(0).evidenceType;

      if (evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey)) {

        final EvidenceTypeParticipantIDStatusesKey participantIDEvidenceTypeStatusesKey =
          new EvidenceTypeParticipantIDStatusesKey();

        participantIDEvidenceTypeStatusesKey.evidenceType =
          evidenceTypeKey.evidenceType;
        participantIDEvidenceTypeStatusesKey.participantID =
          fullEvidenceDescriptorDtlsList.dtls.item(0).relatedID;
        participantIDEvidenceTypeStatusesKey.statusCode1 =
          EVIDENCEDESCRIPTORSTATUS.ACTIVE;
        participantIDEvidenceTypeStatusesKey.statusCode2 =
          EVIDENCEDESCRIPTORSTATUS.INEDIT;
        participantIDEvidenceTypeStatusesKey.statusCode3 =
          EVIDENCEDESCRIPTORSTATUS.SUPERSEDED;

        final EvidenceDescriptorDtlsList participantEvidenceDescriptorDtlsList =
          evidenceDescriptor.searchByEvidenceTypeParticipantIDAndStatus(
            participantIDEvidenceTypeStatusesKey);

        for (final EvidenceDescriptorDtls participantEvidenceDescriptorDtls : participantEvidenceDescriptorDtlsList.dtls) {
          fullEvidenceDescriptorDtlsList.dtls
            .addRef(participantEvidenceDescriptorDtls);
        }

      }
    }

    final EvidenceVerificationListDetails evidenceVerificationListDetails =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance()
        .retrieveEvidenceVerificationDetails(fullEvidenceDescriptorDtlsList);

    // Populate the due date
    for (int i = 0; i < evidenceVerificationListDetails.verificationDtls
      .size(); i++) {
      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationListDetails.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails1(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationListDetails.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  /**
   * Lists down the verifications for a case ID and evidence type.
   *
   * There is another version of this method -
   * listVerificationsForCaseAndEvidence. Therefore,
   * if there is any change made to this method, then developer should also
   * revisit
   *
   *
   * listVerificationsForCaseAndEvidence.
   *
   * @param key
   * Key containing case ID and Evidence type.
   *
   * @return A list of verifications for provided case id and evidence type.
   */
  @Override
  public EvidenceVerificationDisplayDetailsList
    listVerificationsForCaseAndEvidence1(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseID;
    final EvidenceVerificationDisplayDetailsList returnList =
      new EvidenceVerificationDisplayDetailsList();

    curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      new curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList();

    evidenceVerificationDetailsList =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance().listEvidenceVerificationDetails(key);

    // Populate the due date
    for (int i = 0; i < evidenceVerificationDetailsList.verificationDtls
      .size(); i++) {

      final EvidenceVerificationDetails evidenceVerificationDetails =
        new EvidenceVerificationDetails();

      evidenceVerificationDetails
        .assign(evidenceVerificationDetailsList.verificationDtls.item(i));

      final curam.verification.sl.infrastructure.intf.Verification verificationSLObj =
        curam.verification.sl.infrastructure.fact.VerificationFactory
          .newInstance();

      ViewVerificationDetails viewVerificationDetails =
        new ViewVerificationDetails();

      viewVerificationDetails = verificationSLObj
        .readVerificationDetails1(evidenceVerificationDetails);

      final EvidenceVerificationDisplayDetails returnItem =
        new EvidenceVerificationDisplayDetails();

      returnItem.assign(evidenceVerificationDetails);

      final LocalisableString summary = new LocalisableString(
        ENTVERIFICATION.INF_DYNAMIC_VERIFICATION_SUMMARY);

      summary.arg(
        evidenceVerificationDetailsList.verificationDtls.item(i).summary);

      returnItem.summary = summary.toClientFormattedText();
      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.concernRoleID = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).participantID;

      final ConcernRoleKey crKey = new ConcernRoleKey();
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      crKey.concernRoleID = returnItem.concernRoleID;

      returnItem.concernRoleName =
        concernRoleObj.readConcernRoleName(crKey).concernRoleName;

      for (int j = 0; j < viewVerificationDetails.summaryDetailsList
        .size(); j++) {

        if (returnItem.verificationStatus
          .equals(viewVerificationDetails.summaryDetailsList
            .item(j).verificationStatus)) {

          returnItem.dueDate =
            viewVerificationDetails.summaryDetailsList.item(j).dueDate;
        }
      }
      returnList.list.add(returnItem);
    }

    return returnList;
  }

  // END, CR00452380

}
