/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2013, 2015
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office
 */

/*
 * Copyright 2006, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachment.impl.Attachment;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONITEMNAME;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.UniqueID;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.ReadCaseAttachmentKey;
import curam.message.ENTVERIFICATIONATTACHMENT;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.verification.facade.infrastructure.struct.CreateVerificationAttachmentDetails;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.struct.VerificationItemName;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.ItemProvidedIDAndVDIEDLinkIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentSummaryDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentSummaryDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemUtilizationIDDetails;
import curam.verification.sl.infrastructure.struct.CancelVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.CreateVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.ModifyVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.ReadVerificationAttachmentLinkDetails;
import curam.verification.sl.infrastructure.struct.ReadVerificationAttachmentLinkKey;
import curam.verification.sl.infrastructure.struct.VerificationAttachmentLinkID;
import curam.verification.sl.struct.VerificationPageContextDetails;
import java.io.File;
import java.util.Set;


/**
 * This process class provides the functionality for the Verification Attachment
 * Link service layer.
 */
public abstract class VerificationAttachmentLink extends curam.verification.sl.infrastructure.base.VerificationAttachmentLink {

  // BEGIN, CR00146458, VR
  @Inject
  private Attachment attachment;

  // END, CR00146458
  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00354960

  // Add injection for using the new CaseTransactionLog API
  public VerificationAttachmentLink() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves the page context description for verification attachment
   *
   * @param key - Verification Item Provided Key
   * @return Verification Page Context Details
   */
  @Override
  public VerificationPageContextDetails readPageContextDescriptionForAttachment(VerificationItemProvidedKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvided = VerificationItemProvidedFactory.newInstance();
    final curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface = CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    final VerificationPageContextDetails verificationPageContextDetails = new VerificationPageContextDetails();
    VerificationItemUtilizationIDDetails verificationItemUtilizationIDDetails = new VerificationItemUtilizationIDDetails();

    verificationItemUtilizationIDDetails = verificationItemProvided.readUtilizationID(
      key);
    final VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = verificationItemUtilizationIDDetails.verificationItemUtilizationID;
    VerificationItemName verificationItemNames = new VerificationItemName();

    verificationItemNames = verificationItemUtilization.readVerificationItemName(
      verificationItemUtilizationKey);

    verificationPageContextDetails.description = verificationItemNames.name;

    ctitemKey.code = verificationItemUtilization.readVerificationItemName(verificationItemUtilizationKey).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  /**
   * Reads Verification Attachment Link details
   *
   * @param key - Read Verification Attachment Link Key
   * @return verification attachment link details
   */
  @Override
  public ReadVerificationAttachmentLinkDetails readVerificationAttachmentLink(ReadVerificationAttachmentLinkKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();

    final VerificationAttachmentLinkID verificationAttachmentLinkID = new VerificationAttachmentLinkID();
    final ReadVerificationAttachmentLinkDetails readVerificationAttachmentLinkDetails = new ReadVerificationAttachmentLinkDetails();

    final AttachmentKey attachmentKey = new AttachmentKey();

    verificationAttachmentLinkID.verificationAttachmentLinkID = key.verificationAttachmentLinkID;
    ReadCaseAttachmentKey readCaseAttachmentKey = new ReadCaseAttachmentKey();

    readCaseAttachmentKey = verificationAttachmentLink.readAttachmentIDByLinkID(
      verificationAttachmentLinkID);
    attachmentKey.attachmentID = readCaseAttachmentKey.attachmentID;
    // BEGIN, CR00146458, VR
    readVerificationAttachmentLinkDetails.readAttachmentDtls = attachment.read(
      attachmentKey);
    // END, CR00146458
    final VerificationAttachmentLinkKey verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();

    verificationAttachmentLinkKey.verificationAttachmentLinkID = key.verificationAttachmentLinkID;
    readVerificationAttachmentLinkDetails.readLinkDtls = verificationAttachmentLink.read(
      verificationAttachmentLinkKey);

    return readVerificationAttachmentLinkDetails;
  }

  // BEGIN, CR00214905, MR
  /**
   * Adds an attachment.
   *
   * @param details
   * Verification attachment details.
   *
   * @return The unique identifier of the record created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public VerificationAttachmentLinkKey createVerificationAttachmentLink(
    final CreateVerificationAttachmentLinkDetails details)
    throws AppException, InformationalException {

    // END, CR00214905
    // Verification Attachment Link variables
    final curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();
    final VerificationAttachmentLinkKey verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();

    // insert attachment details
    // Determine if the contents of the attachment are included
    if (details.createAttachmentDtls.attachmentContents.length() > 0) {
      details.createAttachmentDtls.attachedFileInd = true;
    } else {
      details.createAttachmentDtls.attachedFileInd = false;
    }
    // BEGIN, CR00155031, MC
    // BEGIN, CR00148723, VR
    if (!getAttachmentIndicator(details)) // END, CR00148723
    {
      // END, CR00155031
      details.createAttachmentDtls.statusCode = RECORDSTATUS.DEFAULTCODE;
      // BEGIN, CR00359837, SSK
      if (details.createAttachmentDtls.receiptDate.isZero()) {
        details.createAttachmentDtls.receiptDate = Date.getCurrentDate();
      }
      // END, CR00359837
      details.createAttachmentDtls.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
      // BEGIN, CR00155031, MC
    }
    // END, CR00155031

    // END, CR00148723

    validateAttachmentLink(details.createLinkDtls, details.createAttachmentDtls);

    // BEGIN, CR00150148, MC
    // BEGIN, CR00146458, VR

    if (!getAttachmentIndicator(details)) {
      // BEGIN, CR00214905, MR
      final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

      details.createAttachmentDtls.attachmentID = uniqueIDObj.getNextID();
      // END, CR00214905

      // BEGIN, CR00354960, CD
      //
      // set up meta data for the attachment
      //
      final curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
      final VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

      verificationItemProvidedKey.verificationItemProvidedID = details.createLinkDtls.verificationItemProvidedID;
      final EvidenceDescriptorDetails evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
        verificationItemProvidedKey);

      final EvidenceDescriptor evDescObj = EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
      final EvidenceDescriptorDtls evidenceDescriptorDtls = evDescObj.read(
        evidenceDescriptorKey);

      final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      cmsMetadata.add(CMSMetadataConst.kCaseID,
        Long.toString(evidenceDescriptorDtls.caseID));
      cmsMetadata.add(CMSMetadataConst.kParticipantID,
        Long.toString(evidenceDescriptorDtls.participantID));
      // END, CR00354960

      //
      // insert the attachment record
      //

      attachment.insert(details.createAttachmentDtls);

      // BEGIN, CR00400972, RPB
      final curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvided = curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory.newInstance();

      final curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey viProvidedKey = new curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey();

      viProvidedKey.verificationItemProvidedID = details.createLinkDtls.verificationItemProvidedID;
      final VerificationItemProvidedDtls verificationItemProvidedDtls = verificationItemProvided.read(
        viProvidedKey);

      final curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey vDIEDLinkKey = new curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID = verificationItemProvidedDtls.VDIEDLinkID;

      final VDIEDLink vdiedLink = VDIEDLinkFactory.newInstance();
      final VDIEDLinkDtls vdiedLinkDtls = vdiedLink.read(vDIEDLinkKey);
      // BEGIN, CR00451715, MR
      final VerificationItemUtilizationDtls verificationItemUtilizationDtls = VerificationConfigurationCacheUtils.getVerificationItemUtilizationDtls(
        verificationItemProvidedDtls.verificationItemUtilizationID);

      final Set<VerificationItemUtilizationDtls> verificationItemUtilizationDtlsSet = VerificationConfigurationCacheUtils.fetchVerificationItemUtilizationDtlsList(
        vdiedLinkDtls.verifiableDataItemID,
        verificationItemUtilizationDtls.verificationItemID);

      for (final VerificationItemUtilizationDtls verificationItemUtilizationUsageDetails : verificationItemUtilizationDtlsSet) {

        // BEGIN, CR00414157, GK
        final ItemProvidedIDAndVDIEDLinkIDDetails itemProvidedIDAndVDIEDLinkIDDetails = new ItemProvidedIDAndVDIEDLinkIDDetails();

        itemProvidedIDAndVDIEDLinkIDDetails.verificationItemUtilizationID = verificationItemUtilizationUsageDetails.verificationItemUtilizationID;
        itemProvidedIDAndVDIEDLinkIDDetails.VDIEDLinkID = verificationItemProvidedDtls.VDIEDLinkID;
        itemProvidedIDAndVDIEDLinkIDDetails.recordStatus = RECORDSTATUS.NORMAL;
        final VerificationItemProvidedDtlsList verificationItemProvidedDtlsList = verificationItemProvided.searchItemProvidedByItemUtilizationIDAndVDIEDLinkID(
          itemProvidedIDAndVDIEDLinkIDDetails);
        CreateVerificationAttachmentDetails createVerificationAttachmentDetails;

        for (final VerificationItemProvidedDtls viItemProvidedDtls : verificationItemProvidedDtlsList.dtls.items()) {
          createVerificationAttachmentDetails = new CreateVerificationAttachmentDetails();

          createVerificationAttachmentDetails.details.createAttachmentDtls = details.createAttachmentDtls;
          createVerificationAttachmentDetails.details.createLinkDtls = details.createLinkDtls;
          createVerificationAttachmentDetails.details.createLinkDtls.verificationItemProvidedID = viItemProvidedDtls.verificationItemProvidedID;
          details.createLinkDtls.attachmentID = details.createAttachmentDtls.attachmentID;
          // insert attachment link details
          details.createLinkDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
          verificationAttachmentLink.insert(details.createLinkDtls);

          if (details.createLinkDtls.verificationItemProvidedID
            == viItemProvidedDtls.verificationItemProvidedID) {
            verificationAttachmentLinkKey.verificationAttachmentLinkID = details.createLinkDtls.verificationAttachmentLinkID;
          }
          // END, CR00414157
        }
      }
      // END, CR00400972
      // END, CR00451715
    }

    // END, CR00146458
    // END, CR00150148
    return verificationAttachmentLinkKey;
  }

  /**
   * Method to modify an attachment
   *
   * @param details Details of the attachment to be modified.
   */
  @Override
  public void modifyVerificationAttachmentLink(
    ModifyVerificationAttachmentLinkDetails details) throws AppException,
      InformationalException {

    final ReadVerificationAttachmentLinkDetails readVerificationAttachmentLinkDetails = new ReadVerificationAttachmentLinkDetails();

    final curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();

    final VerificationAttachmentLinkKey verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();

    VerificationAttachmentLinkDtls verificationAttachmentLinkDtls = new VerificationAttachmentLinkDtls();

    final AttachmentKey attachmentKey = new AttachmentKey();

    attachmentKey.attachmentID = details.modifyAttachmentDtls.attachmentID;
    final AttachmentDtls attachmentDtls = details.modifyAttachmentDtls;

    // update the attachment name if the attachment has not been updated
    // BEGIN, CR00146458, VR
    readVerificationAttachmentLinkDetails.readAttachmentDtls = attachment.read(
      attachmentKey);
    // END, CR00146458
    // BEGIN, CR00052924, GM
    if (readVerificationAttachmentLinkDetails.readAttachmentDtls.attachmentName.equals(
      CuramConst.gkEmpty)) {
      // END, CR00052924
      details.modifyAttachmentDtls.attachmentName = details.modifyAttachmentDtls.attachmentName;
      // BEGIN, CR00052924, GM
    } else if (details.modifyAttachmentDtls.attachmentName.equals(
      CuramConst.gkEmpty)) {
      // END, CR00052924
      details.modifyAttachmentDtls.attachmentName = readVerificationAttachmentLinkDetails.readAttachmentDtls.attachmentName;
    }

    validateAttachmentLink(details.modifyLinkDtls, details.modifyAttachmentDtls);

    // BEGIN, CR00277373, ELG
    if (attachmentDtls.attachmentContents.length() == 0) {
      attachmentDtls.attachmentContents = readVerificationAttachmentLinkDetails.readAttachmentDtls.attachmentContents;
    }
    // END, CR00277373

    // BEGIN, CR00365030, CD
    //
    // set up meta data for the attachment
    //
    final curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

    verificationItemProvidedKey.verificationItemProvidedID = details.modifyLinkDtls.verificationItemProvidedID;
    final EvidenceDescriptorDetails evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);

    final EvidenceDescriptor evDescObj = EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    final EvidenceDescriptorDtls evidenceDescriptorDtls = evDescObj.read(
      evidenceDescriptorKey);
    final CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(evidenceDescriptorDtls.caseID));
    cmsMetadata.add(CMSMetadataConst.kParticipantID,
      Long.toString(evidenceDescriptorDtls.participantID));
    // END, CR00365030

    // BEGIN, CR00146458, VR
    attachment.modify(attachmentKey, attachmentDtls);
    // END, CR00146458
    verificationAttachmentLinkDtls.recordStatus = details.modifyLinkDtls.recordStatus;
    verificationAttachmentLinkDtls.attachmentID = details.modifyAttachmentDtls.attachmentID;
    verificationAttachmentLinkDtls.description = details.modifyLinkDtls.description;
    verificationAttachmentLinkKey.verificationAttachmentLinkID = details.modifyLinkDtls.verificationAttachmentLinkID;
    verificationAttachmentLinkDtls.verificationAttachmentLinkID = details.modifyLinkDtls.verificationAttachmentLinkID;
    verificationAttachmentLinkDtls.verificationItemProvidedID = details.modifyLinkDtls.verificationItemProvidedID;
    verificationAttachmentLink.modify(verificationAttachmentLinkKey,
      verificationAttachmentLinkDtls);

    // BEGIN, CR00400972, RPB
    final VerificationAttachmentKey verificationAttachmentKey = new VerificationAttachmentKey();

    verificationAttachmentKey.attachmentID = details.modifyAttachmentDtls.attachmentID;
    final VerificationAttachmentLinkDtlsList verificationAttachmentLinkDtlsList = verificationAttachmentLink.searchByAttachmentID(
      verificationAttachmentKey);

    for (final VerificationAttachmentLinkDtls vaLinkDtls : verificationAttachmentLinkDtlsList.dtls.items()) {
      final VerificationAttachmentLinkKey vaLinkKey = new VerificationAttachmentLinkKey();

      vaLinkKey.verificationAttachmentLinkID = vaLinkDtls.verificationAttachmentLinkID;
      vaLinkDtls.description = details.modifyLinkDtls.description;
      verificationAttachmentLink.modify(vaLinkKey, vaLinkDtls);
    }
    // END, CR00400972

    // BEGIN, CR00399910, MV
    if (CuramConst.gkYes.equalsIgnoreCase(
      Configuration.getProperty(
        EnvVars.ENV_PREVENT_DUPLICATE_VERIFICATION_ITEM_ATTACHMENT))) {
      final VerificationAttachmentLinkID verificationAttachmentLinkID = new VerificationAttachmentLinkID();

      verificationAttachmentLinkID.verificationAttachmentLinkID = verificationAttachmentLinkKey.verificationAttachmentLinkID;
      final VerificationAttachmentSummaryDetailsList listVerificationAttachLink = verificationAttachmentLink.searchAttachmentByVerificationAttachmentLink(
        verificationAttachmentLinkID);

      for (final VerificationAttachmentSummaryDetails verificationAttachmentSummaryDetails : listVerificationAttachLink.dtls.items()) {
        if (verificationAttachmentSummaryDetails.verificationAttachmentLinkID
          != verificationAttachmentLinkKey.verificationAttachmentLinkID) {
          verificationAttachmentLinkDtls = new VerificationAttachmentLinkDtls();
          verificationAttachmentLinkDtls.recordStatus = details.modifyLinkDtls.recordStatus;
          verificationAttachmentLinkDtls.attachmentID = details.modifyAttachmentDtls.attachmentID;
          verificationAttachmentLinkDtls.description = details.modifyLinkDtls.description;
          verificationAttachmentLinkKey.verificationAttachmentLinkID = verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
          verificationAttachmentLinkDtls.verificationItemProvidedID = verificationAttachmentLink.read(verificationAttachmentLinkKey).verificationItemProvidedID;
          verificationAttachmentLinkDtls.verificationAttachmentLinkID = verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
          verificationAttachmentLink.modify(verificationAttachmentLinkKey,
            verificationAttachmentLinkDtls);
        }
      }
      final Event verificationAttachmentUpdatedEvent = new Event();

      verificationAttachmentUpdatedEvent.eventKey = curam.events.Verification.VerificationAttachmentUpdated;
      verificationAttachmentUpdatedEvent.primaryEventData = verificationAttachmentLinkKey.verificationAttachmentLinkID;
      EventService.raiseEvent(verificationAttachmentUpdatedEvent);
    }
    // END, CR00399910
  }

  /**
   * Method to cancel an attachment
   *
   * @param details Details of the attachment to be cancelled.
   */
  @Override
  public void cancelVerificationAttachmentLink(
    CancelVerificationAttachmentLinkDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();

    VerificationAttachmentLinkKey verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();

    verificationAttachmentLinkKey.verificationAttachmentLinkID = details.cancelDtls.verificationAttachmentLinkID;

    // BEGIN, CR00400972, RPB
    final VerificationAttachmentLinkDtls verificationAttachmentLinkDtls = verificationAttachmentLink.read(
      verificationAttachmentLinkKey);
    final VerificationAttachmentKey verificationAttachmentKey = new VerificationAttachmentKey();

    verificationAttachmentKey.attachmentID = verificationAttachmentLinkDtls.attachmentID;
    final VerificationAttachmentLinkDtlsList verificationAttachmentLinkDtlsList = verificationAttachmentLink.searchByAttachmentID(
      verificationAttachmentKey);

    for (final VerificationAttachmentLinkDtls vaLinkDtls : verificationAttachmentLinkDtlsList.dtls.items()) {
      verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();
      verificationAttachmentLinkKey.verificationAttachmentLinkID = vaLinkDtls.verificationAttachmentLinkID;
      final CancelVerificationAttachmentLinkDetails cancelVerificationAttachmentLinkDetails = new CancelVerificationAttachmentLinkDetails();

      cancelVerificationAttachmentLinkDetails.cancelDtls.recordStatus = vaLinkDtls.recordStatus;
      cancelVerificationAttachmentLinkDetails.cancelDtls.verificationAttachmentLinkID = vaLinkDtls.verificationAttachmentLinkID;
      verificationAttachmentLink.cancel(verificationAttachmentLinkKey,
        cancelVerificationAttachmentLinkDetails.cancelDtls);

      final Event verificationAttachmentDeletedEvent = new Event();

      verificationAttachmentDeletedEvent.eventKey = curam.events.Verification.VerificationAttachmentDeleted;
      verificationAttachmentDeletedEvent.primaryEventData = cancelVerificationAttachmentLinkDetails.cancelDtls.verificationAttachmentLinkID;
      EventService.raiseEvent(verificationAttachmentDeletedEvent);
    }
    // END, CR00400972

    // BEGIN, CR00399910, MV
    if (CuramConst.gkYes.equalsIgnoreCase(
      Configuration.getProperty(
        EnvVars.ENV_PREVENT_DUPLICATE_VERIFICATION_ITEM_ATTACHMENT))) {
      final VerificationAttachmentLinkID verificationAttachmentLinkID = new VerificationAttachmentLinkID();

      verificationAttachmentLinkID.verificationAttachmentLinkID = verificationAttachmentLinkKey.verificationAttachmentLinkID;
      final VerificationAttachmentSummaryDetailsList listVerificationAttachLink = verificationAttachmentLink.searchAttachmentByVerificationAttachmentLink(
        verificationAttachmentLinkID);

      for (final VerificationAttachmentSummaryDetails verificationAttachmentSummaryDetails : listVerificationAttachLink.dtls.items()) {
        if (verificationAttachmentSummaryDetails.verificationAttachmentLinkID
          != verificationAttachmentLinkKey.verificationAttachmentLinkID) {
          verificationAttachmentLinkKey.verificationAttachmentLinkID = verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
          details.cancelDtls.verificationAttachmentLinkID = verificationAttachmentSummaryDetails.verificationAttachmentLinkID;
          details.cancelDtls.recordStatus = RECORDSTATUS.NORMAL;
          verificationAttachmentLink.cancel(verificationAttachmentLinkKey,
            details.cancelDtls);
        }
      }
    }
    // END, CR00399910
  }

  /**
   * method to validate before inserting or modifying an attachment
   *
   * @param key verification attachment link key
   *
   * @return page context details for verification attachment link
   */
  public VerificationPageContextDetails readPageContextDescription(
    curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkKey key)
    throws AppException, InformationalException {

    return null;
  }

  /**
   * method to validate before inserting or modifying an attachment
   *
   * @param attachementLinkDetails AttachmentLink record details,
   * @param attachmentDtls Details of an attachment to be validated.
   */
  @Override
  public void validateAttachmentLink(
    VerificationAttachmentLinkDtls attachementLinkDetails,
    AttachmentDtls attachmentDtls) throws AppException,
      InformationalException {

    File attachmentName;

    if (attachmentDtls.attachmentName.length() > 0) {
      attachmentDtls.attachedFileInd = true;
    } else {
      attachmentDtls.attachedFileInd = false;
    }

    final boolean atachmentNameProvided = attachmentDtls.attachmentName.length()
      != 0;

    final boolean atachmentContentsProvided = attachmentDtls.attachmentContents.length()
      != 0;

    final boolean locationORReferenceProvided = attachmentDtls.fileLocation.length()
      != 0
        || attachmentDtls.fileReference.length() != 0;

    // BEGIN, CR00021492, NK
    if (atachmentNameProvided) {
      // END, CR00021492
      if (atachmentContentsProvided && locationORReferenceProvided) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            ENTVERIFICATIONATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    if (attachementLinkDetails.description.length() != 0) {
      if (!(atachmentNameProvided || locationORReferenceProvided)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            ENTVERIFICATIONATTACHMENT.ERR_CASEATTACHMENT_DESCRIPTION_THEN_ATTACHMENT_OR_LOCATION_OR_REFERENCE_PROVIDED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    if (atachmentNameProvided) {

      // parse attachmentName from path of attachment, leaving just the base
      // name

      attachmentName = new File(attachmentDtls.attachmentName);
      attachmentDtls.attachmentName = attachmentName.getName();

    }

    if (attachmentDtls.receiptDate.after(Date.getCurrentDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONATTACHMENT.ERR_CASEATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Reads Page Context Attachment by attachment id
   *
   * @param key - verification attachment link key
   * @return page context details
   */
  @Override
  public VerificationPageContextDetails readPageContextDescAttachmentByAttachID(
    curam.verification.facade.infrastructure.struct.ReadVerificationAttachmentLinkKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();

    // code table variables
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface = CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    final VerificationPageContextDetails verificationPageContextDetails = new VerificationPageContextDetails();

    final VerificationAttachmentLinkKey verificationAttachmentLinkKey = new VerificationAttachmentLinkKey();

    verificationAttachmentLinkKey.verificationAttachmentLinkID = key.key.verificationAttachmentLinkID;
    ctitemKey.code = verificationAttachmentLink.readVerificationItemContextNameByAttachID(verificationAttachmentLinkKey).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  /**
   * This method checks whether an attachment exists for the evidence
   * verification
   *
   * @param details
   * @return
   */
  // BEGIN, CR00148723, VR
  // BEGIN, CR00198672, VK
  protected boolean getAttachmentIndicator(
    CreateVerificationAttachmentLinkDetails details) {

    // END, CR00198672
    boolean indAttachment = false;
    final boolean attachmentContentsProvided = details.createAttachmentDtls.attachmentContents.length()
      != 0;

    final boolean locationORReferenceProvided = details.createAttachmentDtls.fileLocation.length()
      != 0
        || details.createAttachmentDtls.fileReference.length() != 0;

    if (!attachmentContentsProvided && !locationORReferenceProvided) {
      indAttachment = true;
    }
    return indAttachment;
  }
  // END, CR00148723
}
