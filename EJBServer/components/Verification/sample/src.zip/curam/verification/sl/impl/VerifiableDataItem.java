/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.struct.CancelVerifiableDataItemDetails;
import curam.verification.sl.struct.CreateVerifiableDataItemDetails;
import curam.verification.sl.struct.ModifyVerifiableDataItemDetails;
import curam.verification.sl.struct.ReadVerifiableDataItemDetails;
import curam.verification.sl.struct.VerifiableDataItemNameDetails;


/**
 * This process class provides the functionality for the Verifiable Data Item
 * service layer.
 */
public abstract class VerifiableDataItem extends curam.verification.sl.base.VerifiableDataItem {

  // ___________________________________________________________________________
  /**
   * Cancels a Verifiable Data Item record
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void cancelVerifiableDataItem(CancelVerifiableDataItemDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    // Create and populate the Verifiable Data Item key
    final VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID = details.cancelDtls.verifiableDataItemID;

    // Cancel a Verifiable Data Item record
    verifiableDataItemObj.cancel(verifiableDataItemKey, details.cancelDtls);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Verifiable Data Item record
   *
   * @param details Verifiable Data Item details
   *
   * @return The unique identifier of the record created
   */
  @Override
  public VerifiableDataItemKey createVerifiableDataItem(
    CreateVerifiableDataItemDetails details) throws AppException,
      InformationalException {

    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    // Create a Verifiable Data Item record
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    verifiableDataItemObj.insert(details.createDtls);

    // Create and populate the return struct
    final VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID = details.createDtls.verifiableDataItemID;

    return verifiableDataItemKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verifiable Data Item record
   *
   * @param details Verifiable Data Item details
   */
  @Override
  public void modifyVerifiableDataItem(ModifyVerifiableDataItemDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    // Create and populate the Verifiable Data Item key
    final VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID = details.modiffDtls.verifiableDataItemID;

    // Modify a Verifiable Data Item record
    verifiableDataItemObj.modify(verifiableDataItemKey, details.modiffDtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads a Verifiable Data Item record
   *
   * @param key Verifiable Data Item details
   *
   * @return Details of the Verifiable Data Item record
   */
  @Override
  public ReadVerifiableDataItemDetails readVerifiableDataItem(
    VerifiableDataItemKey key) throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    // Create the return object
    final ReadVerifiableDataItemDetails readVerifiableDataItemDetails = new ReadVerifiableDataItemDetails();

    // Read the Verifiable Data Item record
    readVerifiableDataItemDetails.readDtls = verifiableDataItemObj.read(key);

    return readVerifiableDataItemDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Verifiable Data Item Name
   *
   * @param key - verifiable data item key
   * @return verifiable data item name details
   */
  @Override
  public VerifiableDataItemNameDetails readVerifiableDataItemName(
    VerifiableDataItemKey key) throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();
    final VerifiableDataItemNameDetails verifiableDataItemNameDetails = new VerifiableDataItemNameDetails();

    verifiableDataItemNameDetails.nameDtls = verifiableDataItemObj.readNameByID(
      key);
    return verifiableDataItemNameDetails;
  }

}
