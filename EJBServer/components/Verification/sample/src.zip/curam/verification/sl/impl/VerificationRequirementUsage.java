/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.sl.impl.VerificationRelatedTypeUtil;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.entity.struct.VerificationRequirementUsageKey;
import curam.verification.sl.struct.CancelVerificationRequirementUsageDetails;
import curam.verification.sl.struct.CreateVerificationRequirementUsageDetails;
import curam.verification.sl.struct.ModifyVerificationRequirementUsageDetails;
import curam.verification.sl.struct.ReadVerificationRequirementUsageDetails;


/**
 * This process class provides the functionality for the Verification
 * Requirement Usage service layer.
 */
public abstract class VerificationRequirementUsage extends curam.verification.sl.base.VerificationRequirementUsage {

  // ___________________________________________________________________________
  /**
   * Cancels a Verification Requirement Usage record
   *
   * @param details Verification Requirement Usage details
   */
  @Override
  public void cancelVerificationRequirementUsage(
    CancelVerificationRequirementUsageDetails details) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();
    // Create and populate the Verification Category key
    final VerificationRequirementUsageKey verificationRequirementUsageKey = new VerificationRequirementUsageKey();

    verificationRequirementUsageKey.verificationRequirementUsageID = details.cancelDtls.verificationRequirementUsageID;

    // Cancel a Verification Requirement Usage record
    verificationRequirementUsage.cancel(verificationRequirementUsageKey,
      details.cancelDtls);

  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification Requirement Usage record
   *
   * @param details Verification Requirement Usage details
   */
  @Override
  public VerificationRequirementUsageKey createVerificationRequirementUsage(
    CreateVerificationRequirementUsageDetails details) throws AppException,
      InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    // Create a Verification Requirement Usage record
    verificationRequirementUsage.insert(details.createDtls);

    final VerificationRequirementUsageKey verificationRequirementUsageKey = new VerificationRequirementUsageKey();

    verificationRequirementUsageKey.verificationRequirementUsageID = details.createDtls.verificationRequirementUsageID;

    return verificationRequirementUsageKey;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verification Requirement Usage record
   *
   * @param details Verification Requirement Usage details
   */
  @Override
  public void modifyVerificationRequirementUsage(
    ModifyVerificationRequirementUsageDetails details) throws AppException,
      InformationalException {

    // create object at entity level
    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();
    // Create and populate the Verification Requirement Usage key
    final VerificationRequirementUsageKey verificationRequirementUsageKey = new VerificationRequirementUsageKey();

    verificationRequirementUsageKey.verificationRequirementUsageID = details.modifyDtls.verificationRequirementUsageID;
    // Create a Verification category record
    verificationRequirementUsage.modify(verificationRequirementUsageKey,
      details.modifyDtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification Requirement Usage record
   *
   * @param key Verification Requirement Usage Details
   * @return details Verification Requirement Usage Details
   */
  @Override
  public ReadVerificationRequirementUsageDetails readVerificationRequirementUsage(VerificationRequirementUsageKey key)
    throws AppException, InformationalException {

    // create objects and structures at entity level
    final curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    // create return structure
    final ReadVerificationRequirementUsageDetails readVerificationRequirementUsageDetails = new ReadVerificationRequirementUsageDetails();

    // Read the Verification Requirement Usage Record
    readVerificationRequirementUsageDetails.readDtls = verificationRequirementUsage.read(
      key);

    // BEGIN, CR00369537, RPB
    final VerificationRelatedTypeUtil relatedTypeUtil = new VerificationRelatedTypeUtil();

    readVerificationRequirementUsageDetails.description = relatedTypeUtil.getDescription(
      readVerificationRequirementUsageDetails.readDtls.relatedItemID,
      readVerificationRequirementUsageDetails.readDtls.relatedItemType);
    // END, CR00369537

    return readVerificationRequirementUsageDetails;

  }

}
