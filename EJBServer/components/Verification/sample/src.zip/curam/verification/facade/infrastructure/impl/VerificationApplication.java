/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.verification.facade.infrastructure.impl;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.DOCUMENTREVIEWSTATUS;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFIABLEITEMNAME;
import curam.codetable.VERIFICATIONCONTROLLER;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.facade.fact.ConcernRoleFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.intf.ParticipantContext;
import curam.core.facade.struct.ActionIDProperty;
import curam.core.facade.struct.CaseKey_fo;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ParticipantKey;
import curam.core.facade.struct.WizardProperties;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.CountDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.entity.struct.ReadByTypeAndCaseIDKey;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.ReadRelatedIDParticipantIDAndEvidenceTypeDetails;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.fact.EvidenceRelationshipFactory;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.BusinessObjectKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDisplayDetails;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.pods.impl.PodsConst;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.EmploymentKey;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.ICParticipantHomePageKey;
import curam.core.struct.ICParticipantHomePageName;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.core.struct.UsersKey;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.VERIFICATIONWAIVER;
import curam.message.verification.VERIFICATIONDETAILSPANEL;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.ValueList;
import curam.verification.facade.infrastructure.struct.CancelUserProvidedVerificationItemDetails;
import curam.verification.facade.infrastructure.struct.CancelVerificationAttachmentDetails;
import curam.verification.facade.infrastructure.struct.CancelVerificationItemProvidedDetails;
import curam.verification.facade.infrastructure.struct.CaseEvidenceVerificationDisplayDetails;
import curam.verification.facade.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList;
import curam.verification.facade.infrastructure.struct.CaseIDAndEvidenceTypeKey;
import curam.verification.facade.infrastructure.struct.CaseIDEvidenceIDAndTypeKey;
import curam.verification.facade.infrastructure.struct.CreateVerificaitonItemProvidedDetails;
import curam.verification.facade.infrastructure.struct.CreateVerificationAttachmentDetails;
import curam.verification.facade.infrastructure.struct.DataItemNameVerificationIDDtls;
import curam.verification.facade.infrastructure.struct.EvidenceTypeAndRelatedIDDetails;
import curam.verification.facade.infrastructure.struct.EvidenceTypeDescriptionDetails;
import curam.verification.facade.infrastructure.struct.EvidenceTypeDetails;
import curam.verification.facade.infrastructure.struct.EvidenceVerificationDetails;
import curam.verification.facade.infrastructure.struct.IntegratedCaseVerificationDetailsList;
import curam.verification.facade.infrastructure.struct.IntegratedCaseVerificationDetailsListForDuplicate;
import curam.verification.facade.infrastructure.struct.ListBusinessObjectVerificationDetails;
import curam.verification.facade.infrastructure.struct.ListEvidenceVerificationDetails;
import curam.verification.facade.infrastructure.struct.ListEvidenceVerificationDetailsAndEvidenceType;
import curam.verification.facade.infrastructure.struct.ListVerificationItemNameAndLevelDetails;
import curam.verification.facade.infrastructure.struct.ListVerificationItemNameDetails;
import curam.verification.facade.infrastructure.struct.ModifyVerificationAttachmentDetails;
import curam.verification.facade.infrastructure.struct.ModifyVerificationRequirementDueDateKey;
import curam.verification.facade.infrastructure.struct.ModifyVerificationWaiverDetails;
import curam.verification.facade.infrastructure.struct.NewUserProvidedVerItemAndEvdDetails;
import curam.verification.facade.infrastructure.struct.NewUserProvidedVerItemAndWizardDetails;
import curam.verification.facade.infrastructure.struct.NewUserProvidedVerificationItemDetails;
import curam.verification.facade.infrastructure.struct.ParticipantIDAndEvidenceTypeKey;
import curam.verification.facade.infrastructure.struct.ReadUserProvidedVerificationItemDetails;
import curam.verification.facade.infrastructure.struct.ReadVerificationAttachmentDetails;
import curam.verification.facade.infrastructure.struct.ReadVerificationAttachmentLinkKey;
import curam.verification.facade.infrastructure.struct.ReadVerificationDetails;
import curam.verification.facade.infrastructure.struct.ReadVerificationDueDateDetails;
import curam.verification.facade.infrastructure.struct.ReadVerificationItemProvidedDetails;
import curam.verification.facade.infrastructure.struct.UserProvidedVerificationItem;
import curam.verification.facade.infrastructure.struct.UserProvidedVerificationItemKey;
import curam.verification.facade.infrastructure.struct.VDIEDLinkKey;
import curam.verification.facade.infrastructure.struct.VerificationAttachmentLinkKey;
import curam.verification.facade.infrastructure.struct.VerificationDetails;
import curam.verification.facade.infrastructure.struct.VerificationItemProvidedKey;
import curam.verification.facade.infrastructure.struct.VerificationKey;
import curam.verification.facade.infrastructure.struct.VerificationMenuDataDetails;
import curam.verification.facade.infrastructure.struct.VerificationMenuDataKey;
import curam.verification.facade.infrastructure.struct.VerificationWaiverDetails;
import curam.verification.facade.infrastructure.struct.VerificationWaiverKey;
import curam.verification.facade.infrastructure.struct.ViewEvidenceVerificationDetails;
import curam.verification.facade.struct.VerificationPageContextDetails;
import curam.verification.impl.VerificationConstant;
import curam.verification.impl.VerificationUtilities;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.struct.SearchByVerificationItem;
import curam.verification.sl.entity.struct.VerificationItemUtilizationUsageDetailsList;
import curam.verification.sl.infrastructure.entity.fact.VerificationWaiverFactory;
import curam.verification.sl.infrastructure.entity.intf.VerificationWaiver;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverEDParticipantCaseIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverEDParticipantCaseIDDetailsList;
import curam.verification.sl.infrastructure.fact.MaintainVerificationWaiverFactory;
import curam.verification.sl.infrastructure.fact.OutstandingVerificationAttachmentLinkFactory;
import curam.verification.sl.infrastructure.fact.VerificationApplicationFactory;
import curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.fact.VerificationFactory;
import curam.verification.sl.infrastructure.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.impl.VerificationConst;
import curam.verification.sl.infrastructure.intf.MaintainVerificationWaiver;
import curam.verification.sl.infrastructure.intf.OutstandingVerificationAttachmentLink;
import curam.verification.sl.infrastructure.intf.Verification;
import curam.verification.sl.infrastructure.intf.VerificationAttachmentLink;
import curam.verification.sl.infrastructure.intf.VerificationController;
import curam.verification.sl.infrastructure.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.struct.AttachmentLinkID;
import curam.verification.sl.infrastructure.struct.CancelVerificationWaiverDetails;
import curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetails;
import curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList;
import curam.verification.sl.infrastructure.struct.CaseIDAndVDIEDLinkIDKey;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationListDetails;
import curam.verification.sl.infrastructure.struct.ListVerificationItemNameDetailsList;
import curam.verification.sl.infrastructure.struct.OutstandingIndicator;
import curam.verification.sl.infrastructure.struct.SubmittedDocumentDetailsList;
import curam.verification.sl.infrastructure.struct.VerificationAttachmentReviewStatus;
import curam.verification.sl.infrastructure.struct.ViewVerificationDetails;
import curam.verification.sl.struct.VerificationMessage;
import curam.wizardpersistence.impl.WizardPersistentState;
import java.util.HashSet;
import java.util.Set;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;

/**
 * @see curam.verification.facade.infrastructure.intf.VerificationApplication
 */
public abstract class VerificationApplication extends
  curam.verification.facade.infrastructure.base.VerificationApplication {

  // BEGIN, CR00069996, SK
  // BEGIN, CR00021563, NK

  protected static final String kNavigationMenu =
    XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID =
    XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  // END, CR00069996
  // BEGIN, CR00100651, CSH
  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;

  VerificationUtilities verificationUtilities = new VerificationUtilities();

  // END, CR00100651

  /*
   * @Inject private EvidenceVerification evidenceVerification;
   *//**
      * Default constructor for the class.
      */

  /*
   * public VerificationApplication() {
   * GuiceWrapper.getInjector().injectMembers(this); }
   */

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationAttachmentLinkKey createVerificationAttachment(
    final CreateVerificationAttachmentDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.VerificationAttachmentLink verificationAttachmentLink =
      curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory
        .newInstance();

    // Create a Verification Attachment record and populate the return struct
    final VerificationAttachmentLinkKey verificationAttachmentLinkKey =
      new VerificationAttachmentLinkKey();

    verificationAttachmentLinkKey.dtls = verificationAttachmentLink
      .createVerificationAttachmentLink(details.details);

    return verificationAttachmentLinkKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationItemProvidedKey createVerificationItemProvided(
    final CreateVerificaitonItemProvidedDetails details)
    throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    // Create a Verification Item Provided record and populate the return struct
    final VerificationItemProvidedKey verificationItemProvidedKey =
      new VerificationItemProvidedKey();

    verificationItemProvidedKey.dtls =
      verificationItemProvided.createVerificationItemProvided(details.dtls);

    return verificationItemProvidedKey;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyVerificationAttachment(
    final ModifyVerificationAttachmentDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.VerificationAttachmentLink verificationAttachmentLink =
      curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory
        .newInstance();

    verificationAttachmentLink
      .modifyVerificationAttachmentLink(details.details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationDetails
    readVerificationDetails(final EvidenceVerificationDetails dtls)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final VerificationDetails verificationDetails = new VerificationDetails();

    final ViewVerificationDetails viewVerificationDetails =
      verification.readVerificationDetails(dtls.evidenceVerificationDetails);

    verificationDetails.dtls = viewVerificationDetails;

    verificationDetails.contextDescription =
      verification.readPageContextDescriptionForViewVerificationDetails(
        dtls.evidenceVerificationDetails);

    return verificationDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadVerificationItemProvidedDetails
    readVerificationItemProvided(final VerificationItemProvidedKey key)
      throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    // Create the return object
    final ReadVerificationItemProvidedDetails readVerificationItemProvidedDetails =
      new ReadVerificationItemProvidedDetails();

    // Read the Verification Item Provided record and populate the return object
    readVerificationItemProvidedDetails.dtls =
      verificationItemProvided.readVerificationItemProvided(key.dtls);

    readVerificationItemProvidedDetails.pageContextDescription =
      verificationItemProvided
        .readPageContextDescriptionForItemProvided(key.dtls);

    return readVerificationItemProvidedDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadVerificationAttachmentDetails
    readVerificationAttachment(final ReadVerificationAttachmentLinkKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.VerificationAttachmentLink verificationAttachmentLink =
      curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory
        .newInstance();

    final ReadVerificationAttachmentDetails viewVerificationAttachmentDetails =
      new ReadVerificationAttachmentDetails();

    viewVerificationAttachmentDetails.pageContextDescription =
      verificationAttachmentLink.readPageContextDescAttachmentByAttachID(key);

    viewVerificationAttachmentDetails.details =
      verificationAttachmentLink.readVerificationAttachmentLink(key.key);

    return viewVerificationAttachmentDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationPageContextDetails
    readPageContextDescriptionForAttachment(
      final VerificationItemProvidedKey key)
      throws AppException, InformationalException {

    final VerificationAttachmentLink verificationAttachmentLink =
      VerificationAttachmentLinkFactory.newInstance();

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.pageContextDescription =
      verificationAttachmentLink
        .readPageContextDescriptionForAttachment(key.dtls);

    return verificationPageContextDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationPageContextDetails
    readPageContextDescriptionForItemProvided(
      final VerificationItemProvidedKey key)
      throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.pageContextDescription =
      verificationItemProvided
        .readPageContextDescriptionForItemProvided(key.dtls);

    return verificationPageContextDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationPageContextDetails
    readPageContextDescriptionForCreateItemProvided(
      final curam.verification.facade.infrastructure.struct.VDIEDLinkKey key)
      throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    final VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.pageContextDescription =
      verificationItemProvided
        .readPageContextDescriptionForCreateItemProvided(key.dtls);

    return verificationPageContextDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modifyDueDate(final ModifyVerificationRequirementDueDateKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    verification.modifyDueDate(key.dtls);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListVerificationItemNameAndLevelDetails
    readAllActiveVerificationItemNameAndLevel(final VDIEDLinkKey key)
      throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    final ListVerificationItemNameAndLevelDetails ListVerificationItemNameAndLevelDetails =
      new ListVerificationItemNameAndLevelDetails();

    ListVerificationItemNameAndLevelDetails.listDtls =
      verificationItemProvided
        .readAllActiveVerificationItemNameAndLevel(key.dtls);
    return ListVerificationItemNameAndLevelDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadVerificationDueDateDetails readDueDate(final VerificationKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final curam.verification.facade.infrastructure.struct.ReadVerificationDueDateDetails readVerificationDueDateDetails =
      new curam.verification.facade.infrastructure.struct.ReadVerificationDueDateDetails();

    readVerificationDueDateDetails.dueDateDescription =
      verification.readPageContextDescriptionForDueDate(key.dtls);

    readVerificationDueDateDetails.dtls = verification.readDueDate(key.dtls);
    return readVerificationDueDateDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelVerificationAttachment(
    final CancelVerificationAttachmentDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.VerificationAttachmentLink verificationAttachmentLink =
      curam.verification.sl.infrastructure.fact.VerificationAttachmentLinkFactory
        .newInstance();

    verificationAttachmentLink
      .cancelVerificationAttachmentLink(details.details);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelVerificationItemProvided(
    final CancelVerificationItemProvidedDetails details)
    throws AppException, InformationalException {

    final VerificationItemProvided verificationItemProvided =
      VerificationItemProvidedFactory.newInstance();

    // Cancel a Verification Item Provided record
    verificationItemProvided.cancelVerificationItemProvided(details.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetails
    listEvidenceVerificationDetails(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final ListEvidenceVerificationDetails listEvidenceVerificationDetails =
      new ListEvidenceVerificationDetails();

    // BEGIN, CR 00032741, CH
    final curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey caseIDAndTypeKey =
      new curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey();

    caseIDAndTypeKey.caseID = key.dtls.caseID;
    caseIDAndTypeKey.evidenceType = key.dtls.evidenceType;

    listEvidenceVerificationDetails.evidenceDtls =
      verification.listEvidenceVerificationDetails(caseIDAndTypeKey);
    // END, CR 00032741

    // BEGIN, CR 16459, RK
    listEvidenceVerificationDetails.showVerificationCluster = true;

    // for conditional display of verification cluster
    // if there are no verification requirements then hide the verification
    // cluster
    if (listEvidenceVerificationDetails.evidenceDtls.verificationDtls
      .size() == 0) {

      listEvidenceVerificationDetails.showVerificationCluster = false;
    }
    // END, CR 16459

    return listEvidenceVerificationDetails;
  }

  // BEGIN, CR00224831, ELG
  // BEGIN, CR00261681, AKr
  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public
    curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList
    listCaseEvidenceOutstandingVerificationDetails(final CaseKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList returnList =
      new curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList();

    CaseEvidenceVerificationDetailsList readList =
      new CaseEvidenceVerificationDetailsList();

    // Verification object
    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;

    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    caseKeyStruct.caseID = key.caseID;

    readList = verificationObj.listCaseVerificationDetails(caseKeyStruct,
      outstandingIndicator);

    // BEGIN, CR00264164, JMA
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Get Primary Case Participant
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails =
      caseHeaderObj.readParticipantRoleID(caseHeaderKey);

    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();

    participantKeyStruct.participantID =
      readParticipantRoleIDDetails.concernRoleID;

    CaseEvidenceVerificationDetailsList participantList =
      new CaseEvidenceVerificationDetailsList();

    participantList = verificationObj
      .listPOutstandingVerificationDetails(participantKeyStruct);

    // Add the participant evidence verifications to the list
    for (final CaseEvidenceVerificationDetails verificationDetails : participantList.dtls) {
      readList.dtls.addRef(verificationDetails);
    }
    // END, CR00264164

    for (int i = 0; i < readList.dtls.size(); i++) {

      final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetails returnItem =
        new curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetails();

      returnItem.assign(readList.dtls.item(i));

      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.evidenceType = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).evidenceType;

      returnList.list.add(returnItem);

    }

    return returnList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Deprecated
  public
    curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList
    listCaseEvidenceVerificationDetails(final CaseKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList returnList =
      new curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetailsList();

    CaseEvidenceVerificationDetailsList readList =
      new CaseEvidenceVerificationDetailsList();

    // Verification object
    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.DEFAULTCODE;

    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    caseKeyStruct.caseID = key.caseID;

    readList = verificationObj.listCaseVerificationDetails(caseKeyStruct,
      outstandingIndicator);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // BEGIN, CR00264164, JMA
    // Get Primary Case Participant
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails =
      caseHeaderObj.readParticipantRoleID(caseHeaderKey);

    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();

    participantKeyStruct.participantID =
      readParticipantRoleIDDetails.concernRoleID;

    CaseEvidenceVerificationDetailsList participantList =
      new CaseEvidenceVerificationDetailsList();

    participantList = verificationObj
      .listParticipantVerificationDetails(participantKeyStruct);

    // Add the participant evidence verifications to the list
    for (final CaseEvidenceVerificationDetails verificationDetails : participantList.dtls) {
      readList.dtls.addRef(verificationDetails);
    }
    // END, CR00264164

    for (int i = 0; i < readList.dtls.size(); i++) {

      final curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetails returnItem =
        new curam.verification.sl.infrastructure.struct.CaseEvidenceVerificationDisplayDetails();

      returnItem.assign(readList.dtls.item(i));

      returnItem.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          returnItem.verificationStatus, TransactionInfo.getProgramLocale());

      final EvidenceDescriptor evidenceDescriptorObj =
        EvidenceDescriptorFactory.newInstance();
      final EvidenceDescriptorKey edKey = new EvidenceDescriptorKey();

      edKey.evidenceDescriptorID = returnItem.evidenceDescriptorID;

      returnItem.evidenceType = evidenceDescriptorObj
        .readRelatedIDParticipantIDAndEvidenceType(edKey).evidenceType;

      returnList.list.add(returnItem);

    }

    return returnList;
  }

  // END, CR00261681
  // END, CR00224831

  // BEGIN, CR00229662, ELG
  /**
   * {@inheritDoc}
   */
  @Override
  public ListBusinessObjectVerificationDetails
    listVerificationsForBusinessObject(final SuccessionID key)
      throws AppException, InformationalException {

    // return structure
    final ListBusinessObjectVerificationDetails listBusinessObjectVerificationDetails =
      new ListBusinessObjectVerificationDetails();

    final EvidenceDescriptorDtls lastInSuccession = EvidenceControllerFactory
      .newInstance().getBusinessObjectDescriptor(key);

    final VerificationInterface verificationObj = getVerificationImpl();
    final BusinessObjectKey businessObjectKey = new BusinessObjectKey();

    businessObjectKey.caseID = lastInSuccession.caseID;
    businessObjectKey.evidenceSuccessionID = key.successionID;

    listBusinessObjectVerificationDetails.caseID = lastInSuccession.caseID;
    listBusinessObjectVerificationDetails.verificationDtls =
      verificationObj.listVerificationsForBusinessObject(businessObjectKey);

    return listBusinessObjectVerificationDetails;

  }

  /**
   * Creates and returns an instance of the Verification implementation.
   *
   * @return An instance of the Verification implementation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  private VerificationInterface getVerificationImpl()
    throws AppException, InformationalException {

    // There should only be one entry in the VerificationController codetable.
    // Out-of-the-box, there is one shipped for the default locale of "en".
    // Even though the verification functionality is implemented through an
    // interface, it's pretty much accepted that all customers will use the
    // default implementation rather than provide their own. If they do wish
    // to implement their own functionality, they can make use of codetable
    // merging and add their own entry for VERIFICATIONCONTROLLER.VC1 for the
    // default locale. This will then be picked up here.

    // Get the value of the Default Locale environment variable
    String defaultLocale =
      Configuration.getProperty(EnvVars.ENV_DEFAULT_LOCALE);

    // If it's not set, use the default
    if (defaultLocale == null) {
      defaultLocale = EnvVars.ENV_DEFAULT_LOCALE_DEFAULT;
    }

    final String description =
      CodeTable.getOneItem(VERIFICATIONCONTROLLER.TABLENAME,
        VERIFICATIONCONTROLLER.VC1, EnvVars.ENV_DEFAULT_LOCALE_DEFAULT);

    Class clazz = null;
    VerificationInterface verificationListener = null;

    try {
      clazz = Class.forName(description);
    } catch (final ClassNotFoundException e) {
      throw new AppException(
        BPOEVIDENCECONTROLLER.ERR_VERIFICATIONCONTROLLER_CLASS_COULD_NOT_BE_FOUND);
    }

    if (clazz != null) {
      try {
        verificationListener = (VerificationInterface) clazz.newInstance();
      } catch (final Exception e) {
        throw new AppException(
          BPOEVIDENCECONTROLLER.ERR_VERIFICATIONCONTROLLER_CLASS_COULD_NOT_BE_INSTANTIATED);
      }
    }

    return verificationListener;

  }

  // END, CR00229662

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList listCaseVerificationDetails(
    final CaseKey_fo key) throws AppException, InformationalException {

    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    integratedCaseVerificationDetailsList.dtls =
      verification.listIntegratedCaseVerificationDetails(key.key.key);

    integratedCaseVerificationDetailsList.pageContextDescription =
      verification.readICPageContextDescription(key.key.key);

    // BEGIN, CR00021563, NK
    // Set key to read menu data
    final VerificationMenuDataKey verificationMenuDataKey =
      new VerificationMenuDataKey();

    verificationMenuDataKey.caseID = key.key.key.caseID;

    // Read menu data
    integratedCaseVerificationDetailsList.icMenuData =
      getVerificationMenuData(verificationMenuDataKey);
    // END, CR00021563

    return integratedCaseVerificationDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList
    listOutstandingCaseVerificationDetails(final CaseKey_fo key)
      throws AppException, InformationalException {

    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    integratedCaseVerificationDetailsList.dtls = verification
      .listOutstandingIntegratedCaseVerificationDetails(key.key.key);

    integratedCaseVerificationDetailsList.pageContextDescription =
      verification.readICPageContextDescription(key.key.key);

    // BEGIN, CR00021563, NK
    // Set key to read menu data
    final VerificationMenuDataKey verificationMenuDataKey =
      new VerificationMenuDataKey();

    verificationMenuDataKey.caseID = key.key.key.caseID;

    // Read menu data
    integratedCaseVerificationDetailsList.icMenuData =
      getVerificationMenuData(verificationMenuDataKey);
    // END, CR00021563

    return integratedCaseVerificationDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList
    listPDOutstandingCaseVerificationDetails(final CaseKey_fo key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    integratedCaseVerificationDetailsList.dtls =
      verification.listPDOutstandingCaseVerificationDetails(key.key.key);

    integratedCaseVerificationDetailsList.pageContextDescription =
      verification.readPDPageContextDescription(key.key.key);

    // BEGIN, CR00021563, NK
    // Set key to read menu data
    final VerificationMenuDataKey verificationMenuDataKey =
      new VerificationMenuDataKey();

    verificationMenuDataKey.caseID = key.key.key.caseID;

    // Read menu data
    integratedCaseVerificationDetailsList.icMenuData =
      getVerificationProductDeliveryMenuData(verificationMenuDataKey);
    // END, CR00021563

    return integratedCaseVerificationDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList
    listProductDeliveryCaseVerificationDetails(final CaseKey_fo key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    integratedCaseVerificationDetailsList.dtls =
      verification.listProductDeliveryCaseVerificationDetails(key.key.key);

    integratedCaseVerificationDetailsList.pageContextDescription =
      verification.readPDPageContextDescription(key.key.key);

    // BEGIN, CR00021563, NK
    // Set key to read menu data
    final VerificationMenuDataKey verificationMenuDataKey =
      new VerificationMenuDataKey();

    verificationMenuDataKey.caseID = key.key.key.caseID;

    // Read menu data
    integratedCaseVerificationDetailsList.icMenuData =
      getVerificationProductDeliveryMenuData(verificationMenuDataKey);
    // END, CR00021563

    return integratedCaseVerificationDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetails
    listEvidenceItemVerificationDetails(final CaseIDEvidenceIDAndTypeKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    // BEGIN, CR 3023, RK
    final CaseKey caseKey = new CaseKey();
    // END, CR 3023

    final ListEvidenceVerificationDetails listEvidenceVerificationDetails =
      new ListEvidenceVerificationDetails();

    // BEGIN, CR 00032741, DK
    final EvidenceVerificationDetailsList evidenceVerificationDetailsList =
      new EvidenceVerificationDetailsList();

    final EvidenceVerificationListDetails tempDetailsList =
      verification.listEvidenceItemVerificationDetails(key.dtls);

    // BEGIN, CR00075582, RF
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    for (int i = 0; i < tempDetailsList.verificationDtls.size(); i++) {

      caseKey.caseID = tempDetailsList.verificationDtls.item(i).caseID;
      final curam.core.sl.infrastructure.struct.EvidenceVerificationDetails evidenceVerificationDetails =
        new curam.core.sl.infrastructure.struct.EvidenceVerificationDetails();

      if (!(caseKey.caseID == 0)) {
        // Read CaseHeader
        final CaseTypeCode caseTypeCode =
          caseHeaderObj.readCaseTypeCode(caseKey);

        // BEGIN, CR00350929, ARM

        if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
          evidenceVerificationDetails.verificationLinkedType =
            VERIFICATIONTYPE.INTEGRATEDCASE;
        } else {
          evidenceVerificationDetails.verificationLinkedType =
            caseTypeCode.caseTypeCode;
        }
        // BEGIN, CR00371307, AKr
        evidenceVerificationDetails.verificationLinkedType =
          verificationUtilities.getRelatedItemID(caseKey).getCode();
        // END, CR00371307
        // END, CR00350929

        evidenceVerificationDetails.verificationLinkedID = key.dtls.caseID;
      } else {
        evidenceVerificationDetails.verificationLinkedType =
          VERIFICATIONTYPE.NONCASEDATA;
        evidenceVerificationDetails.verificationLinkedID =
          tempDetailsList.verificationDtls.item(i).verificationLinkedID;
      }

      evidenceVerificationDetails.dataItemName =
        tempDetailsList.verificationDtls.item(i).dataItemName;
      evidenceVerificationDetails.evidenceDescriptorID =
        tempDetailsList.verificationDtls.item(i).evidenceDescriptorID;
      evidenceVerificationDetails.relatedID =
        tempDetailsList.verificationDtls.item(i).relatedID;
      evidenceVerificationDetails.summary =
        tempDetailsList.verificationDtls.item(i).summary;
      evidenceVerificationDetails.vdIEDLinkID =
        tempDetailsList.verificationDtls.item(i).vdIEDLinkID;
      evidenceVerificationDetails.verificationStatus =
        tempDetailsList.verificationDtls.item(i).verificationStatus;

      evidenceVerificationDetailsList.verificationDtls
        .addRef(evidenceVerificationDetails);
    }

    listEvidenceVerificationDetails.evidenceDtls =
      evidenceVerificationDetailsList;
    // END, CR 00032741

    // BEGIN, CR00019054, KY
    listEvidenceVerificationDetails.showVerificationCluster = true;

    // for conditional display of verification cluster
    // if there are no verification requirements then hide the verification
    // cluster
    if (listEvidenceVerificationDetails.evidenceDtls.verificationDtls
      .size() == 0) {

      listEvidenceVerificationDetails.showVerificationCluster = false;
    }
    // END, CR00019054

    // BEGIN, CR 3023, RK
    caseKey.caseID = key.dtls.caseID;

    // BEGIN, ?????, VM
    listEvidenceVerificationDetails.resultDtls.contextDescription =
      EvidenceFactory.newInstance()
        .getContextDescription(caseKey).contextDescription;
    // END, ?????
    // BEGIN, CR 3023

    return listEvidenceVerificationDetails;
  }

  // BEGIN, CR00021563, NK
  /**
   * Returns the Menu Data for the Integrated Case for Verification.
   *
   * @param key
   * Integrated Case identifier of Verification.
   *
   * @return Menu Data for the Integrated Case for Verification.
   */
  protected VerificationMenuDataDetails
    getVerificationMenuData(final VerificationMenuDataKey key)
      throws AppException, InformationalException {

    // Create return object
    final VerificationMenuDataDetails verificationMenuDataDetails =
      new VerificationMenuDataDetails();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create child node
    final Element linkElement = new Element(kItem);

    // Need to retrieve the IC Home Page Name And Type
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    ICHomePageNameAndType icHomePageNameAndType;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read IC Home Page Name and Type
    caseKey.caseID = key.caseID;

    // Read home page name and type
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    final LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType));

    description.arg(icHomePageNameAndType.caseReference);

    // Set up node property values
    linkElement.setAttribute(kPageID, icHomePageNameAndType.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    final Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, String.valueOf(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    verificationMenuDataDetails.menuData =
      outputter.outputString(navigationMenuElement);

    return verificationMenuDataDetails;
  }

  // END, CR00021563

  // BEGIN, CR00021563, NK
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a product delivery on an Integrated Case for
   * verification.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   */
  protected VerificationMenuDataDetails
    getVerificationProductDeliveryMenuData(final VerificationMenuDataKey key)
      throws AppException, InformationalException {

    // Create return object
    final VerificationMenuDataDetails verificationMenuDataDetails =
      new VerificationMenuDataDetails();

    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleIDKey caseParticipantRoleIDKey =
      new CaseParticipantRoleIDKey();

    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj =
      curam.core.fact.ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read productDelivery to retrieve the case home page name and
    // product type
    caseHomePageNameAndType =
      productDeliveryObj.readCaseHomePageNameAndType(caseKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey =
      caseHeaderObj.readIntegratedCaseReferenceByCaseID(caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails =
      caseHeaderObj.readICPageNamesICTypeAndConcernDetails(caseKey);

    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey =
      new ReadByParticipantRoleTypeAndCaseKey();

    // BEGIN, CR00324693, ZV
    readByParticipantRoleTypeAndCaseKey.caseID = key.caseID;
    // END, CR00324693
    readByParticipantRoleTypeAndCaseKey.participantRoleID =
      productDeliveryDtls.recipConcernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode =
      CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;

    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails =
      caseParticipantRole
        .readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
          readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729

    caseParticipantRoleIDKey.caseParticipantRoleID =
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478

    // Get participant home page
    participantHomePageName =
      resolveParticipantHome(caseParticipantRoleIDKey);

    // create link to the participant home page.
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);
    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);

    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue, Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478
    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      caseHomePageNameAndType.caseHomePageName);

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    description.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));

    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);

    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    verificationMenuDataDetails.menuData =
      outputter.outputString(navigationMenuElement);

    return verificationMenuDataDetails;
  }

  // END, CR00021563

  // BEGIN, CR00021563, NK
  /**
   * Returns the home page name for an Integrated Case participant.
   *
   * @param key
   * Contains the integrated case identifier.
   */
  public ParticipantHomePageName
    resolveParticipantHome(final CaseParticipantRoleIDKey key)
      throws AppException, InformationalException {

    // Create return object
    final ParticipantHomePageName participantHomePageName =
      new ParticipantHomePageName();

    // MaintainAdminIntegratedCase manipulation variable
    final curam.core.intf.MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj =
      curam.core.fact.MaintainAdminIntegratedCaseFactory.newInstance();

    final ICParticipantHomePageKey iCParticipantHomePageKey =
      new ICParticipantHomePageKey();

    ICParticipantHomePageName iCParticipantHomePageName;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign key to read participant home page name
    iCParticipantHomePageKey.caseParticipantRoleID =
      key.caseParticipantRoleID;

    // Call MaintainAdminIntegratedCase BPO to read participant home page name
    // and assign to return object
    iCParticipantHomePageName = maintainAdminIntegratedCaseObj
      .getICParticipantHomePageName(iCParticipantHomePageKey);

    participantHomePageName.participantHomePageName =
      iCParticipantHomePageName.participantHomePageName;

    participantHomePageName.participantIconName =
      iCParticipantHomePageName.participantIconName;

    // return details.
    return participantHomePageName;
  }

  // END, CR00021563

  // BEGIN, CR00368690, JMA
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceTypeDescriptionDetails
    readEvidenceTypeDescription(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceTypeDescriptionDetails evidenceTypeDescriptionDetails =
      new EvidenceTypeDescriptionDetails();

    ReadRelatedIDParticipantIDAndEvidenceTypeDetails readRelatedIDParticipantIDAndEvidenceTypeDetails =
      new ReadRelatedIDParticipantIDAndEvidenceTypeDetails();
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    readRelatedIDParticipantIDAndEvidenceTypeDetails =
      evidenceDescriptor.readRelatedIDParticipantIDAndEvidenceType(key);

    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID =
      readRelatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
    eiEvidenceKey.evidenceType =
      readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;

    final EvidenceMap map = EvidenceController.getEvidenceMap();
    // BEGIN, CR00059540, POH
    final StandardEvidenceInterface standardEvidenceInterface =
      map.getEvidenceType(
        readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType);

    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
      standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey);

    evidenceTypeDescriptionDetails.evidenceType =
      readRelatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;
    evidenceTypeDescriptionDetails.description = LocalizableXMLStringHelper
      .toPlainText(eiFieldsForListDisplayDtls.summary);

    return evidenceTypeDescriptionDetails;
  }

  // END, CR00368690, JMA

  // BEGIN, CR00023145, KY
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceTypeDetails readEvidenceType(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    final EvidenceTypeDetails evidenceTypeDetails = new EvidenceTypeDetails();
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    evidenceTypeDetails.evidenceType = evidenceDescriptor
      .readRelatedIDParticipantIDAndEvidenceType(key).evidenceType;

    return evidenceTypeDetails;
  }

  // END, CR00023145

  // BEGIN, CR00148586, CW
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceTypeAndRelatedIDDetails
    readEvidenceTypeAndRelatedID(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final EvidenceTypeAndRelatedIDDetails evidenceTypeAndRelatedIDDetails =
      new EvidenceTypeAndRelatedIDDetails();
    final EvidenceDescriptor evidenceDescriptor =
      EvidenceDescriptorFactory.newInstance();

    final ReadRelatedIDParticipantIDAndEvidenceTypeDetails relatedIDParticipantIDAndEvidenceType =
      evidenceDescriptor.readRelatedIDParticipantIDAndEvidenceType(key);

    evidenceTypeAndRelatedIDDetails.evidenceType =
      relatedIDParticipantIDAndEvidenceType.evidenceType;
    evidenceTypeAndRelatedIDDetails.relatedID =
      relatedIDParticipantIDAndEvidenceType.relatedID;

    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID =
      relatedIDParticipantIDAndEvidenceType.relatedID;
    eiEvidenceKey.evidenceType =
      relatedIDParticipantIDAndEvidenceType.evidenceType;

    // Is this a child evidence record?
    final curam.core.sl.infrastructure.struct.ParentList parentList =
      EvidenceRelationshipFactory.newInstance()
        .getParentKeyList(eiEvidenceKey);

    if (parentList.list.dtls.size() > 0) {
      // This is a child evidence record

      // Populate the return details with the parent info
      evidenceTypeAndRelatedIDDetails.parentEvidenceType =
        parentList.list.dtls.item(0).parentType;
      evidenceTypeAndRelatedIDDetails.parentRelatedID =
        parentList.list.dtls.item(0).parentID;

      // Populate the relatedID field with parentID as expected by client
      evidenceTypeAndRelatedIDDetails.relatedID =
        parentList.list.dtls.item(0).parentID;

    }

    return evidenceTypeAndRelatedIDDetails;
  }

  // END, CR00148586

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetails
    listParticipantEvidenceVerificationDetails(
      final ParticipantIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    final ListEvidenceVerificationDetails listEvidenceVerificationDetails =
      new ListEvidenceVerificationDetails();

    listEvidenceVerificationDetails.evidenceDtls =
      verification.listParticipantEvidenceVerificationDetails(key.dtls);

    listEvidenceVerificationDetails.showVerificationCluster = true;

    // for conditional display of verification cluster
    // if there are no verification requirements then hide the verification
    // cluster
    if (listEvidenceVerificationDetails.evidenceDtls.verificationDtls
      .size() == 0) {
      listEvidenceVerificationDetails.showVerificationCluster = false;
    }

    return listEvidenceVerificationDetails;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listAddressVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.CONCERNROLEADDRESS;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.CONCERNROLEADDRESS;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listAlternateIDVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.CONCERNROLEALTERNATEID;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.CONCERNROLEALTERNATEID;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listAlternateNameVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.ALTERNATENAME;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.ALTERNATENAME;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listBankAccountVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.CONCERNROLEBANKACC;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.CONCERNROLEBANKACC;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listCitizenshipVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.CITIZENSHIP;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.CITIZENSHIP;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listEducationVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.EDUCATION;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.EDUCATION;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listEmployerVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.EMPLOYER;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.EMPLOYER;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listEmploymentVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.EMPLOYMENT;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.EMPLOYMENT;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listForeignResidencyVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.FOREIGNRESIDENCY;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.FOREIGNRESIDENCY;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listPersonVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.PERSON;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.PERSON;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listProspectEmployerVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.PROSPECTEMPLOYER;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.PROSPECTEMPLOYER;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listProspectPersonVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.PROSPECTPERSON;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.PROSPECTPERSON;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listRelationshipVerificationDetails(final ParticipantKey key)
      throws AppException, InformationalException {

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.CONCERNROLERELATIONSHIP;
    participantIDAndEvidenceTypeKey.dtls.participantID =
      key.key.key.participantID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.CONCERNROLERELATIONSHIP;

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public ListEvidenceVerificationDetailsAndEvidenceType
    listEmploymentWorkingHoursVerificationDetails(final EmploymentKey key)
      throws AppException, InformationalException {

    // Get participantID from employmentID
    curam.core.struct.EmploymentDtls dtls =
      new curam.core.struct.EmploymentDtls();
    final curam.core.intf.Employment employmentObj =
      curam.core.fact.EmploymentFactory.newInstance();

    // Read details
    dtls = employmentObj.read(key);

    // Create struct
    final ParticipantIDAndEvidenceTypeKey participantIDAndEvidenceTypeKey =
      new ParticipantIDAndEvidenceTypeKey();

    // Set struct
    participantIDAndEvidenceTypeKey.dtls.evidenceType =
      curam.codetable.CASEEVIDENCE.EMPLOYMENTWORKINGHR;
    participantIDAndEvidenceTypeKey.dtls.participantID = dtls.concernRoleID;

    final ListEvidenceVerificationDetailsAndEvidenceType list =
      new ListEvidenceVerificationDetailsAndEvidenceType();

    // BEGIN, CR00079257, POH
    list.verificationDtls = listParticipantEvidenceVerificationDetails(
      participantIDAndEvidenceTypeKey);
    list.evidenceType = curam.codetable.CASEEVIDENCE.EMPLOYMENTWORKINGHR;
    // END, CR00079257

    return list;
  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList
    listPOutstandingVerificationDetails(final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    // Create verification object.
    final Verification verification = VerificationFactory.newInstance();

    // Call Service Layer and pass the Participant Id struct.
    integratedCaseVerificationDetailsList.dtls =
      verification.listPOutstandingVerificationDetails(key);

    // BEGIN, CR00169613, VK
    // BEGIN,CR00079515,AL
    // Read the participant context description
    final ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    // Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.participantID;

    // Get the context description for the concern role
    integratedCaseVerificationDetailsList.pageContextDescription.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;

    // END,CR00079515,AL
    // END, CR00169613

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
        new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.participantID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier =
        CuramConst.kVerificationApplication_POutstandingVerificationListForDuplicate;
      origPageIdentifier.pageIdentifier =
        CuramConst.kVerificationApplication_PersonOutstandingVerificationList;

      // Build up the xml data needed for the tab widget
      integratedCaseVerificationDetailsList.renderXML =
        clientMergeObj.getDuplicateMenuRendererData(concernRoleKey,
          currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      integratedCaseVerificationDetailsList.ind = clientMergeSLObj
        .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    return integratedCaseVerificationDetailsList;

  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsList
    listParticipantVerificationDetails(final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    // Verification SL object
    final Verification verification = VerificationFactory.newInstance();

    // Get participant verifications for concernRole
    integratedCaseVerificationDetailsList.dtls =
      verification.listParticipantVerificationDetails(key);

    // BEGIN, CR00169613, VK
    // BEGIN,CR00079515,AL
    // Read the participant context description
    final ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    // Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.participantID;

    // Get the context description for the concern role
    integratedCaseVerificationDetailsList.pageContextDescription.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;
    // END,CR00079515,AL
    // END, CR00169613

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
        new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.participantID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier =
        CuramConst.kVerificationApplication_PersonVerificationListForDuplicate;
      origPageIdentifier.pageIdentifier =
        CuramConst.kVerificationApplication_PersonVerificationList;

      // Build up the xml data needed for the tab widget
      integratedCaseVerificationDetailsList.renderXML =
        clientMergeObj.getDuplicateMenuRendererData(concernRoleKey,
          currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      integratedCaseVerificationDetailsList.ind = clientMergeSLObj
        .isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    return integratedCaseVerificationDetailsList;

  }

  // END, CR00075582

  // BEGIN, CR00075582, RF
  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for the Participant for Verification.
   *
   * @param key
   * Participant identifier.
   * @return Menu Data for the Participant for Verification.
   */
  protected VerificationMenuDataDetails
    getVerificationParticipantMenuData(final VerificationMenuDataKey key)
      throws AppException, InformationalException {

    return null;
  }

  // END, CR00075582

  // BEGIN, CR00102618, CSH
  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsListForDuplicate
    listParticipantVerificationDetailsForDuplicate(
      final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return struct
    final IntegratedCaseVerificationDetailsListForDuplicate integratedCaseVerificationDetailsListForDuplicate =
      new IntegratedCaseVerificationDetailsListForDuplicate();

    // Verification object manipulation variables
    final Verification verificationObj = VerificationFactory.newInstance();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();

    // BEGIN, CR00169613, VK
    // Read the participant context description
    final ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    // Participant manipulation variable
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj =
      ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey =
      new SearchByDuplicateConcernRoleIDKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Get the list of verifications for the participant
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.dtls =
      verificationObj.listParticipantVerificationDetails(key);

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.participantID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextDescriptionKey.concernRoleID =
      dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the original concern role
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.pageContextDescription.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;

    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID = key.participantID;

    // Get the context description for the duplicate concern role
    integratedCaseVerificationDetailsListForDuplicate.duplicateContextDesc.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;
    // END, CR00169613
    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.participantID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier =
      CuramConst.kVerificationApplication_PersonVerificationListForDuplicate;
    origPageIdentifier.pageIdentifier =
      CuramConst.kVerificationApplication_PersonVerificationList;

    // Build up the xml data needed for the tab widget
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.renderXML =
      clientMergeObj.getDuplicateMenuRendererData(concernRoleKey, currentKey,
        dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    return integratedCaseVerificationDetailsListForDuplicate;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public IntegratedCaseVerificationDetailsListForDuplicate
    listPOutstandingVerificationDetailsForDuplicate(
      final ParticipantKeyStruct key)
      throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final IntegratedCaseVerificationDetailsListForDuplicate integratedCaseVerificationDetailsListForDuplicate =
      new IntegratedCaseVerificationDetailsListForDuplicate();

    // Create verification object
    final Verification verificationObj = VerificationFactory.newInstance();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Get the list of outstanding verifications for the participant
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.dtls =
      verificationObj.listPOutstandingVerificationDetails(key);

    // BEGIN, CR00169613, VK
    // Read the participant context description
    final ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();

    // Context description key
    final ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj =
      ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey =
      new SearchByDuplicateConcernRoleIDKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.participantID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextDescriptionKey.concernRoleID =
      dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the concern role
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.pageContextDescription.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;
    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID = key.participantID;

    // Get the context description for the duplicate concern role
    integratedCaseVerificationDetailsListForDuplicate.duplicateContextDesc.description =
      participantContextObj
        .readContextDescription(participantContextDescriptionKey).description;
    // END, CR00169613

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.participantID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier =
      CuramConst.kVerificationApplication_POutstandingVerificationListForDuplicate;
    origPageIdentifier.pageIdentifier =
      CuramConst.kVerificationApplication_PersonOutstandingVerificationList;

    // Build up the xml data needed for the tab widget
    integratedCaseVerificationDetailsListForDuplicate.dtlsList.renderXML =
      clientMergeObj.getDuplicateMenuRendererData(concernRoleKey, currentKey,
        dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    return integratedCaseVerificationDetailsListForDuplicate;
  }

  // END, CR00102618

  // BEGIN, CR00109704, MR
  /**
   * {@inheritDoc}
   */
  @Override
  public EvidenceVerificationDetails
    readEvidenceVerificationDetails(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    // Verification manipulation variable
    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();
    // Set Evidence Descriptor Key
    final EvidenceDescriptorKey evidenceDescriptorKey =
      new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = key.evidenceDescriptorID;

    // Get Evidence Verification Details
    final EvidenceVerificationDetails evidenceVerificationDetails =
      new EvidenceVerificationDetails();

    evidenceVerificationDetails.evidenceVerificationDetails =
      verification.readEvidenceVerificationDetails(evidenceDescriptorKey);
    return evidenceVerificationDetails;
  }

  // END, CR00109704

  /**
   * {@inheritDoc}
   */
  @Override
  public ListBusinessObjectVerificationDetails
    listVerificationsForCaseEvidence(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    // return structure
    final ListBusinessObjectVerificationDetails listBusinessObjectVerificationDetails =
      new ListBusinessObjectVerificationDetails();

    final curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
      new curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = key.dtls.caseID;
    caseIDAndEvidenceTypeKey.evidenceType = key.dtls.evidenceType;
    final VerificationController verificationControllerObj =
      VerificationControllerFactory.newInstance();

    listBusinessObjectVerificationDetails.caseID = key.dtls.caseID;
    // BEGIN, CR00452380, GK
    listBusinessObjectVerificationDetails.verificationDtls =
      verificationControllerObj
        .listVerificationsForCaseAndEvidence1(caseIDAndEvidenceTypeKey);
    // END, CR00452380

    listBusinessObjectVerificationDetails.showVerificationCluster = true;

    // for conditional display of verification cluster
    // if there are no verification requirements then hide the verification
    // cluster
    if (listBusinessObjectVerificationDetails.verificationDtls.list
      .size() == 0) {

      listBusinessObjectVerificationDetails.showVerificationCluster = false;
    } else {
      for (final EvidenceVerificationDisplayDetails verificationDetails : listBusinessObjectVerificationDetails.verificationDtls.list) {
        final boolean docsPendingReviewExist =
          checkIfDocumentsPendingReviewExistForVerification(
            verificationDetails.vdIEDLinkID,
            verificationDetails.verificationLinkedID);

        // need localised description of VerifiableDataItem code
        final curam.util.internal.codetable.intf.CodeTable codeTableInterface =
          CodeTableFactory.newInstance();
        final CTItemKey ctitemKey = new CTItemKey();
        ctitemKey.code = verificationDetails.dataItemName;
        ctitemKey.locale = TransactionInfo.getProgramLocale();
        ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
        final String verifiableDataItemName =
          codeTableInterface.getOneItemForUserLocale(ctitemKey).description;

        verificationDetails.verifiableDataItemNameXMLOpt =
          getVerifiableDataItemDetails(verifiableDataItemName,
            docsPendingReviewExist).toString();
      }
    }
    return listBusinessObjectVerificationDetails;

  }

  // BEGIN, CR00260117, FM
  /**
   * {@inheritDoc}
   */
  @Override
  public ViewEvidenceVerificationDetails
    listVerificationWaiverDetails(final EvidenceVerificationDetails key)
      throws AppException, InformationalException {

    final ViewEvidenceVerificationDetails result =
      new ViewEvidenceVerificationDetails();

    final MaintainVerificationWaiver maintainVerificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();

    result.dtls.assign(maintainVerificationWaiverObj
      .listEvidenceVerificationWaiver(key.evidenceVerificationDetails));

    final curam.verification.sl.infrastructure.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    result.contextDescription =
      verificationObj.readPageContextDescriptionForViewVerificationDetails(
        key.evidenceVerificationDetails);
    return result;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationWaiverKey
    createWaiver(final VerificationWaiverDetails details)
      throws AppException, InformationalException {

    final VerificationWaiverKey result = new VerificationWaiverKey();
    final MaintainVerificationWaiver maintainVerificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();

    result.key.assign(
      maintainVerificationWaiverObj.createWithNoOverlapping(details.dtls));
    return result;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelWaiver(final CancelVerificationWaiverDetails details)
    throws AppException, InformationalException {

    final MaintainVerificationWaiver maintainVerificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();
    final CancelVerificationWaiverDetails cancelVerificationWaiverDetails =
      new CancelVerificationWaiverDetails();

    cancelVerificationWaiverDetails.verificationWaiverID =
      details.verificationWaiverID;
    cancelVerificationWaiverDetails.versionNo = details.versionNo;
    maintainVerificationWaiverObj.cancel(cancelVerificationWaiverDetails);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void
    modifyWaiverPeriod(final ModifyVerificationWaiverDetails details)
      throws AppException, InformationalException {

    final MaintainVerificationWaiver maintainVerificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();

    maintainVerificationWaiverObj.modifyPeriod(details.dtls);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public VerificationWaiverDetails
    readWaiverDetails(final VerificationWaiverKey key)
      throws AppException, InformationalException {

    final VerificationWaiverDetails result = new VerificationWaiverDetails();
    final MaintainVerificationWaiver maintainVerificationWaiverObj =
      MaintainVerificationWaiverFactory.newInstance();

    result.dtls.assign(maintainVerificationWaiverObj.view(key.key));
    result.modifiableInd =
      result.dtls.recordStatus.equals(RECORDSTATUS.NORMAL);
    // Users key
    final UsersKey usersKey = new UsersKey();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    // set user name key
    usersKey.userName = result.dtls.lastUpdatedBy;
    // get full user name
    result.lastModifiedByUserFullName =
      userAccessObj.getFullName(usersKey).fullname;

    return result;
  }

  // END, CR00260117

  // BEGIN, CR00261681, AKr
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseEvidenceVerificationDisplayDetailsList
    listOutstandingVerificationDetailsForCaseEvidence(final CaseKey key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDisplayDetailsList caseEvidenceVerificationDisplayDetailsList =
      new CaseEvidenceVerificationDisplayDetailsList();

    final Verification verificationObj = VerificationFactory.newInstance();

    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;

    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    caseKeyStruct.caseID = key.caseID;

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // BEGIN, CR0029473, PB
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    final ReadByTypeAndCaseIDKey readByTypeAndCaseIDKey =
      new ReadByTypeAndCaseIDKey();

    readByTypeAndCaseIDKey.caseID = key.caseID;
    readByTypeAndCaseIDKey.typeCode = CASEPARTICIPANTROLETYPE.MEMBER;

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList =
      caseParticipantRoleObj.searchByTypeAndCaseID(readByTypeAndCaseIDKey);
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails =
      caseHeaderObj.readParticipantRoleID(caseHeaderKey);
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    caseParticipantRoleDtls.participantRoleID =
      readParticipantRoleIDDetails.concernRoleID;
    caseParticipantRoleDtlsList.dtls.add(caseParticipantRoleDtls);

    // BEGIN, CR00303978, PB
    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      verificationObj.listCaseVerificationDetails(caseKeyStruct,
        outstandingIndicator);

    for (final CaseParticipantRoleDtls caseParticipantRoleDetails : caseParticipantRoleDtlsList.dtls
      .items()) {

      participantKeyStruct.participantID =
        caseParticipantRoleDetails.participantRoleID;

      final CaseEvidenceVerificationDetailsList participantList =
        verificationObj
          .listPOutstandingVerificationDetails(participantKeyStruct);

      for (final CaseEvidenceVerificationDetails verificationDetails : participantList.dtls) {
        // BEGIN, CR00313955, MV
        verificationDetails.concernRoleID =
          caseParticipantRoleDetails.participantRoleID;
        // END, CR00313955
        caseEvidenceVerificationDetailsList.dtls.addRef(verificationDetails);
      }
    }
    // END, CR00303978
    CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails;
    EvidenceDescriptor evidenceDescriptorObj;
    EvidenceDescriptorKey edKey;

    for (final CaseEvidenceVerificationDetails details : caseEvidenceVerificationDetailsList.dtls) {

      caseEvidenceVerificationDisplayDetails =
        new CaseEvidenceVerificationDisplayDetails();
      caseEvidenceVerificationDisplayDetails.caseParticipantRoleID =
        details.caseParticpantRoleID;
      caseEvidenceVerificationDisplayDetails.concernRoleID =
        details.concernRoleID;
      caseEvidenceVerificationDisplayDetails.contextDescription =
        details.contextDescription;
      caseEvidenceVerificationDisplayDetails.dueDate = details.dueDate;
      caseEvidenceVerificationDisplayDetails.evidence = details.evidence;
      caseEvidenceVerificationDisplayDetails.evidenceDescriptorID =
        details.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.itemProvided =
        details.itemProvided;
      caseEvidenceVerificationDisplayDetails.primaryClient =
        details.primaryClient;
      caseEvidenceVerificationDisplayDetails.verificationStatus =
        details.verificationStatus;
      caseEvidenceVerificationDisplayDetails.verifiableDataItemName =
        details.verifiableDataItemName;
      caseEvidenceVerificationDisplayDetails.verifiableDataItemNameXMLOpt =
        getVerifiableDataItemDetails(details.verifiableDataItemName,
          details.documentSubmittedOpt).toString();
      caseEvidenceVerificationDisplayDetails.vDIEDLinkID =
        details.vDIEDLinkID;
      caseEvidenceVerificationDisplayDetails.verificationID =
        details.verificationID;
      caseEvidenceVerificationDisplayDetails.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          caseEvidenceVerificationDisplayDetails.verificationStatus,
          TransactionInfo.getProgramLocale());
      // BEGIN, CR00452774, GK
      caseEvidenceVerificationDisplayDetails.verifiableDataItemIDOpt =
        details.verifiableDataItemIDOpt;
      // END, CR00452774
      // BEGIN, 161320, dmorton
      updateVerificationsMandatoryStatus(details,
        caseEvidenceVerificationDisplayDetails);
      // END, 161320
      evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      edKey = new EvidenceDescriptorKey();
      edKey.evidenceDescriptorID =
        caseEvidenceVerificationDisplayDetails.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.evidenceType =
        evidenceDescriptorObj
          .readRelatedIDParticipantIDAndEvidenceType(edKey).evidenceType;

      caseEvidenceVerificationDisplayDetailsList.dtls
        .add(caseEvidenceVerificationDisplayDetails);

    }
    // END, CR0029473

    return caseEvidenceVerificationDisplayDetailsList;
  }

  /**
   * Format the XML data for the Verifiable Data Item Name - this will always
   * contain the verifiable item name, and will conditionally contain an icon
   * image next to the name, if both the
   * 'curam.verification.submittedDocuments.display.enabled' property is
   * enabled and if submitted documents that are pending a review exist.
   *
   * @param verifiableDataItemName
   * The verifiable data item name.
   * @param documentsPendingReviewExist flag that indicates if any documents
   * that are pending a review for a verification exist.
   *
   * @return a content panel builder, which contains the verifiable data item
   * name, and conditionally contains an icon (if documents pending a review
   * exist and if the display property is enabled).
   */
  private ContentPanelBuilder getVerifiableDataItemDetails(
    final String verifiableDataItemName,
    final boolean documentsPendingReviewExist)
    throws AppException, InformationalException {

    final ContentPanelBuilder verifiableDataItemNamePanelBuilder =
      ContentPanelBuilder.createPanel(CuramConst.gkContentPanel);

    verifiableDataItemNamePanelBuilder.addStringItem(verifiableDataItemName,
      VerificationConstant.gkVerfiableDataItemNameCSSStyle);

    final boolean isEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_VERIFICATION_SUBMITTED_DOCUMENT_DISPLAY_ENABLED);

    if (isEnabled && documentsPendingReviewExist) {
      final ImageBuilder imageBuilder =
        ImageBuilder.createImage(PodsConst.kSubmittedDocumentImage);

      imageBuilder.setImageResource(PodsConst.kImageResource);

      final String tooltipText = new LocalisableString(
        VERIFICATIONDETAILSPANEL.INF_TOOLTIP_VERIFICATION_SUBMITTED_DOCUMENT)
          .toClientFormattedText();

      imageBuilder.setImageAltText(tooltipText);

      verifiableDataItemNamePanelBuilder.addImageItem(imageBuilder,
        VerificationConstant.gkVerifiableSubmittedDocumentsIconCSSStyle);

    }
    return verifiableDataItemNamePanelBuilder;
  }

  /**
   * Method to check if any submitted documents with a status of pending review
   * are attached to a verification.
   *
   * If the 'curam.verification.submittedDocuments.display.enabled' property is
   * not enabled, this method will return false without checking for documents,
   * as the list of documents will not be displayed anywhere, so it saves an
   * unnecessary database read.
   *
   * This method takes in a vdiedLinkID and a caseID - if more than one
   * verification exists for the given vdiedLinkID then only the verification
   * for the case specified will be taken into account.
   *
   * @param vdiedLinkID The ID of the VDIEDLink record for a verification.
   * @param caseID The ID of the case that a verification belongs to.
   * @return true, if the
   * 'curam.verification.submittedDocuments.display.enabled' property is enabled
   * and documents with a review status of pending review are linked to the
   * verification.
   *
   * @throws AppException Generic exception signature.
   * @throws InformationalException Generic exception signature.
   */
  private boolean checkIfDocumentsPendingReviewExistForVerification(
    final Long vdiedLinkID, final Long caseID)
    throws AppException, InformationalException {

    // no need to proceed if display property is not enabled.
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_VERIFICATION_SUBMITTED_DOCUMENT_DISPLAY_ENABLED)) {
      return false;
    }

    boolean docsPendingReviewExist = false;

    final curam.verification.sl.infrastructure.entity.intf.Verification verificationObj =
      curam.verification.sl.infrastructure.entity.fact.VerificationFactory
        .newInstance();

    final curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey vdiedLinkKey =
      new curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey();
    vdiedLinkKey.VDIEDLinkID = vdiedLinkID;
    final VerificationDtlsList verificationDtlsList =
      verificationObj.readByVDIEDLinkID(vdiedLinkKey);

    for (final VerificationDtls verificationDtls : verificationDtlsList.dtls) {
      if (Long.compare(caseID, verificationDtls.verificationLinkedID) == 0) {

        final curam.verification.sl.infrastructure.entity.struct.VerificationKey verificationKey =
          new curam.verification.sl.infrastructure.entity.struct.VerificationKey();
        verificationKey.verificationID = verificationDtls.verificationID;
        final CountDetails docPendingReviewCountDetails =
          OutstandingVerificationAttachmentLinkFactory.newInstance()
            .countPendingReviewVerificationAttachments(verificationKey);

        if (docPendingReviewCountDetails.numberOfRecords > 0) {
          docsPendingReviewExist = true;
        }
      }
    }

    return docsPendingReviewExist;
  }

  // BEGIN, 161320, dmorton
  private void updateVerificationsMandatoryStatus(
    final CaseEvidenceVerificationDetails details,
    final CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails)
    throws AppException, InformationalException {

    if (details.mandatory) {
      caseEvidenceVerificationDisplayDetails.mandatory =
        VERIFICATIONWAIVER.TEXT_MANDATORY_VERIFICATION
          .getMessageText(TransactionInfo.getProgramLocale());
      final VerificationWaiverEDParticipantCaseIDDetailsList verificationWaiverList =
        getVerificationsWaiverList(details);
      if (verificationWavered(verificationWaiverList)) {
        caseEvidenceVerificationDisplayDetails.mandatory =
          VERIFICATIONWAIVER.TEXT_MANDATORY_VERIFICATION_WITH_WAIVER
            .getMessageText(TransactionInfo.getProgramLocale());
      }
    } else {
      caseEvidenceVerificationDisplayDetails.mandatory =
        VERIFICATIONWAIVER.TEXT_NOT_MANDATORY_VERIFICATION
          .getMessageText(TransactionInfo.getProgramLocale());
    }
  }

  private VerificationWaiverEDParticipantCaseIDDetailsList
    getVerificationsWaiverList(final CaseEvidenceVerificationDetails details)
      throws AppException, InformationalException {

    final VerificationWaiver verificationWaiverObj =
      VerificationWaiverFactory.newInstance();
    final EvidenceDescriptorIDDetails evidenceDescriptorIDDetails =
      new EvidenceDescriptorIDDetails();
    evidenceDescriptorIDDetails.evidenceDescriptorID =
      details.evidenceDescriptorID;
    return verificationWaiverObj
      .searchByEvidenceDescriptorID(evidenceDescriptorIDDetails);
  }

  private boolean verificationWavered(
    final VerificationWaiverEDParticipantCaseIDDetailsList verificationWaiverList) {

    for (final VerificationWaiverEDParticipantCaseIDDetails waiverDetails : verificationWaiverList.dtls
      .items()) {
      if (Date.getCurrentDate().before(waiverDetails.endDate)
        && Date.getCurrentDate().after(waiverDetails.startDate)
        || Date.getCurrentDate().equals(waiverDetails.endDate)
        || Date.getCurrentDate().equals(waiverDetails.startDate)) {
        return true;
      }
    }
    return false;
  }
  // END, 161320

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseEvidenceVerificationDisplayDetailsList
    listVerificationDetailsforCaseEvidence(final CaseKey key)
      throws AppException, InformationalException {

    final CaseEvidenceVerificationDisplayDetailsList caseEvidenceVerificationDisplayDetailsList =
      new CaseEvidenceVerificationDisplayDetailsList();
    final Verification verificationObj = VerificationFactory.newInstance();
    final OutstandingIndicator outstandingIndicator =
      new OutstandingIndicator();

    outstandingIndicator.verificationStatus = VERIFICATIONSTATUS.DEFAULTCODE;

    final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    caseKeyStruct.caseID = key.caseID;

    // BEGIN, CR0029473, PB
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();

    final ReadByTypeAndCaseIDKey readByTypeAndCaseIDKey =
      new ReadByTypeAndCaseIDKey();

    readByTypeAndCaseIDKey.caseID = key.caseID;
    readByTypeAndCaseIDKey.typeCode = CASEPARTICIPANTROLETYPE.MEMBER;

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList =
      caseParticipantRoleObj.searchByTypeAndCaseID(readByTypeAndCaseIDKey);

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ParticipantKeyStruct participantKeyStruct =
      new ParticipantKeyStruct();
    final ReadParticipantRoleIDDetails readParticipantRoleIDDetails =
      caseHeaderObj.readParticipantRoleID(caseHeaderKey);
    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();

    caseParticipantRoleDtls.participantRoleID =
      readParticipantRoleIDDetails.concernRoleID;
    caseParticipantRoleDtlsList.dtls.add(caseParticipantRoleDtls);

    // BEGIN, CR00303978, PB
    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList =
      verificationObj.listCaseVerificationDetails(caseKeyStruct,
        outstandingIndicator);

    for (final CaseParticipantRoleDtls caseParticipantRoleDetails : caseParticipantRoleDtlsList.dtls
      .items()) {

      participantKeyStruct.participantID =
        caseParticipantRoleDetails.participantRoleID;
      final CaseEvidenceVerificationDetailsList participantList =
        verificationObj
          .listParticipantVerificationDetails(participantKeyStruct);

      for (final CaseEvidenceVerificationDetails verificationDetails : participantList.dtls) {
        // BEGIN, CR00313955, MV
        verificationDetails.concernRoleID =
          caseParticipantRoleDetails.participantRoleID;
        // END, CR00313955

        caseEvidenceVerificationDetailsList.dtls.addRef(verificationDetails);
      }
    }
    // END, CR00303978
    CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails;
    EvidenceDescriptor evidenceDescriptorObj;
    EvidenceDescriptorKey edKey;

    for (final CaseEvidenceVerificationDetails details : caseEvidenceVerificationDetailsList.dtls) {

      caseEvidenceVerificationDisplayDetails =
        new CaseEvidenceVerificationDisplayDetails();
      caseEvidenceVerificationDisplayDetails.caseParticipantRoleID =
        details.caseParticpantRoleID;
      caseEvidenceVerificationDisplayDetails.concernRoleID =
        details.concernRoleID;
      caseEvidenceVerificationDisplayDetails.contextDescription =
        details.contextDescription;
      caseEvidenceVerificationDisplayDetails.dueDate = details.dueDate;
      caseEvidenceVerificationDisplayDetails.evidence = details.evidence;
      caseEvidenceVerificationDisplayDetails.evidenceDescriptorID =
        details.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.itemProvided =
        details.itemProvided;
      caseEvidenceVerificationDisplayDetails.primaryClient =
        details.primaryClient;
      caseEvidenceVerificationDisplayDetails.verificationStatus =
        details.verificationStatus;
      caseEvidenceVerificationDisplayDetails.verifiableDataItemName =
        details.verifiableDataItemName;
      caseEvidenceVerificationDisplayDetails.verifiableDataItemNameXMLOpt =
        getVerifiableDataItemDetails(details.verifiableDataItemName,
          details.documentSubmittedOpt).toString();
      caseEvidenceVerificationDisplayDetails.vDIEDLinkID =
        details.vDIEDLinkID;
      caseEvidenceVerificationDisplayDetails.verificationID =
        details.verificationID;
      caseEvidenceVerificationDisplayDetails.verificationStatusDescription =
        CodeTable.getOneItem(VERIFICATIONSTATUS.TABLENAME,
          caseEvidenceVerificationDisplayDetails.verificationStatus,
          TransactionInfo.getProgramLocale());
      // BEGIN, 161320, dmorton
      updateVerificationsMandatoryStatus(details,
        caseEvidenceVerificationDisplayDetails);
      // END, 161320
      evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      edKey = new EvidenceDescriptorKey();
      edKey.evidenceDescriptorID =
        caseEvidenceVerificationDisplayDetails.evidenceDescriptorID;
      caseEvidenceVerificationDisplayDetails.evidenceType =
        evidenceDescriptorObj
          .readRelatedIDParticipantIDAndEvidenceType(edKey).evidenceType;
      caseEvidenceVerificationDisplayDetailsList.dtls
        .add(caseEvidenceVerificationDisplayDetails);
    }
    // END, CR0029473

    return caseEvidenceVerificationDisplayDetailsList;
  }
  // END, CR00261681

  // BEGIN, CR00279713, AC
  /**
   * {@inheritDoc}
   */
  @Override
  public DataItemNameVerificationIDDtls
    readDataItemAndID(final EvidenceDescriptorKey key)
      throws AppException, InformationalException {

    final DataItemNameVerificationIDDtls dataItemNameVerificationIDDtls =
      new DataItemNameVerificationIDDtls();
    final EvidenceVerificationDetails evidenceVerificationDetails =
      readEvidenceVerificationDetails(key);

    dataItemNameVerificationIDDtls.dataItemName =
      evidenceVerificationDetails.evidenceVerificationDetails.dataItemName;
    dataItemNameVerificationIDDtls.vdIEDLinkID =
      evidenceVerificationDetails.evidenceVerificationDetails.vdIEDLinkID;
    dataItemNameVerificationIDDtls.verificationLinkedID =
      evidenceVerificationDetails.evidenceVerificationDetails.verificationLinkedID;
    return dataItemNameVerificationIDDtls;
  }

  // END, CR00279713

  // BEGIN, CR00342712, SR
  /**
   * {@inheritDoc}
   */
  @Override
  public ListVerificationItemNameDetails readAllUserProvidedVerificationItems(
    final VDIEDLinkKey key) throws AppException, InformationalException {

    final ListVerificationItemNameDetailsList listVerificationItemNameDetailsList =
      VerificationApplicationFactory.newInstance()
        .readAllUserProvidedVerificationItems(key.dtls);

    final ListVerificationItemNameDetails listVerificationItemNameDetails =
      new ListVerificationItemNameDetails();

    listVerificationItemNameDetails.listVerificationItemNameDetailsList =
      listVerificationItemNameDetailsList;
    return listVerificationItemNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public UserProvidedVerificationItemKey newUserProvidedVerificationItem(
    final NewUserProvidedVerificationItemDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.struct.UserProvidedVerificationItemKey userProvidedVerificationItemKey =
      VerificationApplicationFactory.newInstance()
        .newUserProvidedVerificationItem(
          details.newUserProvidedVerificationItemDetails);

    final UserProvidedVerificationItemKey returnKey =
      new UserProvidedVerificationItemKey();

    returnKey.userProvidedVerificationItemKey =
      userProvidedVerificationItemKey;
    // BEGIN, CR00400972, RPB
    final String[] messages =
      TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i != messages.length; i++) {
      final VerificationMessage warning = new VerificationMessage();

      warning.message = messages[i];
      returnKey.infoMsgListOpt.addRef(warning);
    }
    // END, CR00400972

    return returnKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadVerificationDetails
    fetchVerificationDetails(final EvidenceVerificationDetails dtls)
      throws AppException, InformationalException {

    final ReadVerificationDetails readVerificationDetails =
      new ReadVerificationDetails();

    readVerificationDetails.readVerificationDetails =
      VerificationApplicationFactory.newInstance()
        .fetchVerificationDetails(dtls.evidenceVerificationDetails);

    final curam.verification.sl.infrastructure.intf.Verification verification =
      curam.verification.sl.infrastructure.fact.VerificationFactory
        .newInstance();

    readVerificationDetails.verificationPageContextDetails =
      verification.readPageContextDescriptionForViewVerificationDetails(
        dtls.evidenceVerificationDetails);

    final boolean isEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_VERIFICATION_SUBMITTED_DOCUMENT_DISPLAY_ENABLED);
    readVerificationDetails.submittedDocumentDetails.isDisplayEnabledInd =
      isEnabled;
    if (readVerificationDetails.submittedDocumentDetails.isDisplayEnabledInd) {
      final CaseIDAndVDIEDLinkIDKey key = new CaseIDAndVDIEDLinkIDKey();

      key.caseID = dtls.evidenceVerificationDetails.verificationLinkedID;
      key.vdiedLinkID = dtls.evidenceVerificationDetails.vdIEDLinkID;

      final ValueList<curam.verification.sl.infrastructure.struct.SubmittedDocumentDetails> submittedDocs =
        VerificationApplicationFactory.newInstance()
          .listSubmittedDocuments(key).dtls;
      readVerificationDetails.submittedDocumentDetails.submittedDocumentDetailsList
        .addAll(submittedDocs);
    }

    // BEGIN, CR00451648, GK
    final String[] messages =
      TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (

      int i = 0; i != messages.length; i++) {
      final VerificationMessage warning = new VerificationMessage();

      warning.message = messages[i];
      readVerificationDetails.message.addRef(warning);
    }
    // END, CR00451648
    return readVerificationDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancelUserProvidedVerificationItem(
    final CancelUserProvidedVerificationItemDetails details)
    throws AppException, InformationalException {

    VerificationApplicationFactory.newInstance()
      .cancelUserProvidedVerificationItem(
        details.cancelUserProvidedVerificationItemDetails);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReadUserProvidedVerificationItemDetails
    readUserProvidedVerificationItem(final UserProvidedVerificationItem key)
      throws AppException, InformationalException {

    final ReadUserProvidedVerificationItemDetails returnDetails =
      new ReadUserProvidedVerificationItemDetails();

    final curam.verification.sl.infrastructure.struct.ReadUserProvidedVerificationItemDetails readUserProvidedVerificationItemDetails =
      VerificationApplicationFactory.newInstance()
        .readUserProvidedVerificationItem(key.userProvidedVerificationItem);

    returnDetails.readUserProvidedVerificationItemDetails =
      readUserProvidedVerificationItemDetails;

    final curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey verificationItemProvidedKey =
      new curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey();

    // BEGIN, CR00350465, LKS
    verificationItemProvidedKey.verificationItemProvidedID =
      key.userProvidedVerificationItem.verificationItemProvidedID;
    // END, CR00350465
    final VerificationItemProvided verificationItemProvidedObj =
      VerificationItemProvidedFactory.newInstance();

    returnDetails.verificationPageContextDetails = verificationItemProvidedObj
      .readPageContextDescriptionForItemProvided(verificationItemProvidedKey);

    // BEGIN, CR00408279, RPB
    final String[] messages =
      TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i != messages.length; i++) {
      final VerificationMessage warning = new VerificationMessage();

      warning.message = messages[i];
      returnDetails.infoMsgListOpt.addRef(warning);
    }
    // END, CR00408279

    return returnDetails;
  }

  // END, CR00342712

  // BEGIN, CR00451420, GK
  /**
   * {@inheritDoc}
   */
  @Override
  public
    curam.verification.facade.infrastructure.struct.ListVerificationItemNameDetails
    listAllVerificationItemsForAllOutstandingVerification(
      final curam.core.struct.CaseKey caseKey)
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final CaseEvidenceVerificationDisplayDetailsList caseEvidenceVerificationDisplayDetailsListObj =
      listOutstandingVerificationDetailsForCaseEvidence(caseKey);
    final Set<Long> filterDuplicateVerificationItem = new HashSet<Long>();
    final ListVerificationItemNameDetails listVerificationItemNameDetails =
      new ListVerificationItemNameDetails();
    final ListVerificationItemNameDetailsList listVerificationItemNameDetailsList =
      new ListVerificationItemNameDetailsList();

    for (final CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails : caseEvidenceVerificationDisplayDetailsListObj.dtls) {
      final curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey vDIEDLinkKey =
        new curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID =
        caseEvidenceVerificationDisplayDetails.vDIEDLinkID;
      final ListVerificationItemNameDetailsList listVerificationItemNameDetailsList1 =
        VerificationApplicationFactory.newInstance()
          .readAllUserProvidedVerificationItems(vDIEDLinkKey);

      // BEGIN, CR00452774, GK
      if (0 < listVerificationItemNameDetailsList1.listVerificationItemNameDetails
        .size()) {
        for (final curam.verification.sl.infrastructure.struct.ListVerificationItemNameDetails verificationItemNameDetails : listVerificationItemNameDetailsList1.listVerificationItemNameDetails) {
          if (filterDuplicateVerificationItem
            .add(verificationItemNameDetails.verificationItemID)) {
            listVerificationItemNameDetailsList.listVerificationItemNameDetails
              .add(verificationItemNameDetails);
          }
        }
      }
    }
    // END, CR00452774
    listVerificationItemNameDetails.listVerificationItemNameDetailsList =
      listVerificationItemNameDetailsList;
    return listVerificationItemNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public
    curam.verification.facade.infrastructure.struct.ListVerificationItemNameDetails
    listAllVerificationItemsForCaseParticipant(final ParticipantKeyStruct key)
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      listParticipantVerificationDetails(key);

    final ListVerificationItemNameDetails listVerificationItemNameDetails =
      new ListVerificationItemNameDetails();
    final ListVerificationItemNameDetailsList listVerificationItemNameDetailsList =
      new ListVerificationItemNameDetailsList();

    // BEGIN, CR00453111, GK
    final Set<Long> filterDuplicateVerificationItem = new HashSet<Long>();

    // END, CR00453111
    for (final CaseEvidenceVerificationDetails caseEvidenceVerificationDetails : integratedCaseVerificationDetailsList.dtls.dtls) {
      final curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey vDIEDLinkKey =
        new curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey();

      vDIEDLinkKey.VDIEDLinkID = caseEvidenceVerificationDetails.vDIEDLinkID;
      final ListVerificationItemNameDetailsList listVerificationItemNameDetailsList1 =
        VerificationApplicationFactory.newInstance()
          .readAllUserProvidedVerificationItems(vDIEDLinkKey);

      // BEGIN, CR00452774, GK

      if (0 < listVerificationItemNameDetailsList1.listVerificationItemNameDetails
        .size()) {
        for (final curam.verification.sl.infrastructure.struct.ListVerificationItemNameDetails verifictionItemDetail : listVerificationItemNameDetailsList1.listVerificationItemNameDetails) {
          if (filterDuplicateVerificationItem
            .add(verifictionItemDetail.verificationItemID)) {
            listVerificationItemNameDetailsList.listVerificationItemNameDetails
              .add(verifictionItemDetail);
          }
        }
      }
      // END, CR00452774
    }
    listVerificationItemNameDetails.listVerificationItemNameDetailsList =
      listVerificationItemNameDetailsList;
    return listVerificationItemNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public UserProvidedVerificationItemKey
    newUserProvidedVerificationItemAndAssociatedEvidences(
      final ActionIDProperty actionIDProperty,
      final WizardStateID wizardStateID,
      NewUserProvidedVerItemAndEvdDetails details)
      throws AppException, InformationalException {

    details = updateUserProvidedVerificationDetails(wizardStateID, details);
    final curam.verification.sl.infrastructure.struct.UserProvidedVerificationItemKey userProvidedVerificationItemKeyStruct =
      persistUserProvidedVerificationItemWithAssociatedEvidence(wizardStateID,
        details);
    return createFacadeReturnKey(userProvidedVerificationItemKeyStruct);
  }

  private NewUserProvidedVerItemAndEvdDetails
    updateUserProvidedVerificationDetails(final WizardStateID wizardStateID,
      NewUserProvidedVerItemAndEvdDetails details) {

    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();
    NewUserProvidedVerItemAndWizardDetails newUserProvidedVerItemAndWizardDetails =
      new NewUserProvidedVerItemAndWizardDetails();
    if (wizardStateIdValid(wizardStateID)) {
      newUserProvidedVerItemAndWizardDetails =
        getWizardDetails(wizardStateID.wizardStateID, wizardPersistentState);
    }
    details = preserveUserProvidedCommentsDuringUpdate(
      newUserProvidedVerItemAndWizardDetails, details);
    return details;
  }

  private boolean wizardStateIdValid(final WizardStateID wizardStateID) {

    return wizardStateID.wizardStateID != 0;
  }

  private NewUserProvidedVerItemAndWizardDetails getWizardDetails(
    final long wizardStateID,
    final WizardPersistentState wizardPersistentState) {

    return (NewUserProvidedVerItemAndWizardDetails) wizardPersistentState
      .read(wizardStateID);
  }

  private NewUserProvidedVerItemAndEvdDetails
    preserveUserProvidedCommentsDuringUpdate(
      final NewUserProvidedVerItemAndWizardDetails newUserProvidedVerItemAndWizardDetails,
      final NewUserProvidedVerItemAndEvdDetails details) {

    final String userSubmittedVerificationComments =
      details.dtls.newUserProvidedVerificationItemDetails.newUserProvidedVerificationInfo.comments;
    // BEGIN, CR00451497, GK
    details.dtls.newUserProvidedVerificationItemDetails =
      newUserProvidedVerItemAndWizardDetails.newUserProvdedVerificationItemDetails.newUserProvidedVerificationItemDetails;
    // END, CR00451497
    // BEGIN, 170463, dmorton
    details.comments = userSubmittedVerificationComments;
    // END, 170463
    return details;
  }

  curam.verification.sl.infrastructure.struct.UserProvidedVerificationItemKey
    persistUserProvidedVerificationItemWithAssociatedEvidence(
      final WizardStateID wizardStateID,
      final NewUserProvidedVerItemAndEvdDetails details)
      throws AppException, InformationalException {

    return VerificationApplicationFactory.newInstance()
      .newUserProvidedVerificationItemAndAssociatedEvidences(details);
  }

  private UserProvidedVerificationItemKey createFacadeReturnKey(
    final curam.verification.sl.infrastructure.struct.UserProvidedVerificationItemKey userProvidedVerificationItemKeyStuct) {

    UserProvidedVerificationItemKey facadeReturnKey =
      new UserProvidedVerificationItemKey();
    facadeReturnKey.userProvidedVerificationItemKey =
      userProvidedVerificationItemKeyStuct;
    facadeReturnKey =
      includeWarningMessagesInFacadeReturnKey(facadeReturnKey);
    return facadeReturnKey;
  }

  private UserProvidedVerificationItemKey
    includeWarningMessagesInFacadeReturnKey(
      final UserProvidedVerificationItemKey facadeReturnKey) {

    final String[] messages =
      TransactionInfo.getInformationalManager().obtainInformationalAsString();
    for (int i = 0; i != messages.length; i++) {
      final VerificationMessage warning = new VerificationMessage();
      warning.message = messages[i];
      facadeReturnKey.infoMsgListOpt.addRef(warning);
    }
    return facadeReturnKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public curam.core.facade.struct.WizardProperties
    getAddItemsToOutstandingVerificationWizard()
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu =
      CuramConst.kProvideVerificationItemWizardProperties;
    return wizardProperties;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public curam.core.facade.struct.WizardProperties
    getAddItemsToOutstandingVerificationForPDCWizard()
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu =
      CuramConst.kProvideVerificationItemWizardForPDCProperties;
    return wizardProperties;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseEvidenceVerificationDisplayDetailsList
    listOutstandingVerificationDetails(
      final curam.core.sl.struct.WizardStateID wizardStateID)
      throws AppException, InformationalException {

    // BEGIN, CR00452774, GK
    final CaseEvidenceVerificationDisplayDetailsList resultCaseEvidenceVerificationDisplayDetailsList =
      new CaseEvidenceVerificationDisplayDetailsList();

    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();

    NewUserProvidedVerItemAndWizardDetails newUserProvidedVerItemAndWizardDetails =
      new NewUserProvidedVerItemAndWizardDetails();

    if (0L != wizardStateID.wizardStateID) {
      newUserProvidedVerItemAndWizardDetails =
        (NewUserProvidedVerItemAndWizardDetails) wizardPersistentState
          .read(wizardStateID.wizardStateID);
    }

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID =
      newUserProvidedVerItemAndWizardDetails.newUserProvdedVerificationItemDetails.newUserProvidedVerificationItemDetails.itemProvidedDetailsdtls.caseID;

    // BEGIN, CR00452978, GK
    TransactionInfo.setFacadeScopeObject(VerificationConst.kIsAddProofWizard,
      CuramConst.gkYes);

    final CaseEvidenceVerificationDisplayDetailsList caseEvidenceVerificationDisplayDetailsList =
      listOutstandingVerificationDetailsForCaseEvidence(caseKey);

    TransactionInfo.setFacadeScopeObject(VerificationConst.kIsAddProofWizard,
      null);
    // END, CR00452978
    final long verificationItemID =
      newUserProvidedVerItemAndWizardDetails.newUserProvdedVerificationItemDetails.newUserProvidedVerificationItemDetails.newUserProvidedVerificationInfo.verificationItemIDOpt;
    final VerificationItemUtilization verificationItemUtilization =
      VerificationItemUtilizationFactory.newInstance();

    if (null != caseEvidenceVerificationDisplayDetailsList) {
      for (final CaseEvidenceVerificationDisplayDetails caseEvidenceVerificationDisplayDetails : caseEvidenceVerificationDisplayDetailsList.dtls) {
        final SearchByVerificationItem searchByVerificationItemKey =
          new SearchByVerificationItem();

        searchByVerificationItemKey.recordStatus = RECORDSTATUS.NORMAL;
        searchByVerificationItemKey.verifiableDataItemID =
          caseEvidenceVerificationDisplayDetails.verifiableDataItemIDOpt;
        searchByVerificationItemKey.verificationItemID = verificationItemID;
        final VerificationItemUtilizationUsageDetailsList verificationItemUtilizationUsageDetailsList =
          verificationItemUtilization
            .searchByVerificationItemAndVerificableDataItem(
              searchByVerificationItemKey);

        if (null != verificationItemUtilizationUsageDetailsList
          && 0 < verificationItemUtilizationUsageDetailsList.dtls.size()) {
          resultCaseEvidenceVerificationDisplayDetailsList.dtls
            .add(caseEvidenceVerificationDisplayDetails);
        }
      }
    }
    // END, CR00452774
    return resultCaseEvidenceVerificationDisplayDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public
    curam.verification.facade.infrastructure.struct.NewUserProvidedVerItemAndWizardDetails
    validateBulkEvidenceVerificationAddProofPage(
      final curam.verification.facade.infrastructure.struct.NewUserProvidedVerificationItemDetails details,
      final ActionIDProperty actionIDProperty,
      final curam.core.sl.struct.WizardStateID wizardStateID)
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final NewUserProvidedVerItemAndWizardDetails newUserProvidedVerItemAndWizardDetails =
      new NewUserProvidedVerItemAndWizardDetails();

    newUserProvidedVerItemAndWizardDetails.newUserProvdedVerificationItemDetails =
      details;
    final curam.core.facade.struct.ConcernRoleIDKey concernRoleIDKey =
      new curam.core.facade.struct.ConcernRoleIDKey();

    if (0 != details.newUserProvidedVerificationItemDetails.itemProvidedDetailsdtls.participantConcernRoleID) {
      concernRoleIDKey.concernRoleID =
        details.newUserProvidedVerificationItemDetails.itemProvidedDetailsdtls.participantConcernRoleID;
      details.newUserProvidedVerificationItemDetails.itemProvidedDetailsdtls.participantNameOpt =
        ConcernRoleFactory.newInstance()
          .readConcernRoleName(concernRoleIDKey).concernRoleName;
    }
    VerificationApplicationFactory.newInstance()
      .validateBulkEvidenceVerificationAddProofPage(details);
    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();

    if (0 == wizardStateID.wizardStateID) {
      wizardStateID.wizardStateID =
        wizardPersistentState.create(newUserProvidedVerItemAndWizardDetails);
    } else {

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        newUserProvidedVerItemAndWizardDetails);
    }
    newUserProvidedVerItemAndWizardDetails.wizardStateID = wizardStateID;
    return newUserProvidedVerItemAndWizardDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public
    curam.verification.facade.infrastructure.struct.NewUserProvidedVerItemAndWizardDetails
    getUserProvidedVerificationItemWizardDetails(
      final curam.core.sl.struct.WizardStateID wizardStateID)
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    final WizardPersistentState wizardPersistentState =
      new WizardPersistentState();
    NewUserProvidedVerItemAndWizardDetails newUserProvidedVerItemAndWizardDetails =
      new NewUserProvidedVerItemAndWizardDetails();

    if (0 != wizardStateID.wizardStateID) {
      newUserProvidedVerItemAndWizardDetails =
        (NewUserProvidedVerItemAndWizardDetails) wizardPersistentState
          .read(wizardStateID.wizardStateID);
    } else {
      wizardStateID.wizardStateID =
        wizardPersistentState.create(newUserProvidedVerItemAndWizardDetails);
      newUserProvidedVerItemAndWizardDetails.wizardStateID = wizardStateID;
      // BEGIN, CR00451745, GK
      newUserProvidedVerItemAndWizardDetails.newUserProvdedVerificationItemDetails.newUserProvidedVerificationItemDetails.newUserProvidedVerificationInfo.dateReceived =
        Date.getCurrentDate();
      // END, CR00451745
    }
    return newUserProvidedVerItemAndWizardDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public
    curam.verification.facade.infrastructure.struct.IntegratedCaseVerificationDetailsList
    listOutstandingVerificationDetailsForPDC(
      final curam.verification.facade.infrastructure.struct.ParticipantIDAndVerItemIDKey key)
      throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    // BEGIN, CR00452774, GK
    final IntegratedCaseVerificationDetailsList resultIntegratedCaseVerificationDetailsList =
      new IntegratedCaseVerificationDetailsList();

    final ParticipantKeyStruct participantKey = new ParticipantKeyStruct();

    participantKey.participantID = key.participantID;

    // BEGIN, CR00452978, GK
    TransactionInfo.setFacadeScopeObject(VerificationConst.kIsAddProofWizard,
      CuramConst.gkYes);
    final IntegratedCaseVerificationDetailsList integratedCaseVerificationDetailsList =
      listParticipantVerificationDetails(participantKey);

    TransactionInfo.setFacadeScopeObject(VerificationConst.kIsAddProofWizard,
      null);
    // END, CR00452978
    final VerificationItemUtilization verificationItemUtilization =
      VerificationItemUtilizationFactory.newInstance();

    if (null != integratedCaseVerificationDetailsList) {
      for (final CaseEvidenceVerificationDetails caseEvidenceVerificationDisplayDetails : integratedCaseVerificationDetailsList.dtls.dtls) {

        final SearchByVerificationItem searchByVerificationItemKey =
          new SearchByVerificationItem();

        searchByVerificationItemKey.verifiableDataItemID =
          caseEvidenceVerificationDisplayDetails.verifiableDataItemIDOpt;
        searchByVerificationItemKey.recordStatus = RECORDSTATUS.NORMAL;
        searchByVerificationItemKey.verificationItemID =
          key.verificationItemID;
        final VerificationItemUtilizationUsageDetailsList verificationItemUtilizationUsageDetailsList =
          verificationItemUtilization
            .searchByVerificationItemAndVerificableDataItem(
              searchByVerificationItemKey);

        if (null != verificationItemUtilizationUsageDetailsList
          && 0 < verificationItemUtilizationUsageDetailsList.dtls.size()) {
          resultIntegratedCaseVerificationDetailsList.dtls.dtls
            .add(caseEvidenceVerificationDisplayDetails);
        }
      }
    }
    // END, CR00452774
    return resultIntegratedCaseVerificationDetailsList;
  }
  // END, CR00451420

  /**
   * {@inheritDoc}
   */
  @Override
  public UserProvidedVerificationItemKey
    acceptExistingDocumentAsProof(final AttachmentLinkID details)
      throws AppException, InformationalException {

    final curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey newVerificationItemProvidedKey =
      VerificationApplicationFactory.newInstance()
        .acceptExistingDocumentAsProof(details);

    final UserProvidedVerificationItemKey verificationItemProvidedKey =
      new UserProvidedVerificationItemKey();
    verificationItemProvidedKey.userProvidedVerificationItemKey.verificationItemProvidedID =
      newVerificationItemProvidedKey.verificationItemProvidedID;

    return verificationItemProvidedKey;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void rejectDocumentPendingReviewForVerification(
    final AttachmentLinkID attachmentLinkID)
    throws AppException, InformationalException {

    final OutstandingVerificationAttachmentLink outstandingVerificationAttachmentLinkObj =
      OutstandingVerificationAttachmentLinkFactory.newInstance();

    final VerificationAttachmentReviewStatus reviewStatus =
      new VerificationAttachmentReviewStatus();
    reviewStatus.reviewStatus = DOCUMENTREVIEWSTATUS.REJECTED;
    outstandingVerificationAttachmentLinkObj
      .modifyStatusOfAttachmentPendingReviewForVerification(attachmentLinkID,
        reviewStatus);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void rejectAllDocumentsPendingReviewForVerification(
    final CaseIDAndVDIEDLinkIDKey key)
    throws AppException, InformationalException {

    final SubmittedDocumentDetailsList documentsList =
      VerificationApplicationFactory.newInstance()
        .listSubmittedDocuments(key);

    for (final curam.verification.sl.infrastructure.struct.SubmittedDocumentDetails documentDetails : documentsList.dtls) {
      final AttachmentLinkID linkID = new AttachmentLinkID();
      linkID.attachmentLinkID = documentDetails.attachmentLinkID;
      rejectDocumentPendingReviewForVerification(linkID);
    }

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void acceptAllDocumentsPendingReviewForVerification(
    final CaseIDAndVDIEDLinkIDKey key)
    throws AppException, InformationalException {

    final SubmittedDocumentDetailsList documentsList =
      VerificationApplicationFactory.newInstance()
        .listSubmittedDocuments(key);

    for (final curam.verification.sl.infrastructure.struct.SubmittedDocumentDetails documentDetails : documentsList.dtls) {
      final AttachmentLinkID linkID = new AttachmentLinkID();
      linkID.attachmentLinkID = documentDetails.attachmentLinkID;
      acceptExistingDocumentAsProof(linkID);
    }

  }

}
