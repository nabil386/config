/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.evidence.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCENATUREEntry;
import curam.evidence.impl.EvidenceNature;
import java.util.Map;


/**
 * Responsible for creating the correct implementation of the
 * {@link VerificationEvidenceInterface} based on the evidence nature of
 * evidence type being passed. For example if evidence type being passed is
 * dynamic evidence nature then the implementation class which deals with
 * dynamic evidence types would be returned by map binder look up.
 */
public class VerificationEvidenceFactory {

  /**
   * A hash map reference for {@link VerificationEvidenceInterface} which has
   * bindings for implementation class based on evidence nature.
   */
  @Inject
  private static Map<EVIDENCENATUREEntry, VerificationEvidenceInterface> verificationEvidenceMap;

  /**
   * A reference for {@link EvidenceNature}.
   */
  @Inject
  private static EvidenceNature evidenceNature;

  /**
   * Returns an instance of an implementation class which implements
   * VerificationEvidenceInterface interface based on the evidence nature of an
   * evidence type being passed. For example if evidence nature of an evidence
   * type being passed is 'STATIC', then the implementation class which is
   * mapped for 'STATIC' would be returned.
   *
   * @param evidenceType
   * Contains the evidence type code.
   *
   * @return An instance of an implementation class which implements
   * VerificationEvidenceInterface interface based on the evidence
   * nature of an evidence type.
   */
  public static VerificationEvidenceInterface newInstance(
    CASEEVIDENCEEntry evidenceType) {

    VerificationEvidenceInterface verificationEvidenceInterface = null;

    try {
      verificationEvidenceInterface = verificationEvidenceMap.get(
        evidenceNature.getEvidenceNatureCode(evidenceType));
    } catch (final curam.util.exception.AppRuntimeException e) {
      throw e;
    } catch (final java.lang.Exception e) {
      throw new curam.util.exception.AppRuntimeException(e);
    }

    return verificationEvidenceInterface;
  }
}
