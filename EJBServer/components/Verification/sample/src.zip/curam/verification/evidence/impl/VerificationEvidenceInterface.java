/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.evidence.impl;


import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;


/**
 * Abstracts the usage of static and dynamic evidence in the Verification
 * Engine.The purpose of this abstraction is to allow the Verification
 * Engine to work independently of the Dynamic Evidence component. When Dynamic
 * Evidence component is not present in the system, the Verification Engine will
 * operate on static evidence only. When Dynamic Evidence component is installed
 * the Verification Engine will operate on static and dynamic evidence.
 */
public interface VerificationEvidenceInterface {

  /**
   * The isFieldEmpty method checks the field for empty.
   *
   * @param dataItem Name of the field to check for empty.
   * @param evidenceObject Object containing field value.
   * @param evidenceType Evidence type (codetable code) of the specified
   * evidence object.
   * @return true if the field is empty
   */
  boolean isFieldEmpty(String dataItem, Object evidenceObject,
    String evidenceType);

  /**
   * The compare fields method compares the field values.
   *
   * @param dataItem Name of the field to compare the values.
   * @param modifiedEvidence first object containing field value.
   * @param previousEvidence second object containing field value.
   * @param evidenceType Evidence type (codetable code) of the specified
   * evidence object.
   * @return true if the field comparison matches
   */
  boolean compareFields(String dataItem, Object modifiedEvidence,
    Object previousEvidence, String evidenceType);

  /**
   * Checks the value of verifiable data item with the previous value.
   *
   * @param dataItem as String
   * @param eiEvidenceModifyDtls EIEvidence modify details
   * @param eiEvidenceReadDtls EIEvidence read details
   * @param evidenceType Evidence type (codetable code) of the specified
   * evidence object.
   * @return true if the date item value has changed
   */
  boolean checkDataItemValueChanged(String dataItem,
    EIEvidenceModifyDtls eiEvidenceModifyDtls,
    EIEvidenceReadDtls eiEvidenceReadDtls, String evidenceType);
}
