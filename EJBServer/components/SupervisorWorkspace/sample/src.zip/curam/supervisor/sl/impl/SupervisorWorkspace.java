/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.supervisor.sl.impl;


import com.google.inject.Inject;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.codetable.WORKQUEUETYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.ProductDelivery;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrganisationUnitFullDetails;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueNameIDAndTaskCountDetailsList;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.WorkQueueSubscriptionFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.WorkQueueSubscription;
import curam.core.struct.CasesBySupervisorIDAndDateRangeKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ReadUserIDFullNamePosition;
import curam.core.struct.ReadUserIDFullNamePositionList;
import curam.core.struct.SupervisorCasesWithIssuesDetails;
import curam.core.struct.SupervisorCasesWithIssuesDetailsList;
import curam.core.struct.SupervisorUserDetails;
import curam.core.struct.SupervisorUserDetailsList;
import curam.core.struct.UserAndStatusKey;
import curam.core.struct.UserCaseTaskStatus;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.SUPERVISORCONST;
import curam.supervisor.sl.fact.MaintainSupervisorOrgUnitsFactory;
import curam.supervisor.sl.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.sl.intf.MaintainSupervisorOrgUnits;
import curam.supervisor.sl.struct.CasesByDateRangeKey;
import curam.supervisor.sl.struct.CasesWithIssuesByDateKey;
import curam.supervisor.sl.struct.CasesWithIssuesDtlsList;
import curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList;
import curam.supervisor.sl.struct.ChooseDayDetails;
import curam.supervisor.sl.struct.OrgUnitAssignedTasksByUserDueOnDateDetails;
import curam.supervisor.sl.struct.OrgUnitMemberDetailsList;
import curam.supervisor.sl.struct.OrgUnitTasksByUserSearchKey;
import curam.supervisor.sl.struct.OrganisationUnitDetails;
import curam.supervisor.sl.struct.OrganisationUnitDetailsList;
import curam.supervisor.sl.struct.PriorityWeekCaseDtls;
import curam.supervisor.sl.struct.PriorityWeekCasesUICHeatmapDetails;
import curam.supervisor.sl.struct.ReadSupervisorHomePageDetails;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.struct.SupervisorOrganisationUnitDetails;
import curam.supervisor.sl.struct.UserApplicationCodeDetails;
import curam.supervisor.sl.struct.WorkQueueDetails;
import curam.supervisor.sl.struct.WorkQueueDetailsList;
import curam.supervisor.sl.struct.WorkQueueTypeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * Service Layer implementation for Supervisor Workspace
 *
 */
public abstract class SupervisorWorkspace extends curam.supervisor.sl.base.SupervisorWorkspace {

  /**
   * Identifier for holding the HEATMAP element for HEATMAP XML
   */
  protected static final String kHeatMap = SupervisorConst.kHeatMap;

  /**
   * Identifier for holding the CAPTION element for HEATMAP XML
   */
  protected static final String kCaption = SupervisorConst.kCaption;

  /**
   * Identifier for holding the REGION for HEATMAP XML
   */
  protected static final String kRegion = SupervisorConst.kRegion;

  /**
   * Identifier for holding the REGION_ID element
   */
  protected static final String kRegionId = SupervisorConst.kRegionId;

  /**
   * Identifier for holding the CASE_ID for Item element
   */
  protected static final String kItemId = SupervisorConst.kItemId;

  /**
   * Identifier for holding the Label for REGION and ITEM
   */
  protected static final String kLabel = SupervisorConst.kLabel;

  /**
   * Identifier for holding the CASE_ID for Item element
   */
  protected static final String kCaseId = SupervisorConst.kCaseId;

  /**
   * Identifier for holding the Item element
   */
  protected static final String kItem = SupervisorConst.kItem;

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode = SupervisorConst.kTaskOptionCode;

  // BEGIN, CR00451982, MR
  /**
   * Reference to a SupervisorWorkQueuesFetcher class
   */
  @Inject
  protected SupervisorWorkQueuesFetcher supervisorWorkQueuesHooksObj;

  /**
   * Reference to a OrgUnitSubscribedWorkQueuesFetcher class
   */
  @Inject
  protected OrgUnitSubscribedWorkQueuesFetcher orgUnitSubscribedWorkQueuesFetcherObj;

  /**
   * Reference to a JobSubscribedWorkQueuesFetcher class
   */
  @Inject
  protected JobSubscribedWorkQueuesFetcher jobSubscribedWorkQueuesFetcherObj;

  /**
   * Reference to a PositionSubscribedWorkQueuesFetcher class
   */
  @Inject
  protected PositionSubscribedWorkQueuesFetcher positionSubscribedWorkQueuesFetcherObj;

  /**
   * Constructor
   */
  public SupervisorWorkspace() {

    GuiceWrapper.getInjector().injectMembers(this);

  }

  // END, CR00451982
  // ___________________________________________________________________________
  /**
   * Retrieves the list of user details reporting to the supervisor.
   *
   * @return the ReadSupervisorHomePageDetails object.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ReadSupervisorHomePageDetails readSupervisorHomePageDetails()
    throws AppException, InformationalException {

    final UserAndStatusKey userAndStatusKey = new UserAndStatusKey();

    // BEGIN, CR00282652, AKr
    final String programUser = TransactionInfo.getProgramUser();

    userAndStatusKey.userName = programUser;
    userAndStatusKey.status = RECORDSTATUS.CANCELLED;

    // BEGIN CR00107117 ,GM
    final Users usersObj = UsersFactory.newInstance();
    // END CR00107117

    ReadUserIDFullNamePositionList namePositionList = new ReadUserIDFullNamePositionList();
    final String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;
    final String orgUnitSelectOption = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

    if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
      namePositionList = usersObj.searchSupervisorUsersLeadPos(userAndStatusKey);
    } else {
      // BEGIN, CR00279187, AC
      final UserCaseTaskStatus key = new UserCaseTaskStatus();

      key.userName = programUser;
      key.status = RECORDSTATUS.CANCELLED;
      final SupervisorUserDetailsList userList = usersObj.searchUsersBySupervisorID(
        key);
      ReadUserIDFullNamePosition readUserIDFullNamePosition;
      final SupervisorUserDetails[] supervisorUserDetails = userList.dtls.items();

      for (final SupervisorUserDetails userDetails : supervisorUserDetails) {
        readUserIDFullNamePosition = new ReadUserIDFullNamePosition();
        readUserIDFullNamePosition.positionName = userDetails.positionName;
        readUserIDFullNamePosition.userFullName = userDetails.fullName;
        readUserIDFullNamePosition.userName = userDetails.userName;
        namePositionList.dtls.add(readUserIDFullNamePosition);
      }
    }

    // remove the current user's name from the list
    final SystemUser systemUser = SystemUserFactory.newInstance();
    final String userName = systemUser.getUserDetails().userName;
    final ReadUserIDFullNamePosition[] readUserIDFullNamePosition = namePositionList.dtls.items();

    for (final ReadUserIDFullNamePosition userDetails : readUserIDFullNamePosition) {
      if (userDetails.userName.equals(userName)) {
        namePositionList.dtls.remove(userDetails);
      }
    }
    // END, CR00279187

    final ReadSupervisorHomePageDetails pageDetails = new ReadSupervisorHomePageDetails();

    // END, CR00282652
    pageDetails.userListDtls = namePositionList;
    return pageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of work queues that a supervisor's users are currently
   * subscribed to. These can be user subscribed,organization unit
   * subscribed,job subscribed or position subscribed work queues.
   *
   * @param key
   * WorkQueueTypeKey work queue type to display.
   * @return Work queue details list
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WorkQueueDetailsList readWorkqueueList(WorkQueueTypeKey key)
    throws AppException, InformationalException {

    WorkQueueDetailsList workQueueDetailsList = new WorkQueueDetailsList();
    final UserNameKey userNameKey = new UserNameKey();
    final curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();

    userNameKey.userName = systemUser.getUserDetails().userName;
    // BEGIN, CR00451982, MR
    WorkQueueNameIDAndTaskCountDetailsList workQueueNameIDAndTaskCountDetailsList = new WorkQueueNameIDAndTaskCountDetailsList();

    if (WORKQUEUETYPE.USERSUBSCRIBED.equals(key.workqueueType)) {
      workQueueNameIDAndTaskCountDetailsList = supervisorWorkQueuesHooksObj.listUserSubscribedWorkQueues(
        userNameKey);

      workQueueDetailsList = listofWorkqueueDetails(
        workQueueNameIDAndTaskCountDetailsList);
    } else if (WORKQUEUETYPE.ORGOBJECTSUBSCRIBED.equals(key.workqueueType)) {
      workQueueNameIDAndTaskCountDetailsList = orgUnitSubscribedWorkQueuesFetcherObj.listOrgUnitSubscribedWorkQueues(
        userNameKey);
      workQueueDetailsList = listofWorkqueueDetails(
        workQueueNameIDAndTaskCountDetailsList);

    } else if (WORKQUEUETYPE.JOBSUBSCRIBED.equals(key.workqueueType)) {
      workQueueNameIDAndTaskCountDetailsList = jobSubscribedWorkQueuesFetcherObj.listJobSubscribedWorkQueues(
        userNameKey);
      workQueueDetailsList = listofWorkqueueDetails(
        workQueueNameIDAndTaskCountDetailsList);

    } else if (WORKQUEUETYPE.POSITIONSUBSCRIBED.equals(key.workqueueType)) {
      workQueueNameIDAndTaskCountDetailsList = positionSubscribedWorkQueuesFetcherObj.listPositionSubscribedWorkQueues(
        userNameKey);
      workQueueDetailsList = listofWorkqueueDetails(
        workQueueNameIDAndTaskCountDetailsList);

    }
    return workQueueDetailsList;
    // END, CR00451982
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of organization units that are managed by a supervisor.
   * The list contains the number of members in the organization unit and the
   * number of unreserved tasks assigned to it.
   *
   * @return Organization Unit details list
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrganisationUnitDetailsList readOrganisationUnitDetails()
    throws AppException, InformationalException {

    final OrganisationUnitDetailsList organisationUnitDetailsList = new OrganisationUnitDetailsList();

    final MaintainSupervisorOrgUnits maintainSupervisorOrgUnitsObj = MaintainSupervisorOrgUnitsFactory.newInstance();

    final SupervisorOrganisationUnitDetails supervisorOrganisationUnitDetails = maintainSupervisorOrgUnitsObj.listSupervisorOrgUnits();
    OrganisationUnitDetails organisationUnitDetails;

    for (int i = 0; i
      < supervisorOrganisationUnitDetails.orgUnitDetails.dtls.size(); i++) {
      organisationUnitDetails = new OrganisationUnitDetails();

      organisationUnitDetails.organisationUnitID = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgUnitID;
      organisationUnitDetails.organisationUnitName = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgUnitName;

      final MaintainSupervisorOrgUnits maintainSupervisorOrgUnitsSlObj = MaintainSupervisorOrgUnitsFactory.newInstance();

      final OrganisationUnitFullDetails organisationUnitFullDetails = new OrganisationUnitFullDetails();

      organisationUnitFullDetails.organisationUnitID = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgUnitID;
      organisationUnitFullDetails.organisationStructureID = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgStructureID;

      final OrgUnitMemberDetailsList orgUnitMemberDetailsList = maintainSupervisorOrgUnitsSlObj.getOrgUnitMemberList(
        organisationUnitFullDetails);

      // Add total members to list
      organisationUnitDetails.totalMembers = orgUnitMemberDetailsList.memberDetails.size();

      final OrgUnitTasksByUserSearchKey orgUnitTasksByUserSearchKey = new OrgUnitTasksByUserSearchKey();

      orgUnitTasksByUserSearchKey.key.organizationStructureID = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgStructureID;
      orgUnitTasksByUserSearchKey.key.organizationUnitID = supervisorOrganisationUnitDetails.orgUnitDetails.dtls.item(i).orgUnitID;

      final OrgUnitAssignedTasksByUserDueOnDateDetails assignedTasks = maintainSupervisorOrgUnitsSlObj.readOrgUnitAssignedTasks(
        orgUnitTasksByUserSearchKey);

      int totalTasks = 0;

      for (int j = 0; j < assignedTasks.taskDetails.dtls.size(); j++) {
        totalTasks = totalTasks
          + assignedTasks.taskDetails.dtls.item(j).taskAssignedCount;
      }

      // Add total unreserved task to list
      organisationUnitDetails.unreservedTasks = totalTasks;
      organisationUnitDetailsList.dtls.add(organisationUnitDetails);
    }

    return organisationUnitDetailsList;
  }

  /**
   * Reassigns all Cases with Issues for the Supervisor
   *
   * @param key -
   * ReassignCasesForUserKey
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void reassignCasesWithIssues(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintianSupervisorUsers = MaintainSupervisorUsersFactory.newInstance();

    maintianSupervisorUsers.reassignCasesForOrganisationObject(key);
  }

  /**
   * Retrieves the list of all Cases with Issues for the Supervisor based on the
   * Date Range.
   *
   * @param key -
   * CasesByDateRangeKey
   *
   * @return the CasesWithIssuesDtlsList object.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CasesWithIssuesDtlsList listCasesWithIssues(CasesByDateRangeKey key)
    throws AppException, InformationalException {

    final CasesWithIssuesDtlsList detailsList = new CasesWithIssuesDtlsList();

    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    SupervisorCasesWithIssuesDetailsList issueDetailsList = new SupervisorCasesWithIssuesDetailsList();
    final CasesBySupervisorIDAndDateRangeKey supervisorIDandDateKey = new CasesBySupervisorIDAndDateRangeKey();

    supervisorIDandDateKey.caseStatus = CASESTATUS.CLOSED;
    supervisorIDandDateKey.caseType = CASETYPECODE.ISSUE;
    supervisorIDandDateKey.issueStatus = CASESTATUS.OPEN;
    final curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();

    supervisorIDandDateKey.leadUserID = systemUser.getUserDetails().userName;
    supervisorIDandDateKey.registrationFromDate = key.registrationFromDate;
    supervisorIDandDateKey.registrationToDate = key.registrationToDate;
    supervisorIDandDateKey.status = RECORDSTATUS.CANCELLED;
    supervisorIDandDateKey.supervisorRole = CASEUSERROLETYPE.SUPERVISOR;
    supervisorIDandDateKey.supervisorUsername = systemUser.getUserDetails().userName;
    issueDetailsList = caseHeader.searchCasesWithIssuesBySupervisorAndDateRange(
      supervisorIDandDateKey);
    // Iterating through the list to get the value of owner based on the value
    // stored in organization object
    for (int i = 0; i < issueDetailsList.dtls.size(); i++) {
      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID = issueDetailsList.dtls.item(i).caseID;
      try {
        // Retrieves Product Type for a specified case ID
        final ProductDeliveryTypeDetails productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        issueDetailsList.dtls.item(i).productType = productDeliveryTypeDetails.productType;
      } catch (final RecordNotFoundException e) {
        // If the case is not a Product Delivery case then Exception is caught
        // and the value of product type for that case will be set to NULL.
        issueDetailsList.dtls.item(i).productType = "";
      }
      // If the type of organization object is organization unit the owner will
      // have the value organization unit name.
      if (ORGOBJECTTYPE.ORGUNIT.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner will have
      // the
      // value Position name.
      else if (ORGOBJECTTYPE.POSITION.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final Position posObj = PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = posObj.readPositionName(positionKey).name;
      } // If the type of organization object is WorkQueue the owner will have
      // the
      // value WorkQueue name.
      else if (ORGOBJECTTYPE.WORKQUEUE.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final WorkQueue wq = WorkQueueFactory.newInstance();
        final WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner will have the
      // value User name.
      else {
        final UserAccess userAccessObj = UserAccessFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = issueDetailsList.dtls.item(i).userName;
        issueDetailsList.dtls.item(i).owner = userAccessObj.getFullName(usersKey).fullname;
      }
    }

    detailsList.casesWithIssueDetails = issueDetailsList;

    return detailsList;
  }

  protected PriorityWeekCaseDtls calculatePriorityWeekDate(
    PriorityWeekCaseDtls priorityWeekCaseDtls) {

    final String priorityWeekStr = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_PRIORITYWEEK);

    int priorityWeek;

    try {
      priorityWeek = Integer.parseInt(priorityWeekStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      priorityWeek = EnvVars.ENV_SUPERVISOR_PRIORITYWEEK_DEFAULT;
    }

    final int checkDate = Date.getCurrentDate().getCalendar().get(
      java.util.Calendar.DAY_OF_WEEK);

    priorityWeekCaseDtls.endDate = Date.getCurrentDate();
    if (priorityWeekCaseDtls.startDate.isZero()) {
      if (checkDate == 1) {
        priorityWeekCaseDtls.startDate = Date.getCurrentDate();
      } else {
        priorityWeekCaseDtls.startDate = Date.getCurrentDate().addDays(
          1 - checkDate);
      }

      if (priorityWeek != EnvVars.ENV_SUPERVISOR_PRIORITYWEEK_DEFAULT) {
        priorityWeekCaseDtls.startDate = priorityWeekCaseDtls.startDate.addDays(
          priorityWeek * 7);
      }
    } else {
      priorityWeekCaseDtls.startDate = priorityWeekCaseDtls.startDate;
    }
    // finally set the end date of the priority week as well
    priorityWeekCaseDtls.endDate = priorityWeekCaseDtls.startDate.addDays(6);
    return priorityWeekCaseDtls;
  }

  /**
   * List of all Priority Week Cases with Issues for the Supervisor based on the
   * Date Range.
   *
   * @param key -
   * CasesWithIssuesByDateKey
   *
   * @return CasesWithIssuesUICDtlsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CasesWithIssuesUICDtlsList listPriorityWeekCasesWithIssues(
    CasesWithIssuesByDateKey key) throws AppException, InformationalException {

    // TBD check if this priority week date should be got from the UIM instead
    // of calculating as this page is called from the default page

    final CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    final CasesBySupervisorIDAndDateRangeKey supervisorIDandDateKey = new CasesBySupervisorIDAndDateRangeKey();

    final Date toDate = key.priorityDate.addDays(6);
    final curam.supervisor.sl.struct.Date[] dayList = new curam.supervisor.sl.struct.Date[7];
    final curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();

    // Loading values to the argument for the entity layer method
    supervisorIDandDateKey.caseStatus = CASESTATUS.CLOSED;
    supervisorIDandDateKey.caseType = CASETYPECODE.ISSUE;
    supervisorIDandDateKey.issueStatus = CASESTATUS.OPEN;
    supervisorIDandDateKey.leadUserID = systemUser.getUserDetails().userName;
    supervisorIDandDateKey.registrationFromDate = key.priorityDate;
    supervisorIDandDateKey.registrationToDate = toDate;
    supervisorIDandDateKey.status = RECORDSTATUS.CANCELLED;
    supervisorIDandDateKey.supervisorRole = CASEUSERROLETYPE.SUPERVISOR;
    supervisorIDandDateKey.supervisorUsername = systemUser.getUserDetails().userName;

    // Calling the entity layer to retrieve the List Data
    final SupervisorCasesWithIssuesDetailsList supervisorCasesWithIssuesDetailsList = caseHeader.searchCasesWithIssuesBySupervisorIDAndRegistrationDate(
      supervisorIDandDateKey);

    for (int j = 0; j < supervisorCasesWithIssuesDetailsList.dtls.size(); j++) {
      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID = supervisorCasesWithIssuesDetailsList.dtls.item(j).caseID;
      try {
        // Retrieves Product Type for a specified case ID
        final ProductDeliveryTypeDetails productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        supervisorCasesWithIssuesDetailsList.dtls.item(j).productType = productDeliveryTypeDetails.productType;
      } catch (final RecordNotFoundException e) {
        // If the case is not a Product Delivery case then Exception is caught
        // and the value of product type for that case will be set to NULL.
        supervisorCasesWithIssuesDetailsList.dtls.item(j).productType = "";
      }
    }
    casesWithIssuesUICDtlsList.casesWithIssuesDtlsList.casesWithIssueDetails = supervisorCasesWithIssuesDetailsList;

    // setting the priority, previous and next dates to be displayed
    casesWithIssuesUICDtlsList.dateDtls.priorityDates.startDate = key.priorityDate;
    casesWithIssuesUICDtlsList.dateDtls.priorityDates.endDate = toDate;
    casesWithIssuesUICDtlsList.dateDtls.previousDate = key.priorityDate.addDays(
      -7);
    casesWithIssuesUICDtlsList.dateDtls.nextDate = key.priorityDate.addDays(7);

    // setting values for the chooseDay drop down
    ChooseDayDetails chooseDayDetails;

    for (int i = 0; i < dayList.length; i++) {
      dayList[i] = new curam.supervisor.sl.struct.Date();
      dayList[i].date = key.priorityDate.addDays(i);
      chooseDayDetails = new ChooseDayDetails();
      chooseDayDetails.date = getStringValue(dayList[i]);
      chooseDayDetails.dateDesc = formatDateDesc(dayList[i]);
      casesWithIssuesUICDtlsList.chooseDayList.addRef(chooseDayDetails);
    }

    return casesWithIssuesUICDtlsList;
  }

  /**
   * Gets the User Application Code Details
   *
   * @return UserApplicationCodeDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public UserApplicationCodeDetails getUserAppCode() throws AppException,
      InformationalException {

    final UserApplicationCodeDetails userApplicationCodeDetails = new UserApplicationCodeDetails();

    curam.core.struct.UserApplicationCodeDetails userAppCodeDetails = new curam.core.struct.UserApplicationCodeDetails();

    // BEGIN CR00107117 ,GM
    final curam.core.intf.Users user = UsersFactory.newInstance();
    // END CR00107117

    final UserNameKey userKey = new UserNameKey();
    final curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();

    userKey.userName = systemUser.getUserDetails().userName;
    userAppCodeDetails = user.readUserAppCode(userKey);
    userApplicationCodeDetails.appCodeDtls = userAppCodeDetails;

    return userApplicationCodeDetails;
  }

  /**
   * Gets the formatted value for a Date
   *
   * @param date -
   * Date object
   * @return the String Date object.
   */
  // BEGIN, CR00198672, VK
  protected String formatDateDesc(curam.supervisor.sl.struct.Date date) {

    // END, CR00198672
    final int month = date.date.getCalendar().get(Calendar.MONTH) + 1;
    final int day = date.date.getCalendar().get(Calendar.DATE);
    final int year = date.date.getCalendar().get(Calendar.YEAR);
    final StringBuffer dateStringBuf = new StringBuffer();

    // BEGIN, CR00190772, CL
    final String dateSeparator = new LocalisableString(SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_DATE_SEPARATOR).getMessage(
      TransactionInfo.getProgramLocale());

    // BEGIN, CR00085608 SK
    dateStringBuf.append(month);
    dateStringBuf.append(dateSeparator);
    dateStringBuf.append(day);
    dateStringBuf.append(dateSeparator);
    dateStringBuf.append(year);
    // END, CR00190772
    // END, CR00085608 SK
    return dateStringBuf.toString();
  }

  /**
   * Gets the string value for a Date
   *
   * @param date -
   * Date object
   * @return the String Date object.
   */
  // BEGIN, CR00198672, VK
  protected String getStringValue(curam.supervisor.sl.struct.Date date) {

    // END, CR00198672
    final int month = date.date.getCalendar().get(Calendar.MONTH) + 1;
    final int day = date.date.getCalendar().get(Calendar.DATE);
    final int year = date.date.getCalendar().get(Calendar.YEAR);
    final StringBuffer dateStringBuf = new StringBuffer();

    dateStringBuf.append(year);
    if (month < 10) {
      dateStringBuf.append(0);
    }
    dateStringBuf.append(month);

    if (day < 10) {
      dateStringBuf.append(0);
    }
    dateStringBuf.append(day);

    return dateStringBuf.toString();
  }

  /**
   * This method gets details of Heat map XML, priority week details and Choose
   * list.
   *
   * @param key - Date
   * @return PriorityWeekCasesUICHeatmapDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public PriorityWeekCasesUICHeatmapDetails readSupervisorUICWorkSpaceDetails(curam.supervisor.sl.struct.Date key)
    throws AppException, InformationalException {

    final PriorityWeekCasesUICHeatmapDetails priorityWeekCasesUICHeatmapDetails = new PriorityWeekCasesUICHeatmapDetails();

    PriorityWeekCaseDtls priorityWeekCaseDtls = new PriorityWeekCaseDtls();

    if (!key.date.isZero()) {
      priorityWeekCaseDtls.startDate = key.date;
    }

    // Calculating start and end date based on Priority week if specified.
    priorityWeekCaseDtls = calculatePriorityWeekDate(priorityWeekCaseDtls);
    priorityWeekCasesUICHeatmapDetails.casesWithIssuesUICListDtls.dateDtls.priorityDates = priorityWeekCaseDtls;

    final CasesWithIssuesByDateKey date = new CasesWithIssuesByDateKey();

    date.priorityDate = priorityWeekCaseDtls.startDate;

    // Calling method to get the heat map, choose list details list.
    priorityWeekCasesUICHeatmapDetails.casesWithIssuesUICListDtls = listPriorityWeekCasesWithIssues(
      date);

    priorityWeekCasesUICHeatmapDetails.heatmapXMLString = constructChartForHeatmap(
      priorityWeekCasesUICHeatmapDetails.casesWithIssuesUICListDtls);

    return priorityWeekCasesUICHeatmapDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to fetch the configured properties for the legend array
   * which is required for heat map construction.
   *
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] getLegendArray() {

    // END, CR00198672
    String[] legendArray;
    // Fetch the lower limit
    int heatMapLowerLimit;
    final String heatMapLowerLimitStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_LOWERLIMIT);

    try {
      heatMapLowerLimit = Integer.parseInt(heatMapLowerLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapLowerLimit = EnvVars.ENV_SUPERVISOR_ISSUES_LOWERLIMIT_DEFAULT;
    }

    // Fetch the upper limit
    int heatMapUpperLimit;
    final String heatMapUpperLimitStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_UPPERLIMIT);

    try {
      heatMapUpperLimit = Integer.parseInt(heatMapUpperLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapUpperLimit = EnvVars.ENV_SUPERVISOR_ISSUES_UPPERLIMIT_DEFAULT;
    }

    // Fetch the variable interval
    String heatMapVariableInterval;

    try {
      heatMapVariableInterval = Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_ISSUES_VARIABLEINTERVAL);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapVariableInterval = EnvVars.ENV_SUPERVISOR_ISSUES_VARIABLEINTERVAL_DEFAULT;
    }

    // Fetch the constant interval
    int heatMapConstantInterval;
    final String heatMapConstantIntervalStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_CONSTANTINTERVAL);

    try {
      heatMapConstantInterval = Integer.parseInt(heatMapConstantIntervalStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapConstantInterval = EnvVars.ENV_SUPERVISOR_ISSUES_CONSTANTINTERVAL_DEFAULT;
    }

    // If Variable interval is not present only then use Constant interval
    if (heatMapVariableInterval.equals(CuramConst.gkDash)) {
      legendArray = constructLegArrWithConstantInterval(heatMapLowerLimit,
        heatMapUpperLimit, heatMapConstantInterval);
    } else {
      legendArray = constructLegArrWithVariableInterval(heatMapLowerLimit,
        heatMapVariableInterval);
    }

    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with constant interval
   * which is required for heat map construction.
   *
   * @param heatMapVariableInterval -
   * String
   * @param heatMapLowerLimit -
   * int
   * @param heatMapUpperLimit -
   * int
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] constructLegArrWithConstantInterval(int heatMapLowerLimit,
    int heatMapUpperLimit, int heatMapConstantInterval) {

    // END, CR00198672
    // Variables required to construct the array
    final BigDecimal bigDecimal = new BigDecimal(
      heatMapUpperLimit - heatMapLowerLimit);
    int range;

    range = bigDecimal.divide(new BigDecimal(heatMapConstantInterval), BigDecimal.ROUND_HALF_UP).intValue();

    String[] legendArray;

    legendArray = new String[range + 1];

    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + heatMapConstantInterval - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += heatMapConstantInterval;
    }

    // Creating hyphen separated legend Array
    legendArray[0] = legendArrayTemp[0] + CuramConst.gkDash
      + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] = legendArrayTemp[i] + 1 + CuramConst.gkDash
        + legendArrayTemp[i + 1];
    }
    legendArray[range] = SupervisorConst.kGreaterThanEqualTo
      + (legendArrayTemp[range] + 1);

    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with variable interval
   * which is required for heat map construction.
   *
   * @param heatMapLowerLimit -
   * int
   * @param heatMapVariableInterval -
   * String
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] constructLegArrWithVariableInterval(
    int heatMapLowerLimit, String heatMapVariableInterval) {

    // END, CR00198672
    // Variables required to construct the array
    int range;
    int[] intervalArr;

    // String Tokenizer is used to get the variable interval from the
    // heatMapVariableInterval String
    final StringTokenizer st = new StringTokenizer(heatMapVariableInterval,
      CuramConst.gkComma);

    range = st.countTokens();
    intervalArr = new int[range + 1];

    for (int i = 0; st.hasMoreTokens(); i++) {
      intervalArr[i] = Integer.parseInt(st.nextToken());
    }

    String[] legendArray;

    legendArray = new String[range + 1];
    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + intervalArr[0] - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += intervalArr[i];
    }

    // Creating hyphen separated legend Array
    legendArray[0] = legendArrayTemp[0] + CuramConst.gkDash
      + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] = legendArrayTemp[i] + 1 + CuramConst.gkDash
        + legendArrayTemp[i + 1];
    }
    legendArray[range] = SupervisorConst.kGreaterThanEqualTo
      + (legendArrayTemp[range] + 1);

    return legendArray;
  }

  /**
   * This method constructs Heat map XML string from Heat map details list.
   *
   * @param detailsList - CasesWithIssuesUICDtlsList
   *
   * @return String
   */
  // BEGIN, CR00198672, VK
  protected String constructChartForHeatmap(
    CasesWithIssuesUICDtlsList detailsList) {

    // END, CR00198672
    // Create Heat Map element and XML out putter

    final Element heatMapElement = new Element(kHeatMap);
    final XMLOutputter outputter = new XMLOutputter();

    final int detailsListSize = detailsList.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.size();
    int count = 0, j = 0;

    // Using the user defined Array
    final String[] arr = getLegendArray();

    // Looping through the Heat map legend array
    for (int i = arr.length; i > 0; i--) {

      final Element regionElement = new Element(kRegion);

      // BEGIN, CR00085608 SK
      regionElement.setAttribute(kRegionId,
        SupervisorConst.kRegionIdValue + (i - 1));
      // END, CR00085608 SK
      // BEGIN, CR00052924, GM
      regionElement.setAttribute(kLabel, arr[i - 1] + CuramConst.gkEmpty);
      // END, CR00052924

      try {
        // Condition to check for the first element of legend array
        if (i == arr.length) {
          // BEGIN, CR00052924, GM
          final String[] value = arr[i - 1].split(
            SupervisorConst.kGreaterThanEqualTo);
          // END, CR00052924
          final int startingRange = Integer.parseInt(value[1]);

          for (j = count; j < detailsListSize; j++) {

            final SupervisorCasesWithIssuesDetails issueDetails = detailsList.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.item(
              j);

            if (issueDetails.issueCount > startingRange) {

              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId, issueDetails.caseReference);

              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseID));
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);

              count++;
            }
          }
        } else {

          // Splitting the rest of array elements and looping it.
          // BEGIN, CR00052924, GM
          final String[] result = arr[i - 1].split(CuramConst.gkDash);
          // END, CR00052924
          final int startingRange = Integer.parseInt(result[0]);
          final int endingRange = Integer.parseInt(result[1]);

          for (j = count; j < detailsListSize; j++) {
            final SupervisorCasesWithIssuesDetails issueDetails = detailsList.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.item(
              j);

            // Breaking the loop if the issue count is greater than the range
            // given.
            if (issueDetails.issueCount > endingRange) {
              break;
            }

            // Condition to check for issue count within range and creating the
            // item elements for the same

            if (issueDetails.issueCount >= startingRange
              && issueDetails.issueCount <= endingRange) {
              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId, issueDetails.caseReference);

              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseID));
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);
              count++;
            }
          }
        }
      } catch (final NoSuchElementException e) {
        e.printStackTrace();
      }
      heatMapElement.addContent(regionElement);
    }
    return outputter.outputString(heatMapElement);
  }

  // BEGIN, CR00451982, MR

  /**
   * Retrieves the list of work queues that a supervisor's users are currently
   * subscribed to.
   *
   * @param workQueueNameIDAndTaskCountDetailsList
   * List of Work queue name and task count.
   * @return Work queue details list
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  protected WorkQueueDetailsList listofWorkqueueDetails(
    WorkQueueNameIDAndTaskCountDetailsList workQueueNameIDAndTaskCountDetailsList)
    throws AppException, InformationalException {

    WorkQueueDetails workQueueDetails;
    final WorkQueueKey workQueueKey = new WorkQueueKey();
    final WorkQueueSubscription workQueueSubscription = WorkQueueSubscriptionFactory.newInstance();
    final WorkQueueDetailsList workQueueDetailsList = new WorkQueueDetailsList();

    for (int i = 0; i < workQueueNameIDAndTaskCountDetailsList.dtls.size(); i++) {
      workQueueDetails = new WorkQueueDetails();

      workQueueDetails.workQueueID = workQueueNameIDAndTaskCountDetailsList.dtls.item(i).workQueueID;
      workQueueDetails.workQueueName = workQueueNameIDAndTaskCountDetailsList.dtls.item(i).workQueueName;
      workQueueDetails.unreservedTasks = workQueueNameIDAndTaskCountDetailsList.dtls.item(i).taskCount;

      // Get the number of members assigned to work queue

      workQueueKey.workQueueID = workQueueNameIDAndTaskCountDetailsList.dtls.item(i).workQueueID;

      workQueueDetails.totalMembers = workQueueSubscription.listUserSubscriptionsForWorkQueue(workQueueKey).dtls.size();

      workQueueDetailsList.dtls.add(workQueueDetails);
    }
    return workQueueDetailsList;

  }
  // END, CR00451982
}
