/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.supervisor.sl.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.ProductDelivery;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.CasesBySupervisorIDAndDateRangeKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.SupervisorCasesWithIssuesDetails;
import curam.core.struct.SupervisorCasesWithIssuesDetailsList;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORCASE;
import curam.supervisor.sl.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.sl.struct.CasesByDateRangeKey;
import curam.supervisor.sl.struct.CasesWithIssuesAndHeatMapDetails;
import curam.supervisor.sl.struct.CasesWithIssuesRecievedOnDate;
import curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList;
import curam.supervisor.sl.struct.ChooseDayDetails;
import curam.supervisor.sl.struct.ChosenDayDetails;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.struct.RegisteredDateOfCasesWithIssues;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.NotFoundIndicator;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Locale;
import java.util.StringTokenizer;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * Service layer class having API for operations related to cases having issues.
 */
public abstract class MaintainSupervisorCasesWithIssues extends curam.supervisor.sl.base.MaintainSupervisorCasesWithIssues {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kRegion = SupervisorConst.kRegion;

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kHeatMap = SupervisorConst.kHeatMap;

  /**
   * Identifier for holding the element type
   */
  protected static final String kRegionId = SupervisorConst.kRegionId;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = SupervisorConst.kCaption;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaseId = SupervisorConst.kCaseId;

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kLabel = SupervisorConst.kLabel;

  /**
   * Identifier for holding the element
   */
  protected static final String kItem = SupervisorConst.kItem;

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kItemId = SupervisorConst.kItemId;

  /**
   * Identifier for holding the array which contains the legend information
   */
  protected static final String[] kRegionArray = SupervisorConst.kRegionArray;

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode = SupervisorConst.kTaskOptionCode;

  // ___________________________________________________________________________
  /**
   * Service layer method for fetching the details of cases having issues on a
   * given week.
   *
   * @param key -
   * CasesByDateRangeKey
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by
   * {@link #listCasesWithIssue(CasesByDateRangeKey)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Override
  @Deprecated
  public CasesWithIssuesUICDtlsList listCaseWithIssueDetails(
    CasesByDateRangeKey key) throws AppException, InformationalException {

    // object creation
    final CasesWithIssuesUICDtlsList detailsList = new CasesWithIssuesUICDtlsList();
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    SupervisorCasesWithIssuesDetailsList issueDetailsList = new SupervisorCasesWithIssuesDetailsList();
    final CasesBySupervisorIDAndDateRangeKey supervisorIDandDateKey = new CasesBySupervisorIDAndDateRangeKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // Populate the start and end dates
    final CasesByDateRangeKey newDates = populateWeekStartAndEndDate(key);

    // assign values
    supervisorIDandDateKey.caseStatus = CASESTATUS.CLOSED;
    supervisorIDandDateKey.caseType = CASETYPECODE.ISSUE;
    supervisorIDandDateKey.issueStatus = CASESTATUS.OPEN;
    supervisorIDandDateKey.leadUserID = systemUser.getUserDetails().userName;
    supervisorIDandDateKey.registrationFromDate = newDates.registrationFromDate;
    supervisorIDandDateKey.registrationToDate = newDates.registrationToDate;
    supervisorIDandDateKey.status = RECORDSTATUS.CANCELLED;
    supervisorIDandDateKey.supervisorRole = CASEUSERROLETYPE.SUPERVISOR;
    supervisorIDandDateKey.supervisorUsername = systemUser.getUserDetails().userName;

    // get the issue details list
    issueDetailsList = caseHeader.searchCasesWithIssuesBySupervisorAndDateRange(
      supervisorIDandDateKey);

    // Iterating through the list to get the value of owner based on the value
    // stored in organization object
    for (int i = 0; i < issueDetailsList.dtls.size(); i++) {

      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID = issueDetailsList.dtls.item(i).caseID;

      try {
        // Retrieves Product Type for a specified case ID
        final ProductDeliveryTypeDetails productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        issueDetailsList.dtls.item(i).productType = productDeliveryTypeDetails.productType;

      } catch (final RecordNotFoundException e) {
        // If the case is not a Product Delivery case then Exception is caught
        // and the value of product type for that case will be set to NULL.
        issueDetailsList.dtls.item(i).productType = "";
      }

      // If the type of organization object is organization unit the owner will
      // have the value organization unit name.
      if (ORGOBJECTTYPE.ORGUNIT.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner will have
      // the
      // value Position name.
      else if (ORGOBJECTTYPE.POSITION.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final Position posObj = PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = posObj.readPositionName(positionKey).name;
      } // If the type of organization object is WorkQueue the owner will have
      // the
      // value WorkQueue name.
      else if (ORGOBJECTTYPE.WORKQUEUE.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final WorkQueue wq = WorkQueueFactory.newInstance();
        final WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner will have the
      // value User name.
      else {
        final UserAccess userAccessObj = UserAccessFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = issueDetailsList.dtls.item(i).userName;
        issueDetailsList.dtls.item(i).owner = userAccessObj.getFullName(usersKey).fullname;
      }
    }

    detailsList.casesWithIssuesDtlsList.casesWithIssueDetails = issueDetailsList;
    detailsList.dateDtls.priorityDates.startDate = newDates.registrationFromDate;
    detailsList.dateDtls.previousDate = newDates.registrationFromDate.addDays(
      -7);
    detailsList.dateDtls.nextDate = newDates.registrationFromDate.addDays(7);

    if (detailsList.dateDtls.nextDate.after(Date.getCurrentDate())) {
      detailsList.dateDtls.allowNext = false;
    } else {
      detailsList.dateDtls.allowNext = true;
    }

    // Setting values for the chooseDay drop down
    ChooseDayDetails chooseDayDetails;

    for (int i = 0; i < 7; i++) {
      final curam.supervisor.sl.struct.Date dayList = new curam.supervisor.sl.struct.Date();

      dayList.date = newDates.registrationFromDate.addDays(i);

      // Break the loop if the calculated date is greater than the current date.
      if (dayList.date.after(Date.getCurrentDate())) {
        break;
      }
      chooseDayDetails = new ChooseDayDetails();
      chooseDayDetails.date = getStringValue(dayList);
      chooseDayDetails.dateDesc = formatDateDesc(dayList);
      detailsList.chooseDayList.addRef(chooseDayDetails);
    }
    return detailsList;
  }

  // _____________________________________________________________________________
  // BEGIN, CR00294942, AKr
  /**
   * This method fetches the details of cases having issues, by date.
   *
   * @param key -
   * CasesWithIssuesRecievedOnDate
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by
   * {@link #listCasesWithIssueByDate(RegisteredDateOfCasesWithIssues)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Override
  @Deprecated
  // END, CR00294942
  public CasesWithIssuesUICDtlsList listCaseWithIssueDetailsByDate(
    CasesWithIssuesRecievedOnDate key) throws AppException,
      InformationalException {

    // object creation
    final CasesWithIssuesUICDtlsList detailsList = new CasesWithIssuesUICDtlsList();
    final CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    SupervisorCasesWithIssuesDetailsList issueDetailsList = new SupervisorCasesWithIssuesDetailsList();
    final CasesBySupervisorIDAndDateRangeKey supervisorIDandDateKey = new CasesBySupervisorIDAndDateRangeKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();
    String recievedOnDate = new String();

    if (key.recievedOnDate.length() == 0) {
      final curam.supervisor.sl.struct.Date issuesOnDate = new curam.supervisor.sl.struct.Date();

      issuesOnDate.date = key.dateField;
      recievedOnDate = getStringValue(issuesOnDate);
      key.recievedOnDate = recievedOnDate;
    } else {
      recievedOnDate = formatStringToReqDateType(key.recievedOnDate);
    }

    try {
      supervisorIDandDateKey.caseStatus = CASESTATUS.CLOSED;
      supervisorIDandDateKey.caseType = CASETYPECODE.ISSUE;
      supervisorIDandDateKey.issueStatus = CASESTATUS.OPEN;
      supervisorIDandDateKey.leadUserID = systemUser.getUserDetails().userName;
      supervisorIDandDateKey.registrationFromDate = Date.fromISO8601(
        recievedOnDate);
      supervisorIDandDateKey.registrationToDate = Date.fromISO8601(
        recievedOnDate);
      supervisorIDandDateKey.status = RECORDSTATUS.CANCELLED;
      supervisorIDandDateKey.supervisorRole = CASEUSERROLETYPE.SUPERVISOR;
      supervisorIDandDateKey.supervisorUsername = systemUser.getUserDetails().userName;
      issueDetailsList = caseHeader.searchCasesWithIssuesBySupervisorAndDateRange(
        supervisorIDandDateKey);
    } catch (final curam.util.exception.DateConversionException e) {
      throw new AppException(BPOSUPERVISORCASE.SUPERVISOR_CASE_ISSUE_DATE_EMPTY);
    }
    // Iterating through the list to get the value of owner based on the value
    // stored in organization object
    for (int i = 0; i < issueDetailsList.dtls.size(); i++) {

      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();

      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID = issueDetailsList.dtls.item(i).caseID;

      try {

        // Retrieves Product Type for a specified case ID
        final ProductDeliveryTypeDetails productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        issueDetailsList.dtls.item(i).productType = productDeliveryTypeDetails.productType;

      } catch (final RecordNotFoundException e) {

        // If the case is not a Product Delivery case then Exception is caught
        // and the value of product type for that case will be set to NULL.
        issueDetailsList.dtls.item(i).productType = "";
      }
      // If the type of organization object is organization unit the owner will
      // have the value organization unit name.
      if (ORGOBJECTTYPE.ORGUNIT.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner will have
      // the
      // value Position name.
      else if (ORGOBJECTTYPE.POSITION.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final Position posObj = PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = posObj.readPositionName(positionKey).name;
      } // If the type of organization object is WorkQueue the owner will have
      // the
      // value WorkQueue name.
      else if (ORGOBJECTTYPE.WORKQUEUE.equals(
        issueDetailsList.dtls.item(i).orgObjectType)) {
        final WorkQueue wq = WorkQueueFactory.newInstance();
        final WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = issueDetailsList.dtls.item(i).orgObjectReference;
        issueDetailsList.dtls.item(i).owner = wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner will have the
      // value User name.
      else {
        final UserAccess userAccessObj = UserAccessFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = issueDetailsList.dtls.item(i).userName;
        issueDetailsList.dtls.item(i).owner = userAccessObj.getFullName(usersKey).fullname;
      }
    }
    detailsList.casesWithIssuesDtlsList.casesWithIssueDetails = issueDetailsList;
    detailsList.dateDtls.priorityDates.startDate = Date.fromISO8601(
      recievedOnDate);
    detailsList.dateDtls.previousDate = Date.fromISO8601(recievedOnDate).addDays(
      -1);
    detailsList.dateDtls.nextDate = Date.fromISO8601(recievedOnDate).addDays(1);
    // Case Received Date is current date.
    if (detailsList.dateDtls.nextDate.after(Date.getCurrentDate())) {
      detailsList.dateDtls.allowNext = false;
    } else {
      detailsList.dateDtls.allowNext = true;
    }
    return detailsList;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00294942, AKr
  /**
   * This method is used to construct heat map XML from the details of cases
   * with issues list.
   *
   * @param key -
   * CasesWithIssuesRecievedOnDate
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by
   * {@link #readCasesWithIssuesForHeatMap(CasesWithIssuesUICDtlsList)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Override
  @Deprecated
  // END, CR00294942
  public CasesWithIssuesUICDtlsList readCaseWithIssueDetailsByDateForHeatMap(
    CasesWithIssuesRecievedOnDate key) throws AppException,
      InformationalException {

    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();

    casesWithIssuesUICDtlsList = listCaseWithIssueDetailsByDate(key);

    casesWithIssuesUICDtlsList.casesWithIssuesDtlsList.heatMapXMLString = constructHeatMap(
      casesWithIssuesUICDtlsList);

    return casesWithIssuesUICDtlsList;
  }

  // ______________________________________________________________________________

  /**
   * Service layer method for reassigning cases with issues
   *
   *
   * @param key -
   * ReassignCasesForUserKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void reassignCasesWithIssues(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintianSupervisorUsers = MaintainSupervisorUsersFactory.newInstance();

    maintianSupervisorUsers.reassignCasesForOrganisationObject(key);
  }

  // ___________________________________________________________________________
  // BEGIN, CR00294942, AKr
  /**
   * This method is used to construct heat map from the details of cases with
   * issues.
   *
   * @param key -
   * CasesByDateRangeKey
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by
   * {@link #readCasesWithIssuesForHeatMap(CasesWithIssuesUICDtlsList)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Override
  // END, CR00294942
  @Deprecated
  public CasesWithIssuesUICDtlsList readCaseWithIssueDetailsForHeatMap(
    CasesByDateRangeKey key) throws AppException, InformationalException {

    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();

    casesWithIssuesUICDtlsList = listCaseWithIssueDetails(key);

    casesWithIssuesUICDtlsList.casesWithIssuesDtlsList.heatMapXMLString = constructHeatMap(
      casesWithIssuesUICDtlsList);

    return casesWithIssuesUICDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to fetch the configured properties for the legend array
   * which is required for heat map construction.
   *
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] getLegendArray() {

    // END, CR00198672
    String[] legendArray;
    // Fetch the lower limit
    int heatMapLowerLimit;
    final String heatMapLowerLimitStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_LOWERLIMIT);

    try {
      heatMapLowerLimit = Integer.parseInt(heatMapLowerLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapLowerLimit = EnvVars.ENV_SUPERVISOR_ISSUES_LOWERLIMIT_DEFAULT;
    }

    // Fetch the upper limit
    int heatMapUpperLimit;
    final String heatMapUpperLimitStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_UPPERLIMIT);

    try {
      heatMapUpperLimit = Integer.parseInt(heatMapUpperLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapUpperLimit = EnvVars.ENV_SUPERVISOR_ISSUES_UPPERLIMIT_DEFAULT;
    }

    // Fetch the variable interval
    String heatMapVariableInterval;

    try {
      heatMapVariableInterval = Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_ISSUES_VARIABLEINTERVAL);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapVariableInterval = EnvVars.ENV_SUPERVISOR_ISSUES_VARIABLEINTERVAL_DEFAULT;
    }

    // Fetch the constant interval
    int heatMapConstantInterval;
    final String heatMapConstantIntervalStr = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_ISSUES_CONSTANTINTERVAL);

    try {
      heatMapConstantInterval = Integer.parseInt(heatMapConstantIntervalStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapConstantInterval = EnvVars.ENV_SUPERVISOR_ISSUES_CONSTANTINTERVAL_DEFAULT;
    }

    // If Variable interval is not present only then use Constant interval
    if (heatMapVariableInterval.equals(CuramConst.gkDash)) {
      legendArray = constructLegArrWithConstantInterval(heatMapLowerLimit,
        heatMapUpperLimit, heatMapConstantInterval);
    } else {
      legendArray = constructLegArrWithVariableInterval(heatMapLowerLimit,
        heatMapVariableInterval);
    }

    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with constant interval
   * which is required for heat map construction.
   *
   * @param heatMapVariableInterval -
   * String
   * @param heatMapLowerLimit -
   * int
   * @param heatMapUpperLimit -
   * int
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] constructLegArrWithConstantInterval(int heatMapLowerLimit,
    int heatMapUpperLimit, int heatMapConstantInterval) {

    // END, CR00198672
    // Variables required to construct the array
    final BigDecimal bigDecimal = new BigDecimal(
      heatMapUpperLimit - heatMapLowerLimit);
    int range;

    range = bigDecimal.divide(new BigDecimal(heatMapConstantInterval), BigDecimal.ROUND_HALF_UP).intValue();

    String[] legendArray;

    legendArray = new String[range + 1];

    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + heatMapConstantInterval - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += heatMapConstantInterval;
    }

    // Creating hyphen separated legend Array
    legendArray[0] = legendArrayTemp[0] + CuramConst.gkDash
      + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] = legendArrayTemp[i] + 1 + CuramConst.gkDash
        + legendArrayTemp[i + 1];
    }
    legendArray[range] = SupervisorConst.kGreaterThanEqualTo
      + (legendArrayTemp[range] + 1);

    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with variable interval
   * which is required for heat map construction.
   *
   * @param heatMapLowerLimit -
   * int
   * @param heatMapVariableInterval -
   * String
   * @return String[]
   */
  // BEGIN, CR00198672, VK
  protected String[] constructLegArrWithVariableInterval(
    int heatMapLowerLimit, String heatMapVariableInterval) {

    // END, CR00198672
    // Variables required to construct the array
    int range;
    int[] intervalArr;

    // String Tokenizer is used to get the variable interval from the
    // heatMapVariableInterval String
    final StringTokenizer st = new StringTokenizer(heatMapVariableInterval,
      CuramConst.gkComma);

    range = st.countTokens();
    intervalArr = new int[range + 1];

    for (int i = 0; st.hasMoreTokens(); i++) {
      intervalArr[i] = Integer.parseInt(st.nextToken());
    }

    String[] legendArray;

    legendArray = new String[range + 1];
    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + intervalArr[0] - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += intervalArr[i];
    }

    // Creating hyphen separated legend Array
    legendArray[0] = legendArrayTemp[0] + CuramConst.gkDash
      + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] = legendArrayTemp[i] + 1 + CuramConst.gkDash
        + legendArrayTemp[i + 1];
    }
    legendArray[range] = SupervisorConst.kGreaterThanEqualTo
      + (legendArrayTemp[range] + 1);

    return legendArray;
  }

  // _____________________________________________________________________________
  /**
   * This method constructs the heat map string.
   *
   * @param listDetails -
   * CasesWithIssuesUICDtlsList
   * @return String - of HeatMap xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructHeatMap(CasesWithIssuesUICDtlsList listDetails) {

    // END, CR00198672
    // object creation
    final Element heatMapElement = new Element(kHeatMap);
    final XMLOutputter outputter = new XMLOutputter();

    // Get the size of the list to be displayed
    final int listSize = listDetails.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.size();

    int j = 0, count = 0;

    // Using the user defined Array
    final String[] arr = getLegendArray();

    for (int i = arr.length; i > 0; i--) {
      // Creating the legend regions
      final Element regionElement = new Element(kRegion);

      // BEGIN, CR00085608 SK
      regionElement.setAttribute(kRegionId,
        SupervisorConst.kRegionIdValue + (i - 1));
      // END, CR00085608 SK
      regionElement.setAttribute(kLabel, arr[i - 1] + CuramConst.gkEmpty);

      try {
        // Only for the 1st region array element
        if (i == arr.length) {
          for (j = count; j < listSize; j++) {
            final SupervisorCasesWithIssuesDetails issueDetails = listDetails.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.item(
              j);
            final String[] legendArr1 = arr[i - 1].split(
              SupervisorConst.kGreaterThanEqualTo);
            final int startingRange = Integer.parseInt(legendArr1[1]);

            if (issueDetails.issueCount > startingRange) {
              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId, issueDetails.caseReference);
              // The item is added in the region
              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseID));
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);
              count++;
            }
          }
        } else {

          final String[] legendArr2 = arr[i - 1].split(CuramConst.gkDash);
          final int startingRange = Integer.parseInt(legendArr2[0]);
          int endingRange;

          if (legendArr2[1] == null || legendArr2[1].equals(CuramConst.gkEmpty)) {
            endingRange = 0;
          } else {
            endingRange = Integer.parseInt(legendArr2[1]);
          }

          for (j = count; j < listSize; j++) {
            final SupervisorCasesWithIssuesDetails issueDetails = listDetails.casesWithIssuesDtlsList.casesWithIssueDetails.dtls.item(
              j);

            if (issueDetails.issueCount >= startingRange
              && issueDetails.issueCount <= endingRange) {
              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId, issueDetails.caseReference);
              // The item is added in the region
              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseID));
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);

            }
          }
        }
      } catch (final Exception e) {//
      }
      heatMapElement.addContent(regionElement);
    }

    if (heatMapElement.getChildren().isEmpty()) {
      return CuramConst.gkEmpty;
    } else {
      return outputter.outputString(heatMapElement);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method will return date with format 'mm/dd/yyyy'
   *
   * @param date -
   * Date
   * @return String - Date String
   */
  // BEGIN, CR00198672, VK
  protected String formatDateDesc(curam.supervisor.sl.struct.Date date) {

    // END, CR00198672
    // BEGIN, CR00190772, CL
    // Get the date separator for the current locale
    final String dateSeparator = new curam.util.exception.LocalisableString(curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_DATE_SEPARATOR).getMessage(
      TransactionInfo.getProgramLocale());

    final int month = date.date.getCalendar().get(Calendar.MONTH) + 1;
    final int day = date.date.getCalendar().get(Calendar.DATE);
    final int year = date.date.getCalendar().get(Calendar.YEAR);
    final StringBuffer dateStringBuf = new StringBuffer();

    // BEGIN, CR00085608 SK
    dateStringBuf.append(month);
    dateStringBuf.append(dateSeparator);
    dateStringBuf.append(day);
    dateStringBuf.append(dateSeparator);
    dateStringBuf.append(year);
    // END, CR00085608 SK
    // END, CR00190772
    return dateStringBuf.toString();
  }

  // ______________________________________________________________________________
  /**
   * The method will return date with format 'yyyymmdd'
   *
   * @param date -
   * Date
   * @return String - Date String
   */
  // BEGIN, CR00198672, VK
  protected String getStringValue(curam.supervisor.sl.struct.Date date) {

    // END, CR00198672
    final int month = date.date.getCalendar().get(Calendar.MONTH) + 1;
    final int day = date.date.getCalendar().get(Calendar.DATE);
    final int year = date.date.getCalendar().get(Calendar.YEAR);
    final StringBuffer dateStringBuf = new StringBuffer();

    dateStringBuf.append(year);
    if (month < 10) {
      dateStringBuf.append(0);
    }
    dateStringBuf.append(month);
    if (day < 10) {
      dateStringBuf.append(0);
    }
    dateStringBuf.append(day);

    return dateStringBuf.toString();
  }

  // ______________________________________________________________________________
  /**
   * The method will parse the date format 'yyyy/mm/dd to with format
   * 'yyyy/dd/mm'
   *
   * @param recievedDate -
   * String
   * @return String - Date String
   */
  // BEGIN, CR00198672, VK
  protected String formatStringToReqDateType(String recievedDate) {

    // END, CR00198672
    // BEGIN, CR00190772, CL
    // BEGIN, CR00085608 SK
    final StringTokenizer st = new StringTokenizer(recievedDate,
      new curam.util.exception.LocalisableString(curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_DATE_SEPARATOR).getMessage(
      TransactionInfo.getProgramLocale()));

    // END, CR00190772

    // END, CR00085608 SK
    if (st.countTokens() == 1) {
      return recievedDate;
    }

    final StringBuffer buf = new StringBuffer();
    final String[] dateArray = new String[3];

    for (int i = 0; st.hasMoreTokens(); i++) {
      dateArray[i] = st.nextToken();
    }
    final String year = dateArray[2];
    String month = dateArray[1];

    if (month.length() == 1) {
      month = CuramConst.gkStringZero + month;
    }
    String date = dateArray[0];

    if (date.length() == 1) {
      date = CuramConst.gkStringZero + date;
    }
    buf.append(year);
    buf.append(date);
    buf.append(month);

    return buf.toString();
  }

  // ___________________________________________________________________________
  /**
   * Utility method for populating start and end dates of a week
   *
   *
   * @param key -
   * CasesByDateRangeKey
   * @return CasesByDateRangeKey
   */
  // BEGIN, CR00198672, VK
  protected CasesByDateRangeKey populateWeekStartAndEndDate(
    CasesByDateRangeKey key) {

    // END, CR00198672

    final CasesByDateRangeKey newDates = new CasesByDateRangeKey();

    // BEGIN, CR00191423, NP
    // Get current locale and extract the first 2 letters
    final String currentLocale = TransactionInfo.getProgramLocale();
    String shortLocale = currentLocale;

    if (currentLocale.length() > 2) {
      shortLocale = currentLocale.substring(0, 2);
    }

    final int startDayOfWeek = new java.util.GregorianCalendar(new Locale(shortLocale)).getFirstDayOfWeek();

    if (key.registrationFromDate.isZero() && key.registrationToDate.isZero()) {
      final int checkDate = Date.getCurrentDate().getCalendar().get(
        java.util.Calendar.DAY_OF_WEEK);

      if (checkDate < startDayOfWeek) {
        newDates.registrationFromDate = Date.getCurrentDate().addDays(-6);
        newDates.registrationToDate = Date.getCurrentDate();
      } else if (checkDate == startDayOfWeek) {

        newDates.registrationFromDate = Date.getCurrentDate();
        newDates.registrationToDate = newDates.registrationFromDate.addDays(6);
      } else {
        newDates.registrationFromDate = Date.getCurrentDate().addDays(
          startDayOfWeek - checkDate);
        newDates.registrationToDate = newDates.registrationFromDate.addDays(6);
      }
    } else {
      // if the day is Saturday we add startDayOfWeek value (1 for Sunday / 2
      // for Monday) to start
      // from Sunday or Monday depending on Locale when <<next week>> is clicked
      if (key.registrationFromDate.getCalendar().get(
        java.util.Calendar.DAY_OF_WEEK)
          == 7) {
        newDates.registrationFromDate = key.registrationFromDate.addDays(
          startDayOfWeek);
        // END, CR00191423
      } else {
        newDates.registrationFromDate = key.registrationFromDate;
      }
      newDates.registrationToDate = newDates.registrationFromDate.addDays(6);
    }
    if (newDates.registrationToDate.after(Date.getCurrentDate())) {
      newDates.registrationToDate = Date.getCurrentDate();
    }
    return newDates;
  }

  // BEGIN, CR00294942, AKr
  /**
   * Reads the details of cases with issues owned by the users reporting
   * to the current user based on the date range passed in.
   *
   * @param key
   * The date range to search the cases by their registration date.
   *
   * @return CasesWithIssuesAndHeatMapDetails
   * The details of the cases with issues
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  @Override
  public CasesWithIssuesAndHeatMapDetails listCasesWithIssuesByDate(
    final RegisteredDateOfCasesWithIssues registeredDateOfCasesWithIssues)
    throws AppException, InformationalException {

    Date receivedOnDate;

    if (registeredDateOfCasesWithIssues.chosenDate.isZero()) {
      receivedOnDate = registeredDateOfCasesWithIssues.currentDate;
    } else {
      receivedOnDate = registeredDateOfCasesWithIssues.chosenDate;
    }
    final DateRange dateRange = new DateRange(receivedOnDate, receivedOnDate);
    final int dateInterval = CuramConst.gkOne;
    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = searchCasesWithIssuesByDateRange(
      dateRange, dateInterval);

    return casesWithIssuesAndHeatMapDetails;
  }

  /**
   * Reads the details of cases with issues owned by the users reporting
   * to the current user.
   *
   * @param key
   * The date range to search the cases by their registration date.
   *
   * @return CasesWithIssuesAndHeatMapDetails
   * The details of the cases with issues
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  @Override
  public CasesWithIssuesAndHeatMapDetails listCasesWithIssues(
    final CasesByDateRangeKey casesByDateRangeKey) throws AppException,
      InformationalException {

    final CasesByDateRangeKey currentWeekDateRange = populateWeekStartAndEndDate(
      casesByDateRangeKey);

    final DateRange dateRange = new DateRange(
      currentWeekDateRange.registrationFromDate,
      currentWeekDateRange.registrationToDate);
    final int dateInterval = CuramConst.gkNumberOfDaysInAWeek;

    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = searchCasesWithIssuesByDateRange(
      dateRange, dateInterval);
    // Setting values for the chooseDay drop down
    ChosenDayDetails chosenDayDetails;

    for (int i = 0; i < CuramConst.gkNumberOfDaysInAWeek; i++) {
      final curam.supervisor.sl.struct.Date date = new curam.supervisor.sl.struct.Date();

      date.date = currentWeekDateRange.registrationFromDate.addDays(i);

      if (date.date.after(Date.getCurrentDate())) {
        break;
      }
      chosenDayDetails = new ChosenDayDetails();
      chosenDayDetails.date = date.date;
      chosenDayDetails.dateDescription = formatDateDesc(date);
      casesWithIssuesAndHeatMapDetails.chosenDayDetails.addRef(chosenDayDetails);
    }
    return casesWithIssuesAndHeatMapDetails;
  }

  /**
   * Constructs the heat map with the list of cases and their details.
   *
   * @param casesWithIssuesUICDtlsList
   * The details of the list of cases with issues.
   *
   * @return String The constructed heat map XML String.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  @Override
  public String readCasesWithIssuesForHeatMap(
    final CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList)
    throws AppException, InformationalException {

    return constructHeatMap(casesWithIssuesUICDtlsList);
  }

  /**
   * Searches for the cases with issues owned by the users reporting to the
   * current user.
   *
   * @param dateRange
   * The date range to search the cases by their registration date.
   *
   * @return SupervisorCasesWithIssuesDetailsList
   * The list of cases owned by the users reporting to the current user.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  protected CasesWithIssuesAndHeatMapDetails searchCasesWithIssuesByDateRange(final DateRange dateRange,
    final int interval) throws AppException, InformationalException {

    final String username = SystemUserFactory.newInstance().getUserDetails().userName;
    final CasesBySupervisorIDAndDateRangeKey casesBySupervisorIDAndDateRangeKey = new CasesBySupervisorIDAndDateRangeKey();

    casesBySupervisorIDAndDateRangeKey.caseStatus = CASESTATUS.CLOSED;
    casesBySupervisorIDAndDateRangeKey.caseType = CASETYPECODE.ISSUE;
    casesBySupervisorIDAndDateRangeKey.issueStatus = CASESTATUS.OPEN;
    casesBySupervisorIDAndDateRangeKey.leadUserID = username;
    casesBySupervisorIDAndDateRangeKey.registrationFromDate = dateRange.start();
    casesBySupervisorIDAndDateRangeKey.registrationToDate = dateRange.end();
    casesBySupervisorIDAndDateRangeKey.status = RECORDSTATUS.CANCELLED;
    casesBySupervisorIDAndDateRangeKey.supervisorRole = CASEUSERROLETYPE.SUPERVISOR;
    casesBySupervisorIDAndDateRangeKey.supervisorUsername = username;

    final SupervisorCasesWithIssuesDetailsList supervisorCasesWithIssuesDetailsList = CaseHeaderFactory.newInstance().searchCasesWithIssuesBySupervisorAndDateRange(
      casesBySupervisorIDAndDateRangeKey);

    for (final SupervisorCasesWithIssuesDetails supervisorCasesWithIssuesDetails : supervisorCasesWithIssuesDetailsList.dtls) {

      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      final NotFoundIndicator nfIndicator = new NotFoundIndicator();

      productDeliveryKey.caseID = supervisorCasesWithIssuesDetails.caseID;
      final ProductDeliveryTypeDetails productDeliveryTypeDetails = ProductDeliveryFactory.newInstance().readProductType(
        nfIndicator, productDeliveryKey);

      if (!nfIndicator.isNotFound()) {
        supervisorCasesWithIssuesDetails.productType = productDeliveryTypeDetails.productType;
      }

      if (ORGOBJECTTYPE.ORGUNIT.equals(
        supervisorCasesWithIssuesDetails.orgObjectType)) {

        final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = supervisorCasesWithIssuesDetails.orgObjectReference;
        supervisorCasesWithIssuesDetails.owner = OrganisationUnitFactory.newInstance().readOrgUnitName(organisationUnitKey).name;

      } else if (ORGOBJECTTYPE.POSITION.equals(
        supervisorCasesWithIssuesDetails.orgObjectType)) {

        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = supervisorCasesWithIssuesDetails.orgObjectReference;
        supervisorCasesWithIssuesDetails.owner = PositionFactory.newInstance().readPositionName(positionKey).name;

      } else if (ORGOBJECTTYPE.WORKQUEUE.equals(
        supervisorCasesWithIssuesDetails.orgObjectType)) {

        final WorkQueueKey workQueueKey = new WorkQueueKey();

        workQueueKey.workQueueID = supervisorCasesWithIssuesDetails.orgObjectReference;
        supervisorCasesWithIssuesDetails.owner = WorkQueueFactory.newInstance().readWorkQueueName(workQueueKey).name;

      } else {

        final UsersKey usersKey = new UsersKey();

        usersKey.userName = supervisorCasesWithIssuesDetails.userName;
        supervisorCasesWithIssuesDetails.owner = UserAccessFactory.newInstance().getFullName(usersKey).fullname;
      }
    }
    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = new CasesWithIssuesAndHeatMapDetails();

    casesWithIssuesAndHeatMapDetails.casesListAndHeatMap.casesWithIssueDetails = supervisorCasesWithIssuesDetailsList;

    casesWithIssuesAndHeatMapDetails.caseDateDetails.priorityDates.startDate = dateRange.start();
    casesWithIssuesAndHeatMapDetails.caseDateDetails.previousDate = dateRange.start().addDays(
      -interval);
    casesWithIssuesAndHeatMapDetails.caseDateDetails.nextDate = dateRange.start().addDays(
      interval);

    if (!casesWithIssuesAndHeatMapDetails.caseDateDetails.nextDate.after(
      Date.getCurrentDate())) {
      casesWithIssuesAndHeatMapDetails.caseDateDetails.allowNext = true;
    }
    return casesWithIssuesAndHeatMapDetails;
  }
  // END, CR00294942
}
