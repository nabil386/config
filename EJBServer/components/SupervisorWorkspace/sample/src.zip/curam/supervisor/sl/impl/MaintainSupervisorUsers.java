/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006,2021 Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.supervisor.sl.impl;

import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.BATCHPROCESSNAME;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REDIRECTIONTARGETITEMTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.codetable.WQSUBSORGOBJECTTYPE;
import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseSearchRouterFactory;
import curam.core.fact.DatabaseCaseSearchFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.GenericBatchProcessInputFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.UsersFactory;
import curam.core.hook.task.impl.SearchTaskUtilities;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.EmailAddress;
import curam.core.intf.GenericBatchProcessInput;
import curam.core.intf.Organisation;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.fact.JobFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.ExternalUser;
import curam.core.sl.entity.intf.Job;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.intf.WorkQueueSubscription;
import curam.core.sl.entity.struct.AssessmentTypeDetails;
import curam.core.sl.entity.struct.CountDetails;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserNameDetails;
import curam.core.sl.entity.struct.InvestigationTypeCode;
import curam.core.sl.entity.struct.IssueTypeCode;
import curam.core.sl.entity.struct.JobKey;
import curam.core.sl.entity.struct.JobName;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.PositionName;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetails;
import curam.core.sl.entity.struct.TaskRedirectionOrAllocationBlockingPeriodDetails;
import curam.core.sl.entity.struct.UserNameAndDateTimeKey;
import curam.core.sl.entity.struct.UserNameSubscriberAndWorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueNameDetails;
import curam.core.sl.entity.struct.WorkQueueSensitivityAndAllowUserSubscriptionDetails;
import curam.core.sl.entity.struct.WorkQueueSubscriptionDtls;
import curam.core.sl.fact.BulkCaseReassignmentProcessFactory;
import curam.core.sl.fact.BulkTaskForwardProcessFactory;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.TaskSortByPriority;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.BulkCaseReassignmentProcess;
import curam.core.sl.intf.BulkTaskForwardProcess;
import curam.core.sl.intf.Inbox;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.AssignedTaskDetails;
import curam.core.sl.struct.BulkAssignedTaskForwardInputKey;
import curam.core.sl.struct.BulkCaseReassignmentInputKey;
import curam.core.sl.struct.BulkTaskForwardInputKey;
import curam.core.sl.struct.ClearTaskRedirectionDetails;
import curam.core.sl.struct.DeferredTaskDetails;
import curam.core.sl.struct.ListTaskKey;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.ReallocateTaskDetails;
import curam.core.sl.struct.ReserveNextTaskDetails;
import curam.core.sl.struct.ReserveNextWorkQueueTaskKey;
import curam.core.sl.struct.ReserveTaskDetails;
import curam.core.sl.struct.ReservedByStatusTaskDetails;
import curam.core.sl.struct.ReservedByStatusTaskDetailsList;
import curam.core.sl.struct.SQLStatement;
import curam.core.sl.struct.SubscribeUserToWorkQueueKey;
import curam.core.sl.struct.TaskAllocationBlockingCreateDetails;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.TaskRedirectionsForUserDetails;
import curam.core.sl.struct.UserNameAndStatusKey;
import curam.core.sl.struct.WorkQueueSubscriptionDetails;
import curam.core.sl.supervisor.fact.TaskManagementFactory;
import curam.core.sl.supervisor.fact.UserWorkspaceFactory;
import curam.core.sl.supervisor.intf.TaskManagement;
import curam.core.sl.supervisor.intf.UserWorkspace;
import curam.core.sl.supervisor.struct.ActiveAndPendingTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.ExpiredTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.RedirectTaskDetails;
import curam.core.sl.supervisor.struct.TaskAllocationBlockingDetails;
import curam.core.sl.supervisor.struct.TaskRedirectionsFromUserDetails;
import curam.core.sl.supervisor.struct.UserSubscriptionToWorkQueueDetails;
import curam.core.sl.supervisor.struct.UserTasksDueInTheNextMonthKey;
import curam.core.sl.supervisor.struct.UserTasksDueInTheNextTimePeriodDetails;
import curam.core.sl.supervisor.struct.UserTasksDueInTheNextTimePeriodDetailsList;
import curam.core.sl.supervisor.struct.UserTasksDueInTheNextWeekKey;
import curam.core.sl.supervisor.struct.UserWorkQueueDetailsList;
import curam.core.struct.BatchQueuedTaskID;
import curam.core.struct.BatchQueuedTaskIDList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseReferenceTypeProductRolePriClientDateAndStatus;
import curam.core.struct.CaseReferenceTypeProductRolePriClientDateAndStatusList;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.DatabaseCaseSearchKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.GetPhoneNumberKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.OrgObjTypeNameAndCaseStatusKey;
import curam.core.struct.PhoneNumberDetails;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.SearchBySupervisorOrgUnit;
import curam.core.struct.SupervisorUserTabKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserOrgStructStatusCodeKey;
import curam.core.struct.UserStatusAndOrgObjectKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOCASESEARCH;
import curam.message.BPOINBOX;
import curam.message.BPOSUPERVISORUSER;
import curam.message.BPOTASKMANAGEMENT;
import curam.message.BPOWORKQUEUESUBSCRIPTION;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.supervisor.facade.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.facade.struct.AllTaskAllocationBlockingPeriodsForUserDetailsList;
import curam.supervisor.facade.struct.SupervisorUserTabDetails;
import curam.supervisor.sl.fact.DatabaseSupervisorWorkspaceTaskSearchFactory;
import curam.supervisor.sl.fact.MaintainSupervisorOrgUnitsFactory;
import curam.supervisor.sl.struct.ListDeferredTasksReservedByUserDetails;
import curam.supervisor.sl.struct.ListDeferredTasksReservedByUserKey;
import curam.supervisor.sl.struct.ListOpenTasksReservedByUserDetails;
import curam.supervisor.sl.struct.ListOpenTasksReservedByUserKey;
import curam.supervisor.sl.struct.ListUnreservedTasksForUserDetails;
import curam.supervisor.sl.struct.ListUnreservedTasksForUserKey;
import curam.supervisor.sl.struct.ListUserWorkQueueDetails;
import curam.supervisor.sl.struct.ListUserWorkQueueDetailsKey;
import curam.supervisor.sl.struct.ReallocateTaskIDDetails;
import curam.supervisor.sl.struct.ReallocateTasksReservedByUserKey;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.struct.ReassignCasesForUserSearchKey;
import curam.supervisor.sl.struct.ReserveAssignedTasksDetails;
import curam.supervisor.sl.struct.ReserveAssignedTasksToUser;
import curam.supervisor.sl.struct.ReserveWorkQueueTasksForUserDetails;
import curam.supervisor.sl.struct.SubscribeUserWorkQueueKey;
import curam.supervisor.sl.struct.SupervisorDetails;
import curam.supervisor.sl.struct.SupervisorOrganisationUnitDetails;
import curam.supervisor.sl.struct.SupervisorTaskForwardDetails;
import curam.supervisor.sl.struct.SupervisorTaskFwdDetails;
import curam.supervisor.sl.struct.SupervisorUserCaseDetails;
import curam.supervisor.sl.struct.SupervisorUserDetails;
import curam.supervisor.sl.struct.SupervisorUserWithTaskCountDetailsList;
import curam.supervisor.sl.struct.SupervisorUserWorkspaceContentDetails;
import curam.supervisor.sl.struct.SupervisorUserWorkspaceDetails;
import curam.supervisor.sl.struct.TaskFilterCriteriaDetails;
import curam.supervisor.sl.struct.TaskRedirectionKey;
import curam.supervisor.sl.struct.UnsubscribeMemberWorkQueueKey;
import curam.supervisor.sl.struct.UnsubscribeUserWorkQueueKey;
import curam.supervisor.sl.struct.UserNameOrgObjectKey;
import curam.supervisor.sl.struct.UserTaskRedirectionDetails;
import curam.supervisor.sl.struct.UserTasksRedirectionHistoryDetailsList;
import curam.supervisor.sl.util.impl.CasesForSupervisor;
import curam.supervisor.sl.util.impl.CasesForSupervisorImpl;
import curam.supervisor.sl.util.impl.DBSearchQueriesForSupervisorWS;
import curam.supervisor.sl.util.impl.DBSearchQueriesForSupervisorWS.QueryType;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.DatabaseException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.impl.LocalizableStringResolver;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;
import curam.util.workflow.struct.TaskWDOSnapshotDetails;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;

/**
 * Service Layer class for Supervisor user API
 *
 */
public abstract class MaintainSupervisorUsers
  extends curam.supervisor.sl.base.MaintainSupervisorUsers {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kID = SupervisorConst.kID;

  /**
   * Identifier for holding the User Name for Bar chart creation
   */
  protected static final String kUserName = SupervisorConst.kUserName;

  /**
   * Identifier for holding the Full Name for Bar chart creation
   */
  protected static final String kFullName = SupervisorConst.kFullName;

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kBarChart = SupervisorConst.kBarChart;

  /**
   * Identifier for holding the element type
   */
  protected static final String kUnit = SupervisorConst.kUnit;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = SupervisorConst.kCaption;

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kText = SupervisorConst.kText;

  /**
   * Identifier for holding the element
   */
  protected static final String kBlock = SupervisorConst.kBlock;

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kType = SupervisorConst.kType;

  /**
   * Identifier for holding the due date
   */
  protected static final String kDueDate = SupervisorConst.kDueDate;

  /**
   * Identifier for holding the start date
   */
  protected static final String kStartDate = SupervisorConst.kStartDate;

  /**
   * Identifier for holding the bar graph length
   */
  protected static final String kLength = SupervisorConst.kLength;

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode =
    SupervisorConst.kTaskOptionCode;

  /**
   * Identifier for holding the Number of weeks for task due
   *
   */
  protected static final int kNumberOfWeeks = SupervisorConst.kNumberOfWeeks;

  /**
   * Identifier for holding the hyperlink on email identifier
   */

  protected static final String kMailLink = SupervisorConst.kMailLink;

  /**
   * Identifier for holding the value of Date Format to be displayed as the
   * Caption in the bar chart.
   */

  // BEGIN, CR00124642, GSP
  final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;

  // END, CR00124642
  // ___________________________________________________________________________
  // BEGIN, CR00216252 MN
  /**
   * This readUserWorkspaceMonthDetails is used to read the user workspace
   * details
   *
   * @param key -
   * UserNameKey
   * @return UserWorkspaceDetails
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#readSupervisorWorkspaceMonthDetails(UserNameKey key)}
   * .
   * As part of CLE changes the implementation has been moved to
   * readSupervisorWorkspaceMonthDetails with a new return struct
   * SupervisorWorkspaceDetails. This struct has all the fields of
   * UserWorkspaceDetails.UserDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216252>
   */
  @Override
  @Deprecated
  public curam.supervisor.sl.struct.UserWorkspaceDetails
    readUserWorkspaceMonthDetails(final UserNameKey key)
      throws AppException, InformationalException {

    // Creating UserWorkspace Details object
    final curam.supervisor.sl.struct.UserWorkspaceDetails userWorkspaceDetails =
      new curam.supervisor.sl.struct.UserWorkspaceDetails();

    final SupervisorUserWorkspaceDetails supervisorUserWorkspaceDetails =
      this.readSupervisorWorkspaceMonthDetails(key);

    userWorkspaceDetails.dtls = supervisorUserWorkspaceDetails.dtls;
    userWorkspaceDetails.orgDetailsList =
      supervisorUserWorkspaceDetails.orgDetailsList;
    final curam.supervisor.sl.struct.UserDetails userDetails =
      new curam.supervisor.sl.struct.UserDetails();

    userDetails.phoneAreaCode =
      supervisorUserWorkspaceDetails.userDetails.phoneAreaCode;
    userDetails.phoneCountryCode =
      supervisorUserWorkspaceDetails.userDetails.phoneCountryCode;
    userDetails.phoneExtension =
      supervisorUserWorkspaceDetails.userDetails.phoneExtension;
    userDetails.phoneNumber =
      supervisorUserWorkspaceDetails.userDetails.phoneNumber;
    userDetails.taskRedirectedUserName =
      supervisorUserWorkspaceDetails.userDetails.taskRedirectedUserName;
    userDetails.tasksRedirectedTo =
      supervisorUserWorkspaceDetails.userDetails.tasksRedirectedTo;
    userDetails.userEmail =
      supervisorUserWorkspaceDetails.userDetails.userEmail;
    userDetails.userFullName =
      supervisorUserWorkspaceDetails.userDetails.userFullName;
    userDetails.userName =
      supervisorUserWorkspaceDetails.userDetails.userName;

    userWorkspaceDetails.userDetails = userDetails;
    userWorkspaceDetails.userWorkspaceChartXMLString =
      supervisorUserWorkspaceDetails.userWorkspaceChartXMLString;
    userWorkspaceDetails.workQueueSubscription =
      supervisorUserWorkspaceDetails.workQueueSubscription;

    return userWorkspaceDetails;
  }

  // END, CR00216252
  // ___________________________________________________________________________
  /**
   * This method fetches a list of tasks associated with the user, that have
   * been reserved by a particular him, that are deferred.
   *
   * @param key
   * identifies userName and status for the task
   *
   * @return List of tasks associated with the case
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public ListDeferredTasksReservedByUserDetails
    listDeferredTasksReservedByUser(
      final ListDeferredTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Inbox inbox =
      curam.core.sl.fact.InboxFactory.newInstance();
    final ListTaskKey listTaskKey = new ListTaskKey();
    final ListDeferredTasksReservedByUserDetails listDeferredTasksReservedByUserDetails =
      new ListDeferredTasksReservedByUserDetails();

    listTaskKey.userName = key.userName;
    listDeferredTasksReservedByUserDetails.taskDetailsList =
      inbox.listLimitedDeferredTasks(listTaskKey,
        inbox.getInboxTaskReadMultiDetails());

    final TaskSortByPriority<DeferredTaskDetails> prioritySort =
      new TaskSortByPriority<DeferredTaskDetails>();

    prioritySort.sortIfEnabled(
      listDeferredTasksReservedByUserDetails.taskDetailsList.taskDetailsList);

    return listDeferredTasksReservedByUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method fetches a list of tasks associated with the user, that have
   * been reserved by a particular him, that are open.
   *
   * @param key
   * identifies userName and status for the task
   *
   * @return List of tasks associated with the case
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ListOpenTasksReservedByUserDetails
    listOpenTasksReservedByUser(final ListOpenTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Inbox inbox =
      curam.core.sl.fact.InboxFactory.newInstance();
    final UserNameAndStatusKey userNameAndStatusKey =
      new UserNameAndStatusKey();
    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      new ListOpenTasksReservedByUserDetails();

    userNameAndStatusKey.userName = key.userName;
    userNameAndStatusKey.statusCode = TASKSTATUS.NOTSTARTED;
    listOpenTasksReservedByUserDetails.taskDetailsList =
      inbox.listLimitedReservedTasksByStatus(userNameAndStatusKey,
        inbox.getInboxTaskReadMultiDetails());

    final TaskSortByPriority<ReservedByStatusTaskDetails> prioritySort =
      new TaskSortByPriority<ReservedByStatusTaskDetails>();

    prioritySort.sortIfEnabled(
      listOpenTasksReservedByUserDetails.taskDetailsList.taskDetailsList);

    return listOpenTasksReservedByUserDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method lists the tasks assigned to a user, but not currently reserved
   * by the user. The list does not include tasks assigned to work queues that
   * the user is subscribed to.
   *
   * @param key -
   * ListUnreservedTasksForUserKey
   * @return ListUnreservedTasksForUserDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public ListUnreservedTasksForUserDetails
    listTasksAssignedToUser(final ListUnreservedTasksForUserKey key)
      throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.sl.intf.Inbox inbox = InboxFactory.newInstance();

    final ListTaskKey listTaskKey = new ListTaskKey();

    listTaskKey.userName = key.userName;
    final ListUnreservedTasksForUserDetails listUnreservedTasksForUserDetails =
      new ListUnreservedTasksForUserDetails();

    listUnreservedTasksForUserDetails.taskDetailsList =
      inbox.listAssigned(listTaskKey);

    return listUnreservedTasksForUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * This function provides the supervisor a view of the work queues that the
   * user is subscribed to.
   *
   * @param key
   * ListUserWorkQueueDetailsKey
   * @return ListUserWorkQueueDetails listUserWorkQueueDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public ListUserWorkQueueDetails
    listUserWorkQueues(final ListUserWorkQueueDetailsKey key)
      throws AppException, InformationalException {

    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    final ListUserWorkQueueDetails listUserWorkQueueDetails =
      new ListUserWorkQueueDetails();

    listUserWorkQueueDetails.userWorkQueueDtls =
      userWorkspace.listWorkQueuesForUser(usersKey);
    return listUserWorkQueueDetails;
  }

  // ___________________________________________________________________________
  /**
   * To Reserve the next work queue task for user
   *
   * @param key -
   * of ReserveNextWorkQueueTaskKey
   * @return ReserveNextTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ReserveNextTaskDetails reserveNextWorkQueueTask(
    final curam.supervisor.sl.struct.ReserveNextWorkQueueTaskKey key)
    throws AppException, InformationalException {

    final Inbox inbox = InboxFactory.newInstance();

    final curam.core.sl.struct.ReserveNextWorkQueueTaskKey reserveNextWorkQueueTaskKey =
      new ReserveNextWorkQueueTaskKey();

    curam.core.sl.struct.ReserveNextTaskDetails reserveNextTaskDetails =
      new curam.core.sl.struct.ReserveNextTaskDetails();

    reserveNextWorkQueueTaskKey.userName = key.userName;
    reserveNextWorkQueueTaskKey.workQueueID = key.workQueueID;

    /*
     * BEGIN, CR00021818, SS
     */
    validateReserve(key);

    /*
     * END, CR00021818
     */

    reserveNextTaskDetails =
      inbox.reserveNextWorkQueueTask(reserveNextWorkQueueTaskKey);

    // BEGIN, CR00124957, SAI
    // An information message is displayed to the supervisor telling them that
    // the task has been reserved to the user.
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final AppException appException =
      new AppException(BPOSUPERVISORUSER.INF_TASK_RESERVED_TO_USER);

    // Passing Task ID to display the Task ID also with the message.
    appException.arg(reserveNextTaskDetails.taskID);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
      .addInfoMgrExceptionWithLookup(appException, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    return reserveNextTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * Unsubscribe the user from work queue
   *
   * @param key -
   * UnsubscribeUserWorkQueueKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    unsubscribeUserFromWorkQueue(final UnsubscribeUserWorkQueueKey key)
      throws AppException, InformationalException {

    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    final UserSubscriptionToWorkQueueDetails unsubscribeUserFromWorkQueueKey =
      new UserSubscriptionToWorkQueueDetails();

    validate(key);

    unsubscribeUserFromWorkQueueKey.workQueueID = key.workQueueID;
    unsubscribeUserFromWorkQueueKey.userName = key.userName;

    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;

    unsubscribeUserFromWorkQueueKey.workQueueName =
      workQueueObj.readWorkQueueName(workQueueKey).name;

    userWorkspace
      .unsubscribeUserFromWorkQueue(unsubscribeUserFromWorkQueueKey);

    // Send Notification
    final AppException notificationDetails = new AppException(
      BPOSUPERVISORUSER.SUPERVISOR_UNSUBSCRIBE_USER_FROM_WORKQUEUE_NOTIFICATION);

    final StandardManualTaskDtls standardManualDtls =
      new StandardManualTaskDtls();

    // Read workQueue
    final WorkQueueDtls workQueueDtls = workQueueObj.read(workQueueKey);

    notificationDetails.arg(workQueueDtls.name);
    notificationDetails
      .arg(curam.util.transaction.TransactionInfo.getProgramUser());
    standardManualDtls.dtls.taskDtls.subject =
      notificationDetails.getMessage();

  }

  // ___________________________________________________________________________
  // BEGIN, CR00161962, BK
  /**
   * Unsubscribes a member like user, org unit, position, job from a WorkQueue
   *
   * @param key -
   * UnsubscribeUserWorkQueueKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    unsubscribeMemberFromWorkQueue(final UnsubscribeMemberWorkQueueKey key)
      throws AppException, InformationalException {

    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    final UserNameSubscriberAndWorkQueueKey userNameSubscriberAndWorkQueueKey =
      new UserNameSubscriberAndWorkQueueKey();

    // work queue user key
    final UnsubscribeUserWorkQueueKey unsubscribeUserWorkQueueKey =
      new UnsubscribeUserWorkQueueKey();

    // assign key values
    unsubscribeUserWorkQueueKey.workQueueID = key.workQueueID;
    unsubscribeUserWorkQueueKey.userName = key.userName;

    // validation for sensitivity
    validate(unsubscribeUserWorkQueueKey);

    userNameSubscriberAndWorkQueueKey.workQueueID = key.workQueueID;
    userNameSubscriberAndWorkQueueKey.userName = key.userName;
    userNameSubscriberAndWorkQueueKey.subscriberID = key.subscriberID;
    userNameSubscriberAndWorkQueueKey.subscriberType = key.subscriberType;

    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;

    userWorkspace
      .unsubscribeSubscriberFromWorkQueue(userNameSubscriberAndWorkQueueKey);

    // Send Notification
    final AppException notificationDetails = new AppException(
      BPOSUPERVISORUSER.SUPERVISOR_UNSUBSCRIBE_USER_FROM_WORKQUEUE_NOTIFICATION);

    final StandardManualTaskDtls standardManualDtls =
      new StandardManualTaskDtls();

    // Read workQueue
    final WorkQueueDtls workQueueDtls = workQueueObj.read(workQueueKey);

    notificationDetails.arg(workQueueDtls.name);
    notificationDetails
      .arg(curam.util.transaction.TransactionInfo.getProgramUser());
    standardManualDtls.dtls.taskDtls.subject =
      notificationDetails.getMessage();

  } // END, CR00161962

  // ___________________________________________________________________________
  /**
   * This method retrieves a list of the users reporting to the supervisor.
   *
   * @return SupervisorUserDetails The users reporting to the supervisor.
   * @deprecated Since Curam 6.0. This method is replaced by
   * {@link #listSupervisorUsersWithTaskCount() which additionally returns a
   * count of the tasks assigned to each user reporting to the supervisor. See
   * release note CR00221722.
   */
  @Override
  @Deprecated
  public SupervisorUserDetails listSupervisorUsers()
    throws AppException, InformationalException {

    final SupervisorUserDetails userDetails = new SupervisorUserDetails();

    userDetails.userDetails.assign(listSupervisorUsersWithTaskCount());
    return userDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves a list of the users reporting to the supervisor. It
   * also returns a count of the tasks assigned to each of them.
   *
   * @return SupervisorUserWithTaskCountDetailsList The users reporting to the
   * supervisor including a count of the tasks assigned to each of them.
   */
  @Override
  public SupervisorUserWithTaskCountDetailsList
    listSupervisorUsersWithTaskCount()
      throws AppException, InformationalException {

    // BEGIN, CR00305811, MV
    final curam.core.struct.SupervisorUserWithTaskCountDetailsList supervisorUserWithTaskCountDetailsList =
      new curam.core.struct.SupervisorUserWithTaskCountDetailsList();
    final Users usersObj = UsersFactory.newInstance();

    final OrgObjTypeNameAndCaseStatusKey orgObjTypeNameAndCaseStatusKey =
      new OrgObjTypeNameAndCaseStatusKey();

    orgObjTypeNameAndCaseStatusKey.userName =
      TransactionInfo.getProgramUser();
    orgObjTypeNameAndCaseStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjTypeNameAndCaseStatusKey.caseStatus = CASESTATUS.OPEN;
    orgObjTypeNameAndCaseStatusKey.orgObjectType = ORGOBJECTTYPE.USER;

    final String orgUnitSelectDefault =
      EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;
    final String orgUnitSelectOption =
      Configuration.getProperty(EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

    // BEGIN, CR00398625, IBM
    final SupervisorUserWithTaskCountDetailsList supervisorUserDetailsList =
      new SupervisorUserWithTaskCountDetailsList();
    // BEGIN, CR00468368, YP
    final CasesForSupervisor casesForSupervisor =
      new CasesForSupervisorImpl();
    final Set<String> sysLevelCases =
      casesForSupervisor.getCaseTypesNotReqdForSupervisor();

    // END, CR00468368

    if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
      // BEGIN , CR00468368, YP
      supervisorUserDetailsList.assign(
        searchUserTasksAndCasesBySupervisorIDLeadPosFileteringSysCases(
          orgObjTypeNameAndCaseStatusKey, sysLevelCases));
      // END , CR00468368
    } else {

      final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits =
        MaintainSupervisorOrgUnitsFactory.newInstance();

      final SupervisorOrganisationUnitDetails supervisorOrganisationUnitDetails =
        maintainSupervisorOrgUnits.listSupervisorOrgUnits();

      for (final SupervisorOrgUnitDetails supervisorOrgUnitDetails : supervisorOrganisationUnitDetails.orgUnitDetails.dtls
        .items()) {

        final SearchBySupervisorOrgUnit searchBySupervisorOrgUnit =
          new SearchBySupervisorOrgUnit();

        searchBySupervisorOrgUnit.organisationStructureID =
          supervisorOrgUnitDetails.orgStructureID;
        searchBySupervisorOrgUnit.organisationUnitID =
          supervisorOrgUnitDetails.orgUnitID;
        searchBySupervisorOrgUnit.effectiveDate =
          curam.util.type.Date.getCurrentDate();
        searchBySupervisorOrgUnit.recordStatus = RECORDSTATUS.NORMAL;
        searchBySupervisorOrgUnit.caseStatus = CASESTATUS.OPEN;
        searchBySupervisorOrgUnit.orgObjectType = ORGOBJECTTYPE.USER;

        // BEGIN , CR00468368, YP
        final curam.core.struct.SupervisorUserWithTaskCountDetailsList userDetailsList =
          searchUserTasksAndCasesBySupervisorOrgUnitFileteringSysCases(
            searchBySupervisorOrgUnit, sysLevelCases);

        // END , CR00468368

        if (null != userDetailsList) {

          supervisorUserWithTaskCountDetailsList.dtls
            .addAll(userDetailsList.dtls);
        }
      }
      supervisorUserDetailsList
        .assign(supervisorUserWithTaskCountDetailsList);
    }

    return supervisorUserDetailsList;
    // END, CR00398625
    // END, CR00305811
  }

  // ___________________________________________________________________________
  /**
   * */
  public void subscribeUser(final SubscribeUserToWorkQueueKey arg0)
    throws AppException, InformationalException {// TODO Auto-generated

    // method stub
  }

  // ___________________________________________________________________________
  /**
   * */
  public void reserve(final ReserveTaskDetails arg0)
    throws AppException, InformationalException {// TODO Auto-generated method
                                                 // stub

  }

  // BEGIN, CR00139241, GYH
  /**
   * Retrieves the list of unclosed cases for the user.
   *
   * @param key
   * Contains user name and organization key.
   *
   * @return The list of unclosed cases for the user.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00139241
  @Override
  public SupervisorUserCaseDetails
    listAllUserCases(final UserNameOrgObjectKey key)
      throws AppException, InformationalException {

    // BEGIN CR00107117 ,GM
    final curam.core.intf.CaseHeader caseHeaderObj =
      CaseHeaderFactory.newInstance();
    // END CR00107117

    // These are the changes done for the CaseOwnership, using the
    // UserStatusAndOrgObjectKey instead of UserAndStatusKey

    final UserStatusAndOrgObjectKey userStatusAndOrgObjectKey =
      new UserStatusAndOrgObjectKey();

    if (key.orgObjectKey != null && key.orgObjectKey.length() > 0) {
      userStatusAndOrgObjectKey.orgObjectType = key.orgObjectKey;
    } // if the organization object key is not passed, then the default type
    // i.e. User is taken
    else {
      userStatusAndOrgObjectKey.orgObjectType = ORGOBJECTTYPE.USER;
    }

    userStatusAndOrgObjectKey.userName = key.userName;
    userStatusAndOrgObjectKey.status = CASESTATUS.CLOSED;

    CaseReferenceTypeProductRolePriClientDateAndStatusList caseList =
      new CaseReferenceTypeProductRolePriClientDateAndStatusList();

    // BEGIN, CR00468368, GK
    final CasesForSupervisor cfs = new CasesForSupervisorImpl();
    final Set<String> cases = cfs.getCaseTypesNotReqdForSupervisor();

    QueryType queryType = null;

    if (ORGOBJECTTYPE.USER.equals(userStatusAndOrgObjectKey.orgObjectType)) {
      queryType = QueryType.CASESBYUSERID;
    }

    // BEGIN, 198952, CP
    if (BATCHPROCESSNAME.BULK_CASE_REASSIGNMENTS.equals(key.searchTypeOpt)) {
      queryType = QueryType.BULKCASEREASSIGNMENTS;
    }
    // END, 198952
    if (ORGOBJECTTYPE.ORGUNIT
      .equals(userStatusAndOrgObjectKey.orgObjectType)) {
      queryType = QueryType.CASESBYORGUNIT;
    }

    if (ORGOBJECTTYPE.POSITION
      .equals(userStatusAndOrgObjectKey.orgObjectType)) {
      queryType = QueryType.CASESBYPOSITION;
    }

    if (ORGOBJECTTYPE.WORKQUEUE
      .equals(userStatusAndOrgObjectKey.orgObjectType)) {
      queryType = QueryType.CASESBYWORKQUEUE;
    }
    caseList =
      searchFilteredCases(userStatusAndOrgObjectKey, cases, queryType);

    // END, CR00468368

    // BEGIN, CR00357256, IBM
    // BEGIN, CR00468368, GK
    final CaseReferenceTypeProductRolePriClientDateAndStatusList batchCaseList =
      searchFilteredCases(userStatusAndOrgObjectKey, cases,
        QueryType.CASESBYBATCHQUEUEDSTATUS);
    // END, CR00468368
    final CaseReferenceTypeProductRolePriClientDateAndStatusList filteredCaseList =
      new CaseReferenceTypeProductRolePriClientDateAndStatusList();
    boolean isCaseBatchQueued;

    // BEGIN, CR00369467, IBM
    if (!(key.orgObjectKey != null && key.orgObjectKey.length() > 0)) {

      for (final CaseReferenceTypeProductRolePriClientDateAndStatus caseReferenceTypeProductRolePriClientDateAndStatus : caseList.dtls
        .items()) {

        isCaseBatchQueued = false;

        for (final CaseReferenceTypeProductRolePriClientDateAndStatus batchCaseReferenceTypeProductRolePriClientDateAndStatus : batchCaseList.dtls
          .items()) {

          if (batchCaseReferenceTypeProductRolePriClientDateAndStatus.caseID == caseReferenceTypeProductRolePriClientDateAndStatus.caseID) {
            isCaseBatchQueued = true;
            break;
          }
        }

        if (!isCaseBatchQueued) {
          filteredCaseList.dtls
            .add(caseReferenceTypeProductRolePriClientDateAndStatus);
        }
      }
      if (filteredCaseList.dtls.size() > 0) {
        caseList = filteredCaseList;
      } else {
        caseList.dtls.clear();
      }
    }
    // END, CR00369467
    // END, CR00357256

    for (int i = 0; i < caseList.dtls.size(); i++) {
      final String caseTypeCode = caseList.dtls.item(i).caseTypeCode;
      String productTypeDesc = "";

      // BEGIN, CR00139241, GYH
      // Get the description for the type of the product
      if (caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
        || caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

        // BEGIN, CR00372089, AC
        final ProductDeliveryTypeDetails productDeliveryTypeDetails =
          new ProductDeliveryTypeDetails();

        productDeliveryTypeDetails.productType =
          caseList.dtls.item(i).productType;
        productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryTypeDetails.productType,
          TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

        final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

        caseHeaderDtls.integratedCaseType =
          caseList.dtls.item(i).integratedCaseType;

        productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
          caseHeaderDtls.integratedCaseType,
          TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

        final ScreeningName screeningName = new ScreeningName();

        screeningName.name = caseList.dtls.item(i).name;

        productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
          screeningName.name, TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

        final AssessmentTypeDetails assessmentTypeDetails =
          new AssessmentTypeDetails();

        assessmentTypeDetails.assessmentType =
          caseList.dtls.item(i).assessmentType;
        productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
          assessmentTypeDetails.assessmentType,
          TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
        final ServicePlanTypeStruct servicePlanTypeStruct =
          new ServicePlanTypeStruct();

        servicePlanTypeStruct.servicePlanType =
          caseList.dtls.item(i).servicePlanType;
        productTypeDesc =
          CodeTable.getOneItem(curam.codetable.SERVICEPLANTYPE.TABLENAME,
            servicePlanTypeStruct.servicePlanType,
            TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.ISSUE)) {

        final IssueTypeCode issueTypeCode = new IssueTypeCode();

        issueTypeCode.issueType = caseList.dtls.item(i).issueType;

        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
          issueTypeCode.issueType, TransactionInfo.getProgramLocale());

      } else if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

        final InvestigationTypeCode investigationTypeCode =
          new InvestigationTypeCode();

        investigationTypeCode.investigationType =
          caseList.dtls.item(i).investigationType;
        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
          investigationTypeCode.investigationType,
          TransactionInfo.getProgramLocale());
      }
      // END, CR00139241
      // END, CR00372089
      // Product type description cannot be empty
      if (productTypeDesc == null || productTypeDesc.length() == 0) {
        productTypeDesc = // BEGIN, CR00163098, JC
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
      caseList.dtls.item(i).productTypeDesc = productTypeDesc;
    }

    // SupervisorUserCaseDetails object
    final SupervisorUserCaseDetails userCaseDetails =
      new SupervisorUserCaseDetails();

    userCaseDetails.caseDtlsList = caseList;

    // return the SupervisorUserCaseDetails object
    return userCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates the work queue un-subscription details.
   *
   * @param key
   * UnsubscribeUserWorkQueueKey Work queue un-subscription details
   * @throws InformationalException
   * @throws AppException
   */
  public void validate(final UnsubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue manipulation variables
    final curam.core.sl.entity.intf.WorkQueue workQueueObj =
      curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();
    WorkQueueDtls workQueueDtls;

    // Set key to read workQueue
    workQueueKey.workQueueID = key.workQueueID;

    // Read workQueue
    workQueueDtls = workQueueObj.read(workQueueKey);

    // Users manipulation variables
    final UsersKey userKey = new UsersKey();

    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00029748, TV
    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode userSensitivityCode =
      UserAccessFactory.newInstance().readSensitivityCodeForUser(userKey);
    // END, CR00098617

    final int userSensitivity =
      Integer.parseInt(userSensitivityCode.sensitivity);

    if (!workQueueDtls.administratorUserName.equals(userKey.userName)
      && !workQueueDtls.allowUserSubscriptionInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_UNSUBSCRIBE_USER_FROM_WORKQUEUE_NO_PRIVILEGES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check with WorkQueue administrator name and sensitivity level,
    // WorkQueue's user subscription option should be true.
    if (Integer.parseInt(workQueueDtls.sensitivity) > userSensitivity
      && workQueueDtls.allowUserSubscriptionInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_UNSUBSCRIBE_USER_FROM_WORKQUEUE_NO_SENSITIVITY_LEVEL),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // END, CR00029748

  }

  // ___________________________________________________________________________
  /**
   * This method clears the task redirection record for the user.
   *
   * @param key -
   * TaskRedirectionKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void clearTaskRedirection(final TaskRedirectionKey key)
    throws AppException, InformationalException {

    // UserWorkspace Object
    final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();
    final ClearTaskRedirectionDetails redirectionDetails =
      new ClearTaskRedirectionDetails();

    // Assign the detail values
    redirectionDetails.taskRedirectionID = key.taskRedirectionID;
    redirectionDetails.endDateTime = key.endDateTime;
    redirectionDetails.startDateTime = key.startDateTime;
    redirectionDetails.versionNo = key.versionNo;

    userWorkspaceObj.clearTaskRedirectionForUser(redirectionDetails);
  }

  // ___________________________________________________________________________
  /**
   * This forwardTasksReservedByUser forwards the selected tasks reserved by the
   * user either to another user or to a work queue or to a position or to an
   * organization unit.
   *
   * @param key -
   * SupervisorTaskForwardDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    forwardTasksReservedByUser(final SupervisorTaskForwardDetails key)
      throws AppException, InformationalException {

    // BEGIN, CR00351910, IBM
    final BulkTaskForwardProcess bulkTaskForwardProcess =
      BulkTaskForwardProcessFactory.newInstance();

    final BulkTaskForwardInputKey bulkTaskForwardInputKey =
      new BulkTaskForwardInputKey();

    bulkTaskForwardInputKey.deferredTaskIDList = key.deferredTaskIDList;
    bulkTaskForwardInputKey.forwardTaskDetails = key.forwardTaskDetails;
    bulkTaskForwardInputKey.forwardToOrgUnit = key.forwardToOrgUnit;
    bulkTaskForwardInputKey.forwardToUser = key.forwardToUser;
    bulkTaskForwardInputKey.openTaskIDList = key.openTaskIDList;
    bulkTaskForwardInputKey.userName = key.userName;
    bulkTaskForwardInputKey.operationInitiatedBy =
      TransactionInfo.getProgramUser();

    bulkTaskForwardProcess.forward(bulkTaskForwardInputKey);
    // END, CR00351910
  }

  // ___________________________________________________________________________

  // BEGIN, CR00161962, BK
  // BEGIN, CR00216252 MN
  /**
   * This method forwards the selected tasks assigned by the
   * user/or other members either to another user or to a work queue or
   * to a position or to an organization unit.
   *
   * @param key -
   * SupervisorTaskForwardDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public InformationalMsgDetailsList
    forwardTasksNotReservedByUser(final SupervisorTaskFwdDetails key)
      throws AppException, InformationalException {

    final InformationalMsgDetailsList informationalMsgDetailsList =
      new InformationalMsgDetailsList();

    // BEGIN, CR00379440, IBM
    final BulkTaskForwardProcess bulkTaskForwardProcess =
      BulkTaskForwardProcessFactory.newInstance();

    final BulkAssignedTaskForwardInputKey bulkTaskForwardInputKey =
      new BulkAssignedTaskForwardInputKey();

    bulkTaskForwardInputKey.assignedTaskIDList = key.assignedTaskIDList;
    bulkTaskForwardInputKey.deferredTaskIDList = key.deferredTaskIDList;
    bulkTaskForwardInputKey.forwardTaskDetails = key.forwardTaskDetails;
    bulkTaskForwardInputKey.forwardToOrgUnit = key.forwardToOrgUnit;
    bulkTaskForwardInputKey.forwardToUser = key.forwardToUser;
    bulkTaskForwardInputKey.openTaskIDList = key.openTaskIDList;
    bulkTaskForwardInputKey.userName = key.userName;
    bulkTaskForwardInputKey.operationInitiatedBy =
      TransactionInfo.getProgramUser();

    bulkTaskForwardProcess.forwardAssignedTask(bulkTaskForwardInputKey);
    // END, CR00379440

    return informationalMsgDetailsList;
  }

  // END, CR00216252

  // ___________________________________________________________________________
  /**
   * This validateAssignedTaskAndForward validates and forwards the selected
   * assigned tasks
   *
   * @param key -
   * SupervisorTaskForwardDetails
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected InformationalManager
    validateAndForwardUnreservedTask(final SupervisorTaskFwdDetails key)
      throws AppException, InformationalException {

    // END, CR00198672
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithoutSnapshot taskSummaryDetails =
      taskAdminObj.readDetails(key.forwardTaskDetails.taskID);

    if (taskSummaryDetails.status.equals(curam.codetable.TASKSTATUS.CLOSED)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_FORWARD_RESERVED_USERTASKS_CLOSED);

      ae.arg(key.forwardTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    taskManagement.forward(key.forwardTaskDetails);

    final InformationalManager informationalManager =
      new InformationalManager();
    final AppException appException =
      new AppException(BPOTASKMANAGEMENT.TASKS_FORWARDED_SUCCESSFULLY);

    appException.arg(key.forwardTaskDetails.taskID);
    appException.arg(curam.util.type.CodeTable.getOneItem(
      TARGETITEMTYPE.TABLENAME, key.forwardTaskDetails.forwardToType));
    if (key.forwardToOrgUnit > 0) {
      final OrganisationUnit organisationUnitObj =
        OrganisationUnitFactory.newInstance();
      final OrganisationUnitKey organisationUnitKey =
        new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID = key.forwardToOrgUnit;
      final OrganisationUnitName organisationUnitName =
        organisationUnitObj.readOrgUnitName(organisationUnitKey);

      appException.arg(organisationUnitName.name);
    } else if (!key.forwardToUser.equals(CuramConst.gkEmpty)) {
      final Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = key.forwardToUser;
      final UserFullname userFullname = usersObj.readUserFullname(usersKey);

      appException.arg(userFullname.fullname);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType.equals(TARGETITEMTYPE.USER)) {
      final Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = key.forwardTaskDetails.forwardToID;
      final UserFullname userFullname = usersObj.readUserFullname(usersKey);

      appException.arg(userFullname.fullname);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType
        .equals(TARGETITEMTYPE.EXTERNALUSER)) {
      final ExternalUser externalUserObj = ExternalUserFactory.newInstance();
      final ExternalUserKey externalUserKey = new ExternalUserKey();

      externalUserKey.userName = key.forwardTaskDetails.forwardToID;
      final ExternalUserNameDetails externalUserNameDetails =
        externalUserObj.readNameDetails(externalUserKey);

      appException.arg(externalUserNameDetails.fullName);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType.equals(TARGETITEMTYPE.JOB)) {
      final Job jobObj = JobFactory.newInstance();
      final curam.core.sl.entity.struct.JobKey jobKey =
        new curam.core.sl.entity.struct.JobKey();

      jobKey.jobID = Long.parseLong(key.forwardTaskDetails.forwardToID);
      final JobName jobName = jobObj.readJobName(jobKey);

      appException.arg(jobName.name);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType
        .equals(TARGETITEMTYPE.ORGUNIT)) {
      final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj =
        curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
      final OrganisationUnitKey organisationUnitKey =
        new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID =
        Long.parseLong(key.forwardTaskDetails.forwardToID);
      final OrganisationUnitName organisationUnitName =
        organisationUnitObj.readOrgUnitName(organisationUnitKey);

      appException.arg(organisationUnitName.name);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType
        .equals(TARGETITEMTYPE.POSITION)) {
      final Position positionObj =
        curam.core.sl.entity.fact.PositionFactory.newInstance();
      final PositionKey positionKey = new PositionKey();

      positionKey.positionID =
        Long.parseLong(key.forwardTaskDetails.forwardToID);
      final PositionName positionName =
        positionObj.readPositionName(positionKey);

      appException.arg(positionName.name);
    } else if (!key.forwardTaskDetails.forwardToID.equals(CuramConst.gkEmpty)
      && key.forwardTaskDetails.forwardToType
        .equals(TARGETITEMTYPE.WORKQUEUE)) {
      final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      workQueueKey.workQueueID =
        Long.parseLong(key.forwardTaskDetails.forwardToID);
      final WorkQueueNameDetails workQueueNameDetails =
        workQueueObj.readWorkQueueName(workQueueKey);

      appException.arg(workQueueNameDetails.name);
    }
    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
      .addInfoMgrExceptionWithLookup(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    return informationalManager;
  }

  // END, CR00161962

  // ___________________________________________________________________________
  // BEGIN, CR00216807 MN
  /**
   * This method lists the redirected tasks records for the user.
   *
   * @param key -
   * UserNameKey
   * @return TasksRedirectionHistoryDetailsList
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#listTaskRedirectionHistory(UserNameKey key)}
   * .
   * As part of the CLE changes , implementation has been moved to
   * listTaskRedirectionHistory with a new return struct
   * UserTasksRedirectionHistoryDetailsList. This struct has all the fields of
   * TasksRedirectionHistoryDetailsList. See release note : <CR00216807>
   */
  @Override
  @Deprecated
  public curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList
    listUserTaskRedirectionHistory(final UserNameKey key)
      throws AppException, InformationalException {

    final UserTasksRedirectionHistoryDetailsList detailsList =
      this.listTaskRedirectionHistory(key);

    final curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList historyDetailsList =
      new curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList();
    final curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails allTaskRedirectionsFromUserDetails =
      new curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails();

    // BEGIN, CR00225492 MN
    // populating Active and Pending Task Redirection details.
    RedirectTaskDetails redirectActiveAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails taskRedirectionDetails =
      new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ActiveAndPendingTaskRedirectionFromUserDetailsList activeAndPendingTaskRedirectionDetailsList =
      new ActiveAndPendingTaskRedirectionFromUserDetailsList();

    for (int i =
      0; i < detailsList.redirectionDetailsList.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails
        .size(); i++) {

      redirectActiveAndPendingTaskDetails =
        detailsList.redirectionDetailsList.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails
          .get(i);

      taskRedirectionDetails.endDateTime =
        redirectActiveAndPendingTaskDetails.endDateTime;
      taskRedirectionDetails.redirectionStatus =
        redirectActiveAndPendingTaskDetails.redirectionStatus;
      taskRedirectionDetails.startDateTime =
        redirectActiveAndPendingTaskDetails.startDateTime;
      taskRedirectionDetails.taskRedirectionID =
        redirectActiveAndPendingTaskDetails.taskRedirectionID;
      taskRedirectionDetails.toUserFullName =
        redirectActiveAndPendingTaskDetails.toUserFullName;
      taskRedirectionDetails.toUserName =
        redirectActiveAndPendingTaskDetails.toUserName;

      activeAndPendingTaskRedirectionDetailsList.activeAndPendingDtls
        .addRef(taskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirections =
      activeAndPendingTaskRedirectionDetailsList;
    // _________________________________________________________
    // populating Expired Task Redirection details.
    RedirectTaskDetails redirectExpiredAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails expiredTaskRedirectionDetails =
      new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ExpiredTaskRedirectionFromUserDetailsList expiredTaskRedirectionDetailsList =
      new ExpiredTaskRedirectionFromUserDetailsList();

    for (int i =
      0; i < detailsList.redirectionDetailsList.expiredTaskRedirectionDetails.expiredDetails
        .size(); i++) {

      redirectExpiredAndPendingTaskDetails =
        detailsList.redirectionDetailsList.expiredTaskRedirectionDetails.expiredDetails
          .get(i);

      expiredTaskRedirectionDetails.endDateTime =
        redirectExpiredAndPendingTaskDetails.endDateTime;
      expiredTaskRedirectionDetails.redirectionStatus =
        redirectExpiredAndPendingTaskDetails.redirectionStatus;
      expiredTaskRedirectionDetails.startDateTime =
        redirectExpiredAndPendingTaskDetails.startDateTime;
      expiredTaskRedirectionDetails.taskRedirectionID =
        redirectExpiredAndPendingTaskDetails.taskRedirectionID;
      expiredTaskRedirectionDetails.toUserFullName =
        redirectExpiredAndPendingTaskDetails.toUserFullName;
      expiredTaskRedirectionDetails.toUserName =
        redirectExpiredAndPendingTaskDetails.toUserName;

      expiredTaskRedirectionDetailsList.expiredDtls
        .addRef(expiredTaskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.expiredTaskRedirections =
      expiredTaskRedirectionDetailsList;

    // END, CR00225492

    historyDetailsList.redirectionDetailsList =
      allTaskRedirectionsFromUserDetails;

    return historyDetailsList;

  }

  // END, CR00216807

  // ___________________________________________________________________________
  // BEGIN, CR00216252 MN
  /**
   * This readUserWorkspaceWeekDetails is used to read the user workspace
   * details
   *
   * @param key -
   * UserNameKey
   * @return UserWorkspaceDetails
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#readSupervisorWorkspaceWeekDetails(UserNameKey key)}
   * .
   * readSupervisorWorkspaceWeekDetails with a new return struct
   * SupervisorWorkspaceDetails. This struct has all the fields of
   * UserWorkspaceDetails.UserDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216252>
   */
  @Override
  @Deprecated
  public curam.supervisor.sl.struct.UserWorkspaceDetails
    readUserWorkspaceWeekDetails(final UserNameKey key)
      throws AppException, InformationalException {

    // Creating UserWorkspaceDetails object
    final curam.supervisor.sl.struct.UserWorkspaceDetails userWorkspaceDetails =
      new curam.supervisor.sl.struct.UserWorkspaceDetails();

    final SupervisorUserWorkspaceDetails supervisorUserWorkspaceDetails =
      this.readSupervisorWorkspaceWeekDetails(key);

    userWorkspaceDetails.dtls = supervisorUserWorkspaceDetails.dtls;
    userWorkspaceDetails.orgDetailsList =
      supervisorUserWorkspaceDetails.orgDetailsList;

    final curam.supervisor.sl.struct.UserDetails userDetails =
      new curam.supervisor.sl.struct.UserDetails();

    userDetails.phoneAreaCode =
      supervisorUserWorkspaceDetails.userDetails.phoneAreaCode;
    userDetails.phoneCountryCode =
      supervisorUserWorkspaceDetails.userDetails.phoneCountryCode;
    userDetails.phoneExtension =
      supervisorUserWorkspaceDetails.userDetails.phoneExtension;
    userDetails.phoneNumber =
      supervisorUserWorkspaceDetails.userDetails.phoneNumber;
    userDetails.taskRedirectedUserName =
      supervisorUserWorkspaceDetails.userDetails.taskRedirectedUserName;
    userDetails.tasksRedirectedTo =
      supervisorUserWorkspaceDetails.userDetails.tasksRedirectedTo;
    userDetails.userEmail =
      supervisorUserWorkspaceDetails.userDetails.userEmail;
    userDetails.userFullName =
      supervisorUserWorkspaceDetails.userDetails.userFullName;
    userDetails.userName =
      supervisorUserWorkspaceDetails.userDetails.userName;

    userWorkspaceDetails.userDetails = userDetails;

    userWorkspaceDetails.userWorkspaceChartXMLString =
      supervisorUserWorkspaceDetails.userWorkspaceChartXMLString;
    userWorkspaceDetails.workQueueSubscription =
      supervisorUserWorkspaceDetails.workQueueSubscription;

    return userWorkspaceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This readUserDetails returns user details for User Workspace
   *
   * @param key -
   * UserNameKey
   * @return UserDetails
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#readSupervisorDetails(UserNameKey key)}.
   * As part of the CLE changes , implementation has been moved to
   * readSupervisorDetails with a new return struct
   * SupervisorWorkspaceDetails. This struct has all the fields of
   * UserWorkspaceDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216252>
   */
  @Deprecated
  public curam.supervisor.sl.struct.UserDetails readUserDetails(
    final UserNameKey key) throws AppException, InformationalException {

    SupervisorDetails supervisorDetails = new SupervisorDetails();

    supervisorDetails = this.readSupervisorDetails(key);

    final curam.supervisor.sl.struct.UserDetails userDetails =
      new curam.supervisor.sl.struct.UserDetails();

    userDetails.phoneAreaCode = supervisorDetails.phoneAreaCode;
    userDetails.phoneCountryCode = supervisorDetails.phoneCountryCode;
    userDetails.phoneExtension = supervisorDetails.phoneExtension;
    userDetails.phoneNumber = supervisorDetails.phoneNumber;
    userDetails.taskRedirectedUserName =
      supervisorDetails.taskRedirectedUserName;
    userDetails.tasksRedirectedTo = supervisorDetails.tasksRedirectedTo;
    userDetails.userEmail = supervisorDetails.userEmail;
    userDetails.userEmailLink = supervisorDetails.userEmailLink;
    userDetails.userFullName = supervisorDetails.userFullName;
    userDetails.userName = supervisorDetails.userName;
    return userDetails;

  }

  // END, CR00216252
  // BEGIN, CR00161962, BK
  /**
   * Returns the Task redirection target object name which could be JobName,
   * OrgUnitName, PositionName or UserName
   *
   * @param activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails
   * @return String
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  // BEGIN, CR00225492 MN
  protected String readTargetObjectName(
    final TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails)
    throws AppException, InformationalException {

    // END, CR00225492
    // END, CR00198672
    String targetObjectName = null;

    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType
      .equals(REDIRECTIONTARGETITEMTYPE.USER)) {
      final UsersKey userNameKey = new UsersKey();

      userNameKey.userName =
        activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName;
      final Users usersObj = UsersFactory.newInstance();

      targetObjectName = usersObj.readUserFullname(userNameKey).fullname;
    } else if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType
      .equals(REDIRECTIONTARGETITEMTYPE.ORGUNIT)) {
      final OrganisationUnitKey organisationUnitKey =
        new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID =
        activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectID;
      final OrganisationUnit organisationUnitObj =
        OrganisationUnitFactory.newInstance();

      targetObjectName =
        organisationUnitObj.readOrgUnitName(organisationUnitKey).name;
    } else if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType
      .equals(REDIRECTIONTARGETITEMTYPE.POSITION)) {
      final PositionKey positionKey = new PositionKey();

      positionKey.positionID =
        activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectID;
      final Position positionObj = PositionFactory.newInstance();

      targetObjectName = positionObj.readPositionName(positionKey).name;
    } else if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType
      .equals(REDIRECTIONTARGETITEMTYPE.WORKQUEUE)) {
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      workQueueKey.workQueueID =
        activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectID;
      final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

      targetObjectName = workQueueObj.readWorkQueueName(workQueueKey).name;
    }

    return targetObjectName;
  }

  // END, CR00161962
  // ___________________________________________________________________________
  // BEGIN, CR00225492 MN
  /**
   * This method redirects the tasks assignment of one user to another user for
   * a specified time period.
   *
   * @param key -
   * TaskRedirectionDetails
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#taskRedirectionsToUser(UserTaskRedirectionDetails key)}
   * .
   * As part of the CLE changes , implementation has been moved to
   * taskRedirectionsToUser with a new input struct
   * UserTaskRedirectionDetails. This struct has all the fields of
   * TaskRedirectionDetails struct along with fields
   * toRedirectID and toRedirectType. Along with the above functionality the
   * new method allows task redirections between members other than users.
   * See release note : <CR00225492>
   */
  @Override
  @Deprecated
  public void redirectTasksToUser(
    final curam.supervisor.sl.struct.TaskRedirectionDetails key)
    throws AppException, InformationalException {

    final UserTaskRedirectionDetails details =
      new UserTaskRedirectionDetails();

    details.endDateTime = key.endDateTime;
    details.fromUserName = key.fromUserName;
    details.startDateTime = key.startDateTime;
    details.toUserName = key.toUserName;
    details.toUserNameInSupervisorGroup = key.toUserNameInSupervisorGroup;
    details.toRedirectType = REDIRECTIONTARGETITEMTYPE.USER;

    this.taskRedirectionsToUser(details);

  }

  // END, CR00225492

  // ___________________________________________________________________________
  /**
   * This method reserves a specified number of assigned tasks for the user.
   *
   * @param key -
   * ReserveAssignedTasksDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void
    reserveAssignedTasksForUser(final ReserveAssignedTasksDetails key)
      throws AppException, InformationalException {

    // User workspace Object
    final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();

    userWorkspaceObj.reserveAssignedTasksForUser(key.assignedTasksDetails);
  }

  // ___________________________________________________________________________
  /**
   * This reserveTasksFromWorkQueueForUser reserves work queue tasks for user
   *
   * @param key -
   * ReserveWorkQueueTasksForUserDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void reserveTasksFromWorkQueueForUser(
    final ReserveWorkQueueTasksForUserDetails key)
    throws AppException, InformationalException {

    final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();

    final WorkQueue workQueue = WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dtls.workQueueID;
    final WorkQueueDtls workQueueDtls = workQueue.read(workQueueKey);

    final String supervisorUserName = TransactionInfo.getProgramUser();

    if (!workQueueDtls.administratorUserName.equals(supervisorUserName)) {
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = supervisorUserName;

      final UsersDtls usersDtls = usersObj.read(usersKey);
      final int supervisorSensitivity =
        Integer.parseInt(usersDtls.sensitivity);
      final int workQueueSensitivity =
        Integer.parseInt(workQueueDtls.sensitivity);

      // If Work queue sensitivity more than supervisor sensitivity throw
      // exception
      if (workQueueSensitivity > supervisorSensitivity) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_SENSITIVITY_MISMATCH),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
      // If subscriptions are not allowed to the work queue
      if (!workQueueDtls.allowUserSubscriptionInd) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_NO_ALLOW_SUBSCRIPTION_INDICATOR),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            2);
      }
    }

    userWorkspaceObj.reserveWorkQueueTasksForUser(key.dtls);

  }

  // ___________________________________________________________________________
  /**
   * This subscribeUserToWorkqueue subscribes a user to work queue
   *
   * @param key -
   * SubscribeUserWorkQueueKey
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public void subscribeUserToWorkqueue(final SubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final UserSubscriptionToWorkQueueDetails userSubscriptionToWorkQueueDetails =
      new UserSubscriptionToWorkQueueDetails();
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKeyObj = new WorkQueueKey();
    WorkQueueDtls workQueueDtlsObj = new WorkQueueDtls();

    /*
     * BEGIN, CR00021818, SS
     */
    validateSubscribe(key);

    /*
     * END, CR00021818
     */

    workQueueKeyObj.workQueueID = key.workQueueID;
    workQueueDtlsObj = workQueueObj.read(workQueueKeyObj);

    userSubscriptionToWorkQueueDetails.userName = key.userName;
    userSubscriptionToWorkQueueDetails.workQueueID = key.workQueueID;
    userSubscriptionToWorkQueueDetails.workQueueName = workQueueDtlsObj.name;

    userWorkspaceObj
      .subscribeUserToWorkQueue(userSubscriptionToWorkQueueDetails);

  }

  // ___________________________________________________________________________
  /**
   * Lists the work queue details for the specified user.
   *
   * @param key The details required to identify the user.
   *
   * @return The work queue details for the specified user.
   */
  public ListUserWorkQueueDetails
    readSubscribeUserWorkQueueList(final ListUserWorkQueueDetailsKey key)
      throws AppException, InformationalException {

    // TODO Auto-generated method stub
    return null;
  }

  // ___________________________________________________________________________
  /**
   * This reallocateTasksReservedByUser Reallocates the tasks reserved by user
   *
   * @param key -
   * ReallocateTasksReservedByUserKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    reallocateTasksReservedByUser(final ReallocateTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final ReallocateTaskDetails reallocateTaskDetails =
      new ReallocateTaskDetails();

    final StringList deferredTaskIDKeyList =
      StringUtil.delimitedText2StringList(key.deferredTaskIDs, '\t');

    final StringList openTaskIDKeyList =
      StringUtil.delimitedText2StringList(key.openTaskIDs, '\t');

    // Check task selection is empty
    if (deferredTaskIDKeyList.size() == 0 && openTaskIDKeyList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSUPERVISORUSER.SUPERVISOR_REALLOCATE_TASKS_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    reallocateTaskDetails.comments = key.comments;

    for (int i = 0; i < deferredTaskIDKeyList.size(); i++) {

      reallocateTaskDetails.taskID =
        Long.parseLong(deferredTaskIDKeyList.item(i));
      validateAndReallocateTask(key, reallocateTaskDetails);

    }

    for (int i = 0; i < openTaskIDKeyList.size(); i++) {

      reallocateTaskDetails.taskID =
        Long.parseLong(openTaskIDKeyList.item(i));
      validateAndReallocateTask(key, reallocateTaskDetails);

    }
  }

  // ___________________________________________________________________________
  /**
   * This reserveAssignedTasksToUser reserves assigned tasks to user
   *
   * @param key -
   * ReserveAssignedTasksToUser
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void reserveAssignedTasksToUser(final ReserveAssignedTasksToUser key)
    throws AppException, InformationalException {

    // create TaskManagement Obj
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();

    taskManagement.reserve(key.reserveTasksToUser);

  }

  // ___________________________________________________________________________
  /**
   * Validates the work queue Reserve Next Work Queue Task details. Added for
   * CR00021818 by SS
   *
   * @param key
   * ReserveNextWorkQueueTaskKey Work queue un-subscription details
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReserve(
    final curam.supervisor.sl.struct.ReserveNextWorkQueueTaskKey key)
    throws AppException, InformationalException {

    // Work Queue manipulation variables
    final curam.core.sl.entity.intf.WorkQueue workQueueObj =
      curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();
    WorkQueueDtls workQueueDtls;

    // Set key to read workQueue
    workQueueKey.workQueueID = key.workQueueID;

    // Read workQueue
    workQueueDtls = workQueueObj.read(workQueueKey);

    // Users manipulation variables
    final UsersKey userKey = new UsersKey();

    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode userSensitivityCode =
      UserAccessFactory.newInstance().readSensitivityCodeForUser(userKey);
    // END, CR00098617

    final int userSensitivity =
      Integer.parseInt(userSensitivityCode.sensitivity);

    // BEGIN, CR00145751, SS
    // Check with WorkQueue's and user's sensitivity level,
    // WorkQueue's user subscription option should be true.

    if (Integer.parseInt(workQueueDtls.sensitivity) > userSensitivity) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_SENSITIVITY_MISMATCH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    } else if (!workQueueDtls.allowUserSubscriptionInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_NO_ALLOW_SUBSCRIPTION_INDICATOR),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00145751
  }

  // ___________________________________________________________________________
  /**
   * Validates the work queue un-subscription details. Added for CR00021818 by
   * SS
   *
   * @param key
   * SubscribeUserWorkQueueKey Work queue un-subscription details
   * @throws InformationalException
   * @throws AppException
   */
  public void validateSubscribe(final SubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue manipulation variables
    final curam.core.sl.entity.intf.WorkQueue workQueueObj =
      curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    // Set key to read workQueue
    workQueueKey.workQueueID = key.workQueueID;

    // Users manipulation variables
    final UsersKey userKey = new UsersKey();

    userKey.userName =
      curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00098617, VM
    final curam.core.struct.SensitivityCode userSensitivityCode =
      UserAccessFactory.newInstance().readSensitivityCodeForUser(userKey);
    // END, CR00098617

    final int userSensitivity =
      Integer.parseInt(userSensitivityCode.sensitivity);

    // Retrieve the sensitivity level for the specified work queue.
    WorkQueueSensitivityAndAllowUserSubscriptionDetails details =
      new WorkQueueSensitivityAndAllowUserSubscriptionDetails();

    details =
      workQueueObj.readSensitivityLevelAndAllowUserSubscriptionByWorkQueueID(
        workQueueKey);
    final int workQueueSensitivity = Integer.parseInt(details.sensitivity);

    // Check with WorkQueue sensitivity level and supervisor sensitivity level
    if (workQueueSensitivity > userSensitivity) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSUPERVISORUSER.SUPERVISOR_SUBSCRIBE_SUPERVISOR_SENSITIVITY_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This blockTaskAllocationForUser blocks task allocation for user
   *
   * @param key -
   * TaskAllocationBlockingCreateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    blockTaskAllocationForUser(final TaskAllocationBlockingCreateDetails key)
      throws AppException, InformationalException {

    // UserWorkspace object
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();

    validateBlockTaskAllocation(key);
    userWorkspaceObj.blockTaskAllocationForUser(key);
  }

  // ___________________________________________________________________________
  /**
   * Reassigns the case for Organization Object. The new case owner is inserted
   * the CaseUser-Role entity Any tasks assigned to or reserved by the current
   * case owner, are forwarded to the new owner. A notification is sent to the
   * user to whom the case is reassigned, with the subject "You have been
   * assigned the <Role> on <Case Ref No> by <Full User Name of supervisor>"
   *
   * @param key -
   * ReassignCasesForUserKey (Identifies user and case details for
   * reassignment)
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void
    reassignCasesForOrganisationObject(final ReassignCasesForUserKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00351910, IBM
    final BulkCaseReassignmentInputKey caseReassignmentKey =
      new BulkCaseReassignmentInputKey();

    caseReassignmentKey.autoReassign = key.autoReassign;
    caseReassignmentKey.currentUserID = key.currentUserID;
    caseReassignmentKey.newUserID = key.newUserID;
    caseReassignmentKey.organisationObject = key.organisationObject;
    caseReassignmentKey.OrgObjLinkDtls = key.OrgObjLinkDtls;
    caseReassignmentKey.reassignCasesList = key.reassignCasesList;
    caseReassignmentKey.supervisorUserID = key.supervisorUserID;
    caseReassignmentKey.operationInitiatedBy =
      TransactionInfo.getProgramUser();

    final BulkCaseReassignmentProcess bulkCaseReassignmentProcess =
      BulkCaseReassignmentProcessFactory.newInstance();

    bulkCaseReassignmentProcess.reassign(caseReassignmentKey);

    // END, CR00351910
  }

  // ___________________________________________________________________________
  /**
   * This validateBlockTaskAllocation validates the block task allocation
   * details for user
   *
   * @param key -
   * TaskAllocationBlockingCreateDetails
   * @throws InformationalException
   * @throws AppException
   */
  protected void
    validateBlockTaskAllocation(final TaskAllocationBlockingCreateDetails key)
      throws AppException, InformationalException {

    final curam.supervisor.facade.intf.MaintainSupervisorUsers maintainSupUser =
      MaintainSupervisorUsersFactory.newInstance();
    final UserNameKey userNamekey = new UserNameKey();
    DateTime date;

    date = DateTime.getCurrentDateTime();

    // BEGIN, CR00161962, BK
    // start date and time must be entered..
    if (key.startDateTime.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_START_DATE_TIME_NOT_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00161962
    // Start date and time must be in the future.
    if (key.startDateTime.before(date)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_START_DATE_TIME_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // This validation is not executed unless there is an end date time
    // specified.
    // End date and time must be later than the start date and time.
    if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
      if (key.endDateTime.before(key.startDateTime)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_END_DATE_TIME_CHECK),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // The time period of the task allocation block must not overlap with any
    // current or pending
    // task allocation block.
    userNamekey.userName = key.fromUserName;
    final AllTaskAllocationBlockingPeriodsForUserDetailsList allTaskAllocationBlockingPeriodsForUserDetails =
      maintainSupUser.listTaskAllocationBlockingHistoryForUser(userNamekey);

    final int numOfActiveAndPendingTaskAllocBlockingPeriodsForUser =
      allTaskAllocationBlockingPeriodsForUserDetails.allAllocationDetailsList.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
        .size();

    for (int i =
      0; i < numOfActiveAndPendingTaskAllocBlockingPeriodsForUser; i++) {
      TaskAllocationBlockingDetails taskAllocationBlockingDetails =
        new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails =
        allTaskAllocationBlockingPeriodsForUserDetails.allAllocationDetailsList.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
          .item(i);

      if (!taskAllocationBlockingDetails.endDateTime
        .equals(DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.startDateTime
            .before(taskAllocationBlockingDetails.startDateTime)) {

            if (key.endDateTime
              .after(taskAllocationBlockingDetails.startDateTime)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory
                .getManager().throwWithLookup(
                  new AppException(
                    curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_CHECK),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  2);
            } else {// continue;
            }
          } else {
            if (taskAllocationBlockingDetails.endDateTime
              .before(key.startDateTime)) {// continue;
            } else {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory
                .getManager().throwWithLookup(
                  new AppException(
                    curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_CHECK),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  4);
            }
          }
        } // key end date time is blank
        else {
          if (taskAllocationBlockingDetails.endDateTime
            .before(key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_CHECK),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime
            .before(taskAllocationBlockingDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_CHECK),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_CHECK),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              3);
        }
      }
    }

    // The time period of the task allocation block must not overlap with any
    // current or pending
    // task redirections.
    userNamekey.userName = key.fromUserName;
    // BEGIN, CR00225492 MN
    final UserTasksRedirectionHistoryDetailsList tasksRedirectionHistoryDetailsList =
      listTaskRedirectionHistory(userNamekey);
    // END, CR00225492

    final int numOfTasksRedirectionHistoryDetails =
      tasksRedirectionHistoryDetailsList.redirectionDetailsList.activeAndPendingTaskRedirections.activeAndPendingDtls
        .size();

    for (int i = 0; i < numOfTasksRedirectionHistoryDetails; i++) {
      curam.core.sl.supervisor.struct.RedirectTaskDetails tasksRedirectionDetails =
        new curam.core.sl.supervisor.struct.RedirectTaskDetails();

      // BEGIN, CR00225492 MN
      tasksRedirectionDetails =
        tasksRedirectionHistoryDetailsList.redirectionDetailsList.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails
          .item(i);
      // END, CR00225492

      if (!tasksRedirectionDetails.endDateTime
        .equals(DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.startDateTime
            .before(tasksRedirectionDetails.startDateTime)) {

            if (key.endDateTime
              .after(tasksRedirectionDetails.startDateTime)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory
                .getManager().throwWithLookup(
                  new AppException(
                    curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_WITH_TASK_REDIRECTION_CHECK),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  4);
            } else {// continue;
            }
          } else {
            if (tasksRedirectionDetails.endDateTime
              .before(key.startDateTime)) {// continue;
            } else {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory
                .getManager().throwWithLookup(
                  new AppException(
                    curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_WITH_TASK_REDIRECTION_CHECK),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  1);
            }
          }
        } // key end date time is blank
        else {
          if (tasksRedirectionDetails.endDateTime.before(key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_WITH_TASK_REDIRECTION_CHECK),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime.before(tasksRedirectionDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_WITH_TASK_REDIRECTION_CHECK),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                2);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                curam.message.BPOSUPERVISORUSER.SUPERVISOR_TASK_ALLOCATION_BLOCK_NO_OVERLAP_WITH_TASK_REDIRECTION_CHECK),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              3);
        }
      }

    }
  }

  // ___________________________________________________________________________
  /**
   * This validateTaskRedirection validates the task redirection details for
   * user
   *
   * @param key -
   * TaskRedirectionDetails
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0, this method is no longer referenced, there is
   * no replacement method. See release note CR00225257.
   */
  @Deprecated
  protected void validateTaskRedirection(
    final curam.supervisor.sl.struct.TaskRedirectionDetails key)
    throws AppException, InformationalException {

    final curam.supervisor.facade.intf.MaintainSupervisorUsers maintainSupUser =
      MaintainSupervisorUsersFactory.newInstance();
    final UserNameKey userNamekey = new UserNameKey();

    // The time period of the task redirection block must not overlap with any
    // current or pending task allocation block.
    userNamekey.userName = key.fromUserName;
    final AllTaskAllocationBlockingPeriodsForUserDetailsList allTaskAllocationBlockingPeriodsForUserDetails =
      maintainSupUser.listTaskAllocationBlockingHistoryForUser(userNamekey);

    final int numOfActiveAndPendingTaskAllocBlockingPeriodsForUser =
      allTaskAllocationBlockingPeriodsForUserDetails.allAllocationDetailsList.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
        .size();

    for (int i =
      0; i < numOfActiveAndPendingTaskAllocBlockingPeriodsForUser; i++) {
      TaskAllocationBlockingDetails taskAllocationBlockingDetails =
        new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails =
        allTaskAllocationBlockingPeriodsForUserDetails.allAllocationDetailsList.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
          .item(i);

      if (!taskAllocationBlockingDetails.endDateTime
        .equals(DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is blank
          if (taskAllocationBlockingDetails.endDateTime
            .before(key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                4);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime
            .before(taskAllocationBlockingDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                3);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              5);
        }
      }
    }

    // The time period of the task redirection block must not overlap with any
    // current or pending task redirections.
    userNamekey.userName = key.fromUserName;
    final curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList tasksRedirectionHistoryDetailsList =
      listUserTaskRedirectionHistory(userNamekey);

    final int numOfTasksRedirectionHistoryDetails =
      tasksRedirectionHistoryDetailsList.redirectionDetailsList.activeAndPendingTaskRedirections.activeAndPendingDtls
        .size();

    for (int i = 0; i < numOfTasksRedirectionHistoryDetails; i++) {
      curam.core.sl.supervisor.struct.TaskRedirectionDetails tasksRedirectionDetails =
        new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

      tasksRedirectionDetails =
        tasksRedirectionHistoryDetailsList.redirectionDetailsList.activeAndPendingTaskRedirections.activeAndPendingDtls
          .item(i);

      if (!tasksRedirectionDetails.endDateTime
        .equals(DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is blank
          if (tasksRedirectionDetails.endDateTime.before(key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                5);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime.before(tasksRedirectionDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().throwWithLookup(
                new AppException(
                  curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                3);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                curam.message.BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              4);
        }
      }

    }
  }

  // ___________________________________________________________________________
  /**
   * This validateAndForwardTask validates and forwards the selected tasks
   *
   * @param key -
   * SupervisorTaskForwardDetails
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void
    validateAndForwardTask(final SupervisorTaskForwardDetails key)
      throws AppException, InformationalException {

    // END, CR00198672
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithoutSnapshot taskSummaryDetails =
      taskObj.readDetails(key.forwardTaskDetails.taskID);

    if (taskSummaryDetails.status.equals(curam.codetable.TASKSTATUS.CLOSED)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_FORWARD_RESERVED_USERTASKS_CLOSED);

      ae.arg(key.forwardTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if (!taskSummaryDetails.reservedBy.equals(key.userName)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_FORWARD_RESERVED_USERTASKS_NOT_RESERVED);

      ae.arg(key.forwardTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    taskManagement.forward(key.forwardTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * This validateAndReallocateTask validates and reallocates the tasks reserved
   * by user
   *
   * @param key -
   * ReallocateTasksReservedByUserKey
   * @param reallocateTaskDetails -
   * ReallocateTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void validateAndReallocateTask(
    final ReallocateTasksReservedByUserKey key,
    final ReallocateTaskDetails reallocateTaskDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithoutSnapshot taskReservedByDetails =
      taskAdminObj.readDetails(reallocateTaskDetails.taskID);

    if (taskReservedByDetails.status.equals(TASKSTATUS.CLOSED)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_SELECTED_TASK_MUST_NOT_BE_CLOSED);

      ae.arg(reallocateTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    if (!taskReservedByDetails.reservedBy.equals(key.userName)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_SELECTED_TASK_MUST_BE_RESERVED_BY_USER);

      ae.arg(reallocateTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    taskManagement.reallocate(reallocateTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * This getNumberOfDaysInWeek returns the no of days in a week
   *
   * @return int - no of days In a week
   */
  // BEGIN, CR00198672, VK
  protected int getNumberOfDaysInWeek() {

    // END, CR00198672
    final String noOfDaysInaWeekString = curam.util.resources.Configuration
      .getProperty(EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK);

    int noOfDaysInaWeek = 0;

    if (noOfDaysInaWeekString == null) {
      noOfDaysInaWeek = EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK_DEFAULT;
    } else {
      noOfDaysInaWeek = Integer.parseInt(noOfDaysInaWeekString);
    }
    return noOfDaysInaWeek;
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param userNameKey -
   * UserNameKey,
   * @param detailsList -
   * UserTasksDueInTheNextTimePeriodDetailsList
   * @param taskOptionCode -
   * String
   * @return String - of bar chart xml values
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromDetailsList(
    final UserNameKey userNameKey,
    final UserTasksDueInTheNextTimePeriodDetailsList detailsList,
    final String taskOptionCode) throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // set user name to get the user full name
    usersKey.userName = userNameKey.userName;
    final UserFullname userFullName = userAccessObj.getFullName(usersKey);
    final String fullName = userFullName.fullname;
    final int listSize = detailsList.dtls.size();

    // BEGIN, CR00219204, SW

    // BEGIN, CR00263925, ZV
    // sort user task details list by deadline date
    final Comparator<UserTasksDueInTheNextTimePeriodDetails> taskDetailsComparator =
      new UserTaskDetailsComparator();

    Collections.sort(detailsList.dtls, taskDetailsComparator);
    // END, CR00263925

    // BEGIN, CR00263925, ZV
    for (int i = 0; i < listSize; i++) {
      // END, CR00263925

      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      // END, CR00219204

      // BEGIN, CR00335706, MR
      captionElement.setAttribute(kText,
        detailsList.dtls.item(i).deadlineDate.toString());
      // END, CR00335706

      // BEGIN, CR00124642, GSP
      captionElement.setAttribute(kStartDate,
        curam.util.resources.Locale
          .getFormattedDate(detailsList.dtls.item(i).deadlineDate,
            kGanttDateFormat)
          .toString());
      // END, CR00124642
      captionElement.setAttribute(kID, userNameKey.userName);
      captionElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.ALL);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      captionElement.setAttribute(kFullName, fullName);
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kID, userNameKey.userName);
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      blockElement.setAttribute(kLength,
        detailsList.dtls.item(i).taskReservedCount + GeneralConstants.kEmpty);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kFullName, fullName);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale
          .getFormattedDate(detailsList.dtls.item(i).deadlineDate,
            kGanttDateFormat)
          .toString());
      // END, CR00124642

      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kID, userNameKey.userName);

      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      blockElement.setAttribute(kLength,
        detailsList.dtls.item(i).taskAssignedCount + GeneralConstants.kEmpty);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kFullName, fullName);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale
          .getFormattedDate(detailsList.dtls.item(i).deadlineDate,
            kGanttDateFormat)
          .toString());
      // END, CR00124642
      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return GeneralConstants.kEmpty;
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // ___________________________________________________________________________
  // BEGIN, CR00161962, BK
  /**
   * This method reallocates the not reserved tasks by the supervisor.
   *
   * @param key -
   * ReallocateTaskIDDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public InformationalMsgDetailsList
    reallocateTasksNotReservedByUser(final ReallocateTaskIDDetails dtls)
      throws AppException, InformationalException {

    final InformationalMsgDetailsList informationalMsgDetailsList =
      new InformationalMsgDetailsList();
    final ReallocateTaskDetails reallocateTaskDetails =
      new ReallocateTaskDetails();

    final StringList assignedTaskList =
      StringUtil.delimitedText2StringList(dtls.assignedTaskIDList, '\t');

    // Check task selection is empty
    if (assignedTaskList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSUPERVISORUSER.SUPERVISOR_REALLOCATE_TASKS_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    reallocateTaskDetails.comments = dtls.comments;

    InformationalManager informationalManager = null;
    curam.core.struct.InformationalMsgDtls informationalMsgDtls = null;

    for (int i = 0; i < assignedTaskList.size(); i++) {

      reallocateTaskDetails.taskID = Long.parseLong(assignedTaskList.item(i));
      informationalManager =
        validateAndReallocateNotReservedTask(reallocateTaskDetails);

      // add any informational messages to the return struct
      final String[] reallocatedTasksMessages =
        informationalManager.obtainInformationalAsString();

      for (int j = 0; j < reallocatedTasksMessages.length; j++) {
        informationalMsgDtls = new curam.core.struct.InformationalMsgDtls();
        informationalMsgDtls.informationMsgTxt = reallocatedTasksMessages[j];

        informationalMsgDetailsList.informationalMsgDtlsList.dtls
          .addRef(informationalMsgDtls);
      }

    }
    return informationalMsgDetailsList;

  }

  // BEGIN, CR00188841, PDN
  // __________________________________________________________________________
  /**
   * This method reads the details for a user tab panel.
   *
   * @param key -
   * SupervisorUserTabKey which contains the userName
   * @return SupervisorUserTabDetails - the details for the tab panel
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public SupervisorUserTabDetails
    readSupervisorUserTabDetails(final SupervisorUserTabKey key)
      throws AppException, InformationalException {

    final Users usersObj = UsersFactory.newInstance();

    final TabDetailFormatter tabDetailFormatterObj =
      TabDetailFormatterFactory.newInstance();

    final SupervisorUserTabDetails supervisorUserTabDetails =
      new SupervisorUserTabDetails();

    final curam.core.struct.SupervisorUserTabDetails tabDetails =
      usersObj.readSupervisorUserTabDetails(key);

    // assign the details
    supervisorUserTabDetails.assign(tabDetails);

    if (tabDetails.phoneNumberID != 0) {

      final PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = tabDetails.phoneNumberID;

      supervisorUserTabDetails.phoneNumber = tabDetailFormatterObj
        .formatPhoneNumber(phoneNumberKey).phoneNumberString;
    }

    // Get the user full name
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = tabDetails.userName;

    supervisorUserTabDetails.userFullName =
      tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

    // Get the redirection user full name if one exists
    if (tabDetails.toUserName.length() > 0) {
      usersKey.userName = tabDetails.toUserName;

      supervisorUserTabDetails.toUserFullName =
        tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

      supervisorUserTabDetails.toRedirectStringID = tabDetails.toUserName;
    } else {
      supervisorUserTabDetails.toRedirectStringID =
        String.valueOf(tabDetails.toRedirectID);
    }

    // Set the available for allocation
    if (tabDetails.blockTaskAllocation) {
      supervisorUserTabDetails.availableForTaskAlocation = false;
    } else {
      supervisorUserTabDetails.availableForTaskAlocation = true;
    }

    return supervisorUserTabDetails;
  }

  // END, CR00188841

  // ___________________________________________________________________________
  /**
   * This method validates and reallocates the tasks not
   * reserved by user
   *
   * @param reallocateTaskDetails -
   * ReallocateTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected InformationalManager validateAndReallocateNotReservedTask(
    final ReallocateTaskDetails reallocateTaskDetails)
    throws AppException, InformationalException {

    // END, CR00198672
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final InformationalManager informationalManager =
      new InformationalManager();
    final TaskAdmin taskObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithoutSnapshot taskDtls =
      taskObj.readDetails(reallocateTaskDetails.taskID);

    // Check whether the task is closed
    if (taskDtls.status.equals(TASKSTATUS.CLOSED)) {
      final AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_SELECTED_TASK_MUST_NOT_BE_CLOSED);

      ae.arg(reallocateTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(ae,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // Reallocate the task
    taskManagement.reallocate(reallocateTaskDetails);

    final AppException appException =
      new AppException(BPOTASKMANAGEMENT.TASKS_REALLOCATED_SUCCESSFULLY);

    appException.arg(reallocateTaskDetails.taskID);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
      .addInfoMgrExceptionWithLookup(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    return informationalManager;
  }

  // ___________________________________________________________________________
  /**
   * This function parses the Tab-delimited string in to a list of Strings
   *
   * @param key
   * Tab-delimited string list of caseID's
   * @return StringList
   */
  // BEGIN, CR00198672, VK
  protected StringList parseCaseIDList(final ReassignCasesForUserKey key) {

    // END, CR00198672
    StringList stringList = new StringList();

    // Convert the tab delimited string to a list of strings
    stringList = StringUtil.tabText2StringList(key.reassignCasesList);
    return stringList;

  }

  // BEGIN, CR00216252 MN
  // BEGIN, CR00280640, DJ
  /**
   * This method is used to read the user and also other member's workspace
   * details.
   *
   * @param key Contains the user name.
   *
   * @return The user workspace details.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #readSupervisorWorkSpaceContentMonthDetails(UserNameKey)}.
   * This method is deprecated because the return struct parameter
   * does not contain the attribute for informational messages. See
   * release note: CR00280640.
   */
  @Override
  @Deprecated
  // END, CR00280640
  public SupervisorUserWorkspaceDetails readSupervisorWorkspaceMonthDetails(
    final UserNameKey key) throws AppException, InformationalException {

    // Creating UserWorkspace Details object
    final SupervisorUserWorkspaceDetails userWorkspaceDetails =
      new SupervisorUserWorkspaceDetails();
    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();

    final UserTasksDueInTheNextMonthKey monthKey =
      new UserTasksDueInTheNextMonthKey();
    final Organisation organisation = OrganisationFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    // assigning key values
    monthKey.userName = key.userName;
    // BEGIN, CR00274837 ZV
    monthKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    monthKey.numberOfWeeks = kNumberOfWeeks;

    final UserTasksDueInTheNextTimePeriodDetailsList detailsList =
      userWorkspace.countUserTasksDueInTheNextMonth(monthKey);

    userWorkspaceDetails.userWorkspaceChartXMLString =
      constructBarChartFromDetailsList(key, detailsList,
        VIEWTASKSOPTION.NEXTMONTH);
    userWorkspaceDetails.userDetails = readSupervisorDetails(key);

    final UserWorkQueueDetailsList userWorkQueueDetailsListObj =
      userWorkspace.listWorkQueuesForUser(usersKey);

    userWorkspaceDetails.workQueueSubscription = userWorkQueueDetailsListObj;

    final UserOrgStructStatusCodeKey userOrgStructStatusCodeKey =
      new UserOrgStructStatusCodeKey();

    userOrgStructStatusCodeKey.userName = usersKey.userName;
    userOrgStructStatusCodeKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
    userWorkspaceDetails.orgDetailsList = organisation
      .readOrgIDOrgNameAndPositionByUserName(userOrgStructStatusCodeKey);

    return userWorkspaceDetails;
  }

  // BEGIN, CR00280640, DJ
  /**
   * This method is used to read the user and also other member's workspace
   * details.
   *
   * @param key Contains the user name.
   *
   * @return The user workspace details.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #readSupervisorWorkSpaceContentWeekDetails(UserNameKey)}.
   * This method is deprecated because the return struct parameter
   * does not contain the attribute for informational messages. See
   * release note: CR00280640.
   */
  @Override
  @Deprecated
  // END, CR00280640
  public SupervisorUserWorkspaceDetails readSupervisorWorkspaceWeekDetails(
    final UserNameKey key) throws AppException, InformationalException {

    // Creating UserWorkspaceDetails object
    final SupervisorUserWorkspaceDetails userWorkspaceDetails =
      new SupervisorUserWorkspaceDetails();
    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();

    final UserTasksDueInTheNextWeekKey weekKey =
      new UserTasksDueInTheNextWeekKey();
    final Organisation organisation = OrganisationFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    // assigning key values
    weekKey.userName = key.userName;
    // BEGIN, CR00274837 ZV
    weekKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    weekKey.numberOfDays = getNumberOfDaysInWeek();

    final UserTasksDueInTheNextTimePeriodDetailsList detailsList =
      userWorkspace.countUserTasksDueInTheNextWeek(weekKey);

    userWorkspaceDetails.userWorkspaceChartXMLString =
      constructBarChartFromDetailsList(key, detailsList,
        VIEWTASKSOPTION.NEXTWEEK);
    userWorkspaceDetails.userDetails = readSupervisorDetails(key);

    final UserWorkQueueDetailsList userWorkQueueDetailsListObj =
      userWorkspace.listWorkQueuesForUser(usersKey);

    userWorkspaceDetails.workQueueSubscription = userWorkQueueDetailsListObj;
    final UserOrgStructStatusCodeKey userOrgStructStatusCodeKey =
      new UserOrgStructStatusCodeKey();

    userOrgStructStatusCodeKey.userName = usersKey.userName;
    userOrgStructStatusCodeKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
    userWorkspaceDetails.orgDetailsList = organisation
      .readOrgIDOrgNameAndPositionByUserName(userOrgStructStatusCodeKey);

    return userWorkspaceDetails;
  }

  /**
   * This readUserDetails returns user details for User Workspace
   *
   * @param key
   * - UserNameKey
   * @return UserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public SupervisorDetails readSupervisorDetails(final UserNameKey key)
    throws AppException, InformationalException {

    final SupervisorDetails userDetails = new SupervisorDetails();

    EmailAddressDtls userEmailAddressDtls = new EmailAddressDtls();

    // Maintain Phone Number obj to get Phone number
    final curam.core.intf.MaintainPhoneNumber maintainPhoneNumberObj =
      curam.core.fact.MaintainPhoneNumberFactory.newInstance();
    final GetPhoneNumberKey getPhoneNumberKey = new GetPhoneNumberKey();
    PhoneNumberDetails phoneNumberDetails = new PhoneNumberDetails();

    // to get the current task redirected user name
    final curam.core.sl.intf.TaskRedirection taskRedirection =
      curam.core.sl.fact.TaskRedirectionFactory.newInstance();

    final UserNameAndDateTimeKey userNameAndDateTimeKey =
      new UserNameAndDateTimeKey();

    userNameAndDateTimeKey.userName = key.userName;

    userNameAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();

    // If there is an active task redirection period in place, then retrieve
    // the name of the user to whom the tasks will be redirected to.
    // BEGIN, CR00225492 MN
    TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails =
      new TaskRedirectionOrAllocationBlockingPeriodDetails();

    activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails =
      taskRedirection.readTaskRedirectionOrAllocationBlockingPeriodForUser(
        userNameAndDateTimeKey);
    // END, CR00225492

    // creating users Object
    final curam.core.intf.Users usersObj = UsersFactory.newInstance();
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    final UsersDtls usersDtls = usersObj.read(usersKey);

    if (usersDtls.businessEmailID != 0) {
      // get the Email address
      final EmailAddress emailAddress = EmailAddressFactory.newInstance();
      final EmailAddressKey emailAddressKey = new EmailAddressKey();

      emailAddressKey.emailAddressID = usersDtls.businessEmailID;
      userEmailAddressDtls = emailAddress.read(emailAddressKey);
    }

    if (usersDtls.businessPhoneID != 0) {
      // get the ID for the phone record inserted
      getPhoneNumberKey.phoneNumberID = usersDtls.businessPhoneID;
      phoneNumberDetails =
        maintainPhoneNumberObj.readPhoneNumber(getPhoneNumberKey);
    }
    userDetails.userName = key.userName;
    userDetails.userEmail = userEmailAddressDtls.emailAddress;
    userDetails.phoneNumber = phoneNumberDetails.phoneNumber;
    userDetails.phoneAreaCode = phoneNumberDetails.phoneAreaCode;
    userDetails.phoneCountryCode = phoneNumberDetails.phoneCountryCode;
    userDetails.userFullName = userAccessObj.getFullName(usersKey).fullname;
    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails != null) {
      if (!activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.blockTaskAllocation) {
        usersKey.userName =
          activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName;
        userDetails.taskRedirectedUserName = usersKey.userName;

        // target Object name
        userDetails.tasksRedirectedTo = readTargetObjectName(
          activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails);

        // Redirect Type - Job, OrgUnit, WorkQueue, Position or Job
        userDetails.toRedirectType =
          activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectType;
        // if task is redirected to a user, use toUserName field.
        // Otherwise, use
        // toRedirectID

        if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName
          .length() > 0) {
          userDetails.toRedirectID =
            activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName;
        } else {

          userDetails.toRedirectID = String.valueOf(
            activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toRedirectID);
        }
      }
    }

    userDetails.userEmailLink = kMailLink + userEmailAddressDtls.emailAddress;

    return userDetails;
  }

  // END, CR00216252 MN
  // BEGIN, CR00216807 MN

  /**
   * This method lists the redirected tasks records for the user as
   * well as other members.
   *
   * @param key -
   * UserNameKey
   * @return TasksRedirectionHistoryDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public UserTasksRedirectionHistoryDetailsList listTaskRedirectionHistory(
    final UserNameKey key) throws AppException, InformationalException {

    // User workspace Object
    final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();

    // Return Object
    final UserTasksRedirectionHistoryDetailsList detailsList =
      new UserTasksRedirectionHistoryDetailsList();
    final UserNameAndDateTimeKey userNameAndDateTimeKey =
      new UserNameAndDateTimeKey();

    // Assign the key values
    userNameAndDateTimeKey.userName = key.userName;

    userNameAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();

    final TaskRedirectionsFromUserDetails redirectionsFromUserDetails =
      userWorkspaceObj
        .getTaskRedirectionHistoryForUser(userNameAndDateTimeKey);

    detailsList.redirectionDetailsList = redirectionsFromUserDetails;

    return detailsList;
  }

  // END, CR00216807
  // __________________________________________________________________________
  // BEGIN, CR00225492 MN
  /**
   * This method redirects the tasks assignment between users and members
   * other than users for a specified time period.
   *
   * @param key -
   * TaskRedirectionDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void taskRedirectionsToUser(final UserTaskRedirectionDetails key)
    throws AppException, InformationalException {

    // User workspace Object
    final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();
    final TaskRedirectionsForUserDetails redirectTasksForUserDetails =
      new TaskRedirectionsForUserDetails();

    redirectTasksForUserDetails.fromUserName = key.fromUserName;
    redirectTasksForUserDetails.toUserName = key.toUserName;
    redirectTasksForUserDetails.toUserNameInSupervisorGroup =
      key.toUserNameInSupervisorGroup;
    redirectTasksForUserDetails.startDateTime = key.startDateTime;
    redirectTasksForUserDetails.endDateTime = key.endDateTime;
    redirectTasksForUserDetails.toRedirectID = key.toRedirectID;
    redirectTasksForUserDetails.toRedirectType = key.toRedirectType;

    userWorkspaceObj.taskRedirectionsForUser(redirectTasksForUserDetails);
  }

  // END, CR00225492

  // BEGIN, CR00247543, AK
  /**
   * Creates a work queue subscription. The validations that are executed here
   * are:
   * <ul>
   * <li>The work queue being subscribed to must have an administrator specified
   * for it.
   * <li>Ensure that user subscription is allowed for the work queue.
   * <li>Ensure that the subscriber identifier and name if specified are correct
   * with respect to the specified subscriber type.
   * <li>If a user is being subscribed to the specified work queue, ensure that
   * the sensitivity of that user matches that of the work queue being
   * subscribed to.
   * <li>If a user is being subscribed to the specified work queue, ensure that
   * the user does not have a status of <code>closed</code>.
   * <li>Ensure that the subscriber being subscribed to the work queue is not
   * already subscribed to that work queue.
   * </ul>
   *
   * @param details The details required to create a work queue subscription.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOWORKQUEUESUBSCRIPTION. ERR_WORK_QUEUE_SUBSCRIPTION_XRV_NO_ADMIN_USER_EXISTS}
   * - if no administrator user exist for the work queue.
   * {@link BPOWORKQUEUESUBSCRIPTION. ERR_WORK_QUEUE_SUBSCRIPTION_XRV_USERSUBS_NOT_ALLOWED}
   * - if the allow user subscription indicator on the work queue is
   * false.
   */
  @Override
  public void
    subscribeOrgObjectToWorkqueue(final WorkQueueSubscriptionDetails details)
      throws AppException, InformationalException {

    // Work Queue Subscription entity objects
    final WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.entity.fact.WorkQueueSubscriptionFactory.newInstance();

    // Work Queue manipulation variables
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();
    WorkQueueDtls workQueueDtls;

    // Validate the subscriber Name/ID and Type
    validateSubscriberIDAndType(details);

    // If subscriber type is not User then parse the subscriber Name
    // as it stores the number in string format
    if (!WQSUBSORGOBJECTTYPE.USER.equals(details.subscriberType)) {
      details.subscriberID = Long.parseLong(details.subscriberNameOrID);
    }

    // Read workQueue
    workQueueKey.workQueueID = details.workQueueID;
    workQueueDtls = workQueueObj.read(workQueueKey);

    // An administrator must exist if a subscription is being added
    if (0 == workQueueDtls.administratorUserName.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOWORKQUEUESUBSCRIPTION.ERR_WORK_QUEUE_SUBSCRIPTION_XRV_NO_ADMIN_USER_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    if (!workQueueDtls.allowUserSubscriptionInd) {
      // BEGIN, CR00441527, VT
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOWORKQUEUESUBSCRIPTION.ERR_WORKQUEUE_SUBSCRIPTION_XRV_NOT_ALLOWED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
      // END, CR00441527
    }

    validateInsertNotAlreadySubscribed(details.workQueueID,
      details.subscriberType, details.subscriberNameOrID,
      details.subscriberID);

    // Sensitivity Check
    final SubscribeUserWorkQueueKey key = new SubscribeUserWorkQueueKey();

    key.workQueueID = details.workQueueID;
    validateSubscribe(key);
    final WorkQueueSubscriptionDtls dtls = new WorkQueueSubscriptionDtls();

    // Populate the user name or subscriber identifier fields.
    if (WQSUBSORGOBJECTTYPE.USER.equals(details.subscriberType)) {
      dtls.userName = details.subscriberNameOrID;
    } else {
      dtls.subscriberID = details.subscriberID;
    }
    // Subscriber type and Work Queue id are copied into dtls
    dtls.subscriberType = details.subscriberType;
    dtls.workQueueID = details.workQueueID;
    dtls.subscriptionDateTime = details.subscriptionDateTime;

    // Call entity operation to insert a work queue subscription
    workQueueSubscriptionObj.insert(dtls);
  }

  /**
   * This method validates whether the subscriber ID and type are valid.
   * For e.g., an organization unit ID should not be used with position or job
   * or user as a value in the Type field.
   *
   * @param details - details of Work Queue subscription
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE} - if the
   * subscriber type entered by the user is not valid.
   */
  protected void
    validateSubscriberIDAndType(final WorkQueueSubscriptionDetails details)
      throws AppException, InformationalException {

    if (0 == details.subscriberNameOrID.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          5);
    }

    if (WQSUBSORGOBJECTTYPE.ORGUNIT.equals(details.subscriberType)) {
      // Check to see if the subscriber Type value is an organization unit
      final OrganisationUnit organisationUnitObj =
        OrganisationUnitFactory.newInstance();
      final OrganisationUnitKey organisationUnitKey =
        new OrganisationUnitKey();

      try {
        // try parse the subscriber type value, if this throws an error it
        // means a user name string value has been passed down
        organisationUnitKey.organisationUnitID =
          Long.parseLong(details.subscriberNameOrID);
      } catch (final NumberFormatException e) {
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }

      try {
        organisationUnitObj.read(organisationUnitKey);

      } catch (final RecordNotFoundException e) {
        // Not an organization unit so throw an exception
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }
    } else if (WQSUBSORGOBJECTTYPE.POSITION.equals(details.subscriberType)) {
      final Position positionObj = PositionFactory.newInstance();
      final PositionKey positionKey = new PositionKey();

      try {
        // try parse the subscriber type value, if this throws an error it
        // means a user name string value has been passed down
        positionKey.positionID = Long.parseLong(details.subscriberNameOrID);

      } catch (final NumberFormatException e) {
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }

      try {
        positionObj.read(positionKey);

      } catch (final RecordNotFoundException e) {
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }
    } else if (WQSUBSORGOBJECTTYPE.JOB.equals(details.subscriberType)) {
      final Job jobObj = JobFactory.newInstance();
      final JobKey jobKey = new JobKey();

      try {
        // try parse the subscriber type value, if this throws an error it means
        // a user name string value has been passed down
        jobKey.jobID = Long.parseLong(details.subscriberNameOrID);
      } catch (final NumberFormatException e) {
        // Not a Job so throw an exception
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }
      try {
        jobObj.read(jobKey);

      } catch (final RecordNotFoundException e) {
        // Not a Job so throw an exception
        throw new AppException(
          BPOTASKMANAGEMENT.ERR_WORKQUEUE_MEMBER_INVALID_TYPE);
      }
    }
  }

  /**
   * Validates the specified subscriber is not already subscribed to the
   * specified work queue when inserting a new work queue subscription
   * record. In this instance, a simple count of the existing work queue
   * subscriptions for that user or organizational object will dictate whether
   * that user or organizational object has already been subscribed to the
   * specified work queue.
   *
   * @param workQueueID The unique identifier of the work queue.
   * @param subscriberType The type of the subscriber to the work queue.
   * @param subscriberName The name of the user that has subscribed
   * to the work queue.
   * @param subscriberID The identifier of the organizational object that has
   * subscribed to the work queue.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOINBOX.ERR_WORK_QUEUE_USER_ALREADY_SUBSCRIBED}
   * {@link BPOINBOX.ERR_WORK_QUEUE_ORGUNIT_ALREADY_SUBSCRIBED}
   * {@link BPOINBOX.ERR_WORK_QUEUE_POSITION_ALREADY_SUBSCRIBED}
   * {@link BPOINBOX.ERR_WORK_QUEUE_JOB_ALREADY_SUBSCRIBED} - if the
   * organization object is already subscribed to the
   * work queue.
   */
  protected void validateInsertNotAlreadySubscribed(final long workQueueID,
    final String subscriberType, final String subscriberName,
    final long subscriberID) throws AppException, InformationalException {

    final WorkQueueSubscription workQueueSubscriptionObj =
      curam.core.sl.entity.fact.WorkQueueSubscriptionFactory.newInstance();
    CountDetails countDetails;
    // key to count work queue subscriptions by user name and work queue
    final UserNameSubscriberAndWorkQueueKey userNameSubscriberAndWorkQueueKey =
      new UserNameSubscriberAndWorkQueueKey();

    // If the subscriber type is a user, check to see if that user is already
    // subscribed to that work queue.
    if (WQSUBSORGOBJECTTYPE.USER.equals(subscriberType)) {

      userNameSubscriberAndWorkQueueKey.userName = subscriberName;
      userNameSubscriberAndWorkQueueKey.workQueueID = workQueueID;
      userNameSubscriberAndWorkQueueKey.subscriberType = subscriberType;
      userNameSubscriberAndWorkQueueKey.searchBySubscriberIDInd =
        userNameSubscriberAndWorkQueueKey.subscriberID != 0;

      // Count the work queue subscriptions by user name and work queue.
      countDetails = workQueueSubscriptionObj
        .countBySubscriberAndWorkQueue(userNameSubscriberAndWorkQueueKey);

      // check if user is subscribed to specified work queue
      if (1 == countDetails.numberOfRecords) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(BPOINBOX.ERR_WORK_QUEUE_USER_ALREADY_SUBSCRIBED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            4);
      }
    } else {
      // If the subscriber type is an organizational object, check to see if
      // that object is already subscribed to that work queue.
      userNameSubscriberAndWorkQueueKey.subscriberID = subscriberID;
      userNameSubscriberAndWorkQueueKey.subscriberType = subscriberType;
      userNameSubscriberAndWorkQueueKey.workQueueID = workQueueID;
      userNameSubscriberAndWorkQueueKey.searchBySubscriberIDInd =
        userNameSubscriberAndWorkQueueKey.subscriberID != 0;
      // count work queue subscriptions by user name and work queue
      countDetails = workQueueSubscriptionObj
        .countBySubscriberAndWorkQueue(userNameSubscriberAndWorkQueueKey);

      if (1 == countDetails.numberOfRecords) {
        if (WQSUBSORGOBJECTTYPE.ORGUNIT.equals(subscriberType)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOINBOX.ERR_WORK_QUEUE_ORGUNIT_ALREADY_SUBSCRIBED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
        } else if (WQSUBSORGOBJECTTYPE.POSITION.equals(subscriberType)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOINBOX.ERR_WORK_QUEUE_POSITION_ALREADY_SUBSCRIBED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
        } else if (WQSUBSORGOBJECTTYPE.JOB.equals(subscriberType)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOINBOX.ERR_WORK_QUEUE_JOB_ALREADY_SUBSCRIBED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
        }
      }
    }
  }

  // END, CR00247543

  // BEGIN, CR00263925 ZV
  /**
   * Comparator used to order user task details list by deadline date.
   */
  protected class UserTaskDetailsComparator
    implements Comparator<UserTasksDueInTheNextTimePeriodDetails> {

    /**
     * Default constructor.
     */
    public UserTaskDetailsComparator() {

      super();
    }

    /**
     * Compare two user task details structs.
     */
    @Override
    public int compare(final UserTasksDueInTheNextTimePeriodDetails o1,
      final UserTasksDueInTheNextTimePeriodDetails o2) {

      // BEGIN, CR00264571 ZV
      return o2.deadlineDate.compareTo(o1.deadlineDate);
      // END, CR00264571
    }
  }

  // END, CR00263925

  // BEGIN, CR00280640, DJ
  /**
   * Reads the user workspace content monthly details and if no tasks are there
   * an
   * informational message is displayed and if assigned tasks are there the bar
   * chart will be
   * displayed.
   *
   * @param userNameKey Contains the user name.
   *
   * @return The user workspace content monthly details.
   *
   * @throws InformationalException
   * {@link BPOSUPERVISORUSER#INF_SUPERVISOR_USER_WORKSPACE_NO_TASKS_DUE} - If
   * the user does not have tasks which
   * has a due date that falls within the time period selected.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public SupervisorUserWorkspaceContentDetails
    readSupervisorWorkSpaceContentMonthDetails(final UserNameKey userNameKey)
      throws AppException, InformationalException {

    final SupervisorUserWorkspaceContentDetails supervisorUserWorkspaceContentDetails =
      new SupervisorUserWorkspaceContentDetails();
    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();
    final UserTasksDueInTheNextMonthKey UserTasksDueInTheNextMonthKey =
      new UserTasksDueInTheNextMonthKey();
    final UsersKey usersKey = new UsersKey();

    UserTasksDueInTheNextMonthKey.userName = userNameKey.userName;
    UserTasksDueInTheNextMonthKey.deadlineDate = Date.getCurrentDate();
    UserTasksDueInTheNextMonthKey.numberOfWeeks = kNumberOfWeeks;

    final UserTasksDueInTheNextTimePeriodDetailsList userTasksDueInTheNextTimePeriodDetailsList =
      userWorkspace
        .countUserTasksDueInTheNextMonth(UserTasksDueInTheNextMonthKey);

    if (userTasksDueInTheNextTimePeriodDetailsList.dtls.isEmpty()) {
      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();
      final AppException appException = new AppException(
        BPOSUPERVISORUSER.INF_SUPERVISOR_USER_WORKSPACE_NO_TASKS_DUE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(appException, GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      final String[] warning =
        informationalManager.obtainInformationalAsString();
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warning[0];
      supervisorUserWorkspaceContentDetails.msgDetailsListdtls.dtls
        .add(informationalMsgDtls);
    } else {
      supervisorUserWorkspaceContentDetails.userWorkspaceChartXMLString =
        constructBarChartFromDetailsList(userNameKey,
          userTasksDueInTheNextTimePeriodDetailsList,
          VIEWTASKSOPTION.NEXTMONTH);
    }

    supervisorUserWorkspaceContentDetails.supervisorDetails =
      readSupervisorDetails(userNameKey);

    usersKey.userName = userNameKey.userName;
    final UserWorkQueueDetailsList userWorkQueueDetailsListObj =
      userWorkspace.listWorkQueuesForUser(usersKey);

    supervisorUserWorkspaceContentDetails.workQueueDetails =
      userWorkQueueDetailsListObj;

    final UserOrgStructStatusCodeKey userOrgStructStatusCodeKey =
      new UserOrgStructStatusCodeKey();

    userOrgStructStatusCodeKey.userName = usersKey.userName;
    userOrgStructStatusCodeKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
    final Organisation organisation = OrganisationFactory.newInstance();

    supervisorUserWorkspaceContentDetails.orgDetailsList = organisation
      .readOrgIDOrgNameAndPositionByUserName(userOrgStructStatusCodeKey);

    return supervisorUserWorkspaceContentDetails;
  }

  /**
   * Reads the user workspace content weekly details and if no tasks are there
   * an
   * informational message is displayed and if assigned tasks are there the bar
   * chart
   * will be displayed.
   *
   * @param userNameKey Contains the user name.
   *
   * @return The user workspace content weekly details.
   *
   * @throws InformationalException
   * {@link BPOSUPERVISORUSER#INF_SUPERVISOR_USER_WORKSPACE_NO_TASKS_DUE} - If
   * the user does not have tasks which
   * has a due date that falls within the time period selected.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public SupervisorUserWorkspaceContentDetails
    readSupervisorWorkSpaceContentWeekDetails(final UserNameKey userNameKey)
      throws AppException, InformationalException {

    final SupervisorUserWorkspaceContentDetails supervisorUserWorkspaceContentDetails =
      new SupervisorUserWorkspaceContentDetails();
    final UserTasksDueInTheNextWeekKey userTasksDueInTheNextWeekKey =
      new UserTasksDueInTheNextWeekKey();
    final UserWorkspace userWorkspace = UserWorkspaceFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    userTasksDueInTheNextWeekKey.userName = userNameKey.userName;
    userTasksDueInTheNextWeekKey.deadlineDate = Date.getCurrentDate();
    userTasksDueInTheNextWeekKey.numberOfDays = getNumberOfDaysInWeek();

    final UserTasksDueInTheNextTimePeriodDetailsList userTasksDueInTheNextTimePeriodDetailsList =
      userWorkspace
        .countUserTasksDueInTheNextWeek(userTasksDueInTheNextWeekKey);

    if (userTasksDueInTheNextTimePeriodDetailsList.dtls.isEmpty()) {
      final InformationalManager informationalManager =
        TransactionInfo.getInformationalManager();
      final AppException appException = new AppException(
        BPOSUPERVISORUSER.INF_SUPERVISOR_USER_WORKSPACE_NO_TASKS_DUE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(appException, GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      final String[] warning =
        informationalManager.obtainInformationalAsString();
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warning[0];
      supervisorUserWorkspaceContentDetails.msgDetailsListdtls.dtls
        .add(informationalMsgDtls);
    } else {
      supervisorUserWorkspaceContentDetails.userWorkspaceChartXMLString =
        constructBarChartFromDetailsList(userNameKey,
          userTasksDueInTheNextTimePeriodDetailsList,
          VIEWTASKSOPTION.NEXTWEEK);
    }

    supervisorUserWorkspaceContentDetails.supervisorDetails =
      readSupervisorDetails(userNameKey);

    usersKey.userName = userNameKey.userName;
    final UserWorkQueueDetailsList userWorkQueueDetailsListObj =
      userWorkspace.listWorkQueuesForUser(usersKey);

    supervisorUserWorkspaceContentDetails.workQueueDetails =
      userWorkQueueDetailsListObj;

    final UserOrgStructStatusCodeKey userOrgStructStatusCodeKey =
      new UserOrgStructStatusCodeKey();

    userOrgStructStatusCodeKey.userName = usersKey.userName;
    userOrgStructStatusCodeKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
    final Organisation organisation = OrganisationFactory.newInstance();

    supervisorUserWorkspaceContentDetails.orgDetailsList = organisation
      .readOrgIDOrgNameAndPositionByUserName(userOrgStructStatusCodeKey);

    return supervisorUserWorkspaceContentDetails;
  }

  // END, CR00280640

  // BEGIN, CR00369467, IBM
  /**
   * This method fetches a list of tasks associated with the user, that have
   * been reserved by a particular user.
   *
   * @param key
   * identifies userName and status for the task
   *
   * @return List of tasks associated with the case
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ListOpenTasksReservedByUserDetails
    listOpenTasksReservedByFiltered(final ListOpenTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final curam.core.sl.intf.Inbox inbox =
      curam.core.sl.fact.InboxFactory.newInstance();
    final UserNameAndStatusKey userNameAndStatusKey =
      new UserNameAndStatusKey();
    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      new ListOpenTasksReservedByUserDetails();

    userNameAndStatusKey.userName = key.userName;
    userNameAndStatusKey.statusCode = TASKSTATUS.NOTSTARTED;
    listOpenTasksReservedByUserDetails.taskDetailsList =
      inbox.listLimitedReservedTasksByStatus(userNameAndStatusKey,
        inbox.getInboxTaskReadMultiDetails());

    final TaskSortByPriority<ReservedByStatusTaskDetails> prioritySort =
      new TaskSortByPriority<ReservedByStatusTaskDetails>();

    final GenericBatchProcessInput batchProcessInput =
      GenericBatchProcessInputFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();
    final ReservedByStatusTaskDetailsList filteredTaskList =
      new ReservedByStatusTaskDetailsList();

    userNameKey.userName = key.userName;
    boolean isTaskBatchQueued;

    final BatchQueuedTaskIDList batchQueuedTaskIDList =
      batchProcessInput.searchUserTasksByResultStatus(userNameKey);

    for (final ReservedByStatusTaskDetails reservedByStatusTaskDetails : listOpenTasksReservedByUserDetails.taskDetailsList.taskDetailsList
      .items()) {
      isTaskBatchQueued = false;

      for (final BatchQueuedTaskID batchQueuedTaskID : batchQueuedTaskIDList.dtls
        .items()) {

        if (reservedByStatusTaskDetails.taskID == batchQueuedTaskID.taskID) {
          isTaskBatchQueued = true;
          break;
        }
      }
      if (!isTaskBatchQueued) {
        filteredTaskList.taskDetailsList.add(reservedByStatusTaskDetails);
      }
    }

    if (filteredTaskList.taskDetailsList.size() > 0) {
      listOpenTasksReservedByUserDetails.taskDetailsList = filteredTaskList;
    } else {
      listOpenTasksReservedByUserDetails.taskDetailsList.taskDetailsList
        .clear();
    }

    prioritySort.sortIfEnabled(
      listOpenTasksReservedByUserDetails.taskDetailsList.taskDetailsList);

    return listOpenTasksReservedByUserDetails;

  }

  // END, CR00369467

  // BEGIN, CR00372642, SG
  /**
   * Retrieves a list of cases associated with a user based on search criteria.
   *
   * @param searchKey Contains the details of search criteria.
   *
   * @return List of cases associated with the user.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException{@link BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED}
   * When no search criteria is entered.
   * @throws AppException Generic Exception Signature.
   * @throws AppException{@link BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_FROM_LARGE}
   * When Start From Date is set in the future.
   * @throws AppException{@link BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH} When
   * no case could be found that matched the search criteria.
   * @throws AppException{@link BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_TO_LARGE}
   * When Start To Date is set in the future.
   * @throws AppException{@link BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_START_DATE_FROM_START_DATE_TO}
   * When Start To Date is before the Start From Date.
   */
  @Override
  public CaseSearchList1
    caseSearch(final ReassignCasesForUserSearchKey searchKey)
      throws AppException, InformationalException {

    final CaseSearchCriteria1 caseSearchCriteria = searchKey.searchCriteria;
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // If no search criteria is entered.
    if (CuramConst.gkZero == caseSearchCriteria.categoryTypeList.length()
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && CuramConst.gkZero == caseSearchCriteria.statusList.length()) {
      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 4);
    }

    final Date currentDate = Date.getCurrentDate();

    // Prevent date ranges to be set in future.
    if (caseSearchCriteria.startDateFrom.after(currentDate)) {
      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_FROM_LARGE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 1);
    }

    if (caseSearchCriteria.startDateTo.after(currentDate)) {
      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_TO_LARGE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 1);
    }

    // If from date value is before to date value.
    if (!caseSearchCriteria.startDateFrom.isZero()
      && !caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.startDateFrom
        .after(caseSearchCriteria.startDateTo)) {
      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_START_DATE_FROM_START_DATE_TO),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 1);
    }

    CaseSearchRouterFactory.newInstance()
      .validateTypeAndStatus(caseSearchCriteria);

    informationalManager.failOperation();

    final CaseSearchList1 caseSearchList =
      databaseCaseSearch(caseSearchCriteria);

    // If no search results are found.
    if (caseSearchList.searchDtls.isEmpty()) {
      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
        ValidationManagerConst.kSetOne, 6);
    }

    return caseSearchList;

  }

  /**
   * Searches for tasks based on search criteria.
   *
   * @param taskQuery Contains the details of search criteria.
   *
   * @return List of reserved tasks.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException{@link BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED}
   * When no search criteria is entered.
   */
  @Override
  public TaskQueryResultDetailsList
    taskSearch(final TaskQueryCriteria taskQuery)
      throws AppException, InformationalException {

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    if (CuramConst.gkZero == taskQuery.businessObjectID
      && CuramConst.gkZero == taskQuery.priority.length()
      && taskQuery.deadlineFromDate.isZero()
      && taskQuery.deadlineToDate.isZero()) {
      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED),
        ValidationManagerConst.kSetOne, 5);
    }

    final ReadMultiOperationDetails readMultiOperationDetails =
      new ReadMultiOperationDetails();

    readMultiOperationDetails.maxListSize = 0;

    final TaskQueryResultDetailsList taskQueryResultDetailsList =
      SearchTaskUtilities.searchTask(taskQuery, readMultiOperationDetails);

    return taskQueryResultDetailsList;

  }

  // END, CR00372642

  // BEGIN, CR00377799, SG

  /**
   * Performs regular database search for cases using the specified search
   * criteria.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return List of cases that matches the search criteria.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseSearchList1 databaseCaseSearch(final CaseSearchCriteria1 key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

    searchKey.assign(key);

    if (0 < key.statusList.length()) {
      caseList.searchDtls.addAll(searchCaseByStatus(searchKey).searchDtls);
    } else if (0 < key.categoryTypeList.length()) {
      caseList.searchDtls
        .addAll(searchCaseByCategoryType(searchKey).searchDtls);
    } else {
      final DatabaseCaseSearchKey databaseKey = assignCaseSearchCriteria(key);

      caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);
    }

    return caseList;

  }

  /**
   * Converts case search criteria to database search details.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return Details for database case search.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public DatabaseCaseSearchKey
    assignCaseSearchCriteria(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final DatabaseCaseSearchKey databaseKey = new DatabaseCaseSearchKey();

    databaseKey.assign(key);

    if (0 < key.categoryTypeList.length()) {

      final StringList categoryTypeList =
        StringUtil.tabText2StringListWithTrim(key.categoryTypeList);

      final StringList categoryType =
        StringUtil.delimitedText2StringListWithTrim(categoryTypeList.item(0),
          CuramConst.gkPipeDelimiterChar);

      if (CuramConst.gkOne < categoryType.size()) {
        databaseKey.category = categoryType.item(0);
        databaseKey.type = categoryType.item(1);
      }

    }

    databaseKey.orgObjectLinkID = key.orgObjectLinkID;

    return databaseKey;

  }

  /**
   * Performs case search for specified search criteria by category and type
   * values.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return List of cases that matches the search criteria.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseSearchList1
    searchCaseByCategoryType(final CaseSearchCriteria1 key)
      throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (0 < key.categoryTypeList.length()) {

      final StringList categoryTypeList =
        StringUtil.tabText2StringListWithTrim(key.categoryTypeList);

      for (final String categoryTypeItem : categoryTypeList.items()) {

        final StringList categoryType =
          StringUtil.delimitedText2StringListWithTrim(categoryTypeItem,
            CuramConst.gkPipeDelimiterChar);

        if (CuramConst.gkOne < categoryType.size()) {

          final String category = categoryType.item(0);
          final String type = categoryType.item(1);

          final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

          searchKey.assign(key);
          searchKey.categoryTypeList = categoryTypeItem;

          final DatabaseCaseSearchKey databaseKey =
            assignCaseSearchCriteria(key);

          databaseKey.category = category;
          databaseKey.type = type;

          caseList.searchDtls.addAll(searchCaseByKey(databaseKey).searchDtls);

        }

      }

    }

    return caseList;

  }

  /**
   * Performs case search for specified search criteria by single values.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return List of cases that matches the search criteria.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseSearchList1 searchCaseByKey(final DatabaseCaseSearchKey key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.servicePlanCaseType = CASETYPECODE.SERVICEPLAN;
    key.issueCaseType = CASETYPECODE.ISSUE;
    key.investigationCaseType = CASETYPECODE.INVESTIGATIONCASE;

    CuramValueList<CaseSearchDetails1> curamValueList = null;

    try {

      // Call dynamic SQL API to execute SQL
      curamValueList =
        DynamicDataAccess.executeNsMulti(CaseSearchDetails1.class, key, false,
          true, formatCaseSQL(key).sqlStatement);
    } catch (final curam.util.exception.ReadmultiMaxException e) {// Ignore the
      // exception
    }

    for (final CaseSearchDetails1 caseSearchDetails : curamValueList) {

      DatabaseCaseSearchFactory.newInstance()
        .processSearchDetails(caseSearchDetails);

      if (null != caseSearchDetails.caseReference) {
        caseList.searchDtls.addRef(caseSearchDetails);
      }

    }

    return caseList;

  }

  /**
   * Performs case search for specified search criteria by status values.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return List of cases that matches the search criteria.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseSearchList1 searchCaseByStatus(final CaseSearchCriteria1 key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseList = new CaseSearchList1();

    if (0 < key.statusList.length()) {

      final StringList statusList =
        StringUtil.tabText2StringListWithTrim(key.statusList);

      for (final String status : statusList.items()) {

        if (0 < status.length()) {

          final CaseSearchCriteria1 searchKey = new CaseSearchCriteria1();

          searchKey.assign(key);
          searchKey.statusList = status;

          if (0 < key.categoryTypeList.length()) {
            caseList.searchDtls
              .addAll(searchCaseByCategoryType(searchKey).searchDtls);
          } else {
            final DatabaseCaseSearchKey databaseKey =
              assignCaseSearchCriteria(key);

            databaseKey.status = status;
            caseList.searchDtls
              .addAll(searchCaseByKey(databaseKey).searchDtls);
          }

        }

      }

    }

    return caseList;

  }

  /**
   * Formats SQL select statement for case search.
   *
   * @param key Holds criteria for searching cases.
   *
   * @return SQL statement.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SQLStatement formatCaseSQL(final DatabaseCaseSearchKey key)
    throws AppException, InformationalException {

    final SQLStatement sqlStatement = new SQLStatement();

    String selectStr = new String();
    String intoStr = new String();
    String fromStr = new String();
    String whereStr = new String();
    String groupByStr = new String();

    selectStr = "SELECT CaseHeader.caseReference, ";
    selectStr += "ConcernRole.concernRoleName, ";
    selectStr += "ConcernRole.concernRoleType, ";
    selectStr += "CaseHeader.caseTypeCode, CaseHeader.startDate, ";
    selectStr += "CaseHeader.statusCode, CaseHeader.caseID, ";
    selectStr += "CaseHeader.concernRoleID, ";
    selectStr += "COUNT(DISTINCT CPRCount.participantRoleID) ";

    intoStr = "INTO :caseReference, :concernRoleName, ";
    intoStr += ":concernRoleType, ";
    intoStr += ":caseTypeCode, :startDate, ";
    intoStr += ":statusCode, :caseID, :concernRoleID, ";
    intoStr += ":participantCount ";

    fromStr = "FROM CaseHeader, ConcernRole, ";
    fromStr += "CaseParticipantRole CPRCount ";

    whereStr = "WHERE CaseHeader.concernRoleID = ";
    whereStr += "ConcernRole.concernRoleID ";
    whereStr += "AND CPRCount.caseID = CaseHeader.caseID ";
    whereStr += "AND CPRCount.recordStatus = :recordStatus";

    groupByStr = " GROUP BY CaseHeader.caseReference, ";
    groupByStr += "ConcernRole.concernRoleName, ";
    groupByStr += "ConcernRole.concernRoleType, ";
    groupByStr += "CaseHeader.caseTypeCode, ";
    groupByStr += "CaseHeader.startDate, CaseHeader.statusCode, ";
    groupByStr += "CaseHeader.caseID, CaseHeader.concernRoleID";

    if (0 != key.orgObjectLinkID) {

      whereStr += " AND CaseHeader.ownerOrgObjectLinkID = :orgObjectLinkID";
    }

    if (0 < key.status.length()) {
      whereStr += " AND CaseHeader.statusCode = :status";
    }

    if (!key.startDateFrom.isZero()) {
      whereStr += " AND CaseHeader.startDate >= :startDateFrom ";
    }

    if (!key.startDateTo.isZero()) {
      whereStr += " AND CaseHeader.startDate <= :startDateTo";
    }

    if (0 < key.category.length() && 0 == key.type.length()) {

      whereStr += " AND CaseHeader.caseTypeCode = :category";

    } else if (0 < key.category.length() && 0 < key.type.length()) {

      whereStr += " AND CaseHeader.caseID IN (";

      String unionBuf = new String();

      String servicePlanStr = new String();
      String issueStr = new String();
      String investigationStr = new String();
      String assessmentStr = new String();
      String screeningStr = new String();
      String integratedStr = new String();
      String productStr = new String();
      String liabilityStr = new String();
      String appealStr = new String();

      if (CASETYPECODE.SERVICEPLAN.equals(key.category)) {

        if (0 == servicePlanStr.length()) {

          // If the case type is service plan,
          // search the service plan tables
          servicePlanStr += " SELECT CaseHeader.caseID";
          servicePlanStr +=
            " FROM CaseHeader, ServicePlanDelivery, ServicePlan";
          servicePlanStr += " WHERE CaseHeader.caseTypeCode = :category";
          servicePlanStr +=
            " AND CaseHeader.caseID = ServicePlanDelivery.caseID";
          servicePlanStr += " AND ServicePlanDelivery.servicePlanID ";
          servicePlanStr += " = ServicePlan.servicePlanID AND (";

        }

        servicePlanStr += " ServicePlan.servicePlanType = :type OR";

      } else if (CASETYPECODE.ISSUE.equals(key.category)) {

        if (0 == issueStr.length()) {

          // If the case type is issue,
          // search the issue tables
          issueStr += " SELECT CaseHeader.caseID";
          issueStr += " FROM CaseHeader, IssueDelivery";
          issueStr += " WHERE CaseHeader.caseTypeCode = :category";
          issueStr += " AND CaseHeader.caseID = IssueDelivery.caseID AND (";
        }

        issueStr += " IssueDelivery.issueType = :type OR";

      } else if (CASETYPECODE.INVESTIGATIONCASE.equals(key.category)) {

        if (0 == investigationStr.length()) {

          // If the case type is investigation,
          // search the investigation table
          investigationStr += " SELECT CaseHeader.caseID";
          investigationStr += " FROM CaseHeader, InvestigationDelivery";
          investigationStr += " WHERE CaseHeader.caseTypeCode = :category";
          investigationStr +=
            " AND CaseHeader.caseID = InvestigationDelivery.caseID AND (";
        }

        investigationStr +=
          " InvestigationDelivery.investigationType = :type OR";

      } else if (CASETYPECODE.ASSESSMENTDELIVERY.equals(key.category)) {

        if (0 == assessmentStr.length()) {

          // If the case type is assessment delivery,
          // search the assessment tables
          assessmentStr += " SELECT CaseHeader.caseID";
          assessmentStr +=
            " FROM CaseHeader, AssessmentDelivery, AssessmentConfiguration";
          assessmentStr += " WHERE CaseHeader.caseTypeCode = :category";
          assessmentStr +=
            " AND CaseHeader.caseID = AssessmentDelivery.caseID";
          assessmentStr +=
            " AND AssessmentDelivery.assessmentConfigurationID = ";
          assessmentStr +=
            "AssessmentConfiguration.assessmentConfigurationID AND (";

        }

        assessmentStr += " AssessmentConfiguration.assessmentType = :type OR";

      } else if (CASETYPECODE.SCREENINGCASE.equals(key.category)) {

        if (0 == screeningStr.length()) {

          // If the case type is screening,
          // search the screening tables
          screeningStr += " SELECT CaseHeader.caseID";
          screeningStr +=
            " FROM CaseHeader, Screening, ScreeningConfiguration";
          screeningStr += " WHERE CaseHeader.caseTypeCode = :category";
          screeningStr += " AND CaseHeader.caseID = Screening.caseID";
          screeningStr += " AND Screening.screeningConfigID = ";
          screeningStr += "ScreeningConfiguration.screeningConfigID AND (";

        }

        screeningStr += " ScreeningConfiguration.name = :type OR";

      } else if (CASETYPECODE.INTEGRATEDCASE.equals(key.category)) {

        if (0 == integratedStr.length()) {

          integratedStr += " SELECT CaseHeader.caseID FROM CaseHeader WHERE";
          integratedStr += " CaseHeader.caseTypeCode = :category AND (";
        }

        integratedStr += " CaseHeader.integratedCaseType = :type OR";

      } else if (CASETYPECODE.PRODUCTDELIVERY.equals(key.category)) {

        if (0 == productStr.length()) {

          // If the case type is product delivery
          // search the product delivery table
          productStr +=
            " SELECT CaseHeader.caseID FROM CaseHeader, ProductDelivery, Product";
          productStr += " WHERE CaseHeader.caseTypeCode = :category ";
          productStr += " AND Product.productID = ProductDelivery.productID";
          productStr +=
            " AND CaseHeader.caseID = ProductDelivery.caseID AND (";
        }

        productStr += " Product.name = :type OR";

      } else if (CASETYPECODE.LIABILITY.equals(key.category)) {

        if (0 == liabilityStr.length()) {

          // If the case type is liability,
          // search the product delivery table
          liabilityStr +=
            " SELECT CaseHeader.caseID FROM CaseHeader, ProductDelivery, Product";
          liabilityStr += " WHERE CaseHeader.caseTypeCode = :category ";
          liabilityStr +=
            " AND Product.productID = ProductDelivery.productID";
          liabilityStr +=
            " AND CaseHeader.caseID = ProductDelivery.caseID AND (";
        }

        liabilityStr += " Product.name = :type OR";

      } else if (CASETYPECODE.APPEAL.equals(key.category)) {

        // Retrieve the Environment variable for the Appeals component
        // installation setting.
        if (Configuration
          .getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

          if (0 == appealStr.length()) {
            appealStr += " SELECT CaseHeader.caseID FROM CaseHeader, Appeal";
            appealStr += " WHERE CaseHeader.caseTypeCode = :category ";
            appealStr += " AND CaseHeader.caseID = Appeal.caseID AND (";
          }
          appealStr += " AND Appeal.appealTypeCode = :type OR";

        }
      }

      // Remove last OR from where statements.
      final int kORLength = new String("OR").length();

      if (0 < servicePlanStr.length()) {
        servicePlanStr = servicePlanStr.substring(CuramConst.gkZero,
          servicePlanStr.length() - kORLength);
        servicePlanStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += servicePlanStr;
      }

      if (0 < issueStr.length()) {
        issueStr = issueStr.substring(CuramConst.gkZero,
          issueStr.length() - kORLength);
        issueStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += issueStr;
      }

      if (0 < investigationStr.length()) {
        investigationStr = investigationStr.substring(CuramConst.gkZero,
          investigationStr.length() - kORLength);
        investigationStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += investigationStr;
      }

      if (0 < assessmentStr.length()) {
        assessmentStr = assessmentStr.substring(CuramConst.gkZero,
          assessmentStr.length() - kORLength);
        assessmentStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += assessmentStr;
      }

      if (0 < screeningStr.length()) {
        screeningStr = screeningStr.substring(CuramConst.gkZero,
          screeningStr.length() - kORLength);
        screeningStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += screeningStr;
      }

      if (0 < productStr.length()) {
        productStr = productStr.substring(CuramConst.gkZero,
          productStr.length() - kORLength);
        productStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += productStr;
      }

      if (0 < liabilityStr.length()) {
        liabilityStr = liabilityStr.substring(CuramConst.gkZero,
          liabilityStr.length() - kORLength);
        liabilityStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += liabilityStr;
      }

      if (0 < integratedStr.length()) {
        integratedStr = integratedStr.substring(CuramConst.gkZero,
          integratedStr.length() - kORLength);
        integratedStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += integratedStr;
      }

      if (0 < appealStr.length()) {
        appealStr = appealStr.substring(CuramConst.gkZero,
          appealStr.length() - kORLength);
        appealStr += " )";

        if (0 < unionBuf.length()) {
          unionBuf += " UNION ";
        }

        unionBuf += appealStr;
      }

      whereStr += unionBuf;
      whereStr += " )";

    }

    sqlStatement.sqlStatement =
      selectStr + intoStr + fromStr + whereStr + groupByStr;

    return sqlStatement;

  }

  // END, CR00377799

  // BEGIN, CR00429980, VT
  // BEGIN, CR00439815, VT
  /**
   * This method lists the user assigned tasks based on the provided task filter
   * criteria.
   * The list does not include tasks currently reserved by the user and assigned
   * to work queues that the user is subscribed to.
   *
   * @param key -
   * TaskFilterCriteriaDetails
   *
   * @return ListUnreservedTasksForUserDetails
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ListUnreservedTasksForUserDetails listUserAssignedTasks(
    final TaskFilterCriteriaDetails taskFilterCriteriaDetails)
    throws AppException, InformationalException {

    ListUnreservedTasksForUserDetails listUnreservedTasksForUserDetails =
      new ListUnreservedTasksForUserDetails();

    final SearchSupervisorTaskUtilities taskSearchUtilities =
      new SearchSupervisorTaskUtilities();

    taskSearchUtilities
      .saveTaskFilterCriteriaDetails(taskFilterCriteriaDetails);

    listUnreservedTasksForUserDetails =
      DatabaseSupervisorWorkspaceTaskSearchFactory.newInstance()
        .userAssignedTasksSearch(taskFilterCriteriaDetails);

    final int searchSize =
      listUnreservedTasksForUserDetails.taskDetailsList.taskDetailsList
        .size();

    if (searchSize > CuramConst.gkZero) {

      for (final AssignedTaskDetails taskDetails : listUnreservedTasksForUserDetails.taskDetailsList.taskDetailsList) {

        final TaskWDOSnapshotDetails taskWDOSnapshotDetails =
          new TaskWDOSnapshotDetails();

        taskWDOSnapshotDetails.taskID = taskDetails.taskID;
        taskWDOSnapshotDetails.wdoSnapshot = taskDetails.subject;

        taskDetails.subject = LocalizableStringResolver
          .getTaskStringResolver().getSubjectForTask(taskWDOSnapshotDetails);
      }
    } else {
      final AppException e = new AppException(
        curam.message.BPOINBOX.INF_TASK_XFV_MATCHED_RESULTS_FOUND);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(searchSize), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        ValidationManagerConst.kSetOne, 0);

    }

    return listUnreservedTasksForUserDetails;

  }

  // END, CR00439815
  // END, CR00429980
  // BEGIN, CR00468368, GK

  /**
   * This API provides the cases to be shown to the supervisor. This API
   * provides
   * only business level cases and system level cases are filtered out.
   *
   * @param userStatusAndOrgObjectKey containing the parameters required to
   * fetch the list of cases : user id, record status and organization object
   * type.
   * @param cases containing a list of case type codes to be excluded from the
   * result.
   * @param queryType showing the type of the query to be used based on the
   * triggered
   * scenario
   * @return The list of cases to be shown to the supervisor workspace.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  private CaseReferenceTypeProductRolePriClientDateAndStatusList
    searchFilteredCases(
      final UserStatusAndOrgObjectKey userStatusAndOrgObjectKey,
      final Set<String> cases, final QueryType queryType)
      throws InformationalException, AppException {

    CuramValueList<CaseReferenceTypeProductRolePriClientDateAndStatus> curamValueList =
      new CuramValueList<CaseReferenceTypeProductRolePriClientDateAndStatus>(
        CaseReferenceTypeProductRolePriClientDateAndStatus.class);
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    try {
      // BEGIN, CR00468418, GK
      curamValueList = DynamicDataAccess.executeNsMulti(
        CaseReferenceTypeProductRolePriClientDateAndStatus.class,
        userStatusAndOrgObjectKey, false, true, DBSearchQueriesForSupervisorWS
          .formatSQL(cases, queryType, null).sqlStatement);
      // END, CR00468418
    } catch (final curam.util.exception.ReadmultiMaxException e) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

      informationalManager.failOperation();
    }
    final CaseReferenceTypeProductRolePriClientDateAndStatusList caseReferenceTypeProductRolePriClientDateAndStatusList =
      new CaseReferenceTypeProductRolePriClientDateAndStatusList();

    // BEGIN, CR00468418, GK
    caseReferenceTypeProductRolePriClientDateAndStatusList.dtls
      .ensureCapacity(curamValueList.size());
    // END, CR00468418
    for (int i = 0; i < curamValueList.size(); i++) {

      final CaseReferenceTypeProductRolePriClientDateAndStatus caseReferenceTypeProductRolePriClientDateAndStatus =
        curamValueList.get(i);

      populateCaseDescription(
        caseReferenceTypeProductRolePriClientDateAndStatus);
      caseReferenceTypeProductRolePriClientDateAndStatusList.dtls
        .add(caseReferenceTypeProductRolePriClientDateAndStatus);
    }
    return caseReferenceTypeProductRolePriClientDateAndStatusList;
  }

  /**
   * This API is used to populate the case description for each of the cases to
   * be
   * shown to the supervisor.
   *
   * @param caseReferenceTypeProductRolePriClientDateAndStatus containing the
   * list
   * of cases to be shown to the supervisor.
   * @throws DatabaseException
   * @throws AppRuntimeException
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  private void populateCaseDescription(
    final CaseReferenceTypeProductRolePriClientDateAndStatus caseReferenceTypeProductRolePriClientDateAndStatus)
    throws DatabaseException, AppRuntimeException, AppException,
    InformationalException {

    final String caseTypeCode =
      caseReferenceTypeProductRolePriClientDateAndStatus.caseTypeCode;
    String productTypeDesc = "";

    // BEGIN, CR00139241, GYH
    // Get the description for the type of the product
    if (caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)
      || caseTypeCode.equals(CASETYPECODE.LIABILITY)) {

      // BEGIN, CR00372089, AC
      final ProductDeliveryTypeDetails productDeliveryTypeDetails =
        new ProductDeliveryTypeDetails();

      productDeliveryTypeDetails.productType =
        caseReferenceTypeProductRolePriClientDateAndStatus.productType;
      productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        productDeliveryTypeDetails.productType,
        TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

      final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

      caseHeaderDtls.integratedCaseType =
        caseReferenceTypeProductRolePriClientDateAndStatus.integratedCaseType;

      productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        caseHeaderDtls.integratedCaseType,
        TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

      final ScreeningName screeningName = new ScreeningName();

      screeningName.name =
        caseReferenceTypeProductRolePriClientDateAndStatus.name;

      productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
        screeningName.name, TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      final AssessmentTypeDetails assessmentTypeDetails =
        new AssessmentTypeDetails();

      assessmentTypeDetails.assessmentType =
        caseReferenceTypeProductRolePriClientDateAndStatus.assessmentType;
      productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
        assessmentTypeDetails.assessmentType,
        TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {
      final ServicePlanTypeStruct servicePlanTypeStruct =
        new ServicePlanTypeStruct();

      servicePlanTypeStruct.servicePlanType =
        caseReferenceTypeProductRolePriClientDateAndStatus.servicePlanType;
      productTypeDesc =
        CodeTable.getOneItem(curam.codetable.SERVICEPLANTYPE.TABLENAME,
          servicePlanTypeStruct.servicePlanType,
          TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.ISSUE)) {

      final IssueTypeCode issueTypeCode = new IssueTypeCode();

      issueTypeCode.issueType =
        caseReferenceTypeProductRolePriClientDateAndStatus.issueType;

      productTypeDesc =
        CodeTable.getOneItem(curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
          issueTypeCode.issueType, TransactionInfo.getProgramLocale());

    } else if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

      final InvestigationTypeCode investigationTypeCode =
        new InvestigationTypeCode();

      investigationTypeCode.investigationType =
        caseReferenceTypeProductRolePriClientDateAndStatus.investigationType;
      productTypeDesc =
        CodeTable.getOneItem(curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
          investigationTypeCode.investigationType,
          TransactionInfo.getProgramLocale());
    }
    // END, CR00139241
    // END, CR00372089
    // Product type description cannot be empty
    if (productTypeDesc == null || productTypeDesc.length() == 0) {
      productTypeDesc = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
          TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    caseReferenceTypeProductRolePriClientDateAndStatus.productTypeDesc =
      productTypeDesc;

  }

  // END, CR00468368
  // BEGIN, CR00468368, YP

  /**
   * @param searchBySupervisorOrgUnit
   * @param cases
   * @return SupervisorUserWithTaskCountDetailsList The users reporting to the
   * supervisor including a count of the tasks assigned to each of them
   * @throws InformationalException
   * @throws AppException
   */

  private curam.core.struct.SupervisorUserWithTaskCountDetailsList
    searchUserTasksAndCasesBySupervisorOrgUnitFileteringSysCases(
      final SearchBySupervisorOrgUnit searchBySupervisorOrgUnit,
      final Set<String> cases) throws InformationalException, AppException {

    CuramValueList<curam.core.struct.SupervisorUserWithTaskCountDetails> curamValueList =
      new CuramValueList<curam.core.struct.SupervisorUserWithTaskCountDetails>(
        curam.core.struct.SupervisorUserWithTaskCountDetails.class);

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    try {
      // BEGIN, CR00468418, GK
      curamValueList = DynamicDataAccess.executeNsMulti(
        curam.core.struct.SupervisorUserWithTaskCountDetails.class,
        searchBySupervisorOrgUnit, false, true,
        DBSearchQueriesForSupervisorWS.formatSQL(cases,
          DBSearchQueriesForSupervisorWS.QueryType.USERSTASKCOUNT,
          null).sqlStatement);
      // END, CR00468418
    } catch (final curam.util.exception.ReadmultiMaxException e) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

      informationalManager.failOperation();
    }

    final curam.core.struct.SupervisorUserWithTaskCountDetailsList supervisorUserWithTaskCountDetailsList =
      new curam.core.struct.SupervisorUserWithTaskCountDetailsList();

    for (int i = 0; i < curamValueList.size(); i++) {

      final curam.core.struct.SupervisorUserWithTaskCountDetails supervisorUserWithTaskCountDetails =
        curamValueList.get(i);

      supervisorUserWithTaskCountDetailsList.dtls
        .add(supervisorUserWithTaskCountDetails);
    }

    return supervisorUserWithTaskCountDetailsList;

  }

  /**
   * This method retrieves a list of the users by supervisor lead position. It
   * also returns a count of the tasks assigned to each of them filtering system
   * level cases.
   *
   * @param orgObjTypeNameAndCaseStatusKey
   * @param cases
   * @return
   * @throws InformationalException
   * @throws AppException
   */
  private curam.core.struct.SupervisorUserWithTaskCountDetailsList
    searchUserTasksAndCasesBySupervisorIDLeadPosFileteringSysCases(
      final OrgObjTypeNameAndCaseStatusKey orgObjTypeNameAndCaseStatusKey,
      final Set<String> cases) throws InformationalException, AppException {

    CuramValueList<curam.core.struct.SupervisorUserWithTaskCountDetails> curamValueList =
      new CuramValueList<curam.core.struct.SupervisorUserWithTaskCountDetails>(
        curam.core.struct.SupervisorUserWithTaskCountDetails.class);

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    try {
      // BEGIN, CR00468418, GK
      curamValueList = DynamicDataAccess.executeNsMulti(
        curam.core.struct.SupervisorUserWithTaskCountDetails.class,
        orgObjTypeNameAndCaseStatusKey, false, true,
        DBSearchQueriesForSupervisorWS.formatSQL(cases,
          DBSearchQueriesForSupervisorWS.QueryType.USERSTASKCOUNTSUPERVISORLEADPOS,
          null).sqlStatement);
      // END, CR00468418
    } catch (final curam.util.exception.ReadmultiMaxException e) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .addInfoMgrExceptionWithLookup(
          new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);

      informationalManager.failOperation();
    }

    final curam.core.struct.SupervisorUserWithTaskCountDetailsList supervisorUserWithTaskCountDetailsList =
      new curam.core.struct.SupervisorUserWithTaskCountDetailsList();

    for (int i = 0; i < curamValueList.size(); i++) {

      final curam.core.struct.SupervisorUserWithTaskCountDetails supervisorUserWithTaskCountDetails =
        curamValueList.get(i);

      supervisorUserWithTaskCountDetailsList.dtls
        .add(supervisorUserWithTaskCountDetails);
    }

    return supervisorUserWithTaskCountDetailsList;

    // END, CR00468368
  }
}
