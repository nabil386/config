/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007,2021. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.supervisor.sl.impl;


import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.core.facade.struct.OrganisationUnitContactDetails;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.MaintainPhoneNumberFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Activity;
import curam.core.intf.AdminUser;
import curam.core.intf.EmailAddress;
import curam.core.intf.MaintainPhoneNumber;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.struct.OrgStructureOrgUnitAndStatusKey;
import curam.core.sl.entity.struct.OrgUnitUserNameAndStatusKey;
import curam.core.sl.entity.struct.OrganisationUnitDtls;
import curam.core.sl.entity.struct.OrganisationUnitFullDetails;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.OrganisationUnitWithVersionNoFullDetails;
import curam.core.sl.entity.struct.OrganisationUnitWithVersionNoFullDetailsList;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetails;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetailsList;
import curam.core.sl.entity.struct.UserNameAndDateTimeKey;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.TaskRedirectionFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.TaskSortByPriority;
import curam.core.sl.infrastructure.impl.BarChartConst;
import curam.core.sl.intf.Inbox;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.TaskRedirection;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.DeferredTaskDetails;
import curam.core.sl.struct.ListTaskKey;
import curam.core.sl.struct.OrgStructureAndOrgUnitKey;
import curam.core.sl.struct.ReservedByStatusTaskDetails;
import curam.core.sl.struct.UserForPositionDetailsList;
import curam.core.sl.struct.UserNameAndStatusKey;
import curam.core.sl.supervisor.fact.OrganizationUnitWorkspaceFactory;
import curam.core.sl.supervisor.fact.TaskManagementFactory;
import curam.core.sl.supervisor.intf.OrganizationUnitWorkspace;
import curam.core.sl.supervisor.intf.TaskManagement;
import curam.core.sl.supervisor.struct.OrgUnitAssignedTasksForUserDetails;
import curam.core.sl.supervisor.struct.OrgUnitAssignedTasksForUserDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksByUserSearchKey;
import curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextTimePeriodDetails;
import curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextTimePeriodDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetailsList;
import curam.core.sl.supervisor.struct.ReserveTaskDetailsForUser;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.GetPhoneNumberKey;
import curam.core.struct.OrgIDDateTimeStatusKey;
import curam.core.struct.PhoneNumberDetails;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.UserDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORORGUNITS;
import curam.supervisor.sl.struct.ListDeferredTasksReservedByOrgUnitUserDetails;
import curam.supervisor.sl.struct.ListOpenTasksReservedByOrgUnitUserDetails;
import curam.supervisor.sl.struct.OrgUnitAssignedTasksByUserDueOnDateDetails;
import curam.supervisor.sl.struct.OrgUnitDetails;
import curam.supervisor.sl.struct.OrgUnitMemberDetails;
import curam.supervisor.sl.struct.OrgUnitMemberDetailsList;
import curam.supervisor.sl.struct.OrgUnitReservedTasksDetails;
import curam.supervisor.sl.struct.OrgUnitStructureIDAndStartDateKey;
import curam.supervisor.sl.struct.OrgUnitTasksByUserDueOnDateDetails;
import curam.supervisor.sl.struct.OrgUnitTasksByUserDueOnDateKey;
import curam.supervisor.sl.struct.OrgUnitTasksDueInTheNextMonthKey;
import curam.supervisor.sl.struct.OrgUnitTasksDueInTheNextWeekKey;
import curam.supervisor.sl.struct.OrgUnitTasksReservedByUserDetails;
import curam.supervisor.sl.struct.OrgUnitWorkspaceDetails;
import curam.supervisor.sl.struct.OrganisationUnitTabDetails;
import curam.supervisor.sl.struct.OrganizationUnitUsersScheduleDetails;
import curam.supervisor.sl.struct.ReserveOrgUnitTasksToUserKey;
import curam.supervisor.sl.struct.SupervisorDetails;
import curam.supervisor.sl.struct.SupervisorOrganisationUnitDetails;
import curam.supervisor.sl.struct.UserNameOrgUnitIDKey;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;
import curam.util.workflow.struct.TaskKey;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;


/**
 * Service Layer implementation for MaintainSupervisorOrgUnits.
 */

public abstract class MaintainSupervisorOrgUnits extends curam.supervisor.sl.base.MaintainSupervisorOrgUnits {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kID = SupervisorConst.kID;

  /**
   * Identifier for holding the User Name for Bar chart creation
   */
  protected static final String kUserName = SupervisorConst.kUserName;

  /**
   * Identifier for holding the Full Name for Bar chart creation
   */
  protected static final String kFullName = SupervisorConst.kFullName;

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kBarChart = BarChartConst.kBarChart;

  /**
   * Identifier for holding the element type
   */
  protected static final String kUnit = BarChartConst.kUnit;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = BarChartConst.kCaption;

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kText = BarChartConst.kText;

  /**
   * Identifier for holding the element block
   */
  protected static final String kBlock = BarChartConst.kBlock;

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kType = BarChartConst.kType;

  /**
   * Identifier for holding the due date
   */
  protected static final String kDueDate = BarChartConst.kDueDate;

  /**
   * Identifier for holding the start date
   */
  protected static final String kStartDate = SupervisorConst.kStartDate;

  /**
   * Identifier for holding the bar graph length
   */
  protected static final String kLength = BarChartConst.kLength;

  /**
   * Identifier for holding the Organization Unit ID
   */
  protected static final String kOrgUnitID = SupervisorConst.kOrgUnitID;

  /**
   * Identifier for holding the Organization Unit structure ID
   */
  protected static final String kOrgStructureID = SupervisorConst.kOrgStructureID;

  /**
   * Identifier for holding the Organization Unit Name
   */
  protected static final String kOrgUnitName = SupervisorConst.kOrgUnitName;

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode = SupervisorConst.kTaskOptionCode;

  /**
   * Identifier for holding the Organization Unit structure ID
   */
  protected static final String kStructID = SupervisorConst.kStructID;

  /**
   * Identifier for holding the hyperlink on email id
   */
  protected static final String kMailLink = SupervisorConst.kMailLink;

  /**
   * Identifier for holding the Number of weeks for task due
   *
   */
  protected static final int kNumberOfWeeks = SupervisorConst.kNumberOfWeeks;

  // BEGIN, CR00124642, GSP
  final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;

  // END, CR00124642

  // ___________________________________________________________________________
  /**
   * This listSupervisorOrgUnits retrieves the list of org units where the
   * supervisor holds the lead position
   *
   * @return the SupervisorOrganisationUnitDetails object.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public SupervisorOrganisationUnitDetails listSupervisorOrgUnits()
    throws AppException, InformationalException {

    // BEGIN CR00107117 ,GM
    // OrganisationUnit object
    final curam.core.sl.entity.intf.OrganisationUnit organisationUnit = OrganisationUnitFactory.newInstance();
    // END CR00107117

    SupervisorOrgUnitDetailsList orgUnitDetailsList = new SupervisorOrgUnitDetailsList();

    // OrgUnitUserNameAndStatusKey object
    final OrgUnitUserNameAndStatusKey nameAndStatusKey = new OrgUnitUserNameAndStatusKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // Assign the logged-in username and record status to the key object
    nameAndStatusKey.userName = systemUser.getUserDetails().userName;
    nameAndStatusKey.status = RECORDSTATUS.CANCELLED;
    // BEGIN, CR00115371, SAI
    nameAndStatusKey.orgStructStatusCode = ORGSTRUCTURESTATUS.ACTIVE;
    // END, CR00115371

    // boolean variable to check if the OrganisationUnit already exists
    boolean exists = false;

    final String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;
    final String orgUnitSelectOption = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

    if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
      orgUnitDetailsList = organisationUnit.listSupervisorOrgUnitLeadPos(
        nameAndStatusKey);
    } else {
      // BEGIN ,CR00084595 KK
      SupervisorOrgUnitDetailsList supervisorOrgUnitDetailsList = new SupervisorOrgUnitDetailsList();

      // retrieve the list of OrganisationUnits where the user holds a lead
      // position
      supervisorOrgUnitDetailsList = organisationUnit.listSupervisorOrgUnitLeadPos(
        nameAndStatusKey);

      for (int i = 0; i < supervisorOrgUnitDetailsList.dtls.size(); i++) {

        final SupervisorOrgUnitDetails supervisorOrgUnitDetails = supervisorOrgUnitDetailsList.dtls.item(
          i);

        // check is the SupervisorUser OrganisationUnit already exists in the
        // return list.
        for (int k = 0; k < orgUnitDetailsList.dtls.size(); k++) {
          if (supervisorOrgUnitDetails.orgUnitID
            == orgUnitDetailsList.dtls.item(k).orgUnitID) {
            exists = true;
            break;
          }
        }
        if (!exists) {
          orgUnitDetailsList.dtls.addRef(supervisorOrgUnitDetails);
        }

        // variable to store the list of the OrganizationUnits
        OrganisationUnitWithVersionNoFullDetailsList organisationUnitFullDetailsList = new OrganisationUnitWithVersionNoFullDetailsList();
        // key to retrieve the nested organization units
        final OrgStructureOrgUnitAndStatusKey key = new OrgStructureOrgUnitAndStatusKey();

        key.organisationUnitID = supervisorOrgUnitDetails.orgUnitID;
        key.organisationStructureID = supervisorOrgUnitDetails.orgStructureID;
        key.recordStatus = RECORDSTATUS.NORMAL;
        organisationUnitFullDetailsList = organisationUnit.listNestedOrganisationUnitsWithVersionNo(
          key);
        for (int j = 0; j < organisationUnitFullDetailsList.dtls.size(); j++) {

          // retrieve each organization unit in the list
          final OrganisationUnitWithVersionNoFullDetails organisationUnitFullDetails = organisationUnitFullDetailsList.dtls.get(
            j);
          final SupervisorOrgUnitDetails supervisorOrgUnitDetails2 = new SupervisorOrgUnitDetails();

          supervisorOrgUnitDetails2.orgStructureID = organisationUnitFullDetails.organisationStructureID;
          supervisorOrgUnitDetails2.orgUnitCreationDate = organisationUnitFullDetails.creationDate;
          supervisorOrgUnitDetails2.orgUnitID = organisationUnitFullDetails.organisationUnitID;
          supervisorOrgUnitDetails2.orgUnitName = organisationUnitFullDetails.name;
          supervisorOrgUnitDetails2.orgUnitStatusCode = organisationUnitFullDetails.statusCode;

          boolean unitexists = false;

          // check if the SupervisorUser OrganisationUnit already exists in the
          // return list.
          for (int k = 0; k < orgUnitDetailsList.dtls.size(); k++) {
            if (supervisorOrgUnitDetails2.orgUnitID
              == orgUnitDetailsList.dtls.item(k).orgUnitID) {
              unitexists = true;
              break;
            }

          }
          if (!unitexists) {
            orgUnitDetailsList.dtls.addRef(supervisorOrgUnitDetails2);
          }

        }
        // END ,CR00084595 KK
      }

    }
    // return object
    final SupervisorOrganisationUnitDetails unitDetails = new SupervisorOrganisationUnitDetails();

    // assign the list of org units to the return object
    unitDetails.orgUnitDetails = orgUnitDetailsList;

    return unitDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method gets a list of the tasks that have been reserved, and then
   * deferred by members of the organization unit.
   *
   * @param key -
   * UserNameOrgUnitIDKey
   * @return the ListDeferredTasksReservedByOrgUnitUserDetails object.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public ListDeferredTasksReservedByOrgUnitUserDetails listDeferredTasksReservedByOrgUnitUser(UserNameOrgUnitIDKey key)
    throws AppException, InformationalException {

    final Inbox inbox = InboxFactory.newInstance();

    final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

    OrganisationUnitName organisationUnitName = new OrganisationUnitName();

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;

    organisationUnitName = organisationUnitObj.readOrgUnitName(
      organisationUnitKey);
    final ListTaskKey listTaskKey = new ListTaskKey();

    final ListDeferredTasksReservedByOrgUnitUserDetails listDeferredTasksReservedByOrgUnitUserDetails = new ListDeferredTasksReservedByOrgUnitUserDetails();

    listTaskKey.userName = key.userName;

    listDeferredTasksReservedByOrgUnitUserDetails.details = inbox.listLimitedDeferredTasks(
      listTaskKey, inbox.getInboxTaskReadMultiDetails());

    final TaskSortByPriority<DeferredTaskDetails> prioritySort = new TaskSortByPriority<DeferredTaskDetails>();

    prioritySort.sortIfEnabled(
      listDeferredTasksReservedByOrgUnitUserDetails.details.taskDetailsList);

    listDeferredTasksReservedByOrgUnitUserDetails.orgUnitName = organisationUnitName.name;

    return listDeferredTasksReservedByOrgUnitUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method gets a list of the tasks reserved by members of the
   * organization unit, that are open.
   *
   * @param key -
   * UserNameOrgUnitIDKey
   * @return the ListOpenTasksReservedByOrgUnitUserDetails object.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public ListOpenTasksReservedByOrgUnitUserDetails listOpenTasksReservedByOrgUnitUser(UserNameOrgUnitIDKey key)
    throws AppException, InformationalException {

    final Inbox inbox = InboxFactory.newInstance();

    final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

    OrganisationUnitName organisationUnitName = new OrganisationUnitName();

    final UserNameAndStatusKey userNameAndStatusKey = new UserNameAndStatusKey();

    final ListOpenTasksReservedByOrgUnitUserDetails listOpenTasksReservedByOrgUnitUserDetails = new ListOpenTasksReservedByOrgUnitUserDetails();

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;
    organisationUnitName = organisationUnitObj.readOrgUnitName(
      organisationUnitKey);

    userNameAndStatusKey.userName = key.userName;
    userNameAndStatusKey.statusCode = TASKSTATUS.NOTSTARTED;

    listOpenTasksReservedByOrgUnitUserDetails.taskDetailsList = inbox.listLimitedReservedTasksByStatus(
      userNameAndStatusKey, inbox.getInboxTaskReadMultiDetails());

    final TaskSortByPriority<ReservedByStatusTaskDetails> prioritySort = new TaskSortByPriority<ReservedByStatusTaskDetails>();

    prioritySort.sortIfEnabled(
      listOpenTasksReservedByOrgUnitUserDetails.taskDetailsList.taskDetailsList);

    listOpenTasksReservedByOrgUnitUserDetails.orgUnitName = organisationUnitName.name;

    return listOpenTasksReservedByOrgUnitUserDetails;

  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitWorkspaceMonthDetails read Organization Workspace details
   * due by month
   *
   * @param key -
   * OrgUnitTasksDueInTheNextMonthKey
   * @return OrgUnitWorkspaceDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public OrgUnitWorkspaceDetails readOrgUnitWorkspaceMonthDetails(
    OrgUnitTasksDueInTheNextMonthKey key) throws AppException,
      InformationalException {

    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();

    final OrgUnitWorkspaceDetails orgUnitWorkspaceDetails = new OrgUnitWorkspaceDetails();

    OrgUnitTasksDueInTheNextTimePeriodDetailsList orgUnitTasksDueInTheNextTimePeriodDetailsList = new OrgUnitTasksDueInTheNextTimePeriodDetailsList();

    final curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextMonthKey orgUnitTasksDueInTheNextMonthKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextMonthKey();

    final OrganisationUnitFullDetails organisationUnitDetails = new OrganisationUnitFullDetails();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // BEGIN, CR00274837 ZV
    orgUnitTasksDueInTheNextMonthKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837

    orgUnitTasksDueInTheNextMonthKey.organizationStructureID = key.key.organizationStructureID;
    orgUnitTasksDueInTheNextMonthKey.organizationUnitID = key.key.organizationUnitID;
    orgUnitTasksDueInTheNextMonthKey.numberOfWeeks = kNumberOfWeeks;

    orgUnitTasksDueInTheNextTimePeriodDetailsList = organizationUnitWorkspace.countOrgUnitTasksDueInTheNextMonth(
      orgUnitTasksDueInTheNextMonthKey);

    organisationUnitKey.organisationUnitID = key.key.organizationUnitID;
    organisationUnitDetails.organisationStructureID = key.key.organizationStructureID;
    organisationUnitDetails.organisationUnitID = key.key.organizationUnitID;

    // Get OrgUnit workspace Details
    orgUnitWorkspaceDetails.orgUnitWorkspaceDetails.assign(
      getWorkSpaceDetials(organisationUnitDetails));
    organisationUnitDetails.name = orgUnitWorkspaceDetails.orgUnitWorkspaceDetails.orgUnitName;

    orgUnitWorkspaceDetails.orgUnitWorkspaceChartXMLString = constructBarChartFromDetailsList(
      organisationUnitDetails, orgUnitTasksDueInTheNextTimePeriodDetailsList,
      VIEWTASKSOPTION.NEXTMONTH);

    orgUnitWorkspaceDetails.memberList.assign(
      getOrgUnitMemberList(organisationUnitDetails));

    return orgUnitWorkspaceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitWorkspaceWeekDetails reads organization workspace details
   * by week
   *
   * @param key -
   * OrgUnitTasksDueInTheNextWeekKey
   * @return OrgUnitWorkspaceDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public OrgUnitWorkspaceDetails readOrgUnitWorkspaceWeekDetails(
    OrgUnitTasksDueInTheNextWeekKey key) throws AppException,
      InformationalException {

    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();

    final OrgUnitWorkspaceDetails orgUnitWorkspaceDetails = new OrgUnitWorkspaceDetails();

    OrgUnitTasksDueInTheNextTimePeriodDetailsList orgUnitTasksDueInTheNextTimePeriodDetailsList = new OrgUnitTasksDueInTheNextTimePeriodDetailsList();

    final curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextWeekKey orgUnitTasksDueInTheNextWeekKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueInTheNextWeekKey();

    final OrganisationUnitFullDetails organisationUnitDetails = new OrganisationUnitFullDetails();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // BEGIN, CR00274837 ZV
    orgUnitTasksDueInTheNextWeekKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837

    orgUnitTasksDueInTheNextWeekKey.organizationStructureID = key.nextWeekKey.organizationStructureID;
    orgUnitTasksDueInTheNextWeekKey.organizationUnitID = key.nextWeekKey.organizationUnitID;
    orgUnitTasksDueInTheNextWeekKey.numberOfDays = getNumberOfDaysInWeek();

    orgUnitTasksDueInTheNextTimePeriodDetailsList = organizationUnitWorkspace.countOrgUnitTasksDueInTheNextWeek(
      orgUnitTasksDueInTheNextWeekKey);

    organisationUnitKey.organisationUnitID = key.nextWeekKey.organizationUnitID;
    organisationUnitDetails.organisationStructureID = key.nextWeekKey.organizationStructureID;
    organisationUnitDetails.organisationUnitID = key.nextWeekKey.organizationUnitID;

    // Get OrgUnit workspace Details
    orgUnitWorkspaceDetails.orgUnitWorkspaceDetails.assign(
      getWorkSpaceDetials(organisationUnitDetails));
    organisationUnitDetails.name = orgUnitWorkspaceDetails.orgUnitWorkspaceDetails.orgUnitName;

    orgUnitWorkspaceDetails.orgUnitWorkspaceChartXMLString = constructBarChartFromDetailsList(
      organisationUnitDetails, orgUnitTasksDueInTheNextTimePeriodDetailsList,
      VIEWTASKSOPTION.NEXTWEEK);

    orgUnitWorkspaceDetails.memberList.assign(
      getOrgUnitMemberList(organisationUnitDetails));

    return orgUnitWorkspaceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This reserveOrgUnitTasksToUser allows to reserve all or some, of the
   * assigned tasks assigned to an organization unit, to a user.
   *
   * @param key -
   * ReserveOrgUnitTasksToUserKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void reserveOrgUnitTasksToUser(ReserveOrgUnitTasksToUserKey key)
    throws AppException, InformationalException {

    // Create StringList from taskIds
    final StringList reserveTaskIDKeyList = StringUtil.delimitedText2StringList(
      key.reserveTaskIDs, '\t');

    // Create taskManagement object
    final TaskManagement taskManagement = TaskManagementFactory.newInstance();

    // ReserveTaskDetailsForUser Key object
    final ReserveTaskDetailsForUser reserveTaskDetailsForUser = new ReserveTaskDetailsForUser();
    // TaskKey
    final TaskKey taskKey = new TaskKey();

    if ((key.userName.length() == 0 || key.userName == null)
      && (key.supervisorUserName.length() == 0
        || key.supervisorUserName == null)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORORGUNITS.SUPERVISOR_RESERVE_ORGUNIT_USER_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (key.userName != null && key.userName.length() > 0
      && key.supervisorUserName != null && key.supervisorUserName.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORORGUNITS.SUPERVISOR_RESERVE_ORGUNIT_USER_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check task selection is empty
    if (reserveTaskIDKeyList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORORGUNITS.SUPERVISOR_RESERVE_ORGUNIT_TASKS_NO_TASK_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // iterate through selected task ids

    for (int i = 0; i < reserveTaskIDKeyList.size(); i++) {

      taskKey.taskID = Long.parseLong(reserveTaskIDKeyList.item(i));
      validateReserve(taskKey);
      reserveTaskDetailsForUser.taskID = Long.parseLong(
        reserveTaskIDKeyList.item(i));

      if (key.userName.length() == 0 || key.userName == null) {
        reserveTaskDetailsForUser.username = key.supervisorUserName;
      } else {
        reserveTaskDetailsForUser.username = key.userName;
      }
      taskManagement.reserve(reserveTaskDetailsForUser);
    }

  }

  // ___________________________________________________________________________
  /**
   * This validateReserve validates the selected task is already reserved or
   * not.
   *
   * @param key -
   * TaskKey
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReserve(TaskKey key) throws AppException,
      InformationalException {

    // creating users Object
    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskReservedByDetails = taskAdminObj.readDetails(
      key.taskID);

    if (taskReservedByDetails.reservedBy.length() > 0
      && !(taskReservedByDetails.reservedBy == null)) {
      final UserFullname userFullName = new UserFullname();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = taskReservedByDetails.reservedBy;

      userFullName.fullname = userAccessObj.getFullName(usersKey).fullname;

      final AppException ae = new AppException(
        BPOSUPERVISORORGUNITS.SUPERVISOR_RESERVE_ORGUNIT_SELECTED_TASK_MUST_NOT_BE_RESERVED);

      ae.arg(key.taskID);
      ae.arg(userFullName.fullname);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * This getWorkSpaceDetials reads the workspace details
   *
   * @param key -
   * OrganisationUnitFullDetails
   * @return OrgUnitDetails
   * @throws InformationalException
   * @throws AppException
   */

  public curam.supervisor.sl.struct.OrgUnitDetails getWorkSpaceDetials(
    OrganisationUnitFullDetails key) throws AppException,
      InformationalException {

    final OrgUnitDetails orgUnitDetails = new OrgUnitDetails();

    final curam.core.sl.intf.OrganisationUnit organisationUnit_boObj = curam.core.sl.fact.OrganisationUnitFactory.newInstance();

    // return variable for users contact details
    OrganisationUnitContactDetails organisationUnitContactDetails = new OrganisationUnitContactDetails();

    final OrgStructureAndOrgUnitKey orgStructureAndOrgUnit = new OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnit.orgStructAndOrgUnitKey.organisationStructureID = key.organisationStructureID;
    orgStructureAndOrgUnit.orgStructAndOrgUnitKey.organisationUnitID = key.organisationUnitID;

    // read user details list for organization unit
    organisationUnitContactDetails = organisationUnit_boObj.getContactDetails(
      orgStructureAndOrgUnit);
    orgUnitDetails.leadUser = organisationUnitContactDetails.organisationUnitContactDetails.fullName;
    orgUnitDetails.userName = organisationUnitContactDetails.organisationUnitContactDetails.userName;
    orgUnitDetails.phoneNumber = organisationUnitContactDetails.organisationUnitContactDetails.phoneNumber;
    // BEGIN, CR00118694, SK
    orgUnitDetails.phoneCountryCode = organisationUnitContactDetails.organisationUnitContactDetails.phoneCountryCode;
    orgUnitDetails.phoneAreaCode = organisationUnitContactDetails.organisationUnitContactDetails.phoneAreaCode;
    orgUnitDetails.phoneExtension = organisationUnitContactDetails.organisationUnitContactDetails.phoneExtension;
    // END, CR00118694

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    OrganisationUnitDtls organisationUnitDtls = new OrganisationUnitDtls();

    organisationUnitKey.organisationUnitID = key.organisationUnitID;
    organisationUnitDtls = getOrgUnitDetails(organisationUnitKey);

    orgUnitDetails.orgUnitName = organisationUnitDtls.name;
    orgUnitDetails.orgUnitType = organisationUnitDtls.businessTypeCode;
    orgUnitDetails.orgUnitID = organisationUnitDtls.organisationUnitID;
    orgUnitDetails.orgStructureID = key.organisationStructureID;

    return orgUnitDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the organization unit details for workspace
   *
   * @param key -
   * OrganisationUnitKey
   * @return OrganisationUnitDtls
   * @throws InformationalException
   * @throws AppException
   */
  public OrganisationUnitDtls getOrgUnitDetails(OrganisationUnitKey key)
    throws AppException, InformationalException {

    final curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

    return organisationUnitObj.read(key);
  }

  // ___________________________________________________________________________
  /**
   * This getOrgUnitMemberList reads the details of the members of the
   * organization.
   *
   * @param key -
   * OrganisationUnitFullDetails
   * @return OrgUnitMemberDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public curam.supervisor.sl.struct.OrgUnitMemberDetailsList getOrgUnitMemberList(OrganisationUnitFullDetails key)
    throws AppException, InformationalException {

    final OrgUnitMemberDetailsList orgUnitMemberDetailsList = new OrgUnitMemberDetailsList();

    final AdminUser adminUserObj = AdminUserFactory.newInstance();

    final curam.core.struct.ListUsersKey_bo listUsersKey = new curam.core.struct.ListUsersKey_bo();

    UserForPositionDetailsList userForPositionDetailsList = new UserForPositionDetailsList();

    listUsersKey.allInd = false;
    listUsersKey.orgStructureID = key.organisationStructureID;
    listUsersKey.orgUnitID = key.organisationUnitID;

    userForPositionDetailsList = adminUserObj.listUsers(listUsersKey);

    for (int i = 0; i
      < userForPositionDetailsList.userForOrgUnitDetailsList.dtls.size(); i++) {
      final curam.core.struct.UserNameKey userNameKey = new curam.core.struct.UserNameKey();

      final OrgUnitMemberDetails orgUnitMemberDetails = new OrgUnitMemberDetails();

      orgUnitMemberDetails.userFullName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userFullName;
      orgUnitMemberDetails.position = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).positionName;
      orgUnitMemberDetails.userName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userName;
      userNameKey.userName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userName;
      // BEGIN, CR00232351, ZV
      final curam.supervisor.sl.struct.SupervisorDetails supervisorDetails = readSupervisorDetails(
        userNameKey);

      final UserKeyStruct userKeyStruct = new UserKeyStruct();

      userKeyStruct.userName = supervisorDetails.userName;

      final UserDetails userDetails = adminUserObj.read(userKeyStruct);

      if (userDetails.businessPhoneID != 0) {
        final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();

        final PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

        phoneNumberKey.phoneNumberID = userDetails.businessPhoneID;
        orgUnitMemberDetails.phoneNumber = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;
      }
      orgUnitMemberDetails.email = supervisorDetails.userEmail;
      orgUnitMemberDetails.userEmailLink = kMailLink
        + supervisorDetails.userEmail;
      // END, CR00232351
      orgUnitMemberDetailsList.memberDetails.addRef(orgUnitMemberDetails);

    }

    return orgUnitMemberDetailsList;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00216252 MN
  /**
   * This readUserDetails returns user details for User Workspace
   *
   * @param key -
   * UserNameKey
   * @return UserDetails
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorOrgUnits#readSupervisorDetails(UserNameKey key)}.
   * readSupervisorDetails with a new return struct
   * SupervisorDetails. This struct has all the fields of
   * UserDetails struct along with fields toRedirectID and toRedirectType.
   * See release note : <CR00216252>
   */
  @Deprecated
  public curam.supervisor.sl.struct.UserDetails readUserDetails(
    UserNameKey key) throws AppException, InformationalException {

    final SupervisorDetails supervisorDetails = this.readSupervisorDetails(key);
    final curam.supervisor.sl.struct.UserDetails userDetails = new curam.supervisor.sl.struct.UserDetails();

    userDetails.phoneAreaCode = supervisorDetails.phoneAreaCode;
    userDetails.phoneCountryCode = supervisorDetails.phoneCountryCode;
    userDetails.phoneExtension = supervisorDetails.phoneExtension;
    userDetails.phoneNumber = supervisorDetails.phoneNumber;
    userDetails.taskRedirectedUserName = supervisorDetails.taskRedirectedUserName;
    userDetails.tasksRedirectedTo = supervisorDetails.tasksRedirectedTo;
    userDetails.userEmail = supervisorDetails.userEmail;
    userDetails.userEmailLink = supervisorDetails.userEmailLink;
    userDetails.userFullName = supervisorDetails.userFullName;
    userDetails.userName = supervisorDetails.userName;

    return userDetails;

  }

  // END, CR00216252
  // ___________________________________________________________________________
  /**
   * This readOrgUnitReservedTasksDetails reads the org unit reserved tasks
   * details
   *
   * @param key -
   * OrgUnitTasksKey
   * @return the OrgUnitReservedTasksDetails object.
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public OrgUnitReservedTasksDetails readOrgUnitReservedTasksDetails(
    curam.core.sl.supervisor.struct.OrgUnitTasksKey key) throws AppException,
      InformationalException {

    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksByUserSearchKey orgUnitTasksReservedByUserSearchKey = new OrgUnitTasksByUserSearchKey();

    orgUnitTasksReservedByUserSearchKey.organizationUnitID = key.organizationUnitID;
    orgUnitTasksReservedByUserSearchKey.organizationStructureID = key.organizationStructureID;
    final OrgUnitReservedTasksDetails orgUnitReservedTasksDetails = new OrgUnitReservedTasksDetails();

    final OrgUnitTasksReservedByUserDetailsList orgUnitTasksReservedByUserDetailsList = organizationUnitWorkspace.countOrgUnitTasksReservedByUser(
      orgUnitTasksReservedByUserSearchKey);

    final curam.common.util.xml.dom.Element barChartElement = new curam.common.util.xml.dom.Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00263925, ZV
    // sort org unit reserved task details list by user full name
    final Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetails> taskDetailsComparator = new OrgUnitReservedTaskDetailsComparator();

    Collections.sort(orgUnitTasksReservedByUserDetailsList.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < orgUnitTasksReservedByUserDetailsList.dtls.size(); i++) {

      final curam.common.util.xml.dom.Element unitElement = new curam.common.util.xml.dom.Element(kUnit);
      final curam.common.util.xml.dom.Element captionElement = new curam.common.util.xml.dom.Element(kCaption);

      captionElement.setAttribute(kText,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByFullUserName);
      captionElement.setAttribute(kUserName,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByUserName);
      captionElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(captionElement);

      curam.common.util.xml.dom.Element blockElement = new curam.common.util.xml.dom.Element(kBlock);

      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskOpenCount
        + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kID, Long.toString(key.organizationUnitID));
      blockElement.setAttribute(kStructID,
        Long.toString(key.organizationStructureID));
      blockElement.setAttribute(kUserName,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByUserName);
      blockElement.setAttribute(kFullName,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByFullUserName);
      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      blockElement = new curam.common.util.xml.dom.Element(kBlock);
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskDeferredCount
        + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kID, Long.toString(key.organizationUnitID));
      blockElement.setAttribute(kStructID,
        Long.toString(key.organizationStructureID));
      blockElement.setAttribute(kUserName,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByUserName);
      blockElement.setAttribute(kFullName,
        orgUnitTasksReservedByUserDetailsList.dtls.item(i).taskReservedByFullUserName);
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);
    }

    if (barChartElement.getChildren().isEmpty()) {
      // BEGIN, CR00052924, GM
      orgUnitReservedTasksDetails.reservedTasksXMLString = CuramConst.gkEmpty;
      // END, CR00052924

    } else {
      orgUnitReservedTasksDetails.reservedTasksXMLString = outputter.outputString(
        barChartElement);
    }
    return orgUnitReservedTasksDetails;
  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitUsersScheduleDetails reads the users and their activity
   * count for an organizational unit
   *
   * @param key -
   * OrgUnitStructureIDAndStartDateKey
   * @return the OrganizationUnitUsersScheduleDetails object.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrganizationUnitUsersScheduleDetails readOrgUnitUsersScheduleDetails(OrgUnitStructureIDAndStartDateKey key)
    throws AppException, InformationalException {

    OrganizationUnitUsersScheduleDetails organizationUnitusersscheduleDetails = new OrganizationUnitUsersScheduleDetails();
    final OrgIDDateTimeStatusKey orgIDDateTimeStatusKey = new OrgIDDateTimeStatusKey();

    // To get the number of days in a week depending on an environment variable.
    final int numberofDays = getNumberOfDaysInWeek();

    // To calculate the start date and end date for a given date.
    organizationUnitusersscheduleDetails = populateStartAndEndDateOfWeek(
      key.weekBeginDate, numberofDays);

    final Activity activity = curam.core.fact.ActivityFactory.newInstance();

    // Setting the values to be passed to the query.
    orgIDDateTimeStatusKey.organisationUnitID = key.organisationID;
    orgIDDateTimeStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    orgIDDateTimeStatusKey.recordStatusCode = RECORDSTATUS.NORMAL;
    orgIDDateTimeStatusKey.effectiveDate = Date.getCurrentDate();
    orgIDDateTimeStatusKey.organisationStructureID = key.organisationStructID;
    orgIDDateTimeStatusKey.startDateTime = organizationUnitusersscheduleDetails.weekBeginDate.getDateTime();
    orgIDDateTimeStatusKey.endDateTime = organizationUnitusersscheduleDetails.nextDate.getDateTime();

    // This will get the users and count of activities.
    organizationUnitusersscheduleDetails.activityCountDetailsList = activity.countActivityForOrgUnitUsers(
      orgIDDateTimeStatusKey);

    // Setting the previous and next week for the next and previous week links.
    final Date previousDate = organizationUnitusersscheduleDetails.previousDate.addDays(
      -7);
    final Date nextDate = organizationUnitusersscheduleDetails.previousDate.addDays(
      7);

    organizationUnitusersscheduleDetails.nextDate = nextDate;
    organizationUnitusersscheduleDetails.previousDate = previousDate;

    return organizationUnitusersscheduleDetails;

  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitAssignedTasksByUserDueOnDate displays the assigned tasks
   * for users in an organization unit on a particular date.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return the OrgUnitAssignedTasksByUserDueOnDateDetails object.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasksByUserDueOnDate(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // Creating Organization Unit Objects.
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    // Assign key values
    orgUnitTasksByUserDueOnDateKey.key = key.key;

    // calling the entity layer method.
    final OrgUnitAssignedTasksForUserDetailsList orgUnitAssignedTasksForUserDetailsList = organizationUnitWorkspace.countOrgUnitAssignedTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    orgUnitAssignedTasksByUserDueOnDateDetails.barchartXML = constructBarChartXML(
      orgUnitAssignedTasksForUserDetailsList, orgUnitTasksByUserDueOnDateKey,
      VIEWTASKSOPTION.NEXTWEEK);
    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitReservedTasksByUserDueOnDate is used to construct bar chart
   * for Reserved Tasks due on date from the details list.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey,
   *
   * @return OrgUnitTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitTasksReservedByUserDetails readOrgUnitReservedTasksByUserDueOnDate(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksReservedByUserDetails orgUnitTasksReservedByUserDetails = new OrgUnitTasksReservedByUserDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    // Call to SL method
    orgUnitTasksByUserDueOnDateKey.key = key.key;
    orgUnitTasksReservedByUserDetails.taskDetails = organisationUnit.countOrgUnitReservedTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    orgUnitTasksReservedByUserDetails.barchartXML = constructBarChartReservedTasksDueOnDate(
      orgUnitTasksByUserDueOnDateKey, orgUnitTasksReservedByUserDetails,
      VIEWTASKSOPTION.NEXTWEEK);

    return orgUnitTasksReservedByUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * This readOrgUnitTasksByUserDueOnDate is used to construct bar chart for
   * Tasks due on date from the details list.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey,
   *
   * @return OrgUnitTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitTasksByUserDueOnDateDetails readOrgUnitTasksByUserDueOnDate(
    OrgUnitTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksByUserDueOnDateDetails orgUnitTasksByUserDueOnDateDetails = new OrgUnitTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    // Call to SL method
    orgUnitTasksByUserDueOnDateKey.key = key.key;
    orgUnitTasksByUserDueOnDateDetails.taskDetails = organisationUnit.countOrgUnitTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    orgUnitTasksByUserDueOnDateDetails.barchartXML = constructBarChartTasksDueOnDate(
      orgUnitTasksByUserDueOnDateKey, orgUnitTasksByUserDueOnDateDetails,
      VIEWTASKSOPTION.NEXTWEEK);

    return orgUnitTasksByUserDueOnDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Assigned Tasks By Week.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitAssignedTasksByUserDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasksByUserDueByWeek(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;

    // Calling Entity layer method
    orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails = organisationUnit.countOrgUnitAssignedTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);

    orgUnitAssignedTasksByUserDueOnDateDetails.barchartXML = constructBarChartAssignedTasksDueByWeek(
      orgUnitTasksByUserDueOnDateKey,
      orgUnitAssignedTasksByUserDueOnDateDetails, VIEWTASKSOPTION.NEXTMONTH);

    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Reserved Tasks By Week.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksReservedByUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitTasksReservedByUserDetails readOrgUnitReservedTasksByUserDueByWeek(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksReservedByUserDetails orgUnitTasksReservedByUserDetails = new OrgUnitTasksReservedByUserDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;

    // Calling Entity layer method
    orgUnitTasksReservedByUserDetails.taskDetails = organisationUnit.countOrgUnitReservedTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);

    orgUnitTasksReservedByUserDetails.barchartXML = constructBarChartReservedTasksDueOnDate(
      orgUnitTasksByUserDueOnDateKey, orgUnitTasksReservedByUserDetails,
      VIEWTASKSOPTION.NEXTMONTH);

    return orgUnitTasksReservedByUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to fetch all the Assigned Tasks.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksReservedByUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasks(
    curam.supervisor.sl.struct.OrgUnitTasksByUserSearchKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    OrgUnitTasksByUserSearchKey orgUnitTasksByUserSearchKey = new OrgUnitTasksByUserSearchKey();

    orgUnitTasksByUserSearchKey = key.key;

    // Calling Entity layer method
    orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails = organisationUnit.countOrgUnitAssignedTasksByUser(
      orgUnitTasksByUserSearchKey);

    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit assigned task details list by user full name
    final Comparator<OrgUnitAssignedTasksForUserDetails> taskDetailsComparator = new OrgUnitAssignedTaskDetailsComparator();

    Collections.sort(
      orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.item(i).fullName);
      captionElement.setAttribute(kUserName,
        orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(captionElement);

      final Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kLength,
        orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.item(i).taskAssignedCount
        + CuramConst.gkEmpty);
      blockElement.setAttribute(kFullName,
        orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.item(i).fullName);
      blockElement.setAttribute(kUserName,
        orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails.dtls.item(i).userName);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373

      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);

    }
    if (barChartElement.getChildren().isEmpty()) {
      orgUnitAssignedTasksByUserDueOnDateDetails.barchartXML = CuramConst.gkEmpty;

    } else {
      orgUnitAssignedTasksByUserDueOnDateDetails.barchartXML = outputter.outputString(
        barChartElement);
    }
    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // __________________________________________________________________________
  /**
   * This readOrgUnitTasksByUserDueByWeek helps the supervisor manage the tasks
   * due in the specified week.
   *
   * @param key - OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitTasksByUserDueOnDateDetails readOrgUnitTasksByUserDueByWeek(
    OrgUnitTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // Creating Organization Unit Objects
    final OrgUnitTasksByUserDueOnDateDetails orgUnitTasksByUserDueOnDateDetails = new OrgUnitTasksByUserDueOnDateDetails();
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();
    OrgUnitTasksByUserDueOnDateDetailsList orgUnitTasksByUserDueOnDateDetailsList = new OrgUnitTasksByUserDueOnDateDetailsList();

    // Assign key values
    orgUnitTasksByUserDueOnDateKey.key = key.key;

    // calling the entity layer method
    orgUnitTasksByUserDueOnDateDetailsList = organisationUnit.countOrgUnitTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);
    orgUnitTasksByUserDueOnDateDetails.barchartXML = constructBarChartFromXMLData(
      orgUnitTasksByUserDueOnDateKey, orgUnitTasksByUserDueOnDateDetailsList,
      VIEWTASKSOPTION.NEXTMONTH);

    return orgUnitTasksByUserDueOnDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key -
   * OrganisationUnitFullDetails,
   * @param detailsList -
   * OrgUnitTasksDueInTheNextTimePeriodDetailsList
   * @param taskOptionCode -
   * String
   * @return String - of bar chart xml values
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartTasksDueOnDate(
    OrgUnitTasksByUserDueOnDateKey key,
    OrgUnitTasksByUserDueOnDateDetails detailsList, String taskOptionCode)
    throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = detailsList.taskDetails.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit task details list by user full name
    final Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetails> taskDetailsComparator = new OrgUnitTaskDetailsComparator();

    Collections.sort(detailsList.taskDetails.dtls, taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        detailsList.taskDetails.dtls.item(i).userFullName);
      captionElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.taskDetails.dtls.item(i).taskReservedCount
        + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kFullName,
        detailsList.taskDetails.dtls.item(i).userFullName);
      // BEGIN, , SS
      blockElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).userName);
      // END,
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.taskDetails.dtls.item(i).taskAssignedCount
        + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kFullName,
        detailsList.taskDetails.dtls.item(i).userFullName);
      // BEGIN, , SS
      blockElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).userName);
      // END,
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      // BEGIN, CR00052924, GM
      return CuramConst.gkEmpty;
      // END, CR00052924
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartReservedTasksDueOnDate is used to construct bar chart
   * from the details list.
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartReservedTasksDueOnDate(
    OrgUnitTasksByUserDueOnDateKey key,
    OrgUnitTasksReservedByUserDetails detailsList, String taskOptionCode)
    throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = detailsList.taskDetails.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit reserved task details list by user full name
    final Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetails> taskDetailsComparator = new OrgUnitReservedTaskDetailsComparator();

    Collections.sort(detailsList.taskDetails.dtls, taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        detailsList.taskDetails.dtls.item(i).taskReservedByFullUserName);
      captionElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).taskReservedByUserName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.taskDetails.dtls.item(i).taskOpenCount + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kFullName,
        detailsList.taskDetails.dtls.item(i).taskReservedByFullUserName);
      blockElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).taskReservedByUserName);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.taskDetails.dtls.item(i).taskDeferredCount
        + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kFullName,
        detailsList.taskDetails.dtls.item(i).taskReservedByFullUserName);
      blockElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).taskReservedByUserName);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      // BEGIN, CR00052924, GM
      return CuramConst.gkEmpty;
      // END, CR00052924
    } else {

      return outputter.outputString(barChartElement);

    }
  }

  // ___________________________________________________________________________
  /**
   * This constructBarChartXML is used to construct bar chart from the details
   * list.
   *
   * @param orgUnitAssignedTasksForUserDetailsList -
   * OrgUnitAssignedTasksForUserDetailsList
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @param taskOptionCode - String
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartXML(
    OrgUnitAssignedTasksForUserDetailsList orgUnitAssignedTasksForUserDetailsList,
    OrgUnitTasksByUserDueOnDateKey key, String taskOptionCode) {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();
    final int listSize = orgUnitAssignedTasksForUserDetailsList.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit assigned task details list by user full name
    final Comparator<OrgUnitAssignedTasksForUserDetails> taskDetailsComparator = new OrgUnitAssignedTaskDetailsComparator();

    Collections.sort(orgUnitAssignedTasksForUserDetailsList.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {

      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        orgUnitAssignedTasksForUserDetailsList.dtls.item(i).fullName);
      captionElement.setAttribute(kUserName,
        orgUnitAssignedTasksForUserDetailsList.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      final Element blockElement = new Element(kBlock);

      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      blockElement.setAttribute(kLength,
        orgUnitAssignedTasksForUserDetailsList.dtls.item(i).taskAssignedCount
        + CuramConst.gkEmpty);
      blockElement.setAttribute(kUserName,
        orgUnitAssignedTasksForUserDetailsList.dtls.item(i).userName);
      blockElement.setAttribute(kFullName,
        orgUnitAssignedTasksForUserDetailsList.dtls.item(i).fullName);
      blockElement.setAttribute(kOrgUnitID,
        Long.toString(key.key.organizationUnitID));
      blockElement.setAttribute(kOrgStructureID,
        Long.toString(key.key.organizationStructureID));
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642,GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642

      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return CuramConst.gkEmpty;

    } else {

      return outputter.outputString(barChartElement);
    }
  }

  // ___________________________________________________________________________
  /**
   * Utility method for populating start and end dates of week
   *
   * @param key
   * -Date , number of days in a week
   * @param numberofDays
   * @return OrganizationUnitUsersScheduleDetails
   */
  // BEGIN, CR00198672, VK
  protected OrganizationUnitUsersScheduleDetails populateStartAndEndDateOfWeek(Date key, int numberofDays) {

    // END, CR00198672
    final OrganizationUnitUsersScheduleDetails startandenddates = new OrganizationUnitUsersScheduleDetails();

    if (key.isZero()) {
      final int checkDate = Date.getCurrentDate().getCalendar().get(
        Calendar.DAY_OF_WEEK);

      if (checkDate == 2) {
        startandenddates.previousDate = Date.getCurrentDate();
        startandenddates.nextDate = startandenddates.previousDate.addDays(
          numberofDays);
      } else {
        startandenddates.previousDate = Date.getCurrentDate().addDays(
          2 - checkDate);
        startandenddates.nextDate = startandenddates.previousDate.addDays(
          numberofDays);
      }
    } else {
      startandenddates.previousDate = key;
      startandenddates.nextDate = startandenddates.previousDate.addDays(
        numberofDays);
    }
    startandenddates.weekBeginDate = startandenddates.previousDate;
    return startandenddates;
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key -
   * OrganisationUnitFullDetails,
   * @param detailsList -
   * OrgUnitTasksDueInTheNextTimePeriodDetailsList
   * @param taskOptionCode -
   * String
   * @return String - of bar chart xml values
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromDetailsList(
    OrganisationUnitFullDetails key,
    OrgUnitTasksDueInTheNextTimePeriodDetailsList detailsList,
    String taskOptionCode) throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = detailsList.dtls.size();

    // BEGIN, CR00086294, VS
    // BEGIN, CR00085608 SK
    // BEGIN, CR00322267, AC
    // Get current locale and extract the first 2 letters
    final String currentLocale = TransactionInfo.getProgramLocale();
    String shortLocale = currentLocale;

    if (currentLocale.length() > 2) {
      shortLocale = currentLocale.substring(0, 2);
    }

    // Get date format with the current locale
    final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
      SupervisorConst.kDateFormat, new java.util.Locale(shortLocale));
    // END, CR00322267
    // END, CR00085608 SK
    // END, CR00086294

    // BEGIN, CR00263925, ZV
    // sort org unit task details list by deadline date
    final Comparator<OrgUnitTasksDueInTheNextTimePeriodDetails> taskDetailsComparator = new OrgUnitTaskDueInTheNextTimePeriodDetailsComparator();

    Collections.sort(detailsList.dtls, taskDetailsComparator);
    // END, CR00263925

    // BEGIN, CR00263925, ZV
    for (int i = 0; i < listSize; i++) {
      // END, CR00263925
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      // BEGIN, CR00086294, VS
      // BEGIN, CR00085608 SK
      // BEGIN, CR00322267 ,AC
      captionElement.setAttribute(SupervisorConst.kText,
        simpleDateFormat.format(
        detailsList.dtls.item(i).deadlineDate.getCalendar().getTime()));
      // END, CR00322267
      // END, CR00085608 SK
      // END, CR00086294

      // BEGIN, CR00124642, GSP
      captionElement.setAttribute(kStartDate,
        curam.util.resources.Locale.getFormattedDate(detailsList.dtls.item(i).deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642

      captionElement.setAttribute(kOrgUnitID,
        new Long(key.organisationUnitID).toString());
      captionElement.setAttribute(kOrgStructureID,
        new Long(key.organisationStructureID).toString());
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.organisationUnitID).toString());
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.dtls.item(i).taskReservedCount + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kOrgUnitName, key.name);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.organisationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(detailsList.dtls.item(i).deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kOrgUnitID,
        new Long(key.organisationUnitID).toString());
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      // BEGIN, CR00052924, GM
      blockElement.setAttribute(kLength,
        detailsList.dtls.item(i).taskAssignedCount + CuramConst.gkEmpty);
      // END, CR00052924
      blockElement.setAttribute(kOrgUnitName, key.name);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.organisationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(detailsList.dtls.item(i).deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      // BEGIN, CR00052924, GM
      return CuramConst.gkEmpty;
      // END, CR00052924
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // ___________________________________________________________________________
  /**
   * This getNumberOfDaysInWeek returns the no of days in a week
   *
   * @return int - no of days In a week
   */
  // BEGIN, CR00198672, VK
  protected int getNumberOfDaysInWeek() {

    // END, CR00198672
    final String noOfDaysInaWeekString = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK);

    int noOfDaysInaWeek = 0;

    if (noOfDaysInaWeekString == null) {
      noOfDaysInaWeek = EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK_DEFAULT;
    } else {
      noOfDaysInaWeek = Integer.parseInt(noOfDaysInaWeekString);
    }
    return noOfDaysInaWeek;
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey,
   * @param detailsList -
   * OrgUnitAssignedTasksByUserDueOnDateDetails
   * @param taskOptionCode
   * @param taskOptionCode
   *
   * @return String - of bar chart xml values
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartAssignedTasksDueByWeek(
    OrgUnitTasksByUserDueOnDateKey key,
    OrgUnitAssignedTasksByUserDueOnDateDetails detailsList,
    String taskOptionCode) throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = detailsList.taskDetails.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit assigned tasks details list by user full name
    final Comparator<OrgUnitAssignedTasksForUserDetails> orgUnitAssignedTaskDetailsComparator = new OrgUnitAssignedTaskDetailsComparator();

    Collections.sort(detailsList.taskDetails.dtls,
      orgUnitAssignedTaskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        detailsList.taskDetails.dtls.item(i).fullName);
      captionElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      final Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kLength,
        detailsList.taskDetails.dtls.item(i).taskAssignedCount
        + CuramConst.gkEmpty);
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      blockElement.setAttribute(kUserName,
        detailsList.taskDetails.dtls.item(i).userName);
      blockElement.setAttribute(kFullName,
        detailsList.taskDetails.dtls.item(i).fullName);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return CuramConst.gkEmpty;
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key
   * -OrgUnitTasksByUserDueOnDateKey
   * @param orgUnitTasksByUserDueOnDateDetailsList
   * -OrgUnitTasksByUserDueOnDateDetailsList
   * @param taskOptionCode -String
   * @return String - of bar chart xml values
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromXMLData(
    OrgUnitTasksByUserDueOnDateKey key,
    OrgUnitTasksByUserDueOnDateDetailsList orgUnitTasksByUserDueOnDateDetailsList,
    String taskOptionCode) throws AppException, InformationalException {

    // END, CR00198672
    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    final int listSize = orgUnitTasksByUserDueOnDateDetailsList.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort org unit task details list by user full name
    final Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetails> taskDetailsComparator = new OrgUnitTaskDetailsComparator();

    Collections.sort(orgUnitTasksByUserDueOnDateDetailsList.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      final Element unitElement = new Element(kUnit);
      final Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userFullName);
      captionElement.setAttribute(kUserName,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      blockElement.setAttribute(kLength,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).taskReservedCount
        + "");
      blockElement.setAttribute(kFullName,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userFullName);
      blockElement.setAttribute(kUserName,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userName);
      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kOrgUnitID,
        new Long(key.key.organizationUnitID).toString());

      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      blockElement.setAttribute(kLength,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).taskAssignedCount
        + "");

      blockElement.setAttribute(kFullName,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userFullName);
      blockElement.setAttribute(kUserName,
        orgUnitTasksByUserDueOnDateDetailsList.dtls.item(i).userName);

      blockElement.setAttribute(kOrgStructureID,
        new Long(key.key.organizationStructureID).toString());
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.key.deadlineDate,
        kGanttDateFormat));
      // END, CR00124642
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return GeneralConstants.kEmpty;
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // BEGIN, CR00216252 MN
  /**
   * This readUserDetails returns user details for User Workspace and
   * also allows to read workspace details of members other than users.
   *
   * @param key -
   * UserNameKey
   * @return UserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public curam.supervisor.sl.struct.SupervisorDetails readSupervisorDetails(
    UserNameKey key) throws AppException, InformationalException {

    final SupervisorDetails userDetails = new SupervisorDetails();

    EmailAddressDtls userEmailAddressDtls = new EmailAddressDtls();

    // Maintain Phone Number obj to get Phone number
    final MaintainPhoneNumber maintainPhoneNumberObj = MaintainPhoneNumberFactory.newInstance();
    final GetPhoneNumberKey getPhoneNumberKey = new GetPhoneNumberKey();
    PhoneNumberDetails phoneNumberDetails = new PhoneNumberDetails();

    // to get the current task redirected user name
    final TaskRedirection taskRedirection = TaskRedirectionFactory.newInstance();

    final UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    userNameAndDateTimeKey.userName = key.userName;

    // BEGIN, CR00274837 ZV
    userNameAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();
    // END, CR00274837

    // If there is an active task redirection period in place, then retrieve
    // the name of the user to whom the tasks will be redirected to.
    curam.core.sl.entity.struct.TaskRedirectionOrAllocationBlockingPeriodDetails activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = new curam.core.sl.entity.struct.TaskRedirectionOrAllocationBlockingPeriodDetails();

    activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails = taskRedirection.readTaskRedirectionOrAllocationBlockingPeriodForUser(
      userNameAndDateTimeKey);

    // creating users Object
    final curam.core.intf.Users usersObj = UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    final UsersDtls usersDtls = usersObj.read(usersKey);

    if (usersDtls.businessEmailID != 0) {
      // get the Email address
      final EmailAddress emailAddress = EmailAddressFactory.newInstance();
      final EmailAddressKey emailAddressKey = new EmailAddressKey();

      emailAddressKey.emailAddressID = usersDtls.businessEmailID;
      userEmailAddressDtls = emailAddress.read(emailAddressKey);
    }

    if (usersDtls.businessPhoneID != 0) {
      // get the ID for the phone record inserted
      getPhoneNumberKey.phoneNumberID = usersDtls.businessPhoneID;
      phoneNumberDetails = maintainPhoneNumberObj.readPhoneNumber(
        getPhoneNumberKey);
    }
    userDetails.userName = key.userName;
    userDetails.userEmail = userEmailAddressDtls.emailAddress;
    userDetails.phoneNumber = phoneNumberDetails.phoneNumber;
    userDetails.phoneAreaCode = phoneNumberDetails.phoneAreaCode;
    userDetails.phoneCountryCode = phoneNumberDetails.phoneCountryCode;
    userDetails.phoneExtension = phoneNumberDetails.phoneExtension;

    userDetails.userFullName = usersObj.readUserFullname(usersKey).fullname;
    if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails != null) {
      if (activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName.length()
        != 0) {
        usersKey.userName = activeTaskRedirectionOrTaskAllocationBlockingPeriodDetails.toUserName;
        userDetails.tasksRedirectedTo = usersObj.readUserFullname(usersKey).fullname;
      }

    }

    userDetails.userEmailLink = kMailLink + userEmailAddressDtls.emailAddress;

    return userDetails;
  }

  // END, CR00216252

  // BEGIN, CR00232351, ZV
  // ___________________________________________________________________________
  /**
   * Reads the Organization Unit tab display details for supervisor workspace.
   *
   * @param key Key of organization unit to be read
   *
   * @return Organization unit tab display details
   */
  @Override
  public OrganisationUnitTabDetails readOrgUnitTabDetails(
    final curam.core.sl.entity.struct.OrgStructureAndOrgUnitKey key)
    throws AppException, InformationalException {

    final OrganisationUnitTabDetails organisationUnitTabDetails = new OrganisationUnitTabDetails();

    final curam.core.sl.intf.OrganisationUnit organisationUnitSLObj = curam.core.sl.fact.OrganisationUnitFactory.newInstance();

    final OrgStructureAndOrgUnitKey orgStructureAndOrgUnit = new OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnit.orgStructAndOrgUnitKey.organisationStructureID = key.organisationStructureID;
    orgStructureAndOrgUnit.orgStructAndOrgUnitKey.organisationUnitID = key.organisationUnitID;

    // read contact details for organization unit
    final OrganisationUnitContactDetails organisationUnitContactDetails = organisationUnitSLObj.getContactDetails(
      orgStructureAndOrgUnit);

    organisationUnitTabDetails.assign(
      organisationUnitContactDetails.organisationUnitContactDetails);

    if (organisationUnitContactDetails.organisationUnitContactDetails.phoneNumber.length()
      > 0) {

      final AdminUser adminUserObj = AdminUserFactory.newInstance();
      final UserKeyStruct userKeyStruct = new UserKeyStruct();

      userKeyStruct.userName = organisationUnitContactDetails.organisationUnitContactDetails.userName;

      final UserDetails userDetails = adminUserObj.read(userKeyStruct);

      if (userDetails.businessPhoneID != 0) {

        final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();

        final PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

        phoneNumberKey.phoneNumberID = userDetails.businessPhoneID;

        organisationUnitTabDetails.formattedPhoneNumber = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;
      }
    }

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    OrganisationUnitDtls organisationUnitDtls = new OrganisationUnitDtls();

    organisationUnitKey.organisationUnitID = key.organisationUnitID;
    organisationUnitDtls = getOrgUnitDetails(organisationUnitKey);

    organisationUnitTabDetails.orgUnitName = organisationUnitDtls.name;
    organisationUnitTabDetails.orgUnitType = organisationUnitDtls.businessTypeCode;

    return organisationUnitTabDetails;
  }

  // END, CR00232351

  // BEGIN, CR00263925 ZV
  /**
   * Comparator used to order org unit assigned task details list by user full
   * name.
   */
  protected class OrgUnitAssignedTaskDetailsComparator implements
    Comparator<OrgUnitAssignedTasksForUserDetails> {

    /**
     * Default constructor.
     */
    public OrgUnitAssignedTaskDetailsComparator() {

      super();
    }

    /**
     * Compare two org unit assigned task details structs.
     */
    @Override
    public int compare(OrgUnitAssignedTasksForUserDetails o1,
      OrgUnitAssignedTasksForUserDetails o2) {

      // BEGIN, CR00264571 ZV
      return o2.fullName.compareTo(o1.fullName);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order org unit reserved task details list by user full
   * name.
   */
  protected class OrgUnitReservedTaskDetailsComparator
    implements
    Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetails> {

    /**
     * Default constructor.
     */
    public OrgUnitReservedTaskDetailsComparator() {

      super();
    }

    /**
     * Compare two org unit reserved task details structs.
     */
    @Override
    public int compare(
      curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetails o1,
      curam.core.sl.supervisor.struct.OrgUnitTasksReservedByUserDetails o2) {

      // BEGIN, CR00264571 ZV
      return o2.taskReservedByFullUserName.compareTo(
        o1.taskReservedByFullUserName);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order org unit task details list by user full name.
   */
  protected class OrgUnitTaskDetailsComparator
    implements
    Comparator<curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetails> {

    /**
     * Default constructor.
     */
    public OrgUnitTaskDetailsComparator() {

      super();
    }

    /**
     * Compare two org unit task details structs.
     */
    @Override
    public int compare(
      curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetails o1,
      curam.core.sl.supervisor.struct.OrgUnitTasksByUserDueOnDateDetails o2) {

      // BEGIN, CR00264571 ZV
      return o2.userFullName.compareTo(o1.userFullName);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order org unit task details list by deadline date.
   */
  protected class OrgUnitTaskDueInTheNextTimePeriodDetailsComparator
    implements Comparator<OrgUnitTasksDueInTheNextTimePeriodDetails> {

    /**
     * Default constructor.
     */
    public OrgUnitTaskDueInTheNextTimePeriodDetailsComparator() {

      super();
    }

    /**
     * Compare two org unit task details structs.
     */
    @Override
    public int compare(OrgUnitTasksDueInTheNextTimePeriodDetails o1,
      OrgUnitTasksDueInTheNextTimePeriodDetails o2) {

      // BEGIN, CR00264571 ZV
      return o2.deadlineDate.compareTo(o1.deadlineDate);
      // END, CR00264571
    }
  }

  // END, CR00263925

}
