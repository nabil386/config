/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.supervisor.sl.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.ReadByCaseStatusTypeKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.impl.TaskSortByPriority;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.struct.ListTaskKey;
import curam.core.sl.struct.ReasonEndDateComments;
import curam.core.sl.struct.ReservedByStatusTaskDetails;
import curam.core.sl.struct.SendNotificationInd;
import curam.core.sl.struct.UserNameAndStatusKey;
import curam.core.struct.CaseCount;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.OrgObjectTypeUserNameStausKey;
import curam.core.struct.ReadUserIDFullNamePositionList;
import curam.core.struct.ReassignCasesByTypeCaseAndUserKey;
import curam.core.struct.UserAndStatusKey;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORUSER;
import curam.supervisor.sl.struct.ListOpenTasksReservedByUserDetails;
import curam.supervisor.sl.struct.ListUnreservedTasksForUserDetails;
import curam.supervisor.sl.struct.ReassignCaseKey;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.util.impl.SupervisorApplicationUtil;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;


public interface CaseReassign {

  public class AutoReassign {

    /*
     * This method is called when auto reassign is performed on list of cases
     *
     * @param key ReassignCasesForUserKey
     *
     * @throws AppException
     *
     * @throws InformationalException
     */
    public final void autoReassignForUsers(ReassignCasesForUserKey key,
      boolean isIssueCase) throws AppException, InformationalException {

      // parse the Tab-delimited String and lists the cases
      final StringList strList = StringUtil.tabText2StringList(
        key.reassignCasesList);
      Vector vector = new Vector();

      // This method is called for validation of each case.
      SupervisorApplicationUtil.validateReassignCase(key, strList);

      String username = new String();
      String reassignCaseFromNotificationEnabled = new String();

      // A boolean parameter is checked to display issue case specific messages.
      if (isIssueCase) {
        reassignCaseFromNotificationEnabled = curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_SUPERVISOR_REASSIGNCASEISSUEFROMNOTIFICATION);
      } else {
        reassignCaseFromNotificationEnabled = curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_SUPERVISOR_REASSIGNCASESFROMNOTIFICATION);
      }
      final SupervisorApplicationUtil supervisorApplicationUtil = new SupervisorApplicationUtil();

      // If notification to the current owner is enabled then send a
      // notification.
      if (reassignCaseFromNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {

        supervisorApplicationUtil.sendFromNotificationForListOfCases(key,
          strList, isIssueCase);
      }

      // If case size is less than or equal 2 then those cases will be
      // reassigned to User who already has least cases assigned.
      if (strList.size() <= 2) {
        for (int i = 0; i < strList.size(); i++) {
          final long caseID = Long.parseLong(strList.item(i));

          // It returns list of Users who has least number of cases assigned.
          vector = getAutoReassignVector(caseID);
          // Get a random user from the above list
          username = getRandomReassignUsername(vector);
          // Assign the case to the new owner( user selected above).
          assignNewCaseOwner(key, username, caseID);
        }
      } // If number of cases are greater than 2, evenly distribute the cases
      // among
      // the users
      else {
        // Gets the list of users along with the count of newly cases which need
        // to be assigned to them
        final LinkedHashMap map = getUsersAndNewCaseCountMap(strList.size());
        final Set keySet = map.keySet();
        final Iterator itr = keySet.iterator();
        int startCaseCount = 0;
        int endCaseCount = 0;

        // Iterating through users from the map
        while (itr.hasNext()) {

          username = (String) itr.next();
          // This variable stores the end count of cases assigned to the users.
          endCaseCount = endCaseCount
            + ((Integer) map.get(username)).intValue();
          // This loop assigns cases to a user one by one.
          for (int i = startCaseCount; i < endCaseCount; i++) {
            final long caseID = Long.parseLong(strList.item(i));
            final OrgObjectLink orgObjectLink = OrgObjectLinkFactory.newInstance();
            final ReadByCaseStatusTypeKey readByCaseStatusTypeKey = new ReadByCaseStatusTypeKey();

            readByCaseStatusTypeKey.caseID = caseID;
            readByCaseStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
            readByCaseStatusTypeKey.typeCode = CASEUSERROLETYPE.OWNER;

            // BEGIN, CR00080887, CM
            // read the username by caseID, type
            final UsersKey usersKey = orgObjectLink.readUserNameByCaseIDTypeStatus(
              readByCaseStatusTypeKey);

            // END, CR00080887

            // Checking the case is not assigned to same user.
            if (usersKey.userName.equals(username)) {
              endCaseCount = endCaseCount - 1;
              break;
            } // If it is different user then that user will be made owner of
            // the
            // case.
            else {
              assignNewCaseOwner(key, username, caseID);
            }
          }
          // For Loop to start from where it ended.
          startCaseCount = endCaseCount;
        }
      }

      // Send a Notification to the new owner
      String reassignCaseToNotificationEnabled = new String();

      // A boolean parameter is checked to display issue case specific messages.
      if (isIssueCase) {
        reassignCaseToNotificationEnabled = curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_SUPERVISOR_REASSIGNCASEISSUETONOTIFICATION);
      } else {
        reassignCaseToNotificationEnabled = curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_SUPERVISOR_REASSIGNCASESTONOTIFICATION);
      }

      if (reassignCaseToNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
        // Send a Notification to new owner
        supervisorApplicationUtil.sendToNotificationForListOfCases(key, strList,
          isIssueCase);
      }
    }

    /*
     * This method changes the owner ship of the case with new user
     *
     * @param key ReassignCasesForUserKey, Username String, caseID long.
     *
     * @throws AppException
     *
     * @throws InformationalException
     */
    protected void assignNewCaseOwner(ReassignCasesForUserKey key,
      String username, long caseID) throws AppException,
        InformationalException {

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

      final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

      final ReassignCasesByTypeCaseAndUserKey reassignCasesByTypeCaseAndUserKey = new ReassignCasesByTypeCaseAndUserKey();

      reassignCasesByTypeCaseAndUserKey.currentUserID = key.currentUserID;

      key.newUserID = reassignCasesByTypeCaseAndUserKey.newUserID = username;

      SupervisorApplicationUtil.validateReassignCaseUser(key);

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = caseID;

      // Read case details that has to be reassigned
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      if (CASESTATUS.CLOSED.equals(caseHeaderDtls.statusCode)) {
        final AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_CASESTATUS_CLOSED);

        ae.arg(caseHeaderDtls.caseReference);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }

      final ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

      key.OrgObjLinkDtls.orgObjectType = key.organisationObject;
      key.OrgObjLinkDtls.userName = key.newUserID;

      final SendNotificationInd sendNotificationInd = new SendNotificationInd();

      sendNotificationInd.sendNotification = false;

      // Call CaseUserRole to create the new case owner
      caseUserRole.modifyCaseOwner(caseHeaderKey, key.OrgObjLinkDtls,
        reasonEndDateComments, sendNotificationInd);
    }

    /*
     * This method is called when auto reassign is performed on a single case
     *
     * @param ReassignCaseKey key,
     *
     * @throws AppException
     *
     * @throws InformationalException
     */
    public final void autoReassignUser(ReassignCaseKey key)
      throws AppException, InformationalException {

      // CaseUserRole manipulation variables
      final curam.core.sl.intf.CaseUserRole caseUserRole = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      String newUserID;

      final CaseReassign.AutoReassign autoReassign = new CaseReassign.AutoReassign();
      final Vector vector = autoReassign.getAutoReassignVector(key.caseID);
      HashMap hashMap;
      Set keys;
      Iterator It;

      if (vector.size() > 1) {
        hashMap = (HashMap) vector.get(1);
        keys = hashMap.keySet();
        It = keys.iterator();
        newUserID = (String) It.next();
      } else {
        hashMap = (HashMap) vector.get(0);
        keys = hashMap.keySet();
        It = keys.iterator();
        newUserID = (String) It.next();
      }

      SupervisorApplicationUtil.validateReassignCase(key);
      key.newUserID = newUserID;
      SupervisorApplicationUtil.validateReassignUser(key);

      // Send a Notification to the current owner
      final String reassignCaseFromNotificationEnabled = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_REASSIGNCASEFROMNOTIFICATION);
      // if notification to the current owner is enabled then send a
      // notification.
      final SupervisorApplicationUtil supervisorApplicationUtil = new SupervisorApplicationUtil();

      if (reassignCaseFromNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
        final ReassignCaseKey reassignCaseKey = new ReassignCaseKey();

        reassignCaseKey.caseID = key.caseID;
        // Send a Notification to owner
        supervisorApplicationUtil.sendFromNotificationForSingleCase(
          reassignCaseKey);
      }

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      key.OrgObjLinkDtls.userName = key.newUserID;
      key.OrgObjLinkDtls.orgObjectType = ORGOBJECTTYPE.USER;

      final ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

      final SendNotificationInd sendNotificationInd = new SendNotificationInd();

      sendNotificationInd.sendNotification = false;

      // Call CaseUserRole to create the new case owner
      caseUserRole.modifyCaseOwner(caseHeaderKey, key.OrgObjLinkDtls,
        reasonEndDateComments, sendNotificationInd);

      // Send a Notification to the new owner
      final String reassignCaseToNotificationEnabled = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_REASSIGNCASETONOTIFICATION);

      if (reassignCaseToNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
        // Send a Notification to new owner
        supervisorApplicationUtil.sendToNotificationForSingleCase(key);
      }
    }

    /*
     * Gets the list of users along with the count of newly cases which need to
     * be assigned to them.
     *
     * @param Number of task.
     *
     * @throws AppException
     *
     * @throws InformationalException
     */
    public LinkedHashMap getUsersAndNewCaseCountMap(int Numberoftask)
      throws AppException, InformationalException {

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      // BEGIN, CR00103515 ,BD
      final LinkedHashMap<String, Integer> caseUserMap = new LinkedHashMap<String, Integer>();
      // END, CR00103515

      final UserAndStatusKey userAndStatusKey = new UserAndStatusKey();

      // Set the logged-in username and record status to fetch the list of users
      final SystemUser systemUser = SystemUserFactory.newInstance();

      userAndStatusKey.userName = systemUser.getUserDetails().userName;
      userAndStatusKey.status = curam.codetable.RECORDSTATUS.CANCELLED;

      final Users usersObj = UsersFactory.newInstance();

      ReadUserIDFullNamePositionList namePositionList = new ReadUserIDFullNamePositionList();

      final String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;

      final String orgUnitSelectOption = Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

      if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
        namePositionList = usersObj.searchSupervisorUsersLeadPos(
          userAndStatusKey);
      } else {
        namePositionList = usersObj.searchSupervisorUsers(userAndStatusKey);
      }
      final OrgObjectTypeUserNameStausKey orgObjectTypeUserNameStausKey = new OrgObjectTypeUserNameStausKey();

      // Loops through all the users to gets the total case associated with it.
      for (int i = 0; i < namePositionList.dtls.size(); i++) {
        if (!namePositionList.dtls.item(i).userName.equals(
          userAndStatusKey.userName)) {
          orgObjectTypeUserNameStausKey.userName = namePositionList.dtls.item(i).userName;
          orgObjectTypeUserNameStausKey.caseStatus = CASESTATUS.OPEN;
          orgObjectTypeUserNameStausKey.orgObjectType = ORGOBJECTTYPE.USER;
          final CaseCount caseCount = caseHeaderObj.countByOrgObjectTypeUserNameAndStatus(
            orgObjectTypeUserNameStausKey);

          caseUserMap.put(namePositionList.dtls.item(i).userName,
            new Integer(caseCount.value));
        }
      }
      // Sorts the map based on value (case count) not on key.
      LinkedHashMap sortedMap = new LinkedHashMap();

      sortedMap = sortMap(caseUserMap);
      // Finds the users who has maximum case assigned.
      final String maxKey = findhighest(sortedMap);
      // Gets the new map with users and the case count which needs to be
      // reassigned.
      final LinkedHashMap newMap = distributeTasks(sortedMap, Numberoftask,
        maxKey);

      return newMap;
    }

    /*
     * This method sorts the map based on map value.
     *
     * @param map LinkedHashMap.
     *
     * @return LinkedHashMap
     */
    public LinkedHashMap sortMap(LinkedHashMap map) {

      final List mapKeys = new ArrayList(map.keySet());
      final List mapValues = new ArrayList(map.values());

      Collections.sort(mapValues);
      Collections.sort(mapKeys);

      // BEGIN, CR00103515 ,BD
      final LinkedHashMap<String, Integer> sortMap = new LinkedHashMap<String, Integer>();
      // END, CR00103515

      final Iterator valueIt = mapValues.iterator();

      while (valueIt.hasNext()) {
        final Integer val = (Integer) valueIt.next();
        final Iterator keyIt = mapKeys.iterator();

        while (keyIt.hasNext()) {
          final Object key = keyIt.next();

          if (map.get(key).toString().equals(val.toString())) {
            mapKeys.remove(key);
            sortMap.put(key.toString(), val);
            break;
          }
        }
      }
      return sortMap;
    }

    /*
     * This method gets the user who has maximum cases assigned.
     *
     * @param map LinkedHashMap.
     *
     * @return String
     */
    public String findhighest(LinkedHashMap map) {

      String resultKey = null;
      int maxValue = 0;

      final Set keySet = map.keySet();
      final Iterator itr = keySet.iterator();

      if (map.size() == 1) {
        return (String) itr.next();
      }
      while (itr.hasNext()) {
        if (resultKey == null) {
          final String key1 = (String) itr.next();
          final String key2 = (String) itr.next();
          final int tempValue1 = ((Integer) map.get(key1)).intValue();
          final int tempValue2 = ((Integer) map.get(key2)).intValue();

          if (tempValue1 > tempValue2) {
            resultKey = key1;
            maxValue = tempValue1;
          } else {
            resultKey = key2;
            maxValue = tempValue2;
          }
        } else {
          final String key1 = (String) itr.next();
          final int tempValue1 = ((Integer) map.get(key1)).intValue();

          if (maxValue < tempValue1) {
            resultKey = key1;
            maxValue = tempValue1;
          }
        }
      }
      return resultKey;
    }

    /*
     * This method evenly distributes the new cases among the users.
     *
     * @param orgMap LinkedHashMap,tasksCount int, maxUser String.
     *
     * @return LinkedHashMap
     */
    public LinkedHashMap distributeTasks(LinkedHashMap orgMap,
      int tasksCount, String maxUser) {

      // BEGIN, CR000103515, BD
      final LinkedHashMap<String, Integer> newTasks = new LinkedHashMap<String, Integer>();
      final LinkedHashMap<String, Integer> newTasks1 = new LinkedHashMap<String, Integer>();
      // END, CR00103515

      final int maxTasksAssigned = Integer.parseInt(
        orgMap.get(maxUser).toString());
      int remainingTasks = tasksCount;
      final Set keySet = orgMap.keySet();
      final int userCount = keySet.size();
      final Iterator itr = keySet.iterator();
      int previousUser = 0;

      // Cases are distributed evenly comparing with User having maximum cases.
      while (itr.hasNext()) {
        final String key1 = (String) itr.next();
        final int tempValue1 = ((Integer) orgMap.get(key1)).intValue();

        if (maxTasksAssigned != tempValue1 && remainingTasks > 0) {
          final int newTasksCount = maxTasksAssigned - tempValue1;

          remainingTasks = remainingTasks - newTasksCount;
          if (remainingTasks > 0) {
            newTasks.put(key1, new Integer(newTasksCount));
            previousUser = previousUser + newTasksCount;
          } else {
            newTasks.put(key1, new Integer(tasksCount - previousUser));
          }
          continue;
        }
        newTasks.put(key1, new Integer(0));
      }
      orgMap.putAll(newTasks);
      // After cases are distributed according to Maximum user case and still
      // has
      // remaining cases it will be distributed among all the users.
      if (remainingTasks > 0) {
        final int moreTasksAssigned = remainingTasks / userCount;
        int rem = remainingTasks % userCount;
        final Set kSet = orgMap.keySet();
        final Iterator itr1 = kSet.iterator();

        while (itr1.hasNext()) {
          final String key = (String) itr1.next();
          final int tempValue = ((Integer) orgMap.get(key)).intValue();

          if (rem > 0) {
            newTasks1.put(key, new Integer(tempValue + moreTasksAssigned + 1));
            rem--;
          } else {
            newTasks1.put(key, new Integer(tempValue + moreTasksAssigned));
          }
        }
      }
      orgMap.putAll(newTasks1);
      return orgMap;
    }

    /*
     * This method provide the vector with collection of user and case count.
     * An algorithm is implemented as per specification to get the collection.
     *
     * @param caseID long.
     *
     * @return Vector.
     *
     * @throws AppException
     *
     * @throws InformationalException
     */
    public Vector getAutoReassignVector(long caseID) throws AppException,
        InformationalException {

      // set the logged in username & the status to the UserCaseTaskStatus
      // object
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      // BEGIN, CR00103515 ,BD
      final Vector<HashMap> vector = new Vector<HashMap>();
      final HashMap<String, Integer> caseUserMap = new HashMap<String, Integer>();
      // END, CR00103515

      int count = 0;

      // UserAndStatusKey object
      final UserAndStatusKey userAndStatusKey = new UserAndStatusKey();

      // Set the logged-in username and the record status to fetch
      // the list of users
      userAndStatusKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
      userAndStatusKey.status = curam.codetable.RECORDSTATUS.CANCELLED;

      final Users usersObj = UsersFactory.newInstance();

      ReadUserIDFullNamePositionList namePositionList = new ReadUserIDFullNamePositionList();

      final String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;

      final String orgUnitSelectOption = Configuration.getProperty(
        EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

      if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
        namePositionList = usersObj.searchSupervisorUsersLeadPos(
          userAndStatusKey);
      } else {
        namePositionList = usersObj.searchSupervisorUsers(userAndStatusKey);
      }
      final OrgObjectTypeUserNameStausKey orgObjTypeUserNameStatusKey = new OrgObjectTypeUserNameStausKey();

      final OrgObjectLink orgObjectLink = OrgObjectLinkFactory.newInstance();
      final ReadByCaseStatusTypeKey readByCaseStatusTypeKey = new ReadByCaseStatusTypeKey();

      readByCaseStatusTypeKey.caseID = caseID;
      readByCaseStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
      readByCaseStatusTypeKey.typeCode = CASEUSERROLETYPE.OWNER;

      // BEGIN, CR00080887, CM
      // read the username by caseID, type
      final UsersKey usersKey = orgObjectLink.readUserNameByCaseIDTypeStatus(
        readByCaseStatusTypeKey);

      // END, CR00080887

      for (int i = 0; i < namePositionList.dtls.size(); i++) {
        if (!namePositionList.dtls.item(i).userName.equals(usersKey.userName)) {
          orgObjTypeUserNameStatusKey.userName = namePositionList.dtls.item(i).userName;
          orgObjTypeUserNameStatusKey.caseStatus = CASESTATUS.OPEN;
          orgObjTypeUserNameStatusKey.orgObjectType = ORGOBJECTTYPE.USER;
          final CaseCount caseCount = caseHeaderObj.countByOrgObjectTypeUserNameAndStatus(
            orgObjTypeUserNameStatusKey);

          if (i == 0) {
            count = caseCount.value;
            caseUserMap.put(namePositionList.dtls.item(i).userName,
              new Integer(caseCount.value));
          } else {
            if (caseCount.value == count) {
              caseUserMap.put(namePositionList.dtls.item(i).userName,
                new Integer(caseCount.value));
            } else if (caseCount.value < count) {
              caseUserMap.clear();
              count = caseCount.value;
              caseUserMap.put(namePositionList.dtls.item(i).userName,
                new Integer(caseCount.value));
            }
          }
        }
      }
      vector.add(caseUserMap);

      // If more than one user has the smallest number of cases, determine the
      // user with fewest tasks reserved. If only one user is returned, assign
      // the case to this user.

      // BEGIN, CR00103515 ,BD
      final HashMap<String, Integer> userOpenTasksMap = new HashMap<String, Integer>();

      // END, CR00103515

      if (caseUserMap.size() == 1) {
        vector.add(caseUserMap);
        return vector;
      } else {
        final curam.core.sl.intf.Inbox inbox = curam.core.sl.fact.InboxFactory.newInstance();
        final UserNameAndStatusKey userNameAndStatusKey = new UserNameAndStatusKey();
        int openTaskCount;

        count = 0;
        final Set keys = caseUserMap.keySet();
        final Iterator It = keys.iterator();

        while (It.hasNext()) {
          final String HostNow = (String) It.next();
          final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDtls = new ListOpenTasksReservedByUserDetails();

          userNameAndStatusKey.userName = HostNow;
          userNameAndStatusKey.statusCode = TASKSTATUS.NOTSTARTED;

          listOpenTasksReservedByUserDtls.taskDetailsList = inbox.listLimitedReservedTasksByStatus(
            userNameAndStatusKey, inbox.getInboxTaskReadMultiDetails());
          final TaskSortByPriority<ReservedByStatusTaskDetails> prioritySort = new TaskSortByPriority<ReservedByStatusTaskDetails>();

          prioritySort.sortIfEnabled(
            listOpenTasksReservedByUserDtls.taskDetailsList.taskDetailsList);

          openTaskCount = listOpenTasksReservedByUserDtls.taskDetailsList.taskDetailsList.size();
          if (count == 0) {
            count = openTaskCount;
            userOpenTasksMap.put(userNameAndStatusKey.userName,
              new Integer(count));
          } else {
            if (openTaskCount == count) {
              userOpenTasksMap.put(userNameAndStatusKey.userName,
                new Integer(count));
            } else if (openTaskCount < count) {
              userOpenTasksMap.clear();
              count = openTaskCount;
              userOpenTasksMap.put(userNameAndStatusKey.userName,
                new Integer(count));
            }
          }
        }
      }
      // If more than 1 user has the smaller number of reserved tasks ,determine
      // the user with fewest tasks assigned. If only one user is returned
      // assign the case to this user.
      // BEGIN, CR00103515 ,BD
      final HashMap<String, Integer> userAssignedTasksMap = new HashMap<String, Integer>();

      // END, CR00103515

      if (userOpenTasksMap.size() == 1) {
        vector.add(userOpenTasksMap);
        return vector;
      } else {
        int assignTaskCount = 0;

        // BEGIN, CR00114996, GSP
        count = 0;
        // END, CR00114996
        final ListTaskKey listTaskKey = new ListTaskKey();
        final ListUnreservedTasksForUserDetails listReservationTasksforUserDetails = new ListUnreservedTasksForUserDetails();
        final curam.core.sl.intf.Inbox inbox = InboxFactory.newInstance();

        final Set keys = userOpenTasksMap.keySet();
        final Iterator It = keys.iterator();

        while (It.hasNext()) {
          final String HostNow = (String) It.next();

          listTaskKey.userName = HostNow;
          listReservationTasksforUserDetails.taskDetailsList = inbox.listAssigned(
            listTaskKey);
          assignTaskCount = listReservationTasksforUserDetails.taskDetailsList.taskDetailsList.size();
          // BEGIN, CR00114996, GSP
          if (count == 0) {
            // END, CR00114996
            count = assignTaskCount;
            userAssignedTasksMap.put(listTaskKey.userName,
              new Integer(assignTaskCount));
          } else {
            if (assignTaskCount == count) {
              userAssignedTasksMap.put(listTaskKey.userName,
                new Integer(assignTaskCount));
            } else if (assignTaskCount < count) {
              userAssignedTasksMap.clear();
              count = assignTaskCount;
              userAssignedTasksMap.put(listTaskKey.userName,
                new Integer(assignTaskCount));
            }
          }
        }
      }
      vector.add(userAssignedTasksMap);
      return vector;
    } // End of Method getAutoReassignVector

    /*
     * This method selects one user randomly.
     * be assigned to them.
     *
     * @param Vector .
     */
    protected String getRandomReassignUsername(Vector vector) {

      HashMap hashMap;
      String userName = "", reassignCaseUser = "";
      Set keys;
      Iterator It;
      int countTask = 0;

      // If more than one user has the smallest number of assigned tasks, assign
      // the case randomly to one of the remaining candidates.
      if (vector.size() > 1) {
        hashMap = (HashMap) vector.get(1);
        keys = hashMap.keySet();
        It = keys.iterator();
        reassignCaseUser = (String) It.next();
        vector.remove(vector.get(1));
        hashMap = (HashMap) vector.get(0);
      } else {
        hashMap = (HashMap) vector.get(0);
        keys = hashMap.keySet();
        It = keys.iterator();
        int i = 0;

        while (It.hasNext()) {
          userName = (String) It.next();
          if (i == 0) {
            countTask = ((Integer) hashMap.get(userName)).intValue();
            reassignCaseUser = userName;
            i++;
          } else {
            if (countTask > ((Integer) hashMap.get(userName)).intValue()) {
              countTask = ((Integer) hashMap.get(userName)).intValue();
              reassignCaseUser = userName;
            }
          }
        }
      }
      countTask = ((Integer) hashMap.get(reassignCaseUser)).intValue();
      hashMap.remove(reassignCaseUser);
      final Integer countTaskObj = new Integer(++countTask);

      hashMap.put(reassignCaseUser, countTaskObj);

      return reassignCaseUser;
    }// End of Method getRandomReassignUsername
  }// End of inner class
}// End of Outer class
