/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;


import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.CASEISSUESVIEWOPTIONPAGE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.SUPERVISORCASEISSUESVIEW;
import curam.codetable.TASKOPTIONPAGE;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.core.facade.fact.SystemFactory;
import curam.core.facade.struct.CodeTableName;
import curam.core.facade.struct.CodetableCodeAndDescription;
import curam.core.facade.struct.CodetableCodeAndDescriptionList;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.SystemUser;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.supervisor.fact.CaseWorkspaceFactory;
import curam.core.sl.supervisor.intf.CaseWorkspace;
import curam.core.sl.supervisor.struct.CaseTasksByUserKey;
import curam.core.sl.supervisor.struct.CaseTasksDetailsList;
import curam.core.sl.supervisor.struct.CaseTasksDueOnDateDetailsList;
import curam.core.sl.supervisor.struct.CaseTasksDueOnDateKey;
import curam.core.sl.supervisor.struct.CaseTasksKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDDetailsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserNameKey;
import curam.supervisor.facade.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.facade.struct.CaseDetailsList;
import curam.supervisor.facade.struct.CaseDetailsResultList;
import curam.supervisor.facade.struct.CaseIDAndCaseIssuesViewKey;
import curam.supervisor.facade.struct.CaseIDAndDeadlineDateKey;
import curam.supervisor.facade.struct.CaseIDAndTaskOptionKey;
import curam.supervisor.facade.struct.CaseIDAndUserKey;
import curam.supervisor.facade.struct.CaseIdAndIssueTypeKey;
import curam.supervisor.facade.struct.CaseIssueDetailsList;
import curam.supervisor.facade.struct.CaseIssuesChartDetails;
import curam.supervisor.facade.struct.CaseIssuesOfAType;
import curam.supervisor.facade.struct.CaseStatus;
import curam.supervisor.facade.struct.CaseStatusList;
import curam.supervisor.facade.struct.CaseTaskForwardKey;
import curam.supervisor.facade.struct.CaseTypeDetails;
import curam.supervisor.facade.struct.CaseTypeDetailsList;
import curam.supervisor.facade.struct.CaseUsersScheduleDetailsList;
import curam.supervisor.facade.struct.CaseWorkspaceDetails;
import curam.supervisor.facade.struct.ListCaseReservedTasksDetails;
import curam.supervisor.facade.struct.ListCaseTasksDetails;
import curam.supervisor.facade.struct.ListCaseTasksDueByWeekDetails;
import curam.supervisor.facade.struct.ListCaseTasksDueOnDateDetails;
import curam.supervisor.facade.struct.ListDeferredCaseTasksReservedByUserDetails;
import curam.supervisor.facade.struct.ListOpenCaseTasksReservedByUserDetails;
import curam.supervisor.facade.struct.ProductStatusOrgObjectCaseTypeKey;
import curam.supervisor.facade.struct.ProductStausOrgObjectCaseTypeKey;
import curam.supervisor.facade.struct.ProductTypeDetails;
import curam.supervisor.facade.struct.ProductTypeDetailsList;
import curam.supervisor.facade.struct.ReassignCaseKey;
import curam.supervisor.facade.struct.ReassignCasesForUserKey;
import curam.supervisor.facade.struct.ResolveCaseIssuesOptionPageDetails;
import curam.supervisor.facade.struct.ResolveCaseIssuesOptionPageKey;
import curam.supervisor.facade.struct.ResolveReserveTaskOptionPageKey;
import curam.supervisor.facade.struct.ResolveTaskOptionCodeKey;
import curam.supervisor.facade.struct.ResolveTaskOptionPageDetails;
import curam.supervisor.facade.struct.ResolveTaskOptionPageKey;
import curam.supervisor.facade.struct.SupUserDetails;
import curam.supervisor.facade.struct.SupUserDetailsList;
import curam.supervisor.facade.struct.SupervisorUsersDetailsList;
import curam.supervisor.facade.struct.UserAndCaseTaskDetailsKey;
import curam.supervisor.facade.struct.caseID;
import curam.supervisor.sl.fact.MaintainSupervisorCaseFactory;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.impl.SupervisorApplicationPageContextDescription;
import curam.supervisor.sl.impl.SupervisorConst;
import curam.supervisor.sl.struct.CaseIDDateKey;
import curam.supervisor.sl.struct.CaseReservedTasksDetailsList;
import curam.supervisor.sl.struct.CaseTabDetails;
import curam.supervisor.sl.struct.OrgUintDetails;
import curam.supervisor.sl.struct.OrgUnitDetailsList;
import curam.supervisor.sl.util.impl.CasesForSupervisor;
import curam.supervisor.sl.util.impl.CasesForSupervisorImpl;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.intf.CodeTable;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.transaction.TransactionInfo;
import java.util.Set;


/**
 * This class Holds API for Supervisor Case related functions.
 *
 */
public abstract class MaintainSupervisorCase extends curam.supervisor.facade.base.MaintainSupervisorCase {

  // __________________________________________________________________________
  /**
   * Lists all the Case statuses. Supervisor gets a list of all the
   * Case-Status in the drop down in filter section on the Cases page.
   * (E.g Active, Approved, Open, Closed etc.)
   * NOTE: This method should not be called.
   * The Case Status drop downs are populated from the codetable file
   * CT_CaseStatus.ctx.
   *
   * @return CaseStatusList - List of Case Status
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseStatusList getAllCaseStatuses() throws AppException,
      InformationalException {

    // object creation
    final CaseStatusList caseStatusDetailsList = new CaseStatusList();
    CaseStatus caseStatusDetails = new CaseStatus();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey nameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00101928, BD
    // Get locale value
    final String locale = curam.util.transaction.TransactionInfo.getProgramLocale();

    final String[] codeTableItems = curam.util.type.CodeTable.getAllCodes(
      CASESTATUS.TABLENAME, locale);

    // assign values
    caseStatusDetails.status = SupervisorConst.kcode_All;
    // BEGIN, CR00109753, SK
    final LocalisableString messageAll = new LocalisableString(
      curam.message.BPOSUPERVISORCONST.INF_CONST_ALL);

    caseStatusDetails.description = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00109753

    caseStatusDetailsList.dtls.addRef(caseStatusDetails);

    // Create a list of case statuses
    for (int i = 0; i < codeTableItems.length; i++) {

      final String codeTableCode = codeTableItems[i];

      if (CASESTATUS.ACTIVE.equals(codeTableCode)
        || CASESTATUS.APPROVED.equals(codeTableCode)
        || CASESTATUS.OPEN.equals(codeTableCode)
        || CASESTATUS.COMPLETED.equals(codeTableCode)
        || CASESTATUS.DELAYEDPROC.equals(codeTableCode)
        || CASESTATUS.SUSPENDED.equals(codeTableCode)
        || CASESTATUS.PENDINGCLOSURE.equals(codeTableCode)) {

        caseStatusDetails = new CaseStatus();
        caseStatusDetails.status = codeTableCode;
        caseStatusDetails.description = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(CASESTATUS.TABLENAME,
          codeTableCode, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        caseStatusDetailsList.dtls.addRef(caseStatusDetails);
      }
    }
    // END, CR00101928

    // get the user name and the page context details for the user
    nameKey.userName = systemUser.getUserDetails().userName;
    caseStatusDetailsList.pageContextDescription = contextDescription.readUserNamePageContextDescription(
      nameKey);

    return caseStatusDetailsList;
  }

  // BEGIN, CR00304801, VT
  /**
   * Lists supervisor cases by product status and organization unit.
   * Supervisor views list of cases filter by product status and Organization
   * Unit.
   *
   * @param productStatusOrgObjectCaseTypeKey contains product status case type
   * key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public CaseDetailsResultList listCasesByProductStatusCaseTypeAndOrganisationObject(
    final ProductStatusOrgObjectCaseTypeKey productStatusOrgObjectCaseTypeKey)
    throws AppException, InformationalException {

    final CaseDetailsResultList caseDetailsResultList = new CaseDetailsResultList();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCaseObj = MaintainSupervisorCaseFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription supervisorApplicationPageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    userNameKey.userName = systemUserObj.getUserDetails().userName;
    caseDetailsResultList.pageContextDescription = supervisorApplicationPageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    if (SupervisorConst.kcode_All.equals(
      productStatusOrgObjectCaseTypeKey.dtls.productType)) {
      caseDetailsResultList.filter.productTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.productTypeName = readCodeTableItemDescription(
        productStatusOrgObjectCaseTypeKey.dtls.productType,
        PRODUCTTYPE.TABLENAME);
    }

    if (SupervisorConst.kcode_All.equals(
      productStatusOrgObjectCaseTypeKey.dtls.caseType)) {
      caseDetailsResultList.filter.caseTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.caseTypeName = readCodeTableItemDescription(
        productStatusOrgObjectCaseTypeKey.dtls.caseType, CASETYPECODE.TABLENAME);
    }

    if (CuramConst.gkEmpty.equals(
      productStatusOrgObjectCaseTypeKey.dtls.statusCode.trim())) {
      caseDetailsResultList.filter.caseStatus = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.caseStatus = readCodeTableItemDescription(
        productStatusOrgObjectCaseTypeKey.dtls.statusCode, CASESTATUS.TABLENAME);
    }

    caseDetailsResultList.dtls = maintainSupervisorCaseObj.listCasesByProductStatusCaseTypeAndOrganisationObject(
      productStatusOrgObjectCaseTypeKey.dtls);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      caseDetailsResultList.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return caseDetailsResultList;
  }

  // END, CR00304801

  /**
   * Method to list all product types. Supervisor gets a list of all
   * product types in the drop down in filter section on the Cases page
   * (E.g CaseSupport, Medical Assistance etc.)
   *
   * @return ProductTypeDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ProductTypeDetailsList getAllProductTypes() throws AppException,
      InformationalException {

    // object creation
    final CodeTableName codeTableName = new CodeTableName();
    final ProductTypeDetailsList productTypeDetailsList = new ProductTypeDetailsList();
    ProductTypeDetails productTypeDetails = new ProductTypeDetails();

    codeTableName.name = PRODUCTTYPE.TABLENAME;

    // BEGIN, CR00190239, NP
    final curam.core.facade.intf.System systemObj = curam.core.facade.fact.SystemFactory.newInstance();

    // Retrieve the list of items in the code table for the users locale
    final CodetableCodeAndDescriptionList codetableCodeAndDescriptionList = systemObj.listEnabledItemsInCodetableForLocale(
      codeTableName);

    productTypeDetails.code = SupervisorConst.kcode_All;
    // BEGIN, CR00109753, SK
    final LocalisableString messageAll = new LocalisableString(
      curam.message.BPOSUPERVISORCONST.INF_CONST_ALL);

    productTypeDetails.description = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00109753
    productTypeDetailsList.dtls.addRef(productTypeDetails);

    // Copy list to return object
    for (int i = 0; i
      < codetableCodeAndDescriptionList.codetableCodeAndDescription.size(); i++) {

      CodetableCodeAndDescription codetableCodeAndDescription = new CodetableCodeAndDescription();

      codetableCodeAndDescription = codetableCodeAndDescriptionList.codetableCodeAndDescription.item(
        i);
      // BEGIN, CR00468418, GK
      if (!PRODUCTTYPE.RESTRICTEDACCESS.equals(codetableCodeAndDescription.code)
        && !PRODUCTTYPE.OTHER.equals(codetableCodeAndDescription.code)) {
        // END, CR00468418
        productTypeDetails = new ProductTypeDetails();
        productTypeDetails.code = codetableCodeAndDescription.code;
        productTypeDetails.description = codetableCodeAndDescription.description;
        productTypeDetailsList.dtls.addRef(productTypeDetails);
      }
    }
    // END, CR00190239
    return productTypeDetailsList;
  }

  // __________________________________________________________________________
  /**
   * Lists all Organization Units in the drop down
   * filter section of Cases page. Supervisor gets a list of all the
   * Organization Units that are managed by him/her.
   *
   * @return OrgUnitDetailsList - List of OrganizationUint details
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public curam.supervisor.facade.struct.OrgUnitDetailsList getAllOrgUnitBySupervisor() throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();
    final curam.supervisor.facade.struct.OrgUnitDetailsList detailsList = new curam.supervisor.facade.struct.OrgUnitDetailsList();
    final OrgUintDetails orgUnitDetails = new OrgUintDetails();
    final OrgUnitDetailsList orgUnitDetailsList = maintainSupervisorCase.getAllOrgUnitBySupervisor();

    orgUnitDetails.orgUnitID = SupervisorConst.korhUint_All;
    orgUnitDetails.description = SupervisorConst.kcode_Description;
    detailsList.key.dtls.addRef(orgUnitDetails);

    for (int i = 0; i < orgUnitDetailsList.dtls.size(); i++) {
      final OrgUintDetails details = new OrgUintDetails();

      details.description = orgUnitDetailsList.dtls.item(i).description;
      details.orgUnitID = orgUnitDetailsList.dtls.item(i).orgUnitID;
      detailsList.key.dtls.addRef(details);
    }
    return detailsList;
  }

  /**
   * This readCodeTableItemDescription method reads the description of code
   * table code.
   *
   * @param codeName - String (code table code)
   * @param codeTablelName - String (code table name)
   * @return String - CodeTableItemDescription
   * @throws AppException
   * @throws InformationalException
   */
  public String readCodeTableItemDescription(final String codeName,
    final String codeTablelName) throws AppException, InformationalException {

    // object creation
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();
    // code table variables
    final CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = codeName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = codeTablelName;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    return ctitem.description;
  }

  /**
   * Lists all the Assigned Tasks. This method gives a list of all the tasks
   * associated with the case, which have not yet been reserved for
   * a supervisor case.
   *
   * @param key - CaseIDKey
   * @return ListCaseTasksDetails - list of case tasks details
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDetails listCaseAssignedTasks(
    final curam.supervisor.facade.struct.CaseIDKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseTasksDetails listCaseTasksDetails = new ListCaseTasksDetails();
    CaseTasksDetailsList caseTasksDetailsList = new CaseTasksDetailsList();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    final CaseTasksKey caseTasksKey = new CaseTasksKey();
    final CaseIDKey caseIDKeyObj = new CaseIDKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // Set caseTasksKey to read Case tasks
    caseTasksKey.bizObjectID = key.caseID;
    caseTasksKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    caseTasksKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;

    // Read the list of Case tasks
    caseTasksDetailsList = caseWorkspace.getCaseTasks(caseTasksKey);
    listCaseTasksDetails.taskDetails.assign(caseTasksDetailsList);

    // get the page context description for the case
    caseIDKeyObj.caseID = key.caseID;
    listCaseTasksDetails.pageContextDescription = contextDescription.readCasePageContextDescription(
      caseIDKeyObj);

    return listCaseTasksDetails;

  }

  /**
   * Method to reserve case tasks. This method allows the supervisor to
   * reserve all or some of the assigned tasks associated with a case,
   * to a user.
   *
   * @param key - UserAndCaseTaskDetailsKey
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public void reserveCaseTasks(final UserAndCaseTaskDetailsKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = curam.supervisor.sl.fact.MaintainSupervisorCaseFactory.newInstance();
    final curam.supervisor.sl.struct.UserAndCaseTaskDetailsKey userandCaseTaskDetailsKey = new curam.supervisor.sl.struct.UserAndCaseTaskDetailsKey();

    userandCaseTaskDetailsKey.supervisorUserName = key.key.supervisorUserName;
    userandCaseTaskDetailsKey.TaskIDKeyList = key.key.TaskIDKeyList;
    userandCaseTaskDetailsKey.userName = key.key.userName;

    // call SL method to reserve the case tasks
    maintainSupervisorCase.reserveCaseTasks(userandCaseTaskDetailsKey);
  }

  // __________________________________________________________________________
  /**
   * Lists open and deferred tasks associated with the case.
   * This method allows supervisor to list all open and deferred tasks
   * associated with a case.
   *
   * @param key - CaseIDKey
   * @return ListCaseReservedTasksDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseReservedTasksDetails readCaseReservedTasksSummaryDetails(
    final curam.supervisor.facade.struct.CaseIDKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseReservedTasksDetails listCaseReservedTasksDetails = new ListCaseReservedTasksDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = curam.supervisor.sl.fact.MaintainSupervisorCaseFactory.newInstance();
    CaseReservedTasksDetailsList caseReservedTasksDetailsList = new CaseReservedTasksDetailsList();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final CaseIDKey caseIDKeyObj = new CaseIDKey();
    // Set key to read context description
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    caseIDKey.caseID = key.caseID;
    // Read the list of Case's open and deferred tasks
    caseReservedTasksDetailsList = maintainSupervisorCase.listCaseReservedTasks(
      caseIDKey);
    listCaseReservedTasksDetails.dtls.chartXMLString = caseReservedTasksDetailsList.chartXMLString;

    // get the page context description for the case
    caseIDKeyObj.caseID = key.caseID;
    listCaseReservedTasksDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKeyObj);

    return listCaseReservedTasksDetails;

  }

  // __________________________________________________________________________
  /**
   * Lists case tasks due on that date. This method allows supervisor to list
   * all case tasks due on the specified date.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueOnDateDetails listCaseTasksDueOnDate(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseTasksDueOnDateDetails listCaseTasksDueOnDateDetails = new ListCaseTasksDueOnDateDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // assign key details
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;
    final CaseTasksDueOnDateDetailsList detailsList = caseWorkspace.getCaseTasksDueOnDate(
      tasksDueOnDateKey);

    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();

      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDueOnDateDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueOnDate(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnDateDetails.dtls = detailsList;

    // get the page context description for the case
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnDateDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnDateDetails;
  }

  /**
   * Lists assigned case tasks due on that date. This method allows supervisor
   * to list all assigned case tasks due on the specified date.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueOnDateDetails listCaseAssignedTasksDueOnDate(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseTasksDueOnDateDetails listCaseTasksDueOnDateDetails = new ListCaseTasksDueOnDateDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // assign key details
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;

    final CaseTasksDueOnDateDetailsList detailsList = caseWorkspace.getCaseTasksDueOnDate(
      tasksDueOnDateKey);

    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();

      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDueOnDateDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueOnDate(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnDateDetails.dtls = detailsList;

    // get the page context description
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnDateDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnDateDetails;
  }

  /**
   * Lists case tasks due on that week. This method allows supervisor to list
   * all case tasks due during a specified week.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueByWeekDetails listCaseTasksDueByWeek(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseTasksDueByWeekDetails listCaseTasksDueOnWeekDetails = new ListCaseTasksDueByWeekDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();

    // assign key details
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;

    final CaseTasksDetailsList detailsList = caseWorkspace.getCaseTasksDueByWeek(
      tasksDueOnDateKey);

    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();
      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueByWeek(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnWeekDetails.dtls = detailsList;

    // get the page context description
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnWeekDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnWeekDetails;
  }

  /**
   * Lists Reserved case tasks due on that week. This method allows supervisor
   * to list all reserved case tasks due during a specified week.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueByWeekDetails listCaseReservedTasksDueByWeek(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final ListCaseTasksDueByWeekDetails listCaseTasksDueOnWeekDetails = new ListCaseTasksDueByWeekDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();

    // assign key details
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;

    final CaseTasksDetailsList detailsList = caseWorkspace.getCaseTasksDueByWeek(
      tasksDueOnDateKey);

    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();

      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueByWeek(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnWeekDetails.dtls = detailsList;

    // get the page context description
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnWeekDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnWeekDetails;
  }

  /**
   * Lists assigned case tasks due on that week. This method allows supervisor
   * to list all assigned case tasks due during a specified week.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueByWeekDetails - List of case task due
   * on deadline date period
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueByWeekDetails listCaseAssignedTasksDueByWeek(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    // case tasks variables
    final ListCaseTasksDueByWeekDetails listCaseTasksDueOnWeekDetails = new ListCaseTasksDueByWeekDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // get assigned tasks due by week
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;
    final CaseTasksDetailsList detailsList = caseWorkspace.getCaseTasksDueByWeek(
      tasksDueOnDateKey);

    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();

      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueByWeek(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnWeekDetails.dtls = detailsList;

    // get the page context description for the case
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnWeekDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnWeekDetails;
  }

  /**
   * Lists Open case tasks reserved by user.
   * This method allows supervisor to fetch a list of tasks associated
   * with the cases that are open, which have been reserved by a
   * particular user.
   *
   * @param key - CaseIDAndUserKey
   * @return ListOpenCaseTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListOpenCaseTasksReservedByUserDetails listOpenCaseTasksReservedByUser(final CaseIDAndUserKey key)
    throws AppException, InformationalException {

    // object creation
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117
    final ListOpenCaseTasksReservedByUserDetails listOpenCaseTasksReservedByUserDetails = new ListOpenCaseTasksReservedByUserDetails();
    final CaseTasksByUserKey caseTaskUserKey = new CaseTasksByUserKey();
    final CaseIDKey caseIDkey = new CaseIDKey();

    // assign key details
    caseTaskUserKey.bizObjectID = key.key.caseID;
    caseTaskUserKey.taskReservedByUserName = key.key.userName;
    caseTaskUserKey.taskStatus = TASKSTATUS.NOTSTARTED;
    caseTaskUserKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    listOpenCaseTasksReservedByUserDetails.openTaskDetails = caseWorkspace.getCaseTasksByUser(
      caseTaskUserKey);

    // get the page context description for the case
    caseIDkey.caseID = key.key.caseID;
    listOpenCaseTasksReservedByUserDetails.description = contextDescription.readCasePageContextDescription(
      caseIDkey);

    return listOpenCaseTasksReservedByUserDetails;
  }

  /**
   * Lists Deferred case tasks reserved by user. This method allows
   * supervisor to fetch a list of tasks associated with the case,
   * which have been reserved by a particular user, and then deferred.
   *
   * @param key - CaseIDAndUserKey
   * @return ListDeferredCaseTasksReservedByUserDetails -
   * List of tasks associated with the case
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListDeferredCaseTasksReservedByUserDetails listDeferredCaseTasksReservedByUser(final CaseIDAndUserKey key)
    throws AppException, InformationalException {

    // object creation
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final ListDeferredCaseTasksReservedByUserDetails listDeferredCaseTasksReservedByUserDetails = new ListDeferredCaseTasksReservedByUserDetails();
    final CaseTasksByUserKey caseTaskUserKey = new CaseTasksByUserKey();
    final CaseIDKey caseIDkey = new CaseIDKey();

    // assign key details
    caseTaskUserKey.bizObjectID = key.key.caseID;
    caseTaskUserKey.taskReservedByUserName = key.key.userName;
    caseTaskUserKey.taskStatus = TASKSTATUS.DEFERRED;
    caseTaskUserKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    listDeferredCaseTasksReservedByUserDetails.defferedTaskDetails = caseWorkspace.getCaseTasksByUser(
      caseTaskUserKey);

    // get the page context description for the case
    caseIDkey.caseID = key.key.caseID;
    listDeferredCaseTasksReservedByUserDetails.description = contextDescription.readCasePageContextDescription(
      caseIDkey);

    return listDeferredCaseTasksReservedByUserDetails;
  }

  /**
   * Lists reserved case tasks due on that date. This method allows supervisor
   * to list all reserved case tasks due on the specified date.
   *
   * @param key - CaseIDAndDeadlineDateKey
   * @return ListCaseTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListCaseTasksDueOnDateDetails listCaseReservedTasksDueOnDate(
    final CaseIDAndDeadlineDateKey key) throws AppException,
      InformationalException {

    // object creation
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final ListCaseTasksDueOnDateDetails listCaseTasksDueOnDateDetails = new ListCaseTasksDueOnDateDetails();
    final CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueOnDateKey tasksDueOnDateKey = new CaseTasksDueOnDateKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // assign key details
    tasksDueOnDateKey.bizObjectID = key.caseID;
    tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    tasksDueOnDateKey.deadlineDate = key.deadlineDate;
    tasksDueOnDateKey.taskReservationStatus = key.taskType;
    final CaseTasksDueOnDateDetailsList detailsList = caseWorkspace.getCaseTasksDueOnDate(
      tasksDueOnDateKey);

    // assign the caseID value
    caseHeaderKey.caseID = key.caseID;
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {
      tasksDueOnDateKey = new CaseTasksDueOnDateKey();
      // assign key details
      tasksDueOnDateKey.bizObjectID = caseIDDetailsList.dtls.item(i).caseID;
      tasksDueOnDateKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      tasksDueOnDateKey.deadlineDate = key.deadlineDate;
      tasksDueOnDateKey.taskReservationStatus = key.taskType;

      final CaseTasksDueOnDateDetailsList intCaseDetailsList = caseWorkspace.getCaseTasksDueOnDate(
        tasksDueOnDateKey);

      for (int j = 0; j < intCaseDetailsList.dtls.size(); j++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(j));
      }
    }
    listCaseTasksDueOnDateDetails.dtls = detailsList;

    // get the page context description for the case
    caseIDKey.caseID = key.caseID;
    listCaseTasksDueOnDateDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listCaseTasksDueOnDateDetails;
  }

  /**
   * Reads case workspace details. This method allows Supervisor to read the
   * selected case details in case workspace. The Case Workspace allows
   * supervisors to manage tasks by case.
   *
   * @param key - CaseIDAndTaskOptionKey
   * @return CaseWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseWorkspaceDetails readCaseWorkspaceDetails(
    final CaseIDAndTaskOptionKey key) throws AppException,
      InformationalException {

    // object creation
    final CaseWorkspaceDetails workspaceDetails = new CaseWorkspaceDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    curam.supervisor.sl.struct.CaseWorkspaceDetails caseWorkspaceDetails = new curam.supervisor.sl.struct.CaseWorkspaceDetails();

    // assign key details
    caseIDKey.caseID = key.caseID;
    if (key.taskOption.equalsIgnoreCase(VIEWTASKSOPTION.NEXTMONTH)) {
      caseWorkspaceDetails = maintainSupervisorCase.readCaseWorkspaceMonthDetails(
        caseIDKey);
    } else {
      caseWorkspaceDetails = maintainSupervisorCase.readCaseWorkspaceDetails(
        caseIDKey);
    }
    workspaceDetails.dtls = caseWorkspaceDetails;

    // get the page context description for the case
    workspaceDetails.contextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    // set the task option code on the workspace page
    if (key.taskOption.equalsIgnoreCase("")) {
      workspaceDetails.taskOption = VIEWTASKSOPTION.DEFAULTCODE;
    } else {
      workspaceDetails.taskOption = key.taskOption;
    }

    return workspaceDetails;
  }

  /**
   * Reassigns the case to the user. This method allows Supervisor to reassign
   *
   * @param key - ReassignCaseKey
   * (Identifies user and case details for reassignment)
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void reassignCase(final ReassignCaseKey key) throws AppException,
      InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();

    // call the SL method to reassign the case
    maintainSupervisorCase.reassignCase(key.key);
  }

  /**
   * Fetches page name based on task option. This method allows supervisor to
   * view either tasks due in the next week page or tasks due in the next
   * month page.
   *
   * @param key - ResolveTaskOptionPageKey
   * @return ResolveTaskOptionPageDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveTaskOptionPageDetails resolveTaskOptionPage(
    final ResolveTaskOptionPageKey key) throws AppException,
      InformationalException {

    // object creation
    final ResolveTaskOptionPageDetails taskOptionPageDetails = new ResolveTaskOptionPageDetails();
    final int dateDiff = key.endDate.subtract(key.startDate);
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
      TASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (dateDiff > 0) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEBYWEEK_RESERVED, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEBYWEEK_ASSIGNED, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEBYWEEK_ALL, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (dateDiff == 0) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEONDATE_RESERVED, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEONDATE_ASSIGNED, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
          TASKOPTIONPAGE.DUEONDATE_ALL, TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }

    taskOptionPageDetails.pageName = pageName;
    return taskOptionPageDetails;
  }

  /**
   * Fetches page name based on reserved task option. This method allows
   * supervisor to view either reserved tasks or deferred tasks page. The page
   * to be redirected to particular UIM page based on the option selected.
   *
   * @param key - ResolveReserveTaskOptionPageKey
   * @return ResolveTaskOptionPageDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveTaskOptionPageDetails resolveReserveTaskOptionPage(
    final ResolveReserveTaskOptionPageKey key) throws AppException,
      InformationalException {

    // object creation
    final ResolveTaskOptionPageDetails taskOptionPageDetails = new ResolveTaskOptionPageDetails();
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
      TASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    // Task Status should be Open
    if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
        TASKOPTIONPAGE.NOTSTARTED, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
      // Tasks Status Should be deferred
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
        TASKOPTIONPAGE.DEFERRED, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    taskOptionPageDetails.pageName = pageName;

    return taskOptionPageDetails;
  }

  /**
   * Method to forward case tasks reserved by user. This method allows the
   * supervisor to forward the selected tasks reserved
   * either by the user or to another user or to a work queue or to a
   * position or to an organization unit.
   *
   * @param key - CaseTaskForwardKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void forwardCaseTasksReservedByUser(final CaseTaskForwardKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();

    // call the SL method
    maintainSupervisorCase.forwardCaseTasksReservedByUser(key.key);
  }

  // __________________________________________________________________________
  /**
   * Lists all the Case Issues by Age.
   * This method allows supervisor to list all the case issues based on age.
   *
   * @param key - CaseIDAndCaseIssuesViewKey
   * @return CaseIssueDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseIssueDetailsList listCaseIssuesByAge(
    final CaseIDAndCaseIssuesViewKey key) throws AppException,
      InformationalException {

    // object creation
    final CaseIssueDetailsList caseIssueDetailsList = new CaseIssueDetailsList();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = curam.supervisor.sl.fact.MaintainSupervisorCaseFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final SupervisorApplicationPageContextDescription contextDescription = (SupervisorApplicationPageContextDescription) SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // assign key details
    caseIDKey.caseID = key.caseID;
    caseIssueDetailsList.caseIssueDtls = maintainSupervisorCase.listCaseIssuesByAge(
      caseIDKey);

    // read the page context description for the case
    caseIssueDetailsList.pageContextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    // assign task option code
    if ("".equals(key.caseIssuesViewOption)) {
      caseIssueDetailsList.caseIssuesViewOption = SUPERVISORCASEISSUESVIEW.DEFAULTCODE;
    } else {
      caseIssueDetailsList.caseIssuesViewOption = key.caseIssuesViewOption;
    }
    return caseIssueDetailsList;
  }

  /**
   * Reassigns the Case Issues By Age. This method allows Supervisor
   * to reassign a case issues based on age to a selected user.
   *
   * @param key -
   * ReassignCasesForUserKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void reassignCaseIssuesByAge(final ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.impl.MaintainSupervisorCase maintainSupervisorCase = (curam.supervisor.sl.impl.MaintainSupervisorCase) MaintainSupervisorCaseFactory.newInstance();

    // call the SL method to reassign the case issues
    maintainSupervisorCase.reassignCaseIssuesByAge(key.userKey);
  }

  /**
   * Method to reserve case tasks. This method allows the
   * supervisor to reserve all or some, of the assigned tasks
   * associated with a case, to a user.Fetches page name based on Type or
   * Age option. This method allow supervisor to view Case issues by
   * Type or By Age. The page to be redirected to particular UIM page based
   * on the option selected.
   *
   * @param key -
   * ResolveCaseIssuesOptionPageKey
   * @return ResolveCaseIssuesOptionPageDetails - Lists CaseIssue Option Page
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveCaseIssuesOptionPageDetails resolveCaseIssuesOptionPage(
    final ResolveCaseIssuesOptionPageKey key) throws AppException,
      InformationalException {

    // object creation
    final ResolveCaseIssuesOptionPageDetails resolveCaseIssuesOptionPageDetails = new ResolveCaseIssuesOptionPageDetails();

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(CASEISSUESVIEWOPTIONPAGE.TABLENAME,
      CASEISSUESVIEWOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (SUPERVISORCASEISSUESVIEW.AGE.equals(key.caseIssuesViewType)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(CASEISSUESVIEWOPTIONPAGE.TABLENAME,
        CASEISSUESVIEWOPTIONPAGE.CASEISSUES_AGE,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (SUPERVISORCASEISSUESVIEW.TYPE.equals(key.caseIssuesViewType)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(CASEISSUESVIEWOPTIONPAGE.TABLENAME,
        CASEISSUESVIEWOPTIONPAGE.CASEISSUES_TYPE,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveCaseIssuesOptionPageDetails.pageName = pageName;

    return resolveCaseIssuesOptionPageDetails;
  }

  /**
   * Returns the filter key for case issues. This key will have details of
   * Case-ID and case issues.
   *
   * @param key -
   * CaseIDAndCaseIssuesViewKey
   * @return CaseIDAndCaseIssuesViewKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseIDAndCaseIssuesViewKey issuesFilter(
    final CaseIDAndCaseIssuesViewKey key) throws AppException,
      InformationalException {

    return key;
  }

  /**
   * Lists all the Case Issues Based on Type and returns the
   * list as an XML String.
   *
   * @param key - caseID
   * @return CaseIssuesChartDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseIssuesChartDetails chartCaseIssuesByType(final caseID key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final CaseIssuesChartDetails listCaseIssuesChartDetails = new CaseIssuesChartDetails();
    final curam.supervisor.sl.struct.CaseIDKey caseKey = new curam.supervisor.sl.struct.CaseIDKey();

    // Assign the caseID from the facade to the SL object
    caseKey.key.caseID = key.caseID.key.caseID;
    caseIDKey.caseID = key.caseID.key.caseID;

    // Assign the chart from the SL to the facade object
    listCaseIssuesChartDetails.dtls.chartXMLString = maintainSupervisorCase.chartCaseIssuesByType(caseKey).chartXMLString;

    // get the page context description for the case
    listCaseIssuesChartDetails.pageContext = contextDescription.readCasePageContextDescription(
      caseIDKey);

    // set the issues view option
    if ("".equals(key.caseIssuesViewOption)) {
      listCaseIssuesChartDetails.caseIssuesViewOption = SUPERVISORCASEISSUESVIEW.DEFAULTCODE;
    } else {
      listCaseIssuesChartDetails.caseIssuesViewOption = key.caseIssuesViewOption;
    }
    return listCaseIssuesChartDetails;
  }

  /**
   * Lists all the Case Issues by Type. This method allows supervisor to list
   * all the case issues based on Type.
   *
   * @param key - CaseIdAndIssueTypeKey
   * @return CaseIssuesOfAType
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseIssuesOfAType listCaseIssuesOfAType(
    final CaseIdAndIssueTypeKey key) throws AppException,
      InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final CaseIssuesOfAType listOfCaseIssuesOfAType = new CaseIssuesOfAType();
    final curam.supervisor.sl.struct.CaseIdAndIssueTypeKey caseKey = new curam.supervisor.sl.struct.CaseIdAndIssueTypeKey();

    // Assign the case Id and Issue type to
    // the SL object to fetch the details
    caseKey.caseDtls.caseID = key.dtls.caseDtls.caseID;
    caseKey.caseDtls.issueType = key.dtls.caseDtls.issueType;
    caseIDKey.caseID = key.dtls.caseDtls.caseID;

    listOfCaseIssuesOfAType.typeDetails = maintainSupervisorCase.listCaseIssuesOfAType(
      caseKey);
    listOfCaseIssuesOfAType.issueDesc = readCodeTableItemDescription(
      caseKey.caseDtls.issueType, ISSUECONFIGURATIONTYPE.TABLENAME);

    // get the page context description for the case
    listOfCaseIssuesOfAType.pageContext = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return listOfCaseIssuesOfAType;
  }

  // __________________________________________________________________________
  /**
   * Returns the filter key for case issues based on type.
   * This filter key will have details of Case-Id
   *
   * @param key - caseID
   * @return caseID
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public caseID filterIssuesByType(final caseID key) throws AppException,
      InformationalException {

    return key;
  }

  /**
   * Lists all the Case types. Supervisor gets a list of all the Case-Types in
   * the drop down in filter section.(Ex: Integrated Case, Product Delivery,
   * Screening etc.)
   *
   * @return CaseTypeDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseTypeDetailsList getAllCaseTypes() throws AppException,
      InformationalException {

    // object creation
    final CodeTableName codeTableName = new CodeTableName();
    final CaseTypeDetailsList caseTypeDetailsList = new CaseTypeDetailsList();
    CaseTypeDetails caseTypeDetails = new CaseTypeDetails();

    codeTableName.name = CASETYPECODE.TABLENAME;

    // Retrieve the list of items in the code table
    // BEGIN, CR00340488, SSK
    final curam.core.facade.intf.System systemObj = SystemFactory.newInstance();

    final CodetableCodeAndDescriptionList codetableCodeAndDescriptionList = systemObj.listEnabledItemsInCodetableForLocale(
      codeTableName);

    // END, CR00340488
    // END, CR00124504
    caseTypeDetails.code = SupervisorConst.kcode_All;
    // BEGIN, CR00109753, SK
    final LocalisableString messageAll = new LocalisableString(
      curam.message.BPOSUPERVISORCONST.INF_CONST_ALL);

    caseTypeDetails.description = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00109753

    caseTypeDetailsList.dtls.addRef(caseTypeDetails);
    // BEGIN, CR00468368, GK
    final CasesForSupervisor casesForSupervisor = new CasesForSupervisorImpl();
    final Set<String> casesNotToBeIncluded = casesForSupervisor.getCaseTypesNotReqdForSupervisor();

    // END, CR00468368

    // BEGIN, CR00340488, SSK
    for (final CodetableCodeAndDescription codetableCodeAndDescription : codetableCodeAndDescriptionList.codetableCodeAndDescription) {
      // BEGIN, CR00468368, GK
      if (!CASETYPECODE.RESTRICTEDACCESS.equals(
        codetableCodeAndDescription.code)
          && !casesNotToBeIncluded.contains(codetableCodeAndDescription.code)) {
        // END, CR00468368, GK
        caseTypeDetails = new CaseTypeDetails();
        caseTypeDetails.code = codetableCodeAndDescription.code;

        caseTypeDetails.description = codetableCodeAndDescription.description;
        caseTypeDetailsList.dtls.addRef(caseTypeDetails);
      }
    }
    // END, CR00340488
    return caseTypeDetailsList;
  }

  /**
   * Method to list all Users. Supervisor gets a list all the Users that the
   * supervisor manages in the drop down in filter section.
   *
   * @return SupUserDetailsList - List of Supervisor Users
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public SupUserDetailsList getAllSupervisorUsers() throws AppException,
      InformationalException {

    // object creation
    final MaintainSupervisorUsers maintainSupervisorUsers = (MaintainSupervisorUsers) MaintainSupervisorUsersFactory.newInstance();
    final SupervisorUsersDetailsList supervisorDetailsList = maintainSupervisorUsers.listSupervisorUsers();
    final SupUserDetailsList detailsList = new SupUserDetailsList();
    final SupUserDetails supDetails = new SupUserDetails();

    // assign values
    supDetails.userName = SupervisorConst.kcode_All;
    supDetails.fullName = SupervisorConst.kcode_Description;
    detailsList.key.addRef(supDetails);

    for (int i = 0; i < supervisorDetailsList.dtls.userDetails.dtls.size(); i++) {
      final SupUserDetails details = new SupUserDetails();

      details.userName = supervisorDetailsList.dtls.userDetails.dtls.item(i).userName;
      details.fullName = supervisorDetailsList.dtls.userDetails.dtls.item(i).fullName;
      detailsList.key.addRef(details);
    }
    return detailsList;
  }

  /**
   * Reads the details of Case Users Schedule Details.
   *
   * @param key - CaseIDDateKey
   * @return CaseUsersScheduleDetailsList -
   * - list of Case Users Schedule Details
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public CaseUsersScheduleDetailsList readCaseUsersScheduleDetails(
    final CaseIDDateKey key) throws AppException, InformationalException {

    // object creation
    final CaseUsersScheduleDetailsList caseUsersScheduleDetailsList = new CaseUsersScheduleDetailsList();
    curam.supervisor.sl.struct.CaseUsersScheduleDetails caseUsersScheduleDetails = new curam.supervisor.sl.struct.CaseUsersScheduleDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();
    final CaseIDKey caseIDKey = new CaseIDKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // Call the service layer method
    caseUsersScheduleDetails = maintainSupervisorCase.readCaseUsersScheduleDetails(
      key);

    // Assign the details list retrieved from the
    // service layer to this return struct
    caseUsersScheduleDetailsList.detailsList = caseUsersScheduleDetails;

    // get the page context description for the case
    caseIDKey.caseID = key.caseID;
    caseUsersScheduleDetailsList.pageContextDescription = contextDescription.readCasePageContextDescription(
      caseIDKey);

    return caseUsersScheduleDetailsList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Lists Supervisor Cases by product status and Organization Unit.
   * Supervisor views list of cases filter by product status and
   * Organization Unit.
   *
   * @param key - ProductStausOrgObjectCaseTypeKey
   * @return CaseDetailsList - Details of cases
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link MaintainSupervisorCase#getCasesByProductStatusCaseTypeAndOrgObject(ProductStausOrgObjectCaseTypeKey)}
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by getCasesByProductStatusCaseTypeAndOrgObject(
   * ProductStausOrgObjectCaseTypeKey)
   * which returns the informational message along with supervisor cases by
   * product status and organization Object details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Override
  @Deprecated
  public CaseDetailsList listCasesByProductStatusCaseTypeAndOrgObject(
    final ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // END, CR00290965

    // object creation
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey nameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // get the username and the page context description for the user
    nameKey.userName = systemUser.getUserDetails().userName;
    caseDetailsList.pageContextDescription = contextDescription.readUserNamePageContextDescription(
      nameKey);

    if (key.dtls.productType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList.filter.productTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsList.filter.productTypeName = readCodeTableItemDescription(
        key.dtls.productType, PRODUCTTYPE.TABLENAME);
    }

    if (key.dtls.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList.filter.caseTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsList.filter.caseTypeName = readCodeTableItemDescription(
        key.dtls.caseType, CASETYPECODE.TABLENAME);
    }

    // BEGIN, CR00098757, CW
    // Empty status code means search on all status codes
    if (key.dtls.statusCode.trim().equals(CuramConst.gkEmpty)) {
      // END, CR00098757
      caseDetailsList.filter.caseStatus = SupervisorConst.kcode_Description;
    } else {
      caseDetailsList.filter.caseStatus = readCodeTableItemDescription(
        key.dtls.statusCode, CASESTATUS.TABLENAME);
    }
    caseDetailsList.dtls = maintainSupervisorCase.listCasesByProductStatusCaseTypeAndOrgObject(
      key.dtls);

    return caseDetailsList;
  }

  /**
   * This method allows the supervisor to fetch the page name based on selected
   * task option.
   *
   * @param key -
   * ResolveTaskOptionCodeKey
   * @return ResolveTaskOptionPageDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveTaskOptionPageDetails resolveCaseTasksByDateOrWeek(
    final ResolveTaskOptionCodeKey key) throws AppException,
      InformationalException {

    final ResolveTaskOptionPageDetails resolveCasePages = new ResolveTaskOptionPageDetails();

    final String taskOptionCode = key.taskOptionCode;

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
      TASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
        TASKOPTIONPAGE.DUEBYWEEK_ALL, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(TASKOPTIONPAGE.TABLENAME,
        TASKOPTIONPAGE.DUEONDATE_ALL, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveCasePages.pageName = pageName;
    return resolveCasePages;
  }

  // BEGIN, CR00232351, ZV
  /**
   * Reads the Case tab display details for supervisor workspace.
   *
   * @param key Key of case to be read
   *
   * @return Case tab display details
   */
  @Override
  public CaseTabDetails readCaseTabDetails(final CaseIDKey key)
    throws AppException, InformationalException {

    return MaintainSupervisorCaseFactory.newInstance().readCaseTabDetails(key);
  }

  // END, CR00232351

  // BEGIN, CR00290965, IBM
  /**
   * Lists Supervisor Cases by product status and Organization unit.
   * Supervisor views list of cases filter by product status and
   * Organization Unit.
   *
   * @param productStausOrgObjectCaseTypeKey contains product status case type
   * key
   * @return case details list
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced with
   * {@link MaintainSupervisorCase#listCasesByProductStatusCaseTypeAndOrganisationObject(ProductStatusOrgObjectCaseTypeKey arg0)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with listCasesByProductStatusCaseTypeAndOrganisationObject(
   * ProductStatusOrgObjectCaseTypeKey) and input struct name has been
   * corrected.
   * See release notes CS-10661/CR00304801
   */
  @Override
  @Deprecated
  public CaseDetailsResultList getCasesByProductStatusCaseTypeAndOrgObject(
    final ProductStausOrgObjectCaseTypeKey productStausOrgObjectCaseTypeKey)
    throws AppException, InformationalException {

    final CaseDetailsResultList caseDetailsResultList = new CaseDetailsResultList();
    final curam.supervisor.sl.intf.MaintainSupervisorCase maintainSupervisorCase = MaintainSupervisorCaseFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription supervisorApplicationPageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey nameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    nameKey.userName = systemUser.getUserDetails().userName;
    caseDetailsResultList.pageContextDescription = supervisorApplicationPageContextDescription.readUserNamePageContextDescription(
      nameKey);

    if (SupervisorConst.kcode_All.equals(
      productStausOrgObjectCaseTypeKey.dtls.productType)) {
      caseDetailsResultList.filter.productTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.productTypeName = readCodeTableItemDescription(
        productStausOrgObjectCaseTypeKey.dtls.productType,
        PRODUCTTYPE.TABLENAME);
    }

    if (SupervisorConst.kcode_All.equals(
      productStausOrgObjectCaseTypeKey.dtls.caseType)) {
      caseDetailsResultList.filter.caseTypeName = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.caseTypeName = readCodeTableItemDescription(
        productStausOrgObjectCaseTypeKey.dtls.caseType, CASETYPECODE.TABLENAME);
    }

    if (CuramConst.gkEmpty.equals(
      productStausOrgObjectCaseTypeKey.dtls.statusCode.trim())) {
      caseDetailsResultList.filter.caseStatus = SupervisorConst.kcode_Description;
    } else {
      caseDetailsResultList.filter.caseStatus = readCodeTableItemDescription(
        productStausOrgObjectCaseTypeKey.dtls.statusCode, CASESTATUS.TABLENAME);
    }

    caseDetailsResultList.dtls = maintainSupervisorCase.listCasesByProductStatusCaseTypeAndOrgObject(
      productStausOrgObjectCaseTypeKey.dtls);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      caseDetailsResultList.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return caseDetailsResultList;
  }
  // END, CR00290965
}
