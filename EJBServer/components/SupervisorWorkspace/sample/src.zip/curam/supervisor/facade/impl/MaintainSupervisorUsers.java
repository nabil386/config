/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014, 2018. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;

import curam.codetable.ASSIGNEETYPE;
import curam.codetable.BATCHPROCESSNAME;
import curam.codetable.CASESEARCHSTATUS;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.REDIRECTIONTARGETITEMTYPE;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKREDIRECTIONSTATUS;
import curam.codetable.TASKSTATUS;
import curam.codetable.USERTASKOPTIONPAGE;
import curam.codetable.VIEWTASKSOPTION;
import curam.codetable.WQSUBSORGOBJECTTYPE;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.struct.CaseSearchResultList;
import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.ReserveNextTaskDetails;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.GenericBatchProcessInputFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.GenericBatchProcessInput;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.TaskCountDetails;
import curam.core.sl.entity.struct.UserNameAndDateTimeKey;
import curam.core.sl.entity.struct.WorkQueueDetailsList;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.WorkQueueFactory;
import curam.core.sl.impl.TaskSortByPriority;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.intf.WorkQueue;
import curam.core.sl.struct.AssignedTaskDetails;
import curam.core.sl.struct.ClearTaskAllocationBlockingDetails;
import curam.core.sl.struct.DeferredTaskDetails;
import curam.core.sl.struct.ListTaskKey;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.ReservedByStatusTaskDetails;
import curam.core.sl.struct.ReservedByStatusTaskDetailsList;
import curam.core.sl.struct.TaskAllocationBlockingCreateDetails;
import curam.core.sl.struct.TaskQueryResultDetails;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.UserNameAndStatusKey;
import curam.core.sl.struct.WorkQueueSubscriptionDetails;
import curam.core.sl.supervisor.fact.UserWorkspaceFactory;
import curam.core.sl.supervisor.intf.UserWorkspace;
import curam.core.sl.supervisor.struct.ActiveAndPendingTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.AllTaskAllocationBlockingPeriodsForUserDetails;
import curam.core.sl.supervisor.struct.ExpiredTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.RedirectTaskDetails;
import curam.core.sl.supervisor.struct.TaskAllocationBlockingDetails;
import curam.core.sl.supervisor.struct.UserWorkQueueWithPageContextDetails;
import curam.core.sl.supervisor.struct.UserWorkQueueWithPageContextDetailsList;
import curam.core.sl.util.impl.CommonUtils;
import curam.core.struct.BatchQueuedTaskID;
import curam.core.struct.BatchQueuedTaskIDList;
import curam.core.struct.CaseReferenceTypeProductRolePriClientDateAndStatus;
import curam.core.struct.CaseReferenceTypeProductRolePriClientDateAndStatusList;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.CaseStatusFilterDetails;
import curam.core.struct.CaseStatusFilterDetailsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.InitialCaseSearchCriteria;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserStatusAndOrgObjectKey;
import curam.core.struct.UsersKey;
import curam.message.BPOBULKCASEREASSIGNMENT;
import curam.message.BPOBULKTASKFORWARD;
import curam.supervisor.facade.fact.MaintainSupervisorTasksFactory;
import curam.supervisor.facade.struct.AllTaskAllocationBlockingPeriodsForUserDetailsList;
import curam.supervisor.facade.struct.AssignedTaskForUserList;
import curam.supervisor.facade.struct.AssignedTaskForwardDetails;
import curam.supervisor.facade.struct.AvailableWorkQueueDetailsList;
import curam.supervisor.facade.struct.ListDeferredTasksReservedByUserDetails;
import curam.supervisor.facade.struct.ListDeferredTasksReservedByUserKey;
import curam.supervisor.facade.struct.ListOpenTasksReservedByUserDetails;
import curam.supervisor.facade.struct.ListOpenTasksReservedByUserKey;
import curam.supervisor.facade.struct.ListReservedDeferredTasksByUserDetails;
import curam.supervisor.facade.struct.ListReservedOpenTasksByUserDetails;
import curam.supervisor.facade.struct.ListUnreservedTasksForUserDetails;
import curam.supervisor.facade.struct.ListUnreservedTasksForUserKey;
import curam.supervisor.facade.struct.ListUserOrgObjectWorkQueueDetails;
import curam.supervisor.facade.struct.ListUserTasksByWeekDetails;
import curam.supervisor.facade.struct.ListUserTasksDueOnDateDetails;
import curam.supervisor.facade.struct.ListUserTasksRedirectionHistoryDetails;
import curam.supervisor.facade.struct.OpenAndDeferredTasksForReallocateTasksDetails;
import curam.supervisor.facade.struct.ReallocateTaskIDDetails;
import curam.supervisor.facade.struct.ReassignCasesForUserKey;
import curam.supervisor.facade.struct.ReassignCasesForUserSearchKey;
import curam.supervisor.facade.struct.ReserveAssignedTasksDetails;
import curam.supervisor.facade.struct.ReserveAssignedTasksToUser;
import curam.supervisor.facade.struct.ReserveWorkQueueTasksForUserDetails;
import curam.supervisor.facade.struct.ReservedTaskByUserList;
import curam.supervisor.facade.struct.ReservedTaskForwardDetails;
import curam.supervisor.facade.struct.ResolveTaskOptionKey;
import curam.supervisor.facade.struct.ResolveUserPageDetails;
import curam.supervisor.facade.struct.ResolveUserTaskOptionPageKey;
import curam.supervisor.facade.struct.SubscribeUserWorkQueueKey;
import curam.supervisor.facade.struct.SupervisorCaseDetailsWithInformationalMessage;
import curam.supervisor.facade.struct.SupervisorTaskForwardDetails;
import curam.supervisor.facade.struct.SupervisorTaskFwdDetails;
import curam.supervisor.facade.struct.SupervisorUserCaseListDetails;
import curam.supervisor.facade.struct.SupervisorUserTabDetails;
import curam.supervisor.facade.struct.SupervisorUserTabKey;
import curam.supervisor.facade.struct.SupervisorUsersDetailsList;
import curam.supervisor.facade.struct.SupervisorWorkspaceContentDetails;
import curam.supervisor.facade.struct.SupervisorWorkspaceDetails;
import curam.supervisor.facade.struct.TaskFilterCriteriaDetails;
import curam.supervisor.facade.struct.TaskFilterCriteriaPageDetails;
import curam.supervisor.facade.struct.TaskRedirectionKey;
import curam.supervisor.facade.struct.UserAssignedTaskDetailsAndFilterCriteriaDetails;
import curam.supervisor.facade.struct.UserNameAndDeadLineDateKey;
import curam.supervisor.facade.struct.UserNameAndTaskOptionKey;
import curam.supervisor.facade.struct.UserNameOrgObjectKey;
import curam.supervisor.facade.struct.UserTaskRedirectionDetails;
import curam.supervisor.sl.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.impl.SearchSupervisorTaskUtilities;
import curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription;
import curam.supervisor.sl.struct.ReallocateTasksReservedByUserKey;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.supervisor.sl.struct.SupervisorUserCaseDetails;
import curam.supervisor.sl.struct.SupervisorUserWithTaskCountDetailsList;
import curam.supervisor.sl.struct.UserTasksRedirectionHistoryDetailsList;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.message.CatEntry;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;

/**
 * Facade Layer implementation for Supervisor Users
 *
 */

public abstract class MaintainSupervisorUsers
  extends curam.supervisor.facade.base.MaintainSupervisorUsers {

  // _________________________________________________________________________
  /**
   * Lists available work queues for the current user. This method is used by
   * supervisor to list the available work queues for the selected user.
   *
   * @param key
   * - UsersKey
   * @return AvailableWorkQueueDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AvailableWorkQueueDetailsList listAvailableWorkQueuesForCurrentUser(
    final UsersKey key) throws AppException, InformationalException {

    // object creation

    // BEGIN CR00107117 ,GM
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    // END CR00107117

    final curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();
    curam.core.sl.entity.struct.AvailableWorkQueueDetailsList availableWorkQueueDetailsList =
      new curam.core.sl.entity.struct.AvailableWorkQueueDetailsList();
    final AvailableWorkQueueDetailsList availableWorkQueueDetailsListobj =
      new AvailableWorkQueueDetailsList();

    // Calling the SL method to get the list of work queues available
    // for user
    availableWorkQueueDetailsList =
      userWorkspaceObj.listWorkQueuesAvailableForUserSubscription(key);

    availableWorkQueueDetailsListobj.dtls
      .assign(availableWorkQueueDetailsList);

    final String[] matchedResults =
      informationalManager.obtainInformationalAsString();

    // iterate through the result from information manager
    for (int i = 0; i < matchedResults.length; i++) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];
      availableWorkQueueDetailsListobj.infMsgList.dtls
        .addRef(informationalMsgDtls);
    }
    return availableWorkQueueDetailsListobj;
  }

  // BEGIN, CR00226714, LP
  // BEGIN, CR00161962, BK
  /**
   * Lists all the work queues that the user passed in is subscribed to. It list
   * all the Work Queues subscribed by user and his organization objects.
   *
   * @param Username
   * @return list of WorkQueues for Organization object subscribed WorkQueues.
   * @exception AppException
   * ,InformationalException
   */
  @Override
  public CurrentUserWorkQueueAndSubscriberDetailsList
    listAllWorkQueuesForUser(final UserNameKey key)
      throws AppException, InformationalException {

    // Return information
    CurrentUserWorkQueueAndSubscriberDetailsList list =
      new CurrentUserWorkQueueAndSubscriberDetailsList();

    // Creating SL object
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    list = workQueueObj.listAllWorkQueuesForUser(key);

    return list;
  }

  // END, CR00161962
  // END, CR00226714

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the details of work queues for
   * the subscribed user. And also details of number of tasks user has reserved
   * from work queue, and total number of tasks in work queue.
   *
   * @param key
   * - UsersKey (holds the userName)
   * @return ListUserWorkQueueDetails.
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#listWorkQueuesForSupervisor(UsersKey)}.
   * In addition to the current functionality, the new method return struct
   * ListUserOrgObjectWorkQueueDetails contains the struct
   * UserOrgObjectsWorkQueueDetailsList.
   * See release note : <CR00216292>
   */
  @Override
  @Deprecated
  // BEGIN, CR00216292, LP
  public curam.supervisor.facade.struct.ListUserWorkQueueDetails
    listUserWorkQueues(final UsersKey key)
      throws AppException, InformationalException {

    final curam.supervisor.facade.struct.ListUserWorkQueueDetails listUserWorkQueueDetails =
      new curam.supervisor.facade.struct.ListUserWorkQueueDetails();
    final ListUserOrgObjectWorkQueueDetails userWQDtls =
      listWorkQueuesForSupervisor(key);

    for (final UserWorkQueueWithPageContextDetails nextQueue : userWQDtls.dtls.dtls) {
      final curam.core.sl.supervisor.struct.UserWorkQueueDetails s =
        new curam.core.sl.supervisor.struct.UserWorkQueueDetails();

      s.assign(nextQueue);
      listUserWorkQueueDetails.dtls.userWorkQueueDtls.dtls.addRef(s);
    }
    listUserWorkQueueDetails.pageContext = userWQDtls.pageContext;

    return listUserWorkQueueDetails;
  }

  // END, CR00216292

  // __________________________________________________________________________

  // BEGIN, CR00161962, BK
  /**
   * Method returns the list of work queue subscribed by user and its
   * organization objects The List will contain unique WorkQueues by
   * workQueueID. This list shall be preferably used in dropdown lists of
   * WorkQueues of user.
   *
   * @param UserNameKey
   * - user name
   *
   * @return WorkQueueDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public WorkQueueDetailsList listWorkQueueForUser(final UserNameKey key)
    throws AppException, InformationalException {

    // Return Object
    WorkQueueDetailsList userWorkQueueDetailsList =
      new WorkQueueDetailsList();

    // Get SL Layer Object
    final curam.core.sl.intf.Inbox inboxObj = InboxFactory.newInstance();

    // Call SL method to populate the list of users WorkQueues
    userWorkQueueDetailsList = inboxObj.getWorkQueueForUser(key);

    return userWorkQueueDetailsList;
  }

  // END, CR00161962

  // BEGIN, CR00351910, IBM
  /**
   * Reassigns cases to a selected user. This method allows supervisor to
   *
   * @param userNameOrgObjectKey
   * - UserNameOrgObjectKey.
   * @return SupervisorUserCaseListDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated , replaced with
   * {@link MaintainSupervisorUsers#listAllUserCaseDetails(UserNameOrgObjectKey)
   *
   * This method is deprecated because the return struct does not contain the
   * attribute for informational messages.
   */
  @Override
  @Deprecated
  public SupervisorUserCaseListDetails
    listAllUserCases(final UserNameOrgObjectKey userNameOrgObjectKey)
      throws AppException, InformationalException {

    // END, CR00351910

    // register the security implementation
    SecurityImplementationFactory.register();

    // object creation
    final SupervisorUserCaseListDetails caseListDetails =
      new SupervisorUserCaseListDetails();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.MaintainSupervisorUsers workspace =
      MaintainSupervisorUsersFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey userNameKey = new UserNameKey();

    // call SL method to list all the user cases
    final SupervisorUserCaseDetails userCaseDetails =
      workspace.listAllUserCases(userNameOrgObjectKey.key);

    // assign the list of cases to the return object
    caseListDetails.caseDetails = userCaseDetails;

    // get the user name and the page context details for the user
    userNameKey.userName = userNameOrgObjectKey.key.userName;
    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(userNameKey);

    caseListDetails.pageContextDescription = pageContextDetails;

    return caseListDetails;
  }

  // BEGIN, CR00369467, IBM
  /**
   * Reassigns cases to a selected user. This method allows supervisor to
   * reassign some or all of the cases that the user owns.
   *
   * @param key
   * - ReassignCasesForUserKey (Tab-delimited string list of caseID's)
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated , replaced with
   * {@link MaintainSupervisorUsers#reassignCasesForOrganisationObjectWithInformationalMessage(ReassignCasesForUserKey)}
   *
   *
   * This method is deprecated because the return does not contain the attribute
   * for informational messages.
   */
  @Override
  @Deprecated
  public void
    reassignCasesForOrganisationObject(final ReassignCasesForUserKey key)
      throws AppException, InformationalException {

    // END, CR00369467
    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to reassign the cases to the selected user
    maintainSupervisorUsers.reassignCasesForOrganisationObject(key.userKey);
  }

  /**
   * This method retrieves a list of the users reporting to the supervisor.
   *
   * @return SupervisorUsersDetailsList The users reporting to the supervisor.
   */
  @Override
  public SupervisorUsersDetailsList listSupervisorUsers()
    throws AppException, InformationalException {

    // object creation
    final SupervisorUsersDetailsList details =
      new SupervisorUsersDetailsList();
    final SupervisorUserWithTaskCountDetailsList userTaskCount =
      listSupervisorUsersWithTaskCount();

    details.dtls.userDetails.assign(userTaskCount);
    details.pageContextDescription.description =
      userTaskCount.pageContextDescription;
    return details;
  }

  /**
   * This method retrieves a list of the users reporting to the supervisor. It
   * also returns a count of the tasks assigned to each of them.
   *
   * @return SupervisorUserWithTaskCountDetailsList The users reporting to the
   * supervisor including a count of the tasks assigned to each of them.
   */
  @Override
  public SupervisorUserWithTaskCountDetailsList
    listSupervisorUsersWithTaskCount()
      throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.MaintainSupervisorUsers workspace =
      MaintainSupervisorUsersFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey userNameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // call the SL method to get the list of supervisor's users
    final SupervisorUserWithTaskCountDetailsList userDetails =
      workspace.listSupervisorUsersWithTaskCount();

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(userNameKey);

    userDetails.pageContextDescription = pageContextDetails.description;

    return userDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to Reserve the next task in for the
   * User.The supervisor is allowed to confirm the reservation of next task in
   * work queue.
   *
   * @param key
   * - UserNameKey
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SupervisorApplicationPageContextDetails
    readReserveNextWorkQueueTaskForUserContextDescription(
      final UserNameKey key) throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(key);

    return pageContextDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to get the page context details for the
   * un subscribed users of the work queue.
   *
   * @param key
   * - UserNameKey
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SupervisorApplicationPageContextDetails
    readUnsubscribeUserFromWorkQueueContextDescription(final UserNameKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // getting the page context details
    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(key);

    return pageContextDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reserve the next task from work queue
   * for the user.
   *
   * @param key
   * - ReserveNextWorkQueueTaskKey
   * @return - ReserveNextTaskDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ReserveNextTaskDetails reserveNextWorkQueueTask(
    final curam.supervisor.facade.struct.ReserveNextWorkQueueTaskKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.core.facade.struct.ReserveNextTaskDetails reserveNextTaskDetails =
      new ReserveNextTaskDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final curam.supervisor.sl.struct.ReserveNextWorkQueueTaskKey reserveNextWorkQueueTaskKey =
      new curam.supervisor.sl.struct.ReserveNextWorkQueueTaskKey();
    curam.core.sl.struct.ReserveNextTaskDetails nextTaskDetails =
      new curam.core.sl.struct.ReserveNextTaskDetails();

    // assign the key values
    reserveNextWorkQueueTaskKey.userName = key.key.userName;
    reserveNextWorkQueueTaskKey.workQueueID = key.key.workQueueID;

    // call SL method to reserve the next task
    nextTaskDetails = maintainSupervisorUsers
      .reserveNextWorkQueueTask(reserveNextWorkQueueTaskKey);
    reserveNextTaskDetails.reserveTaskDetails.taskID = nextTaskDetails.taskID;

    // BEGIN, CR00124957, SAI
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // All the information messages to displayed on the screen will returned as
    // an array. This array of messages will be iterated one by one and will be
    // displayed as list of message(s).

    final String[] messages =
      informationalManager.obtainInformationalAsString();

    // iterate through the result from informational manager
    for (int i = 0; i < messages.length; i++) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = messages[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    reserveNextTaskDetails.reserveTaskDetails.infoMsgDtlsList =
      informationalMsgDtlsList;
    // END, CR00124957

    return reserveNextTaskDetails;
  }

  /**
   * This method allows the supervisor to unsubscribe the user
   * from the selected work queue.
   *
   * @param key - UnsubscribeUserWorkQueueKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void unsubscribeUserFromWorkQueue(
    final curam.supervisor.facade.struct.UnsubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final curam.supervisor.sl.struct.UnsubscribeUserWorkQueueKey unsubscribeUserFromWorkQueueKey =
      new curam.supervisor.sl.struct.UnsubscribeUserWorkQueueKey();

    // assign the key values
    unsubscribeUserFromWorkQueueKey.workQueueID = key.key.workQueueID;
    unsubscribeUserFromWorkQueueKey.userName = key.key.userName;

    // call the SL method to unsubscribe the user
    maintainSupervisorUsers
      .unsubscribeUserFromWorkQueue(unsubscribeUserFromWorkQueueKey);
  }

  // _________________________________________________________________________

  // BEGIN, CR00161962, BK
  /**
   * This method allows the supervisor to unsubscribe a subscriber from the
   * selected work queue.
   *
   * @param key
   * - UnsubscribeMemberWorkQueueKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void unsubscribeMemberFromWorkQueue(
    final curam.supervisor.sl.struct.UnsubscribeMemberWorkQueueKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // If subscriber type is empty that mean it is user.
    if (key.subscriberType.equals(CuramConst.gkEmpty)) {
      key.subscriberType = WQSUBSORGOBJECTTYPE.USER;
    }

    // call the SL method to unsubscribe the subscriber
    maintainSupervisorUsers.unsubscribeMemberFromWorkQueue(key);
  }

  // END, CR00161962

  // _________________________________________________________________________
  /**
   * Clears the task redirection record for the user. This method allows the
   * supervisor to clear the task redirection record for the user.
   *
   * @param key
   * - TaskRedirectionKey
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public void clearTaskRedirection(final TaskRedirectionKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to clear the task redirection
    maintainSupervisorUsers.clearTaskRedirection(key.key);
  }

  // BEGIN, CR00369467, IBM
  /**
   * This method allows the supervisor to forward the selected tasks
   * reserved by the user either to another user or to a work queue
   * or to a position or to an organization unit.
   *
   * @param key - SupervisorTaskForwardDetails
   *
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated , replaced with
   * {@link MaintainSupervisorUsers#forwardTasksReservedByUserWithInformationalMessage(SupervisorTaskForwardDetails)}
   *
   * This method is deprecated because the return does not contain the attribute
   * for informational messages.
   */
  @Override
  @Deprecated
  public void
    forwardTasksReservedByUser(final SupervisorTaskForwardDetails key)
      throws AppException, InformationalException {

    // END, CR00369467
    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to forward the reserved tasks
    maintainSupervisorUsers.forwardTasksReservedByUser(key.details);
  }

  // _________________________________________________________________________

  // BEGIN, CR00161962, BK
  // BEGIN, CR00216252 MN
  /**
   * This forwardTasksNotReservedByUser forwards the selected tasks assigned by
   * the user either to another user or to a work queue or to a position or to
   * an organization unit.
   *
   * @param key SupervisorTaskForwardDetails
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public InformationalMsgDetailsList
    forwardTasksNotReservedByUser(final SupervisorTaskFwdDetails key)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to forward the non reserved tasks
    final InformationalMsgDetailsList informationalMsgDetailsList =
      maintainSupervisorUsers.forwardTasksNotReservedByUser(key.details);

    return informationalMsgDetailsList;
  }

  // END, CR00216252
  // END, CR00161962

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list all the Assigned tasks due on a
   * specified week, for the user. Lists Tasks details (such as assigned date,
   * deadline date, priority, Task type etc.,) assigned to a user for a period
   * of specified week.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksByWeekDetails
    listUserAssignedTasksByWeek(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.supervisor.facade.struct.ListUserTasksByWeekDetails listUserTasksByWeekDetails =
      new curam.supervisor.facade.struct.ListUserTasksByWeekDetails();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTasksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign the key values
    userTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTasksDueOnDateKey.taskReservationStatus = key.key.taskType;
    userTasksDueOnDateKey.userName = key.key.userName;

    // call the SL method to get the user tasks and assign them
    listUserTasksByWeekDetails.dtls
      .assign(userWorkspaceObj.getUserTasksDueByWeek(userTasksDueOnDateKey));

    return listUserTasksByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list all the assigned tasks due on the
   * specified date for the User. Lists Tasks details (such as assigned date,
   * deadline date, priority, Task type etc.) assigned to a user for a specified
   * date.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksDueOnDateDetails
    listUserAssignedTasksDueOnDate(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final ListUserTasksDueOnDateDetails listUserTasksDueOnDateDetails =
      new ListUserTasksDueOnDateDetails();
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTAsksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign the key values
    userTAsksDueOnDateKey.userName = key.key.userName;
    userTAsksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTAsksDueOnDateKey.taskReservationStatus = key.key.taskType;

    // call the SL method to get the user tasks
    listUserTasksDueOnDateDetails.dueOnDetails =
      userWorkspaceObj.getUserTasksDueOnDate(userTAsksDueOnDateKey);

    return listUserTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list all the reserved tasks due on a
   * specified week, for the user. Lists Tasks details (such as assigned date,
   * deadline date, priority etc.) assigned to a user for a specified week.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksByWeekDetails
    listUserReservedTasksByWeek(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.supervisor.facade.struct.ListUserTasksByWeekDetails listUserTasksByWeekDetails =
      new curam.supervisor.facade.struct.ListUserTasksByWeekDetails();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTasksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign key values
    userTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTasksDueOnDateKey.taskReservationStatus = key.key.taskType;
    userTasksDueOnDateKey.userName = key.key.userName;

    // call the SL method to get the user tasks
    listUserTasksByWeekDetails.dtls
      .assign(userWorkspaceObj.getUserTasksDueByWeek(userTasksDueOnDateKey));

    return listUserTasksByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list all the reserved tasks due on the
   * specified date for the User. Lists Tasks details (such as assigned date,
   * deadline date, priority etc.) assigned to a user for a specified date.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksDueOnDateDetails
    listUserReservedTasksDueOnDate(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final ListUserTasksDueOnDateDetails listUserTasksDueOnDateDetails =
      new ListUserTasksDueOnDateDetails();
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTAsksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign key values
    userTAsksDueOnDateKey.userName = key.key.userName;
    userTAsksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTAsksDueOnDateKey.taskReservationStatus = key.key.taskType;

    // call the SL method to get the user tasks
    listUserTasksDueOnDateDetails.dueOnDetails =
      userWorkspaceObj.getUserTasksDueOnDate(userTAsksDueOnDateKey);

    return listUserTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  // BEGIN, CR00216807 MN
  /**
   * This method allows the supervisor to list all the redirected task records
   * for the user. Lists details of active and pending redirections, expired
   * redirections
   *
   * @param key
   * - UserNameKey
   * @return ListTasksRedirectionHistoryDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#listTaskRedirectionHistory(UserNameKey key)}
   * .
   * As part of the CLE changes , implementation has been moved to
   * listTaskRedirectionHistory with a new return struct
   * ListUserTasksRedirectionHistoryDetails. This struct has all the fields of
   * ListTasksRedirectionHistoryDetails. See release note : <CR00216807>
   */
  @Override
  @Deprecated
  public curam.supervisor.facade.struct.ListTasksRedirectionHistoryDetails
    listUserTaskRedirectionHistory(final UserNameKey key)
      throws AppException, InformationalException {

    final ListUserTasksRedirectionHistoryDetails details =
      this.listTaskRedirectionHistory(key);

    final curam.supervisor.facade.struct.ListTasksRedirectionHistoryDetails historyDetails =
      new curam.supervisor.facade.struct.ListTasksRedirectionHistoryDetails();

    final curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList historyDetailsList =
      new curam.supervisor.sl.struct.TasksRedirectionHistoryDetailsList();

    final curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails allTaskRedirectionsFromUserDetails =
      new curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails();

    // BEGIN, CR00225492 MN
    // populating Active and Pending Task Redirection details.
    RedirectTaskDetails redirectActiveAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails taskRedirectionDetails =
      new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ActiveAndPendingTaskRedirectionFromUserDetailsList activeAndPendingTaskRedirectionDetailsList =
      new ActiveAndPendingTaskRedirectionFromUserDetailsList();

    for (int i =
      0; i < details.dtls.redirectionDetailsList.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails
        .size(); i++) {
      redirectActiveAndPendingTaskDetails =
        details.dtls.redirectionDetailsList.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails
          .get(i);

      taskRedirectionDetails.endDateTime =
        redirectActiveAndPendingTaskDetails.endDateTime;
      taskRedirectionDetails.redirectionStatus =
        redirectActiveAndPendingTaskDetails.redirectionStatus;
      taskRedirectionDetails.startDateTime =
        redirectActiveAndPendingTaskDetails.startDateTime;
      taskRedirectionDetails.taskRedirectionID =
        redirectActiveAndPendingTaskDetails.taskRedirectionID;
      taskRedirectionDetails.toUserFullName =
        redirectActiveAndPendingTaskDetails.toUserFullName;
      taskRedirectionDetails.toUserName =
        redirectActiveAndPendingTaskDetails.toUserName;
      taskRedirectionDetails.versionNo =
        redirectActiveAndPendingTaskDetails.versionNo;

      activeAndPendingTaskRedirectionDetailsList.activeAndPendingDtls
        .addRef(taskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirections =
      activeAndPendingTaskRedirectionDetailsList;
    // _________________________________________________________
    // populating Expired Task Redirection details.
    RedirectTaskDetails redirectExpiredAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails expiredTaskRedirectionDetails =
      new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ExpiredTaskRedirectionFromUserDetailsList expiredTaskRedirectionDetailsList =
      new ExpiredTaskRedirectionFromUserDetailsList();

    for (int i =
      0; i < details.dtls.redirectionDetailsList.expiredTaskRedirectionDetails.expiredDetails
        .size(); i++) {
      redirectExpiredAndPendingTaskDetails =
        details.dtls.redirectionDetailsList.expiredTaskRedirectionDetails.expiredDetails
          .get(i);

      expiredTaskRedirectionDetails.endDateTime =
        redirectExpiredAndPendingTaskDetails.endDateTime;
      expiredTaskRedirectionDetails.redirectionStatus =
        redirectExpiredAndPendingTaskDetails.redirectionStatus;
      expiredTaskRedirectionDetails.startDateTime =
        redirectExpiredAndPendingTaskDetails.startDateTime;
      expiredTaskRedirectionDetails.taskRedirectionID =
        redirectExpiredAndPendingTaskDetails.taskRedirectionID;
      expiredTaskRedirectionDetails.toUserFullName =
        redirectExpiredAndPendingTaskDetails.toUserFullName;
      expiredTaskRedirectionDetails.toUserName =
        redirectExpiredAndPendingTaskDetails.toUserName;
      expiredTaskRedirectionDetails.versionNo =
        redirectExpiredAndPendingTaskDetails.versionNo;
      expiredTaskRedirectionDetailsList.expiredDtls
        .addRef(expiredTaskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.expiredTaskRedirections =
      expiredTaskRedirectionDetailsList;

    // END, CR00225492

    historyDetailsList.redirectionDetailsList =
      allTaskRedirectionsFromUserDetails;

    historyDetails.dtls = historyDetailsList;

    return historyDetails;
  }

  // END, CR00216807

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the user's task record details
   * due on a period of specified week.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksByWeekDetails
    listUserTasksByWeek(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.supervisor.facade.struct.ListUserTasksByWeekDetails listUserTasksByWeekDetails =
      new curam.supervisor.facade.struct.ListUserTasksByWeekDetails();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTasksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign key values
    userTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTasksDueOnDateKey.taskReservationStatus = key.key.taskType;
    userTasksDueOnDateKey.userName = key.key.userName;

    // call the SL method to get user tasks
    listUserTasksByWeekDetails.dtls
      .assign(userWorkspaceObj.getUserTasksDueByWeek(userTasksDueOnDateKey));

    return listUserTasksByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the user's task record details
   * due on the specified date.
   *
   * @param key
   * - UserNameAndDeadLineDateKey
   * @return ListUserTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksDueOnDateDetails
    listUserTasksDueOnDate(final UserNameAndDeadLineDateKey key)
      throws AppException, InformationalException {

    // object creation
    final ListUserTasksDueOnDateDetails listUserTasksDueOnDateDetails =
      new ListUserTasksDueOnDateDetails();
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final curam.core.sl.supervisor.struct.UserTasksDueOnDateKey userTAsksDueOnDateKey =
      new curam.core.sl.supervisor.struct.UserTasksDueOnDateKey();

    // assign key values
    userTAsksDueOnDateKey.userName = key.key.userName;
    userTAsksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    userTAsksDueOnDateKey.taskReservationStatus = key.key.taskType;

    // call the SL method to get user tasks
    listUserTasksDueOnDateDetails.dueOnDetails =
      userWorkspaceObj.getUserTasksDueOnDate(userTAsksDueOnDateKey);

    return listUserTasksDueOnDateDetails;
  }

  // BEGIN, CR00351910, IBM
  /**
   * This method allows the supervisor to fetch list of tasks associated with
   * the case, which have been reserved by a particular user, and then deferred.
   *
   * @param key
   * - ListDeferredTasksReservedByUserKey (identifies caseID and
   * userName for the task)
   * @return ListDeferredTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated This method is deprecated as it does provide support for
   * displaying the informational messages back to the client.
   * Please refer the replacement method
   * {@link #listReservedDeferredTasksByUser(ListDeferredTasksReservedByUserKey)
   * (ListOpenTasksReservedByUserKey)} for more details.
   */
  @Deprecated
  @Override
  public ListDeferredTasksReservedByUserDetails
    listDeferredTasksReservedByUser(
      final ListDeferredTasksReservedByUserKey key)
      throws AppException, InformationalException {

    // END, CR00351910

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final ListDeferredTasksReservedByUserDetails listDeferredTasksReservedByUserDetails =
      new ListDeferredTasksReservedByUserDetails();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();

    // call the SL method to get the tasks reserved and then deferred.
    listDeferredTasksReservedByUserDetails.dtls =
      maintainSupervisorUsers.listDeferredTasksReservedByUser(key.key);

    // get the user name and the page context details for the user
    userNameKey.userName = key.key.userName;
    listDeferredTasksReservedByUserDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    return listDeferredTasksReservedByUserDetails;
  }

  // BEGIN, CR00351910, IBM
  /**
   * This method allows the supervisor to fetch a list of tasks associated with
   * the case, which have been reserved by a particular user, that are open.
   *
   * @param key
   * - ListOpenTasksReservedByUserKey (identifies caseID and userName
   * for the task)
   * @return ListOpenTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated This method is deprecated as it does provide support for
   * displaying the informational messages back to the client. Please refer the
   * replacement method
   * {@link #listReservedOpenTasksByUser(ListOpenTasksReservedByUserKey)} for
   * more details.
   */
  @Deprecated
  @Override
  public ListOpenTasksReservedByUserDetails
    listOpenTasksReservedByUser(final ListOpenTasksReservedByUserKey key)
      throws AppException, InformationalException {

    // END, CR00351910
    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      new ListOpenTasksReservedByUserDetails();
    final UserNameKey userNameKey = new UserNameKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // call the SL to get the open tasks reserved by the user
    listOpenTasksReservedByUserDetails.dtls =
      maintainSupervisorUsers.listOpenTasksReservedByUser(key.key);

    // get the user name and the page context details for the user
    userNameKey.userName = key.key.userName;
    listOpenTasksReservedByUserDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    return listOpenTasksReservedByUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks assigned to a user, but
   * not currently reserved by the user. The list does not include tasks
   * assigned to work queues that the user is subscribed to.
   *
   * @param key
   * - ListUnreservedTasksForUserKey
   * @return ListUnreservedTasksForUserDetails.
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListUnreservedTasksForUserDetails
    listTasksAssignedToUser(final ListUnreservedTasksForUserKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final ListUnreservedTasksForUserDetails listUnreservedTasksForUserDetails =
      new ListUnreservedTasksForUserDetails();
    final UserNameKey userNameKey = new UserNameKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // call the SL method to list the tasks assigned to user
    listUnreservedTasksForUserDetails.dtls =
      maintainSupervisorUsers.listTasksAssignedToUser(key.key);

    // get the user name and the page context details for the user
    userNameKey.userName = key.key.userName;
    listUnreservedTasksForUserDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    return listUnreservedTasksForUserDetails;
  }

  // _________________________________________________________________________
  // BEGIN, CR00216252 MN
  /**
   * This method allows the supervisor to view the user workspace details. The
   * user Workspace allows supervisors to manage tasks and cases by user.
   *
   * @param key
   * - UserNameAndTaskOptionKey
   * @return UserWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#readSupervisorWorkspaceDetails(UserNameAndTaskOptionKey key)}
   * .
   * As part of the CLE changes , implementation has been moved to
   * readSupervisorWorkspaceDetails with a new return struct
   * SupervisorWorkspaceDetails. This struct has all the fields of
   * UserWorkspaceDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216252>
   */
  @Override
  @Deprecated
  public curam.supervisor.facade.struct.UserWorkspaceDetails
    readUserWorkspaceDetails(final UserNameAndTaskOptionKey key)
      throws AppException, InformationalException {

    final SupervisorWorkspaceDetails details =
      this.readSupervisorWorkspaceDetails(key);

    final curam.supervisor.facade.struct.UserWorkspaceDetails userWorkspaceDetails =
      new curam.supervisor.facade.struct.UserWorkspaceDetails();
    final curam.supervisor.sl.struct.UserDetails userDetails =
      new curam.supervisor.sl.struct.UserDetails();

    userDetails.phoneAreaCode = details.dtls.userDetails.phoneAreaCode;
    userDetails.phoneCountryCode = details.dtls.userDetails.phoneCountryCode;
    userDetails.phoneExtension = details.dtls.userDetails.phoneExtension;
    userDetails.phoneNumber = details.dtls.userDetails.phoneNumber;
    userDetails.taskRedirectedUserName =
      details.dtls.userDetails.taskRedirectedUserName;
    userDetails.tasksRedirectedTo =
      details.dtls.userDetails.tasksRedirectedTo;
    userDetails.userEmail = details.dtls.userDetails.userEmail;
    userDetails.userEmailLink = details.dtls.userDetails.userEmailLink;
    userDetails.userFullName = details.dtls.userDetails.userFullName;
    userDetails.userName = details.dtls.userDetails.userName;

    final curam.supervisor.sl.struct.UserWorkspaceDetails workspaceDetails =
      new curam.supervisor.sl.struct.UserWorkspaceDetails();

    workspaceDetails.userDetails = userDetails;
    workspaceDetails.orgDetailsList = details.dtls.orgDetailsList;
    workspaceDetails.dtls = details.dtls.dtls;
    workspaceDetails.userWorkspaceChartXMLString =
      details.dtls.userWorkspaceChartXMLString;
    workspaceDetails.workQueueSubscription =
      details.dtls.workQueueSubscription;

    userWorkspaceDetails.dtls = workspaceDetails;
    userWorkspaceDetails.pageDescription = details.pageDescription;
    userWorkspaceDetails.taskOption = details.taskOption;

    return userWorkspaceDetails;

  }

  // END, CR00216252
  // _________________________________________________________________________
  /**
   * This method allows the supervisor to redirect the tasks assignment of one
   * user to another user to a specified time period. It also lists out current
   * and pending redirections.
   *
   * @param key
   * - TaskRedirectionDetails
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorUsers#taskRedirectionsToUser(UserTaskRedirectionDetails key)}
   * .
   * As part of the CLE changes , implementation has been moved to
   * taskRedirectionsToUser with a new input struct
   * UserTaskRedirectionDetails. This struct has all the fields of
   * TaskRedirectionDetails struct along with fields
   * toRedirectID and toRedirectType. Along with the above functionality the
   * new method allows task redirections between members other than users.
   * See release note : <CR00225492>
   */
  @Override
  @Deprecated
  public void redirectTasksToUser(
    final curam.supervisor.facade.struct.TaskRedirectionDetails key)
    throws AppException, InformationalException {

    final UserTaskRedirectionDetails details =
      new UserTaskRedirectionDetails();

    final curam.supervisor.sl.struct.UserTaskRedirectionDetails redirectionDetails =
      new curam.supervisor.sl.struct.UserTaskRedirectionDetails();

    redirectionDetails.endDateTime = key.dtls.endDateTime;
    redirectionDetails.fromUserName = key.dtls.fromUserName;
    redirectionDetails.startDateTime = key.dtls.startDateTime;
    redirectionDetails.toUserName = key.dtls.toUserName;
    redirectionDetails.toUserNameInSupervisorGroup =
      key.dtls.toUserNameInSupervisorGroup;
    redirectionDetails.toRedirectType = REDIRECTIONTARGETITEMTYPE.USER;

    details.dtls = redirectionDetails;

    this.taskRedirectionsToUser(details);
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reserve a number of tasks to the user
   * that have been assigned to the user.
   *
   * @param key
   * - ReserveAssignedTasksDetails
   * @return InformationalMsgDtlsList
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public InformationalMsgDtlsList
    reserveAssignedTasksForUser(final ReserveAssignedTasksDetails key)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    maintainSupervisorUsers.reserveAssignedTasksForUser(key.dtls);

    final String[] matchedResults =
      informationalManager.obtainInformationalAsString();

    // iterate through the result from informational manager
    for (int i = 0; i < matchedResults.length; i++) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * This method allows the supervisor to confirm that they wish to reserve the
   * next work queue task for the user.
   *
   * @param key
   * - ReserveWorkQueueTasksForUserDetails
   * @return InformationalMsgDtlsList
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public InformationalMsgDtlsList reserveTasksFromWorkQueueForUser(
    final ReserveWorkQueueTasksForUserDetails key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // call the SL method to reserve tasks from work queue
    maintainSupervisorUsers.reserveTasksFromWorkQueueForUser(key.key);

    final String[] matchedResults =
      informationalManager.obtainInformationalAsString();

    // iterate through the result from information manager
    for (int i = 0; i < matchedResults.length; i++) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to subscribe the user for the selected
   * work queue.
   *
   * @param key
   * - SubscribeUserWorkQueueKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void subscribeUserToWorkqueue(final SubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final curam.supervisor.sl.struct.SubscribeUserWorkQueueKey subscribeUserWorkQueueKey =
      new curam.supervisor.sl.struct.SubscribeUserWorkQueueKey();

    subscribeUserWorkQueueKey.assign(key.key);

    // call the SL method to subscribe the user to work queue
    maintainSupervisorUsers
      .subscribeUserToWorkqueue(subscribeUserWorkQueueKey);
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the particular page name based
   * on selected task option.
   *
   * @param key
   * - ResolveUserTaskOptionPageKey
   * @return ResolveUserPageDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveUserPageDetails
    resolveUserWorkspacePage(final ResolveUserTaskOptionPageKey key)
      throws AppException, InformationalException {

    // object creation
    final ResolveUserPageDetails resolveUserPageDetails =
      new ResolveUserPageDetails();

    final String taskOptionCode = key.taskOptionCode;
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
        USERTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    // check the task option and task reserved search status to fetch
    // appropriate page
    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEBYWEEK_RESERVED,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEBYWEEK_ASSIGNED,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEBYWEEK_ALL,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEONDATE_RESERVED,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEONDATE_ASSIGNED,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
            USERTASKOPTIONPAGE.DUEONDATE_ALL,
            TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }
    resolveUserPageDetails.pageName = pageName;

    return resolveUserPageDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reallocate selected tasks that have
   * been reserved by the user to read, open and deferred tasks. The tasks
   * reserved by the user will be divided into 2 lists. A list of open and a
   * list of deferred tasks.
   *
   * @param key
   * - UserNameKey
   * @return OpenAndDeferredTasksForReallocateTasksDetails
   * @throws AppException
   * , InformationalException
   * @throws InformationalException
   */
  @Override
  public OpenAndDeferredTasksForReallocateTasksDetails
    readOpenAndDererredTasksForReallocateTasks(final UserNameKey key)
      throws AppException, InformationalException {

    // object creation
    final OpenAndDeferredTasksForReallocateTasksDetails openAndDeferredTasksForReallocateTasksDetails =
      new OpenAndDeferredTasksForReallocateTasksDetails();
    final ListDeferredTasksReservedByUserKey listDeferredTasksReservedByUserKey =
      new ListDeferredTasksReservedByUserKey();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final ListOpenTasksReservedByUserKey listOpenTasksReservedByUserKey =
      new ListOpenTasksReservedByUserKey();

    // assign key values
    listDeferredTasksReservedByUserKey.key.userName = key.userName;
    listOpenTasksReservedByUserKey.key.userName = key.userName;

    // get deferred tasks list
    final ListDeferredTasksReservedByUserDetails listDeferredTasksReservedByUserDetails =
      listDeferredTasksReservedByUser(listDeferredTasksReservedByUserKey);

    // read open tasks list
    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      listOpenTasksReservedByUser(listOpenTasksReservedByUserKey);

    // assign values to OpenAndDeferredTasksForReallocateTasksDetails
    openAndDeferredTasksForReallocateTasksDetails.deferredTasksDetails =
      listDeferredTasksReservedByUserDetails;

    openAndDeferredTasksForReallocateTasksDetails.openTasksDetails =
      listOpenTasksReservedByUserDetails;

    openAndDeferredTasksForReallocateTasksDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(key);

    return openAndDeferredTasksForReallocateTasksDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reallocate selected tasks, which have
   * been reserved by a user. Lists tasks into 2 lists, a open task list and a
   * deferred task list.
   *
   * @param key
   * - ReallocateTasksReservedByUserKey
   * @throws AppException
   * ,InformationalException
   * @throws InformationalException
   */
  @Override
  public void reallocateTasksReservedByUser(
    final curam.supervisor.facade.struct.ReallocateTasksReservedByUserKey key)
    throws AppException, InformationalException {

    // object creation
    final ReallocateTasksReservedByUserKey reallocateTasksReservedByUserKey =
      new ReallocateTasksReservedByUserKey();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // assign key values
    reallocateTasksReservedByUserKey.comments = key.key.comments;
    reallocateTasksReservedByUserKey.deferredTaskIDs =
      key.key.deferredTaskIDs;
    reallocateTasksReservedByUserKey.openTaskIDs = key.key.openTaskIDs;
    reallocateTasksReservedByUserKey.userName = key.key.userName;

    // call the SL method to reallocate the tasks reserved by user
    maintainSupervisorUsers
      .reallocateTasksReservedByUser(reallocateTasksReservedByUserKey);
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reserve a task to the user, which has
   * been assigned to the user.
   *
   * @param key
   * - ReserveAssignedTasksToUser
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void reserveAssignedTasksToUser(final ReserveAssignedTasksToUser key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to reserve the assigned tasks to the user
    maintainSupervisorUsers.reserveAssignedTasksToUser(key.details);
  }

  // _________________________________________________________________________
  /**
   * Blocks task allocation for user. This method allows supervisor to block
   * task allocations for the users for a period of time.
   *
   * @param key
   * - TaskAllocationBlockingCreateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void
    blockTaskAllocationForUser(final TaskAllocationBlockingCreateDetails key)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final TaskAllocationBlockingCreateDetails taskAllocationBlockingDetails =
      new TaskAllocationBlockingCreateDetails();

    // assign the values to the key
    taskAllocationBlockingDetails.endDateTime = key.endDateTime;
    taskAllocationBlockingDetails.fromUserName = key.fromUserName;
    taskAllocationBlockingDetails.startDateTime = key.startDateTime;

    // call the SL method to block the task allocation for user
    maintainSupervisorUsers
      .blockTaskAllocationForUser(taskAllocationBlockingDetails);
  }

  // _________________________________________________________________________
  /**
   * Clears task allocation blocks for user. This method allows supervisor to
   * clear the task allocation blocks for the users
   *
   * @param key
   * - TaskAllocationBlockingDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void
    clearTaskAllocationBlockForUser(final TaskAllocationBlockingDetails key)
      throws AppException, InformationalException {

    // object creation
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final ClearTaskAllocationBlockingDetails clearTaskAllocationBlockingDetails =
      new ClearTaskAllocationBlockingDetails();

    // assign values to the key
    clearTaskAllocationBlockingDetails.endDateTime = key.endDateTime;
    clearTaskAllocationBlockingDetails.startDateTime = key.startDateTime;
    clearTaskAllocationBlockingDetails.taskRedirectionID =
      key.taskRedirectionID;
    clearTaskAllocationBlockingDetails.versionNo = key.versionNo;

    // call the SL method to clear the task allocation blocks for user
    userWorkspaceObj
      .clearTaskAllocationBlockForUser(clearTaskAllocationBlockingDetails);
  }

  // _________________________________________________________________________
  /**
   * Lists all the task allocation blocks for the User. This method allows
   * supervisor to view all the tasks allocation details such active or pending
   * or expired tasks. And also task allocation availability status.
   *
   * @param key
   * - UserNameKey
   * @return AllTaskAllocationBlockingPeriodsForUserDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public AllTaskAllocationBlockingPeriodsForUserDetailsList
    listTaskAllocationBlockingHistoryForUser(final UserNameKey key)
      throws AppException, InformationalException {

    // object creation
    final curam.core.sl.supervisor.intf.UserWorkspace userWorkspaceObj =
      curam.core.sl.supervisor.fact.UserWorkspaceFactory.newInstance();
    final UserNameAndDateTimeKey userNameAndDatekey =
      new UserNameAndDateTimeKey();
    final AllTaskAllocationBlockingPeriodsForUserDetailsList allTaskAllocationBlockingPeriodsForUserDetailsList =
      new AllTaskAllocationBlockingPeriodsForUserDetailsList();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();

    // assign values to the key
    userNameAndDatekey.userName = key.userName;
    userNameAndDatekey.currentDateTime = DateTime.getCurrentDateTime();

    // get the page context description for the user
    userNameKey.userName = key.userName;
    allTaskAllocationBlockingPeriodsForUserDetailsList.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    // BEGIN, CR00182755, CL
    // Set the default value of the
    // attribute availableForTaskAllocationStatus to Yes
    allTaskAllocationBlockingPeriodsForUserDetailsList.availableForTaskAllocationStatus =
      new curam.util.exception.LocalisableString(
        curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_YES)
          .getMessage();
    // END, CR00182755

    // Reading the List from the Entity
    final AllTaskAllocationBlockingPeriodsForUserDetails allTaskAllocationBlockingPeriodsForUserDetails =
      userWorkspaceObj
        .listTaskAllocationBlockingHistoryForUser(userNameAndDatekey);

    // Must now iterate through these records and add them into the list for
    // active and pending task allocation blocking periods and the list for
    // expired task allocation blocking periods.

    final int numOfActiveAndPendingTaskAllocBlockingPeriodsForUser =
      allTaskAllocationBlockingPeriodsForUserDetails.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
        .size();

    for (int i =
      0; i < numOfActiveAndPendingTaskAllocBlockingPeriodsForUser; i++) {
      TaskAllocationBlockingDetails taskAllocationBlockingDetails =
        new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails =
        allTaskAllocationBlockingPeriodsForUserDetails.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
          .item(i);

      allTaskAllocationBlockingPeriodsForUserDetailsList.allAllocationDetailsList.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
        .add(taskAllocationBlockingDetails);
    }

    final int numOfExpiredTaskAllocBlockingPeriodsForUser =
      allTaskAllocationBlockingPeriodsForUserDetails.expiredTaskAllocationBlockingPeriods.expiredDtls
        .size();

    for (int i = 0; i < numOfExpiredTaskAllocBlockingPeriodsForUser; i++) {
      TaskAllocationBlockingDetails taskAllocationBlockingDetails =
        new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails =
        allTaskAllocationBlockingPeriodsForUserDetails.expiredTaskAllocationBlockingPeriods.expiredDtls
          .item(i);

      allTaskAllocationBlockingPeriodsForUserDetailsList.allAllocationDetailsList.expiredTaskAllocationBlockingPeriods.expiredDtls
        .add(taskAllocationBlockingDetails);
    }

    // Checking Availability for Task Allocation
    for (int i =
      0; i < numOfActiveAndPendingTaskAllocBlockingPeriodsForUser; i++) {
      TaskAllocationBlockingDetails taskAllocationBlockingDetails =
        new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails =
        allTaskAllocationBlockingPeriodsForUserDetails.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls
          .item(i);

      if (taskAllocationBlockingDetails.taskAllocationBlockingStatus
        .equals(TASKREDIRECTIONSTATUS.ACTIVE)) {
        // BEGIN, CR00182755, CL
        allTaskAllocationBlockingPeriodsForUserDetailsList.availableForTaskAllocationStatus =
          new curam.util.exception.LocalisableString(
            curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_NO)
              .getMessage();
        // END, CR00182755
      }
    }
    return allTaskAllocationBlockingPeriodsForUserDetailsList;
  }

  /**
   * This method allows the supervisor to fetch the page name based on selected
   * task option.
   *
   * @param key
   * - ResolveTaskOptionKey
   * @return ResolveUserPageDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveUserPageDetails
    resolveUserTasksByDateOrWeek(final ResolveTaskOptionKey key)
      throws AppException, InformationalException {

    final ResolveUserPageDetails resolveUserPages =
      new ResolveUserPageDetails();

    final String taskOptionCode = key.taskOptionCode;

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
        USERTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
          USERTASKOPTIONPAGE.DUEBYWEEK_ALL,
          TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(USERTASKOPTIONPAGE.TABLENAME,
          USERTASKOPTIONPAGE.DUEONDATE_ALL,
          TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveUserPages.pageName = pageName;
    return resolveUserPages;
  }

  // ___________________________________________________________________________

  // BEGIN, CR00161962, BK
  /**
   * This method reallocates the not reserved tasks by the supervisor.
   *
   * @param key
   * - ReallocateTaskIDDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public InformationalMsgDetailsList
    reallocateTasksNotReservedByUser(final ReallocateTaskIDDetails dtls)
      throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsersObj =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to reallocate the tasks not reserved by user
    return maintainSupervisorUsersObj
      .reallocateTasksNotReservedByUser(dtls.dtls);
  }

  // END, CR00161962

  // BEGIN, CR00188841, PDN
  // __________________________________________________________________________
  /**
   * This method reads the details for a user tab panel.
   *
   * @param key
   * - SupervisorUserTabKey which contains the userName
   * @return SupervisorUserTabDetails - the details for the tab panel
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SupervisorUserTabDetails
    readSupervisorUserTabDetails(final SupervisorUserTabKey key)
      throws AppException, InformationalException {

    SupervisorUserTabDetails supervisorUserTabDetails =
      new SupervisorUserTabDetails();

    final curam.core.struct.SupervisorUserTabKey supervisorUserTabKey =
      new curam.core.struct.SupervisorUserTabKey();

    supervisorUserTabKey.currentDateTime = DateTime.getCurrentDateTime();
    supervisorUserTabKey.userName = key.userName;

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsersObj =
      MaintainSupervisorUsersFactory.newInstance();

    supervisorUserTabDetails = maintainSupervisorUsersObj
      .readSupervisorUserTabDetails(supervisorUserTabKey);

    return supervisorUserTabDetails;
  }

  // END, CR00188841

  // BEGIN, CR00216252 MN
  // BEGIN, CR00280640, DJ
  /**
   * This method allows the supervisor to view the user workspace details. The
   * user Workspace allows supervisors to manage tasks and cases by use.
   * This method also allows the user to view workspace of members other
   * than users.
   *
   * @param key Contains the user name and task option.
   *
   * @return The user workspace details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #readSupervisorWorkspaceContentDetails(UserNameAndTaskOptionKey)}.
   * This method is deprecated because the return struct parameter
   * does not contain the attribute for informational messages. See
   * release note: CR00280640.
   */
  @Override
  @Deprecated
  // END, CR00280640
  public SupervisorWorkspaceDetails
    readSupervisorWorkspaceDetails(final UserNameAndTaskOptionKey key)
      throws AppException, InformationalException {

    // object creation
    final SupervisorWorkspaceDetails workspaceDetails =
      new SupervisorWorkspaceDetails();

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUser =
      MaintainSupervisorUsersFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();
    curam.supervisor.sl.struct.SupervisorUserWorkspaceDetails userWorkspaceDetails =
      new curam.supervisor.sl.struct.SupervisorUserWorkspaceDetails();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    userNameKey.userName = key.userName;

    // check the task option code and call the appropriate SL method to
    // fetch the user workspace details
    if (key.taskOption.equalsIgnoreCase(VIEWTASKSOPTION.NEXTMONTH)) {
      userWorkspaceDetails = maintainSupervisorUser
        .readSupervisorWorkspaceMonthDetails(userNameKey);
    } else {
      userWorkspaceDetails = maintainSupervisorUser
        .readSupervisorWorkspaceWeekDetails(userNameKey);
    }
    workspaceDetails.dtls = userWorkspaceDetails;

    // get the page description for the user
    workspaceDetails.pageDescription =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    // set the task option code on the workspace
    if (key.taskOption.equalsIgnoreCase("")) {
      workspaceDetails.taskOption = VIEWTASKSOPTION.DEFAULTCODE;
    } else {
      workspaceDetails.taskOption = key.taskOption;
    }

    return workspaceDetails;
  }

  // END, CR00216252

  // BEGIN, CR00280640, DJ
  /**
   * This allows the supervisor to view the user workspace content details
   * weekly or monthly
   * depending on the task option. The user workspace allows supervisors to
   * manage tasks and
   * cases by user.
   *
   * @param userNameAndTaskOptionKey
   * Contains the user name and task option.
   *
   * @return The user workspace content details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public SupervisorWorkspaceContentDetails
    readSupervisorWorkspaceContentDetails(
      final UserNameAndTaskOptionKey userNameAndTaskOptionKey)
      throws AppException, InformationalException {

    final SupervisorWorkspaceContentDetails supervisorWorkspaceContentDetails =
      new SupervisorWorkspaceContentDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUser =
      MaintainSupervisorUsersFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();
    final SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    userNameKey.userName = userNameAndTaskOptionKey.userName;

    // check the task option code and call the appropriate service layer method
    // to
    // fetch the user workspace details.
    if (VIEWTASKSOPTION.NEXTMONTH
      .equalsIgnoreCase(userNameAndTaskOptionKey.taskOption)) {
      supervisorWorkspaceContentDetails.contentDetails =
        maintainSupervisorUser
          .readSupervisorWorkSpaceContentMonthDetails(userNameKey);
    } else {
      supervisorWorkspaceContentDetails.contentDetails =
        maintainSupervisorUser
          .readSupervisorWorkSpaceContentWeekDetails(userNameKey);
    }
    supervisorWorkspaceContentDetails.pageDescription =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    if (StringUtil.isNullOrEmpty(userNameAndTaskOptionKey.taskOption)) {
      supervisorWorkspaceContentDetails.taskOption =
        VIEWTASKSOPTION.DEFAULTCODE;
    } else {
      supervisorWorkspaceContentDetails.taskOption =
        userNameAndTaskOptionKey.taskOption;
    }
    return supervisorWorkspaceContentDetails;
  }

  // END, CR00280640

  // BEGIN, CR00216807 MN
  /**
   * This method allows the supervisor to list all the redirected task records
   * for the user as well as other members. Lists details of active and
   * pending redirections, expired redirections
   *
   * @param key
   * - UserNameKey
   * @return ListTasksRedirectionHistoryDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListUserTasksRedirectionHistoryDetails listTaskRedirectionHistory(
    final UserNameKey key) throws AppException, InformationalException {

    // object creation
    final ListUserTasksRedirectionHistoryDetails historyDetails =
      new ListUserTasksRedirectionHistoryDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsersObj =
      MaintainSupervisorUsersFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // call the SL method to get the user tasks
    final UserTasksRedirectionHistoryDetailsList detailsList =
      maintainSupervisorUsersObj.listTaskRedirectionHistory(key);

    historyDetails.dtls = detailsList;

    // read the page context description for the user
    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(key);

    historyDetails.pageContextDescription = pageContextDetails;

    return historyDetails;
  }

  // END, CR00216807

  // BEGIN, CR00225492 MN
  /**
   * This method redirects the tasks assignment between users and members
   * other than users for a specified time period. It also lists out current
   * and pending redirections.
   *
   * @param key
   * - TaskRedirectionDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void taskRedirectionsToUser(final UserTaskRedirectionDetails key)
    throws AppException, InformationalException {

    // object creation
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    // call the SL method to redirect the tasks
    maintainSupervisorUsers.taskRedirectionsToUser(key.dtls);
  }

  // END, CR00225492

  // BEGIN, CR00216292, LP
  /**
   * This method allows the supervisor to list the details of work queues for
   * the subscribed user. And also details of number of tasks user has reserved
   * from work queue, and total number of tasks in work queue.
   *
   * @param key
   * - UsersKey (holds the userName)
   * @return ListUserWorkQueueDetails.
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListUserOrgObjectWorkQueueDetails listWorkQueuesForSupervisor(
    final UsersKey key) throws AppException, InformationalException {

    // object creation
    final UserWorkspace userWorkSpaceObj = UserWorkspaceFactory.newInstance();
    final ListUserOrgObjectWorkQueueDetails listUserWorkQueueDetails =
      new ListUserOrgObjectWorkQueueDetails();
    UserWorkQueueWithPageContextDetailsList userWorkQueueDetailsListObj =
      new UserWorkQueueWithPageContextDetailsList();
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();

    // call SL method to get the work queues for the subscribed user
    userWorkQueueDetailsListObj =
      userWorkSpaceObj.listWorkQueuesWithPageContextForUser(key);
    listUserWorkQueueDetails.dtls.assign(userWorkQueueDetailsListObj);

    // call the SL method to get the indirect assignment details as well
    final curam.core.sl.supervisor.struct.UserOrgObjectsWorkQueueDetailsList taskList =
      userWorkSpaceObj.listWorkQueuesForUserOrgObjects(key);

    final int numberOfRecords = taskList.dtls.size();

    for (int i = 0; i < numberOfRecords; i++) {
      final curam.core.sl.supervisor.struct.UserOrgObjectsWorkQueueDetails result =
        taskList.dtls.item(0);
      final curam.supervisor.facade.struct.UserOrgObjectsWorkQueueDetails userOrgObjectsWorkQueueDetails =
        new curam.supervisor.facade.struct.UserOrgObjectsWorkQueueDetails();

      userOrgObjectsWorkQueueDetails.workQueueID = result.workQueueID;
      userOrgObjectsWorkQueueDetails.workQueueName = result.workQueueName;
      userOrgObjectsWorkQueueDetails.unsubscribePageText =
        result.unsubscribePageText;
      userOrgObjectsWorkQueueDetails.subscriptionDateTime =
        result.subscriptionDateTime;
      userOrgObjectsWorkQueueDetails.subscriberType = result.subscriberType;
      userOrgObjectsWorkQueueDetails.subscriberName = result.subscriberName;
      userOrgObjectsWorkQueueDetails.subscriberID = result.subscriberID;
      userOrgObjectsWorkQueueDetails.pageTitle = result.pageTitle;
      userOrgObjectsWorkQueueDetails.numberOfWorkQueueTasks =
        result.numberOfWorkQueueTasks;
      userOrgObjectsWorkQueueDetails.numberOfReservedTasksByUser =
        result.numberOfReservedTasksByUser;
      listUserWorkQueueDetails.orgObjectsDtls.dtls
        .addRef(userOrgObjectsWorkQueueDetails);
    }

    // get the user name and the page context details for the user
    userNameKey.userName = key.userName;
    listUserWorkQueueDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);

    return listUserWorkQueueDetails;
  }

  // END, CR00216292

  // BEGIN, CR00236932, PM
  /**
   * This method allows the supervisor to subscribe the user for the selected
   * work queue.
   *
   * @param key
   * Contains the user subscription details for the work queue.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void subscribeWorkqueueUser(final SubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();
    final curam.supervisor.sl.struct.SubscribeUserWorkQueueKey subscribeUserWorkQueueKey =
      new curam.supervisor.sl.struct.SubscribeUserWorkQueueKey();

    subscribeUserWorkQueueKey.assign(key.key);

    maintainSupervisorUsers
      .subscribeUserToWorkqueue(subscribeUserWorkQueueKey);
  }

  // END, CR00236932

  // BEGIN, CR00247543, AK
  /**
   * This method allows the supervisor to subscribe the organization object
   * for the selected work queue.
   *
   * @param details The details required to create a work queue subscription.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void
    subscribeOrgObjectToWorkqueue(final WorkQueueSubscriptionDetails details)
      throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    maintainSupervisorUsers.subscribeOrgObjectToWorkqueue(details);
  }

  // END, CR00247543

  // BEGIN, CR00351910, IBM
  /**
   * This method allows the supervisor to fetch list of tasks associated with
   * the case, which have been reserved by a particular user, and then deferred.
   *
   * @param key
   * Contains the user name.
   *
   * @return The list of details of deferred tasks reserved by user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListReservedDeferredTasksByUserDetails
    listReservedDeferredTasksByUser(
      final ListDeferredTasksReservedByUserKey key)
      throws AppException, InformationalException {

    // BEGIN, CR00372642, SG
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    final ListDeferredTasksReservedByUserDetails listDeferredTasksReservedByUserDetails =
      new ListDeferredTasksReservedByUserDetails();

    final SupervisorApplicationPageContextDescription contextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();

    // call the SL method to get the tasks reserved and then deferred.
    listDeferredTasksReservedByUserDetails.dtls =
      maintainSupervisorUsers.listDeferredTasksReservedByUser(key.key);

    // get the user name and the page context details for the user
    userNameKey.userName = key.key.userName;
    listDeferredTasksReservedByUserDetails.pageContext =
      contextDescription.readUserNamePageContextDescription(userNameKey);
    // END, CR00372642

    final ListReservedDeferredTasksByUserDetails listReservedDeferredTasksByUserDetails =
      new ListReservedDeferredTasksByUserDetails();

    listReservedDeferredTasksByUserDetails.dtls =
      listDeferredTasksReservedByUserDetails.dtls;
    listReservedDeferredTasksByUserDetails.pageContext =
      listDeferredTasksReservedByUserDetails.pageContext;

    // BEGIN, CR00358498, IBM
    final InformationalMsgDtlsList informationalMsgDtlsList =
      CommonUtils.populateInformationalMsgDtlsByUserName(
        CommonUtils.BULK_OPERATION_TASK_FORWARD,
        TransactionInfo.getProgramUser(),
        BPOBULKTASKFORWARD.DEFERRED_PROCESS_INFO_MESSAGE,
        BPOBULKTASKFORWARD.BATCH_PROCESS_INFO_MESSAGE);

    // END, CR00358498

    listReservedDeferredTasksByUserDetails.informationalMsgDtlsList =
      informationalMsgDtlsList;

    return listReservedDeferredTasksByUserDetails;
  }

  /**
   * This method allows the supervisor to fetch a list of tasks associated with
   * the case, which have been reserved by a particular user, that are open.
   *
   * @param key
   * Contains the user name.
   *
   * @return The list of details of open tasks reserved by user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListReservedOpenTasksByUserDetails
    listReservedOpenTasksByUser(final ListOpenTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      listOpenTasksReservedByUser(key);

    final ListReservedOpenTasksByUserDetails listReservedOpenTasksByUserDetails =
      new ListReservedOpenTasksByUserDetails();

    listReservedOpenTasksByUserDetails.dtls =
      listOpenTasksReservedByUserDetails.dtls;
    listReservedOpenTasksByUserDetails.pageContext =
      listOpenTasksReservedByUserDetails.pageContext;

    // BEGIN, CR00358498, IBM
    final InformationalMsgDtlsList informationalMsgDtlsList =
      CommonUtils.populateInformationalMsgDtlsByUserName(
        CommonUtils.BULK_OPERATION_TASK_FORWARD,
        TransactionInfo.getProgramUser(),
        BPOBULKTASKFORWARD.DEFERRED_PROCESS_INFO_MESSAGE,
        BPOBULKTASKFORWARD.BATCH_PROCESS_INFO_MESSAGE);

    // END, CR00358498

    listReservedOpenTasksByUserDetails.informationalMsgDtlsList =
      informationalMsgDtlsList;

    return listReservedOpenTasksByUserDetails;
  }

  /**
   * Lists all the User Cases and allows supervisor to list all unclosed cases
   * of the selected user.
   *
   * @param userNameOrgObjectKey contains userNameOrgObjectKey details.
   *
   * @return The list of supervisor user case details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public SupervisorCaseDetailsWithInformationalMessage
    listAllUserCaseDetails(final UserNameOrgObjectKey userNameOrgObjectKey)
      throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final SupervisorCaseDetailsWithInformationalMessage supervisorCaseDetailsWithInformationalMessage =
      new SupervisorCaseDetailsWithInformationalMessage();

    final curam.supervisor.sl.intf.MaintainSupervisorUsers workspace =
      MaintainSupervisorUsersFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription =
      SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();

    final SupervisorUserCaseDetails userCaseDetails =
      workspace.listAllUserCases(userNameOrgObjectKey.key);

    supervisorCaseDetailsWithInformationalMessage.caseDetails =
      userCaseDetails;

    userNameKey.userName = userNameOrgObjectKey.key.userName;

    final SupervisorApplicationPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(userNameKey);

    supervisorCaseDetailsWithInformationalMessage.pageContextDescription =
      pageContextDetails;

    // BEGIN, CR00357932, IBM
    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    if (null != userNameOrgObjectKey.key.orgObjectKey
      && userNameOrgObjectKey.key.orgObjectKey.length() > 0) {

      // BEGIN, CR00358498, IBM
      informationalMsgDtlsList =
        CommonUtils.populateInformationalMsgDtlsByUserName(
          CommonUtils.BULK_OPERATION_CASE_REASSIGNMENT,
          TransactionInfo.getProgramUser(),
          BPOBULKCASEREASSIGNMENT.DEFERRED_PROCESS_INFO_MESSAGE,
          BPOBULKCASEREASSIGNMENT.BATCH_PROCESS_INFO_MESSAGE);
      // END, CR00358498

    }
    // END, CR00357932
    // BEGIN, CR00417796, RB
    if (Configuration.getBooleanProperty(EnvVars.ENV_CASE_SEARCH,
      Configuration.getBooleanProperty(EnvVars.ENV_CASE_SEARCH_DEFAULT))) {
      supervisorCaseDetailsWithInformationalMessage.caseSearchIndOpt = true;
    }
    // END, CR00417796
    supervisorCaseDetailsWithInformationalMessage.informationalMsgDtlsList =
      informationalMsgDtlsList;

    return supervisorCaseDetailsWithInformationalMessage;
  }

  // END, CR00351910

  // BEGIN, CR00357932, IBM
  /**
   * Populates and returns the information message details.
   *
   * @param catEntry The informational message entry.
   * @param count Total number of case reassignment or tasks forward count.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  private InformationalMsgDtlsList
    populateInformationalMsgDtsList(final CatEntry catEntry, final int count)
      throws AppException, InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final AppException infoMessage = new AppException(catEntry);

    infoMessage.arg(count);

    TransactionInfo.getInformationalManager().addInformationalMsg(infoMessage,
      CuramConst.gkEmpty, InformationalType.kWarning);

    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();
    final String[] messages =
      informationalManager.obtainInformationalAsString();

    for (final String message : messages) {
      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  // END, CR00357932

  // BEGIN, CR00369467, IBM
  /**
   * Reassigns cases to a selected user. This method allows supervisor to
   * reassign some or all of the cases that the user owns and indicates the
   * informational message when cases are queued to later assignment.
   *
   * @param key
   * - ReassignCasesForUserKey (tab-delimited string list of caseID's)
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public InformationalMsgDtlsList
    reassignCasesForOrganisationObjectWithInformationalMessage(
      final ReassignCasesForUserKey reassignCasesForUserKey)
      throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    maintainSupervisorUsers
      .reassignCasesForOrganisationObject(reassignCasesForUserKey.userKey);

    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    final String propertyName =
      EnvVars.ENV_BULK_CASE_REASSIGNMENT_DEFERRED_PROCESS_MAX_PROCESSING_COUNT;
    final int defaultValue =
      EnvVars.ENV_BULK_CASE_REASSIGNMENT_DEFERRED_PROCESS_MAX_PROCESSING_COUNT_DEFAULT;

    final StringList caseList = StringUtil
      .tabText2StringList(reassignCasesForUserKey.userKey.reassignCasesList);

    final int noOfProcessableCases = CommonUtils
      .getConfigurationIntegerPropertyValue(propertyName, defaultValue);

    if (noOfProcessableCases < caseList.size()) {

      informationalMsgDtlsList = populateInformationalMsgDtsList(
        BPOBULKCASEREASSIGNMENT.SUPERVISOR_CASE_QUEUED_FOR_LATER_REASSIGNMENT,
        caseList.size());
    }

    return informationalMsgDtlsList;
  }

  /**
   * Forward tasks to a selected user. This method allows supervisor to
   * forward some or all of the tasks that the user owns and indicates the
   * informational message when tasks are queued to later assignment.
   *
   * @param key - SupervisorTaskForwardDetails
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public InformationalMsgDtlsList
    forwardTasksReservedByUserWithInformationalMessage(
      final SupervisorTaskForwardDetails supervisorTaskForwardDetails)
      throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    maintainSupervisorUsers
      .forwardTasksReservedByUser(supervisorTaskForwardDetails.details);

    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    final String propertyName =
      EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT;
    final int defaultValue =
      EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT_DEFAULT;

    // BEGIN, CR00378956, IBM
    final StringList openTaskIDList = StringUtil.tabText2StringList(
      supervisorTaskForwardDetails.details.openTaskIDList);
    final StringList deferredTaskIDList = StringUtil.tabText2StringList(
      supervisorTaskForwardDetails.details.deferredTaskIDList);

    final StringList taskList = new StringList();

    taskList.addAll(deferredTaskIDList);
    taskList.addAll(openTaskIDList);
    // END, CR00378956

    final int noOfProcessableCases = CommonUtils
      .getConfigurationIntegerPropertyValue(propertyName, defaultValue);

    if (noOfProcessableCases < taskList.size()) {

      informationalMsgDtlsList = populateInformationalMsgDtsList(
        BPOBULKTASKFORWARD.SUPERVISOR_TASK_QUEUED_FOR_LATER_REASSIGNMENT,
        taskList.size());
    }

    return informationalMsgDtlsList;
  }

  /**
   * This method allows the supervisor to fetch a list of tasks associated with
   * the task, which have been reserved by a particular user, that are open.
   *
   * @param key
   * Contains the user name.
   *
   * @return The list of details of open tasks reserved by user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListReservedOpenTasksByUserDetails
    listReservedOpenTasksByFiltered(final ListOpenTasksReservedByUserKey key)
      throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorUsers =
      MaintainSupervisorUsersFactory.newInstance();

    final curam.supervisor.sl.struct.ListOpenTasksReservedByUserKey userKey =
      new curam.supervisor.sl.struct.ListOpenTasksReservedByUserKey();

    userKey.userName = key.key.userName;

    final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
      new ListOpenTasksReservedByUserDetails();

    listOpenTasksReservedByUserDetails.dtls =
      maintainSupervisorUsers.listOpenTasksReservedByFiltered(userKey);

    final ListReservedOpenTasksByUserDetails listReservedOpenTasksByUserDetails =
      new ListReservedOpenTasksByUserDetails();

    listReservedOpenTasksByUserDetails.dtls =
      listOpenTasksReservedByUserDetails.dtls;
    listReservedOpenTasksByUserDetails.pageContext =
      listOpenTasksReservedByUserDetails.pageContext;

    final InformationalMsgDtlsList informationalMsgDtlsList =
      CommonUtils.populateInformationalMsgDtlsByUserName(
        CommonUtils.BULK_OPERATION_TASK_FORWARD,
        TransactionInfo.getProgramUser(),
        BPOBULKTASKFORWARD.DEFERRED_PROCESS_INFO_MESSAGE,
        BPOBULKTASKFORWARD.BATCH_PROCESS_INFO_MESSAGE);

    listReservedOpenTasksByUserDetails.informationalMsgDtlsList =
      informationalMsgDtlsList;

    return listReservedOpenTasksByUserDetails;
  }

  // END, CR00369467

  // BEGIN, CR00372642, SG
  // BEGIN, CR00377799, SG
  /**
   * Reassigns cases to a selected user and an informational message is
   * displayed when cases are queued to later assignment. The supervisor can
   * reassign some or all of the cases that the user owns.
   *
   * @param searchKey Contains the details of search criteria.
   *
   * @return List of cases currently owned by the user.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public CaseSearchResultList reassignCasesForOrgObjectWithSearch(
    final ReassignCasesForUserSearchKey searchKey)
    throws AppException, InformationalException {

    CaseSearchResultList caseSearchResultList = new CaseSearchResultList();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorObj =
      MaintainSupervisorUsersFactory.newInstance();
    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    if (ClientActionConst.kSearchUsers.equals(searchKey.actionIDProperty)) {

      CaseSearchDetails1 caseSearchDetails1 = null;

      if (searchKey.allCasesAssignedToUser) {

        final UserNameOrgObjectKey userNameOrgObjectKey =
          new UserNameOrgObjectKey();

        userNameOrgObjectKey.key.userName =
          searchKey.key.OrgObjLinkDtls.userName;
        // BEGIN, 198952, CP
        userNameOrgObjectKey.key.searchTypeOpt =
          BATCHPROCESSNAME.BULK_CASE_REASSIGNMENTS;
        // END, 198952
        final SupervisorCaseDetailsWithInformationalMessage caseDetailResults =
          listAllUserCaseDetails(userNameOrgObjectKey);

        caseSearchResultList.msgList =
          caseDetailResults.informationalMsgDtlsList;

        for (final CaseReferenceTypeProductRolePriClientDateAndStatus caseRefTypeProdRolePriClientDateStatus : caseDetailResults.caseDetails.caseDtlsList.dtls
          .items()) {
          caseSearchDetails1 = new CaseSearchDetails1();
          caseSearchDetails1.caseID =
            caseRefTypeProdRolePriClientDateStatus.caseID;
          caseSearchDetails1.caseReference =
            caseRefTypeProdRolePriClientDateStatus.caseReference;
          caseSearchDetails1.caseCatTypeCode =
            caseRefTypeProdRolePriClientDateStatus.productTypeDesc;
          caseSearchDetails1.concernRoleName =
            caseRefTypeProdRolePriClientDateStatus.primaryClient;
          caseSearchDetails1.statusCode =
            caseRefTypeProdRolePriClientDateStatus.status;
          caseSearchResultList.listDtls.searchDtls.addRef(caseSearchDetails1);
        }

      } else {

        final NotFoundIndicator orgObjectNotFoundInd =
          new NotFoundIndicator();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = searchKey.key.OrgObjLinkDtls.userName;

        final OrgObjectLinkDtls orgObjectLinkDtls = OrgObjectLinkFactory
          .newInstance().readByUsername(orgObjectNotFoundInd, usersKey);

        if (!orgObjectNotFoundInd.isNotFound()) {
          final long orgObjLinkID = orgObjectLinkDtls.orgObjectLinkID;
          final String ownerList =
            String.valueOf(orgObjLinkID) + CuramConst.gkTabDelimiter;

          searchKey.search.ownerList = ownerList;
          searchKey.search.orgObjectLinkID = orgObjLinkID;
        }

        final curam.supervisor.sl.struct.ReassignCasesForUserSearchKey reassignCasesForUserSearchKey =
          new curam.supervisor.sl.struct.ReassignCasesForUserSearchKey();

        reassignCasesForUserSearchKey.searchCriteria.assign(searchKey.search);

        final CaseSearchList1 caseSearchList =
          maintainSupervisorObj.caseSearch(reassignCasesForUserSearchKey);

        for (final CaseSearchDetails1 caseSearchDtls1 : caseSearchList.searchDtls
          .items()) {

          // BEGIN, WI194964, YF
          // Skip PDC cases
          if (caseSearchDtls1.caseTypeCode
            .equals(CASETYPECODE.PARTICIPANTDATACASE)) {
            continue;
          }
          // END, WI194964, YF

          caseSearchDetails1 = new CaseSearchDetails1();
          caseSearchDetails1.caseID = caseSearchDtls1.caseID;
          caseSearchDetails1.caseReference = caseSearchDtls1.caseReference;
          caseSearchDetails1.caseCatTypeCode =
            caseSearchDtls1.caseCatTypeCode;
          caseSearchDetails1.concernRoleName =
            caseSearchDtls1.concernRoleName;
          caseSearchDetails1.statusCode = caseSearchDtls1.statusCode;
          caseSearchResultList.listDtls.searchDtls.addRef(caseSearchDetails1);
        }

        // BEGIN, CR00379440, IBM
        final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
        final UserStatusAndOrgObjectKey userStatusAndOrgObjectKey =
          new UserStatusAndOrgObjectKey();
        final CaseSearchResultList filteredCaseList =
          new CaseSearchResultList();

        userStatusAndOrgObjectKey.orgObjectType = ORGOBJECTTYPE.USER;
        userStatusAndOrgObjectKey.userName =
          searchKey.key.OrgObjLinkDtls.userName;
        userStatusAndOrgObjectKey.status = CASESTATUS.CLOSED;

        boolean isCaseBatchQueued;
        final CaseReferenceTypeProductRolePriClientDateAndStatusList batchCaseList =
          caseHeaderObj
            .searchAllCasesByBatchQueuedStatus(userStatusAndOrgObjectKey);

        for (final CaseSearchDetails1 caseSearchDetails : caseSearchResultList.listDtls.searchDtls
          .items()) {

          isCaseBatchQueued = false;

          for (final CaseReferenceTypeProductRolePriClientDateAndStatus batchCaseReferenceTypeProductRolePriClientDateAndStatus : batchCaseList.dtls
            .items()) {

            if (caseSearchDetails.caseID == batchCaseReferenceTypeProductRolePriClientDateAndStatus.caseID) {
              isCaseBatchQueued = true;
              break;
            }
          }

          if (!isCaseBatchQueued) {
            filteredCaseList.listDtls.searchDtls.addRef(caseSearchDetails);
          }
        }

        caseSearchResultList = filteredCaseList;
        // END, CR00379440

        final InformationalManager informationalManager =
          TransactionInfo.getInformationalManager();
        final String[] infos =
          informationalManager.obtainInformationalAsString();

        informationalMsgDtlsList = new InformationalMsgDtlsList();
        InformationalMsgDtls informationalMsgDtls = null;

        for (final String message : infos) {
          informationalMsgDtls = new InformationalMsgDtls();
          informationalMsgDtls.informationMsgTxt = message;
          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
        }

        caseSearchResultList.msgList = informationalMsgDtlsList;

      }

    } else if (ClientActionConst.kReassignCases
      .equals(searchKey.actionIDProperty)) {

      final ReassignCasesForUserKey reassignCasesForUserKey =
        new ReassignCasesForUserKey();

      // BEGIN, CR00378956, IBM
      searchKey.key.OrgObjLinkDtls.userName = CuramConst.gkEmpty;
      // END, CR00378956

      reassignCasesForUserKey.userKey = searchKey.key;

      caseSearchResultList.msgList =
        reassignCasesForOrganisationObjectWithInformationalMessage(
          reassignCasesForUserKey);

    }

    return caseSearchResultList;

  }

  /**
   * Displays a message that if more than default number of cases are selected
   * for reassignment, then they would be processed by batch or deferred
   * process.
   *
   * @return List of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InformationalMsgDtlsList displayCaseReassignmentInformation()
    throws AppException, InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();

    final String propertyName =
      EnvVars.ENV_BULK_CASE_REASSIGNMENT_DEFERRED_PROCESS_MAX_PROCESSING_COUNT;
    final int defaultValue =
      EnvVars.ENV_BULK_CASE_REASSIGNMENT_DEFERRED_PROCESS_MAX_PROCESSING_COUNT_DEFAULT;

    final int noOfProcessableCases = CommonUtils
      .getConfigurationIntegerPropertyValue(propertyName, defaultValue);

    informationalMsgDtlsList = populateInformationalMsgDtsList(
      BPOBULKCASEREASSIGNMENT.INF_SUPERVISOR_CASE_REASSIGNMENT,
      noOfProcessableCases);

    return informationalMsgDtlsList;

  }

  /**
   * Forwards the selected tasks assigned to an user to another user or
   * to a work queue or to a position or to an organization unit.
   *
   * @param assignedTaskForwardDetails
   * The details of the unreserved tasks that need to be forwarded.
   *
   * @return List of tasks currently assigned to the user.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public AssignedTaskForUserList forwardTasksNotReservedByUserSearch(
    final AssignedTaskForwardDetails assignedTaskForwardDetails)
    throws AppException, InformationalException {

    AssignedTaskForUserList assignedTaskForUserList =
      new AssignedTaskForUserList();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorObj =
      MaintainSupervisorUsersFactory.newInstance();

    if (ClientActionConst.kSearchTasks
      .equals(assignedTaskForwardDetails.actionIDProperty)) {

      // BEGIN, CR00379440, IBM
      final GenericBatchProcessInput batchProcessInput =
        GenericBatchProcessInputFactory.newInstance();
      boolean isTaskBatchQueued;

      final BatchQueuedTaskIDList batchQueuedTaskIDList =
        batchProcessInput.searchAssignedTaskByBatchStatus();

      // END, CR00379440

      if (assignedTaskForwardDetails.allTasksAssignedToUser) {

        final ListUnreservedTasksForUserKey listUnreservedTasksForUserKey =
          new ListUnreservedTasksForUserKey();

        listUnreservedTasksForUserKey.key.userName =
          assignedTaskForwardDetails.taskFwdDtls.userName;

        final ListUnreservedTasksForUserDetails listUnreservedTasksForUserDetails =
          listTasksAssignedToUser(listUnreservedTasksForUserKey);

        TaskQueryResultDetails taskQueryResultDetails = null;

        for (final AssignedTaskDetails assignedTaskDetails : listUnreservedTasksForUserDetails.dtls.taskDetailsList.taskDetailsList
          .items()) {

          taskQueryResultDetails = new TaskQueryResultDetails();
          taskQueryResultDetails.taskID = assignedTaskDetails.taskID;
          taskQueryResultDetails.subject = assignedTaskDetails.subject;
          taskQueryResultDetails.priority = assignedTaskDetails.priority;
          taskQueryResultDetails.assignedDateTime =
            assignedTaskDetails.assignedDateTime;
          taskQueryResultDetails.deadlineDateTime =
            assignedTaskDetails.deadlineDateTime;
          taskQueryResultDetails.versionNo = assignedTaskDetails.versionNo;

          assignedTaskForUserList.taskQueryResultDetailsList.taskDetailsList
            .addRef(taskQueryResultDetails);
        }

      } else {

        assignedTaskForwardDetails.taskQueryCriteria.isAvailableTaskSearch =
          true;
        assignedTaskForwardDetails.taskQueryCriteria.assigneeType =
          ASSIGNEETYPE.USER;
        assignedTaskForwardDetails.taskQueryCriteria.assignedToID =
          assignedTaskForwardDetails.taskFwdDtls.userName;
        assignedTaskForwardDetails.taskQueryCriteria.relatedName =
          assignedTaskForwardDetails.taskFwdDtls.userName;

        assignedTaskForUserList.taskQueryResultDetailsList =
          maintainSupervisorObj
            .taskSearch(assignedTaskForwardDetails.taskQueryCriteria);
      }

      // BEGIN, CR00379440, IBM
      final AssignedTaskForUserList filteredAssignedTaskForUserList =
        new AssignedTaskForUserList();

      for (final TaskQueryResultDetails taskQueryResultDetails : assignedTaskForUserList.taskQueryResultDetailsList.taskDetailsList
        .items()) {
        isTaskBatchQueued = false;

        for (final BatchQueuedTaskID batchQueuedTaskID : batchQueuedTaskIDList.dtls
          .items()) {
          if (taskQueryResultDetails.taskID == batchQueuedTaskID.taskID) {
            isTaskBatchQueued = true;
            break;
          }
        }

        if (!isTaskBatchQueued) {
          filteredAssignedTaskForUserList.taskQueryResultDetailsList.taskDetailsList
            .addRef(taskQueryResultDetails);
        }
      }

      assignedTaskForUserList = filteredAssignedTaskForUserList;
      // END, CR00379440

    } else if (ClientActionConst.kForwardTasks
      .equals(assignedTaskForwardDetails.actionIDProperty)) {

      final SupervisorTaskFwdDetails supervisorTaskFwdDetails =
        new SupervisorTaskFwdDetails();

      supervisorTaskFwdDetails.details =
        assignedTaskForwardDetails.taskFwdDtls;

      // BEGIN, CR00379440, IBM
      forwardTasksNotReservedByUser(supervisorTaskFwdDetails);

      final StringList assignedTaskIDList = StringUtil.tabText2StringList(
        supervisorTaskFwdDetails.details.assignedTaskIDList);

      final TaskCountDetails countDetails = new TaskCountDetails();

      countDetails.taskCount = assignedTaskIDList.size();

      assignedTaskForUserList.taskQueryResultDetailsList.informationalMsgDetailsList =
        displayTaskForwardInformation(countDetails);
      // END, CR00379440
    }

    return assignedTaskForUserList;

  }

  /**
   * Forwards the selected tasks reserved by an user to another user or
   * to a work queue or to a position or to an organization unit.
   *
   * @param reservedTaskForwardDetails The details of the reserved tasks that
   * need to be forwarded.
   *
   * @return List of tasks currently reserved by the user.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public ReservedTaskByUserList forwardTasksReservedByUserSearch(
    final ReservedTaskForwardDetails reservedTaskForwardDetails)
    throws AppException, InformationalException {

    final ReservedTaskByUserList reservedTaskByUserList =
      new ReservedTaskByUserList();
    final curam.supervisor.sl.intf.MaintainSupervisorUsers maintainSupervisorObj =
      MaintainSupervisorUsersFactory.newInstance();
    InformationalMsgDtls informationalMsgDtls = null;

    if (ClientActionConst.kSearchTasks
      .equals(reservedTaskForwardDetails.actionIDProperty)) {

      // BEGIN, CR00379440, IBM
      final GenericBatchProcessInput batchProcessInput =
        GenericBatchProcessInputFactory.newInstance();
      final UserNameKey userNameKey = new UserNameKey();

      userNameKey.userName = reservedTaskForwardDetails.taskFwdDtls.userName;
      boolean isTaskBatchQueued;

      final BatchQueuedTaskIDList batchQueuedTaskIDList =
        batchProcessInput.searchUserTasksByResultStatus(userNameKey);

      // END, CR00379440

      if (reservedTaskForwardDetails.allTasksReservedByUser) {

        // Deferred tasks
        final ListDeferredTasksReservedByUserDetails listDeferredTasksReservedByUserDetails =
          new ListDeferredTasksReservedByUserDetails();

        final ListTaskKey listTaskKey = new ListTaskKey();

        listTaskKey.userName =
          reservedTaskForwardDetails.taskFwdDtls.userName;

        final ReadMultiOperationDetails readMultiOperationDetails =
          new ReadMultiOperationDetails();

        readMultiOperationDetails.maxListSize = 0;

        listDeferredTasksReservedByUserDetails.dtls.taskDetailsList =
          InboxFactory.newInstance().listLimitedDeferredTasks(listTaskKey,
            readMultiOperationDetails);

        final TaskSortByPriority<DeferredTaskDetails> prioritySort =
          new TaskSortByPriority<DeferredTaskDetails>();

        prioritySort.sortIfEnabled(
          listDeferredTasksReservedByUserDetails.dtls.taskDetailsList.taskDetailsList);

        // BEGIN, CR00379440, IBM
        final ListDeferredTasksReservedByUserDetails filteredDeferredTask =
          new ListDeferredTasksReservedByUserDetails();

        for (final DeferredTaskDetails deferredTaskDetails : listDeferredTasksReservedByUserDetails.dtls.taskDetailsList.taskDetailsList
          .items()) {

          isTaskBatchQueued = false;

          for (final BatchQueuedTaskID batchQueuedTaskID : batchQueuedTaskIDList.dtls
            .items()) {
            if (deferredTaskDetails.taskID == batchQueuedTaskID.taskID) {
              isTaskBatchQueued = true;
              break;
            }
          }

          if (!isTaskBatchQueued) {
            filteredDeferredTask.dtls.taskDetailsList.taskDetailsList
              .addRef(deferredTaskDetails);
          }
        }
        reservedTaskByUserList.deferredTaskDtls = filteredDeferredTask.dtls;
        // END, CR00379440

        InformationalMsgDtlsList informationalMsgDtlsList =
          CommonUtils.populateInformationalMsgDtlsByUserName(
            CommonUtils.BULK_OPERATION_TASK_FORWARD,
            TransactionInfo.getProgramUser(),
            BPOBULKTASKFORWARD.DEFERRED_PROCESS_INFO_MESSAGE,
            BPOBULKTASKFORWARD.BATCH_PROCESS_INFO_MESSAGE);

        if (informationalMsgDtlsList.dtls.isEmpty()) {

          final String propertyName =
            EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT;

          final int defaultValue =
            EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT_DEFAULT;

          final int noOfProcessableTasks = CommonUtils
            .getConfigurationIntegerPropertyValue(propertyName, defaultValue);

          informationalMsgDtlsList = populateInformationalMsgDtsList(
            BPOBULKTASKFORWARD.INF_SUPERVISOR_TASK_REASSIGNMENT,
            noOfProcessableTasks);
        }

        reservedTaskByUserList.resultDtlsList.informationalMsgDetailsList =
          informationalMsgDtlsList;

        // Open tasks
        final ListOpenTasksReservedByUserDetails listOpenTasksReservedByUserDetails =
          new ListOpenTasksReservedByUserDetails();

        final UserNameAndStatusKey userNameAndStatusKey =
          new UserNameAndStatusKey();

        userNameAndStatusKey.userName =
          reservedTaskForwardDetails.taskFwdDtls.userName;
        userNameAndStatusKey.statusCode = TASKSTATUS.NOTSTARTED;

        listOpenTasksReservedByUserDetails.dtls.taskDetailsList =
          InboxFactory.newInstance().listLimitedReservedTasksByStatus(
            userNameAndStatusKey, readMultiOperationDetails);

        final TaskSortByPriority<ReservedByStatusTaskDetails> priorityTaskSort =
          new TaskSortByPriority<ReservedByStatusTaskDetails>();

        final ReservedByStatusTaskDetailsList filteredTaskList =
          new ReservedByStatusTaskDetailsList();

        for (final ReservedByStatusTaskDetails reservedByStatusTaskDetails : listOpenTasksReservedByUserDetails.dtls.taskDetailsList.taskDetailsList
          .items()) {

          isTaskBatchQueued = false;

          for (final BatchQueuedTaskID batchQueuedTaskID : batchQueuedTaskIDList.dtls
            .items()) {
            if (reservedByStatusTaskDetails.taskID == batchQueuedTaskID.taskID) {
              isTaskBatchQueued = true;
              break;
            }
          }

          if (!isTaskBatchQueued) {
            filteredTaskList.taskDetailsList.add(reservedByStatusTaskDetails);
          }
        }

        if (filteredTaskList.taskDetailsList.size() > 0) {
          listOpenTasksReservedByUserDetails.dtls.taskDetailsList =
            filteredTaskList;
        } else {
          listOpenTasksReservedByUserDetails.dtls.taskDetailsList.taskDetailsList
            .clear();
        }

        priorityTaskSort.sortIfEnabled(
          listOpenTasksReservedByUserDetails.dtls.taskDetailsList.taskDetailsList);

        reservedTaskByUserList.openTaskDtls =
          listOpenTasksReservedByUserDetails.dtls;

      } else {

        reservedTaskForwardDetails.taskQueryCriteria.isTaskQuery = true;
        reservedTaskForwardDetails.taskQueryCriteria.searchMyTasksOnly = true;
        reservedTaskForwardDetails.taskQueryCriteria.assigneeType =
          ASSIGNEETYPE.USER;
        reservedTaskForwardDetails.taskQueryCriteria.assignedToID =
          reservedTaskForwardDetails.taskFwdDtls.userName;
        reservedTaskForwardDetails.taskQueryCriteria.relatedName =
          reservedTaskForwardDetails.taskFwdDtls.userName;

        final TaskQueryResultDetailsList taskQueryResultDetailsList =
          maintainSupervisorObj
            .taskSearch(reservedTaskForwardDetails.taskQueryCriteria);

        DeferredTaskDetails deferredTaskDetails = null;
        ReservedByStatusTaskDetails reservedByStatusTaskDetails = null;

        // BEGIN, CR00379440, IBM
        for (final TaskQueryResultDetails taskQueryResultDetails : taskQueryResultDetailsList.taskDetailsList
          .items()) {

          isTaskBatchQueued = false;

          for (final BatchQueuedTaskID batchQueuedTaskID : batchQueuedTaskIDList.dtls
            .items()) {
            if (taskQueryResultDetails.taskID == batchQueuedTaskID.taskID) {
              isTaskBatchQueued = true;
              break;
            }
          }
          if (!isTaskBatchQueued
            && TASKSTATUS.DEFERRED.equals(taskQueryResultDetails.status)) {

            deferredTaskDetails = new DeferredTaskDetails();

            deferredTaskDetails.deadlineDateTime =
              taskQueryResultDetails.deadlineDateTime;
            deferredTaskDetails.priority = taskQueryResultDetails.priority;
            deferredTaskDetails.restartDateTime =
              taskQueryResultDetails.restartTime;
            deferredTaskDetails.subject = taskQueryResultDetails.subject;
            deferredTaskDetails.taskID = taskQueryResultDetails.taskID;
            deferredTaskDetails.versionNo = taskQueryResultDetails.versionNo;

            reservedTaskByUserList.deferredTaskDtls.taskDetailsList.taskDetailsList
              .addRef(deferredTaskDetails);

          } else if (!isTaskBatchQueued
            && TASKSTATUS.NOTSTARTED.equals(taskQueryResultDetails.status)) {

            reservedByStatusTaskDetails = new ReservedByStatusTaskDetails();

            reservedByStatusTaskDetails.assignedDateTime =
              taskQueryResultDetails.assignedDateTime;
            reservedByStatusTaskDetails.priority =
              taskQueryResultDetails.priority;
            reservedByStatusTaskDetails.dueDateTime =
              taskQueryResultDetails.deadlineDateTime;
            reservedByStatusTaskDetails.subject =
              taskQueryResultDetails.subject;
            reservedByStatusTaskDetails.taskID =
              taskQueryResultDetails.taskID;
            reservedByStatusTaskDetails.versionNo =
              taskQueryResultDetails.versionNo;

            reservedTaskByUserList.openTaskDtls.taskDetailsList.taskDetailsList
              .addRef(reservedByStatusTaskDetails);
          }
          // END, CR00379440
        }

        final InformationalManager informationalManager =
          TransactionInfo.getInformationalManager();
        final String[] infos =
          informationalManager.obtainInformationalAsString();
        final InformationalMsgDtlsList informationalMsgDtlsList =
          new InformationalMsgDtlsList();

        for (final String message : infos) {
          informationalMsgDtls = new InformationalMsgDtls();
          informationalMsgDtls.informationMsgTxt = message;
          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
        }

        reservedTaskByUserList.resultDtlsList.informationalMsgDetailsList =
          informationalMsgDtlsList;

      }

    } else if (ClientActionConst.kForwardTasks
      .equals(reservedTaskForwardDetails.actionIDProperty)) {

      // Forward tasks
      final SupervisorTaskForwardDetails supervisorTaskForwardDetails =
        new SupervisorTaskForwardDetails();

      supervisorTaskForwardDetails.details.deferredTaskIDList =
        reservedTaskForwardDetails.taskFwdDtls.deferredTaskIDList;
      supervisorTaskForwardDetails.details.openTaskIDList =
        reservedTaskForwardDetails.taskFwdDtls.openTaskIDList;
      supervisorTaskForwardDetails.details.forwardToOrgUnit =
        reservedTaskForwardDetails.taskFwdDtls.forwardToOrgUnit;
      supervisorTaskForwardDetails.details.forwardToUser =
        reservedTaskForwardDetails.taskFwdDtls.forwardToUser;
      supervisorTaskForwardDetails.details.userName =
        reservedTaskForwardDetails.taskFwdDtls.userName;
      supervisorTaskForwardDetails.details.forwardTaskDetails =
        reservedTaskForwardDetails.taskFwdDtls.forwardTaskDetails;

      reservedTaskByUserList.resultDtlsList.informationalMsgDetailsList =
        forwardTasksReservedByUserWithInformationalMessage(
          supervisorTaskForwardDetails);

    }

    return reservedTaskByUserList;

  }

  // END, CR00372642
  // END, CR00377799

  // BEGIN, CR00379440, IBM
  /**
   * Displays a message that if more than default number of tasks are selected
   * for forward, then they would be processed by batch or deferred process.
   *
   * @return List of informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public InformationalMsgDtlsList
    displayTaskForwardInformation(final TaskCountDetails taskCountDetails)
      throws AppException, InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList =
      new InformationalMsgDtlsList();
    final String propertyName =
      EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT;
    final int defaultValue =
      EnvVars.ENV_BULK_TASK_FORWARD_DEFERRED_PROCESS_MAX_PROCESSING_COUNT_DEFAULT;

    final int noOfProcessableTasks = CommonUtils
      .getConfigurationIntegerPropertyValue(propertyName, defaultValue);

    if (noOfProcessableTasks < taskCountDetails.taskCount) {
      informationalMsgDtlsList = populateInformationalMsgDtsList(
        BPOBULKTASKFORWARD.SUPERVISOR_TASK_QUEUED_FOR_LATER_REASSIGNMENT,
        Integer.parseInt(String.valueOf(taskCountDetails.taskCount)));
    }

    informationalMsgDtlsList =
      CommonUtils.populateInformationalMsgDtlsByUserName(
        CommonUtils.BULK_OPERATION_ASSIGNED_TASK_FORWARD,
        TransactionInfo.getProgramUser(),
        BPOBULKTASKFORWARD.DEFERRED_PROCESS_INFO_MESSAGE,
        BPOBULKTASKFORWARD.BATCH_PROCESS_INFO_MESSAGE);

    if (informationalMsgDtlsList.dtls.isEmpty()) {
      informationalMsgDtlsList = populateInformationalMsgDtsList(
        BPOBULKTASKFORWARD.INF_SUPERVISOR_TASK_REASSIGNMENT,
        noOfProcessableTasks);
    }

    return informationalMsgDtlsList;
  }

  // END, CR00379440

  // BEGIN, CR00386315, SG
  /**
   * Returns initial details to populate case search criteria.
   *
   * @return Case search criteria details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public InitialCaseSearchCriteria getCaseSearchCriteria()
    throws AppException, InformationalException {

    final InitialCaseSearchCriteria initialCaseSearchCriteria =
      CaseFactory.newInstance().getCaseSearchCriteria();

    final CaseStatusFilterDetailsList caseStatusFilterDetailsList =
      initialCaseSearchCriteria.statusDtlsList;

    final CaseStatusFilterDetailsList newCaseStatusFilterDetailsList =
      new CaseStatusFilterDetailsList();

    for (final CaseStatusFilterDetails caseStatusFilterDetails : caseStatusFilterDetailsList.dtlsList
      .items()) {
      if (!caseStatusFilterDetails.statusCode
        .equals(CASESEARCHSTATUS.CLOSED)) {
        newCaseStatusFilterDetailsList.dtlsList.add(caseStatusFilterDetails);
      }
    }

    initialCaseSearchCriteria.statusDtlsList = newCaseStatusFilterDetailsList;

    return initialCaseSearchCriteria;

  }

  // END, CR00386315

  // BEGIN, CR00429980, VT
  // BEGIN, CR00439815, VT
  /**
   * This method returns the list of tasks that are assigned to user based
   * on the provided task search criteria.
   *
   * @param taskFilterCriteriaDetails
   * Task filter criteria details.
   *
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * List of tasks assigned to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ListUnreservedTasksForUserDetails listUserAssignedTasks(
    final TaskFilterCriteriaDetails taskFilterCriteriaDetails)
    throws AppException, InformationalException {

    final ListUnreservedTasksForUserDetails userassignedTaskDetails =
      new ListUnreservedTasksForUserDetails();
    final SupervisorApplicationPageContextDetails pageContextDetails =
      new SupervisorApplicationPageContextDetails();
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    final TaskFilterCriteriaDetails taskSearchDetails =
      new TaskFilterCriteriaDetails();

    taskSearchDetails.assign(taskFilterCriteriaDetails);
    taskSearchDetails.details.assigneeType = TARGETITEMTYPE.USER;

    userassignedTaskDetails.dtls = MaintainSupervisorUsersFactory
      .newInstance().listUserAssignedTasks(taskSearchDetails.details);

    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = taskFilterCriteriaDetails.details.relatedName;

    pageContextDetails.description =
      SupervisorApplicationPageContextDescriptionFactory.newInstance()
        .readUserNamePageContextDescription(userNameKey).description;

    for (final String warning : informationalManager
      .obtainInformationalAsString()) {

      final InformationalMsgDtls informationalMsgDtls =
        new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warning;

      userassignedTaskDetails.informationalMsgDtls.dtls
        .addRef(informationalMsgDtls);

    }

    return userassignedTaskDetails;
  }

  /**
   * This method returns the saved filter criteria details for UserAssignedTasks
   * page.
   *
   * @param taskFilterCriteriaDetails
   * Task filter criteria details.
   *
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * List of tasks assigned to work queue
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public TaskFilterCriteriaDetails readUserAssignedTasksPageFilterCriteria()
    throws AppException, InformationalException {

    final TaskFilterCriteriaDetails criteriaDetails =
      new TaskFilterCriteriaDetails();

    final TaskFilterCriteriaPageDetails taskFilterCriteriaPageDetails =
      MaintainSupervisorTasksFactory.newInstance()
        .readTaskFilterCriteriaPageDetails();

    // BEGIN, CR00440718, VT
    criteriaDetails.details = new SearchSupervisorTaskUtilities()
      .readTaskFilterCriteriaDetailsForPage(
        taskFilterCriteriaPageDetails.userAssignedTasksPageID);
    // END, CR00440718

    return criteriaDetails;
  }

  // END, CR00429980
  // END, CR00439815

  // BEGIN, CR00441712, VT
  /**
   * This method allows the supervisor to list the tasks assigned to a user, but
   * not currently reserved by the user. The list does not include tasks
   * assigned to work queues that the user is subscribed to. This method also
   * returns the saved filter criteria details for UserAssignedTasks page.
   *
   * @param ListUnreservedTasksForUserKey
   * User name details.
   *
   * @return UserAssignedTaskDetailsAndFilterCriteriaDetails List of tasks
   * assigned to work queue and filter criteria details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  @Override
  public UserAssignedTaskDetailsAndFilterCriteriaDetails
    listUserAssignedTasksAndFilterCriteriaDetails(
      final ListUnreservedTasksForUserKey key)
      throws AppException, InformationalException {

    final UserAssignedTaskDetailsAndFilterCriteriaDetails userAssignedTaskDetailsAndFilterCriteriaDetails =
      new UserAssignedTaskDetailsAndFilterCriteriaDetails();
    final boolean workQueueTaskFilterCriteriaInd =
      Configuration.getBooleanProperty(
        EnvVars.ENV_SUPERVISOR_ENABLE_USER_TASK_SEARCH_FUNCTIONALITY);

    if (!workQueueTaskFilterCriteriaInd) {

      userAssignedTaskDetailsAndFilterCriteriaDetails.dtls =
        listTasksAssignedToUser(key);

    } else {

      userAssignedTaskDetailsAndFilterCriteriaDetails.taskFilterCriteriaDetails =
        readUserAssignedTasksPageFilterCriteria();
    }

    return userAssignedTaskDetailsAndFilterCriteriaDetails;

  }
  // END, CR00441712
}
