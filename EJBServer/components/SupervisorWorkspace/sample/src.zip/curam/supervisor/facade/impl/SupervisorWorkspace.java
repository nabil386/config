/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;


import curam.codetable.APPLICATION_CODE;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.SystemUser;
import curam.core.struct.UserNameKey;
import curam.supervisor.facade.struct.CasesByDateRangeKey;
import curam.supervisor.facade.struct.CasesWithIssuesByDateKey;
import curam.supervisor.facade.struct.CasesWithIssuesDtlsList;
import curam.supervisor.facade.struct.CasesWithIssuesUICDtlsList;
import curam.supervisor.facade.struct.PriorityWeekCasesUICHeatmapDetails;
import curam.supervisor.facade.struct.ReadSupervisorHomePageDetails;
import curam.supervisor.facade.struct.ReassignCasesForUserKey;
import curam.supervisor.facade.struct.UserApplicationCodeDetails;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.fact.SupervisorWorkspaceFactory;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This class provides an entry point for supervisors, from which they can view
 * summary details of the cases and tasks that they manage.
 *
 *
 */
public abstract class SupervisorWorkspace extends curam.supervisor.facade.base.SupervisorWorkspace {

  // _________________________________________________________________________
  /**
   * This method allows supervisor to get the list of the users that the
   * supervisor manages.
   *
   * @return ReadSupervisorHomePageDetails details
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ReadSupervisorHomePageDetails readSupervisorHomePageDetails()
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    // object creation
    final ReadSupervisorHomePageDetails details = new ReadSupervisorHomePageDetails();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorWorkspace workspace = SupervisorWorkspaceFactory.newInstance();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey userNameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // call SL method to read home page details
    final curam.supervisor.sl.struct.ReadSupervisorHomePageDetails pageDetails = workspace.readSupervisorHomePageDetails();

    details.listDetails = pageDetails;

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    final SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    details.pageContextDescription = pageContextDetails;

    return details;
  }

  // _________________________________________________________________________
  /**
   * This method allows supervisor to Reassign the cases with issues
   * to another user.
   *
   * @param key - ReassignCasesForUserKey
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public void reassignCasesWithIssues(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // object creation
    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorWorkspace workspace = SupervisorWorkspaceFactory.newInstance();

    // END CR00107117

    // call SL method to reassign cases with issues
    workspace.reassignCasesWithIssues(key.userKey);
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to get the case details which has
   * issues associated.
   *
   * @param key - CasesByDateRangeKey
   * @return CasesWithIssuesDtlsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public CasesWithIssuesDtlsList listCasesWithIssues(CasesByDateRangeKey key)
    throws AppException, InformationalException {

    // object creation
    final CasesWithIssuesDtlsList detailsList = new CasesWithIssuesDtlsList();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorWorkspace workspace = SupervisorWorkspaceFactory.newInstance();
    // END CR00107117
    final curam.supervisor.sl.struct.CasesByDateRangeKey supervisorIDandDateRangeKey = new curam.supervisor.sl.struct.CasesByDateRangeKey();
    final UserNameKey userNameKey = new UserNameKey();
    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // assign key values and call the SL method to get cases with issues.
    supervisorIDandDateRangeKey.registrationFromDate = key.dateRange.registrationFromDate;
    supervisorIDandDateRangeKey.registrationToDate = key.dateRange.registrationToDate;
    final curam.supervisor.sl.struct.CasesWithIssuesDtlsList issueDetails = workspace.listCasesWithIssues(
      supervisorIDandDateRangeKey);

    detailsList.dtls = issueDetails;

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    final SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    detailsList.pageContextDescription = pageContextDetails;

    return detailsList;
  }

  // _________________________________________________________________________
  /**
   * This method gets details of Heat map XML, priority week details and Choose
   * list.
   *
   * @param key - Date
   * @return PriorityWeekCasesUICHeatmapDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public PriorityWeekCasesUICHeatmapDetails readSupervisorUICWorkSpaceDetails(curam.supervisor.sl.struct.Date key)
    throws AppException, InformationalException {

    // object creation
    final PriorityWeekCasesUICHeatmapDetails priorityWeekCasesUICHeatmapDetails = new PriorityWeekCasesUICHeatmapDetails();
    final curam.supervisor.sl.intf.SupervisorWorkspace supervisorWorkspace = SupervisorWorkspaceFactory.newInstance();

    // Calling the method that returns the Heat map cases details
    priorityWeekCasesUICHeatmapDetails.priorityCasesUICHeatmapDtls = supervisorWorkspace.readSupervisorUICWorkSpaceDetails(
      key);

    return priorityWeekCasesUICHeatmapDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to get the details of specified weeks
   * cases with issues.
   *
   * @param key - CasesWithIssuesByDateKey
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public CasesWithIssuesUICDtlsList listPriorityWeekCasesWithIssues(
    CasesWithIssuesByDateKey key) throws AppException, InformationalException {

    // object creation
    final CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    final curam.supervisor.sl.intf.SupervisorWorkspace supervisorWorkspace = SupervisorWorkspaceFactory.newInstance();

    // BEGIN CR00107117 ,GM
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117

    final UserNameKey userNameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    // Calling the SL method that returns the priority week details
    casesWithIssuesUICDtlsList.casesWithIssuesUICDtlsList = supervisorWorkspace.listPriorityWeekCasesWithIssues(
      key.casesWithIssuesByDateKey);

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    final SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    casesWithIssuesUICDtlsList.pageContextDescription = pageContextDetails;

    return casesWithIssuesUICDtlsList;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to get the Application code details.
   *
   * @return UserApplicationCodeDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public UserApplicationCodeDetails getUserAppCode() throws AppException,
      InformationalException {

    // object creation
    final UserApplicationCodeDetails userApplicationCodeDetails = new UserApplicationCodeDetails();
    curam.supervisor.sl.struct.UserApplicationCodeDetails userAppCodeDetails = new curam.supervisor.sl.struct.UserApplicationCodeDetails();
    final curam.supervisor.sl.intf.SupervisorWorkspace supervisorWorkspace = SupervisorWorkspaceFactory.newInstance();

    // call SL to get the Application Code details
    userAppCodeDetails = supervisorWorkspace.getUserAppCode();
    final String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(APPLICATION_CODE.TABLENAME,
      userAppCodeDetails.appCodeDtls.applicationCode,
      TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    userApplicationCodeDetails.pageName = pageName;

    return userApplicationCodeDetails;
  }

  // _________________________________________________________________________
  /**
   * This method returns Date filter key.
   *
   * @param key - Date
   * @return Date
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public curam.supervisor.facade.struct.Date viewUICfilter(
    curam.supervisor.facade.struct.Date key) throws AppException,
      InformationalException {

    return key;
  }

}
