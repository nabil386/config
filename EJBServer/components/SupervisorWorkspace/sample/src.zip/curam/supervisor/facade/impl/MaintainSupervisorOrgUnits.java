/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright (c) 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.supervisor.facade.impl;


import curam.codetable.ORGUNITTASKOPTIONPAGE;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.OrgStructureAndOrgUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.supervisor.fact.OrganizationUnitWorkspaceFactory;
import curam.core.sl.supervisor.intf.OrganizationUnitWorkspace;
import curam.core.sl.supervisor.struct.OrgUnitReservedTasksByUserDueOnDateDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksDueByWeekDetailsList;
import curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateDetailsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserNameKey;
import curam.message.BPOSUPERVISORORGUNITS;
import curam.supervisor.facade.struct.ListDeferredTasksReservedByOrgUnitUserDetails;
import curam.supervisor.facade.struct.ListOpenTasksReservedByOrgUnitUserDetails;
import curam.supervisor.facade.struct.ListOrgUnitTasksDueByWeekDetails;
import curam.supervisor.facade.struct.ListOrgUnitTasksDueOnDateDetails;
import curam.supervisor.facade.struct.OrgUnitAssignedTasksByUserDueOnDateDetails;
import curam.supervisor.facade.struct.OrgUnitAssignedTasksDetails;
import curam.supervisor.facade.struct.OrgUnitAssignedTasksDetailsList;
import curam.supervisor.facade.struct.OrgUnitAssignedTasksKey;
import curam.supervisor.facade.struct.OrgUnitIDStructIDAndTaskOptionKey;
import curam.supervisor.facade.struct.OrgUnitReservedTasksByUserDueOnDateDetails;
import curam.supervisor.facade.struct.OrgUnitReservedTasksByUserDueOnDateKey;
import curam.supervisor.facade.struct.OrgUnitReservedTasksDetails;
import curam.supervisor.facade.struct.OrgUnitTasksByUserDueOnDateDetails;
import curam.supervisor.facade.struct.OrgUnitTasksByUserDueOnDateKey;
import curam.supervisor.facade.struct.OrgUnitTasksByUserSearchKey;
import curam.supervisor.facade.struct.OrgUnitTasksDueOnDateKey;
import curam.supervisor.facade.struct.OrgUnitTasksKey;
import curam.supervisor.facade.struct.OrgUnitTasksReservedByUserDetails;
import curam.supervisor.facade.struct.OrgUnitWorkspaceDetails;
import curam.supervisor.facade.struct.OrganizationUnitKey;
import curam.supervisor.facade.struct.OrganizationUnitScheduleDetails;
import curam.supervisor.facade.struct.OrganizationUnitUsersScheduleDetailsList;
import curam.supervisor.facade.struct.ReserveOrgUnitTasksToUserKey;
import curam.supervisor.facade.struct.ResolveOrgUnitPages;
import curam.supervisor.facade.struct.ResolveOrgUnitReservedTasksKey;
import curam.supervisor.facade.struct.ResolveOrgUnitTaskOptionKey;
import curam.supervisor.facade.struct.ResolveOrgUnitTaskOptionPageKey;
import curam.supervisor.facade.struct.SupervisorOrganisationUnitDetails;
import curam.supervisor.facade.struct.SupervisorUsersDetailsList;
import curam.supervisor.facade.struct.UserNameOrgUnitIDKey;
import curam.supervisor.sl.fact.MaintainSupervisorOrgUnitsFactory;
import curam.supervisor.sl.fact.MaintainSupervisorUsersFactory;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.impl.SupervisorConst;
import curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription;
import curam.supervisor.sl.struct.OrgUnitStructureIDAndStartDateKey;
import curam.supervisor.sl.struct.OrgUnitTasksDueInTheNextMonthKey;
import curam.supervisor.sl.struct.OrgUnitTasksDueInTheNextWeekKey;
import curam.supervisor.sl.struct.OrganisationUnitTabDetails;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.supervisor.sl.struct.SupervisorUserDetails;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;


/**
 * Facade Layer implementation for Supervisor Organization Units.
 */

public abstract class MaintainSupervisorOrgUnits extends curam.supervisor.facade.base.MaintainSupervisorOrgUnits {

  /**
   * This method lists the deferred tasks reserved by a member of the
   * organization unit, due on a particular date.
   *
   * @param key -OrgUnitReservedTasksByUserDueOnDateKey
   * @return OrgUnitReservedTasksByUserDueOnDateDetails
   * @throws AppException,InformationalException
   */
  @Override
  public OrgUnitReservedTasksByUserDueOnDateDetails listDeferredOrgUnitReservedTasksByUserDueOnDate(
    OrgUnitReservedTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrgUnitReservedTasksByUserDueOnDateDetails orgUnitReservedTasksByUserDueOnDateDetails = new OrgUnitReservedTasksByUserDueOnDateDetails();
    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();
    OrgUnitReservedTasksByUserDueOnDateDetailsList orgUnitReservedTasksByUserDueOnDateDetailsList = new OrgUnitReservedTasksByUserDueOnDateDetailsList();
    final OrgUnitReservedTasksByUserDueOnDateKey orgUnitReservedTasksByUserDueOnDateKey = new OrgUnitReservedTasksByUserDueOnDateKey();

    // Assign values to key
    orgUnitReservedTasksByUserDueOnDateKey.key = key.key;
    orgUnitReservedTasksByUserDueOnDateKey.orgUnitID = key.orgUnitID;

    // calling the entity layer method.
    orgUnitReservedTasksByUserDueOnDateDetailsList = organizationUnitWorkspace.getDeferredOrgUnitReservedTasksByUserDueOnDate(
      orgUnitReservedTasksByUserDueOnDateKey.key);
    orgUnitReservedTasksByUserDueOnDateDetails.dueOnDateDtls = orgUnitReservedTasksByUserDueOnDateDetailsList;

    // To get page context
    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitReservedTasksByUserDueOnDateKey.orgUnitID;
    orgUnitReservedTasksByUserDueOnDateDetails.pageContext.description = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitReservedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method lists the open tasks reserved by a member of the
   * organization unit, due on a particular date.
   *
   * @param key -OrgUnitReservedTasksByUserDueOnDateKey
   * @return OrgUnitReservedTasksByUserDueOnDateDetails
   * @throws AppException,InformationalException
   */
  @Override
  public OrgUnitReservedTasksByUserDueOnDateDetails listOpenOrgUnitReservedTasksByUserDueOnDate(
    OrgUnitReservedTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // Create Organization Unit objects
    final OrgUnitReservedTasksByUserDueOnDateDetails orgUnitReservedTasksByUserDueOnDateDetails = new OrgUnitReservedTasksByUserDueOnDateDetails();
    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();
    OrgUnitReservedTasksByUserDueOnDateDetailsList orgUnitReservedTasksByUserDueOnDateDetailsList = new OrgUnitReservedTasksByUserDueOnDateDetailsList();
    final OrgUnitReservedTasksByUserDueOnDateKey orgUnitReservedTasksByUserDueOnDateKey = new OrgUnitReservedTasksByUserDueOnDateKey();

    // Assign key values
    orgUnitReservedTasksByUserDueOnDateKey.key = key.key;
    orgUnitReservedTasksByUserDueOnDateKey.orgUnitID = key.orgUnitID;

    // calling the entity layer method.
    orgUnitReservedTasksByUserDueOnDateDetailsList = organizationUnitWorkspace.getOpenOrgUnitReservedTasksByUserDueOnDate(
      orgUnitReservedTasksByUserDueOnDateKey.key);
    orgUnitReservedTasksByUserDueOnDateDetails.dueOnDateDtls = orgUnitReservedTasksByUserDueOnDateDetailsList;

    // To get page context
    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitReservedTasksByUserDueOnDateKey.orgUnitID;
    orgUnitReservedTasksByUserDueOnDateDetails.pageContext.description = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitReservedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the page name based on
   * selected task option.
   *
   * @param key - ResolveOrgUnitTaskOptionPageKey
   * @return ResolveOrgUnitPages
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveOrgUnitPages resolveOrgUnitTasksDueOnDateOrWeekPage(
    ResolveOrgUnitTaskOptionPageKey key) throws AppException,
      InformationalException {

    final ResolveOrgUnitPages resolveOrgUnitPages = new ResolveOrgUnitPages();
    final String taskOptionCode = key.taskOptionCode;
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
      ORGUNITTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {

      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEONDATE_RESERVEDBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEONDATE_ASSIGNEDTO,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEBYWEEK_RESERVEDBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEBYWEEK_ASSIGNEDTO,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }
    resolveOrgUnitPages.pageName = pageName;
    return resolveOrgUnitPages;
  }

  // ___________________________________________________________________________
  /**
   * This listOrgUnitTasksDueOnDateAssignedTo lists the tasks due on date
   * Assigned To a user.
   *
   * @param key -
   * OrgUnitTasksDueOnDateKey,
   *
   * @return ListOrgUnitTasksDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDateAssignedTo(OrgUnitTasksDueOnDateKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    OrgUnitTasksDueOnDateDetailsList orgUnitTasksDueOnDateDetailsList = new OrgUnitTasksDueOnDateDetailsList();

    final ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDateDetails = new ListOrgUnitTasksDueOnDateDetails();

    // Call to the Entity layer to fetch the records.
    final curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey orgUnitTasksDueOnDateKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey();

    // Assign key values
    orgUnitTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    orgUnitTasksDueOnDateKey.userName = key.key.userName;
    if (key.key.taskReservationStatus.equals(SupervisorConst.kCaptionAssigned)) {
      orgUnitTasksDueOnDateKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;
    } else {
      orgUnitTasksDueOnDateKey.taskReservationStatus = key.key.taskReservationStatus;
    }

    orgUnitTasksDueOnDateDetailsList = organisationUnit.getOrgUnitTasksByUserDueOnDate(
      orgUnitTasksDueOnDateKey);
    listOrgUnitTasksDueOnDateDetails.taskDetailsList = orgUnitTasksDueOnDateDetailsList;

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;
    listOrgUnitTasksDueOnDateDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return listOrgUnitTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This listOrgUnitTasksDueOnDateReservedBy lists the tasks due on date
   * Reserved By a user.
   *
   * @param key -
   * OrgUnitTasksDueOnDateKey,
   *
   * @return ListOrgUnitTasksDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDateReservedBy(OrgUnitTasksDueOnDateKey key)
    throws AppException, InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    OrgUnitTasksDueOnDateDetailsList orgUnitTasksDueOnDateDetailsList = new OrgUnitTasksDueOnDateDetailsList();
    final ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDateDetails = new ListOrgUnitTasksDueOnDateDetails();

    // Call to the Entity layer to fetch the records.
    final curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey orgUnitTasksDueOnDateKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey();

    // Assign key values
    orgUnitTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    orgUnitTasksDueOnDateKey.userName = key.key.userName;

    if (key.key.taskReservationStatus.equals(SupervisorConst.kCaptionAssigned)) {
      orgUnitTasksDueOnDateKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;
    } else {
      orgUnitTasksDueOnDateKey.taskReservationStatus = key.key.taskReservationStatus;
    }

    orgUnitTasksDueOnDateDetailsList = organisationUnit.getOrgUnitTasksByUserDueOnDate(
      orgUnitTasksDueOnDateKey);
    listOrgUnitTasksDueOnDateDetails.taskDetailsList = orgUnitTasksDueOnDateDetailsList;

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;
    listOrgUnitTasksDueOnDateDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return listOrgUnitTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This readOrgUnitAssignedTasksByUserDueOnDate helps the supervisor manage
   * assigned tasks due on the specified date.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitAssignedTasksByUserDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasksByUserDueOnDate(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // Create objects to call SL method
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    // Assign values to key
    orgUnitTasksByUserDueOnDateKey.key.key = key.key.key;

    // Calling SL method
    orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails = maintainSupervisorOrgUnits.readOrgUnitAssignedTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitTasksByUserDueOnDateKey.key.key.organizationUnitID;
    orgUnitAssignedTasksByUserDueOnDateDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;
    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This readOrgUnitReservedTasksByUserDueOnDate is used to construct bar
   * chart for Reserved Tasks due on date from the details list.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey,
   *
   * @return OrgUnitTasksReservedByUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitTasksReservedByUserDetails readOrgUnitReservedTasksByUserDueOnDate(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // Create objects to call SL method
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();
    final OrgUnitTasksReservedByUserDetails orgUnitTasksReservedByUserDetails = new OrgUnitTasksReservedByUserDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;
    orgUnitTasksReservedByUserDetails.dtls = maintainSupervisorOrgUnits.readOrgUnitReservedTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitTasksByUserDueOnDateKey.key.key.organizationUnitID;

    orgUnitTasksReservedByUserDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitTasksReservedByUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This readOrgUnitTasksByUserDueOnDate is used to construct bar chart for
   * Tasks due on date from the details list.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey,
   *
   * @return OrgUnitTasksByUserDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public OrgUnitTasksByUserDueOnDateDetails readOrgUnitTasksByUserDueOnDate(
    OrgUnitTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // Create objects to call SL method
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();
    final OrgUnitTasksByUserDueOnDateDetails orgUnitTasksByUserDueOnDateDetails = new OrgUnitTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;
    orgUnitTasksByUserDueOnDateDetails.dtls = maintainSupervisorOrgUnits.readOrgUnitTasksByUserDueOnDate(
      orgUnitTasksByUserDueOnDateKey.key);

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitTasksByUserDueOnDateKey.key.key.organizationUnitID;
    orgUnitTasksByUserDueOnDateDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to retrieve the list of organization
   * units where the supervisor holds the lead position.
   *
   * @return SupervisorOrganisationUnitDetails object.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SupervisorOrganisationUnitDetails listSupervisorOrgUnits()
    throws AppException, InformationalException {

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final LocalisableString localisableString = new LocalisableString(
      BPOSUPERVISORORGUNITS.ERR_NO_ORGUNIT_LEAD_POSITION);

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      localisableString, GeneralConstants.kEmpty,
      InformationalElement.InformationalType.kError,
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    // register the security implementation
    SecurityImplementationFactory.register();

    // return object
    final SupervisorOrganisationUnitDetails organisationUnitDetails = new SupervisorOrganisationUnitDetails();

    // MaintainSupervisorOrgUnits object
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits supervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    final curam.supervisor.sl.struct.SupervisorOrganisationUnitDetails orgUnitDetails = supervisorOrgUnits.listSupervisorOrgUnits();

    if (orgUnitDetails.orgUnitDetails.dtls.size() == 0) {
      final String[] matchedResults = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < matchedResults.length; i++) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = matchedResults[i];
        organisationUnitDetails.infoMsg.dtls.addRef(informationalMsgDtls);
      }
    } else {
      // assign the list of org units to the return object
      organisationUnitDetails.unitDetails = orgUnitDetails;
    }

    // PageContextDescription object
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey nameKey = new UserNameKey();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    nameKey.userName = systemUser.getUserDetails().userName;

    final SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      nameKey);

    // Set the return value of the pageContextDescription to the return
    // object
    organisationUnitDetails.contextDescription = pageContextDetails;

    return organisationUnitDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks that have been
   * reserved, and then deferred by members of the organization unit. *
   *
   * @param key -
   * UserNameOrgUnitIDKey
   * @return the ListDeferredTasksReservedByOrgUnitUserDetails object.
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListDeferredTasksReservedByOrgUnitUserDetails listDeferredTasksReservedByOrgUnitUser(UserNameOrgUnitIDKey key)
    throws AppException, InformationalException {

    // Create MaintainSupervisorOrgUnits object
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    final ListDeferredTasksReservedByOrgUnitUserDetails listDeferredTasksReservedByOrgUnitUserDetails = new ListDeferredTasksReservedByOrgUnitUserDetails();

    listDeferredTasksReservedByOrgUnitUserDetails.deferredTaskDetails = maintainSupervisorOrgUnits.listDeferredTasksReservedByOrgUnitUser(
      key.key);

    return listDeferredTasksReservedByOrgUnitUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks reserved by members
   * of the organization unit, which are open.
   *
   * @param key -
   * UserNameOrgUnitIDKey
   * @return the ListOpenTasksReservedByOrgUnitUserDetails object.
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListOpenTasksReservedByOrgUnitUserDetails listOpenTasksReservedByOrgUnitUser(UserNameOrgUnitIDKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    final ListOpenTasksReservedByOrgUnitUserDetails listOpenTasksReservedByOrgUnitUserDetails = new ListOpenTasksReservedByOrgUnitUserDetails();

    listOpenTasksReservedByOrgUnitUserDetails.details = maintainSupervisorOrgUnits.listOpenTasksReservedByOrgUnitUser(
      key.key);

    return listOpenTasksReservedByOrgUnitUserDetails;

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to view the list of organization unit
   * tasks for a specified week.
   *
   * @param key -
   * OrgUnitTasksDueOnDateKey
   * @return ListOrgUnitTasksDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListOrgUnitTasksDueByWeekDetails listOrgUnitTasksByWeek(
    OrgUnitTasksDueOnDateKey key) throws AppException, InformationalException {

    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();

    final ListOrgUnitTasksDueByWeekDetails details = new ListOrgUnitTasksDueByWeekDetails();

    final curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey orgUnitTasksDueOnDateKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey();

    // Assign key values
    orgUnitTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    orgUnitTasksDueOnDateKey.userName = key.key.userName;

    if (key.key.taskReservationStatus.equals(SupervisorConst.kCaptionAssigned)) {
      orgUnitTasksDueOnDateKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;
    }

    final OrgUnitTasksDueByWeekDetailsList detailsList = organizationUnitWorkspace.getOrgUnitTasksByUserDueByWeek(
      orgUnitTasksDueOnDateKey);

    details.tasksByWeekList = detailsList;

    return details;

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks assigned to members
   * of the organization unit, that have not yet been reserved.
   *
   * @param key -
   * OrgUnitTasksKey
   * @return OrgUnitAssignedTasksDetailsList
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public OrgUnitAssignedTasksDetailsList listOrgUnitAssignedTasks(
    OrgUnitTasksKey key) throws AppException, InformationalException {

    // Create OrgUnitAssignedTasksDetailsList object
    final OrgUnitAssignedTasksDetailsList orgUnitAssignedTasksDetailsList = new OrgUnitAssignedTasksDetailsList();

    // Create OrganizationUnitWorkspace object
    final OrganizationUnitWorkspace organizationUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();

    // Create OrgUnitTasksDetailsList to populate the details list
    OrgUnitTasksDetailsList orgUnitTasksDetailsList = new OrgUnitTasksDetailsList();

    final curam.core.sl.supervisor.struct.OrgUnitTasksKey orgUnitTasksKey = new curam.core.sl.supervisor.struct.OrgUnitTasksKey();

    final SupervisorApplicationPageContextDetails pageContextDetails = new SupervisorApplicationPageContextDetails();

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // Assign key values
    orgUnitTasksKey.organizationStructureID = key.key.organizationStructureID;
    orgUnitTasksKey.organizationUnitID = key.key.organizationUnitID;
    orgUnitTasksKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;

    orgUnitTasksDetailsList = organizationUnitWorkspace.getOrgUnitTasks(
      orgUnitTasksKey);

    orgUnitAssignedTasksDetailsList.detailsList = orgUnitTasksDetailsList;

    // To pass organisationUnitID
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // assign key values
    organisationUnitKey.organisationUnitID = key.key.organizationUnitID;

    pageContextDetails.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    orgUnitAssignedTasksDetailsList.pageContext = pageContextDetails;

    return orgUnitAssignedTasksDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the organization unit task
   * records due on the specified date.
   *
   * @param key -
   * OrgUnitTasksDueOnDateKey
   * @return ListOrgUnitTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDate(
    OrgUnitTasksDueOnDateKey key) throws AppException, InformationalException {

    // Create ListOrgUnitTasksDueOnDateDetails object
    final ListOrgUnitTasksDueOnDateDetails listOrgUnitTasksDueOnDateDetails = new ListOrgUnitTasksDueOnDateDetails();

    // Create OrganizationUnitWorkspace object to get the list of org unit
    // tasks
    final OrganizationUnitWorkspace orgUnitWorkspace = OrganizationUnitWorkspaceFactory.newInstance();

    final curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey orgUnitTasksDueOnDateKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey();

    // Assign key values
    orgUnitTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    orgUnitTasksDueOnDateKey.userName = key.key.userName;

    if (key.key.taskReservationStatus.equals(SupervisorConst.kCaptionAssigned)) {
      orgUnitTasksDueOnDateKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;
    } else {
      orgUnitTasksDueOnDateKey.taskReservationStatus = key.key.taskReservationStatus;
    }

    listOrgUnitTasksDueOnDateDetails.taskDetailsList = orgUnitWorkspace.getOrgUnitTasksByUserDueOnDate(
      orgUnitTasksDueOnDateKey);

    return listOrgUnitTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to read the Organization units
   * workspace
   * details.
   *
   * @param key -
   * OrgUnitIDStructIDAndTaskOptionKey
   * @return OrgUnitWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public OrgUnitWorkspaceDetails readOrgUnitWorkspaceDetails(
    OrgUnitIDStructIDAndTaskOptionKey key) throws AppException,
      InformationalException {

    final OrgUnitWorkspaceDetails orgUnitWorkspaceDetails = new OrgUnitWorkspaceDetails();
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnitsObj = MaintainSupervisorOrgUnitsFactory.newInstance();

    curam.supervisor.sl.struct.OrgUnitWorkspaceDetails orgUnitWorkspaceDetailsobj = new curam.supervisor.sl.struct.OrgUnitWorkspaceDetails();

    if (key.taskOption.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      final OrgUnitTasksDueInTheNextWeekKey orgUnitTasksDueInTheNextWeekKey = new OrgUnitTasksDueInTheNextWeekKey();

      orgUnitTasksDueInTheNextWeekKey.nextWeekKey.organizationUnitID = key.orgUnitID;
      orgUnitTasksDueInTheNextWeekKey.nextWeekKey.organizationStructureID = key.orgStructureID;
      orgUnitWorkspaceDetailsobj = maintainSupervisorOrgUnitsObj.readOrgUnitWorkspaceWeekDetails(
        orgUnitTasksDueInTheNextWeekKey);
      orgUnitWorkspaceDetails.workspaceDetails = orgUnitWorkspaceDetails.workspaceDetails.assign(
        orgUnitWorkspaceDetailsobj);
    }

    if (key.taskOption.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      final OrgUnitTasksDueInTheNextMonthKey orgUnitTasksDueInTheNextMonthKey = new OrgUnitTasksDueInTheNextMonthKey();

      orgUnitTasksDueInTheNextMonthKey.key.organizationUnitID = key.orgUnitID;
      orgUnitTasksDueInTheNextMonthKey.key.organizationStructureID = key.orgStructureID;
      orgUnitWorkspaceDetailsobj = maintainSupervisorOrgUnitsObj.readOrgUnitWorkspaceMonthDetails(
        orgUnitTasksDueInTheNextMonthKey);
      orgUnitWorkspaceDetails.workspaceDetails = orgUnitWorkspaceDetails.workspaceDetails.assign(
        orgUnitWorkspaceDetailsobj);
    }

    // BEGIN, CR00052924, GM
    if (key.taskOption.equalsIgnoreCase(CuramConst.gkEmpty)) {
      // END, CR00052924
      orgUnitWorkspaceDetails.taskOption = VIEWTASKSOPTION.DEFAULTCODE;
    } else {
      orgUnitWorkspaceDetails.taskOption = key.taskOption;
    }

    return orgUnitWorkspaceDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reserve Organization unit tasks to
   * the selected user.
   *
   * @param key -
   * ReserveOrgUnitTasksToUserKey
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void reserveOrgUnitTasksToUser(ReserveOrgUnitTasksToUserKey key)
    throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    maintainSupervisorOrgUnits.reserveOrgUnitTasksToUser(key.key);
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the page name based on
   * selected task option.
   *
   * @param key -
   * ResolveOrgUnitTaskOptionPageKey
   * @return ResolveOrgUnitPages
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ResolveOrgUnitPages resolveOrgUnitTaskOptionPage(
    ResolveOrgUnitTaskOptionPageKey key) throws AppException,
      InformationalException {

    final ResolveOrgUnitPages resolveOrgUnitPages = new ResolveOrgUnitPages();

    final String taskOptionCode = key.taskOptionCode;

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
      ORGUNITTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {

      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEBYWEEK_RESERVED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEBYWEEK_ASSIGNED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEBYWEEK_ALL,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEONDATE_RESERVED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEONDATE_ASSIGNED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.DUEONDATE_ALL,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }

    // Task Status should be Open
    if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASK_OPEN,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
      // Tasks Status Should be deferred
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASK_DEFERRED,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveOrgUnitPages.pageName = pageName;
    return resolveOrgUnitPages;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch list of the tasks reserved to
   * members of the organization unit.
   *
   * @param key -
   * OrgUnitTasksKey
   * @return the OrgUnitReservedTasksDetails object.
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitReservedTasksDetails readOrgUnitReservedTasksDetails(
    OrgUnitTasksKey key) throws AppException, InformationalException {

    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    final OrgUnitReservedTasksDetails orgUnitReservedTasksDetails = new OrgUnitReservedTasksDetails();

    final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

    OrganisationUnitName organisationUnitName = new OrganisationUnitName();

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    orgUnitReservedTasksDetails.details = maintainSupervisorOrgUnits.readOrgUnitReservedTasksDetails(
      key.key);

    // assign key values
    organisationUnitKey.organisationUnitID = key.key.organizationUnitID;
    organisationUnitName = organisationUnitObj.readOrgUnitName(
      organisationUnitKey);

    orgUnitReservedTasksDetails.pageContext.description = organisationUnitName.name;

    return orgUnitReservedTasksDetails;

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to retrieve the list of reporting
   * users.
   * Lists user who is actively holding a position within the organization.
   * This list does not include any user who holds a position in an
   * organization unit that is contained within this organization unit.
   *
   * @return the SupervisorUsersDetailsList object.
   * @throws AppException
   * @throws InformationalException
   */
  public SupervisorUsersDetailsList listSupervisorUsers()
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final SupervisorUsersDetailsList details = new SupervisorUsersDetailsList();

    final curam.supervisor.sl.intf.MaintainSupervisorUsers workspace = MaintainSupervisorUsersFactory.newInstance();

    final SupervisorUserDetails userDetails = new SupervisorUserDetails();

    userDetails.userDetails.assign(workspace.listSupervisorUsersWithTaskCount());

    details.dtls = userDetails;

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();

    final SystemUser systemUser = SystemUserFactory.newInstance();

    userNameKey.userName = systemUser.getUserDetails().userName;

    final SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    details.pageContextDescription = pageContextDetails;

    return details;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch page for Open and Deferred
   * pages from Organization Unit Reserved tasks.
   *
   * @param key -
   * ResolveOrgUnitReservedTasksKey - Task Status
   * @return ResolveOrgUnitPages
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveOrgUnitPages resolveOrgUnitReservedTasksPage(
    ResolveOrgUnitReservedTasksKey key) throws AppException,
      InformationalException {

    final ResolveOrgUnitPages resolveOrgUnitPages = new ResolveOrgUnitPages();

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
      ORGUNITTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    // Task Status should be Open
    if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {

      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASK_OPEN,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
      // Tasks Status Should be deferred
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASK_DEFERRED,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveOrgUnitPages.pageName = pageName;

    return resolveOrgUnitPages;

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the Organization Unit Schedule
   * Details.
   *
   * @param key -
   * OrganizationUnitKey
   * @return OrganizationUnitScheduleDetails
   * @throws AppException,
   * InformationalException
   * @throws InformationalException
   */
  @Override
  public OrganizationUnitScheduleDetails readOrganizationUnitScheduleDetails(
    OrganizationUnitKey key) throws AppException, InformationalException {

    final OrganizationUnitScheduleDetails organizationUnitScheduleDetails = new OrganizationUnitScheduleDetails();

    // create OrganisationUnit object to retrieve the organization unit name

    final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

    // Create key object
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // assign key value
    organisationUnitKey.organisationUnitID = key.orgUnitID;

    organizationUnitScheduleDetails.orgUnitName.name = organisationUnitObj.readOrgUnitName(organisationUnitKey).name;

    return organizationUnitScheduleDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the all the Users belonging to
   * an Organization Unit and Activity Schedule Details.
   *
   *
   * @param arg0 -
   * OrgUnitStructureIDAndStartDateKey
   * @return OrganizationUnitUsersScheduleDetailsList
   * @throws AppException,
   * InformationalException
   * @throws InformationalException
   */

  @Override
  public OrganizationUnitUsersScheduleDetailsList readOrgUnitUsersScheduleDetails(OrgUnitStructureIDAndStartDateKey arg0)
    throws AppException, InformationalException {

    final OrganizationUnitUsersScheduleDetailsList organizationUnitUsersScheduleDetailsList = new OrganizationUnitUsersScheduleDetailsList();

    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    organizationUnitUsersScheduleDetailsList.scheduleDetailsList = maintainSupervisorOrgUnits.readOrgUnitUsersScheduleDetails(
      arg0);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve page context details
    organisationUnitKey.organisationUnitID = arg0.organisationID;
    organizationUnitUsersScheduleDetailsList.contextDescription = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return organizationUnitUsersScheduleDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to resolve the page that will be opened
   * after clicking on the Reserved Tasks bar chart.
   *
   * @param key -
   * ResolveOrgUnitReservedTasksKey
   * @return ResolveOrgUnitPages
   * @throws AppException,
   * InformationalException
   * @throws InformationalException
   */
  @Override
  public ResolveOrgUnitPages resolveOrgUnitReservedTasksDueOnDateOrWeekPage(
    ResolveOrgUnitReservedTasksKey key) throws AppException,
      InformationalException {

    final ResolveOrgUnitPages resolveOrgUnitPages = new ResolveOrgUnitPages();

    final String taskOptionCode = key.taskOptionCode;

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
      ORGUNITTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {

      if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
        // Task Status should be Open
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.ORGUNITTASK_OPENRESBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
        // Tasks Status Should be deferred
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.ORGUNITTASK_DEFERREDRESBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
        // Task Status should be Open
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.ORGUNITTASKBYWEEK_OPENRESBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
        // Tasks Status Should be deferred
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
          ORGUNITTASKOPTIONPAGE.ORGUNITTASKBYWEEK_DEFERREDRESBY,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }

    resolveOrgUnitPages.pageName = pageName;
    return resolveOrgUnitPages;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Deferred Reserved Tasks By
   * Week.
   *
   * @param key -
   * OrgUnitReservedTasksByUserDueOnDateKey
   * @return OrgUnitReservedTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitReservedTasksByUserDueOnDateDetails listDeferredOrgUnitReservedTasksByUserDueByWeek(
    OrgUnitReservedTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitReservedTasksByUserDueOnDateDetails orgUnitReservedTasksByUserDueOnDateDetails = new OrgUnitReservedTasksByUserDueOnDateDetails();
    final OrgUnitReservedTasksByUserDueOnDateKey orgUnitReservedTasksByUserDueOnDateKey = new OrgUnitReservedTasksByUserDueOnDateKey();

    orgUnitReservedTasksByUserDueOnDateKey.key = key.key;

    // Call to Entity method
    orgUnitReservedTasksByUserDueOnDateDetails.dueOnDateDtls = organisationUnit.getDeferredOrgUnitReservedTasksByUserDueByWeek(
      orgUnitReservedTasksByUserDueOnDateKey.key);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve Org Unit name from page context details
    organisationUnitKey.organisationUnitID = key.orgUnitID;
    orgUnitReservedTasksByUserDueOnDateDetails.pageContext = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return orgUnitReservedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Open Reserved Tasks By
   * Week.
   *
   * @param key -
   * OrgUnitReservedTasksByUserDueOnDateKey
   * @return OrgUnitReservedTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitReservedTasksByUserDueOnDateDetails listOpenOrgUnitReservedTasksByUserDueByWeek(
    OrgUnitReservedTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // OrganisationUnit objects to fetch the data
    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();
    final OrgUnitReservedTasksByUserDueOnDateDetails orgUnitReservedTasksByUserDueOnDateDetails = new OrgUnitReservedTasksByUserDueOnDateDetails();
    final OrgUnitReservedTasksByUserDueOnDateKey orgUnitReservedTasksByUserDueOnDateKey = new OrgUnitReservedTasksByUserDueOnDateKey();

    orgUnitReservedTasksByUserDueOnDateKey.key = key.key;

    // Call to Entity method
    orgUnitReservedTasksByUserDueOnDateDetails.dueOnDateDtls = organisationUnit.getOpenOrgUnitReservedTasksByUserDueByWeek(
      orgUnitReservedTasksByUserDueOnDateKey.key);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve Org Unit name from page context details
    organisationUnitKey.organisationUnitID = key.orgUnitID;
    orgUnitReservedTasksByUserDueOnDateDetails.pageContext = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return orgUnitReservedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Assigned Tasks By Week.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitAssignedTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasksByUserDueByWeek(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // Creating objects to call SL method
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    // Calling SL method
    orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails = maintainSupervisorOrgUnits.readOrgUnitAssignedTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve page context details
    organisationUnitKey.organisationUnitID = key.key.key.organizationUnitID;
    orgUnitAssignedTasksByUserDueOnDateDetails.pageContext = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the Reserved Tasks By Week.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitTasksReservedByUserDetails readOrgUnitReservedTasksByUserDueByWeek(OrgUnitTasksByUserDueOnDateKey key)
    throws AppException, InformationalException {

    // Creating objects to call SL method
    final OrgUnitTasksReservedByUserDetails orgUnitTasksReservedByUserDetails = new OrgUnitTasksReservedByUserDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();

    orgUnitTasksByUserDueOnDateKey.key = key.key;
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    // Calling SL method
    orgUnitTasksReservedByUserDetails.dtls = maintainSupervisorOrgUnits.readOrgUnitReservedTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve page context details
    organisationUnitKey.organisationUnitID = key.key.key.organizationUnitID;
    orgUnitTasksReservedByUserDetails.pageContext = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return orgUnitTasksReservedByUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list all the Assigned Tasks for a
   * User.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitAssignedTasksDetails listOrgUnitAssignedTasksToUser(
    OrgUnitAssignedTasksKey key) throws AppException, InformationalException {

    // Creating objects to call SL method
    final OrgUnitAssignedTasksDetails orgUnitAssignedTasksDetails = new OrgUnitAssignedTasksDetails();
    final OrgUnitAssignedTasksKey orgUnitAssignedTasksKey = new OrgUnitAssignedTasksKey();

    orgUnitAssignedTasksKey.key = key.key;
    final curam.core.sl.intf.Inbox inbox = InboxFactory.newInstance();

    // Calling Entity layer method
    orgUnitAssignedTasksDetails.taskDetails = inbox.listAssigned(
      orgUnitAssignedTasksKey.key);

    // To get page context
    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;

    orgUnitAssignedTasksDetails.pageContext.description = pageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitAssignedTasksDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch all the Assigned Tasks.
   *
   * @param key -
   * OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksReservedByUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitAssignedTasksByUserDueOnDateDetails readOrgUnitAssignedTasks(
    OrgUnitTasksByUserSearchKey key) throws AppException,
      InformationalException {

    // Creating objects to call SL method
    final OrgUnitAssignedTasksByUserDueOnDateDetails orgUnitAssignedTasksByUserDueOnDateDetails = new OrgUnitAssignedTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserSearchKey orgUnitTasksByUserSearchKey = new OrgUnitTasksByUserSearchKey();

    orgUnitTasksByUserSearchKey.key = key.key;
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    // Calling SL method
    orgUnitAssignedTasksByUserDueOnDateDetails.taskDetails = maintainSupervisorOrgUnits.readOrgUnitAssignedTasks(
      orgUnitTasksByUserSearchKey.key);

    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // To retrieve page context details
    organisationUnitKey.organisationUnitID = key.key.key.organizationUnitID;
    orgUnitAssignedTasksByUserDueOnDateDetails.pageContext = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(
      organisationUnitKey);

    return orgUnitAssignedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * The method listOrgUnitTasksDueByWeek helps the supervisor manages the
   * task due in a specified week by displaying the assigned and reserved
   * task details separately.
   *
   * @param key -
   * OrgUnitTasksDueOnDateKey
   * @return ListOrgUnitTasksDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ListOrgUnitTasksDueByWeekDetails listOrgUnitTasksDueByWeek(
    OrgUnitTasksDueOnDateKey key) throws AppException, InformationalException {

    final ListOrgUnitTasksDueByWeekDetails listOrgUnitTasksDueByWeekDetails = new ListOrgUnitTasksDueByWeekDetails();

    final OrganizationUnitWorkspace organisationUnit = OrganizationUnitWorkspaceFactory.newInstance();

    final curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey orgUnitTasksDueOnDateKey = new curam.core.sl.supervisor.struct.OrgUnitTasksDueOnDateKey();

    // Assign key values
    orgUnitTasksDueOnDateKey.deadlineDate = key.key.deadlineDate;
    orgUnitTasksDueOnDateKey.userName = key.key.userName;

    if (key.key.taskReservationStatus.equals(SupervisorConst.kCaptionAssigned)) {
      orgUnitTasksDueOnDateKey.taskReservationStatus = TASKRESERVEDSEARCHSTATUS.UNRESERVED;
    } else {
      orgUnitTasksDueOnDateKey.taskReservationStatus = key.key.taskReservationStatus;
    }

    // calling the entity layer method
    listOrgUnitTasksDueByWeekDetails.tasksByWeekList = organisationUnit.getOrgUnitTasksByUserDueByWeek(
      orgUnitTasksDueOnDateKey);

    // To get page context
    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = key.orgUnitID;
    listOrgUnitTasksDueByWeekDetails.pageContext.description = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return listOrgUnitTasksDueByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * The method readOrgUnitTasksByUserDueByWeek helps the supervisor manage
   * the tasks due in the specified week by displaying the assigned and
   * reserved tasks in a bar chart format.
   *
   * @param key - OrgUnitTasksByUserDueOnDateKey
   * @return OrgUnitTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public OrgUnitTasksByUserDueOnDateDetails readOrgUnitTasksByUserDueByWeek(
    OrgUnitTasksByUserDueOnDateKey key) throws AppException,
      InformationalException {

    // Create Organization Unit objects to call SL method
    final OrgUnitTasksByUserDueOnDateDetails orgUnitTasksByUserDueOnDateDetails = new OrgUnitTasksByUserDueOnDateDetails();
    final OrgUnitTasksByUserDueOnDateKey orgUnitTasksByUserDueOnDateKey = new OrgUnitTasksByUserDueOnDateKey();
    final curam.supervisor.sl.intf.MaintainSupervisorOrgUnits maintainSupervisorOrgUnits = MaintainSupervisorOrgUnitsFactory.newInstance();

    // Assign key values
    orgUnitTasksByUserDueOnDateKey.key = key.key;

    // calling the service layer method
    orgUnitTasksByUserDueOnDateDetails.dtls = maintainSupervisorOrgUnits.readOrgUnitTasksByUserDueByWeek(
      orgUnitTasksByUserDueOnDateKey.key);

    // To get page context
    final SupervisorApplicationPageContextDescription supervisorapplicationpageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = orgUnitTasksByUserDueOnDateKey.key.key.organizationUnitID;
    orgUnitTasksByUserDueOnDateDetails.pageContext.description = supervisorapplicationpageContextDescription.readOrgUnitNamePageContext(organisationUnitKey).description;

    return orgUnitTasksByUserDueOnDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to fetch the page name based on selected
   * task option.
   *
   * @param key -
   * ResolveOrgUnitTaskOptionKey
   * @return ResolveOrgUnitPages
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public ResolveOrgUnitPages resolveOrgUnitTasksByDateOrWeek(
    ResolveOrgUnitTaskOptionKey key) throws AppException,
      InformationalException {

    final ResolveOrgUnitPages resolveOrgUnitPages = new ResolveOrgUnitPages();

    final String taskOptionCode = key.taskOptionCode;

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
      ORGUNITTASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASKS_INWEEK,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(ORGUNITTASKOPTIONPAGE.TABLENAME,
        ORGUNITTASKOPTIONPAGE.ORGUNITTASKS_ONDATE,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveOrgUnitPages.pageName = pageName;
    return resolveOrgUnitPages;
  }

  // BEGIN, CR00232351, ZV
  // ___________________________________________________________________________
  /**
   * Reads the Organization Unit tab display details for supervisor workspace.
   *
   * @param key Key of organization unit to be read
   *
   * @return Organization unit tab display details
   */
  @Override
  public OrganisationUnitTabDetails readOrgUnitTabDetails(
    final OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    return MaintainSupervisorOrgUnitsFactory.newInstance().readOrgUnitTabDetails(
      key);
  }
  // END, CR00232351
}
