/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;

import curam.codetable.PODTYPE;
import curam.codetable.SAMPLEPODLOADERBINDINGS;
import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.UserPageConfigsFactory;
import curam.core.sl.entity.intf.UserPageConfigs;
import curam.core.sl.entity.struct.UserPageConfigsDtls;
import curam.core.sl.entity.struct.UserPageConfigsKey;
import curam.core.sl.pods.impl.PodsConst;
import curam.core.struct.UserRoleDetails;
import curam.core.struct.UsersKey;
import curam.sample.facade.struct.CustomPage;
import curam.util.common.util.xml.HTMLSerializer;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.resources.XMLParserCache;
import curam.util.transaction.TransactionInfo;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Create a DOM document describing the custom contents of the current users
 * home page. Read the user preferences to find a list of Pods that are
 * required,
 * then load all the specified pods and add them to the document.
 */
public class CustomizablePageLoader {

  // Create a Application message that tells the user when the
  // process has failed
  AppException globalCannotRenderException =
    new AppException(curam.message.PODINFORMATIONALS.ERR_CANNOT_RENDER_PODS);

  // _____________________________________________________________________________
  /**
   * Load the page content. Read the user preferences to return a list of
   * pods to pass to the page renderer.
   */
  public CustomPage loadContent()
    throws AppException, InformationalException {

    // Declare return structure
    final CustomPage page = new CustomPage();

    // UserPageConfigs manipulation variables
    final UserPageConfigs userPageConfigsObj =
      UserPageConfigsFactory.newInstance();
    final UserPageConfigsKey userPageConfigsKey = new UserPageConfigsKey();
    UserPageConfigsDtls userPageConfigsDtls = new UserPageConfigsDtls();

    // Users manipulation variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UserRoleDetails userRoleDetails = new UserRoleDetails();

    // Populate key to read back userName
    usersKey.userName = TransactionInfo.getProgramUser();

    userRoleDetails = usersObj.readUserRole(usersKey);

    // Populate key to read back existing preference details for the user
    userPageConfigsKey.userName = TransactionInfo.getProgramUser();
    userPageConfigsKey.customPageID = PodsConst.kCaseworkerCustomHomepage;
    userPageConfigsKey.userRoleName = userRoleDetails.roleName;

    userPageConfigsDtls = userPageConfigsObj.read(userPageConfigsKey);

    Document configDoc = null;

    // Convert preference data into a DOM objectuserRoleDetails
    try {
      final DocumentBuilder docBuilder = XMLParserCache.getDocumentBuilder();

      configDoc = docBuilder.parse(new InputSource(
        new StringReader(userPageConfigsDtls.config.toString())));

    } catch (final IOException ioExeption) {
      ioExeption.printStackTrace();
      throw globalCannotRenderException;
    } catch (final SAXException saxException) {
      saxException.printStackTrace();
      throw globalCannotRenderException;
    }

    try {
      final DocumentBuilder docBuilder = XMLParserCache.getDocumentBuilder();
      // Create the document for the page
      final Document pageDocument = docBuilder.newDocument();
      // Create the pods (root) element in the document
      final Element podList =
        pageDocument.createElement(PodsConst.kPodListElement);

      pageDocument.appendChild(podList);

      // Append config data to display selected pods
      final Node configNode =
        pageDocument.importNode(configDoc.getFirstChild(), true);

      pageDocument.getDocumentElement().appendChild(configNode);

      // Read the Current Users Preferences for the workspace layout.
      final ArrayList<String> userPods = getUserPreferences();

      // Set the class types that are used in the loadContent method
      final Class[] parameterTypes =
        new Class[]{Class.forName(PodsConst.kDomDocument) };

      // Set the arguments to pass to the loadContent method
      final Object[] arguments = new Object[]{pageDocument };

      // For each Pod in the user preferences...
      // 1. Read the Bindings Codetable and return the Pod Loader class.
      // 2. Create and instance of the returned Pod Loader class.
      // 3. Invoke the createPod method on the interface class.
      for (final String pod : userPods) {

        // 1.Read the Bindings Codetable and return the Factory class.
        final curam.util.internal.codetable.intf.CodeTable codeTableIntf =
          curam.util.internal.codetable.fact.CodeTableFactory.newInstance();

        final CTItemKey ctItemKey = new CTItemKey();

        ctItemKey.locale =
          curam.util.transaction.TransactionInfo.getProgramLocale();
        ctItemKey.tableName = SAMPLEPODLOADERBINDINGS.TABLENAME;
        ctItemKey.code = pod;

        final CTItem ctItem = codeTableIntf.getOneItem(ctItemKey);

        // The loader factory class is stored in the description field
        final String podLoaderClassName = ctItem.description;

        // 2. Create an instance of the Pod Loader class
        final Class podLoaderClass = Class.forName(podLoaderClassName);
        final Object podLoaderInstance = podLoaderClass.newInstance();

        // 3. Invoke the createPod method on the Loader class
        final String createPodMethod = PodsConst.kCreatePodMethodName;
        final Method createPod =
          podLoaderClass.getMethod(createPodMethod, parameterTypes);

        createPod.invoke(podLoaderInstance, arguments);
      }

      // Convert the document in to a string and add it to the return struct.
      page.contentXML =
        HTMLSerializer.toString(pageDocument, HTMLSerializer.Method.XHTML);

    } catch (final NoSuchMethodException e) {
      e.printStackTrace();
      throw globalCannotRenderException;
    } catch (final ClassNotFoundException e) {
      e.printStackTrace();
      throw globalCannotRenderException;
    } catch (final Exception e) {
      e.printStackTrace();
      throw globalCannotRenderException;
    }
    return page;
  }

  // _______________________________________________________________________________
  /**
   * Get the preference data for the current User.
   *
   * @return String[], a string of pod types from the SAMPLEPODLOADERBINDINGS
   * CODETABLE
   */
  public ArrayList<String> getUserPreferences()
    throws AppException, InformationalException {

    // Return struct
    final ArrayList<String> displayPods = new ArrayList<String>();

    // UserPageConfigs manipulation variables
    final UserPageConfigs userPageConfigsObj =
      UserPageConfigsFactory.newInstance();
    final UserPageConfigsKey userPageConfigsKey = new UserPageConfigsKey();
    UserPageConfigsDtls userPageConfigsDtls = new UserPageConfigsDtls();

    // Users manipulation variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UserRoleDetails userRoleDetails = new UserRoleDetails();

    // Populate key to read back userName
    usersKey.userName = TransactionInfo.getProgramUser();

    userRoleDetails = usersObj.readUserRole(usersKey);

    // Populate key to read back existing preference details for the user
    userPageConfigsKey.userName = TransactionInfo.getProgramUser();
    userPageConfigsKey.customPageID = PodsConst.kCaseworkerCustomHomepage;
    userPageConfigsKey.userRoleName = userRoleDetails.roleName;

    userPageConfigsDtls = userPageConfigsObj.read(userPageConfigsKey);

    Document document = null;

    // Convert preference data into a DOM objectuserRoleDetails
    try {
      final DocumentBuilder docBuilder = XMLParserCache.getDocumentBuilder();

      document = docBuilder.parse(new InputSource(
        new StringReader(userPageConfigsDtls.config.toString())));

      final NodeList podList =
        document.getElementsByTagName(PodsConst.kPodNameElement);

      for (int i = 0; i < podList.getLength(); i++) {

        final String podName =
          podList.item(i).getChildNodes().item(0).getNodeValue();

        // TODO Flesh out for other pod types, does it have to be an if/else?
        if (podName.equals(PODTYPE.QUICKLINKS)) {
          displayPods.add(SAMPLEPODLOADERBINDINGS.QUICKLINKPOD);
        } else if (podName.equals(PODTYPE.MYTASKS)) {
          displayPods.add(SAMPLEPODLOADERBINDINGS.TASKPOD);
        } else if (podName.equals(PODTYPE.MYBOOKMARKS)) {
          displayPods.add(SAMPLEPODLOADERBINDINGS.MYBOOKMARKSPOD);
        } else if (podName.equals(PODTYPE.MYQUERIES)) {
          displayPods.add(SAMPLEPODLOADERBINDINGS.MYQUERIESPOD);
        }
      }

    } catch (final IOException ioExeption) {
      ioExeption.printStackTrace();
      throw globalCannotRenderException;
    } catch (final SAXException saxException) {
      saxException.printStackTrace();
      throw globalCannotRenderException;
    }

    return displayPods;
  }
}
