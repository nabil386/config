/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.sl.tab.impl;


import curam.core.impl.EnvVars;
import curam.util.resources.Configuration;
import curam.util.tab.impl.DynamicNavStateLoader;
import curam.util.tab.impl.NavigationState;
import java.util.Map;


/**
 * Populates the sample assistance integrate case navigation.
 */
public class IncomeAssistanceBenefitSampleNavStateLoader implements
  DynamicNavStateLoader {

  // ___________________________________________________________________________
  /**
   * Returns the state of the given list of navigation items.
   *
   * @param navigation The navigation instance to load states into.
   * @param pageParameters The context information, in our current case it is
   * the page parameters.
   *
   * @param idsToUpdate The IDs requested by the client to be updated.
   * @return The same navigation instance with the updated states.
   */
  @Override
  public NavigationState loadNavState(NavigationState navigation,
    Map<String, String> pageParameters, String[] idsToUpdate) {

    final boolean appealsInstalled = Configuration.getBooleanProperty(
      EnvVars.ENV_APPEALS_ISINSTALLED);

    for (final String id : idsToUpdate) {

      if (id.equals(SampleTabLoaderConst.kParticipants)) {

        // When appeals is NOT installed we only display the participants page
        navigation.setVisible(!appealsInstalled,
          SampleTabLoaderConst.kParticipants);
      }

      if (id.equals(SampleTabLoaderConst.kParticipantsFolder)) {

        // When appeals is installed we display the participants folder
        navigation.setVisible(appealsInstalled,
          SampleTabLoaderConst.kParticipantsFolder);
      }

      if (id.equals(SampleTabLoaderConst.kAppeals)) {

        // When appeals is installed we display the appeals page
        navigation.setVisible(appealsInstalled, SampleTabLoaderConst.kAppeals);
      }

      if (id.equals(SampleTabLoaderConst.kLegalActions)) {

        // When appeals is installed we display the legal actions page
        navigation.setVisible(appealsInstalled,
          SampleTabLoaderConst.kLegalActions);
      }

    }

    return navigation;
  }

}
