/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.NotificationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainCase;
import curam.core.intf.Notification;
import curam.core.sl.entity.fact.IssueConfigurationFactory;
import curam.core.sl.entity.intf.IssueConfiguration;
import curam.core.sl.entity.struct.IssueConfigurationDtls;
import curam.core.sl.entity.struct.IssueConfigurationKey;
import curam.core.sl.fact.IssueDeliveryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.intf.IssueDelivery;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.IssueCreationDetails;
import curam.core.sl.struct.IssueType;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.message.BPOSAMPLESPORTINGGRANTEVIDENCECONTROLLERHOOK;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.intf.SampleSportingActivity;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * This process class allows methods in the core evidence controller hook to
 * be overridden.
 *
 */
public class SampleSportingGrantEvidenceControllerHook extends curam.sample.sl.base.SampleSportingGrantEvidenceControllerHook {

  /**
   * The maximum payment amount allowable. Its value is @value
   */
  protected static final int kMaxAllowableAmount = 1000;

  // ___________________________________________________________________________
  /**
   * This method will examine the payment amount recorded on the sample
   * sporting activity evidence to determine whether an issue delivery case
   * should be created.
   *
   * @param caseKey key containing the case id
   * @param evKey key containing the evidence descriptor id
   */
  @Override
  public void postApplyInEdit(CaseKey caseKey, EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // BEGIN, CR00030411, KH
    // We only want to examine the SAMPLESPORTINGACTIVITY evidence
    if (evKey.evidenceType.equals(CASEEVIDENCE.SAMPLESPORTINGACTIVITY)) {

      // IssueDelivery manipulation variables
      final IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
      final IssueCreationDetails issueCreationDetails = new IssueCreationDetails();

      // IssueConfiguration entity manipulation variables
      IssueConfigurationKey issueConfigurationKey = new IssueConfigurationKey();
      final IssueConfiguration issueConfigurationObj = IssueConfigurationFactory.newInstance();
      // BEGIN, CR00030124, KH
      final IssueType issueType = new IssueType();
      // END, CR00030124

      // EvidenceDescriptor entity manipulation variables
      final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();
      final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      // SampleSprotingActivity entity manipulation variables
      final SampleSportingActivity sampleSportingActivityObj = SampleSportingActivityFactory.newInstance();
      final SampleSportingActivityKey sampleSportingActivityKey = new SampleSportingActivityKey();
      SampleSportingActivityDtls sampleSportingActivityDtls = new SampleSportingActivityDtls();

      // BEGIN, CR00029103, KH
      // CaseHeader manipulation variables
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // END, CR00029103

      // Set key to find the evidence
      relatedIDAndEvidenceTypeKey.relatedID = evKey.evidenceID;
      relatedIDAndEvidenceTypeKey.evidenceType = evKey.evidenceType;

      // Read EvidenceDescriptor
      final EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
        relatedIDAndEvidenceTypeKey);

      // Set key to find the sample sporting activity
      sampleSportingActivityKey.sportingActivityID = evidenceDescriptorDtls.relatedID;

      // Read the details
      sampleSportingActivityDtls = sampleSportingActivityObj.read(
        sampleSportingActivityKey);

      // Check the payment amount
      if (sampleSportingActivityDtls.paymentAmount.getValue()
        > kMaxAllowableAmount) {

        // The amount is larger than allowed, we will create an
        // Earned Income issue delivery case.

        // BEGIN, CR00030124, KH
        // BEGIN, CR00031101, KH
        // Find the appropriate issue configuration in admin
        issueType.issueType = ISSUECONFIGURATIONTYPE.EARNEDINCOME;

        // BEGIN, CR00029222, KH
        issueConfigurationKey = curam.core.sl.fact.IssueConfigurationFactory.newInstance().readCurrentConfigurationForIssueType(
          issueType);
        // END, CR00031101

        // If a valid configuration is found, we can create the issue
        if (issueConfigurationKey.issueConfigurationID != 0) {

          // Read issue configuration details to get the priority
          final IssueConfigurationDtls issueConfigurationDtls = issueConfigurationObj.read(
            issueConfigurationKey);

          // Set evidence descriptor key for issue delivery evidence list
          evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

          // BEGIN, CR00029103, KH
          // Find the primary client of the IC Product Delivery
          caseHeaderKey.caseID = caseKey.caseID;

          // BEGIN, CR00279909, SG
          final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(
            caseHeaderKey);

          // END, CR00279909
          // END, CR00029103

          // Populate the Issue Case Creation details
          // BEGIN, CR00080678, CH
          // We want to create the Issue against the IC. We the it IC caseID
          // from the evidence details
          issueCreationDetails.caseID = evidenceDescriptorDtls.caseID;
          // END, CR00080678
          // BEGIN, CR00029103, KH
          issueCreationDetails.concernRoleID = caseHeaderDtls.concernRoleID;
          // END, CR00029103
          issueCreationDetails.issueConfigurationID = issueConfigurationKey.issueConfigurationID;
          issueCreationDetails.startDate = Date.getCurrentDate();
          issueCreationDetails.endDate = Date.kZeroDate;
          issueCreationDetails.priorityCode = issueConfigurationDtls.priority;
          issueCreationDetails.evidenceDtlsList.dtls.addRef(
            evidenceDescriptorKey);

          // BEGIN, CR00031196, KH
          // Create an Issue Delivery Case
          issueDeliveryObj.createIssueDelivery(issueCreationDetails);
          // END, CR00031196

        } else { // There is no valid issue configured in the administration

          // Notification manipulation variables
          final Notification notificationObj = NotificationFactory.newInstance();
          final StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

          final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
          CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = new CaseReferenceProductNameConcernRoleName();
          final CaseIDKey caseIDKey = new CaseIDKey();

          caseIDKey.caseID = caseKey.caseID;
          caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);

          final AppException subject = new AppException(
            BPOSAMPLESPORTINGGRANTEVIDENCECONTROLLERHOOK.ERR_RV_NO_VALID_ISSUE_TYPE_FOUND_SUBJECT);

          subject.arg(caseReferenceProductNameConcernRoleName.caseReference);
          subject.arg(caseReferenceProductNameConcernRoleName.productName);
          subject.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

          final AppException body = new AppException(
            BPOSAMPLESPORTINGGRANTEVIDENCECONTROLLERHOOK.ERR_RV_NO_VALID_ISSUE_TYPE_FOUND_BODY);

          body.arg(caseReferenceProductNameConcernRoleName.caseReference);
          body.arg(caseReferenceProductNameConcernRoleName.productName);
          body.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

          // Read case owner
          caseHeaderKey.caseID = caseKey.caseID;

          // BEGIN, CR00163659, CL
          standardManualTaskDtls.dtls.taskDtls.subject = subject.getMessage(
            TransactionInfo.getProgramLocale());
          standardManualTaskDtls.dtls.taskDtls.comments = body.getMessage(
            TransactionInfo.getProgramLocale());
          // END, CR00163659
          standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = // BEGIN,
            // CR00052924,
            // GM
            TaskDefinitionIDConst.notificationTaskDefinitionID;
          // END, CR00052924

          standardManualTaskDtls.dtls.concerningDtls.caseID = caseKey.caseID;

          // BEGIN, CR00079597, RCB
          // create notification
          notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
          // END, CR00079597

        } // end if createIssueDeliveryInd
        // END, CR00029222

      } // end if amount > kMaxAllowableAmount

    } // end if SAMPLESPORTINGACTIVITY evidence
    // END, CR00030411
  }

}
