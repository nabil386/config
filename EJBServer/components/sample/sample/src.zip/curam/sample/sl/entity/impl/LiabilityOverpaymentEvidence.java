/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.core.sl.entity.fact.LiabilityOverpaymentEvidenceFactory;
import curam.sample.sl.entity.struct.LiabilityOverpaymentEvidenceDtls;
import curam.sample.sl.entity.struct.LiabilityOverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class acts as a wrapper for the Liability Overpayment Evidence entity
 * that has been moved into core. Its existence is to minimize impact on those
 * customers who have referenced it in their custom code.
 */
public class LiabilityOverpaymentEvidence extends curam.sample.sl.entity.base.LiabilityOverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * Inserts a Liability Overpayment Evidence record.
   *
   * @param dtls Liability Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.intf.LiabilityOverpaymentEvidence#insert(curam.core.sl.struct.LiabilityOverpaymentEvidenceDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Liability Overpayment Evidence entity has been moved into core. See release
   * note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void insert(final LiabilityOverpaymentEvidenceDtls dtls)
    throws AppException, InformationalException {

    final curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls liabilityOverpaymentEvidenceDtls = new curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls();

    liabilityOverpaymentEvidenceDtls.caseID = dtls.caseID;
    liabilityOverpaymentEvidenceDtls.fromDate = dtls.fromDate;
    liabilityOverpaymentEvidenceDtls.toDate = dtls.toDate;
    liabilityOverpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    liabilityOverpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;
    liabilityOverpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    liabilityOverpaymentEvidenceDtls.overpaymentEvidenceID = dtls.overpaymentEvidenceID;

    LiabilityOverpaymentEvidenceFactory.newInstance().insert(
      liabilityOverpaymentEvidenceDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies Liability Overpayment Evidence details.
   *
   * @param key Liability Overpayment Evidence key.
   * @param dtls Liability Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.intf.LiabilityOverpaymentEvidence#modify(curam.core.sl.struct.LiabilityOverpaymentEvidenceKey, curam.core.sl.struct.LiabilityOverpaymentEvidenceDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Liability Overpayment Evidence entity has been moved into core. See release
   * note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void modify(final LiabilityOverpaymentEvidenceKey key,
    final LiabilityOverpaymentEvidenceDtls dtls) throws AppException,
      InformationalException {

    final curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceKey liabilityOverpaymentEvidenceKey = new curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceKey();

    final curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls liabilityOverpaymentEvidenceDtls = new curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls();

    // Set key
    liabilityOverpaymentEvidenceKey.overpaymentEvidenceID = key.overpaymentEvidenceID;

    // Set details
    liabilityOverpaymentEvidenceDtls.caseID = dtls.caseID;
    liabilityOverpaymentEvidenceDtls.fromDate = dtls.fromDate;
    liabilityOverpaymentEvidenceDtls.toDate = dtls.toDate;
    liabilityOverpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    liabilityOverpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;
    liabilityOverpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    liabilityOverpaymentEvidenceDtls.overpaymentEvidenceID = dtls.overpaymentEvidenceID;

    LiabilityOverpaymentEvidenceFactory.newInstance().modify(
      liabilityOverpaymentEvidenceKey, liabilityOverpaymentEvidenceDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads Liability Overpayment Evidence details.
   *
   * @param key Liability Overpayment Evidence key.
   * @return Liability Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.intf.LiabilityOverpaymentEvidence#read(curam.core.sl.struct.LiabilityOverpaymentEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Liability Overpayment Evidence entity has been moved into core. See release
   * note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public LiabilityOverpaymentEvidenceDtls read(
    final LiabilityOverpaymentEvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    final LiabilityOverpaymentEvidenceDtls liabilityOverpaymentEvidenceDtls = new LiabilityOverpaymentEvidenceDtls();

    final curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceKey liabilityOverpaymentEvidenceKey = new curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceKey();

    // Set key
    liabilityOverpaymentEvidenceKey.overpaymentEvidenceID = key.overpaymentEvidenceID;

    final curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls dtls = LiabilityOverpaymentEvidenceFactory.newInstance().read(
      liabilityOverpaymentEvidenceKey);

    liabilityOverpaymentEvidenceDtls.caseID = dtls.caseID;
    liabilityOverpaymentEvidenceDtls.fromDate = dtls.fromDate;
    liabilityOverpaymentEvidenceDtls.toDate = dtls.toDate;
    liabilityOverpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    liabilityOverpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;
    liabilityOverpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    liabilityOverpaymentEvidenceDtls.overpaymentEvidenceID = dtls.overpaymentEvidenceID;

    return liabilityOverpaymentEvidenceDtls;
  }

}
