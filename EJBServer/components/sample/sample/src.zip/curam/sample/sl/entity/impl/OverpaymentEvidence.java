/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.sl.entity.fact.OverpaymentEvidenceFactory;
import curam.sample.sl.entity.struct.GetEvidenceByRelatedCaseIDKey;
import curam.sample.sl.entity.struct.OverpaymentEvidenceDetails;
import curam.sample.sl.entity.struct.OverpaymentEvidenceDtls;
import curam.sample.sl.entity.struct.OverpaymentEvidenceDtlsList;
import curam.sample.sl.entity.struct.OverpaymentEvidenceID;
import curam.sample.sl.entity.struct.OverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class acts as a wrapper for the Overpayment Evidence entity that has
 * been moved into core. Its existence is to minimize impact on those customers
 * who have referenced it in their custom code.
 */
public class OverpaymentEvidence extends curam.sample.sl.entity.base.OverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * Inserts an Overpayment Evidence record.
   *
   * @param Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.OverpaymentEvidence#insert(curam.core.sl.entity.struct.OverpaymentEvidenceDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void insert(final OverpaymentEvidenceDtls dtls) throws AppException,
      InformationalException {

    final curam.core.sl.entity.struct.OverpaymentEvidenceDtls overpaymentEvidenceDtls = new curam.core.sl.entity.struct.OverpaymentEvidenceDtls();

    overpaymentEvidenceDtls.caseID = dtls.caseID;
    overpaymentEvidenceDtls.fromDate = dtls.fromDate;
    overpaymentEvidenceDtls.toDate = dtls.toDate;
    overpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    overpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    overpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;
    overpaymentEvidenceDtls.overpaymentEvidenceID = UniqueIDFactory.newInstance().getNextID();
    overpaymentEvidenceDtls.versionNo = dtls.versionNo;

    OverpaymentEvidenceFactory.newInstance().insert(overpaymentEvidenceDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies an Overpayment Evidence record.
   *
   * @param key Overpayment Evidence Key details.
   * @param dtls Overpayment Evidence Details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.OverpaymentEvidence#modify(curam.core.sl.entity.struct.OverpaymentEvidenceKey, curam.core.sl.entity.struct.OverpaymentEvidenceDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void modify(final OverpaymentEvidenceKey key,
    final OverpaymentEvidenceDtls dtls) throws AppException,
      InformationalException {

    final curam.core.sl.entity.struct.OverpaymentEvidenceKey overpaymentEvidenceKey = new curam.core.sl.entity.struct.OverpaymentEvidenceKey();
    final curam.core.sl.entity.struct.OverpaymentEvidenceDtls overpaymentEvidenceDtls = new curam.core.sl.entity.struct.OverpaymentEvidenceDtls();

    overpaymentEvidenceKey.overpaymentEvidenceID = dtls.overpaymentEvidenceID;

    overpaymentEvidenceDtls.caseID = dtls.caseID;
    overpaymentEvidenceDtls.fromDate = dtls.fromDate;
    overpaymentEvidenceDtls.toDate = dtls.toDate;
    overpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    overpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    overpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;
    overpaymentEvidenceDtls.versionNo = dtls.versionNo;

    OverpaymentEvidenceFactory.newInstance().insert(overpaymentEvidenceDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads Overpayment Evidence details.
   *
   * @param key Overpayment Evidence Key.
   * @return Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.OverpaymentEvidence#read(curam.core.sl.entity.struct.OverpaymentEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public OverpaymentEvidenceDtls read(final OverpaymentEvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final OverpaymentEvidenceDtls overpaymentEvidenceDtls = new OverpaymentEvidenceDtls();

    final curam.core.sl.entity.struct.OverpaymentEvidenceKey overpaymentEvidenceKey = new curam.core.sl.entity.struct.OverpaymentEvidenceKey();

    overpaymentEvidenceKey.overpaymentEvidenceID = key.overpaymentEvidenceID;

    final curam.core.sl.entity.struct.OverpaymentEvidenceDtls details = OverpaymentEvidenceFactory.newInstance().read(
      overpaymentEvidenceKey);

    overpaymentEvidenceDtls.caseID = details.caseID;
    overpaymentEvidenceDtls.fromDate = details.fromDate;
    overpaymentEvidenceDtls.toDate = details.toDate;
    overpaymentEvidenceDtls.overpaymentAmount = details.overpaymentAmount;
    overpaymentEvidenceDtls.reassessmentDate = details.reassessmentDate;
    overpaymentEvidenceDtls.relatedCaseID = details.relatedCaseID;
    overpaymentEvidenceDtls.versionNo = details.versionNo;
    overpaymentEvidenceDtls.overpaymentEvidenceID = details.overpaymentEvidenceID;

    return overpaymentEvidenceDtls;
  }

  // ___________________________________________________________________________
  /**
   * Reads overpayment evidence.
   *
   * @param key Key details for reading Overpayment Evidence details.
   *
   * @return Overpayment Evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.OverpaymentEvidence#readEvidence(curam.core.sl.entity.struct.OverpaymentEvidenceID)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public OverpaymentEvidenceDetails readEvidence(
    final OverpaymentEvidenceID key) throws AppException,
      InformationalException {

    // Return object
    final OverpaymentEvidenceDetails overpaymentEvidenceDetails = new OverpaymentEvidenceDetails();

    final curam.core.sl.entity.struct.OverpaymentEvidenceID overpaymentEvidenceID = new curam.core.sl.entity.struct.OverpaymentEvidenceID();

    overpaymentEvidenceID.overpaymentEvidenceID = key.overpaymentEvidenceID;

    final curam.core.sl.entity.struct.OverpaymentEvidenceDetails details = OverpaymentEvidenceFactory.newInstance().readEvidence(
      overpaymentEvidenceID);

    overpaymentEvidenceDetails.caseID = details.caseID;
    overpaymentEvidenceDetails.caseReference = details.caseReference;
    overpaymentEvidenceDetails.fromDate = details.fromDate;
    overpaymentEvidenceDetails.toDate = details.toDate;
    overpaymentEvidenceDetails.overpaymentAmount = details.overpaymentAmount;
    overpaymentEvidenceDetails.reassessmentDate = details.reassessmentDate;
    overpaymentEvidenceDetails.relatedCaseID = details.relatedCaseID;
    overpaymentEvidenceDetails.relatedCaseReference = details.relatedCaseReference;
    overpaymentEvidenceDetails.versionNo = details.versionNo;
    overpaymentEvidenceDetails.overpaymentEvidenceID = details.overpaymentEvidenceID;

    return overpaymentEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of Overpayment Evidence records on the related case
   * identifier.
   *
   * @param key Contains a related case identifier.
   * @return List of Overpayment Evidence records.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.OverpaymentEvidence#searchByRelatedCaseID(curam.core.sl.entity.struct.GetEvidenceByRelatedCaseIDKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public OverpaymentEvidenceDtlsList searchByRelatedCaseID(
    final GetEvidenceByRelatedCaseIDKey key) throws AppException,
      InformationalException {

    // Return object
    final OverpaymentEvidenceDtlsList overpaymentEvidenceDtlsList = new OverpaymentEvidenceDtlsList();

    final curam.core.sl.entity.struct.GetEvidenceByRelatedCaseIDKey getEvidenceByRelatedCaseIDKey = new curam.core.sl.entity.struct.GetEvidenceByRelatedCaseIDKey();

    getEvidenceByRelatedCaseIDKey.relatedCaseID = key.relatedCaseID;

    final curam.core.sl.entity.struct.OverpaymentEvidenceDtlsList dtlsList = OverpaymentEvidenceFactory.newInstance().searchByRelatedCaseID(
      getEvidenceByRelatedCaseIDKey);

    for (int i = 0; i < dtlsList.dtls.size(); i++) {

      final OverpaymentEvidenceDtls overpaymentEvidenceDtls = new OverpaymentEvidenceDtls();

      overpaymentEvidenceDtls.caseID = dtlsList.dtls.item(i).caseID;
      overpaymentEvidenceDtls.relatedCaseID = dtlsList.dtls.item(i).relatedCaseID;
      overpaymentEvidenceDtls.fromDate = dtlsList.dtls.item(i).fromDate;
      overpaymentEvidenceDtls.toDate = dtlsList.dtls.item(i).toDate;
      overpaymentEvidenceDtls.reassessmentDate = dtlsList.dtls.item(i).reassessmentDate;
      overpaymentEvidenceDtls.overpaymentAmount = dtlsList.dtls.item(i).overpaymentAmount;
      overpaymentEvidenceDtls.overpaymentEvidenceID = dtlsList.dtls.item(i).overpaymentEvidenceID;
      overpaymentEvidenceDtls.versionNo = dtlsList.dtls.item(i).versionNo;

      overpaymentEvidenceDtlsList.dtls.addRef(overpaymentEvidenceDtls);
    }

    return overpaymentEvidenceDtlsList;
  }

}
