/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.sample.sl.tab.impl;


import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.tab.impl.BusinessObjectMenuLoader;
import curam.core.sl.tab.impl.TabLoaderConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;
import java.util.Map;


public class SportingActivityObjectMenuLoader implements
  DynamicMenuStateLoader {

  /**
   * Constructor.
   */
  public SportingActivityObjectMenuLoader() {

    super();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public MenuState loadMenuState(MenuState menuState,
    Map<String, String> pageParameters, String[] idsToUpdate) {

    final BusinessObjectMenuLoader businessObjectMenuLoader = new BusinessObjectMenuLoader();
    // configure menu state to load the defaults
    final MenuState returnState = businessObjectMenuLoader.loadMenuState(
      menuState, pageParameters, idsToUpdate);

    final String successionIDParam = pageParameters.get(
      TabLoaderConst.kSuccessionID);
    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = Long.parseLong(successionIDParam);

    EvidenceDescriptorDtls lastInSuccession = null;

    try {
      lastInSuccession = EvidenceControllerFactory.newInstance().getBusinessObjectDescriptor(
        successionID);

    } catch (final AppException e) {// e.printStackTrace();
    } catch (final InformationalException e) {// e.printStackTrace();
    }

    if (lastInSuccession != null) {

      if (!lastInSuccession.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.CANCELED)) {
        // set visibility of children
        returnState.setVisible(true,
          SampleTabLoaderConst.kSportingActivityNewSportingActivityExpense);

      }
    }

    return returnState;
  }

}
