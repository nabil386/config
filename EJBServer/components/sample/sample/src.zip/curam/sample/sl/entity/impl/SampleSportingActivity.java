/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2017. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SAMPLESPORTINGACTIVITYTYPE;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.impl.ExternalEvidenceInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.fact.EvidenceRelationshipFactory;
import curam.core.sl.infrastructure.impl.EvidenceInterface;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.ChildList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceTransferDetails;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AmountDetail;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseParticipantRoleDetails;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.RelatedCasesDetailsList;
import curam.message.BPOSAMPLESPORTINGACTIVITY;
import curam.message.ENTSAMPLESPORTINGACTIVITY;
import curam.message.ENTSAMPLESPORTINGSPONSORSHIP;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.fact.SportingSponsorshipFactory;
import curam.sample.sl.entity.intf.SampleSportingActivityExpense;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseKey;
import curam.sample.sl.entity.struct.SampleSportingActivityKey;
import curam.sample.sl.entity.struct.SportingSponsorshipDtls;
import curam.sample.sl.entity.struct.SportingSponsorshipKey;
import curam.sample.sl.entity.struct.ValidateDuplicateDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.Money;

/**
 * Operations for the SampleSportingActivity entity
 */
public class SampleSportingActivity
  extends curam.sample.sl.entity.base.SampleSportingActivity
  implements EvidenceInterface, ExternalEvidenceInterface {

  // ___________________________________________________________________________
  /**
   * Calculate the attribution dates for the case
   *
   * @param caseKey Contains the case identifier
   * @param evKey Contains the evidenceID and evidenceType
   *
   * @return The attribution dates for the entity
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(
    final CaseKey caseKey, final EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // Return object
    final AttributedDateDetails attributedDateDetails =
      new AttributedDateDetails();

    // SampleSportingActivityKey entity key
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Read the SampleSportingActivity entity to retrieve the dates
    sampleSportingActivityKey.sportingActivityID = evKey.evidenceID;
    final SampleSportingActivityDtls sampleSportingActivityDtls =
      read(sampleSportingActivityKey);

    attributedDateDetails.fromDate = sampleSportingActivityDtls.startDate;
    attributedDateDetails.toDate = sampleSportingActivityDtls.endDate;

    return attributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(
    final EIEvidenceKey key) throws AppException, InformationalException {

    // Return object
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
      new EIFieldsForListDisplayDtls();

    // SampleSportingActivityKey entity key
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Read the SampleSportingActivity entity to get display details
    sampleSportingActivityKey.sportingActivityID = key.evidenceID;
    final SampleSportingActivityDtls sampleSportingActivityDtls =
      read(sampleSportingActivityKey);

    // Set the start / end dates
    eiFieldsForListDisplayDtls.startDate =
      sampleSportingActivityDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = sampleSportingActivityDtls.endDate;

    // Set the summary details.
    final StringBuffer strBuf = new StringBuffer(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(SAMPLESPORTINGACTIVITYTYPE.TABLENAME,
        sampleSportingActivityDtls.sportingActivityType,
        TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    // BEGIN, CR00241441, PDN
    final TabDetailFormatter tabDetailFormatterObj =
      TabDetailFormatterFactory.newInstance();

    // BEGIN, CR00069956, GM
    // BEGIN, CR00085734, MR
    final AmountDetail amountDetail = new AmountDetail();

    amountDetail.amount = sampleSportingActivityDtls.paymentAmount;
    strBuf.append(CuramConst.gkSpace).append(
      tabDetailFormatterObj.formatCurrencyAmount(amountDetail).amount);
    // END, CR00085734
    // END, CR00069956
    // END, CR00241441

    eiFieldsForListDisplayDtls.summary = strBuf.toString();

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Activity evidence
   *
   * @param parentKey Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidence(final Object dtls,
    final EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((SampleSportingActivityDtls) dtls);

    eiEvidenceKey.evidenceID =
      ((SampleSportingActivityDtls) dtls).sportingActivityID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Activity evidence on modification
   *
   * @param origKey
   *
   * @param parentKey Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(final Object dtls,
    final EIEvidenceKey origKey, final EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((SampleSportingActivityDtls) dtls);

    eiEvidenceKey.evidenceID =
      ((SampleSportingActivityDtls) dtls).sportingActivityID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify Sample Sporting Activity evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   * @param dtls Sample Sporting Activity entity details
   */
  @Override
  public void modifyEvidence(final EIEvidenceKey key, final Object dtls)
    throws AppException, InformationalException {

    // SampleSportingActivityKey object
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Set entity key for modify
    sampleSportingActivityKey.sportingActivityID = key.evidenceID;

    // Modify details
    modify(sampleSportingActivityKey, (SampleSportingActivityDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads all child records.
   *
   * @param key Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(final EIEvidenceKey key)
    throws AppException, InformationalException {

    // Do nothing... this entity is a top level entity. No parent.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read Sample Sporting Activity evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   *
   * @return Sample Sporting Activity entity details
   */
  @Override
  public Object readEvidence(final EIEvidenceKey key)
    throws AppException, InformationalException {

    // SampleSportingActivityKey object
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Set key to read SampleSportingActivity
    sampleSportingActivityKey.sportingActivityID = key.evidenceID;

    // Read SampleSportingActivity
    return read(sampleSportingActivityKey);
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Activity details
   *
   * @param details Sample Sporting Activity details
   */
  @Override
  protected void preinsert(final SampleSportingActivityDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies Sample Sporting Activity details
   *
   * @param key Sample Sporting Activity key
   * @param details Sample Sporting Activity details
   */
  @Override
  protected void premodify(final SampleSportingActivityKey key,
    final SampleSportingActivityDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates Sample Sporting Activity entity details
   *
   * @param details Sample Sporting Activity details
   */
  @Override
  public void validate(final SampleSportingActivityDtls details)
    throws AppException, InformationalException {

    // A positive payment amount must be entered
    if (details.paymentAmount.isNegative()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITY.ERR_SA_FV_PAYMENT_AMOUNT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // An activity type must be specified
    if (details.sportingActivityType.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITY.ERR_SA_FV_ACTIVITY_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // An award type must be specified
    if (details.sportingAwardType.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITY.ERR_SA_FV_AWARD_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // End date must not be earlier than the start date
    if (!details.endDate.isZero() && !details.startDate.isZero()) {
      if (details.endDate.before(details.startDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(
            new AppException(
              BPOSAMPLESPORTINGACTIVITY.ERR_SA_XFV_END_DATE_BEFORE_START_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Check the start and end dates against the related child records
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = details.sportingActivityID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    final ChildList childList = EvidenceRelationshipFactory.newInstance()
      .getChildKeyList(eiEvidenceKey);

    // SampleSportingActivityExpense manipulation variables
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey =
      new SampleSportingActivityExpenseKey();
    final SampleSportingActivityExpense sampleSportingActivityExpenseObj =
      SampleSportingActivityExpenseFactory.newInstance();

    for (int i = 0; i < childList.list.dtls.size(); i++) {

      sampleSportingActivityExpenseKey.sportingActivityExpenseID =
        childList.list.dtls.item(i).childID;

      final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls =
        sampleSportingActivityExpenseObj
          .read(sampleSportingActivityExpenseKey);

      if (!sampleSportingActivityExpenseDtls.startDate.isZero()
        && !details.startDate.isZero()) {

        if (sampleSportingActivityExpenseDtls.startDate
          .before(details.startDate)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOSAMPLESPORTINGACTIVITY.ERR_SA_XFV_START_DATE_AFTER_SAE_START_DATES),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      if (!sampleSportingActivityExpenseDtls.endDate.isZero()
        && !details.endDate.isZero()) {

        if (sampleSportingActivityExpenseDtls.endDate
          .after(details.endDate)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().throwWithLookup(
              new AppException(
                BPOSAMPLESPORTINGACTIVITY.ERR_SA_XFV_END_DATE_BEFORE_SAE_END_DATES),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  @Override
  public EIEvidenceKeyList selectForValidation(final EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // BEGIN, CR00091163, VM
    // Casting to interface to avoid class cast exceptions when tracing is
    // turned on
    final StandardEvidenceInterface standardEvidenceInterface =
      (StandardEvidenceInterface) SampleSportingActivityExpenseFactory
        .newInstance();

    // END, CR00091163

    eiEvidenceKey.evidenceID = evKey.evidenceID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    final EIEvidenceKeyList eiEvidenceKeyList =
      standardEvidenceInterface.readAllByParentID(eiEvidenceKey);

    eiEvidenceKeyList.dtls.add(0, evKey);

    return eiEvidenceKeyList;
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey Evidence key
   * @param evKeyList Evidence key list
   * @param mode Validate mode (insert, delete, applyChanges, modify)
   */
  @Override
  public void validate(final EIEvidenceKey evKey,
    final EIEvidenceKeyList evKeyList, final ValidateMode mode)
    throws AppException, InformationalException {

    // Get the informational manager
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();
    // SampleSportingActivity manipulation variables
    final curam.sample.sl.entity.intf.SampleSportingActivity sampleSportingActivityObj =
      SampleSportingActivityFactory.newInstance();
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    sampleSportingActivityKey.sportingActivityID = evKey.evidenceID;

    final SampleSportingActivityDtls modifiedSportingActivityDtls =
      sampleSportingActivityObj.read(sampleSportingActivityKey);

    // EvidenceDescriptor entity objects
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();

    // If we're in modify or applyChanges mode and child records do exist, we
    // need to validate the parent amount against the sum of the child amounts
    if ((mode.modify || mode.applyChanges || mode.validateChanges)
      && evKeyList.dtls.size() > 1) {

      // SampleSportingActivityExpense manipulation variables
      final SampleSportingActivityExpense sampleSportingActivityExpenseObj =
        SampleSportingActivityExpenseFactory.newInstance();
      final SampleSportingActivityExpenseKey currSportingActivityExpenseKey =
        new SampleSportingActivityExpenseKey();

      Money kSportingActivityExpenseTotal = Money.kZeroMoney;

      // total the actual amounts for all sporting activity expenses
      for (int i = 1; i < evKeyList.dtls.size(); i++) {

        currSportingActivityExpenseKey.sportingActivityExpenseID =
          evKeyList.dtls.item(i).evidenceID;
        final SampleSportingActivityExpenseDtls currSportingActivityExpenseDtls =
          sampleSportingActivityExpenseObj
            .read(currSportingActivityExpenseKey);

        kSportingActivityExpenseTotal =
          new Money(kSportingActivityExpenseTotal.getValue()
            + currSportingActivityExpenseDtls.amount.getValue());
      }

      if (kSportingActivityExpenseTotal.getValue() > 0
        && kSportingActivityExpenseTotal
          .getValue() > modifiedSportingActivityDtls.paymentAmount
            .getValue()) {

        final AppException appException = new AppException(
          ENTSAMPLESPORTINGACTIVITY.ERR_SAMPLESPORTINGACTIVITY_XRV_PAYMENTAMOUNT_TOTALSPORTINGACTIVITYEXPENSEAMOUNT);

        // BEGIN, CR00052924, GM
        if (mode.applyChanges) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().addInfoMgrExceptionWithLookup(appException,
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);

        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager().addInfoMgrExceptionWithLookup(appException,
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kWarning,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }
      }
    }

    // EvidenceDescriptor manipulation variables
    relatedIDAndEvidenceTypeKey.relatedID = evKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = evKey.evidenceType;

    EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj
      .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

    if (mode.applyChanges || mode.validateChanges) {

      // Check that no child records exist if the parent is to be deleted
      if (!evKeyList.dtls.isEmpty()) {

        // If the mode is applyChange and the status is 'Canceled' OR
        // if the mode is validateChanges and the record is pendingRemoval
        if (mode.applyChanges
          && evidenceDescriptorDtls.statusCode
            .equals(EVIDENCEDESCRIPTORSTATUS.CANCELED)
          || mode.validateChanges
            && evidenceDescriptorDtls.pendingRemovalInd == true) {

          final AppException appException = new AppException(
            BPOSAMPLESPORTINGACTIVITY.ERR_SAMPLE_SPORTINGACTIVITY_XRV_SPORTINGACTIVITYEXPENSE_EXISTS);

          if (mode.applyChanges) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().addInfoMgrExceptionWithLookup(appException,
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().addInfoMgrExceptionWithLookup(appException,
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kWarning,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
          }
        }
      }
    }

    // Validate for duplicate records. Only validate if the record is not
    // canceled or pending removal
    if (!(mode.applyChanges && evidenceDescriptorDtls.statusCode
      .equals(EVIDENCEDESCRIPTORSTATUS.CANCELED))
      || mode.validateChanges
        && evidenceDescriptorDtls.pendingRemovalInd == true) {

      final ValidateDuplicateDtls validateDuplicateDtls =
        new ValidateDuplicateDtls();

      validateDuplicateDtls.dtls = modifiedSportingActivityDtls;
      validateDuplicateDtls.caseID = evidenceDescriptorDtls.caseID;
      if (mode.applyChanges) {
        validateDuplicateDtls.validateOnAppliedChangesInd = true;
      } else {
        validateDuplicateDtls.validateOnAppliedChangesInd = false;
      }

      validateDuplicates(validateDuplicateDtls);
    }

    // BEGIN, CR00022287, TV
    // Check the condition, the IC level evidence amount should no be less than
    // PD level evidence amount
    // BEGIN, CR00141891, ELG
    if (mode.applyChanges) {
      // END, CR00141891

      relatedIDAndEvidenceTypeKey.relatedID = evKey.evidenceID;
      relatedIDAndEvidenceTypeKey.evidenceType = evKey.evidenceType;

      evidenceDescriptorDtls = evidenceDescriptorObj
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

      RelatedCasesDetailsList relatedCasesDetailsList =
        new RelatedCasesDetailsList();
      final CaseRelationshipCaseIDKey caseRelationshipCaseIDKey =
        new CaseRelationshipCaseIDKey();

      caseRelationshipCaseIDKey.caseID = evidenceDescriptorDtls.caseID;

      // get all the case relationships for this integrated case
      relatedCasesDetailsList = CaseRelationshipFactory.newInstance()
        .searchCaseRelationshipByCaseID(caseRelationshipCaseIDKey);

      double pDEvidenceamount = 0, ICEvidenceamount = 0;
      CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = null;
      EIEvidenceKeyList eiEvidenceKeyList = null;
      final SportingSponsorshipKey sportingSponsorshipKey =
        new SportingSponsorshipKey();
      SportingSponsorshipDtls sportingSponsorshipDtls =
        new SportingSponsorshipDtls();

      relatedIDAndEvidenceTypeKey.evidenceType =
        CASEEVIDENCE.SPORTINGSPONSORSHIP;
      // Calculate All PD case Sporting Sponsorship Amount
      for (int i = 0; i < relatedCasesDetailsList.dtls.size(); i++) {

        // Return object
        eiEvidenceKeyList = new EIEvidenceKeyList();
        caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();
        caseIDAndEvidenceTypeKey.caseID =
          relatedCasesDetailsList.dtls.item(i).relatedCaseID;
        caseIDAndEvidenceTypeKey.evidenceType =
          CASEEVIDENCE.SPORTINGSPONSORSHIP;

        eiEvidenceKeyList.assign(evidenceDescriptorObj
          .searchAllByTypeForCase(caseIDAndEvidenceTypeKey));

        for (int k = 0; k < eiEvidenceKeyList.dtls.size(); k++) {

          relatedIDAndEvidenceTypeKey.relatedID =
            eiEvidenceKeyList.dtls.item(k).evidenceID;
          relatedIDAndEvidenceTypeKey.evidenceType =
            CASEEVIDENCE.SPORTINGSPONSORSHIP;
          evidenceDescriptorDtls = evidenceDescriptorObj
            .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

          sportingSponsorshipKey.sportingSponsorshipID =
            evidenceDescriptorDtls.relatedID;
          // BEGIN, CR00091163, VM
          sportingSponsorshipDtls = SportingSponsorshipFactory.newInstance()
            .read(sportingSponsorshipKey);
          // END, CR00091163

          // BEGIN, CR00141891, ELG
          if (evidenceDescriptorDtls.evidenceType
            .equals(CASEEVIDENCE.SPORTINGSPONSORSHIP)
            && evidenceDescriptorDtls.statusCode
              .equals(EVIDENCEDESCRIPTORSTATUS.ACTIVE)) {
            // END, CR00141891

            pDEvidenceamount +=
              sportingSponsorshipDtls.sponsorshipAmount.getValue();
          }
        } // end for k
      } // end for i

      final CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = caseRelationshipCaseIDKey.caseID;
      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList =
        evidenceDescriptorObj.searchByCaseID(caseIDKey);

      SampleSportingActivityDtls sampleSportingActivityDtls =
        new SampleSportingActivityDtls();

      for (int k = 0; k < evidenceDescriptorDtlsList.dtls.size(); k++) {

        // BEGIN, CR00141891, ELG
        if (evidenceDescriptorDtlsList.dtls.item(k).evidenceType
          .equals(CASEEVIDENCE.SAMPLESPORTINGACTIVITY)
          && evidenceDescriptorDtlsList.dtls.item(k).statusCode
            .equals(EVIDENCEDESCRIPTORSTATUS.ACTIVE)) {
          // END, CR00141891

          sampleSportingActivityKey.sportingActivityID =
            evidenceDescriptorDtlsList.dtls.item(k).relatedID;
          sampleSportingActivityDtls =
            sampleSportingActivityObj.read(sampleSportingActivityKey);
          ICEvidenceamount +=
            sampleSportingActivityDtls.paymentAmount.getValue();
        }
      } // end for k

      // Check the condition of PD Evidence amount is not Greater than the IC
      // Evidence Amount
      if (ICEvidenceamount < pDEvidenceamount) {

        // BEGIN, CR00141891, ELG
        final AppException appException = new AppException(
          ENTSAMPLESPORTINGSPONSORSHIP.ERR_SAMPLE_SPORTINGSPONSORSHIP_XRV_SORTINACTIVITY_NOT_LAESS_SPONSORSHIP_EVIDENCE);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addInfoMgrExceptionWithLookup(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }

    }
    // END CR00022287
  }

  // ___________________________________________________________________________
  /**
   * Validate for duplicate evidence records
   *
   * @param validateDtls Details to check for duplicate evidence
   */
  @Override
  public void validateDuplicates(final ValidateDuplicateDtls validateDtls)
    throws AppException, InformationalException {

    // Get the informational manager
    final InformationalManager informationalManager =
      TransactionInfo.getInformationalManager();

    // Retrieve all the evidence for this case
    final EvidenceDescriptor evidenceDescriptorObj =
      EvidenceDescriptorFactory.newInstance();
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey =
      new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = validateDtls.caseID;
    caseIDAndEvidenceTypeKey.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    eiEvidenceKeyList.assign(
      evidenceDescriptorObj.searchAllByTypeForCase(caseIDAndEvidenceTypeKey));

    eiEvidenceKeyList = EvidenceControllerFactory.newInstance()
      .filterActiveAndPendingChanges(eiEvidenceKeyList);

    // Retrieve the instanceID of the modified evidence
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey =
      new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;
    relatedIDAndEvidenceTypeKey.relatedID =
      validateDtls.dtls.sportingActivityID;

    final EvidenceDescriptorDtls updatedEvidenceDescriptorDtls =
      evidenceDescriptorObj
        .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();
    SampleSportingActivityDtls sampleSportingActivityDtls;

    // Iterate through the list of evidence to check for duplicates
    for (int i = 0; i < eiEvidenceKeyList.dtls.size(); i++) {

      // Read the details for the current record
      sampleSportingActivityKey.sportingActivityID =
        eiEvidenceKeyList.dtls.item(i).evidenceID;
      sampleSportingActivityDtls = read(sampleSportingActivityKey);

      // Get the instance ID of the current record
      relatedIDAndEvidenceTypeKey.relatedID =
        eiEvidenceKeyList.dtls.item(i).evidenceID;

      final EvidenceDescriptorDtls currentEvidenceDescriptorDtls =
        evidenceDescriptorObj
          .readByRelatedIDAndType(relatedIDAndEvidenceTypeKey);

      // BEGIN, CR00114562, KH
      // If current evidence is In-Edit don't validate against it
      if (currentEvidenceDescriptorDtls.statusCode
        .equals(EVIDENCEDESCRIPTORSTATUS.INEDIT)) {
        continue; // to next 'for i'
      }
      // END, CR00114562

      // Check that the evidence type and case participant match ignoring
      // the record with the same identifier and records with the same
      // SuccessionID
      if (sampleSportingActivityDtls.caseParticipantRoleID == validateDtls.dtls.caseParticipantRoleID
        && sampleSportingActivityDtls.sportingActivityType
          .equals(validateDtls.dtls.sportingActivityType)
        // If the correctionSetID's are equal this is a change of
        // circumstance and the original record will be superseded.
        // Likewise if the successionID's are equal this means both
        // records are in the same succession set. This means that
        // the original record is being cloned. In both cases we can
        // safely ignore these records.
        && !currentEvidenceDescriptorDtls.correctionSetID
          .equals(updatedEvidenceDescriptorDtls.correctionSetID)
        && currentEvidenceDescriptorDtls.successionID != updatedEvidenceDescriptorDtls.successionID) {

        // We have a matching case participant and sample sporting type. Now
        // check if the date periods overlap
        if (validateDtls.dtls.startDate
          .compareTo(sampleSportingActivityDtls.startDate) >= 0
          && validateDtls.dtls.startDate
            .compareTo(sampleSportingActivityDtls.endDate) <= 0

          || validateDtls.dtls.endDate
            .compareTo(sampleSportingActivityDtls.startDate) >= 0
            && validateDtls.dtls.endDate
              .compareTo(sampleSportingActivityDtls.endDate) <= 0) {
          final AppException appException = new AppException(
            ENTSAMPLESPORTINGACTIVITY.ERR_SAMPLE_SPORTINGACTIVITY_XRV_SPORTINGACTIVITY_EXISTS);

          appException.arg(
            // BEGIN, CR00163098, JC
            curam.util.type.CodeTable.getOneItem(
              SAMPLESPORTINGACTIVITYTYPE.TABLENAME,
              validateDtls.dtls.sportingActivityType,
              TransactionInfo.getProgramLocale()));
          // END, CR00163098, JC

          // Retrieve the case participant name
          final CaseParticipantRole caseParticipantRoleObj =
            curam.core.sl.entity.fact.CaseParticipantRoleFactory
              .newInstance();
          final CaseParticipantRoleKey caseParticipantRoleKey =
            new CaseParticipantRoleKey();

          caseParticipantRoleKey.caseParticipantRoleID =
            validateDtls.dtls.caseParticipantRoleID;

          appException.arg(caseParticipantRoleObj
            .readFullName(caseParticipantRoleKey).fullName);

          // If we are validating on Apply Changes throw an error, otherwise
          // throw a warning
          if (validateDtls.validateOnAppliedChangesInd) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().addInfoMgrExceptionWithLookup(appException,
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kError,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory
              .getManager().addInfoMgrExceptionWithLookup(appException,
                CuramConst.gkEmpty,
                InformationalElement.InformationalType.kWarning,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
          }
        }
      }
    } // end for i
  }

  // BEGIN, CR00078469, VM
  // ___________________________________________________________________________
  /**
   * Method that does any entity adjustments for moving the evidence record
   * to a new caseID
   *
   * @param details Contains the evidenceID / evidenceType pairings of the
   * evidence to be transferred and the transferred
   * @param fromCaseKey The case from which the evidence is being transferred
   * @param toCaseKey The case to which the evidence is being transferred
   */
  @Override
  public void transferEvidence(final EvidenceTransferDetails details,
    final CaseHeaderKey fromCaseKey, final CaseHeaderKey toCaseKey)
    throws AppException, InformationalException {

    // Get all the structs need for the operation
    final EIEvidenceKey key = new EIEvidenceKey();

    SampleSportingActivityDtls sampleSportingActivityDtls;
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    CaseParticipantRoleDtls caseParticipantRoleDtls;
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
      new CaseIDParticipantRoleKey();
    CaseParticipantRoleDtlsList caseParicipantRoleDtlsList;

    // Get the caseParticipantRole Obj
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // Read the current Evidence entity details
    key.evidenceID = details.fromEvidenceID;
    key.evidenceType = details.fromEvidenceType;

    sampleSportingActivityDtls =
      (SampleSportingActivityDtls) readEvidence(key);

    // Find the ParticipantRoleID by using the existing CaseParicipantRoleID
    caseParticipantRoleKey.caseParticipantRoleID =
      sampleSportingActivityDtls.caseParticipantRoleID;

    caseParticipantRoleDtls =
      caseParticipantRoleObj.read(caseParticipantRoleKey);

    // Need to search for the CaseParticipantRole that have the to CaseID and
    // the existing ParicipantRoleID there should only be one
    caseIDParticipantRoleKey.caseID = toCaseKey.caseID;
    caseIDParticipantRoleKey.participantRoleID =
      caseParticipantRoleDtls.participantRoleID;

    caseParicipantRoleDtlsList = caseParticipantRoleObj
      .searchByParticipantRoleAndCase(caseIDParticipantRoleKey);

    // Need to update the CaseParticipantRoleID on the new Evidence ID
    // Firstly read the new evidence record to get the details
    key.evidenceID = details.toEvidenceID;
    key.evidenceType = details.toEvidenceType;

    sampleSportingActivityDtls =
      (SampleSportingActivityDtls) readEvidence(key);

    // BEGIN, CR00088251, VM
    // If the list is empty, it means the participant to whom the evidence
    // belongs is not a CPR on the toCase. One possible reason for this is
    // if a Case Member Issue is being created manually for a Member and
    // the evidence linked to the issue is associated with a participant
    // other than that Member. In this instance, we would need to create
    // a new CPR record for the participant linked with the evidence on
    // the Issue Case
    if (caseParicipantRoleDtlsList.dtls.isEmpty()) {

      final CaseParticipantRoleDetails caseParticipantRoleDetails =
        new CaseParticipantRoleDetails();

      caseParticipantRoleDetails.dtls.caseID = toCaseKey.caseID;
      caseParticipantRoleDetails.dtls.participantRoleID =
        caseParticipantRoleDtls.participantRoleID;
      caseParticipantRoleDetails.dtls.fromDate = Date.getCurrentDate();
      caseParticipantRoleDetails.dtls.recordStatus = RECORDSTATUS.NORMAL;
      caseParticipantRoleDetails.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.MEMBER;

      CaseParticipantRoleFactory.newInstance()
        .insertCaseParticipantRole(caseParticipantRoleDetails);

      sampleSportingActivityDtls.caseParticipantRoleID =
        caseParticipantRoleDetails.dtls.caseParticipantRoleID;
    } else {

      // Update the details with the new caseparticipantRoleID and modify the
      // new evidence with this change
      sampleSportingActivityDtls.caseParticipantRoleID =
        caseParicipantRoleDtlsList.dtls.item(0).caseParticipantRoleID;
    }
    // END, CR00088251

    sampleSportingActivityKey.sportingActivityID = details.toEvidenceID;
    modify(sampleSportingActivityKey, sampleSportingActivityDtls);
  }

  // END, CR00078469

  // BEGIN, CR00206664, PB.
  /**
   * Transfers evidence from a remote case to a source case.
   *
   * @param evidenceObject
   * Contains the evidence key value pair object.
   * @param details
   * Contains the evidenceID / evidenceType pairings of the evidence to
   * be transferred and the transferred
   * @param fromCaseKey
   * The case from which the evidence is being transferred
   * @param toCaseKey
   * The case to which the evidence is being transferred
   *
   * * @throws AppException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void transferExternalEvidence(final Object evidenceObject,
    final SharedEvidenceDescriptorDetails descriptorDetails,
    final EvidenceTransferDetails details, final CaseHeaderKey fromCaseKey,
    final CaseHeaderKey toCaseKey)
    throws AppException, InformationalException {

    // Get all the structs need for the operation
    final EIEvidenceKey key = new EIEvidenceKey();

    SampleSportingActivityDtls sampleSportingActivityDtls;
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    final CaseIDParticipantRoleKey caseIDParticipantRoleKey =
      new CaseIDParticipantRoleKey();
    CaseParticipantRoleDtlsList caseParicipantRoleDtlsList;
    final CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    // Need to search for the CaseParticipantRole that have the to CaseID and
    // the existing ParicipantRoleID there should only be one
    caseIDParticipantRoleKey.caseID = toCaseKey.caseID;
    caseIDParticipantRoleKey.participantRoleID =
      descriptorDetails.details.participantID;

    caseParicipantRoleDtlsList = caseParticipantRoleObj
      .searchByParticipantRoleAndCase(caseIDParticipantRoleKey);

    // Need to update the CaseParticipantRoleID on the new Evidence ID
    // Firstly read the new evidence record to get the details
    key.evidenceID = details.toEvidenceID;
    key.evidenceType = details.toEvidenceType;

    sampleSportingActivityDtls =
      (SampleSportingActivityDtls) readEvidence(key);

    if (caseParicipantRoleDtlsList.dtls.isEmpty()) {

      final CaseParticipantRoleDetails caseParticipantRoleDetails =
        new CaseParticipantRoleDetails();

      caseParticipantRoleDetails.dtls.caseID = toCaseKey.caseID;
      caseParticipantRoleDetails.dtls.participantRoleID =
        descriptorDetails.details.participantID;
      caseParticipantRoleDetails.dtls.fromDate = Date.getCurrentDate();
      caseParticipantRoleDetails.dtls.recordStatus = RECORDSTATUS.NORMAL;
      caseParticipantRoleDetails.dtls.typeCode =
        CASEPARTICIPANTROLETYPE.MEMBER;

      CaseParticipantRoleFactory.newInstance()
        .insertCaseParticipantRole(caseParticipantRoleDetails);

      sampleSportingActivityDtls.caseParticipantRoleID =
        caseParticipantRoleDetails.dtls.caseParticipantRoleID;
    } else {

      // Update the details with the new caseparticipantRoleID and modify the
      // new evidence with this change
      sampleSportingActivityDtls.caseParticipantRoleID =
        caseParicipantRoleDtlsList.dtls.item(0).caseParticipantRoleID;
    }

    sampleSportingActivityKey.sportingActivityID = details.toEvidenceID;
    modify(sampleSportingActivityKey, sampleSportingActivityDtls);

  }

  // END, CR00206664.
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(final EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // SampleSportingActivityKey entity key
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Read the SampleSportingActivity entity to retrieve the dates
    sampleSportingActivityKey.sportingActivityID = evKey.evidenceID;
    final SampleSportingActivityDtls sampleSportingActivityDtls =
      read(sampleSportingActivityKey);

    return sampleSportingActivityDtls.endDate;
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(final EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // SampleSportingActivityKey entity key
    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    // Read the SampleSportingActivity entity to retrieve the dates
    sampleSportingActivityKey.sportingActivityID = evKey.evidenceID;
    final SampleSportingActivityDtls sampleSportingActivityDtls =
      read(sampleSportingActivityKey);

    return sampleSportingActivityDtls.startDate;

  }
  // END, CR002204022

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtlsList getCaseParticipantRoles(
    final EIEvidenceKey key) throws AppException, InformationalException {

    final CaseParticipantRoleDtlsList caseParticipantRoleDtlsList =
      new CaseParticipantRoleDtlsList();

    CaseParticipantRoleDtls caseParticipantRoleDtls =
      new CaseParticipantRoleDtls();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();
    final CaseParticipantRole caseParticipantRoleObj =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final SampleSportingActivityDtls evidenceDtls =
      (SampleSportingActivityDtls) readEvidence(key);

    if (evidenceDtls.caseParticipantRoleID != 0L) {

      caseParticipantRoleKey.caseParticipantRoleID =
        evidenceDtls.caseParticipantRoleID;

      caseParticipantRoleDtls =
        caseParticipantRoleObj.read(caseParticipantRoleKey);

      caseParticipantRoleDtlsList.dtls.add(caseParticipantRoleDtls);
    }

    return caseParticipantRoleDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setEndDate(final Object dtls, final Date date)
    throws AppException, InformationalException {

    ((SampleSportingActivityDtls) dtls).endDate = date;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setStartDate(final Object dtls, final Date date)
    throws AppException, InformationalException {

    ((SampleSportingActivityDtls) dtls).startDate = date;
  }
}
