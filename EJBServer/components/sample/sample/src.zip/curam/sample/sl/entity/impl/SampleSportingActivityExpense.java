/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2017. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.SPORTINGACTIVITYEXPTYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.impl.ExternalEvidenceInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.fact.EvidenceRelationshipFactory;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceInterface;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.struct.ChildList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceTransferDetails;
import curam.core.sl.infrastructure.struct.ParentList;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.CaseParticipantRoleDetails;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.message.BPOSAMPLESPORTINGACTIVITYEXPENSE;
import curam.message.ENTSAMPLESPORTINGACTIVITYEXPENSE;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.intf.SampleSportingActivity;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseKey;
import curam.sample.sl.entity.struct.SampleSportingActivityKey;
import curam.sample.sl.entity.struct.ValidateDuplicateSAExpenseDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * Operations for the Sample Sporting Activity Expense entity
 */
public class SampleSportingActivityExpense extends curam.sample.sl.entity.base.SampleSportingActivityExpense implements
  EvidenceInterface, ExternalEvidenceInterface {

  // ___________________________________________________________________________
  /**
   * Calculates the attribution dates
   *
   * @param caseKey
   * @param evKey Key containing the evidenceID and evidenceType
   *
   * @return Attribution details
   */
  @Override
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    // Return object
    final AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // SampleSportingActivityExpenseKey object
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    // Read the SampleSportingActivityExpense entity
    sampleSportingActivityExpenseKey.sportingActivityExpenseID = evKey.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = read(
      sampleSportingActivityExpenseKey);

    attributedDateDetails.fromDate = sampleSportingActivityExpenseDtls.startDate;
    attributedDateDetails.toDate = sampleSportingActivityExpenseDtls.endDate;

    return attributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads details for the list display
   *
   * @param key Key containing the evidenceID and evidenceType
   *
   * @return Details for the list display
   */
  @Override
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // Read the SampleSportingActivityExpense record for the input key
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    sampleSportingActivityExpenseKey.sportingActivityExpenseID = key.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = read(
      sampleSportingActivityExpenseKey);

    // Set the start / end dates
    eiFieldsForListDisplayDtls.startDate = sampleSportingActivityExpenseDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = sampleSportingActivityExpenseDtls.endDate;

    // Set the summary details
    final StringBuffer strBuf = new StringBuffer(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(SPORTINGACTIVITYEXPTYPE.TABLENAME,
      sampleSportingActivityExpenseDtls.sportingExpenseType,
      TransactionInfo.getProgramLocale()));

    // END, CR00163098, JC

    // BEGIN, CR00120110, KH
    strBuf.append(CuramConst.gkSpace).append(
      sampleSportingActivityExpenseDtls.amount);
    // END, CR00120110

    eiFieldsForListDisplayDtls.summary = strBuf.toString();

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new Sample Sporting Activity Expense evidence
   *
   * @param dtls Evidence details
   *
   * @param parentKey Key containing the parent evidence identifier
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // Insert SampleSportingActivityExpense record
    insert((SampleSportingActivityExpenseDtls) dtls);

    eiEvidenceKey.evidenceID = ((SampleSportingActivityExpenseDtls) dtls).sportingActivityExpenseID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts a Sample Sporting Activity Expense evidence during the modify
   * process
   *
   * @param dtls Evidence details
   *
   * @param origKey Key containing the original evidence identifier
   * @param parentKey Key containing the parent evidence identifier
   * @return Key containing the evidenceID and evidenceType
   */
  @Override
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // Insert SampleSportingActivityExpense record
    insert((SampleSportingActivityExpenseDtls) dtls);

    eiEvidenceKey.evidenceID = ((SampleSportingActivityExpenseDtls) dtls).sportingActivityExpenseID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Sample Sporting Activity Expense evidence
   *
   * @param key Key containing the evidence identifier
   * @param dtls Evidence details
   */
  @Override
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // SampleSportingActivityExpenseKey object
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    // Set key to modify details
    sampleSportingActivityExpenseKey.sportingActivityExpenseID = key.evidenceID;

    modify(sampleSportingActivityExpenseKey,
      (SampleSportingActivityExpenseDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * Read all Sample Sporting Activity Expense records
   *
   * @param key Contains the evidenceID and evidenceType
   *
   * @return A list of evidenceID and evidenceType pairs
   */
  @Override
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // EvidenceRelationship entity object
    final ChildList childList = EvidenceRelationshipFactory.newInstance().getChildKeyList(
      key);

    for (int i = 0; i < childList.list.dtls.size(); i++) {

      final EIEvidenceKey listEvidenceKey = new EIEvidenceKey();

      listEvidenceKey.evidenceID = childList.list.dtls.item(i).childID;
      listEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

      eiEvidenceKeyList.dtls.addRef(listEvidenceKey);
    }

    return eiEvidenceKeyList;
  }

  // ___________________________________________________________________________
  /**
   * Reads a Sample Sporting Activity Expense evidence
   *
   * @param key Key containing the evidence identifier
   *
   * @return Object containing the evidence details
   */
  @Override
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // SampleSportingActivityExpenseKey object
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    // Reads Sample Sporting Activity Expense details
    sampleSportingActivityExpenseKey.sportingActivityExpenseID = key.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = read(
      sampleSportingActivityExpenseKey);

    return sampleSportingActivityExpenseDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Grant Expense details
   *
   * @param details Sample Sporting Grant Expense details
   */
  @Override
  protected void preinsert(SampleSportingActivityExpenseDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies Sample Sporting Grant Expense details
   *
   * @param key Sample Sporting Grant Expense key
   * @param details Sample Sporting Grant Expense details to be modified
   */
  @Override
  protected void premodify(SampleSportingActivityExpenseKey key,
    SampleSportingActivityExpenseDtls details) throws AppException,
      InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates Sample Sporting Grant Expense entity details
   *
   * @param details Sample Sporting Grant Expense details
   */
  @Override
  public void validate(SampleSportingActivityExpenseDtls details)
    throws AppException, InformationalException {

    // A positive amount must be entered
    if (details.amount.isNegative()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAE_FV_AMOUNT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // End date must not be earlier than the start date
    if (!details.startDate.isZero() && !details.endDate.isZero()) {

      if (details.endDate.before(details.startDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAE_XFV_END_DATE_BEFORE_START_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // The expense type must be specified
    if (details.sportingExpenseType.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAE_FV_EXPENSE_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    final SampleSportingActivity sampleSportingActivityObj = SampleSportingActivityFactory.newInstance();
    final SampleSportingActivityKey sampleSportingActivityKey = new SampleSportingActivityKey();

    sampleSportingActivityKey.sportingActivityID = details.sportingActivityID;

    final SampleSportingActivityDtls sampleSportingActivityDtls = sampleSportingActivityObj.read(
      sampleSportingActivityKey);

    // Start Date must not be before start date of parent
    if (!details.startDate.isZero()
      && !sampleSportingActivityDtls.startDate.isZero()) {

      if (details.startDate.before(sampleSportingActivityDtls.startDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAE_XFV_START_DATE_BEFORE_PARENT_START_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // End Date must not be after end date of parent
    if (!details.endDate.isZero()
      && !sampleSportingActivityDtls.endDate.isZero()) {

      if (details.endDate.after(sampleSportingActivityDtls.endDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAE_XFV_END_DATE_AFTER_PARENT_END_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  @Override
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // EvidenceController objects
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final ParentList parentList = EvidenceRelationshipFactory.newInstance().getParentKeyList(
      evKey);

    for (int i = 0; i < parentList.list.dtls.size(); i++) {

      final EIEvidenceKey listEvidenceKey = new EIEvidenceKey();

      listEvidenceKey.evidenceID = parentList.list.dtls.item(i).parentID;
      listEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

      eiEvidenceKeyList.dtls.addRef(listEvidenceKey);
    }

    // Filter down the list to only contain active and edit records where
    // these records are pending removal or pending update
    eiEvidenceKeyList = evidenceControllerObj.filterActiveAndPendingChanges(
      eiEvidenceKeyList);

    if (eiEvidenceKeyList.dtls.isEmpty()) {

      // No Active parent. This is not an error so just return.
      return eiEvidenceKeyList;

    } else if (eiEvidenceKeyList.dtls.size() > 1) {

      // Check to ensure all parents are in the same succession set.
      evidenceControllerObj.checkActiveParentsInSameSuccessionSet(
        eiEvidenceKeyList);

    }

    final EIEvidenceKey parentEvidenceKey = eiEvidenceKeyList.dtls.item(0);

    // Get the list of SampleSportingActivityExpense for SampleSportingActivity
    eiEvidenceKeyList = readAllByParentID(parentEvidenceKey);

    // Add the parent to the start of the list
    eiEvidenceKeyList.dtls.add(0, parentEvidenceKey);

    return eiEvidenceKeyList;
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey Evidence key
   * @param evKeyList Evidence key list
   * @param mode Validate mode (insert, applyChanges, modify, validateChanges)
   */
  @Override
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {

    // Get the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (mode.applyChanges || mode.insert || mode.modify || mode.validateChanges) {

      if (evKeyList.dtls.size() > 1) {

        // SampleSportingActivity entity objects
        final SampleSportingActivity sampleSportingActivityObj = SampleSportingActivityFactory.newInstance();
        final SampleSportingActivityKey sampleSportingActivityKey = new SampleSportingActivityKey();

        sampleSportingActivityKey.sportingActivityID = evKeyList.dtls.item(0).evidenceID;

        final SampleSportingActivityDtls sampleSportingActivityDtls = sampleSportingActivityObj.read(
          sampleSportingActivityKey);

        Money kSportingActivityExpenseTotal = Money.kZeroMoney;

        for (int i = 1; i < evKeyList.dtls.size(); i++) {

          // Read the amount from current SportingActivityExpense
          final SampleSportingActivityExpenseKey currSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

          currSportingActivityExpenseKey.sportingActivityExpenseID = evKeyList.dtls.item(i).evidenceID;
          final SampleSportingActivityExpenseDtls currSportingActivityExpenseDtls = read(
            currSportingActivityExpenseKey);

          kSportingActivityExpenseTotal = new Money(
            kSportingActivityExpenseTotal.getValue()
              + currSportingActivityExpenseDtls.amount.getValue());
        }

        if (kSportingActivityExpenseTotal.getValue()
          > sampleSportingActivityDtls.paymentAmount.getValue()) {

          final AppException appException = new AppException(
            ENTSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAMPLESPORTINGACTIVITYEXPENSE_XRV_TOTALAMOUNT_SPORTINGACTIVITYPAYMENTAMOUNT);

          if (mode.applyChanges) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
              appException, CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
              appException, CuramConst.gkEmpty,
              InformationalElement.InformationalType.kWarning,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
          }
        }
      }
    }
    //
    // Validate for duplicate records. Only validate if the record is not
    // canceled or pending removal
    //

    // EvidenceDescriptor manipulation variables
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = evKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = evKey.evidenceType;

    final EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
      relatedIDAndEvidenceTypeKey);

    // SampleSportingActivityExpense manipulation variables
    final curam.sample.sl.entity.intf.SampleSportingActivityExpense sampleSportingActivityExpenseObj = SampleSportingActivityExpenseFactory.newInstance();

    final SampleSportingActivityExpenseKey currSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    currSportingActivityExpenseKey.sportingActivityExpenseID = evKey.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = sampleSportingActivityExpenseObj.read(
      currSportingActivityExpenseKey);

    if (!(mode.applyChanges
      && evidenceDescriptorDtls.statusCode.equals(
        EVIDENCEDESCRIPTORSTATUS.CANCELED))
          || mode.validateChanges
            && evidenceDescriptorDtls.pendingRemovalInd == true) {

      final ValidateDuplicateSAExpenseDtls validateDuplicateSAExpenseDtls = new ValidateDuplicateSAExpenseDtls();

      validateDuplicateSAExpenseDtls.dtls = sampleSportingActivityExpenseDtls;
      validateDuplicateSAExpenseDtls.caseID = evidenceDescriptorDtls.caseID;
      if (mode.applyChanges) {
        validateDuplicateSAExpenseDtls.validateOnAppliedChangesInd = true;
      } else {
        validateDuplicateSAExpenseDtls.validateOnAppliedChangesInd = false;
      }

      validateDuplicates(validateDuplicateSAExpenseDtls);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validate for duplicate evidence records
   *
   * @param validateDtls Details to check for duplicate evidence
   */
  @Override
  public void validateDuplicates(ValidateDuplicateSAExpenseDtls validateDtls)
    throws AppException, InformationalException {

    // Get the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Retrieve evidence for this case
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = validateDtls.caseID;
    caseIDAndEvidenceTypeKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    eiEvidenceKeyList.assign(
      evidenceDescriptorObj.searchAllByTypeForCase(caseIDAndEvidenceTypeKey));

    final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    eiEvidenceKeyList = evidenceControllerObj.filterActiveAndPendingChanges(
      eiEvidenceKeyList);

    // Retrieve the instanceID of the modified evidence
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;
    relatedIDAndEvidenceTypeKey.relatedID = validateDtls.dtls.sportingActivityExpenseID;

    final EvidenceDescriptorDtls updatedEvidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
      relatedIDAndEvidenceTypeKey);

    // Iterate through the list of evidence to check for duplicates
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();
    SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls;

    for (int i = 0; i < eiEvidenceKeyList.dtls.size(); i++) {

      // Read the details for the current record
      sampleSportingActivityExpenseKey.sportingActivityExpenseID = eiEvidenceKeyList.dtls.item(i).evidenceID;
      sampleSportingActivityExpenseDtls = read(sampleSportingActivityExpenseKey);

      // Get the instance ID of the current record
      relatedIDAndEvidenceTypeKey.relatedID = eiEvidenceKeyList.dtls.item(i).evidenceID;
      final EvidenceDescriptorDtls currentEvidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
        relatedIDAndEvidenceTypeKey);

      final CaseParticipantRoleDetails caseParticipantRoleDetailsA = new CaseParticipantRoleDetails();
      final CaseParticipantRoleDetails caseParticipantRoleDetailsB = new CaseParticipantRoleDetails();

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = validateDtls.dtls.sportingActivityExpenseID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

      ParentList parentList = EvidenceRelationshipFactory.newInstance().getParentKeyList(
        eiEvidenceKey);

      // Check to ensure elements present in list before accessing
      if (parentList.list.dtls.size() != 0) {

        // Assign value to key
        sampleSportingActivityExpenseKey.sportingActivityExpenseID = validateDtls.dtls.sportingActivityExpenseID;

        // Create SampleSportingActivity key
        final SampleSportingActivityKey sampleSportingActivityKey = new SampleSportingActivityKey();

        // Retrieve SampleSportingActivityID
        sampleSportingActivityKey.sportingActivityID = parentList.list.dtls.item(0).parentID;

        // Read SampleSportingActivity table for related caseParticipantRoleID
        // and assign it to first comparison struct
        caseParticipantRoleDetailsA.dtls.caseParticipantRoleID = SampleSportingActivityFactory.newInstance().read(sampleSportingActivityKey).caseParticipantRoleID;

        // Assign second value to key
        sampleSportingActivityExpenseKey.sportingActivityExpenseID = sampleSportingActivityExpenseDtls.sportingActivityExpenseID;

        eiEvidenceKey.evidenceID = sampleSportingActivityExpenseDtls.sportingActivityExpenseID;
        eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

        parentList = EvidenceRelationshipFactory.newInstance().getParentKeyList(
          eiEvidenceKey);

        // Check to ensure elements present in list before accessing
        if (parentList.list.dtls.size() != 0) {

          // Read SampleSportingActivityID
          sampleSportingActivityKey.sportingActivityID = parentList.list.dtls.item(0).parentID;

          // Read SampleSportingActivity table for related caseParticipantRoleID
          // and assign it to second comparison struct
          caseParticipantRoleDetailsB.dtls.caseParticipantRoleID = SampleSportingActivityFactory.newInstance().read(sampleSportingActivityKey).caseParticipantRoleID;

          // Check the case participant match ignoring
          // the record with the same identifier
          if (caseParticipantRoleDetailsA.dtls.caseParticipantRoleID
            == caseParticipantRoleDetailsB.dtls.caseParticipantRoleID
              && sampleSportingActivityExpenseDtls.sportingExpenseType.equals(
                validateDtls.dtls.sportingExpenseType)
                && sampleSportingActivityExpenseDtls.sportingActivityID
                  == validateDtls.dtls.sportingActivityID
                  // If the correctionSetID's are equal this is a change of
                  // circumstance and the original record will be superseded.
                  // Likewise if the successionID's are equal this means both
                  // records are in the same succession set. This means that
                  // the original record is being cloned. In both cases we can
                  // safely ignore these records.
                  && !currentEvidenceDescriptorDtls.correctionSetID.equals(
                    updatedEvidenceDescriptorDtls.correctionSetID)
                    && currentEvidenceDescriptorDtls.successionID
                      != updatedEvidenceDescriptorDtls.successionID) {

            if (validateDtls.dtls.startDate.compareTo(
              sampleSportingActivityExpenseDtls.startDate)
                >= 0
                  && validateDtls.dtls.startDate.compareTo(
                    sampleSportingActivityExpenseDtls.endDate)
                      <= 0
                        || validateDtls.dtls.endDate.compareTo(
                          sampleSportingActivityExpenseDtls.startDate)
                            >= 0
                              && validateDtls.dtls.endDate.compareTo(
                                sampleSportingActivityExpenseDtls.endDate)
                                  <= 0) {

              final AppException appException = new AppException(
                ENTSAMPLESPORTINGACTIVITYEXPENSE.ERR_SAMPLESPORTINGACTIVITYEXPENSE_XRV_SPORTINGACTIVITY_EXISTS);

              appException.arg(
                // BEGIN, CR00163098, JC
                CodeTable.getOneItem(SPORTINGACTIVITYEXPTYPE.TABLENAME,
                validateDtls.dtls.sportingExpenseType,
                TransactionInfo.getProgramLocale()));
              // END, CR00163098, JC

              // Retrieve the case participant name
              final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
              final CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

              caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleDetailsA.dtls.caseParticipantRoleID;

              appException.arg(
                caseParticipantRoleObj.readFullName(caseParticipantRoleKey).fullName);

              // If we are validating on Apply Changes throw an error, otherwise
              // throw a warning
              if (validateDtls.validateOnAppliedChangesInd) {
                // BEGIN, CR00052924, GM

                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
                  appException, CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  1);
              } else {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
                  appException, CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kWarning,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
              }

            }

          }
        }
      }
    }

  }

  // BEGIN, CR00078469, VM
  // ___________________________________________________________________________
  /**
   * Method that does any entity adjustments for moving the evidence record
   * to a new caseID
   *
   * @param details Contains the evidenceID / evidenceType pairings of the
   * evidence to be transferred and the transferred
   * @param fromCaseKey The case from which the evidence is being transferred
   * @param toCaseKey The case to which the evidence is being transferred
   */
  @Override
  public void transferEvidence(EvidenceTransferDetails details,
    CaseHeaderKey fromCaseKey, CaseHeaderKey toCaseKey) throws AppException,
      InformationalException {// Insert transfer evidence implementation here.
  }

  // END, CR00078469

  // BEGIN, CR00206664, PB.
  /**
   * Transfers evidence from a remote case to a source case.
   *
   * @param evidenceObject
   * Contains the evidence key value pair object.
   * @param descriptorDetails
   * @param details
   * Contains the evidenceID / evidenceType pairings of the evidence to
   * be transferred and the transferred
   * @param fromCaseKey
   * The case from which the evidence is being transferred
   * @param toCaseKey
   * The case to which the evidence is being transferred
   *
   * * @throws AppException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void transferExternalEvidence(final Object evidenceObject,
    final SharedEvidenceDescriptorDetails descriptorDetails,
    final EvidenceTransferDetails details, final CaseHeaderKey fromCaseKey,
    final CaseHeaderKey toCaseKey) throws AppException,
      InformationalException {// Insert external evidence implementation as
    // required
  }

  // END, CR00206664.
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // SampleSportingActivityExpenseKey object
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    // Read the SampleSportingActivityExpense entity
    sampleSportingActivityExpenseKey.sportingActivityExpenseID = evKey.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = read(
      sampleSportingActivityExpenseKey);

    return sampleSportingActivityExpenseDtls.endDate;
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence
   * infrastructure
   *
   * @param evKey The evidence key.
   */
  @Override
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {

    // SampleSportingActivityExpenseKey object
    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();

    // Read the SampleSportingActivityExpense entity
    sampleSportingActivityExpenseKey.sportingActivityExpenseID = evKey.evidenceID;
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls = read(
      sampleSportingActivityExpenseKey);

    return sampleSportingActivityExpenseDtls.startDate;
  }
  // END, CR002204022

  /**
   * {@inheritDoc}
   */
  @Override
  public CaseParticipantRoleDtlsList getCaseParticipantRoles(
    final EIEvidenceKey key) throws AppException, InformationalException {

    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = new CaseParticipantRoleDtlsList();
    
    return caseParticipantRoleDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setEndDate(final Object dtls, final Date date)
    throws AppException, InformationalException {
    ((SampleSportingActivityExpenseDtls) dtls).endDate = date;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setStartDate(final Object dtls, final Date date)
    throws AppException, InformationalException {
    ((SampleSportingActivityExpenseDtls) dtls).startDate = date;
  }
}
