/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;


import curam.codetable.CASEEVIDENCE;
import curam.core.sl.infrastructure.impl.Evidence2CompareMap;
import curam.core.sl.infrastructure.impl.Evidence2CompareRegistrar;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceEntityRegistrar;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.sample.facade.fact.SampleMaintainSportingActivityExpenseFactory;
import curam.sample.facade.fact.SampleMaintainSportingActivityFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.fact.SportingSponsorshipFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


// BEGIN, CR00223990, EC
// BEGIN, CR00199182, GYH
/**
 * Sample Sporting Grant Evidence Registrar implementation. Registrars must
 * implement the EvidenceEntityRegistrar
 * interface.
 *
 * @deprecated Since Curam 6.0, replaced with
 * {@link curam.sample.impl.SampleRegistrarModule}. Note that this approach to
 * evidence registration has been deprecated.
 * See release note <CEF-586> for details.
 *
 * The new approach is used for most sample evidence registrations. See module
 * {@link curam.sample.impl.SampleRegistrarModule} for these registrations
 *
 * However, the old approach to registration is maintained for
 * SAMPLESPORTINGACTIVITY , SAMPLESPORTINGACTIVITYEXPENSE and
 * SPORTINGSPONSORSHIP in sample in order to ensure that it still works
 * correctly.
 */
// END, CR00199182
// END, CR00223990, EC
@Deprecated
public class SampleSportingGrantEvidenceRegistrar extends curam.sample.sl.base.SampleSportingGrantEvidenceRegistrar
  // BEGIN, CR00120297, CD
  implements EvidenceEntityRegistrar, Evidence2CompareRegistrar {

  @Override
  public void registerEvidence2Compare() throws AppException,
      InformationalException {

    final Evidence2CompareMap map = EvidenceController.getEvidence2CompareMap();

    map.putEvidenceType(CASEEVIDENCE.SAMPLESPORTINGACTIVITY,
      SampleMaintainSportingActivityFactory.class);
    map.putEvidenceType(CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE,
      SampleMaintainSportingActivityExpenseFactory.class);
    map.putEvidenceType(CASEEVIDENCE.SPORTINGSPONSORSHIP,
      curam.sample.facade.fact.SportingSponsershipFactory.class);

  }

  // END, CR00120297

  /**
   * Inherited from EvidenceEntityRegistrar interface. Must be implemented
   * by all evidence entity registrars.
   */
  @Override
  public void register() throws AppException, InformationalException {

    final EvidenceMap map = EvidenceController.getEvidenceMap();

    map.putEvidenceType(CASEEVIDENCE.SAMPLESPORTINGACTIVITY,
      SampleSportingActivityFactory.class);
    map.putEvidenceType(CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE,
      SampleSportingActivityExpenseFactory.class);

    // BEGIN, CR00022287, TV
    map.putEvidenceType(CASEEVIDENCE.SPORTINGSPONSORSHIP,
      SportingSponsorshipFactory.class);
    // END CR00022287

  }

}
