/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.core.sl.entity.fact.ClientInteractionFactory;
import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.ClientInteractionKey;
import curam.core.sl.entity.struct.InteractionCommentsDetails;
import curam.core.sl.entity.struct.InteractionCommentsKey;
import curam.core.sl.entity.struct.InteractionDetailsList;
import curam.core.sl.entity.struct.ListInteractionKey;
import curam.core.sl.entity.struct.ReadInteractionHomePageKey;
import curam.core.sl.entity.struct.ReadPersonInteractionHomePageDtls;
import curam.sample.sl.entity.struct.InteractionDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class acts as a wrapper for the Client Interaction entity that has
 * been moved into core. Its existence is to minimize impact on those customers
 * who have referenced it in their custom code.
 */
public class ClientInteraction extends curam.sample.sl.entity.base.ClientInteraction {

  // ___________________________________________________________________________
  /**
   * Inserts Client Interaction details.
   *
   * @param dtls Client Interaction details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#insert(ClientInteractionDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void insert(
    final curam.sample.sl.entity.struct.ClientInteractionDtls dtls)
    throws AppException, InformationalException {

    final ClientInteractionDtls clientInteractionDtls = new ClientInteractionDtls();

    clientInteractionDtls.clientInteractionID = dtls.clientInteractionID;
    clientInteractionDtls.comments = dtls.comments;
    clientInteractionDtls.description = dtls.description;
    clientInteractionDtls.concernRoleID = dtls.concernRoleID;
    clientInteractionDtls.relatedID = dtls.relatedID;
    clientInteractionDtls.relatedType = dtls.relatedType;
    clientInteractionDtls.interactionTypeCode = dtls.interactionTypeCode;
    clientInteractionDtls.interactionDateTime = dtls.interactionDateTime;

    ClientInteractionFactory.newInstance().insert(clientInteractionDtls);
  }

  // ___________________________________________________________________________
  /**
   * Insert client interaction comments.
   *
   * @param key Interaction Comments key.
   * @param details Interaction Comment details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.impl.ClientInteraction#insertComments(InteractionCommentsKey, InteractionCommentsDetails)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void insertComments(
    final curam.sample.sl.entity.struct.InteractionCommentsKey key,
    final curam.sample.sl.entity.struct.InteractionCommentsDetails details)
    throws AppException, InformationalException {

    final InteractionCommentsKey interactionCommentsKey = new InteractionCommentsKey();
    final InteractionCommentsDetails interactionCommentsDetails = new InteractionCommentsDetails();

    // Set key
    interactionCommentsKey.clientInteractionID = key.clientInteractionID;

    // Set details
    interactionCommentsDetails.comments = details.comments;
    interactionCommentsDetails.versionNo = details.versionNo;

    ClientInteractionFactory.newInstance().modifyComments(
      interactionCommentsKey, interactionCommentsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Lists interaction details for a concern.
   *
   * @superseded - replaced by searchByConcernRole (since v5.0)
   * @param key Contains a concern role identifier.
   *
   * @return List of interaction details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.impl.ClientInteraction#list(ListInteractionKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public curam.sample.sl.entity.struct.InteractionDetailsList list(
    final curam.sample.sl.entity.struct.ListInteractionKey key)
    throws AppException, InformationalException {

    // Return object
    final curam.sample.sl.entity.struct.InteractionDetailsList detailsList = new curam.sample.sl.entity.struct.InteractionDetailsList();

    // Set key to read Interaction Details
    final ListInteractionKey listInteractionKey = new ListInteractionKey();

    listInteractionKey.concernRoleID = key.concernRoleID;

    final InteractionDetailsList list = ClientInteractionFactory.newInstance().searchByConcernRole(
      listInteractionKey);

    for (int i = 0; i < list.dtls.size(); i++) {

      final InteractionDetails details = new InteractionDetails();

      details.clientInteractionID = list.dtls.item(i).clientInteractionID;
      details.interactionDateTime = list.dtls.item(i).interactionDateTime;
      details.interactionTypeCode = list.dtls.item(i).interactionTypeCode;
      details.relatedID = list.dtls.item(i).relatedID;
      details.relatedType = list.dtls.item(i).relatedType;

      detailsList.dtls.addRef(details);
    }

    return detailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies interaction details.
   *
   * @parm dtls Client Interaction details.
   *
   * @param key Client Interaction key.
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#modify(ClientInteractionKey, ClientInteractionDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void modify(
    final curam.sample.sl.entity.struct.ClientInteractionKey key,
    final curam.sample.sl.entity.struct.ClientInteractionDtls dtls)
    throws AppException, InformationalException {

    final ClientInteractionKey clientInteractionKey = new ClientInteractionKey();
    final ClientInteractionDtls clientInteractionDtls = new ClientInteractionDtls();

    // Set key details
    clientInteractionKey.clientInteractionID = key.clientInteractionID;

    // Set details
    clientInteractionDtls.clientInteractionID = dtls.clientInteractionID;
    clientInteractionDtls.comments = dtls.comments;
    clientInteractionDtls.concernRoleID = dtls.concernRoleID;
    clientInteractionDtls.description = dtls.description;
    clientInteractionDtls.interactionDateTime = dtls.interactionDateTime;
    clientInteractionDtls.relatedID = dtls.relatedID;
    clientInteractionDtls.relatedType = dtls.relatedType;

    ClientInteractionFactory.newInstance().modify(clientInteractionKey,
      clientInteractionDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the comments for an interaction.
   *
   * @param key Interaction Comments key.
   * @param details Interaction Comment Details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#modifyComments(InteractionCommentsKey, InteractionCommentsDetails)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void modifyComments(
    final curam.sample.sl.entity.struct.InteractionCommentsKey key,
    final curam.sample.sl.entity.struct.InteractionCommentsDetails details)
    throws AppException, InformationalException {

    final InteractionCommentsKey interactionCommentsKey = new InteractionCommentsKey();
    final InteractionCommentsDetails interactionCommentsDetails = new InteractionCommentsDetails();

    // Set key details
    interactionCommentsKey.clientInteractionID = key.clientInteractionID;

    // Set details
    interactionCommentsDetails.comments = details.comments;
    interactionCommentsDetails.versionNo = details.versionNo;

    ClientInteractionFactory.newInstance().modifyComments(
      interactionCommentsKey, interactionCommentsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads Client Interaction Details.
   *
   * @param key Client Interaction key.
   *
   * @return Client Interaction details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#read(ClientInteractionKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public curam.sample.sl.entity.struct.ClientInteractionDtls read(
    final curam.sample.sl.entity.struct.ClientInteractionKey key)
    throws AppException, InformationalException {

    // Return object
    final curam.sample.sl.entity.struct.ClientInteractionDtls clientInteractionDtls = new curam.sample.sl.entity.struct.ClientInteractionDtls();

    final ClientInteractionKey clientInteractionKey = new ClientInteractionKey();

    clientInteractionKey.clientInteractionID = key.clientInteractionID;

    final ClientInteractionDtls details = ClientInteractionFactory.newInstance().read(
      clientInteractionKey);

    // Map details
    clientInteractionDtls.clientInteractionID = details.clientInteractionID;
    clientInteractionDtls.comments = details.comments;
    clientInteractionDtls.concernRoleID = details.concernRoleID;
    clientInteractionDtls.description = details.description;
    clientInteractionDtls.interactionDateTime = details.interactionDateTime;
    clientInteractionDtls.interactionTypeCode = details.interactionTypeCode;
    clientInteractionDtls.relatedID = details.relatedID;
    clientInteractionDtls.relatedType = details.relatedType;

    return clientInteractionDtls;
  }

  // ___________________________________________________________________________
  /**
   * Reads Person Interaction Home Page Details.
   *
   * @param key Read Interaction Home Page key details.
   *
   * @return Person Interaction Home Page details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#readPersonInteractionHomePage(ReadInteractionHomePageKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public curam.sample.sl.entity.struct.ReadPersonInteractionHomePageDtls readPersonInteractionHomePage(
    final curam.sample.sl.entity.struct.ReadInteractionHomePageKey key)
    throws AppException, InformationalException {

    final curam.sample.sl.entity.struct.ReadPersonInteractionHomePageDtls homePageDtls = new curam.sample.sl.entity.struct.ReadPersonInteractionHomePageDtls();

    final ReadInteractionHomePageKey readInteractionHomePageKey = new ReadInteractionHomePageKey();

    // Set key details
    readInteractionHomePageKey.participantID = key.participantID;

    final ReadPersonInteractionHomePageDtls details = ClientInteractionFactory.newInstance().readPersonInteractionHomePage(
      readInteractionHomePageKey);

    // Map details
    homePageDtls.concernRoleName = details.concernRoleName;
    homePageDtls.dateOfBirth = details.dateOfBirth;
    homePageDtls.gender = details.gender;
    homePageDtls.primaryAddressID = details.primaryAddressID;
    homePageDtls.primaryAlternateID = details.primaryAlternateID;
    homePageDtls.primaryPhoneNumberID = details.primaryPhoneNumberID;

    return homePageDtls;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of client interaction details for a concern.
   *
   * @param key Contains a concern role identifier.
   *
   * @return List of client interaction details.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.entity.intf.ClientInteraction#searchByConcernRole(ListInteractionKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Client Interaction entity has been moved into core. See release note
   * CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public curam.sample.sl.entity.struct.InteractionDetailsList searchByConcernRole(
    final curam.sample.sl.entity.struct.ListInteractionKey key)
    throws AppException, InformationalException {

    // Return object
    final curam.sample.sl.entity.struct.InteractionDetailsList detailsList = new curam.sample.sl.entity.struct.InteractionDetailsList();

    final ListInteractionKey listInteractionKey = new ListInteractionKey();

    // Set key details
    listInteractionKey.concernRoleID = key.concernRoleID;

    final InteractionDetailsList list = ClientInteractionFactory.newInstance().searchByConcernRole(
      listInteractionKey);

    for (int i = 0; i < list.dtls.size(); i++) {

      final InteractionDetails details = new InteractionDetails();

      details.clientInteractionID = list.dtls.item(i).clientInteractionID;
      details.interactionDateTime = list.dtls.item(i).interactionDateTime;
      details.interactionTypeCode = list.dtls.item(i).interactionTypeCode;
      details.relatedID = list.dtls.item(i).relatedID;
      details.relatedType = list.dtls.item(i).relatedType;

      detailsList.dtls.addRef(details);
    }

    return detailsList;
  }

}
