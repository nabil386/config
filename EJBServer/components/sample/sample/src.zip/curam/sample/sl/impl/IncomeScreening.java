/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003, 2007, 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;


import curam.core.impl.CuramConst;
import curam.core.sl.fact.SpecialCautionFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.intf.SpecialCaution;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CreateStandardManualTaskDetails;
import curam.core.sl.struct.SpecialCautionConcernKey;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressForConcernRoleKey;
import curam.core.struct.AssessmentConfigurationKey;
import curam.core.struct.AssessmentDtls;
import curam.core.struct.AssessmentDtlsList;
import curam.core.struct.AssessmentKey;
import curam.core.struct.AssessmentNameStruct;
import curam.core.struct.AssessmentObjectiveDtlsList;
import curam.core.struct.AssessmentObjectiveReadmultiKey;
import curam.core.struct.AssessmentReadmultiKey;
import curam.core.struct.CaseEvidenceAndTypeDetails;
import curam.core.struct.CaseEvidenceLinkDtls;
import curam.core.struct.CaseEvidenceLinkDtlsList;
import curam.core.struct.CaseEvidenceReadNearestEvidenceByTypeKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CommunicationDetails;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.EvidenceTypeAndCETypeIDKey;
import curam.core.struct.ListUsersKey_bo;
import curam.core.struct.MaintainActivityDetails;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainCommunicationKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.core.struct.ProspectPersonDtls;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.ReadConcernRoleAddressKey;
import curam.core.struct.ReadConcernRolePhoneKey;
import curam.core.struct.RemoveByEvidenceIDTypeAndRelatedIDKey;
import curam.core.struct.SearchForAltIDKey;
import curam.core.struct.SearchUserByDateRangeResult;
import curam.core.struct.UserActivitySearchKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.pdc.fact.PDCAddressFactory;
import curam.pdc.fact.PDCPhoneNumberFactory;
import curam.pdc.intf.PDCPhoneNumber;
import curam.pdc.struct.ParticipantAddressDetails;
import curam.pdc.struct.ParticipantPhoneDetails;
import curam.sample.sl.entity.struct.FSHholdBenefitKey;
import curam.sample.sl.entity.struct.FSHholdEvidenceKey;
import curam.sample.sl.entity.struct.FSHholdExpenseKey;
import curam.sample.sl.entity.struct.FSHholdIncomeKey;
import curam.sample.sl.entity.struct.FSHholdResourceKey;
import curam.sample.sl.entity.struct.FSHouseholdBenefitsDtls;
import curam.sample.sl.entity.struct.FSHouseholdBenefitsKey;
import curam.sample.sl.entity.struct.FSHouseholdEvidenceDtls;
import curam.sample.sl.entity.struct.FSHouseholdEvidenceKey;
import curam.sample.sl.entity.struct.FSHouseholdExpensesDtls;
import curam.sample.sl.entity.struct.FSHouseholdExpensesKey;
import curam.sample.sl.entity.struct.FSHouseholdIncomeDtls;
import curam.sample.sl.entity.struct.FSHouseholdIncomeKey;
import curam.sample.sl.entity.struct.FSHouseholdResourcesDtls;
import curam.sample.sl.entity.struct.FSHouseholdResourcesKey;
import curam.sample.sl.entity.struct.FSHouseholdSize;
import curam.sample.sl.entity.struct.FSIncomeLimitsDtls;
import curam.sample.sl.entity.struct.FSIncomeLimitsKey;
import curam.sample.sl.entity.struct.FSStatusCodeVersNo;
import curam.sample.sl.struct.AssessmentInfoDtls;
import curam.sample.sl.struct.AssessmentInfoKey;
import curam.sample.sl.struct.AssessmentResultText;
import curam.sample.sl.struct.CalculateIncomeDtls;
import curam.sample.sl.struct.CalculateIncomeKey;
import curam.sample.sl.struct.CaseHomeKey;
import curam.sample.sl.struct.CaseMemberDetails;
import curam.sample.sl.struct.CreateAppointmentDetails;
import curam.sample.sl.struct.CreateBfitEvidenceDtls;
import curam.sample.sl.struct.CreateExpEvidenceDtls;
import curam.sample.sl.struct.CreateHholdEvidenceDtls;
import curam.sample.sl.struct.CreateIncomeEvidenceDtls;
import curam.sample.sl.struct.CreateResourceEvidenceDtls;
import curam.sample.sl.struct.GetBenefitEvidenceDetails;
import curam.sample.sl.struct.GetBenefitEvidenceKey;
import curam.sample.sl.struct.GetBenefitEvidenceListDetails;
import curam.sample.sl.struct.GetBenefitEvidenceListDetailsList;
import curam.sample.sl.struct.GetEvidenceListKey;
import curam.sample.sl.struct.GetExpenseEvidenceDetails;
import curam.sample.sl.struct.GetExpenseEvidenceDetailsList;
import curam.sample.sl.struct.GetExpenseEvidenceKey;
import curam.sample.sl.struct.GetHouseholdEvidenceDetails;
import curam.sample.sl.struct.GetHouseholdEvidenceKey;
import curam.sample.sl.struct.GetHouseholdEvidenceListDetails;
import curam.sample.sl.struct.GetHouseholdMemberDetails;
import curam.sample.sl.struct.GetIncomeEvidenceDetails;
import curam.sample.sl.struct.GetIncomeEvidenceKey;
import curam.sample.sl.struct.GetIncomeEvidenceListDetails;
import curam.sample.sl.struct.GetIncomeEvidenceListDetailsList;
import curam.sample.sl.struct.GetIncomeLimitsKey;
import curam.sample.sl.struct.GetMedicalExpenseEvidenceList;
import curam.sample.sl.struct.GetMedicalExpenseEvidenceListDetails;
import curam.sample.sl.struct.GetMemberDetailsList;
import curam.sample.sl.struct.GetMemberNameDtls;
import curam.sample.sl.struct.GetMemberNameKey;
import curam.sample.sl.struct.GetMembersListKey;
import curam.sample.sl.struct.GetResourceEvidenceDetails;
import curam.sample.sl.struct.GetResourceEvidenceKey;
import curam.sample.sl.struct.GetResourceEvidenceListDetails;
import curam.sample.sl.struct.GetResourceEvidenceListDetailsList;
import curam.sample.sl.struct.GetShelterExpenseEvidenceList;
import curam.sample.sl.struct.GetShelterExpenseEvidenceListDetails;
import curam.sample.sl.struct.GetUserAvailabilityDtls;
import curam.sample.sl.struct.GetUserAvailabilityKey;
import curam.sample.sl.struct.GethouseholdEvidenceListDetailsList;
import curam.sample.sl.struct.HouseholdDetailsKey;
import curam.sample.sl.struct.HouseholdEvidenceDetails;
import curam.sample.sl.struct.HouseholdEvidenceDetailsList;
import curam.sample.sl.struct.HouseholdEvidenceKey;
import curam.sample.sl.struct.HouseholdExpenseDetailsKey;
import curam.sample.sl.struct.HouseholdMemberBenefitDetails;
import curam.sample.sl.struct.HouseholdMemberExpenseDetails;
import curam.sample.sl.struct.HouseholdMemberIncomeDetails;
import curam.sample.sl.struct.HouseholdMemberResourceDetails;
import curam.sample.sl.struct.IncomeLimitDetails;
import curam.sample.sl.struct.InsertAddressDtls;
import curam.sample.sl.struct.InsertHomePhoneDtls;
import curam.sample.sl.struct.InsertMailingAddressDtls;
import curam.sample.sl.struct.InsertWorkPhoneDtls;
import curam.sample.sl.struct.ModifyBenefitEvidenceDetails;
import curam.sample.sl.struct.ModifyExpenseEvidenceDetails;
import curam.sample.sl.struct.ModifyHouseholdEvidenceDetails;
import curam.sample.sl.struct.ModifyIncomeEvidenceDetails;
import curam.sample.sl.struct.ModifyResourceEvidenceDetails;
import curam.sample.sl.struct.RemoveBenefitEvidenceKey;
import curam.sample.sl.struct.RemoveExpenseEvidenceKey;
import curam.sample.sl.struct.RemoveHouseholdEvidenceKey;
import curam.sample.sl.struct.RemoveIncomeEvidenceKey;
import curam.sample.sl.struct.RemoveResourceEvidenceKey;
import curam.sample.sl.struct.ScreeningCaseHomeDetails;
import curam.sample.sl.struct.UserAvailabilityDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;


/**
 * This process class provides the functionality for the screening case
 */
public abstract class IncomeScreening extends curam.sample.sl.base.IncomeScreening {

  // ___________________________________________________________________________
  /**
   * Method used to record benefit evidence records.
   *
   * @param dtls CreateBfitEvidenceDtls
   */
  @Override
  public void createBenefitEvidence(CreateBfitEvidenceDtls dtls)
    throws AppException, InformationalException {

    // FSHouseholdBenefits manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    final FSHouseholdBenefitsDtls fSHouseholdBenefitsDtls = new FSHouseholdBenefitsDtls();

    // caseEvidenceLink manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final CaseEvidenceLinkDtls caseEvidenceLinkDtls = new CaseEvidenceLinkDtls();

    // Unique ID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // set the details to perform the FSHouseholdBenefits entity insert
    fSHouseholdBenefitsDtls.benefitClaimNo = dtls.createBfitDtls.benefitClaimNo;
    fSHouseholdBenefitsDtls.benefitTypeCode = dtls.createBfitDtls.benefitTypeCode;
    fSHouseholdBenefitsDtls.concernRoleID = dtls.createBfitDtls.concernRoleID;
    fSHouseholdBenefitsDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    fSHouseholdBenefitsObj.insert(fSHouseholdBenefitsDtls);

    // set the details to perform the case evidence link insert
    caseEvidenceLinkDtls.caseEvidenceLinkID = uniqueIDObj.getNextID();
    caseEvidenceLinkDtls.caseEvidenceTypeID = dtls.createBfitDtls.caseEvidenceTypeID;
    caseEvidenceLinkDtls.evidenceType = curam.codetable.CASEEVIDENCE.BENEFITEVIDENCE;
    caseEvidenceLinkDtls.relatedID = fSHouseholdBenefitsDtls.fsHouseholdBenefitsID;

    caseEvidenceLinkObj.insert(caseEvidenceLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * To record all fsHouseholdExpense records on the database.
   *
   * @param dtls CreateExpEvidenceDtls
   */
  @Override
  public void createExpenseEvidence(CreateExpEvidenceDtls dtls)
    throws AppException, InformationalException {

    // FSHouseholdExpenses manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    final FSHouseholdExpensesDtls fSHouseholdExpensesDtls = new FSHouseholdExpensesDtls();

    // caseEvidenceLink manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final CaseEvidenceLinkDtls caseEvidenceLinkDtls = new CaseEvidenceLinkDtls();

    // Unique ID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // set the details to perform the FSHouseholdExpenses entity insert
    fSHouseholdExpensesDtls.concernRoleID = dtls.concernRoleID;
    fSHouseholdExpensesDtls.currMthlyExpenseAmount = dtls.currMthlyExpenseAmount;
    fSHouseholdExpensesDtls.expenseAmount = dtls.expenseAmount;
    fSHouseholdExpensesDtls.expenseCategoryCode = dtls.expenseCategoryCode;
    fSHouseholdExpensesDtls.expenseFrequencyCode = dtls.expenseFrequencyCode;
    fSHouseholdExpensesDtls.expenseTypeCode = dtls.expenseTypeCode;
    fSHouseholdExpensesDtls.propertyAddress = dtls.propertyAddress;
    fSHouseholdExpensesDtls.serviceSupplierID = dtls.serviceSupplierID;
    fSHouseholdExpensesDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    fSHouseholdExpensesObj.insert(fSHouseholdExpensesDtls);

    // set the details to perform the case evidence link insert
    caseEvidenceLinkDtls.caseEvidenceLinkID = uniqueIDObj.getNextID();
    caseEvidenceLinkDtls.caseEvidenceTypeID = dtls.caseEvidenceTypeID;
    caseEvidenceLinkDtls.evidenceType = curam.codetable.CASEEVIDENCE.EXPENSEEVIDENCE;
    caseEvidenceLinkDtls.relatedID = fSHouseholdExpensesDtls.fsHouseholdExpensesID;

    caseEvidenceLinkObj.insert(caseEvidenceLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to record household details on the fsHouseholdEvidence entity
   *
   * @param dtls CreateHholdEvidenceDtls
   */
  @Override
  public void createHouseholdEvidence(CreateHholdEvidenceDtls dtls)
    throws AppException, InformationalException {

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();

    // caseEvidenceLink manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final CaseEvidenceLinkDtls caseEvidenceLinkDtls = new CaseEvidenceLinkDtls();

    // caseEvidenceLink obj, dtls and key structs
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // Ensure record has not already been entered
    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = dtls.createHholdDtls.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    // call method to retrieve a list of related ID's for household evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList
      // read the FSHouseholdBenefits evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {
        // set the key for the FSHouseholdEvidence entity read
        fSHouseholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
          fSHouseholdEvidenceKey);

        if (fSHouseholdEvidenceDtls.concernRoleID
          == dtls.createHholdDtls.concernRoleID) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.INCOMESCREENING.ERR_FV_DUPLICATE_MEMBER),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }

    // Unique ID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // set the details to perform the FSHouseholdEvidence entity insert
    fSHouseholdEvidenceDtls.citizenshipCode = dtls.createHholdDtls.citizenshipCode;
    fSHouseholdEvidenceDtls.concernRoleID = dtls.createHholdDtls.concernRoleID;
    fSHouseholdEvidenceDtls.disabledInd = dtls.createHholdDtls.disabledInd;
    fSHouseholdEvidenceDtls.prepareMealsInd = dtls.createHholdDtls.prepareMealsInd;
    fSHouseholdEvidenceDtls.rshipToHOH = dtls.createHholdDtls.rshipToHOH;
    fSHouseholdEvidenceDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdEvidenceDtls.strikerInd = dtls.createHholdDtls.strikerInd;

    fSHouseholdEvidenceObj.insert(fSHouseholdEvidenceDtls);

    // set the details to perform the case evidence link insert
    caseEvidenceLinkDtls.caseEvidenceLinkID = uniqueIDObj.getNextID();
    caseEvidenceLinkDtls.caseEvidenceTypeID = dtls.createHholdDtls.caseEvidenceTypeID;
    caseEvidenceLinkDtls.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;
    caseEvidenceLinkDtls.relatedID = fSHouseholdEvidenceDtls.fsHouseholdEvidenceID;

    caseEvidenceLinkObj.insert(caseEvidenceLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to create fsHouseholdIncome evidence screening assessment
   * records on the database.
   *
   * @param dtls CreateIncomeEvidenceDtls
   */
  @Override
  public void createIncomeEvidence(CreateIncomeEvidenceDtls dtls)
    throws AppException, InformationalException {

    // FSHouseholdIncome manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    final FSHouseholdIncomeDtls fSHouseholdIncomeDtls = new FSHouseholdIncomeDtls();

    // caseEvidenceLink manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final CaseEvidenceLinkDtls caseEvidenceLinkDtls = new CaseEvidenceLinkDtls();

    // Unique ID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // set the details to perform the FSHouseholdIncome entity insert
    fSHouseholdIncomeDtls.concernRoleID = dtls.createIncDtls.concernRoleID;
    fSHouseholdIncomeDtls.currMonthlyAmount = dtls.createIncDtls.currMonthlyAmount;
    fSHouseholdIncomeDtls.incomeAmount = dtls.createIncDtls.incomeAmount;
    fSHouseholdIncomeDtls.incomeFrequencyCode = dtls.createIncDtls.incomeFrequencyCode;
    fSHouseholdIncomeDtls.incomeTypeCode = dtls.createIncDtls.incomeTypeCode;
    fSHouseholdIncomeDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    fSHouseholdIncomeObj.insert(fSHouseholdIncomeDtls);

    // set the details to perform the case evidence link insert
    caseEvidenceLinkDtls.caseEvidenceLinkID = uniqueIDObj.getNextID();
    caseEvidenceLinkDtls.caseEvidenceTypeID = dtls.createIncDtls.caseEvidenceTypeID;
    caseEvidenceLinkDtls.evidenceType = curam.codetable.CASEEVIDENCE.INCOMEEVIDENCE;
    caseEvidenceLinkDtls.relatedID = fSHouseholdIncomeDtls.fsHouseholdIncomeID;

    caseEvidenceLinkObj.insert(caseEvidenceLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to create fsHouseholdResource records for a screening
   * assessment.
   *
   * @param dtls CreateResourceEvidenceDtls
   */
  @Override
  public void createResourceEvidence(CreateResourceEvidenceDtls dtls)
    throws AppException, InformationalException {

    // FSHouseholdResources manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    final FSHouseholdResourcesDtls fSHouseholdResourcesDtls = new FSHouseholdResourcesDtls();

    // caseEvidenceLink manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final CaseEvidenceLinkDtls caseEvidenceLinkDtls = new CaseEvidenceLinkDtls();

    // Unique ID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // set the details to perform the FSHouseholdResources entity insert
    fSHouseholdResourcesDtls.amountReceived = dtls.createResDtls.amountReceived;
    fSHouseholdResourcesDtls.assetTypeCode = dtls.createResDtls.assetTypeCode;
    fSHouseholdResourcesDtls.assetUsage = dtls.createResDtls.assetUsage;
    fSHouseholdResourcesDtls.concernRoleID = dtls.createResDtls.concernRoleID;
    fSHouseholdResourcesDtls.dateAquired = dtls.createResDtls.dateAquired;
    fSHouseholdResourcesDtls.dateDisposed = dtls.createResDtls.dateDisposed;
    fSHouseholdResourcesDtls.disposalReasonCode = dtls.createResDtls.disposalReasonCode;
    fSHouseholdResourcesDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdResourcesDtls.totalOwed = dtls.createResDtls.totalOwed;
    fSHouseholdResourcesDtls.totalValue = dtls.createResDtls.totalValue;

    fSHouseholdResourcesObj.insert(fSHouseholdResourcesDtls);

    // set the details to perform the case evidence link insert
    caseEvidenceLinkDtls.caseEvidenceLinkID = uniqueIDObj.getNextID();
    caseEvidenceLinkDtls.caseEvidenceTypeID = dtls.createResDtls.caseEvidenceTypeID;
    caseEvidenceLinkDtls.evidenceType = curam.codetable.CASEEVIDENCE.RESOURCEEVIDENCE;
    caseEvidenceLinkDtls.relatedID = fSHouseholdResourcesDtls.fsHouseholdResourcesID;

    caseEvidenceLinkObj.insert(caseEvidenceLinkDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve benefit evidence details that a household member
   * who is applying for a Food Stamps Product is receiving.
   *
   * @param key GetBenefitEvidenceKey
   *
   * @return Benefit Evidence Details
   */
  @Override
  public GetBenefitEvidenceDetails getBenefitEvidence(
    GetBenefitEvidenceKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetBenefitEvidenceDetails getBenefitEvidenceDetails = new GetBenefitEvidenceDetails();

    // FSHouseholdBenefits object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    final FSHouseholdBenefitsKey fSHouseholdBenefitsKey = new FSHouseholdBenefitsKey();
    FSHouseholdBenefitsDtls fSHouseholdBenefitsDtls;

    // caseEvidenceLink obj, dtls and key structs
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // FSHouseholdEvidence object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // set ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // set the key for the FSHouseholdBenefits read
    fSHouseholdBenefitsKey.fsHouseholdBenefitsID = key.getBfitKey.fsHouseholdBenefitsID;

    fSHouseholdBenefitsDtls = fSHouseholdBenefitsObj.read(
      fSHouseholdBenefitsKey);

    // set the concernRoleID in the FSHouseholdEvidenceKey
    fSHholdEvidenceKey.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;

    // set details in the return struct
    getBenefitEvidenceDetails.benefitClaimNo = fSHouseholdBenefitsDtls.benefitClaimNo;
    getBenefitEvidenceDetails.benefitTypeCode = fSHouseholdBenefitsDtls.benefitTypeCode;
    getBenefitEvidenceDetails.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;
    getBenefitEvidenceDetails.versionNo = fSHouseholdBenefitsDtls.versionNo;

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.getBfitKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fSHholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

      try {
        // read the fSHouseholdEvidence details
        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
          fSHholdEvidenceKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        getBenefitEvidenceDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
      }
    }

    // set up key to perform a concernRole read
    concernRoleKey.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // map details to output struct
    getBenefitEvidenceDetails.concernRoleName = concernRoleDtls.concernRoleName;
    getBenefitEvidenceDetails.concernRoleType = concernRoleDtls.concernRoleType;

    return getBenefitEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve all benefit evidence records for the screening
   * assessment.
   *
   * @param key GetEvidenceListKey
   *
   * @return List of Benefit Evidence Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public GetBenefitEvidenceListDetailsList getBenefitEvidenceList(
    GetEvidenceListKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetBenefitEvidenceListDetailsList getBenefitEvidenceListDetailsList = new GetBenefitEvidenceListDetailsList();

    GetBenefitEvidenceListDetails getBenefitEvidenceListDetails;

    // FSHouseholdBenefits manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    final FSHouseholdBenefitsKey fSHouseholdBenefitsKey = new FSHouseholdBenefitsKey();
    FSHouseholdBenefitsDtls fSHouseholdBenefitsDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;
    final EvidenceTypeAndCETypeIDKey bfitEvidenceTypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList bfitCaseEvidenceLinkList = new CaseEvidenceLinkDtlsList();

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    assessmentReadmultiKey.caseID = key.listKeyDtls.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    for (int i = 0; i < assessmentDtlsList.dtls.size(); i++) {
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(i).assessmentID;
      break;
    }
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.listKeyDtls.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return getBenefitEvidenceListDetailsList;
    }

    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.BENEFITEVIDENCE;

    // call method to retrieve a list of related ID's for benefit evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the
      // FSHouseholdBenefits evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getBenefitEvidenceListDetails = new GetBenefitEvidenceListDetails();

        // set the key for the FSHouseholdBenefits entity read
        fSHouseholdBenefitsKey.fsHouseholdBenefitsID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdBenefitsDtls = fSHouseholdBenefitsObj.read(
          fSHouseholdBenefitsKey);

        // populate the return struct with FS Household Benefits details
        getBenefitEvidenceListDetails.benefitClaimNo = fSHouseholdBenefitsDtls.benefitClaimNo;
        getBenefitEvidenceListDetails.benefitTypeCode = fSHouseholdBenefitsDtls.benefitTypeCode;
        getBenefitEvidenceListDetails.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;
        getBenefitEvidenceListDetails.fsHouseholdBenefitsID = fSHouseholdBenefitsDtls.fsHouseholdBenefitsID;
        getBenefitEvidenceListDetails.statusCode = fSHouseholdBenefitsDtls.statusCode;

        getBenefitEvidenceListDetails.versionNo = fSHouseholdBenefitsDtls.versionNo;

        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with concern role details
        getBenefitEvidenceListDetails.concernRoleType = concernRoleDtls.concernRoleType;
        getBenefitEvidenceListDetails.concernRoleName = concernRoleDtls.concernRoleName;

        // set the key to perform a FS Household Evidence read
        fSHholdEvidenceKey.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;

        // set up key to read a list of case evidence link
        // records for household evidence
        bfitEvidenceTypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        bfitEvidenceTypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

        // call method to retrieve a list of related ID's for benefit evidence
        bfitCaseEvidenceLinkList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
          bfitEvidenceTypeIDKey);

        // for each element in CaseEvidenceLinkDtlsList read
        // the FSHouseholdEvidence record
        for (int j = 0; j < bfitCaseEvidenceLinkList.dtls.size(); j++) {

          boolean recordFound = true;

          // set the key for the FSHouseholdEvidence entity read
          fSHholdEvidenceKey.fsHouseholdEvidenceID = bfitCaseEvidenceLinkList.dtls.item(j).relatedID;
          fSHholdEvidenceKey.concernRoleID = fSHouseholdBenefitsDtls.concernRoleID;

          try {

            fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
              fSHholdEvidenceKey);
          } catch (final curam.util.exception.RecordNotFoundException e) {
            recordFound = false;
          }

          if (recordFound) {
            // populate the return struct with relationship to head of
            // household details
            getBenefitEvidenceListDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
          }
          // map the details to the output struct

        } // end for

        getBenefitEvidenceListDetailsList.benefitDtls.addRef(
          getBenefitEvidenceListDetails);

      } // end for

    } // end if

    getBenefitEvidenceListDetailsList.BfitEvidenceKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;

    return getBenefitEvidenceListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve expense evidence details for a household member
   * who is applying for a Food Stamps Product.
   *
   * @param key GetExpenseEvidenceKey
   *
   * @return Food stamps expense evidence details.
   */
  @Override
  public GetExpenseEvidenceDetails getExpenseEvidence(
    GetExpenseEvidenceKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetExpenseEvidenceDetails getExpenseEvidenceDetails = new GetExpenseEvidenceDetails();

    // caseEvidenceLink obj, dtls and key structs
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // FSHouseholdExpense object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    final FSHouseholdExpensesKey fSHouseholdExpensesKey = new FSHouseholdExpensesKey();
    FSHouseholdExpensesDtls fSHouseholdExpensesDtls;

    // FSHouseholdEvidence object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // set ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    fSHouseholdExpensesKey.fsHouseholdExpensesID = key.getExpKey.fsHouseholdExpensesID;

    fSHouseholdExpensesDtls = fSHouseholdExpensesObj.read(
      fSHouseholdExpensesKey);

    getExpenseEvidenceDetails.currMthlyExpenseAmount = fSHouseholdExpensesDtls.currMthlyExpenseAmount;
    getExpenseEvidenceDetails.expenseAmount = fSHouseholdExpensesDtls.expenseAmount;
    getExpenseEvidenceDetails.expenseCategoryCode = fSHouseholdExpensesDtls.expenseCategoryCode;
    getExpenseEvidenceDetails.expenseFrequencyCode = fSHouseholdExpensesDtls.expenseFrequencyCode;
    getExpenseEvidenceDetails.expenseTypeCode = fSHouseholdExpensesDtls.expenseTypeCode;
    getExpenseEvidenceDetails.propertyAddress = fSHouseholdExpensesDtls.propertyAddress;
    getExpenseEvidenceDetails.serviceSupplierID = fSHouseholdExpensesDtls.serviceSupplierID;
    getExpenseEvidenceDetails.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;
    getExpenseEvidenceDetails.versionNo = fSHouseholdExpensesDtls.versionNo;

    // set up key to perform a concernRole read to retrieve ServiceSupplier
    // name
    if (getExpenseEvidenceDetails.serviceSupplierID != 0) {

      concernRoleKey.concernRoleID = fSHouseholdExpensesDtls.serviceSupplierID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      getExpenseEvidenceDetails.serviceSupplierName = concernRoleDtls.concernRoleName;
    }

    fSHholdEvidenceKey.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.getExpKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fSHholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

      try {
        // read the fSHouseholdEvidence details
        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
          fSHholdEvidenceKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }
      // if a record is found, map the details
      if (recordFound) {

        getExpenseEvidenceDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
      }

    }

    // set up key to perform a concernRole read
    concernRoleKey.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // map details to output struct
    getExpenseEvidenceDetails.concernRoleName = concernRoleDtls.concernRoleName;
    getExpenseEvidenceDetails.concernRoleType = concernRoleDtls.concernRoleType;

    return getExpenseEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve all records from the fsHouseholdExpense entity.
   *
   * @param key GetEvidenceListKey
   *
   * @return List of Expense Evidence Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public GetExpenseEvidenceDetailsList getExpenseEvidenceList(
    GetEvidenceListKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetExpenseEvidenceDetailsList getExpenseEvidenceDetailsList = new GetExpenseEvidenceDetailsList();

    final GetMedicalExpenseEvidenceList getMedicalExpenseEvidenceList = new GetMedicalExpenseEvidenceList();
    final GetShelterExpenseEvidenceList getShelterExpenseEvidenceList = new GetShelterExpenseEvidenceList();
    GetShelterExpenseEvidenceListDetails getShelterExpenseDetails;
    GetMedicalExpenseEvidenceListDetails getMedicalExpenseDetails;

    // FSHouseholdExpenses manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    final FSHouseholdExpensesKey fSHouseholdExpensesKey = new FSHouseholdExpensesKey();
    FSHouseholdExpensesDtls fSHouseholdExpensesDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;
    CaseEvidenceLinkDtlsList expEvidenceLinkList;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    assessmentReadmultiKey.caseID = key.listKeyDtls.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    if (assessmentDtlsList.dtls.size() >= 1) {
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(0).assessmentID;
    } else {
      return getExpenseEvidenceDetailsList;
    }
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.listKeyDtls.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return getExpenseEvidenceDetailsList;
    }

    // set key to read list of case evidence records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.EXPENSEEVIDENCE;

    // call method to retrieve a list of related ID's for expense evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the
      // FSHouseholdExpense evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getShelterExpenseDetails = new GetShelterExpenseEvidenceListDetails();
        getMedicalExpenseDetails = new GetMedicalExpenseEvidenceListDetails();

        // set the key for the FSHouseholdExpenses entity read
        fSHouseholdExpensesKey.fsHouseholdExpensesID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdExpensesDtls = fSHouseholdExpensesObj.read(
          fSHouseholdExpensesKey);

        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with FS Household Expenses details
        if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
          curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES)) {
          getShelterExpenseDetails.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;
          getShelterExpenseDetails.currMthlyExpenseAmount = fSHouseholdExpensesDtls.currMthlyExpenseAmount;
          getShelterExpenseDetails.expenseCategoryCode = fSHouseholdExpensesDtls.expenseCategoryCode;
          getShelterExpenseDetails.expenseTypeCode = fSHouseholdExpensesDtls.expenseTypeCode;
          getShelterExpenseDetails.fsHouseholdExpensesID = fSHouseholdExpensesDtls.fsHouseholdExpensesID;
          getShelterExpenseDetails.statusCode = fSHouseholdExpensesDtls.statusCode;
          getShelterExpenseDetails.versionNo = fSHouseholdExpensesDtls.versionNo;
          getShelterExpenseDetails.concernRoleType = concernRoleDtls.concernRoleType;
          getShelterExpenseDetails.concernRoleName = concernRoleDtls.concernRoleName;
        } else {
          if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
            curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES)) {
            getMedicalExpenseDetails.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;
            getMedicalExpenseDetails.currMthlyExpenseAmount = fSHouseholdExpensesDtls.currMthlyExpenseAmount;
            getMedicalExpenseDetails.expenseCategoryCode = fSHouseholdExpensesDtls.expenseCategoryCode;
            getMedicalExpenseDetails.expenseTypeCode = fSHouseholdExpensesDtls.expenseTypeCode;
            getMedicalExpenseDetails.fsHouseholdExpensesID = fSHouseholdExpensesDtls.fsHouseholdExpensesID;
            getMedicalExpenseDetails.statusCode = fSHouseholdExpensesDtls.statusCode;
            getMedicalExpenseDetails.versionNo = fSHouseholdExpensesDtls.versionNo;
            getMedicalExpenseDetails.concernRoleType = concernRoleDtls.concernRoleType;
            getMedicalExpenseDetails.concernRoleName = concernRoleDtls.concernRoleName;
          }
        }
        // set the key to perform a FS Household Evidence read
        fSHholdEvidenceKey.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;

        // set up key to read a list of case evidence link records for
        // household evidence
        evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

        // call method to retrieve a list of related ID's for benefit evidence
        expEvidenceLinkList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
          evidenceTypeAndCETypeIDKey);

        // for each element in CaseEvidenceLinkDtlsList read the
        // FSHouseholdEvidence record
        for (int j = 0; j < expEvidenceLinkList.dtls.size(); j++) {

          boolean recordFound = true;

          // set the key for the FSHouseholdEvidence entity read
          fSHholdEvidenceKey.fsHouseholdEvidenceID = expEvidenceLinkList.dtls.item(j).relatedID;
          fSHholdEvidenceKey.concernRoleID = fSHouseholdExpensesDtls.concernRoleID;

          try {
            fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
              fSHholdEvidenceKey);
          } catch (final curam.util.exception.RecordNotFoundException e) {
            recordFound = false;
          }

          if (recordFound) {
            if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
              curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES)) {
              getShelterExpenseDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
            } else {

              if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
                curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES)) {
                getMedicalExpenseDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
              }
            }
          }
        } // end for

        // map the details to the output struct
        if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
          curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES)) {
          getShelterExpenseEvidenceList.shelterExpList.addRef(
            getShelterExpenseDetails);
        } else {
          if (fSHouseholdExpensesDtls.expenseCategoryCode.equals(
            curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES)) {
            getMedicalExpenseEvidenceList.medExpList.addRef(
              getMedicalExpenseDetails);
          }
        }
      }

    }
    getExpenseEvidenceDetailsList.expEvidenceKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    getExpenseEvidenceDetailsList.medicalList = getMedicalExpenseEvidenceList;
    getExpenseEvidenceDetailsList.shelterList = getShelterExpenseEvidenceList;

    return getExpenseEvidenceDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve details of a specified fsHouseholdEvidence record.
   *
   * @param key GetHouseholdEvidenceKey
   *
   * @return Household evidence details
   */
  @Override
  public GetHouseholdEvidenceDetails getHouseholdEvidence(
    GetHouseholdEvidenceKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetHouseholdEvidenceDetails getHouseholdEvidenceDetails = new GetHouseholdEvidenceDetails();

    // FSHouseholdEvidence object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concenRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // set the key for the FSHouseholdEvidence read
    fSHouseholdEvidenceKey.fsHouseholdEvidenceID = key.getHholdKey.fsHouseholdEvidenceID;

    fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
      fSHouseholdEvidenceKey);

    // set details in the return struct
    getHouseholdEvidenceDetails.assign(fSHouseholdEvidenceDtls);

    // set the key for the Concern Role read
    concernRoleKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

    concernRoleDtls = concenRoleObj.read(concernRoleKey);

    // set details in the return struct
    getHouseholdEvidenceDetails.concernRoleName = concernRoleDtls.concernRoleName;
    getHouseholdEvidenceDetails.concernRoleType = concernRoleDtls.concernRoleType;

    return getHouseholdEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve details of all fsHouseholdEvidence records.
   *
   * @param key GetEvidenceListKey
   *
   * @return List of Household Evidence Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public GethouseholdEvidenceListDetailsList getHouseholdEvidenceList(
    GetEvidenceListKey key) throws AppException, InformationalException {

    // variable to store return values
    final GethouseholdEvidenceListDetailsList gethouseholdEvidenceListDetailsList = new GethouseholdEvidenceListDetailsList();

    // remove this later when model has included assignments
    GetHouseholdEvidenceListDetails getHouseholdEvidenceListDetails;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // concern role manipulation variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    final PersonKey personKey = new PersonKey();
    PersonDtls personDtls;

    // prospect person manipulation variables
    final curam.core.intf.ProspectPerson prospectPersonObj = curam.core.fact.ProspectPersonFactory.newInstance();
    final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();
    ProspectPersonDtls prospectPersonDtls;

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    assessmentReadmultiKey.caseID = key.listKeyDtls.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    for (int i = 0; i < assessmentDtlsList.dtls.size(); i++) {
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(i).assessmentID;
      break;
    }
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.listKeyDtls.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return gethouseholdEvidenceListDetailsList;
    }

    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    // call method to retrieve a list of related ID's for household evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the
      // FSHouseholdBenefits evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getHouseholdEvidenceListDetails = new GetHouseholdEvidenceListDetails();

        // set the key for the FSHouseholdEvidence entity read
        fSHouseholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
          fSHouseholdEvidenceKey);

        // populate the return struct with FS Household Evidence details
        getHouseholdEvidenceListDetails.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;
        getHouseholdEvidenceListDetails.fsHouseholdEvidenceID = fSHouseholdEvidenceDtls.fsHouseholdEvidenceID;
        getHouseholdEvidenceListDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;

        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with concern role details
        getHouseholdEvidenceListDetails.concernRoleType = concernRoleDtls.concernRoleType;
        getHouseholdEvidenceListDetails.concernRoleName = concernRoleDtls.concernRoleName;

        if (concernRoleDtls.concernRoleType.equals(
          curam.codetable.CONCERNROLETYPE.PERSON)) {

          // set up key to perform a person read
          personKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;
          personDtls = personObj.read(personKey);
          getHouseholdEvidenceListDetails.dateOfBirth = personDtls.dateOfBirth;

        } else {

          if (concernRoleDtls.concernRoleType.equals(
            curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {
            // set up key to perform a person read
            prospectPersonKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;
            prospectPersonDtls = prospectPersonObj.read(prospectPersonKey);
            getHouseholdEvidenceListDetails.dateOfBirth = prospectPersonDtls.dateOfBirth;
          }
        }
        // BEGIN, CR00129996, ZV
        final SpecialCaution specialCautionObj = SpecialCautionFactory.newInstance();
        final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

        // assigning concern role id to SpecialCautionConcernKey struct
        specialCautionConcernKey.concernRoleID = getHouseholdEvidenceListDetails.concernRoleID;
        // invoking displayActiveSpecialCautionIndicator() method on special
        // caution
        // object
        getHouseholdEvidenceListDetails.specialCautionInd = specialCautionObj.displayActiveSpecialCautionIndicator(specialCautionConcernKey).displayIndicator;
        // END, CR00129996

        // map the details to the output struct
        gethouseholdEvidenceListDetailsList.hholdListDtls.addRef(
          getHouseholdEvidenceListDetails);

      }

    }

    gethouseholdEvidenceListDetailsList.hholdEvidenceDtls.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;

    return gethouseholdEvidenceListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve details of a specified fsHouseholdIncome record
   * from the database.
   *
   * @param key GetIncomeEvidenceKey
   *
   * @return Income Evidence Details
   */
  @Override
  public GetIncomeEvidenceDetails getIncomeEvidence(GetIncomeEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    final GetIncomeEvidenceDetails getIncomeEvidenceDetails = new GetIncomeEvidenceDetails();

    // FSHouseholdIncome object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    final FSHouseholdIncomeKey fSHouseholdIncomeKey = new FSHouseholdIncomeKey();
    FSHouseholdIncomeDtls fSHouseholdIncomeDtls;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // set key to perform FSHouseholdIncome read
    fSHouseholdIncomeKey.fsHouseholdIncomeID = key.getIncDtls.fsHouseholdIncomeID;

    fSHouseholdIncomeDtls = fSHouseholdIncomeObj.read(fSHouseholdIncomeKey);

    // map details to return struct
    getIncomeEvidenceDetails.assign(fSHouseholdIncomeDtls);

    // set the key to perform a concern role read
    concernRoleKey.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;

    // set the key to perform a fSHouseholdEvidence read
    fSHholdEvidenceKey.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // map details to the return struct
    getIncomeEvidenceDetails.concernRoleName = concernRoleDtls.concernRoleName;
    getIncomeEvidenceDetails.concernRoleType = concernRoleDtls.concernRoleType;

    // set to details to read the caseEvidenceLink record for household
    // evidence
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.getIncDtls.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fSHholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

      try {
        // read the fSHouseholdEvidence details
        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
          fSHholdEvidenceKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        getIncomeEvidenceDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
      }
    }

    return getIncomeEvidenceDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve all fsHouseholdIncome records from the database.
   *
   * @param key GetEvidenceListKey
   *
   * @return List of Income Evidence Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public GetIncomeEvidenceListDetailsList getIncomeEvidenceList(
    GetEvidenceListKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetIncomeEvidenceListDetailsList getIncomeEvidenceListDetailsList = new GetIncomeEvidenceListDetailsList();

    GetIncomeEvidenceListDetails getIncomeEvidenceListDetails;

    // FSHouseholdIncome manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    final FSHouseholdIncomeKey fSHouseholdIncomeKey = new FSHouseholdIncomeKey();
    FSHouseholdIncomeDtls fSHouseholdIncomeDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;
    CaseEvidenceLinkDtlsList incEvidenceLinkList;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    assessmentReadmultiKey.caseID = key.listKeyDtls.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    for (int i = 0; i < assessmentDtlsList.dtls.size(); i++) {
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(i).assessmentID;
      break;
    }
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.listKeyDtls.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return getIncomeEvidenceListDetailsList;
    }

    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.INCOMEEVIDENCE;

    // call method to retrieve a list of related ID's for benefit evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the FSHouseholdIncome
      // evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getIncomeEvidenceListDetails = new GetIncomeEvidenceListDetails();

        // set the key for the FSHouseholdIncome entity read
        fSHouseholdIncomeKey.fsHouseholdIncomeID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdIncomeDtls = fSHouseholdIncomeObj.read(fSHouseholdIncomeKey);

        // populate the return struct with FS Household Income Evidence details
        getIncomeEvidenceListDetails.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;
        getIncomeEvidenceListDetails.currMonthlyAmount = fSHouseholdIncomeDtls.currMonthlyAmount;
        getIncomeEvidenceListDetails.fsHouseholdIncomeID = fSHouseholdIncomeDtls.fsHouseholdIncomeID;
        getIncomeEvidenceListDetails.incomeTypeCode = fSHouseholdIncomeDtls.incomeTypeCode;
        getIncomeEvidenceListDetails.statusCode = fSHouseholdIncomeDtls.statusCode;
        getIncomeEvidenceListDetails.versionNo = fSHouseholdIncomeDtls.versionNo;

        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with concern role details
        getIncomeEvidenceListDetails.concernRoleType = concernRoleDtls.concernRoleType;
        getIncomeEvidenceListDetails.concernRoleName = concernRoleDtls.concernRoleName;

        // set the key to perform a FS Household Evidence read
        fSHholdEvidenceKey.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;

        // set up key to read a list of case evidence link records for
        // household evidence
        evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

        // call method to retrieve a list of related ID's for benefit evidence
        incEvidenceLinkList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
          evidenceTypeAndCETypeIDKey);

        // for each element in CaseEvidenceLinkDtlsList read the
        // FSHouseholdEvidence record
        for (int j = 0; j < incEvidenceLinkList.dtls.size(); j++) {

          boolean recordFound = true;

          // set the key for the FSHouseholdEvidence entity read
          fSHholdEvidenceKey.fsHouseholdEvidenceID = incEvidenceLinkList.dtls.item(j).relatedID;
          fSHholdEvidenceKey.concernRoleID = fSHouseholdIncomeDtls.concernRoleID;

          try {
            fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
              fSHholdEvidenceKey);
          } catch (final curam.util.exception.RecordNotFoundException e) {
            recordFound = false;
          }

          // if a record is found, map the details
          if (recordFound) {
            // populate the return struct with relationship to head of
            // household details
            getIncomeEvidenceListDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
          }
        } // end for

        // map the details to the output struct
        getIncomeEvidenceListDetailsList.incomeListDtls.addRef(
          getIncomeEvidenceListDetails);

      }
    }

    getIncomeEvidenceListDetailsList.incEvidenceKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;

    return getIncomeEvidenceListDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve details of a specified fsHouseholdResource record.
   *
   * @param key GetResourceEvidenceKey
   *
   * @return Resource Evidence Details
   */
  @Override
  public GetResourceEvidenceDetails getResourceEvidence(
    GetResourceEvidenceKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetResourceEvidenceDetails getResourceEvidenceDetails = new GetResourceEvidenceDetails();

    // FSHouseholdResources object, dtls and key structs
    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    final FSHouseholdResourcesKey fSHouseholdResourcesKey = new FSHouseholdResourcesKey();
    FSHouseholdResourcesDtls fSHouseholdResourcesDtls;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // set key to perform FSHouseholdResources read
    fSHouseholdResourcesKey.fsHouseholdResourcesID = key.getResourceKey.fsHouseholdResourcesID;

    fSHouseholdResourcesDtls = fSHouseholdResourcesObj.read(
      fSHouseholdResourcesKey);

    // map details to output struct
    getResourceEvidenceDetails.assign(fSHouseholdResourcesDtls);

    // set key to perform a concern role read
    concernRoleKey.concernRoleID = fSHouseholdResourcesDtls.concernRoleID;

    // set up the key to perform a FSHholdEvidence read
    fSHholdEvidenceKey.concernRoleID = fSHouseholdResourcesDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // map details to output struct
    getResourceEvidenceDetails.concernRoleName = concernRoleDtls.concernRoleName;
    getResourceEvidenceDetails.concernRoleType = concernRoleDtls.concernRoleType;

    // set to details to read the caseEvidenceLink record for
    // household evidence
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.getResourceKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fSHholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

      try {
        // read the fSHouseholdEvidence details
        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
          fSHholdEvidenceKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        getResourceEvidenceDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
      }
    }

    return getResourceEvidenceDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method used to retrieve all fsHouseholdResource records from the database.
   *
   * @param key GetEvidenceListKey
   *
   * @return List of Resource Evidence Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public GetResourceEvidenceListDetailsList getResourceEvidenceList(
    GetEvidenceListKey key) throws AppException, InformationalException {

    // variable to store return values
    final GetResourceEvidenceListDetailsList getResourceEvidenceListDetailsList = new GetResourceEvidenceListDetailsList();

    GetResourceEvidenceListDetails getResourceEvidenceListDetails;

    // FSHouseholdResources manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    final FSHouseholdResourcesKey fSHouseholdResourcesKey = new FSHouseholdResourcesKey();
    FSHouseholdResourcesDtls fSHouseholdResourcesDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;
    CaseEvidenceLinkDtlsList resEvidenceLinkList;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHholdEvidenceKey fSHholdEvidenceKey = new FSHholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    assessmentReadmultiKey.caseID = key.listKeyDtls.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    for (int i = 0; i < assessmentDtlsList.dtls.size(); i++) {
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(i).assessmentID;
      break;
    }
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.listKeyDtls.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return getResourceEvidenceListDetailsList;
    }

    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.RESOURCEEVIDENCE;

    // call method to retrieve a list of related ID's for benefit evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the
      // FSHouseholdResources evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getResourceEvidenceListDetails = new GetResourceEvidenceListDetails();

        // set the key for the FSHouseholdBenefits entity read
        fSHouseholdResourcesKey.fsHouseholdResourcesID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdResourcesDtls = fSHouseholdResourcesObj.read(
          fSHouseholdResourcesKey);

        // populate the return struct with FS Household Benefits details
        getResourceEvidenceListDetails.assetTypeCode = fSHouseholdResourcesDtls.assetTypeCode;
        getResourceEvidenceListDetails.concernRoleID = fSHouseholdResourcesDtls.concernRoleID;
        getResourceEvidenceListDetails.fsHouseholdResourcesID = fSHouseholdResourcesDtls.fsHouseholdResourcesID;
        getResourceEvidenceListDetails.totalOwed = fSHouseholdResourcesDtls.totalOwed;
        getResourceEvidenceListDetails.totalValue = fSHouseholdResourcesDtls.totalValue;
        getResourceEvidenceListDetails.versionNo = fSHouseholdResourcesDtls.versionNo;

        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdResourcesDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with concern role details
        getResourceEvidenceListDetails.concernRoleType = concernRoleDtls.concernRoleType;
        getResourceEvidenceListDetails.concernRoleName = concernRoleDtls.concernRoleName;

        // set the key to perform a FS Household Evidence read
        fSHholdEvidenceKey.concernRoleID = fSHouseholdResourcesDtls.concernRoleID;

        // set up key to read a list of case evidence link records for
        // household evidence
        evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

        // call method to retrieve a list of related ID's for benefit evidence
        resEvidenceLinkList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
          evidenceTypeAndCETypeIDKey);

        // for each element in CaseEvidenceLinkDtlsList read the
        // FSHouseholdEvidence record
        for (int j = 0; j < resEvidenceLinkList.dtls.size(); j++) {

          boolean recordFound = true;

          // set the key for the FSHouseholdEvidence entity read
          fSHholdEvidenceKey.fsHouseholdEvidenceID = resEvidenceLinkList.dtls.item(j).relatedID;
          try {
            fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.readByKeyConcernRoleID(
              fSHholdEvidenceKey);
          } catch (final curam.util.exception.RecordNotFoundException e) {
            recordFound = false;
          }
          // if a record is found, map the details
          if (recordFound) {
            // populate the return struct with relationship to head of
            // household details
            getResourceEvidenceListDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;
          }
        }

        // map the details to the output struct
        getResourceEvidenceListDetailsList.resourceListDtls.addRef(
          getResourceEvidenceListDetails);

      }
    }
    getResourceEvidenceListDetailsList.resEvidenceDtls.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;

    return getResourceEvidenceListDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Method used to modify benefit evidence details for a household member
   * who is applying for a Food Stamps Product.
   *
   * @param dtls ModifyBenefitEvidenceDetails
   */
  @Override
  public void modifyBenefitEvidence(ModifyBenefitEvidenceDetails dtls)
    throws AppException, InformationalException {

    // FSHouseholdBenefits manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    final FSHouseholdBenefitsKey fSHouseholdBenefitsKey = new FSHouseholdBenefitsKey();
    final FSHouseholdBenefitsDtls fSHouseholdBenefitsDtls = new FSHouseholdBenefitsDtls();

    // set up the key to modify FSHouseholdBenefits
    fSHouseholdBenefitsKey.fsHouseholdBenefitsID = dtls.modifyBfitDtls.fsHouseholdBenefitsID;

    // map the details to be modified
    fSHouseholdBenefitsDtls.benefitClaimNo = dtls.modifyBfitDtls.benefitClaimNo;
    fSHouseholdBenefitsDtls.benefitTypeCode = dtls.modifyBfitDtls.benefitTypeCode;
    fSHouseholdBenefitsDtls.concernRoleID = dtls.modifyBfitDtls.concernRoleID;
    fSHouseholdBenefitsDtls.fsHouseholdBenefitsID = dtls.modifyBfitDtls.fsHouseholdBenefitsID;
    fSHouseholdBenefitsDtls.versionNo = dtls.modifyBfitDtls.versionNo;
    fSHouseholdBenefitsDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    fSHouseholdBenefitsObj.modify(fSHouseholdBenefitsKey,
      fSHouseholdBenefitsDtls);
  }

  // ___________________________________________________________________________
  /**
   * Method used to modify specified fsHouseholdExpense record.
   *
   * @param dtls ModifyExpenseEvidenceDetails
   */
  @Override
  public void modifyExpenseEvidence(ModifyExpenseEvidenceDetails dtls)
    throws AppException, InformationalException {

    // FSHouseholdExpense manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    final FSHouseholdExpensesKey fSHouseholdExpensesKey = new FSHouseholdExpensesKey();
    final FSHouseholdExpensesDtls fSHouseholdExpensesDtls = new FSHouseholdExpensesDtls();

    // set up the key to modify FSHouseholdExpense
    fSHouseholdExpensesKey.fsHouseholdExpensesID = dtls.fsHouseholdExpensesID;

    // map the details to be modified
    fSHouseholdExpensesDtls.concernRoleID = dtls.concernRoleID;
    fSHouseholdExpensesDtls.currMthlyExpenseAmount = dtls.currMthlyExpenseAmount;
    fSHouseholdExpensesDtls.expenseAmount = dtls.expenseAmount;
    fSHouseholdExpensesDtls.expenseCategoryCode = dtls.expenseCategoryCode;
    fSHouseholdExpensesDtls.expenseFrequencyCode = dtls.expenseFrequencyCode;
    fSHouseholdExpensesDtls.expenseTypeCode = dtls.expenseTypeCode;
    fSHouseholdExpensesDtls.fsHouseholdExpensesID = dtls.fsHouseholdExpensesID;
    fSHouseholdExpensesDtls.propertyAddress = dtls.propertyAddress;
    fSHouseholdExpensesDtls.serviceSupplierID = dtls.serviceSupplierID;
    fSHouseholdExpensesDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdExpensesDtls.versionNo = dtls.versionNo;

    fSHouseholdExpensesObj.modify(fSHouseholdExpensesKey,
      fSHouseholdExpensesDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to modify household evidence details for a household member
   * who is applying for a Food Stamps Product.
   *
   * @param dtls ModifyHouseholdEvidenceDetails
   */
  @Override
  public void modifyHouseholdEvidence(ModifyHouseholdEvidenceDetails dtls)
    throws AppException, InformationalException {

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // set up the key to modify FSHouseholdEvidence
    fSHouseholdEvidenceKey.fsHouseholdEvidenceID = dtls.modifyHholdDtls.fsHouseholdEvidenceID;

    fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
      fSHouseholdEvidenceKey);

    if (!fSHouseholdEvidenceDtls.rshipToHOH.equals(
      dtls.modifyHholdDtls.rshipToHOH)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.INCOMESCREENING.ERR_FV_NO_MODIFY_RHSIPTOHOH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    if (fSHouseholdEvidenceDtls.prepareMealsInd
      != dtls.modifyHholdDtls.prepareMealsInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.INCOMESCREENING.ERR_FV_NO_MODIFY_PREPAREFOOD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // map the details to be modified
    fSHouseholdEvidenceDtls.citizenshipCode = dtls.modifyHholdDtls.citizenshipCode;
    fSHouseholdEvidenceDtls.concernRoleID = dtls.modifyHholdDtls.concernRoleID;
    fSHouseholdEvidenceDtls.disabledInd = dtls.modifyHholdDtls.disabledInd;
    fSHouseholdEvidenceDtls.fsHouseholdEvidenceID = dtls.modifyHholdDtls.fsHouseholdEvidenceID;
    fSHouseholdEvidenceDtls.prepareMealsInd = dtls.modifyHholdDtls.prepareMealsInd;
    fSHouseholdEvidenceDtls.rshipToHOH = dtls.modifyHholdDtls.rshipToHOH;
    fSHouseholdEvidenceDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdEvidenceDtls.strikerInd = dtls.modifyHholdDtls.strikerInd;
    fSHouseholdEvidenceDtls.versionNo = dtls.modifyHholdDtls.versionNo;

    fSHouseholdEvidenceObj.modify(fSHouseholdEvidenceKey,
      fSHouseholdEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * Method used to modify fsHouseholdIncome screening assessment records
   *
   * @param dtls ModifyIncomeEvidenceDetails
   */
  @Override
  public void modifyIncomeEvidence(ModifyIncomeEvidenceDetails dtls)
    throws AppException, InformationalException {

    // FSHouseholdIncome manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    final FSHouseholdIncomeKey fSHouseholdIncomeKey = new FSHouseholdIncomeKey();
    final FSHouseholdIncomeDtls fSHouseholdIncomeDtls = new FSHouseholdIncomeDtls();

    // set up the key to modify FSHouseholdIncome
    fSHouseholdIncomeKey.fsHouseholdIncomeID = dtls.modifyIncDtls.fsHouseholdIncomeID;

    // map the details to be modified
    fSHouseholdIncomeDtls.concernRoleID = dtls.modifyIncDtls.concernRoleID;
    fSHouseholdIncomeDtls.currMonthlyAmount = dtls.modifyIncDtls.currMonthlyAmount;
    fSHouseholdIncomeDtls.fsHouseholdIncomeID = dtls.modifyIncDtls.fsHouseholdIncomeID;
    fSHouseholdIncomeDtls.incomeAmount = dtls.modifyIncDtls.incomeAmount;
    fSHouseholdIncomeDtls.incomeFrequencyCode = dtls.modifyIncDtls.incomeFrequencyCode;
    fSHouseholdIncomeDtls.incomeTypeCode = dtls.modifyIncDtls.incomeTypeCode;
    fSHouseholdIncomeDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdIncomeDtls.versionNo = dtls.modifyIncDtls.versionNo;

    fSHouseholdIncomeObj.modify(fSHouseholdIncomeKey, fSHouseholdIncomeDtls);
  }

  // ___________________________________________________________________________
  /**
   * Method used to update details of a specific record on the
   * fsHouseholdResource entity.
   *
   * @param dtls ModifyResourceEvidenceDetails
   */
  @Override
  public void modifyResourceEvidence(ModifyResourceEvidenceDetails dtls)
    throws AppException, InformationalException {

    // FSHouseholdResources manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    final FSHouseholdResourcesKey fSHouseholdResourcesKey = new FSHouseholdResourcesKey();
    final FSHouseholdResourcesDtls fSHouseholdResourcesDtls = new FSHouseholdResourcesDtls();

    // set up the key to modify FSHouseholdBenefits
    fSHouseholdResourcesKey.fsHouseholdResourcesID = dtls.modResourceDtls.fsHouseholdResourceID;

    // map the details to be modified
    fSHouseholdResourcesDtls.amountReceived = dtls.modResourceDtls.amountReceived;
    fSHouseholdResourcesDtls.assetTypeCode = dtls.modResourceDtls.assetTypeCode;
    fSHouseholdResourcesDtls.assetUsage = dtls.modResourceDtls.assetUsage;
    fSHouseholdResourcesDtls.concernRoleID = dtls.modResourceDtls.concernRoleID;
    fSHouseholdResourcesDtls.dateAquired = dtls.modResourceDtls.dateAquired;
    fSHouseholdResourcesDtls.dateDisposed = dtls.modResourceDtls.dateDisposed;
    fSHouseholdResourcesDtls.disposalReasonCode = dtls.modResourceDtls.disposalReasonCode;
    fSHouseholdResourcesDtls.fsHouseholdResourcesID = dtls.modResourceDtls.fsHouseholdResourceID;
    fSHouseholdResourcesDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    fSHouseholdResourcesDtls.totalOwed = dtls.modResourceDtls.totalOwed;
    fSHouseholdResourcesDtls.totalValue = dtls.modResourceDtls.totalValue;
    fSHouseholdResourcesDtls.versionNo = dtls.modResourceDtls.versionNo;

    fSHouseholdResourcesObj.modify(fSHouseholdResourcesKey,
      fSHouseholdResourcesDtls);
  }

  // ___________________________________________________________________________
  /**
   * Method used to remove/cancel a benefit evidence record for a household
   * member who is applying for a Food Stamps Product.
   *
   * @param key RemoveBenefitEvidenceKey
   */
  @Override
  public void removeBenefitEvidence(RemoveBenefitEvidenceKey key)
    throws AppException, InformationalException {

    // FSHouseholdBenefits manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    final FSHouseholdBenefitsKey fSHouseholdBenefitsKey = new FSHouseholdBenefitsKey();
    final FSStatusCodeVersNo fsStatusCodeVersNo = new FSStatusCodeVersNo();

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final RemoveByEvidenceIDTypeAndRelatedIDKey removeByEvidenceIDTypeAndRelatedIDKey = new RemoveByEvidenceIDTypeAndRelatedIDKey();

    // set the key to modify FSHouseholdBenefits record
    fSHouseholdBenefitsKey.fsHouseholdBenefitsID = key.cancBfitKey.fsHouseholdBenefitsID;

    // update the status to canceled
    fsStatusCodeVersNo.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
    fsStatusCodeVersNo.versionNo = key.cancBfitKey.versionNo;

    fSHouseholdBenefitsObj.modifyStatusCode(fSHouseholdBenefitsKey,
      fsStatusCodeVersNo);

    // set key to remove the case evidence link
    removeByEvidenceIDTypeAndRelatedIDKey.caseEvidenceTypeID = key.cancBfitKey.caseEvidenceTypeID;
    removeByEvidenceIDTypeAndRelatedIDKey.evidenceType = curam.codetable.CASEEVIDENCE.BENEFITEVIDENCE;
    removeByEvidenceIDTypeAndRelatedIDKey.relatedID = key.cancBfitKey.fsHouseholdBenefitsID;

    caseEvidenceLinkObj.removeByEvidenceTypeIDTypeAndRelatedID(
      removeByEvidenceIDTypeAndRelatedIDKey);
  }

  // ___________________________________________________________________________
  /**
   * Method used to remove a specified record from the fsHouseholdExpense
   * entity.
   *
   * @param key RemoveExpenseEvidenceKey
   */
  @Override
  public void removeExpenseEvidence(RemoveExpenseEvidenceKey key)
    throws AppException, InformationalException {

    // FSHouseholdExpense manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    final FSHouseholdExpensesKey fSHouseholdExpensesKey = new FSHouseholdExpensesKey();
    final FSStatusCodeVersNo fsStatusCodeVersNo = new FSStatusCodeVersNo();

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final RemoveByEvidenceIDTypeAndRelatedIDKey removeByEvidenceIDTypeAndRelatedIDKey = new RemoveByEvidenceIDTypeAndRelatedIDKey();

    // set the key to modify FSHouseholdExpense record
    fSHouseholdExpensesKey.fsHouseholdExpensesID = key.cancExpKey.fsHouseholdExpensesID;

    // update the status to canceled
    fsStatusCodeVersNo.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
    fsStatusCodeVersNo.versionNo = key.cancExpKey.versionNo;

    fSHouseholdExpensesObj.modifyStatusCode(fSHouseholdExpensesKey,
      fsStatusCodeVersNo);

    // set key to remove the case evidence link
    removeByEvidenceIDTypeAndRelatedIDKey.caseEvidenceTypeID = key.cancExpKey.caseEvidenceTypeID;
    removeByEvidenceIDTypeAndRelatedIDKey.evidenceType = curam.codetable.CASEEVIDENCE.EXPENSEEVIDENCE;
    removeByEvidenceIDTypeAndRelatedIDKey.relatedID = key.cancExpKey.fsHouseholdExpensesID;

    caseEvidenceLinkObj.removeByEvidenceTypeIDTypeAndRelatedID(
      removeByEvidenceIDTypeAndRelatedIDKey);
  }

  // ___________________________________________________________________________
  /**
   * Method used to remove details of a specified fsHouseholdEvidence record.
   *
   * @param key RemoveHouseholdEvidenceKey
   */
  @Override
  public void removeHouseholdEvidence(RemoveHouseholdEvidenceKey key)
    throws AppException, InformationalException {

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    final FSStatusCodeVersNo fsStatusCodeVersNo = new FSStatusCodeVersNo();
    FSHouseholdEvidenceDtls fsHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final RemoveByEvidenceIDTypeAndRelatedIDKey removeByEvidenceIDTypeAndRelatedIDKey = new RemoveByEvidenceIDTypeAndRelatedIDKey();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // Evidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fSHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    FSHouseholdBenefitsDtls fsHouseholdBenefitsDtls = new FSHouseholdBenefitsDtls();
    final FSHholdBenefitKey fsHholdBenefitKey = new FSHholdBenefitKey();
    final RemoveBenefitEvidenceKey removeBenefitEvidenceKey = new RemoveBenefitEvidenceKey();

    final curam.sample.sl.entity.intf.FSHouseholdExpenses fSHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    FSHouseholdExpensesDtls fsHouseholdExpensesDtls = new FSHouseholdExpensesDtls();
    final FSHholdExpenseKey fsHholdExpenseKey = new FSHholdExpenseKey();
    final RemoveExpenseEvidenceKey removeExpenseEvidenceKey = new RemoveExpenseEvidenceKey();

    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    FSHouseholdIncomeDtls fsHouseholdIncomeDtls = new FSHouseholdIncomeDtls();
    final FSHholdIncomeKey fsHholdIncomeKey = new FSHholdIncomeKey();
    final RemoveIncomeEvidenceKey removeIncomeEvidenceKey = new RemoveIncomeEvidenceKey();

    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    FSHouseholdResourcesDtls fsHouseholdResourcesDtls = new FSHouseholdResourcesDtls();
    final FSHholdResourceKey fsHholdResourceKey = new FSHholdResourceKey();
    final RemoveResourceEvidenceKey removeResourceEvidenceKey = new RemoveResourceEvidenceKey();

    // set the key to modify FSHouseholdEvidence record
    fSHouseholdEvidenceKey.fsHouseholdEvidenceID = key.cancHholdKey.fsHouseholdEvidenceID;
    // Read the record to be removed.
    fsHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
      fSHouseholdEvidenceKey);
    if (fsHouseholdEvidenceDtls.rshipToHOH.equals(
      curam.codetable.RELATIONSHIPTYPECODE.SELF)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.INCOMESCREENING.ERR_GENERAL_FV_NO_REMOVE_HOH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // update the status to canceled
    fsStatusCodeVersNo.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
    fsStatusCodeVersNo.versionNo = key.cancHholdKey.versionNo;

    fSHouseholdEvidenceObj.modifyStatusCode(fSHouseholdEvidenceKey,
      fsStatusCodeVersNo);

    // set key to remove the case evidence link
    removeByEvidenceIDTypeAndRelatedIDKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
    removeByEvidenceIDTypeAndRelatedIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;
    removeByEvidenceIDTypeAndRelatedIDKey.relatedID = key.cancHholdKey.fsHouseholdEvidenceID;

    caseEvidenceLinkObj.removeByEvidenceTypeIDTypeAndRelatedID(
      removeByEvidenceIDTypeAndRelatedIDKey);

    // Remove any associated evidence

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.BENEFITEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int j = 0; j < caseEvidenceLinkDtlsList.dtls.size(); j++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fsHholdBenefitKey.fsHouseholdBenefitsID = caseEvidenceLinkDtlsList.dtls.item(j).relatedID;
      fsHholdBenefitKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;

      try {
        // read the fSHouseholdEvidence details
        fsHouseholdBenefitsDtls = fSHouseholdBenefitsObj.readByKeyConcernRoleID(
          fsHholdBenefitKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {
        removeBenefitEvidenceKey.cancBfitKey.fsHouseholdBenefitsID = fsHouseholdBenefitsDtls.fsHouseholdBenefitsID;
        removeBenefitEvidenceKey.cancBfitKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
        removeBenefitEvidenceKey.cancBfitKey.versionNo = fsHouseholdBenefitsDtls.versionNo;

        removeBenefitEvidence(removeBenefitEvidenceKey);
      }
    } // End For

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.EXPENSEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int k = 0; k < caseEvidenceLinkDtlsList.dtls.size(); k++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fsHholdExpenseKey.fsHouseholdExpensesID = caseEvidenceLinkDtlsList.dtls.item(k).relatedID;
      fsHholdExpenseKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;

      try {
        // read the fSHouseholdEvidence details
        fsHouseholdExpensesDtls = fSHouseholdExpensesObj.readByKeyConcernRoleID(
          fsHholdExpenseKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        removeExpenseEvidenceKey.cancExpKey.fsHouseholdExpensesID = fsHouseholdExpensesDtls.fsHouseholdExpensesID;
        removeExpenseEvidenceKey.cancExpKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
        removeExpenseEvidenceKey.cancExpKey.versionNo = fsHouseholdExpensesDtls.versionNo;

        removeExpenseEvidence(removeExpenseEvidenceKey);
      }
    } // End For

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.INCOMEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fsHholdIncomeKey.fsHouseholdIncomeID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;
      fsHholdIncomeKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;

      try {
        // read the fSHouseholdEvidence details
        fsHouseholdIncomeDtls = fSHouseholdIncomeObj.readByKeyConcernRoleID(
          fsHholdIncomeKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        removeIncomeEvidenceKey.cancIncKey.fsHouseholdIncomeID = fsHouseholdIncomeDtls.fsHouseholdIncomeID;
        removeIncomeEvidenceKey.cancIncKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
        removeIncomeEvidenceKey.cancIncKey.versionNo = fsHouseholdIncomeDtls.versionNo;

        removeIncomeEvidence(removeIncomeEvidenceKey);
      }
    } // End For

    // set up key to retrieve a list of related ID's
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.RESOURCEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByTypeAndEvidenceTypeID(
      evidenceTypeAndCETypeIDKey);

    for (int l = 0; l < caseEvidenceLinkDtlsList.dtls.size(); l++) {

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
      fsHholdResourceKey.fsHouseholdResourcesID = caseEvidenceLinkDtlsList.dtls.item(l).relatedID;
      fsHholdResourceKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;

      try {
        // read the fSHouseholdEvidence details
        fsHouseholdResourcesDtls = fSHouseholdResourcesObj.readByKeyConcernRoleID(
          fsHholdResourceKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found, map the details
      if (recordFound) {

        removeResourceEvidenceKey.cancResourceKey.fsHouseholdResourceID = fsHouseholdResourcesDtls.fsHouseholdResourcesID;
        removeResourceEvidenceKey.cancResourceKey.caseEvidenceTypeID = key.cancHholdKey.caseEvidenceTypeID;
        removeResourceEvidenceKey.cancResourceKey.versionNo = fsHouseholdResourcesDtls.versionNo;

        removeResourceEvidence(removeResourceEvidenceKey);
      }
    } // End For

  }

  // ___________________________________________________________________________
  /**
   * Method used to remove/cancel a fsHouseholdIncome record from the
   * screening assessment.
   *
   * @param key RemoveIncomeEvidenceKey
   */
  @Override
  public void removeIncomeEvidence(RemoveIncomeEvidenceKey key)
    throws AppException, InformationalException {

    // FSHouseholdIncome manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdIncome fSHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    final FSHouseholdIncomeKey fSHouseholdIncomeKey = new FSHouseholdIncomeKey();
    final FSStatusCodeVersNo fsStatusCodeVersNo = new FSStatusCodeVersNo();

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final RemoveByEvidenceIDTypeAndRelatedIDKey removeByEvidenceIDTypeAndRelatedIDKey = new RemoveByEvidenceIDTypeAndRelatedIDKey();

    // set the key to modify FSHouseholdBenefits record
    fSHouseholdIncomeKey.fsHouseholdIncomeID = key.cancIncKey.fsHouseholdIncomeID;

    // update the status to canceled
    fsStatusCodeVersNo.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
    fsStatusCodeVersNo.versionNo = key.cancIncKey.versionNo;

    fSHouseholdIncomeObj.modifyStatusCode(fSHouseholdIncomeKey,
      fsStatusCodeVersNo);

    // set key to remove the case evidence link
    removeByEvidenceIDTypeAndRelatedIDKey.caseEvidenceTypeID = key.cancIncKey.caseEvidenceTypeID;
    removeByEvidenceIDTypeAndRelatedIDKey.evidenceType = curam.codetable.CASEEVIDENCE.INCOMEEVIDENCE;
    removeByEvidenceIDTypeAndRelatedIDKey.relatedID = key.cancIncKey.fsHouseholdIncomeID;

    caseEvidenceLinkObj.removeByEvidenceTypeIDTypeAndRelatedID(
      removeByEvidenceIDTypeAndRelatedIDKey);

  }

  // ___________________________________________________________________________
  /**
   * Method used to remove/cancel a specified record from the
   * fsHouseholdResource entity.
   *
   * @param key RemoveResourceEvidenceKey
   */
  @Override
  public void removeResourceEvidence(RemoveResourceEvidenceKey key)
    throws AppException, InformationalException {

    // FSHouseholdResources manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdResources fSHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    final FSHouseholdResourcesKey fSHouseholdResourcesKey = new FSHouseholdResourcesKey();
    final FSStatusCodeVersNo fsStatusCodeVersNo = new FSStatusCodeVersNo();

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final RemoveByEvidenceIDTypeAndRelatedIDKey removeByEvidenceIDTypeAndRelatedIDKey = new RemoveByEvidenceIDTypeAndRelatedIDKey();

    // set the key to modify FSHouseholdResource record
    fSHouseholdResourcesKey.fsHouseholdResourcesID = key.cancResourceKey.fsHouseholdResourceID;

    // update the status to canceled
    fsStatusCodeVersNo.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;
    fsStatusCodeVersNo.versionNo = key.cancResourceKey.versionNo;

    fSHouseholdResourcesObj.modifyStatusCode(fSHouseholdResourcesKey,
      fsStatusCodeVersNo);

    // set key to remove the case evidence link
    removeByEvidenceIDTypeAndRelatedIDKey.caseEvidenceTypeID = key.cancResourceKey.caseEvidenceTypeID;
    removeByEvidenceIDTypeAndRelatedIDKey.evidenceType = curam.codetable.CASEEVIDENCE.RESOURCEEVIDENCE;
    removeByEvidenceIDTypeAndRelatedIDKey.relatedID = key.cancResourceKey.fsHouseholdResourceID;

    caseEvidenceLinkObj.removeByEvidenceTypeIDTypeAndRelatedID(
      removeByEvidenceIDTypeAndRelatedIDKey);
  }

  // ___________________________________________________________________________
  /**
   * To retrieve the household benefit evidence for each member of the
   * household
   *
   * @param key containing caseID, caseEvidenceTypeID
   *
   * @return List of all household benefit evidence
   */
  @Override
  public HouseholdMemberBenefitDetails readBenefitEvidenceDtls(
    HouseholdDetailsKey key) throws AppException, InformationalException {

    final HouseholdMemberBenefitDetails householdMemberBenefitDetails = new HouseholdMemberBenefitDetails();

    // Case Evidence Link variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList = new CaseEvidenceLinkDtlsList();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();

    // fsHouseholdBenefits object and details
    final curam.sample.sl.entity.intf.FSHouseholdBenefits fsHouseholdBenefitsObj = curam.sample.sl.entity.fact.FSHouseholdBenefitsFactory.newInstance();
    FSHouseholdBenefitsDtls fsHouseholdBenefitsDtls = new FSHouseholdBenefitsDtls();
    final FSHholdBenefitKey fsHholdBenefitKey = new FSHholdBenefitKey();

    // Read Household Income
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.BENEFITEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        // recordNotFound indicator
        boolean recordNotFound = false;

        fsHholdBenefitKey.fsHouseholdBenefitsID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;
        fsHholdBenefitKey.concernRoleID = key.concernRoleID;

        try {
          fsHouseholdBenefitsDtls = fsHouseholdBenefitsObj.readByKeyConcernRoleID(
            fsHholdBenefitKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (!recordNotFound) {
          if (fsHouseholdBenefitsDtls.benefitTypeCode.equals(
            curam.codetable.BENEFITTYPECODE.FOODSTAMPS)) {

            householdMemberBenefitDetails.foodStampsRecipientInd = true;
          }

          if (fsHouseholdBenefitsDtls.benefitTypeCode.equals(
            curam.codetable.BENEFITTYPECODE.TANF)) {

            householdMemberBenefitDetails.tanfRecipientInd = true;
          } // end if BENEFITTYPECODE.TANF
        } // end !recordNotFound
      } // end For
    } // !caseEvidenceLinkDtlsList.dtls.isEmpty()

    return householdMemberBenefitDetails;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve the household expenses evidence for each member of the
   * household
   *
   * @param key containing caseID, caseEvidenceTypeID
   *
   * @return List of all household Expense evidence
   */
  @Override
  public HouseholdMemberExpenseDetails readExpenseEvidenceDtls(
    HouseholdExpenseDetailsKey key) throws AppException,
      InformationalException {

    final HouseholdMemberExpenseDetails householdMemberExpenseDetails = new HouseholdMemberExpenseDetails();

    // Case Evidence Link variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList = new CaseEvidenceLinkDtlsList();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();

    // fsHouseholdExpenses object and details
    final curam.sample.sl.entity.intf.FSHouseholdExpenses fsHouseholdExpensesObj = curam.sample.sl.entity.fact.FSHouseholdExpensesFactory.newInstance();
    FSHouseholdExpensesDtls fsHouseholdExpensesDtls = new FSHouseholdExpensesDtls();
    final FSHholdExpenseKey fsHholdExpenseKey = new FSHholdExpenseKey();

    // Read Household Income
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.EXPENSEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    // recordNotFound indicator
    curam.util.type.Money shelterExpenseTotal = new curam.util.type.Money(0);
    curam.util.type.Money medicalExpenseTotal = new curam.util.type.Money(0);
    final int kAge60 = 60;

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        boolean recordNotFound = false;

        fsHholdExpenseKey.fsHouseholdExpensesID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;
        fsHholdExpenseKey.concernRoleID = key.concernRoleID;

        try {
          fsHouseholdExpensesDtls = fsHouseholdExpensesObj.readByKeyConcernRoleID(
            fsHholdExpenseKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (!recordNotFound) {

          if (fsHouseholdExpensesDtls.expenseCategoryCode.equals(
            curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES)) {
            if (!fsHouseholdExpensesDtls.expenseTypeCode.equals(
              curam.codetable.SHELTEREXPENSETYPE.APPLIANCEREPAIR)
                && !fsHouseholdExpensesDtls.expenseTypeCode.equals(
                  curam.codetable.SHELTEREXPENSETYPE.MAINTENANCEFEES)
                  && !fsHouseholdExpensesDtls.expenseTypeCode.equals(
                    curam.codetable.SHELTEREXPENSETYPE.CABLETVINSTALL)
                    && !fsHouseholdExpensesDtls.expenseTypeCode.equals(
                      curam.codetable.SHELTEREXPENSETYPE.VENDORPAYMENT)) {

              shelterExpenseTotal = new curam.util.type.Money(
                shelterExpenseTotal.getValue()
                  + fsHouseholdExpensesDtls.currMthlyExpenseAmount.getValue());

            } // End expenseTypeCode
          } // End expenseCategoryCode

          if (fsHouseholdExpensesDtls.expenseCategoryCode.equals(
            curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES)) {
            if (!fsHouseholdExpensesDtls.expenseTypeCode.equals(
              curam.codetable.MEDICALEXPENSETYPE.SPECIALDIETS)
                && !fsHouseholdExpensesDtls.expenseTypeCode.equals(
                  curam.codetable.MEDICALEXPENSETYPE.INTERESTONLOAN)
                  && !fsHouseholdExpensesDtls.expenseTypeCode.equals(
                    curam.codetable.MEDICALEXPENSETYPE.REIMBURSEDEXPENSES)) {

              if (key.memberAge >= kAge60) {

                medicalExpenseTotal = new curam.util.type.Money(
                  medicalExpenseTotal.getValue()
                    + fsHouseholdExpensesDtls.currMthlyExpenseAmount.getValue());

              } // End if over60
            } // End expense Type Code
          } // End Expense Category Code

        } // End !recordNotFound
      } // End For

      householdMemberExpenseDetails.shelterExpenseTotal = shelterExpenseTotal;
      householdMemberExpenseDetails.medicalExpenseTotal = medicalExpenseTotal;

    }
    return householdMemberExpenseDetails;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve the household evidence for each member of the household
   *
   * @param key containing caseID, assessmentID and dateOfCalculation
   *
   * @return List of all household related evidence
   */
  @Override
  @SuppressWarnings("deprecation")
  public HouseholdEvidenceDetailsList readHouseholdEvidenceDtls(
    HouseholdEvidenceKey key) throws AppException, InformationalException {

    HouseholdEvidenceDetails householdEvidenceDetails;

    final HouseholdEvidenceDetailsList householdEvidenceDetailsList = new HouseholdEvidenceDetailsList();

    // Manipulate Evidence Tree variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // Case Evidence Link variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList = new CaseEvidenceLinkDtlsList();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();

    // person variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    PersonDtls personDtls = new PersonDtls();
    final PersonKey personKey = new PersonKey();

    // prospect person variables
    final curam.core.intf.ProspectPerson prospectPersonObj = curam.core.fact.ProspectPersonFactory.newInstance();
    ProspectPersonDtls prospectPersonDtls = new ProspectPersonDtls();
    final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

    // Concern Role variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Concern Role Alternate IDvariables
    final curam.core.intf.ConcernRoleAlternateID concernRoleAltIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    final SearchForAltIDKey searchForAltIDKey = new SearchForAltIDKey();

    // fsHouseholdEvidence object and details
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fsHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    FSHouseholdEvidenceDtls fsHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();
    final FSHouseholdEvidenceKey fsHouseholdEvidenceKey = new FSHouseholdEvidenceKey();

    // read Evidence details
    final HouseholdDetailsKey householdDetailsKey = new HouseholdDetailsKey();
    final HouseholdExpenseDetailsKey householdExpenseDetailsKey = new HouseholdExpenseDetailsKey();
    HouseholdMemberResourceDetails householdMemberResourceDetails = new HouseholdMemberResourceDetails();
    HouseholdMemberIncomeDetails householdMemberIncomeDetails = new HouseholdMemberIncomeDetails();
    HouseholdMemberBenefitDetails householdMemberBenefitDetails = new HouseholdMemberBenefitDetails();
    HouseholdMemberExpenseDetails householdMemberExpenseDetails = new HouseholdMemberExpenseDetails();

    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = key.assessmentID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = curam.util.type.Date.getCurrentDate();
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return householdEvidenceDetailsList;
    }

    // Read Household Evidence
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        // recordNotFound indicator
        boolean recordNotFound = false;

        curam.util.type.Date dateOfBirth = curam.util.type.Date.kZeroDate;

        householdEvidenceDetails = new HouseholdEvidenceDetails();

        fsHouseholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fsHouseholdEvidenceDtls = fsHouseholdEvidenceObj.read(
          fsHouseholdEvidenceKey);

        // Read the concern role details
        concernRoleKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;
        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        if (concernRoleDtls.concernRoleType.equals(
          curam.codetable.CONCERNROLETYPE.PERSON)) {

          // Read the person information
          personKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;
          personDtls = personObj.read(personKey);
          dateOfBirth = personDtls.dateOfBirth;

        } else {
          if (concernRoleDtls.concernRoleType.equals(
            curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {

            // Read the person information
            prospectPersonKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;
            prospectPersonDtls = prospectPersonObj.read(prospectPersonKey);
            dateOfBirth = prospectPersonDtls.dateOfBirth;

          }
        }

        // Read the concern role alternate id details
        searchForAltIDKey.alternateID = concernRoleDtls.primaryAlternateID;
        searchForAltIDKey.concernRoleID = concernRoleDtls.concernRoleID;

        searchForAltIDKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

        // Perform the search to see if any records were returned
        try {
          concernRoleAltIDObj.readForAltID(searchForAltIDKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (recordNotFound) {
          householdEvidenceDetails.invalidSSNInd = true;
        } else {
          householdEvidenceDetails.invalidSSNInd = false;
        }

        // Approximate age in years
        householdEvidenceDetails.memberAge = key.dateOfCalculation.getCalendar().get(
          java.util.Calendar.YEAR)
            - dateOfBirth.getCalendar().get(java.util.Calendar.YEAR);

        // If the current month is earlier in the year than
        // the person's birth month, decrement the age by one
        if (key.dateOfCalculation.getCalendar().get(java.util.Calendar.MONTH)
          + 1
            < dateOfBirth.getCalendar().get(java.util.Calendar.MONTH) + 1) {

          householdEvidenceDetails.memberAge--;

        }

        // If the current month is equal to the person's birth month,
        // and today is before their birthday, decrement the age by one
        if (key.dateOfCalculation.getCalendar().get(java.util.Calendar.MONTH)
          + 1
            == dateOfBirth.getCalendar().get(java.util.Calendar.MONTH) + 1
              && key.dateOfCalculation.getCalendar().get(
                java.util.Calendar.DAY_OF_MONTH)
                  < dateOfBirth.getCalendar().get(
                    java.util.Calendar.DAY_OF_MONTH)) {

          householdEvidenceDetails.memberAge--;

        }

        if (fsHouseholdEvidenceDtls.rshipToHOH.equals(
          curam.codetable.RELATIONSHIPTYPECODE.SELF)) {
          householdEvidenceDetails.headOfHouseholdInd = true;
        } else {
          householdEvidenceDetails.headOfHouseholdInd = false;
        }

        if (fsHouseholdEvidenceDtls.rshipToHOH.equals(
          curam.codetable.RELATIONSHIPTYPECODE.ATTENDANT)) {
          householdEvidenceDetails.liveInAttendantInd = true;
        } else {
          householdEvidenceDetails.liveInAttendantInd = false;
        }

        if (fsHouseholdEvidenceDtls.rshipToHOH.equals(
          curam.codetable.RELATIONSHIPTYPECODE.SPOUSE)) {
          householdEvidenceDetails.spouseOfHOHInd = true;
        } else {
          householdEvidenceDetails.spouseOfHOHInd = false;
        }
        if (fsHouseholdEvidenceDtls.rshipToHOH.equals(
          curam.codetable.RELATIONSHIPTYPECODE.CHILD)) {
          householdEvidenceDetails.residingWithParentsInd = true;
        } else {
          householdEvidenceDetails.residingWithParentsInd = false;
        }

        if (caseEvidenceLinkDtlsList.dtls.size() > 1) {
          householdEvidenceDetails.livingAloneInd = false;
        } else {
          householdEvidenceDetails.livingAloneInd = true;
        }

        if (fsHouseholdEvidenceDtls.citizenshipCode.equals(
          curam.codetable.CITIZENSHIPCODE.INELIGIBLEALIEN)) {
          householdEvidenceDetails.ineligibleAlienInd = true;
        } else {
          householdEvidenceDetails.ineligibleAlienInd = false;
        }

        householdEvidenceDetails.strikerInd = fsHouseholdEvidenceDtls.strikerInd;
        householdEvidenceDetails.disabledInd = fsHouseholdEvidenceDtls.disabledInd;
        householdEvidenceDetails.memberName = concernRoleDtls.concernRoleName;
        householdEvidenceDetails.prepareMealsInd = fsHouseholdEvidenceDtls.prepareMealsInd;

        householdDetailsKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        householdDetailsKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;

        // Retrieve the fsHouseholdIncome details
        householdMemberIncomeDetails = readIncomeEvidenceDtls(
          householdDetailsKey);

        householdEvidenceDetails.earnedIncomeAmount = householdMemberIncomeDetails.countableEarnedIncome;
        householdEvidenceDetails.unearnedIncomeAmount = householdMemberIncomeDetails.countableUnearnedIncome;

        // Retrieve the fsHouseholdResource details
        householdMemberResourceDetails = readResourceEvidenceDtls(
          householdDetailsKey);
        householdEvidenceDetails.resourceAmount = householdMemberResourceDetails.countableResourceAmount;
        householdEvidenceDetails.invalidResourceTransferInd = householdMemberResourceDetails.invalidResourceTransferInd;

        householdExpenseDetailsKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
        householdExpenseDetailsKey.concernRoleID = fsHouseholdEvidenceDtls.concernRoleID;
        householdExpenseDetailsKey.memberAge = householdEvidenceDetails.memberAge;

        // Retrieve the fsHouseholdExpense details
        householdMemberExpenseDetails = readExpenseEvidenceDtls(
          householdExpenseDetailsKey);

        householdEvidenceDetails.medicalExpenseTotal = householdMemberExpenseDetails.medicalExpenseTotal;
        householdEvidenceDetails.shelterExpenseTotal = householdMemberExpenseDetails.shelterExpenseTotal;

        // Retrieve the fsHouseholdBenefit details
        householdMemberBenefitDetails = readBenefitEvidenceDtls(
          householdDetailsKey);

        householdEvidenceDetails.foodStampsRecipientInd = householdMemberBenefitDetails.foodStampsRecipientInd;
        householdEvidenceDetails.tanfRecipientInd = householdMemberBenefitDetails.tanfRecipientInd;

        householdEvidenceDetailsList.hholdDtlsList.addRef(
          householdEvidenceDetails);
      }
    }

    return householdEvidenceDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve the household income evidence for each member of the household
   *
   * @param key containing caseID, caseEvidenceTypeID
   *
   * @return List of all household income evidence
   */
  @Override
  public HouseholdMemberIncomeDetails readIncomeEvidenceDtls(
    HouseholdDetailsKey key) throws AppException, InformationalException {

    final HouseholdMemberIncomeDetails householdMemberIncomeDetails = new HouseholdMemberIncomeDetails();

    // Case Evidence Link variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList = new CaseEvidenceLinkDtlsList();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();

    // fsHouseholdIncome object and details
    final curam.sample.sl.entity.intf.FSHouseholdIncome fsHouseholdIncomeObj = curam.sample.sl.entity.fact.FSHouseholdIncomeFactory.newInstance();
    FSHouseholdIncomeDtls fsHouseholdIncomeDtls = new FSHouseholdIncomeDtls();
    final FSHholdIncomeKey fsHholdIncomeKey = new FSHholdIncomeKey();

    // Read Household Income
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.INCOMEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    curam.util.type.Money totalEarnedIncome = new curam.util.type.Money(0);
    curam.util.type.Money totalUnearnedIncome = new curam.util.type.Money(0);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        // recordNotFound indicator
        boolean recordNotFound = false;

        fsHholdIncomeKey.fsHouseholdIncomeID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;
        fsHholdIncomeKey.concernRoleID = key.concernRoleID;

        try {
          fsHouseholdIncomeDtls = fsHouseholdIncomeObj.readByKeyConcernRoleID(
            fsHholdIncomeKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (!recordNotFound) {
          if (fsHouseholdIncomeDtls.incomeTypeCode.equals(
            curam.codetable.INCOMETYPECODE.WAGESANDSALARIES)
              || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                curam.codetable.INCOMETYPECODE.TIPSANDCOMMISSION)
                || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                  curam.codetable.INCOMETYPECODE.SELFEMPINCOME)
                  || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                    curam.codetable.INCOMETYPECODE.CAPITALGAINS)) {

            totalEarnedIncome = new curam.util.type.Money(
              totalEarnedIncome.getValue()
                + fsHouseholdIncomeDtls.currMonthlyAmount.getValue());

          } else {

            if (fsHouseholdIncomeDtls.incomeTypeCode.equals(
              curam.codetable.INCOMETYPECODE.WORKERSCOMP)
                || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                  curam.codetable.INCOMETYPECODE.ANNUITIESPENSIONS)
                  || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                    curam.codetable.INCOMETYPECODE.ASSISTANCEPMTS)
                    || fsHouseholdIncomeDtls.incomeTypeCode.equals(
                      curam.codetable.INCOMETYPECODE.DIVIDENDINTERESTROYALTY)) {

              totalUnearnedIncome = new curam.util.type.Money(
                totalUnearnedIncome.getValue()
                  + fsHouseholdIncomeDtls.currMonthlyAmount.getValue());

            } // End if unearned income type
          } // End if earned income type
        } // End if record not found
      } // end for

      householdMemberIncomeDetails.countableEarnedIncome = totalEarnedIncome;
      householdMemberIncomeDetails.countableUnearnedIncome = totalUnearnedIncome;

    } // end list size

    return householdMemberIncomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve the household resource evidence for each member of the
   * household
   *
   * @param key containing caseID, caseEvidenceTypeID
   *
   * @return List of all household resource evidence
   */
  @Override
  public HouseholdMemberResourceDetails readResourceEvidenceDtls(
    HouseholdDetailsKey key) throws AppException, InformationalException {

    final HouseholdMemberResourceDetails householdMemberResourceDetails = new HouseholdMemberResourceDetails();

    // Case Evidence Link variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList = new CaseEvidenceLinkDtlsList();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();

    // fsHouseholdResource object and details
    final curam.sample.sl.entity.intf.FSHouseholdResources fsHouseholdResourcesObj = curam.sample.sl.entity.fact.FSHouseholdResourcesFactory.newInstance();
    FSHouseholdResourcesDtls fsHouseholdResourceDtls = new FSHouseholdResourcesDtls();
    final FSHholdResourceKey fsHholdResourceKey = new FSHholdResourceKey();
    // blank date
    final curam.util.type.Date blankDate = curam.util.type.Date.kZeroDate;

    // Frequency Pattern Data
    final curam.util.type.FrequencyPattern freqPatternMonthly = new curam.util.type.FrequencyPattern(
      // BEGIN, CR00163471, JC
      curam.message.BPOCASEEVENTSREPORT.INF_QUARTERLY.getMessageText(
        TransactionInfo.getProgramLocale()));

    // END, CR00163471, JC

    // Read Household Income
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.RESOURCEEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    curam.util.type.Money totalResourceAmount = new curam.util.type.Money(0);

    curam.util.type.Date todayDate;

    todayDate = curam.util.type.Date.getCurrentDate();
    curam.util.type.Date cutoffDate;

    cutoffDate = curam.util.type.Date.kZeroDate;

    // Today minus three months
    cutoffDate = freqPatternMonthly.getPrevOccurrence(todayDate);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        // recordNotFound indicator
        boolean recordNotFound = false;

        fsHholdResourceKey.fsHouseholdResourcesID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;
        fsHholdResourceKey.concernRoleID = key.concernRoleID;

        try {
          fsHouseholdResourceDtls = fsHouseholdResourcesObj.readByKeyConcernRoleID(
            fsHholdResourceKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (!recordNotFound) {

          if (!fsHouseholdResourceDtls.assetTypeCode.equals(
            curam.codetable.ASSETTYPECODE.VEHICLES)
              && !fsHouseholdResourceDtls.assetTypeCode.equals(
                curam.codetable.ASSETTYPECODE.LIFEINSURANCE)
                && !fsHouseholdResourceDtls.assetTypeCode.equals(
                  curam.codetable.ASSETTYPECODE.HOMEPROPERTY)
                  && !fsHouseholdResourceDtls.assetTypeCode.equals(
                    curam.codetable.ASSETTYPECODE.HEATINGASSISTANCE)
                    && !fsHouseholdResourceDtls.assetTypeCode.equals(
                      curam.codetable.ASSETTYPECODE.PREPAIDBURIALPLAN)) {

            // Check for transfers
            // Calculate 3 months from today

            if (!fsHouseholdResourceDtls.dateDisposed.equals(blankDate)) {
              if (fsHouseholdResourceDtls.disposalReasonCode.equals(
                curam.codetable.ASSETDISPOSALREASON.COURTORDERED)
                  || fsHouseholdResourceDtls.disposalReasonCode.equals(
                    curam.codetable.ASSETDISPOSALREASON.SETTLELEGALCLAIM)
                    || fsHouseholdResourceDtls.disposalReasonCode.equals(
                      curam.codetable.ASSETDISPOSALREASON.VICTIMOFFRAUD)
                      || fsHouseholdResourceDtls.dateDisposed.before(cutoffDate)) {

                householdMemberResourceDetails.invalidResourceTransferInd = false;

              } else {

                householdMemberResourceDetails.invalidResourceTransferInd = true;

              } // end valid transfer check

            } else {

              if (fsHouseholdResourceDtls.totalValue.getValue()
                > fsHouseholdResourceDtls.totalOwed.getValue()) {

                totalResourceAmount = new curam.util.type.Money(
                  totalResourceAmount.getValue()
                    + (fsHouseholdResourceDtls.totalValue.getValue()
                      - fsHouseholdResourceDtls.totalOwed.getValue()));

              } // End totalValue > totalOwed
            } // End dateDisposed != blank date
          } // End Not exempt resource
        } // End !recordNotFound
      } // End For

      householdMemberResourceDetails.countableResourceAmount = new curam.util.type.Money(
        totalResourceAmount);
    } // End !caseEvidenceLinkDtlsList.dtls.isEmpty

    return householdMemberResourceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Calculate the net income amount for the household
   *
   * @param key CalculateIncomeKey
   *
   * @return Net income amount for the household
   */
  @Override
  public CalculateIncomeDtls calculateNetIncome(CalculateIncomeKey key)
    throws AppException, InformationalException {

    final CalculateIncomeDtls calculateIncomeDtls = new CalculateIncomeDtls();

    // change all doubles to Money objects as it's not safe to perform
    // arithmetic operations
    // involving both types or to perform comparisons on the results between the
    // 2 different types
    curam.util.type.Money earnedIncomeDeduction = new curam.util.type.Money(0);
    curam.util.type.Money totalDeduction = new curam.util.type.Money(0);
    curam.util.type.Money totalIncome = new curam.util.type.Money(0);
    curam.util.type.Money netIncomeAmount = new curam.util.type.Money(0);
    curam.util.type.Money shelterDeduction = new curam.util.type.Money(0);

    if (key.earnedIncomeTotal.getValue() > 0
      || key.unearnedIncomeTotal.getValue() > 0) {

      if (key.earnedIncomeTotal.getValue() > 0) {
        earnedIncomeDeduction = new curam.util.type.Money(
          key.earnedIncomeTotal.getValue()
            * new curam.util.type.Money(key.earnedIncomePercent).getValue());
      }

      totalIncome = new curam.util.type.Money(
        key.earnedIncomeTotal.getValue() + key.unearnedIncomeTotal.getValue());

      if (key.countableMembers < 5) {

        totalDeduction = new curam.util.type.Money(
          totalDeduction.getValue()
            + (earnedIncomeDeduction.getValue()
              + key.standardDeductionAmt.getValue()));

      } else {

        if (key.countableMembers < 6) {

          totalDeduction = new curam.util.type.Money(
            totalDeduction.getValue()
              + (earnedIncomeDeduction.getValue()
                + key.standard5DeductionAmt.getValue()));

        } else {

          totalDeduction = new curam.util.type.Money(
            totalDeduction.getValue()
              + (earnedIncomeDeduction.getValue()
                + key.standard6DeductionAmt.getValue()));

        }
      }

      if (key.medicalCostsTotal.getValue()
        > key.medicalCostsExcessAmount.getValue()) {

        totalDeduction = new curam.util.type.Money(
          totalDeduction.getValue()
            + (key.medicalCostsTotal.getValue()
              - key.medicalCostsExcessAmount.getValue()));

      }

      netIncomeAmount = new curam.util.type.Money(
        totalIncome.getValue() - totalDeduction.getValue());

      if (key.shelterExpenseTotal.getValue() > 0) {

        shelterDeduction = new curam.util.type.Money(
          netIncomeAmount.getValue()
            * new curam.util.type.Money(key.shelterExpensePercent).getValue());

        if (key.shelterExpenseTotal.getValue() > shelterDeduction.getValue()) {

          shelterDeduction = new curam.util.type.Money(
            key.shelterExpenseTotal.getValue() - shelterDeduction.getValue());

          if (shelterDeduction.getValue()
            > key.shelterExpenseMaxAmount.getValue()) {

            shelterDeduction = key.shelterExpenseMaxAmount;

          }
        } else {

          shelterDeduction = new curam.util.type.Money(0);

        }
      } else {

        shelterDeduction = new curam.util.type.Money(0);

      }

      netIncomeAmount = new curam.util.type.Money(
        netIncomeAmount.getValue() - shelterDeduction.getValue());

      calculateIncomeDtls.netIncomeAmount = new curam.util.type.Money(
        netIncomeAmount);
    }

    return calculateIncomeDtls;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve the Maximum income limits by household size
   *
   * @param key household size
   *
   * @return Gross and Net income limits for the household size
   */
  @Override
  public IncomeLimitDetails getIncomeLimits(GetIncomeLimitsKey key)
    throws AppException, InformationalException {

    final IncomeLimitDetails incomeLimitDetails = new IncomeLimitDetails();

    final FSIncomeLimitsKey fsIncomeLimitsKey = new FSIncomeLimitsKey();

    FSIncomeLimitsDtls fsIncomeLimitsDtls = new FSIncomeLimitsDtls();

    // Income manipulation variables
    final curam.sample.sl.entity.intf.FSIncomeLimits fsIncomeLimitsObj = curam.sample.sl.entity.fact.FSIncomeLimitsFactory.newInstance();

    // Household Size variable
    FSHouseholdSize fsHouseholdSize = new FSHouseholdSize();

    // recordNotFound indicator
    boolean recordNotFound = false;

    curam.util.type.Money grossIncomeLimit = new curam.util.type.Money(0);
    curam.util.type.Money netIncomeLimit = new curam.util.type.Money(0);
    curam.util.type.Money grossIncomeAmount = new curam.util.type.Money(0);

    // set fsFamilySize.fsFamilySize
    fsIncomeLimitsKey.householdSize = key.householdSize;

    try {
      fsIncomeLimitsDtls = fsIncomeLimitsObj.read(fsIncomeLimitsKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      fsIncomeLimitsDtls = new FSIncomeLimitsDtls();
      recordNotFound = true;
    }

    if (recordNotFound) {
      // get maximum Household size
      fsHouseholdSize = fsIncomeLimitsObj.readMaxHouseholdSize();

      fsIncomeLimitsKey.householdSize = fsHouseholdSize.householdSize;

      // read grossIncome by familySize
      fsIncomeLimitsDtls = fsIncomeLimitsObj.read(fsIncomeLimitsKey);

      fsHouseholdSize.householdSize = key.householdSize
        - fsHouseholdSize.householdSize;

      grossIncomeLimit = new curam.util.type.Money(
        fsHouseholdSize.householdSize * key.addGrossIncomeLimit.getValue());

      netIncomeLimit = new curam.util.type.Money(
        fsHouseholdSize.householdSize * key.addNetIncomeLimit.getValue());

      grossIncomeLimit = new curam.util.type.Money(
        grossIncomeLimit.getValue()
          + fsIncomeLimitsDtls.grossMthlyIncomeLimit.getValue());

      netIncomeLimit = new curam.util.type.Money(
        netIncomeLimit.getValue()
          + fsIncomeLimitsDtls.netMthlyIncomeLimit.getValue());

    } else {

      grossIncomeLimit = fsIncomeLimitsDtls.grossMthlyIncomeLimit;
      netIncomeLimit = fsIncomeLimitsDtls.netMthlyIncomeLimit;
    }

    grossIncomeAmount = new curam.util.type.Money(
      grossIncomeAmount.getValue() + key.earnedIncomeAmount.getValue());

    grossIncomeAmount = new curam.util.type.Money(
      grossIncomeAmount.getValue() + key.unearnedIncomeAmount.getValue());

    incomeLimitDetails.grossIncomeLimit = grossIncomeLimit;
    incomeLimitDetails.netIncomeLimit = netIncomeLimit;
    incomeLimitDetails.grossIncomeAmount = grossIncomeAmount;

    return incomeLimitDetails;
  }

  // ___________________________________________________________________________
  /**
   * To the determine the AssessmentID and AssessmentConfigurationID for
   * the assessment
   *
   * @param key containing the CaseID
   *
   * @return The AssessmentID and AssessmentConfigutationID
   */
  @Override
  public AssessmentInfoDtls determineAssessmentInfo(AssessmentInfoKey key)
    throws AppException, InformationalException {

    final AssessmentInfoDtls assessmentInfoDtls = new AssessmentInfoDtls();

    // Assessment variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList = new AssessmentDtlsList();

    // Assessment Configuration variables
    final curam.core.intf.AssessmentConfiguration assessmentConfigObj = curam.core.fact.AssessmentConfigurationFactory.newInstance();
    AssessmentConfigurationKey assessmentConfigurationkey = new AssessmentConfigurationKey();
    final AssessmentNameStruct assessmentName = new AssessmentNameStruct();

    assessmentReadmultiKey.caseID = key.assessKey.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    for (int i = 0; i < assessmentDtlsList.dtls.size(); i++) {

      assessmentInfoDtls.assessmentID = assessmentDtlsList.dtls.item(i).assessmentID;

      break;
    }

    // Retrieve the Assessment ConfigurationID

    assessmentName.name = curam.codetable.ASSESSMENTNAME.FOODSTAMPS;

    assessmentConfigurationkey = assessmentConfigObj.readByName(assessmentName);

    assessmentInfoDtls.assessmentConfigurationID = assessmentConfigurationkey.assessmentConfigurationID;

    return assessmentInfoDtls;
  }

  // ___________________________________________________________________________
  /**
   * To manipulate the assessment result
   *
   * @param dtls Containing the assessment result
   */
  @Override
  public void manipulateAssessmentResult(AssessmentResultText dtls)
    throws AppException, InformationalException {

    final curam.core.intf.AssessmentObjective assessmentObjectiveObj = curam.core.fact.AssessmentObjectiveFactory.newInstance();
    final AssessmentObjectiveReadmultiKey assessmentObjectiveKey = new AssessmentObjectiveReadmultiKey();
    AssessmentObjectiveDtlsList assessmentObjectiveDtlsList;

    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentKey assessmentKey = new AssessmentKey();
    AssessmentDtls assessmentDtls;

    assessmentObjectiveKey.assessmentID = dtls.assessmentID;

    assessmentObjectiveDtlsList = assessmentObjectiveObj.searchByAssessmentID(
      assessmentObjectiveKey);

    // read Assessment from database
    assessmentKey.assessmentID = dtls.assessmentID;
    assessmentDtls = assessmentObj.read(assessmentKey, true);

    if (assessmentObjectiveDtlsList.dtls.size() == 0) {

      assessmentDtls.assessmentResult = curam.codetable.ASSESSMENTRESULT.FAIL;
      assessmentObj.modify(assessmentKey, assessmentDtls);
      dtls.assessmentResultText = // BEGIN, CR00163471, JC
        curam.message.INCOMESCREENING.INF_GENERAL_HOUSEHOLD_INELIGIBLE.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    } else {

      assessmentDtls.assessmentResult = curam.codetable.ASSESSMENTRESULT.SUCCESS;
      assessmentObj.modify(assessmentKey, assessmentDtls);
      dtls.assessmentResultText = // BEGIN, CR00163471, JC
        curam.message.INCOMESCREENING.INF_GENERAL_HOUSEHOLD_ELIGIBLE.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    }

  }

  // ___________________________________________________________________________
  /**
   * To the determine the Member details for the assessment
   *
   * @param key contains the CaseEvidenceTypeID
   *
   * @return Member Name and caseID
   */
  @Override
  public GetMemberDetailsList getMemberDetails(GetMembersListKey key)
    throws AppException, InformationalException {

    // variable to store return values
    final GetMemberDetailsList getMemberDetailsList = new GetMemberDetailsList();

    // remove this later when model has included assignments
    GetHouseholdMemberDetails getMemberDetails;

    // FSHouseholdEvidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // set up key to read a list of case evidence link records
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = key.mbrDtlsList.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    // call method to retrieve a list of related ID's for household evidence
    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // for each element in CaseEvidenceLinkDtlsList read the
      // FSHouseholdBenefits evidence record
      for (int i = 0; i < caseEvidenceLinkDtlsList.dtls.size(); i++) {

        getMemberDetails = new GetHouseholdMemberDetails();

        // set the key for the FSHouseholdEvidence entity read
        fSHouseholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(i).relatedID;

        fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
          fSHouseholdEvidenceKey);

        // populate the return struct with FS Household Evidence details
        getMemberDetails.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;
        // set up key to perform a concern role read
        concernRoleKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // populate the return struct with concern role details
        getMemberDetails.memberName = concernRoleDtls.concernRoleName;

        // map the details to the output struct
        getMemberDetailsList.getMbrDtls.addRef(getMemberDetails);

      }
    }

    return getMemberDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * To insert a new home phone number on the system
   *
   * @param dtls InsertHomePhoneDtls
   */
  @Override
  public void insertHomePhoneNumber(InsertHomePhoneDtls dtls)
    throws AppException, InformationalException {

    // MaintainConcernRolePhoneNumber manipulation variables
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    final ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();

    // map the key to create the phone number
    maintainPhoneNumberKey.concernRoleID = dtls.concernRoleID;

    // map the details to create the phone number
    concernRolePhoneDetails.concernRoleID = dtls.concernRoleID;
    concernRolePhoneDetails.phoneAreaCode = dtls.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = dtls.phoneCountryCode;
    concernRolePhoneDetails.phoneExtension = dtls.phoneExtension;
    concernRolePhoneDetails.phoneNumber = dtls.phoneNumber;
    concernRolePhoneDetails.primaryPhoneInd = true;
    concernRolePhoneDetails.startDate = curam.util.type.Date.getCurrentDate();
    concernRolePhoneDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    concernRolePhoneDetails.typeCode = curam.codetable.PHONETYPE.PERSONAL;

    maintainConcernRolePhoneObj.createPhoneNumber(maintainPhoneNumberKey,
      concernRolePhoneDetails);
  }

  // ___________________________________________________________________________
  /**
   * To create a new mailing address on the system
   *
   * @param dtls InsertMailingAddressDtls
   */
  @Override
  public void insertMailingAddress(final InsertMailingAddressDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00360875, ELG
    // MaintainConcernRoleAddress manipulation variables
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();
    final AddressDetails addressDetails = new AddressDetails();

    // ConcernRoleAddress manipulation variables
    final curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();
    final AddressForConcernRoleKey addressForConcernRoleKey = new AddressForConcernRoleKey();

    final curam.pdc.intf.PDCAddress pdcAddressObj = PDCAddressFactory.newInstance();

    // check if the phone number ID input is zero
    if (dtls.mailingAddressID != 0) {

      // set the key to read the concern role address
      addressForConcernRoleKey.addressID = dtls.mailingAddressID;
      addressForConcernRoleKey.concernRoleID = dtls.concernRoleID;

      // perform a concern role address read
      final ConcernRoleAddressDtls concernRoleAddressDtls = concernRoleAddressObj.readAddressForConcernRole(
        addressForConcernRoleKey);

      final ReadConcernRoleAddressKey readConcernRoleAddressKey = new ReadConcernRoleAddressKey();

      readConcernRoleAddressKey.concernRoleAddressID = concernRoleAddressDtls.concernRoleAddressID;

      final AddressDetails addressDetailsRead = maintainConcernRoleAddressObj.readAddress(
        readConcernRoleAddressKey);

      final ParticipantAddressDetails participantAddressDetails = new ParticipantAddressDetails();

      participantAddressDetails.assign(addressDetailsRead);

      // set the endDate to today on the address record
      participantAddressDetails.endDate = curam.util.type.Date.getCurrentDate();

      pdcAddressObj.modify(participantAddressDetails);

    }
    // END, CR00360875

    // map the key to create the address
    maintainAddressKey.concernRoleID = dtls.concernRoleID;

    // map the details to create the address
    addressDetails.addressData = dtls.addressData;
    addressDetails.concernRoleID = dtls.concernRoleID;
    addressDetails.primaryAddressInd = false;
    addressDetails.startDate = curam.util.type.Date.getCurrentDate();
    addressDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    addressDetails.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.MAILING;

    // call create address
    maintainConcernRoleAddressObj.createAddress(maintainAddressKey,
      addressDetails);
  }

  // ___________________________________________________________________________
  /**
   * To insert a new residence address for a household member
   *
   * @param dtls InsertAddressDtls
   */
  @Override
  public void insertResidenceAddress(InsertAddressDtls dtls)
    throws AppException, InformationalException {

    // MaintainConcernRoleAddress manipulation variables
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();
    final AddressDetails addressDetails = new AddressDetails();

    // map the key to create the address
    maintainAddressKey.concernRoleID = dtls.concernRoleID;

    // map the details to create the address
    addressDetails.addressData = dtls.addressData;
    addressDetails.concernRoleID = dtls.concernRoleID;
    addressDetails.primaryAddressInd = true;
    addressDetails.startDate = curam.util.type.Date.getCurrentDate();
    addressDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    addressDetails.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.PRIVATE;

    // call create address
    maintainConcernRoleAddressObj.createAddress(maintainAddressKey,
      addressDetails);
  }

  // ___________________________________________________________________________
  /**
   * To insert a new work phone number on the system
   *
   * @param dtls InsertWorkPhoneDtls
   */
  @Override
  public void insertWorkPhoneNumber(final InsertWorkPhoneDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00360875, ELG
    // ConcernRolePhoneNumber manipulation variables
    final curam.core.intf.ConcernRolePhoneNumber concernRolePhoneNumberObj = curam.core.fact.ConcernRolePhoneNumberFactory.newInstance();
    final PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

    // MaintainConcernRolePhoneNumber manipulation variables
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    final ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();

    final PDCPhoneNumber pdcPhoneNumber = PDCPhoneNumberFactory.newInstance();
    final ParticipantPhoneDetails participantPhoneDetails = new ParticipantPhoneDetails();

    // check if the phone number ID input is zero
    if (dtls.phoneNumberID != 0) {

      // set the key to perform the concern role phone number read
      phoneForConcernRoleKey.concernRoleID = dtls.concernRoleID;
      phoneForConcernRoleKey.phoneNumberID = dtls.phoneNumberID;

      final ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);

      final ReadConcernRolePhoneKey readConcernRolePhoneKey = new ReadConcernRolePhoneKey();

      readConcernRolePhoneKey.concernRolePhoneNumberID = concernRolePhoneNumberDtls.concernRolePhoneNumberID;

      final ConcernRolePhoneDetails concernRolePhoneDetailsRead = maintainConcernRolePhoneObj.readPhoneNumber(
        readConcernRolePhoneKey);

      participantPhoneDetails.assign(concernRolePhoneDetailsRead);
      // set the end date to today
      participantPhoneDetails.endDate = curam.util.type.Date.getCurrentDate();

      // update the concern role phone number end date to today
      pdcPhoneNumber.modify(participantPhoneDetails);

    }
    // END, CR00360875

    // map the key to insert a phone number
    maintainPhoneNumberKey.concernRoleID = dtls.concernRoleID;

    // map the details to perform the phone number insert
    concernRolePhoneDetails.concernRoleID = dtls.concernRoleID;
    concernRolePhoneDetails.phoneAreaCode = dtls.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = dtls.phoneCountryCode;
    concernRolePhoneDetails.phoneExtension = dtls.phoneExtension;
    concernRolePhoneDetails.phoneNumber = dtls.phoneNumber;
    concernRolePhoneDetails.primaryPhoneInd = false;
    concernRolePhoneDetails.startDate = curam.util.type.Date.getCurrentDate();
    concernRolePhoneDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    concernRolePhoneDetails.typeCode = curam.codetable.PHONETYPE.BUSINESS;

    maintainConcernRolePhoneObj.createPhoneNumber(maintainPhoneNumberKey,
      concernRolePhoneDetails);

  }

  // ___________________________________________________________________________
  /**
   * To create an appointment for the household member with the caseworker.
   *
   * @param dtls create ticket details struct.
   *
   * @deprecated Since Curam 6.0, because all calls to {@link #curam.core.intf.MaintainConcernRoleComm} have been
   * replaced by {@link #curam.core.sl.impl.Communication}
   */
  @Override
  @Deprecated
  public void createAppointment(CreateAppointmentDetails dtls)
    throws AppException, InformationalException {

    // MaintainActivity manipulation variables
    final curam.core.intf.MaintainActivity maintainActivityObj = curam.core.fact.MaintainActivityFactory.newInstance();
    final MaintainActivityDetails maintainActivityDetails = new MaintainActivityDetails();

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();
    final CommunicationDetails communicationDetails = new CommunicationDetails();

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Users manipulation variables
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersDtls usersDtls;
    final UsersKey usersKey = new UsersKey();

    // Task manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();
    final CreateStandardManualTaskDetails createStandardManualTaskDetails = new CreateStandardManualTaskDetails();

    // perform a concern role read to determine the correspondent
    // concern role name
    concernRoleKey.concernRoleID = dtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Perform a users read to determine the users full name
    usersKey.userName = dtls.userName;
    usersDtls = usersObj.read(usersKey);

    final AppException subjectText = new AppException(
      curam.message.INCOMESCREENING.INF_GENERAL_APPOINTMENT_SCHEDULED);

    subjectText.arg(concernRoleDtls.concernRoleName);
    subjectText.arg(usersDtls.fullName);
    subjectText.arg(dtls.appointmentDateTime);

    dtls.subject = subjectText.toString();

    // set details to create a new activity
    maintainActivityDetails.caseID = dtls.caseID;
    maintainActivityDetails.concernRoleID = dtls.concernRoleID;
    maintainActivityDetails.subject = dtls.subject;
    maintainActivityDetails.activityTypeCode = dtls.activityTypeCode;
    maintainActivityDetails.startDateTime = dtls.appointmentDateTime;
    maintainActivityDetails.priorityCode = curam.codetable.ACTIVITYPRIORITY.MEDIUM;
    maintainActivityDetails.timeStatusCode = curam.codetable.ACTIVITYTIMESTATUS.BUSY;
    maintainActivityDetails.userName = dtls.userName;
    maintainActivityDetails.recordStatusCode = curam.codetable.RECORDSTATUS.NORMAL;
    maintainActivityDetails.allDayInd = false;
    maintainActivityDetails.locationID = 0;
    // BEGIN, CR00052924, GM
    maintainActivityDetails.locationName = CuramConst.gkEmpty;
    // END, CR00052924
    maintainActivityDetails.frequencyPattern = CuramConst.gkDefaultFrequencyPattern;
    maintainActivityDetails.recurrenceStartDate = curam.util.type.Date.kZeroDate;
    maintainActivityDetails.recurrenceEndDate = curam.util.type.Date.kZeroDate;

    // duration is 1 hour
    final java.util.Calendar endDateTimeCal = dtls.appointmentDateTime.getCalendar();

    endDateTimeCal.add(java.util.Calendar.HOUR_OF_DAY, 1);
    maintainActivityDetails.endDateTime = new DateTime(endDateTimeCal);

    // create a new activity
    maintainActivityObj.createActivity(maintainActivityDetails);

    // set key to perform the creation of a communication
    maintainCommunicationKey.caseID = dtls.caseID;
    maintainCommunicationKey.concernRoleID = dtls.concernRoleID;

    // set details to perform the creation of a communication
    communicationDetails.subjectText = dtls.subject;
    communicationDetails.concernRoleID = dtls.concernRoleID;
    communicationDetails.caseID = dtls.caseID;
    communicationDetails.correspondentConcernRoleID = dtls.concernRoleID;
    communicationDetails.correspondentTypeCode = curam.codetable.CORRESPONDENT.CLIENT;
    communicationDetails.typeCode = curam.codetable.COMMUNICATIONTYPE.APPOINTMENT;

    communicationDetails.correspondentName = concernRoleDtls.concernRoleName;
    // BEGIN, CR00052924, GM
    communicationDetails.communicationText = CuramConst.gkSpace;
    // END, CR00052924
    communicationDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // call the createCommunication method
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);

    // set case details, if applicable
    if (dtls.caseID != 0) {
      createStandardManualTaskDetails.concerningDtls.caseID = dtls.caseID;
    }

    // set concern role details, if applicable
    if (dtls.concernRoleID != 0) {
      createStandardManualTaskDetails.concerningDtls.participantRoleID = dtls.concernRoleID;
    }

    createStandardManualTaskDetails.taskDtls.deadlineTime = dtls.appointmentDateTime;

    createStandardManualTaskDetails.taskDtls.priority = curam.codetable.TASKPRIORITY.DEFAULTCODE;

    createStandardManualTaskDetails.taskDtls.subject = dtls.subject;

    // BEGIN, CR00053248, GM
    createStandardManualTaskDetails.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
    // END, CR00053248

    // create the task
    workAllocationTaskObj.createTask(createStandardManualTaskDetails);

  }

  // ___________________________________________________________________________
  /**
   * To view details of a screening case home page.
   *
   * @param key CaseHomeKey
   *
   * @return Screening Case Details
   */
  @Override
  @SuppressWarnings("deprecation")
  public ScreeningCaseHomeDetails viewScreeningCaseHome(CaseHomeKey key)
    throws AppException, InformationalException {

    // variable to store return values
    final ScreeningCaseHomeDetails screeningCaseHomeDetails = new ScreeningCaseHomeDetails();

    // need to access the items directly
    CaseMemberDetails caseMemberDetails;

    // ManipulateEvidenceTree manipulation variables
    final curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    final CaseEvidenceReadNearestEvidenceByTypeKey caseEvidenceReadNearestEvidenceByTypeKey = new CaseEvidenceReadNearestEvidenceByTypeKey();
    CaseEvidenceAndTypeDetails caseEvidenceAndTypeDetails;

    // case header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // case evidence link manipulation variables
    final curam.core.intf.CaseEvidenceLink caseEvidenceLinkObj = curam.core.fact.CaseEvidenceLinkFactory.newInstance();
    final EvidenceTypeAndCETypeIDKey evidenceTypeAndCETypeIDKey = new EvidenceTypeAndCETypeIDKey();
    CaseEvidenceLinkDtlsList caseEvidenceLinkDtlsList;

    // household evidence manipulation variables
    final curam.sample.sl.entity.intf.FSHouseholdEvidence fSHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    final FSHouseholdEvidenceKey fSHouseholdEvidenceKey = new FSHouseholdEvidenceKey();
    FSHouseholdEvidenceDtls fSHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // person manipulation variables
    final curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    final PersonKey personKey = new PersonKey();
    PersonDtls personDtls;

    // prospect person manipulation variables
    final curam.core.intf.ProspectPerson prospectPersonObj = curam.core.fact.ProspectPersonFactory.newInstance();
    final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();
    ProspectPersonDtls prospectPersonDtls;

    // assessment manipulation variables
    final curam.core.intf.Assessment assessmentObj = curam.core.fact.AssessmentFactory.newInstance();
    final AssessmentReadmultiKey assessmentReadmultiKey = new AssessmentReadmultiKey();
    AssessmentDtlsList assessmentDtlsList;

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00060051

    // set key to perform the assessment read
    assessmentReadmultiKey.caseID = key.caseKey.caseID;

    assessmentDtlsList = assessmentObj.searchByCaseID(assessmentReadmultiKey);

    // set the case ID in the return struct
    screeningCaseHomeDetails.assDtls.caseID = key.caseKey.caseID;

    if (assessmentDtlsList.dtls.size() >= 1) {

      // set the assessment details in the return struct
      screeningCaseHomeDetails.assDtls.assessmentID = assessmentDtlsList.dtls.item(0).assessmentID;

      if (assessmentDtlsList.dtls.item(0).assessmentResult.equals(
        curam.codetable.ASSESSMENTRESULT.SUCCESS)) {
        screeningCaseHomeDetails.assDtls.assessmentResult = // BEGIN,
          // CR00163471, JC
          curam.message.INCOMESCREENING.INF_GENERAL_HOUSEHOLD_ELIGIBLE.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC
      } else {
        screeningCaseHomeDetails.assDtls.assessmentResult = // BEGIN,
          // CR00163471, JC
          curam.message.INCOMESCREENING.INF_GENERAL_HOUSEHOLD_INELIGIBLE.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC
      }

      screeningCaseHomeDetails.assDtls.lastRunDate = assessmentDtlsList.dtls.item(0).assessmentLastRunDate;
      // set key for the read nearest evidence by type
      caseEvidenceReadNearestEvidenceByTypeKey.assessmentID = assessmentDtlsList.dtls.item(0).assessmentID;
    }

    // set key to perform a case header read
    caseHeaderKey.caseID = key.caseKey.caseID;

    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // set details in the return struct
    screeningCaseHomeDetails.caseHomeDtls.caseCreationDate = caseHeaderDtls.registrationDate;
    screeningCaseHomeDetails.caseHomeDtls.caseStatus = caseHeaderDtls.statusCode;
    screeningCaseHomeDetails.caseHomeDtls.concernRoleID = caseHeaderDtls.concernRoleID;

    // BEGIN, CR00060051, PMD
    // Read the case owner
    final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
      caseHeaderKey);

    // Set the owner details
    screeningCaseHomeDetails.caseHomeDtls.ownerDetails.assign(caseOwnerDetails);
    // END, CR00060051

    // set key to read the concern role record for the head of household
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // set head of household details in the return struct
    screeningCaseHomeDetails.caseHomeDtls.concernRoleType = concernRoleDtls.concernRoleType;
    screeningCaseHomeDetails.caseHomeDtls.headOfHouseholdName = concernRoleDtls.concernRoleName;

    // set key to read the nearest evidence by type
    caseEvidenceReadNearestEvidenceByTypeKey.caseID = key.caseKey.caseID;
    caseEvidenceReadNearestEvidenceByTypeKey.effectiveFrom = caseHeaderDtls.effectiveDate.addDays(
      1);
    caseEvidenceReadNearestEvidenceByTypeKey.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;
    caseEvidenceReadNearestEvidenceByTypeKey.statusCode = curam.codetable.EVIDENCESTATUS.CURRENT;

    try {
      caseEvidenceAndTypeDetails = manipulateEvidenceTreeObj.readNearestEvidenceByType(
        caseEvidenceReadNearestEvidenceByTypeKey);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      // if no evidence is recorded, exit here
      return screeningCaseHomeDetails;
    }

    // set key to read the caseEvidenceLink records for household evidence
    evidenceTypeAndCETypeIDKey.caseEvidenceTypeID = caseEvidenceAndTypeDetails.caseEvidenceTypeID;
    evidenceTypeAndCETypeIDKey.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;

    caseEvidenceLinkDtlsList = caseEvidenceLinkObj.searchByEvidenceTypeIDAndType(
      evidenceTypeAndCETypeIDKey);

    if (!caseEvidenceLinkDtlsList.dtls.isEmpty()) {

      // iterate through the list of records returned
      for (int j = 0; j < caseEvidenceLinkDtlsList.dtls.size(); j++) {

        caseMemberDetails = new CaseMemberDetails();
        // set boolean variable to flag if a record is found
        boolean recordFound = true;

        // set the fsHouseholdEvidenceID for the FHouseholdEvidence entity read
        fSHouseholdEvidenceKey.fsHouseholdEvidenceID = caseEvidenceLinkDtlsList.dtls.item(j).relatedID;

        try {
          // read the FSHouseholdEvidence details
          fSHouseholdEvidenceDtls = fSHouseholdEvidenceObj.read(
            fSHouseholdEvidenceKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          recordFound = false;
        }

        // if a record is found, map the details to return struct
        if (recordFound) {

          caseMemberDetails.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;
          caseMemberDetails.rshipToHOH = fSHouseholdEvidenceDtls.rshipToHOH;

          // set key to perform a concern role read to retrieve member details
          concernRoleKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

          concernRoleDtls = concernRoleObj.read(concernRoleKey);

          // map details to return struct
          caseMemberDetails.concernRoleType = concernRoleDtls.concernRoleType;
          caseMemberDetails.memberName = concernRoleDtls.concernRoleName;

          if (concernRoleDtls.concernRoleType.equals(
            curam.codetable.CONCERNROLETYPE.PERSON)) {
            // set key to perform a person read to retrieve member details
            personKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

            personDtls = personObj.read(personKey);

            // map details to return struct
            caseMemberDetails.memberDateOfBirth = personDtls.dateOfBirth;
          } else {
            if (concernRoleDtls.concernRoleType.equals(
              curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {
              // set key to perform a person read to retrieve member details
              prospectPersonKey.concernRoleID = fSHouseholdEvidenceDtls.concernRoleID;

              prospectPersonDtls = prospectPersonObj.read(prospectPersonKey);

              // map details to return struct
              caseMemberDetails.memberDateOfBirth = prospectPersonDtls.dateOfBirth;
            }
          }

        }

        // map the details to the output struct
        screeningCaseHomeDetails.caseMbrDtls.memberListDtls.addRef(
          caseMemberDetails);

      }

    }

    // BEGIN, CR00129996, ZV
    final SpecialCaution specialCautionObj = SpecialCautionFactory.newInstance();
    final SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();

    // assigning concern role id to SpecialCautionConcernKey struct
    specialCautionConcernKey.concernRoleID = caseHeaderDtls.concernRoleID;
    // invoking displayActiveSpecialCautionIndicator() method on special caution
    // object
    screeningCaseHomeDetails.caseHomeDtls.specialCautionInd = specialCautionObj.displayActiveSpecialCautionIndicator(specialCautionConcernKey).displayIndicator;
    // END, CR00129996

    return screeningCaseHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * To get the name of a household member
   *
   * @param key Containing the ConcernRoleID
   *
   * @return Member Name Details
   */
  @Override
  public GetMemberNameDtls getMemberName(GetMemberNameKey key)
    throws AppException, InformationalException {

    final GetMemberNameDtls getMemberNameDtls = new GetMemberNameDtls();

    // concern role manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    concernRoleKey.concernRoleID = key.memberKey.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    getMemberNameDtls.concernRoleName = concernRoleDtls.concernRoleName;
    getMemberNameDtls.concernRoleType = concernRoleDtls.concernRoleType;

    return getMemberNameDtls;
  }

  // ___________________________________________________________________________
  /**
   * To get the availability of all users in a specified workgroup for a
   * specified date.
   *
   * @param key GetUserAvailailityKey
   *
   * @return User Availability Details
   */
  @Override
  public UserAvailabilityDetails getUserAvailability(
    GetUserAvailabilityKey key) throws AppException, InformationalException {

    // Set up the time intervals. Using 30-minute intervals from 8am to
    // 8pm there are 25 times bounding the 24 intervals.

    final long startHour = 8; // 8am
    final long millis = 1800000; // milliseconds in a 30 minute interval.
    final long times[] = new long[25];

    for (int t = 0; t < 25; t++) {
      times[t] = key.userAvailKey.appointmentDate.asLong()
        + startHour * 2 * millis + t * millis;
    }

    // variable to store return values
    final UserAvailabilityDetails userAvailabilityDetails = new UserAvailabilityDetails();
    // AdminUser manipulation variables
    final curam.core.intf.AdminUser adminUserObj = curam.core.fact.AdminUserFactory.newInstance();
    final ListUsersKey_bo listUsersKey = new ListUsersKey_bo();
    curam.core.sl.struct.UserForPositionDetailsList userForPositionDetailsList = new curam.core.sl.struct.UserForPositionDetailsList();

    // MaintainUserActivity manipulation variables
    final curam.core.intf.MaintainUserActivity maintainUserActivityObj = curam.core.fact.MaintainUserActivityFactory.newInstance();
    final UserActivitySearchKey userActivitySearchKey = new UserActivitySearchKey();
    SearchUserByDateRangeResult searchUserByDateRangeResult;

    // output struct
    GetUserAvailabilityDtls getUserAvailabilityDtls;

    // Set key to perform the workgroup read
    listUsersKey.orgUnitID = key.userAvailKey.organisationUnitID;

    userForPositionDetailsList = adminUserObj.listUsers(listUsersKey);

    // for each user in the list returned want to determine the activities for
    // the date range
    for (int i = 0; i
      < userForPositionDetailsList.userForOrgUnitDetailsList.dtls.size(); i++) {

      getUserAvailabilityDtls = new GetUserAvailabilityDtls();
      searchUserByDateRangeResult = new SearchUserByDateRangeResult();

      // read all user activities for the schedule date
      userActivitySearchKey.selectedDate = key.userAvailKey.appointmentDate;
      userActivitySearchKey.userName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userName;

      // need to convert the appointment date to a dateTime
      java.util.Calendar endDateCal;

      endDateCal = key.userAvailKey.appointmentDate.getCalendar();
      endDateCal.add(java.util.Calendar.HOUR_OF_DAY, 20);
      userActivitySearchKey.endDateTime = new DateTime(endDateCal);

      java.util.Calendar startDateCal;

      startDateCal = key.userAvailKey.appointmentDate.getCalendar();
      startDateCal.add(java.util.Calendar.HOUR_OF_DAY, 8);
      userActivitySearchKey.startDateTime = new DateTime(startDateCal);

      // set boolean variable to flag if a record is found
      boolean recordFound = true;

      // Retrieves the details of all activities for the specified
      // user within the specified date range.
      try {
        searchUserByDateRangeResult = maintainUserActivityObj.searchUserByDateRange(
          userActivitySearchKey);
      } catch (final curam.util.exception.RecordNotFoundException e) {
        recordFound = false;
      }

      // if a record is found then activities exist for the specified user

      if (recordFound) {

        // populate the output struct with the user name
        // only want to get the user name if you have activities
        getUserAvailabilityDtls.userName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userName;
        getUserAvailabilityDtls.userFullName = userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userFullName;

        int bitField = 0;

        // determine from the start and end date times, what half hour slot in
        // the day is busy
        for (int j = 0; j < searchUserByDateRangeResult.detailsList.dtls.size(); j++) {
          // get the start time and the end time....
          final long apst = searchUserByDateRangeResult.detailsList.dtls.item(j).startDateTime.asLong();
          final long apet = searchUserByDateRangeResult.detailsList.dtls.item(j).endDateTime.asLong();

          bitField = 0;
          for (int t = 0; t < 24; t++) {
            if (times[t + 1] < apst || times[t] >= apet) {
              continue;
            } else {
              // intersection
              bitField = 1 << t | bitField;
            }
          }
        }
        // returns the userFullName and ScheduleBit in a tabbed delimited string
        // The format of the tab string is: UserFullName, tab, Schedule bit

        getUserAvailabilityDtls.schedule += String.valueOf(
          userForPositionDetailsList.userForOrgUnitDetailsList.dtls.item(i).userFullName);
        getUserAvailabilityDtls.schedule += CuramConst.gkTabDelimiter;
        getUserAvailabilityDtls.schedule += String.valueOf(bitField);

        userAvailabilityDetails.availabilityList.userAvailDtls.addRef(
          getUserAvailabilityDtls);

      } // end of if

    } // end of for

    userAvailabilityDetails.availDate.appointmentDate = key.userAvailKey.appointmentDate;

    return userAvailabilityDetails;

  }

}
