/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.sl.impl;


import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.ClientInteractionKey;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.struct.ListInteractionDetails;
import curam.core.struct.ConcernRoleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Participant
 * service layer for interactions.
 */
public abstract class ParticipantInteractions extends curam.sample.sl.base.ParticipantInteractions {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of clients interaction detail records.
   *
   * @param key Contains the concern role identifier.
   *
   * @return The list of client interaction records.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#listForParticipant(ConcernRoleKey)}
   */
  @Deprecated
  @Override
  public curam.sample.sl.struct.ListInteractionDetails list(
    curam.sample.sl.entity.struct.ListInteractionKey key)
    throws AppException, InformationalException {

    // Return object
    final curam.sample.sl.struct.ListInteractionDetails list = new curam.sample.sl.struct.ListInteractionDetails();

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    final ListInteractionDetails details = clientInteractionObj.listForParticipant(
      concernRoleKey);

    // Map details to output struct
    for (int i = 0; i < details.detailsList.dtls.size(); i++) {

      final curam.sample.sl.entity.struct.InteractionDetails interactionDetails = new curam.sample.sl.entity.struct.InteractionDetails();

      interactionDetails.clientInteractionID = details.detailsList.dtls.item(i).clientInteractionID;
      interactionDetails.interactionDateTime = details.detailsList.dtls.item(i).interactionDateTime;
      interactionDetails.interactionTypeCode = details.detailsList.dtls.item(i).interactionTypeCode;
      interactionDetails.relatedID = details.detailsList.dtls.item(i).relatedID;
      interactionDetails.relatedType = details.detailsList.dtls.item(i).relatedType;

      list.detailsList.dtls.addRef(interactionDetails);
    }
    // END, CR00192165

    return list;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves a person's interaction details
   *
   * @param key identifies interaction to be found
   *
   * @return person's interaction details found
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#view(ClientInteractionKey)}
   */
  @Deprecated
  @Override
  public curam.sample.sl.struct.ReadInteractionDetails read(
    curam.sample.sl.struct.ReadInteractionKey key) throws AppException,
      InformationalException {

    final curam.sample.sl.struct.ReadInteractionDetails readInteractionDetails = new curam.sample.sl.struct.ReadInteractionDetails();

    // BEGIN, CR00192165, VM
    final curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();

    final ClientInteractionKey clientInteractionKey = new ClientInteractionKey();
    ClientInteractionDtls clientInteractionDtls;

    clientInteractionKey.clientInteractionID = key.clientInteractionID;

    // read the interaction details
    clientInteractionDtls = clientInteractionObj.read(clientInteractionKey);

    // assign interaction details to return struct
    readInteractionDetails.comments = clientInteractionDtls.comments;
    readInteractionDetails.concernRoleID = clientInteractionDtls.concernRoleID;
    readInteractionDetails.description = clientInteractionDtls.description;
    readInteractionDetails.interactionDateTime = clientInteractionDtls.interactionDateTime;
    readInteractionDetails.interactionTypeCode = clientInteractionDtls.interactionTypeCode;
    readInteractionDetails.relatedID = clientInteractionDtls.relatedID;
    readInteractionDetails.relatedType = clientInteractionDtls.relatedType;
    // END, CR00192165

    // return the details
    return readInteractionDetails;
  }

}
