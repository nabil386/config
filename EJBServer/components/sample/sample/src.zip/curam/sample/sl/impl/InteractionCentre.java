/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2020. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;

import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.InteractionDetails;
import curam.core.sl.entity.struct.InteractionDetailsList;
import curam.core.sl.entity.struct.ListInteractionKey;
import curam.core.sl.entity.struct.ReadInteractionHomePageKey;
import curam.core.sl.entity.struct.ReadPersonInteractionHomePageDtls;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.struct.ClientInteractionDetails;
import curam.core.sl.struct.ClientInteractionSupplementaryDetails;
import curam.core.sl.struct.ListInteractionDetails;
import curam.core.struct.PersonAltSearchKey;
import curam.core.struct.PersonParticipantID;
import curam.core.struct.PersonSearchKey;
import curam.core.struct.ReadBasicContactDetailsKey;
import curam.core.struct.ReadBasicContactDetailsResult;
import curam.message.BPOINTERACTIONCENTRE;
import curam.sample.sl.struct.ClientInteractionPersonSearchDetails;
import curam.sample.sl.struct.ClientInteractionPersonSearchKey;
import curam.sample.sl.struct.ListHomePageInteractionKey;
import curam.sample.sl.struct.ReadPersonInteractionHomePageDetails;
import curam.sample.sl.struct.ReadPersonInteractionHomePageDetails_bo;
import curam.sample.sl.struct.ReadPersonInteractionHomePageKey_bo;
import curam.sample.sl.struct.RecordInteractionComments;
import curam.sample.sl.struct.RecordInteractionKey;
import curam.sample.sl.struct.RecordedInteractionDetails;
import curam.sample.sl.struct.VerifyInteractionCentreParametersDetails;
import curam.sample.sl.struct.VerifyInteractionCentreParametersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.net.URLCodec;

/**
 * This process class provides the functionality for the Interaction Center
 * service layer.
 */
public abstract class InteractionCentre
  extends curam.sample.sl.base.InteractionCentre {

  // BEGIN, CR00069996, SK
  protected static final String kInteractionID = GeneralConst.gkInteractionID;

  protected static final String kInteractionDescription =
    GeneralConst.gkInteractionDescription;

  // END, CR00069996
  // ___________________________________________________________________________
  /**
   * Searches for a person by concern identifier.
   *
   * @param key Identifies the person concerned
   *
   * @return The details of the person read from the database.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #curam.core.impl.PersonSearchRouter.search1(PersonSearchKey1)}
   */
  @Override
  @Deprecated
  public ClientInteractionPersonSearchDetails
    personSearch(final ClientInteractionPersonSearchKey key)
      throws AppException, InformationalException {

    // details to be returned
    final ClientInteractionPersonSearchDetails clientInteractionPersonSearchDetails =
      new ClientInteractionPersonSearchDetails();

    // person search object and key.
    final curam.core.intf.PersonSearchRouter personSearchRouterObj =
      curam.core.fact.PersonSearchRouterFactory.newInstance();
    PersonSearchKey personSearchKey = new PersonSearchKey();

    // get the details for the search from the search key.
    personSearchKey = key.personSearchKey;

    // search for person
    clientInteractionPersonSearchDetails.personSearchResult =
      personSearchRouterObj.search(personSearchKey);

    for (int i =
      0; i < clientInteractionPersonSearchDetails.personSearchResult.details.dtls
        .size(); i++) {

      clientInteractionPersonSearchDetails.personSearchResult.details.dtls
        .item(i).personFullName =
          clientInteractionPersonSearchDetails.personSearchResult.details.dtls
            .item(i).forename

            + CuramConst.gkSpace

            + clientInteractionPersonSearchDetails.personSearchResult.details.dtls
              .item(i).surname;
    }
    // return the details
    return clientInteractionPersonSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads a person's interaction home page details and interaction records
   *
   * @param key Identifies the person concerned
   *
   * @return The home page details of the person.
   */
  @Override
  public ReadPersonInteractionHomePageDetails_bo
    readPersonInteractionHomePage(
      final ReadPersonInteractionHomePageKey_bo key)
      throws AppException, InformationalException {

    // details to be returned
    final ReadPersonInteractionHomePageDetails_bo readPersonInteractionHomePageDetailsRet =
      new ReadPersonInteractionHomePageDetails_bo();

    ListInteractionDetails listInteractionDetails =
      new ListInteractionDetails();

    final curam.core.sl.entity.intf.ClientInteraction clientInteractionObj =
      curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();
    final ListHomePageInteractionKey listHomePageInteractionKey =
      new ListHomePageInteractionKey();

    final ReadPersonInteractionHomePageDetails readPersonInteractionHomePageDetails =
      new ReadPersonInteractionHomePageDetails();
    ReadPersonInteractionHomePageDtls readPersonInteractionHomePageDtls;
    final ReadInteractionHomePageKey readInteractionHomePageKey =
      new ReadInteractionHomePageKey();

    readInteractionHomePageKey.participantID =
      key.readPersonInteractionHomePageKey.participantID;

    readPersonInteractionHomePageDtls = clientInteractionObj
      .readPersonInteractionHomePage(readInteractionHomePageKey);

    readPersonInteractionHomePageDetails.concernRoleName =
      readPersonInteractionHomePageDtls.concernRoleName;
    readPersonInteractionHomePageDetails.dateOfBirth =
      readPersonInteractionHomePageDtls.dateOfBirth;
    readPersonInteractionHomePageDetails.gender =
      readPersonInteractionHomePageDtls.gender;
    readPersonInteractionHomePageDetails.primaryAddressID =
      readPersonInteractionHomePageDtls.primaryAddressID;
    readPersonInteractionHomePageDetails.primaryAlternateID =
      readPersonInteractionHomePageDtls.primaryAlternateID;
    readPersonInteractionHomePageDetails.primaryPhoneNumberID =
      readPersonInteractionHomePageDtls.primaryPhoneNumberID;

    // assign interaction home page details to return struct
    readPersonInteractionHomePageDetailsRet
      .assign(readPersonInteractionHomePageDetails);

    listHomePageInteractionKey.concernRoleID =
      key.readPersonInteractionHomePageKey.participantID;

    // read the number of interactions to be included when viewing the
    // client interaction home page from the application.properties file
    final String interactions =
      curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_CLIENT_INTERACTIONS_DISPLAYED_ON_CLIENTINTERACTION_HOMEPAGE);
    int interactionsNumber = 0;

    if (interactions == null) {
      interactionsNumber =
        curam.core.impl.EnvVars.ENV_CLIENT_INTERACTIONS_DISPLAYED_ON_CLIENTINTERACTION_HOMEPAGE_DEFAULT;
    } else {
      interactionsNumber = Integer.parseInt(interactions);
    }

    listHomePageInteractionKey.interactions = (short) interactionsNumber;

    // read person interaction details records
    listInteractionDetails =
      listHomePageInteractions(listHomePageInteractionKey);

    // assign interaction details records to return struct
    readPersonInteractionHomePageDetailsRet.listInteractionDetails
      .assign(listInteractionDetails);

    final ReadBasicContactDetailsKey readBasicContactDetailsKey =
      new ReadBasicContactDetailsKey();
    ReadBasicContactDetailsResult readBasicContactDetailsResult;

    // variable to read basic contract details
    final curam.core.intf.MaintainContractAssistant maintainContractAssistantObj =
      curam.core.fact.MaintainContractAssistantFactory.newInstance();

    readBasicContactDetailsKey.concernRoleID =
      key.readPersonInteractionHomePageKey.participantID;
    readBasicContactDetailsKey.primaryAddressID =
      readPersonInteractionHomePageDetails.primaryAddressID;
    readBasicContactDetailsKey.primaryPhoneNumberID =
      readPersonInteractionHomePageDetails.primaryPhoneNumberID;

    // read client contact details
    readBasicContactDetailsResult = maintainContractAssistantObj
      .readBasicContactDetails(readBasicContactDetailsKey);

    readPersonInteractionHomePageDetailsRet.address =
      readBasicContactDetailsResult.basicContactDetails.formattedAddressData;
    readPersonInteractionHomePageDetailsRet.phoneAreaCode =
      readBasicContactDetailsResult.basicContactDetails.phoneAreaCode;
    readPersonInteractionHomePageDetailsRet.phoneCountryCode =
      readBasicContactDetailsResult.basicContactDetails.phoneCountryCode;
    readPersonInteractionHomePageDetailsRet.phoneExtension =
      readBasicContactDetailsResult.basicContactDetails.phoneExtension;
    readPersonInteractionHomePageDetailsRet.phoneExtension =
      readBasicContactDetailsResult.basicContactDetails.phoneExtension;
    readPersonInteractionHomePageDetailsRet.phoneNumber =
      readBasicContactDetailsResult.basicContactDetails.phoneNumber;

    // return the details
    return readPersonInteractionHomePageDetailsRet;
  }

  // ___________________________________________________________________________
  /**
   * Verifies interaction center parameters social security number
   * and interaction id
   *
   * @param key Interaction center parameter string with set of name=value
   * pairs that were attached as user data to the incoming call
   *
   * @return participant ID and verification code
   */
  @Override
  public VerifyInteractionCentreParametersDetails
    verifyInteractionCentreParameters(
      final VerifyInteractionCentreParametersKey key)
      throws AppException, InformationalException {

    // details to be returned
    final VerifyInteractionCentreParametersDetails verifyInteractionCentreParametersDetails =
      new VerifyInteractionCentreParametersDetails();

    // person object
    final curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();
    PersonParticipantID personParticipantID = new PersonParticipantID();
    final PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();

    final Map<String, String> map =
      parseParameters(key.interactionCentreParamters);

    if (map.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
        .throwWithLookup(
          new AppException(
            BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_PARAMETERS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    String interactionId = kInteractionID;
    String ssn = GeneralConst.gkSSN;

    if (map.get(ssn) == null) { // parameter coming from applet may not have an
      // "=" at the start of the string
      // BEGIN, CR00053248, GM
      ssn = GeneralConstants.kEquals + ssn; // when we enter this code by just
      // adding data to URL already have
      // this present
      // END, CR00053248
    }
    personAltSearchKey.primaryAlternateID = map.get(ssn);
    if (map.get(kInteractionID) == null) { // same reason as check above
      // BEGIN, CR00053248, GM
      interactionId = GeneralConstants.kEquals + kInteractionID;
      // END, CR00053248
    }

    verifyInteractionCentreParametersDetails.interactionID =
      map.get(interactionId);
    if (personAltSearchKey.primaryAlternateID == null) {
      verifyInteractionCentreParametersDetails.verificationCode =
        curam.codetable.INTCENTREVERIY.SSNNOTPROVIDED;

    } else {

      try {
        // read the participant by alternate ID
        personParticipantID =
          personObj.readParticipantIDbyAlternateID(personAltSearchKey);
        final RecordInteractionKey recordInteractionKey =
          new RecordInteractionKey();

        recordInteractionKey.concernRoleID =
          personParticipantID.concernRoleID;
        recordInteractionKey.interactionID =
          verifyInteractionCentreParametersDetails.interactionID;

        verifyInteractionCentreParametersDetails.recordedInteractionDetails =
          recordInteraction(recordInteractionKey);

        verifyInteractionCentreParametersDetails.verificationCode =
          curam.codetable.INTCENTREVERIY.SSNFOUND;

        verifyInteractionCentreParametersDetails.participantID =
          personParticipantID.concernRoleID;

      } catch (final curam.util.exception.RecordNotFoundException e) {

        verifyInteractionCentreParametersDetails.verificationCode =
          curam.codetable.INTCENTREVERIY.SSNNOTFOUND;
        verifyInteractionCentreParametersDetails.ctiDataReferenceNumber =
          personAltSearchKey.primaryAlternateID;
      }
    }

    // details to be returned
    return verifyInteractionCentreParametersDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists client interactions
   *
   * @param key identifies the client and the number of interactions to be
   * displayed on the client interaction home page.
   *
   * @return list of client interaction records
   */
  @Override
  public ListInteractionDetails
    listHomePageInteractions(final ListHomePageInteractionKey key)
      throws AppException, InformationalException {

    // details to be returned
    final ListInteractionDetails listInteractionDetails =
      new ListInteractionDetails();

    final curam.core.sl.entity.intf.ClientInteraction clientInteractionObj =
      curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();
    InteractionDetailsList interactionDetailsList;
    InteractionDetails interactionDetails;

    final ListInteractionKey listInteractionKey = new ListInteractionKey();

    listInteractionKey.concernRoleID = key.concernRoleID;

    // read the list of interaction detail records.
    interactionDetailsList = clientInteractionObj.list(listInteractionKey);

    listInteractionDetails.detailsList.dtls
      .ensureCapacity(interactionDetailsList.dtls.size());

    // list client interactions on the client interaction home page based
    // on the the interactions set in the environment variable
    for (int i = 0; i < interactionDetailsList.dtls.size(); i++) {

      if (i <= key.interactions) {
        interactionDetails = new InteractionDetails();
        interactionDetails.assign(interactionDetailsList.dtls.item(i));
        listInteractionDetails.detailsList.dtls.addRef(interactionDetails);
      }
    }
    // details to be returned
    return listInteractionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Inserts a client interaction record
   *
   * @param key identifies the client and interaction id
   */
  @Override
  public RecordedInteractionDetails
    recordInteraction(final RecordInteractionKey key)
      throws AppException, InformationalException {

    final curam.core.sl.entity.intf.ClientInteraction clientInteractionObj =
      curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();

    // client interaction details
    final ClientInteractionDtls clientInteractionDtls =
      new ClientInteractionDtls();

    // return details
    final RecordedInteractionDetails recordedInteractionDetails =
      new RecordedInteractionDetails();

    // check if interaction id exists
    if (key.interactionID.length() > 0) {
      clientInteractionDtls.relatedID = Integer.parseInt(key.interactionID);
    }

    clientInteractionDtls.concernRoleID = key.concernRoleID;
    clientInteractionDtls.description = kInteractionDescription;
    clientInteractionDtls.comments = key.comments;
    clientInteractionDtls.interactionTypeCode =
      curam.codetable.INTERACTIONTYPE.PHONERECEIVED;
    clientInteractionDtls.interactionDateTime =
      curam.util.type.DateTime.getCurrentDateTime();

    // insert client interaction record
    clientInteractionObj.insert(clientInteractionDtls);
    recordedInteractionDetails.clientInteractionID =
      clientInteractionDtls.clientInteractionID;
    recordedInteractionDetails.versionNo = clientInteractionDtls.versionNo;
    return recordedInteractionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Inserts a comment for an interaction.
   *
   * @param details contains the key and the comments entered
   */
  @Override
  public void recordComments(final RecordInteractionComments details)
    throws AppException, InformationalException {

    final curam.core.sl.entity.intf.ClientInteraction clientInteractionObj =
      curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();

    clientInteractionObj.insertComments(details.interactionCommentsKey,
      details.interactionCommentsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client payment interaction. Sets
   * InteractionType to 'Payment'
   *
   * @param clientInteractionDtls Contains details of payment generated
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteractionPayment(ClientInteractionDetails)}
   */
  @Deprecated
  @Override
  public void recordClientInteractionPayment(
    final curam.sample.sl.struct.ClientInteractionDetails clientInteractionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj =
      ClientInteractionFactory.newInstance();
    final ClientInteractionDetails details = new ClientInteractionDetails();

    details.dtls.comments = clientInteractionDtls.dtls.comments;
    details.dtls.concernRoleID = clientInteractionDtls.dtls.concernRoleID;
    details.dtls.description = clientInteractionDtls.dtls.description;
    details.dtls.relatedID = clientInteractionDtls.dtls.relatedID;
    details.dtls.relatedType = clientInteractionDtls.dtls.relatedType;
    details.dtls.interactionDateTime =
      clientInteractionDtls.dtls.interactionDateTime;
    details.dtls.interactionTypeCode =
      clientInteractionDtls.dtls.interactionTypeCode;

    clientInteractionObj.recordClientInteractionPayment(details);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a ClientInteraction.
   *
   * @param clientInteractionDtls contains details of interaction
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteraction(ClientInteractionDtls)}
   */
  @Deprecated
  @Override
  public void recordClientInteraction(
    final curam.sample.sl.entity.struct.ClientInteractionDtls clientInteractionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj =
      ClientInteractionFactory.newInstance();
    final ClientInteractionDtls entityDtls = new ClientInteractionDtls();

    entityDtls.comments = clientInteractionDtls.comments;
    entityDtls.concernRoleID = clientInteractionDtls.relatedID;
    entityDtls.description = clientInteractionDtls.description;
    entityDtls.interactionDateTime =
      clientInteractionDtls.interactionDateTime;
    entityDtls.interactionTypeCode =
      clientInteractionDtls.interactionTypeCode;
    entityDtls.relatedType = clientInteractionDtls.relatedType;
    entityDtls.relatedID = clientInteractionDtls.relatedID;

    clientInteractionObj.recordClientInteraction(entityDtls);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client communication interaction. Sets
   * InteractionType according to the Communication Method + Communication
   * Direction.
   *
   * @param interactionDtls Contains details of communication including whether
   * it's an incoming or outgoing communication.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteractionAndCommunicationDirection(ClientInteractionSupplementaryDetails)}
   */
  @Deprecated
  @Override
  public void recordClientInteractionAndCommunicationDirection(
    final curam.sample.sl.struct.ClientInteractionSupplementaryDetails interactionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj =
      ClientInteractionFactory.newInstance();
    final ClientInteractionSupplementaryDetails supplementaryDetails =
      new ClientInteractionSupplementaryDetails();

    supplementaryDetails.clientDtls.dtls.concernRoleID =
      interactionDtls.clientDtls.dtls.concernRoleID;
    supplementaryDetails.clientDtls.dtls.comments =
      interactionDtls.clientDtls.dtls.comments;
    supplementaryDetails.clientDtls.dtls.description =
      interactionDtls.clientDtls.dtls.description;
    supplementaryDetails.clientDtls.dtls.interactionTypeCode =
      interactionDtls.clientDtls.dtls.interactionTypeCode;
    supplementaryDetails.clientDtls.dtls.interactionDateTime =
      interactionDtls.clientDtls.dtls.interactionDateTime;
    supplementaryDetails.clientDtls.dtls.relatedID =
      interactionDtls.clientDtls.dtls.relatedID;
    supplementaryDetails.clientDtls.dtls.relatedType =
      interactionDtls.clientDtls.dtls.relatedType;

    supplementaryDetails.incomingInd = interactionDtls.incomingInd;
    supplementaryDetails.communicationDirectionInd =
      interactionDtls.communicationDirectionInd;
    supplementaryDetails.correspondentConcernRoleID =
      interactionDtls.correspondentConcernRoleID;
    supplementaryDetails.methodTypeCode = interactionDtls.methodTypeCode;

    clientInteractionObj
      .recordClientInteractionAndCommunicationDirection(supplementaryDetails);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client communication interaction.
   * If the communication was to a case participant other than the primary
   * client, a ClientInteraction is recorded for both the correspondent and the
   * primary client.
   *
   * @param interactionDtls Contains details of communication including
   * correspondent id
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientAndCorrespondentInteraction(ClientInteractionSupplementaryDetails)}
   */
  @Deprecated
  @Override
  public void recordClientAndCorrespondentInteraction(
    final curam.sample.sl.struct.ClientInteractionSupplementaryDetails interactionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj =
      ClientInteractionFactory.newInstance();
    final ClientInteractionSupplementaryDetails supplementaryDetails =
      new ClientInteractionSupplementaryDetails();

    supplementaryDetails.clientDtls.dtls.concernRoleID =
      interactionDtls.clientDtls.dtls.concernRoleID;
    supplementaryDetails.clientDtls.dtls.comments =
      interactionDtls.clientDtls.dtls.comments;
    supplementaryDetails.clientDtls.dtls.description =
      interactionDtls.clientDtls.dtls.description;
    supplementaryDetails.clientDtls.dtls.interactionTypeCode =
      interactionDtls.clientDtls.dtls.interactionTypeCode;
    supplementaryDetails.clientDtls.dtls.interactionDateTime =
      interactionDtls.clientDtls.dtls.interactionDateTime;
    supplementaryDetails.clientDtls.dtls.relatedID =
      interactionDtls.clientDtls.dtls.relatedID;
    supplementaryDetails.clientDtls.dtls.relatedType =
      interactionDtls.clientDtls.dtls.relatedType;

    supplementaryDetails.incomingInd = interactionDtls.incomingInd;
    supplementaryDetails.communicationDirectionInd =
      interactionDtls.communicationDirectionInd;
    supplementaryDetails.correspondentConcernRoleID =
      interactionDtls.correspondentConcernRoleID;
    supplementaryDetails.methodTypeCode = interactionDtls.methodTypeCode;

    clientInteractionObj
      .recordClientAndCorrespondentInteraction(supplementaryDetails);
    // END, CR00192165
  }

  /**
   * Decode the Interaction Centre Data and return a map of name and
   * value pairs.
   *
   * @param ctiData The encode list of parameters.
   * @return A map of name and value pairs.
   */
  public static Map<String, String> parseParameters(final String data)
    throws AppException {

    final Map<String, String> map = new HashMap<String, String>();

    // URL is encoded using the URLCodec encode method and the UTF-8
    // character set.
    String unescapedParameterList = GeneralConstants.kEmpty;

    try {
      unescapedParameterList =
        new URLCodec().decode(data, GeneralConstants.kUTF8);
    } catch (final DecoderException e) {
      final AppException exception = new AppException(
        BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_INVALID_DATA, e);
      exception.arg(data);
      throw exception;
    } catch (final UnsupportedEncodingException e) {
      final AppException exception = new AppException(
        BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_INVALID_DATA, e);
      exception.arg(data);
      throw exception;
    }

    // The parameters are separated by &.
    final StringTokenizer tokenizer = new StringTokenizer(
      unescapedParameterList, GeneralConstants.kAmpersand);

    while (tokenizer.hasMoreTokens()) {
      final String token = tokenizer.nextToken();
      final int indexOfEquals = token.indexOf(GeneralConstants.kEquals);

      if (indexOfEquals == -1) {
        final AppException exception = new AppException(
          BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_INVALID_DATA);
        exception.arg(data);
        throw exception;
      }
      final String name = token.substring(0, indexOfEquals);
      final String value = token.substring(indexOfEquals + 1);
      map.put(name, value);
    }

    return map;
  }
}
