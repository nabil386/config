/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;

import curam.codetable.CASEEVIDENCE;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.infrastructure.intf.Evidence;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.Evidence2Compare;
import curam.core.sl.infrastructure.impl.EvidenceComparisonHelper;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.struct.ECEvidenceForListPageDtls;
import curam.core.sl.infrastructure.struct.ECParentDtls;
import curam.core.sl.infrastructure.struct.ECParentEvidenceDtls;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIListCaseEvidenceKey;
import curam.core.sl.infrastructure.struct.EvidenceAttributeDtls;
import curam.core.sl.infrastructure.struct.EvidenceComparisonDtls;
import curam.core.sl.infrastructure.struct.EvidenceTypeDtls;
import curam.core.sl.infrastructure.struct.EvidenceTypeDtlsList;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.struct.CaseHeaderKey;
import curam.sample.facade.struct.SampleCreateSportingActivityExpenseDtls;
import curam.sample.facade.struct.SampleCreateSportingActivityExpenseReturnDtls;
import curam.sample.facade.struct.SampleListSportingActivityExpenseEvidenceDtls;
import curam.sample.facade.struct.SampleListSportingActivityExpenseEvidenceKey;
import curam.sample.facade.struct.SampleModifySportingActivityExpenseDtls;
import curam.sample.facade.struct.SampleModifySportingActivityExpenseReturnDtls;
import curam.sample.facade.struct.SampleSportingActivityExpenseKey;
import curam.sample.facade.struct.SampleViewSportingActivityExpenseDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Facade operations for Sample Sporting Grant Activity Expense
 */
public class SampleMaintainSportingActivityExpense
  extends curam.sample.facade.base.SampleMaintainSportingActivityExpense
  // BEGIN, CR00120297, CD
  implements Evidence2Compare {

  // END, CR00120297

  // ___________________________________________________________________________
  /**
   * Method to create Sporting Activity Expense Evidence
   *
   * @param dtls Sporting Activity Evidence Expense details
   *
   * @return Unique identifier of the Sample Sporting Activity Evidence Expense
   * record created as well as a list of informational messages
   */
  @Override
  public SampleCreateSportingActivityExpenseReturnDtls
    createSampleSportingActivityExpense(
      final SampleCreateSportingActivityExpenseDtls dtls)
      throws AppException, InformationalException {

    // Create return object
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls =
      new SampleSportingActivityExpenseDtls();

    // Assign details
    sampleSportingActivityExpenseDtls.assign(dtls);

    final EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls =
      new EvidenceDescriptorInsertDtls();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // CaseHeader entity object
    final CaseHeader caseheaderObj = CaseHeaderFactory.newInstance();

    // populate case header key
    caseHeaderKey.caseID = dtls.caseID;

    evidenceDescriptorInsertDtls.assign(dtls);

    evidenceDescriptorInsertDtls.participantID =
      caseheaderObj.readCaseParticipantDetails(caseHeaderKey).concernRoleID;

    evidenceDescriptorInsertDtls.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    final EIEvidenceInsertDtls eiEvidenceInsertDtls =
      new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.parentKey.evidenceID = dtls.sportingActivityID;
    eiEvidenceInsertDtls.parentKey.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;
    eiEvidenceInsertDtls.evidenceObject = sampleSportingActivityExpenseDtls;
    evidenceDescriptorInsertDtls.participantID =
      evidenceDescriptorInsertDtls.participantID;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    eiEvidenceKey =
      evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // Return the warnings
    final SampleCreateSportingActivityExpenseReturnDtls sampleCreateSportingActivityExpenseReturnDtls =
      new SampleCreateSportingActivityExpenseReturnDtls();

    sampleCreateSportingActivityExpenseReturnDtls.key.sportingActivityExpenseID =
      eiEvidenceKey.evidenceID;

    sampleCreateSportingActivityExpenseReturnDtls.warnings =
      evidenceControllerObj.getWarnings();

    return sampleCreateSportingActivityExpenseReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to create Sporting Activity Expense Evidence
   *
   * @param dtls Sporting Activity Evidence Expense details and succession ID
   *
   * @return Unique identifier of the Sample Sporting Activity Evidence Expense
   * record created as well as a list of informational messages
   */
  @Override
  public SampleCreateSportingActivityExpenseReturnDtls
    createSampleSportingActivityExpenseForSportingActivity(
      final SampleCreateSportingActivityExpenseDtls dtls)
      throws AppException, InformationalException {

    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = dtls.successionID;

    // get the descriptor
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final EvidenceDescriptorDtls lastInSuccession =
      evidenceControllerObj.getBusinessObjectDescriptor(successionID);

    dtls.caseID = lastInSuccession.caseID;
    dtls.sportingActivityID = lastInSuccession.relatedID;
    dtls.successionID = 0;

    return createSampleSportingActivityExpense(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to list Sample Sporting Activity Expense Evidence
   *
   * @param key Key to retrieve list of Sporting Activity Expense Evidence
   *
   * @return List of Sample Sporting Activity Expense Evidence
   */
  @Override
  public SampleListSportingActivityExpenseEvidenceDtls
    listSampleSportingActivityExpense(
      final SampleListSportingActivityExpenseEvidenceKey key)
      throws AppException, InformationalException {

    // Call the Controller object.
    final EIListCaseEvidenceKey eiListCaseEvidenceKey =
      new EIListCaseEvidenceKey();

    eiListCaseEvidenceKey.parentEvidenceID = key.parentEvidenceID;
    eiListCaseEvidenceKey.caseID = key.caseID;
    eiListCaseEvidenceKey.parentEvidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;
    eiListCaseEvidenceKey.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final ECEvidenceForListPageDtls ecEvidenceForListPageDtls =
      evidenceControllerObj.listAllForEvidenceListPage(eiListCaseEvidenceKey);

    // Instantiate the return struct
    final SampleListSportingActivityExpenseEvidenceDtls sampleListSportingActivityExpenseEvidenceDtls =
      new SampleListSportingActivityExpenseEvidenceDtls();

    sampleListSportingActivityExpenseEvidenceDtls.listDtls
      .assign(ecEvidenceForListPageDtls);

    return sampleListSportingActivityExpenseEvidenceDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the Sporting Activity Expense Evidence
   *
   * @param key Key to modify Sporting Activity Expense Evidence
   * @param dtls Modified Sporting Activity Expense Evidence
   *
   * @return Modified Sporting Activity Expense Evidence
   */
  @Override
  public SampleModifySportingActivityExpenseReturnDtls
    modifySampleSportingActivityExpense(
      final SampleSportingActivityExpenseKey key,
      final SampleModifySportingActivityExpenseDtls dtls)
      throws AppException, InformationalException {

    // Create return object
    final SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls =
      new SampleSportingActivityExpenseDtls();

    // Set up the required structures
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = key.sportingActivityExpenseID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    sampleSportingActivityExpenseDtls.assign(dtls);

    final EIEvidenceModifyDtls eiEvidenceModifyDtls =
      new EIEvidenceModifyDtls();

    eiEvidenceModifyDtls.descriptor.assign(dtls);
    eiEvidenceModifyDtls.parentKey.evidenceID = dtls.sportingActivityID;
    eiEvidenceModifyDtls.parentKey.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;
    eiEvidenceModifyDtls.evidenceObject = sampleSportingActivityExpenseDtls;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.modifyEvidence(eiEvidenceKey, eiEvidenceModifyDtls);

    // Return the warnings
    final SampleModifySportingActivityExpenseReturnDtls sampleModifySportingActivityExpenseReturnDtls =
      new SampleModifySportingActivityExpenseReturnDtls();

    sampleModifySportingActivityExpenseReturnDtls.warnings =
      evidenceControllerObj.getWarnings();

    return sampleModifySportingActivityExpenseReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Sporting Activity Expense Evidence.
   *
   * @param key Identifies the evidence business object to read.
   *
   * @return Sporting Activity Expense Evidence.
   */
  @Override
  public SampleViewSportingActivityExpenseDtls
    readSampleSportingActivityExpenseObject(final SuccessionID key)
      throws AppException, InformationalException {

    final Evidence evidenceObj = EvidenceFactory.newInstance();
    final EvidenceCaseKey evidenceCaseKey =
      evidenceObj.getEvidenceAndCaseFromSuccession(key);
    final SampleSportingActivityExpenseKey sportingActivityExpenseKey =
      new SampleSportingActivityExpenseKey();

    sportingActivityExpenseKey.sportingActivityExpenseID =
      evidenceCaseKey.evidenceKey.evidenceID;
    return readSampleSportingActivityExpense(sportingActivityExpenseKey);
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Sporting Activity Expense Evidence
   *
   * @param key Key to read the Sporting Activity Expense Evidence
   *
   * @return Sporting Activity Expense Evidence
   */
  @Override
  public SampleViewSportingActivityExpenseDtls
    readSampleSportingActivityExpense(
      final SampleSportingActivityExpenseKey key)
      throws AppException, InformationalException {

    // Create return object
    final SampleViewSportingActivityExpenseDtls sampleViewSportingActivityExpenseDtls =
      new SampleViewSportingActivityExpenseDtls();

    // Set up the required structures
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = key.sportingActivityExpenseID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    final EIEvidenceReadDtls eiEvidenceReadDtls =
      evidenceControllerObj.readEvidence(eiEvidenceKey);

    sampleViewSportingActivityExpenseDtls
      .assign(eiEvidenceReadDtls.descriptor);
    sampleViewSportingActivityExpenseDtls.evidenceType =
      eiEvidenceReadDtls.descriptor.evidenceType;
    sampleViewSportingActivityExpenseDtls.assign(
      (SampleSportingActivityExpenseDtls) eiEvidenceReadDtls.evidenceObject);

    return sampleViewSportingActivityExpenseDtls;
  }

  // BEGIN, CR00080440, CD
  // ___________________________________________________________________________
  /**
   * Gets a list of potential parents when creating a child record without the
   * help of a parent identifier.
   *
   * @param key The child's evidence type and the case identifier.
   *
   * @return The list of potential parent evidence details.
   */
  @Override
  public ECParentDtls
    getParentEvidenceList(final CaseIDAndEvidenceTypeKey key)
      throws AppException, InformationalException {

    final ECParentDtls parentDtls = new ECParentDtls();

    // get the potential parent types to search for
    final EvidenceTypeDtls evidenceTypeDtls = new EvidenceTypeDtls();

    evidenceTypeDtls.evidenceType = key.evidenceType;
    final EvidenceTypeDtlsList evidenceTypeDtlsList =
      getParentTypeList(evidenceTypeDtls);

    final EIListCaseEvidenceKey eiListCaseEvidenceKey =
      new EIListCaseEvidenceKey();

    eiListCaseEvidenceKey.caseID = key.caseID;

    // for each parent type and the case id, get the active and in-edit lists
    for (int i = 0; i < evidenceTypeDtlsList.dtls.size(); i++) {

      eiListCaseEvidenceKey.evidenceType =
        evidenceTypeDtlsList.dtls.item(i).evidenceType;

      final ECEvidenceForListPageDtls ecEvidenceForListPageDtls =
        EvidenceControllerFactory.newInstance()
          .listAllForEvidenceListPage(eiListCaseEvidenceKey);

      // only add the active and in-edit lists to the return struct as we're not
      // interested in pending removal or verification lists on the create
      // screen
      ECParentEvidenceDtls ecParentEvidenceDtls;

      for (int j = 0; j < ecEvidenceForListPageDtls.activeList.dtls
        .size(); j++) {
        ecParentEvidenceDtls = new ECParentEvidenceDtls();
        ecParentEvidenceDtls
          .assign(ecEvidenceForListPageDtls.activeList.dtls.item(j));
        parentDtls.parentList.dtls.addRef(ecParentEvidenceDtls);
      }
      for (int j = 0; j < ecEvidenceForListPageDtls.newAndUpdateList.dtls
        .size(); j++) {
        ecParentEvidenceDtls = new ECParentEvidenceDtls();
        ecParentEvidenceDtls
          .assign(ecEvidenceForListPageDtls.newAndUpdateList.dtls.item(j));
        parentDtls.parentList.dtls.addRef(ecParentEvidenceDtls);
      }
    }

    // return the list of parent details
    return parentDtls;
  }

  // ___________________________________________________________________________
  /**
   * Gets a list of parent evidence types that may relate to a child evidence
   * type.
   *
   * @param key The child's evidence type details.
   *
   * @return The list of potential parent evidence types.
   */
  @Override
  public EvidenceTypeDtlsList getParentTypeList(final EvidenceTypeDtls key)
    throws AppException, InformationalException {

    // create the return struct
    final EvidenceTypeDtlsList parentTypeDtlsList =
      new EvidenceTypeDtlsList();
    EvidenceTypeDtls evidenceTypeDtls;

    // get the parent types based on the child type
    if (key.evidenceType.equals(CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE)) {

      evidenceTypeDtls = new EvidenceTypeDtls();
      evidenceTypeDtls.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;
      parentTypeDtlsList.dtls.addRef(evidenceTypeDtls);
    }

    return parentTypeDtlsList;
  }

  // END, CR00080440

  // BEGIN, CR00120297, CD
  // ___________________________________________________________________________
  /**
   * Return details that will comprise the XML blob used to populate the
   * evidence comparison screen inside the Evidence Broker.
   *
   * @param key Identifies an evidence entity
   * @return Evidence entity details
   */
  @Override
  public EvidenceComparisonDtls getComparisonData(final EvidenceCaseKey key)
    throws AppException, InformationalException {

    final EvidenceComparisonDtls evidenceComparisonDtls =
      new EvidenceComparisonDtls();

    final SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey =
      new SampleSportingActivityExpenseKey();

    sampleSportingActivityExpenseKey.sportingActivityExpenseID =
      key.evidenceKey.evidenceID;

    final SampleViewSportingActivityExpenseDtls readDtls =
      readSampleSportingActivityExpense(sampleSportingActivityExpenseKey);

    // BEGIN, CR00122003, KH
    final EvidenceDescriptorKey evidenceKey = new EvidenceDescriptorKey();

    evidenceKey.evidenceDescriptorID = readDtls.evidenceDescriptorID;

    final EvidenceDescriptorDtls evidenceDtls = EvidenceControllerFactory
      .newInstance().readEvidenceDescriptorDtls(evidenceKey);

    evidenceComparisonDtls.descriptor.assign(evidenceDtls);
    // END, CR00122003

    evidenceComparisonDtls.descriptor.updatedBy = readDtls.updatedBy;
    evidenceComparisonDtls.descriptor.updatedDateTime =
      readDtls.updatedDateTime;

    // BEGIN, CR00386333, VT
    final Locale locale =
      ProgramLocale.parseLocale(TransactionInfo.getProgramLocale());

    final ResourceBundle domainTypes = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSampleSportingActivityExpenseDomainsFile,
      locale);

    final ResourceBundle labels = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSampleSportingActivityExpenseLabelsFile,
      locale);
    // END, CR00386333

    final Object[] valueObjects =
      {readDtls.sportingExpenseType, readDtls.amount, readDtls.startDate,
        readDtls.endDate, readDtls.comments };

    final String[] attributeNames =
      {"sportingexpensetype", "amount", "startdate", "enddate", "comments" };

    final EvidenceComparisonHelper helper = new EvidenceComparisonHelper();

    // populate the return struct one attribute at a time
    for (int i =
      0; i < SampleSportingGrantConst.kSampleSportingActivityExpenseNames.length
        && i < valueObjects.length && i < attributeNames.length; i++) {

      final EvidenceAttributeDtls attribute = new EvidenceAttributeDtls();

      try {
        attribute.domain = domainTypes.getString(
          SampleSportingGrantConst.kSampleSportingActivityExpenseNames[i]);
      } catch (final MissingResourceException mre) {
        // missing domain causes widget to fail
        // insert SVR_STRING by default
        attribute.domain = CuramConst.kDomainSVR_STRING;
      }
      try {
        attribute.label = labels.getString(
          SampleSportingGrantConst.kSampleSportingActivityExpenseNames[i]);
      } catch (final MissingResourceException mre) {
        // labels are blank by default
        attribute.label = CuramConst.gkEmpty;
        attribute.name = attributeNames[i];
      }
      attribute.value = helper.objectToString(valueObjects[i]);
      evidenceComparisonDtls.details.addRef(attribute);
    }

    return evidenceComparisonDtls;
  }
  // END, CR00120297
}
