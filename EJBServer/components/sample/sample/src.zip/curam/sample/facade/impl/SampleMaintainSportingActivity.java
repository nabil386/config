/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.EVIDENCECHANGEREASON;
import curam.codetable.PRODUCTCATEGORY;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.infrastructure.intf.Evidence;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.Evidence2Compare;
import curam.core.sl.infrastructure.impl.EvidenceComparisonHelper;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.struct.ECEvidenceForListPageDtls;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIListCaseEvidenceKey;
import curam.core.sl.infrastructure.struct.EvidenceAttributeDtls;
import curam.core.sl.infrastructure.struct.EvidenceComparisonDtls;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ParticipantCaseAndUserDetails;
import curam.core.struct.ParticipantCaseAndUserKey;
import curam.message.FACADEEVIDENCE;
import curam.sample.facade.struct.EvidenceContextDescription;
import curam.sample.facade.struct.SampleCreateSportingActivityDtls;
import curam.sample.facade.struct.SampleCreateSportingActivityReturnDtls;
import curam.sample.facade.struct.SampleListSportingActivityEvidenceDtls;
import curam.sample.facade.struct.SampleListSportingActivityEvidenceKey;
import curam.sample.facade.struct.SampleModifySportingActivityDtls;
import curam.sample.facade.struct.SampleModifySportingActivityReturnDtls;
import curam.sample.facade.struct.SampleSportingActivityKey;
import curam.sample.facade.struct.SampleViewSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Facade methods for the Sample Sporting Grant Activity product.
 */
public class SampleMaintainSportingActivity
  extends curam.sample.facade.base.SampleMaintainSportingActivity
  // BEGIN, CR00120297, CD
  implements Evidence2Compare {

  // END, CR00120297

  // ___________________________________________________________________________
  /**
   * Method to create Sporting Activity Evidence
   *
   * @param dtls Sporting Activity Evidence details
   *
   * @return Unique identifier of the Sporting Activity Evidence record
   * created as well as a list of informational messages
   */
  @Override
  public SampleCreateSportingActivityReturnDtls
    createSampleSportingActivityEvidence(
      final SampleCreateSportingActivityDtls dtls)
      throws AppException, InformationalException {

    // Create return object
    final SampleCreateSportingActivityReturnDtls sampleCreateSportingActivityReturnDtls =
      new SampleCreateSportingActivityReturnDtls();

    // Set up the required structures.
    final SampleSportingActivityDtls sampleSportingActivityDtls =
      new SampleSportingActivityDtls();

    sampleSportingActivityDtls.assign(dtls);

    final EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls =
      new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.assign(dtls);

    // BEGIN, CR00037537, CSH
    if (dtls.caseParticipantRoleID == 0) {

      final CaseHeader caseheaderObj = CaseHeaderFactory.newInstance();
      final ParticipantCaseAndUserKey participantCaseAndUserKey =
        new ParticipantCaseAndUserKey();

      participantCaseAndUserKey.caseID = dtls.caseID;
      participantCaseAndUserKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;

      final ParticipantCaseAndUserDetails participantCaseAndUserDetails =
        caseheaderObj
          .readParticipanCaseAndUserDetails(participantCaseAndUserKey);

      sampleSportingActivityDtls.caseParticipantRoleID =
        participantCaseAndUserDetails.caseParticipantRoleID;
    }

    if (evidenceDescriptorInsertDtls.participantID == 0) {

      final CaseParticipantRole caseParticipantRoleObj =
        CaseParticipantRoleFactory.newInstance();

      final CaseParticipantRoleKey caseParticipantRoleKey =
        new CaseParticipantRoleKey();

      caseParticipantRoleKey.caseParticipantRoleID =
        sampleSportingActivityDtls.caseParticipantRoleID;

      final CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails =
        caseParticipantRoleObj
          .readCaseIDandParticipantID(caseParticipantRoleKey);

      evidenceDescriptorInsertDtls.participantID =
        caseIDAndParticipantRoleIDDetails.participantRoleID;
    }
    // END, CR00037537

    evidenceDescriptorInsertDtls.evidenceType =
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    final EIEvidenceInsertDtls eiEvidenceInsertDtls =
      new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.parentKey.evidenceID = 0;
    eiEvidenceInsertDtls.evidenceObject = sampleSportingActivityDtls;
    // BEGIN, EVDMGMT, GSP
    eiEvidenceInsertDtls.descriptor.changeReason =
      EVIDENCECHANGEREASON.INITIAL;
    // END, EVDMGMT
    // EvidenceController business object
    final curam.core.sl.infrastructure.impl.EvidenceControllerInterface evidenceControllerObj =
      (curam.core.sl.infrastructure.impl.EvidenceControllerInterface) curam.core.sl.infrastructure.fact.EvidenceControllerFactory
        .newInstance();

    final EIEvidenceKey eiEvidenceKey =
      evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // Return the key value and warnings
    sampleCreateSportingActivityReturnDtls.key.sportingActivityID =
      eiEvidenceKey.evidenceID;
    sampleCreateSportingActivityReturnDtls.warnings =
      evidenceControllerObj.getWarnings();

    return sampleCreateSportingActivityReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to list Sporting Activity Evidence
   *
   * @param key Key to retrieve list of Sporting Activity Evidence
   *
   * @return List of Sporting Activity Evidence
   */
  @Override
  public SampleListSportingActivityEvidenceDtls
    listSampleSportingActivityEvidence(
      final SampleListSportingActivityEvidenceKey key)
      throws AppException, InformationalException {

    // Instantiate the return struct
    final SampleListSportingActivityEvidenceDtls sampleListSportingActivityEvidenceDtls =
      new SampleListSportingActivityEvidenceDtls();

    // EvidenceInterface variable
    final EIListCaseEvidenceKey eiListCaseEvidenceKey =
      new EIListCaseEvidenceKey();

    eiListCaseEvidenceKey.caseID = key.caseID;
    eiListCaseEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    // EvidenceController business object
    final curam.core.sl.infrastructure.impl.EvidenceControllerInterface evidenceControllerObj =
      (curam.core.sl.infrastructure.impl.EvidenceControllerInterface) curam.core.sl.infrastructure.fact.EvidenceControllerFactory
        .newInstance();

    final ECEvidenceForListPageDtls ecEvidenceForListPageDtls =
      evidenceControllerObj.listAllForEvidenceListPage(eiListCaseEvidenceKey);

    sampleListSportingActivityEvidenceDtls.listEvDtls
      .assign(ecEvidenceForListPageDtls);

    // Retrieve context description
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    sampleListSportingActivityEvidenceDtls.contextDescription =
      getEvidenceContextDescription(caseKey).contextDescription;

    return sampleListSportingActivityEvidenceDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the Sporting Activity Evidence
   *
   * @param key Key to modify Sporting Activity Evidence
   * @param dtls Modified Sporting Activity Evidence
   *
   * @return Modified Sporting Activity Evidence
   */
  @Override
  public SampleModifySportingActivityReturnDtls
    modifySampleSportingActivityEvidence(final SampleSportingActivityKey key,
      final SampleModifySportingActivityDtls dtls)
      throws AppException, InformationalException {

    // Set up the required structures.
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = key.sportingActivityID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    final SampleSportingActivityDtls sampleSportingActivityDtls =
      new SampleSportingActivityDtls();

    sampleSportingActivityDtls.assign(dtls);

    final EIEvidenceModifyDtls eiEvidenceModifyDtls =
      new EIEvidenceModifyDtls();

    eiEvidenceModifyDtls.descriptor.assign(dtls);
    eiEvidenceModifyDtls.parentKey.evidenceID = 0;
    eiEvidenceModifyDtls.evidenceObject = sampleSportingActivityDtls;

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj =
      (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.modifyEvidence(eiEvidenceKey, eiEvidenceModifyDtls);

    // Return the warnings.
    final SampleModifySportingActivityReturnDtls sampleModifySportingActivityReturnDtls =
      new SampleModifySportingActivityReturnDtls();

    sampleModifySportingActivityReturnDtls.warnings =
      evidenceControllerObj.getWarnings();

    return sampleModifySportingActivityReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Sample Sporting Activity Evidence.
   *
   * @param key Identifies the evidence business object to read.
   *
   * @return Sample Sporting Activity Evidence.
   */
  @Override
  public SampleViewSportingActivityDtls readSampleSportingActivityObject(
    final SuccessionID key) throws AppException, InformationalException {

    final Evidence evidenceObj = EvidenceFactory.newInstance();
    final EvidenceCaseKey evidenceCaseKey =
      evidenceObj.getEvidenceAndCaseFromSuccession(key);
    final SampleSportingActivityKey sportingActivityKey =
      new SampleSportingActivityKey();

    sportingActivityKey.sportingActivityID =
      evidenceCaseKey.evidenceKey.evidenceID;
    return readSampleSportingActivityEvidence(sportingActivityKey);
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Sample Sporting Activity Evidence
   *
   * @param key Key to read the Sample Sporting Activity Evidence
   *
   * @return Sample Sporting Activity Evidence
   */
  @Override
  public SampleViewSportingActivityDtls
    readSampleSportingActivityEvidence(final SampleSportingActivityKey key)
      throws AppException, InformationalException {

    // Set up the required structures
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = key.sportingActivityID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    // EvidenceController business object
    final curam.core.sl.infrastructure.impl.EvidenceControllerInterface evidenceControllerObj =
      (curam.core.sl.infrastructure.impl.EvidenceControllerInterface) curam.core.sl.infrastructure.fact.EvidenceControllerFactory
        .newInstance();

    // Read evidence
    final EIEvidenceReadDtls eiEvidenceReadDtls =
      evidenceControllerObj.readEvidence(eiEvidenceKey);

    final SampleViewSportingActivityDtls sampleViewSportingActivityDtls =
      new SampleViewSportingActivityDtls();

    sampleViewSportingActivityDtls.assign(eiEvidenceReadDtls.descriptor);
    sampleViewSportingActivityDtls.evidenceType =
      eiEvidenceReadDtls.descriptor.evidenceType;
    sampleViewSportingActivityDtls.assign(
      (curam.sample.sl.entity.struct.SampleSportingActivityDtls) eiEvidenceReadDtls.evidenceObject);

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = eiEvidenceReadDtls.descriptor.caseID;

    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID =
      sampleViewSportingActivityDtls.caseParticipantRoleID;

    sampleViewSportingActivityDtls.clientDtls.name =
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance()
        .readNameAndParticipantRoleID(caseParticipantRoleKey).name;

    sampleViewSportingActivityDtls.clientDtls.caseParticipantRoleID =
      sampleViewSportingActivityDtls.caseParticipantRoleID;

    return sampleViewSportingActivityDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to retrieve the context description for the sample sporting grant
   * evidence.
   *
   * @param key CaseKey Contains a case identifier
   *
   * @return Context description
   */
  @Override
  public EvidenceContextDescription getEvidenceContextDescription(
    final CaseKey key) throws AppException, InformationalException {

    // Create return object

    final EvidenceContextDescription evidenceContextDescription =
      new EvidenceContextDescription();

    final LocalisableString description =
      new LocalisableString(FACADEEVIDENCE.EVIDENCECONTEXTDESCRIPTION);

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseConcernRoleName caseConcernRoleName;
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read ProductDelivery
    caseHeaderKey.caseID = key.caseID;

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = caseHeaderObj
      .readCaseTypeConcernRoleAndConcernRoleType(caseHeaderKey).concernRoleID;

    // Read concernRoleName
    concernRoleNameDetails =
      concernRoleObj.readConcernRoleName(concernRoleKey);

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // BEGIN, CR00022287, TV
    // Read caseHeader
    caseKey.caseID = key.caseID;
    final curam.core.struct.ICHomePageNameAndType icHomePageNameAndType =
      caseHeaderObj.readICHomePageNameAndType(caseKey);

    description.arg(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        icHomePageNameAndType.integratedCaseType,
        TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // END, CR00022287

    description.arg(caseConcernRoleName.caseReference);
    // BEGIN, CR00098942, SAI
    description.arg(CuramConst.gkSpace);
    // END, CR00098942
    // BEGIN, CR00072819, GM
    description.arg(CuramConst.kSeparator);
    description.arg(concernRoleNameDetails.concernRoleName);
    // BEGIN, CR00098942, SAI
    description.arg(CuramConst.gkSpace);
    // END, CR00098942
    description.arg(CuramConst.kSeparator);
    // END, CR00072819

    description.arg(new CodeTableItemIdentifier(CASEEVIDENCE.TABLENAME,
      CASEEVIDENCE.SAMPLESPORTINGACTIVITY));

    // Assign it to the return object
    evidenceContextDescription.contextDescription =
      description.toClientFormattedText();
    // END CR00022287
    return evidenceContextDescription;

  }

  // BEGIN, CR00120297, CD
  // ___________________________________________________________________________
  /**
   * Return details that will comprise the XML blob used to populate the
   * evidence comparison screen inside the Evidence Broker.
   *
   * @param key Identifies an evidence entity
   * @return Evidence entity details
   */
  @Override
  public EvidenceComparisonDtls getComparisonData(final EvidenceCaseKey key)
    throws AppException, InformationalException {

    final EvidenceComparisonDtls evidenceComparisonDtls =
      new EvidenceComparisonDtls();

    final SampleSportingActivityKey sampleSportingActivityKey =
      new SampleSportingActivityKey();

    sampleSportingActivityKey.sportingActivityID = key.evidenceKey.evidenceID;

    final SampleViewSportingActivityDtls readDtls =
      readSampleSportingActivityEvidence(sampleSportingActivityKey);

    // BEGIN, CR00122003, KH
    final EvidenceDescriptorKey evidenceKey = new EvidenceDescriptorKey();

    evidenceKey.evidenceDescriptorID = readDtls.evidenceDescriptorID;

    final EvidenceDescriptorDtls evidenceDtls = EvidenceControllerFactory
      .newInstance().readEvidenceDescriptorDtls(evidenceKey);

    evidenceComparisonDtls.descriptor.assign(evidenceDtls);
    // END, CR00122003

    evidenceComparisonDtls.descriptor.updatedBy = readDtls.updatedBy;
    evidenceComparisonDtls.descriptor.updatedDateTime =
      readDtls.updatedDateTime;

    // BEGIN, CR00386333, VT
    final Locale locale =
      ProgramLocale.parseLocale(TransactionInfo.getProgramLocale());

    final ResourceBundle domainTypes = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSampleSportingActivityDomainsFile, locale);

    final ResourceBundle labels = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSampleSportingActivityLabelsFile, locale);
    // END, CR00386333

    final Object[] valueObjects =
      {readDtls.clientDtls.name, readDtls.sportingActivityType,
        readDtls.sportingAwardType, readDtls.paymentAmount,
        readDtls.startDate, readDtls.endDate, readDtls.comments };

    final String[] attributeNames = {"caseparticipantrole",
      "sportingactivitytype", "sportingactivityawardtype", "paymentamount",
      "startdate", "enddate", "comments" };

    final EvidenceComparisonHelper helper = new EvidenceComparisonHelper();

    // populate the return struct one attribute at a time
    for (int i =
      0; i < SampleSportingGrantConst.kSampleSportingActivityNames.length
        && i < valueObjects.length && i < attributeNames.length; i++) {

      final EvidenceAttributeDtls attribute = new EvidenceAttributeDtls();

      try {
        attribute.domain = domainTypes.getString(
          SampleSportingGrantConst.kSampleSportingActivityNames[i]);
      } catch (final MissingResourceException mre) {
        // missing domain causes widget to fail
        // insert SVR_STRING by default
        attribute.domain = CuramConst.kDomainSVR_STRING;
      }
      try {
        attribute.label = labels.getString(
          SampleSportingGrantConst.kSampleSportingActivityNames[i]);
      } catch (final MissingResourceException mre) {
        // labels are blank by default
        attribute.label = CuramConst.gkEmpty;
      }
      attribute.value = helper.objectToString(valueObjects[i]);
      attribute.name = attributeNames[i];
      evidenceComparisonDtls.details.addRef(attribute);
    }

    return evidenceComparisonDtls;
  }
  // END, CR00120297
}
