/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.core.facade.struct.CreatedCaseIDKey;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.struct.ActivateEvidenceTreeDetails;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.sample.facade.struct.ActivateSampleBenefitEvidence;
import curam.sample.facade.struct.CancelEvidenceDetails;
import curam.sample.facade.struct.CreateLiabilityCaseKey;
import curam.sample.facade.struct.CreateSampleLiabilityDetails;
import curam.sample.facade.struct.GetSampleLiabilityEvidenceKey;
import curam.sample.facade.struct.MaintainSimpleLiabilityProduct;
import curam.sample.facade.struct.SampleLiabilityEvidence;
import curam.sample.struct.SimpleLiabilityEvidenceDateAndVersionKey;
import curam.sample.struct.SimpleLiabilityEvidenceDetails;
import curam.sample.struct.SimpleLiabilityEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Contains maintenance functions for the SampleLiability facade layer.
 */
public abstract class SampleLiability extends curam.sample.facade.base.SampleLiability {

  // ___________________________________________________________________________
  /**
   * Creates a case for the Sample Liability Product
   *
   * @param details Details to create the Sample Liability Product
   */
  @Override
  public CreateLiabilityCaseKey createCase(
    CreateSampleLiabilityDetails details) throws AppException,
      InformationalException {

    // Create return object
    final CreateLiabilityCaseKey createLiabilityCaseKey = new CreateLiabilityCaseKey();

    // CreateProductDelivery manipulation variables
    final curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();
    final CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();
    final RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();

    // MaintainSampleLiabilityEvidence manipulation variables
    final curam.sample.intf.MaintainSimpleLiabilityEvidence maintainSampleLiabilityEvidenceObj = curam.sample.fact.MaintainSimpleLiabilityEvidenceFactory.newInstance();
    final SimpleLiabilityEvidenceDetails simpleLiabilityEvidenceDetails = new SimpleLiabilityEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // Call CreateProductDelivery BPO to register the Sample Liability Product
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(registerProductDeliveryKey, new RegisterProductDeliveryDetails()).caseID;

    // Set caseID in output struct
    createLiabilityCaseKey.caseID = createdCaseIDKey.caseID;

    // Assign details to create initial evidence on the Sample Liability
    simpleLiabilityEvidenceDetails.caseID = createdCaseIDKey.caseID;
    simpleLiabilityEvidenceDetails.assign(details);

    // Call MaintainSampleLiabilityEvidence BPO to create initial evidence
    // on the Sample Liability case that has just been created above
    maintainSampleLiabilityEvidenceObj.createEvidence(
      simpleLiabilityEvidenceDetails);

    return createLiabilityCaseKey;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves evidence for the Sample Liability Product
   *
   * @param key Key to retrieve the Sample Liability evidence.
   */
  @Override
  public SampleLiabilityEvidence getEvidence(GetSampleLiabilityEvidenceKey key) throws AppException,
      InformationalException {

    // Create return object
    final SampleLiabilityEvidence sampleLiabilityEvidence = new SampleLiabilityEvidence();

    // MaintainSampleLiabilityEvidence manipulation variables
    final curam.sample.intf.MaintainSimpleLiabilityEvidence maintainSampleLiabilityEvidenceObj = curam.sample.fact.MaintainSimpleLiabilityEvidenceFactory.newInstance();
    final SimpleLiabilityEvidenceKey simpleLiabilityEvidenceKey = new SimpleLiabilityEvidenceKey();
    SimpleLiabilityEvidenceDetails simpleLiabilityEvidenceDetails = new SimpleLiabilityEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign key to read the Sample Liability Evidence
    simpleLiabilityEvidenceKey.assign(key);

    // Call MaintainSampleLiabilityEvidence BPO to read the Sample Liability
    // evidence
    simpleLiabilityEvidenceDetails = maintainSampleLiabilityEvidenceObj.getEvidence(
      simpleLiabilityEvidenceKey);

    // Assign details to return object
    sampleLiabilityEvidence.assign(simpleLiabilityEvidenceDetails);

    return sampleLiabilityEvidence;
  }

  // ___________________________________________________________________________
  /**
   * Maintains the evidence for the Sample Liability Product
   *
   * @param details Evidence for the Sample Liability Product.
   */
  @Override
  public void maintainEvidence(MaintainSimpleLiabilityProduct details)
    throws AppException, InformationalException {

    // MaintainSampleLiabilityEvidence manipulation variables
    final curam.sample.intf.MaintainSimpleLiabilityEvidence maintainSampleLiabilityEvidenceObj = curam.sample.fact.MaintainSimpleLiabilityEvidenceFactory.newInstance();
    final SimpleLiabilityEvidenceDetails simpleLiabilityEvidenceDetails = new SimpleLiabilityEvidenceDetails();

    final SimpleLiabilityEvidenceDateAndVersionKey simpleLiabilityEvidenceDateAndVersionKey = new SimpleLiabilityEvidenceDateAndVersionKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign evidence details
    simpleLiabilityEvidenceDetails.assign(details);

    simpleLiabilityEvidenceDateAndVersionKey.effectiveDate = details.effectiveFrom;
    simpleLiabilityEvidenceDateAndVersionKey.evidenceID = details.evidenceID;
    simpleLiabilityEvidenceDateAndVersionKey.versionNo = details.versionNo;

    // Call MaintainSampleLiabilityEvidence BPO to maintain the evidence
    maintainSampleLiabilityEvidenceObj.maintainEvidence(
      simpleLiabilityEvidenceDetails, simpleLiabilityEvidenceDateAndVersionKey);
  }

  // ___________________________________________________________________________
  /**
   * Activates evidence tree
   *
   * @param details Evidence tree ID for the Sample Benefit Product.
   */
  @Override
  public void activateEvidence(ActivateSampleBenefitEvidence details)
    throws AppException, InformationalException {

    // MaintainSampleBenefitEvidence manipulation variables
    final curam.sample.intf.MaintainSimpleLiabilityEvidence maintainSimpleLiabilityEvidenceObj = curam.sample.fact.MaintainSimpleLiabilityEvidenceFactory.newInstance();
    final ActivateEvidenceTreeDetails activateEvidenceTreeDetails = new ActivateEvidenceTreeDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // activate case evidence tree
    activateEvidenceTreeDetails.key.caseEvidenceTreeID = details.caseEvidenceTreeID;
    activateEvidenceTreeDetails.details.versionNo = details.versionNo;

    maintainSimpleLiabilityEvidenceObj.activateEvidence(
      activateEvidenceTreeDetails);
  }

  // ___________________________________________________________________________
  /**
   * Cancels an evidence tree.
   *
   * @param details Contains details to cancel the evidence tree.
   */
  @Override
  public void cancelEvidence(CancelEvidenceDetails details)
    throws AppException, InformationalException {

    // MaintainSimpleProductEvidence manipulation variables
    final curam.sample.intf.MaintainSimpleLiabilityEvidence maintainSimpleLiabilityEvidenceObj = curam.sample.fact.MaintainSimpleLiabilityEvidenceFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Call business process to cancel evidence tree
    maintainSimpleLiabilityEvidenceObj.cancelEvidence(details.details);
  }
}
