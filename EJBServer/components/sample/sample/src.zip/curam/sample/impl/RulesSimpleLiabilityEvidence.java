/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupResult;
import curam.sample.sl.entity.struct.SimpleLiabilityProductDtls;
import curam.sample.sl.entity.struct.SimpleLiabilityProductKey;
import curam.sample.struct.SimpleLiabilityRulesEvidenceDetails;
import curam.sample.struct.SimpleLiabilityRulesEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to get the details of evidences associated with Simple Liability
 * Product Rules
 *
 */
public abstract class RulesSimpleLiabilityEvidence extends curam.sample.base.RulesSimpleLiabilityEvidence {

  // ___________________________________________________________________________
  /**
   * Method to return rules details for Simple Liability Product
   *
   * @param key Structure containing identifier of evidence to return
   *
   * @return Simple Liability Product Evidence Details
   */
  @Override
  public SimpleLiabilityRulesEvidenceDetails getEvidence(
    SimpleLiabilityRulesEvidenceKey key) throws AppException,
      InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    final GetNearestActiveEvidenceByGroupKey getNearestActiveEvidenceByGroupKey = new GetNearestActiveEvidenceByGroupKey();
    GetNearestActiveEvidenceByGroupResult getNearestActiveEvidenceByGroupResult;

    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;

    // simpleLiabilityRulesEvidenceDetails manipulation variable
    final SimpleLiabilityRulesEvidenceDetails simpleLiabilityRulesEvidenceDetails = new SimpleLiabilityRulesEvidenceDetails();

    // Set key to get nearest active evidence by group
    getNearestActiveEvidenceByGroupKey.key.caseID = key.caseID;
    getNearestActiveEvidenceByGroupKey.key.effectiveFrom = key.dateOfCalculation;
    getNearestActiveEvidenceByGroupKey.key.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLELIABILITYPRODICT;

    // Get nearest active evidence by group
    getNearestActiveEvidenceByGroupResult = caseEvidenceAPIObj.getNearestActiveEvidenceByGroup(
      getNearestActiveEvidenceByGroupKey);

    // If no evidence is recorded, exit here
    if (getNearestActiveEvidenceByGroupResult.evidenceExistsInd == false) {

      return simpleLiabilityRulesEvidenceDetails;
    }

    // Set key to get links and group by tree and type
    getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = getNearestActiveEvidenceByGroupResult.details.caseEvidenceTreeID;
    getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

    // Get links and group by tree and type
    getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
      getLinksAndGroupByTreeAndTypeKey);

    // Check if any links exist; if they don't, exit here
    if (getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.isEmpty()) {

      return simpleLiabilityRulesEvidenceDetails;
    }

    // SimpleLiabilityProduct Object, Key and Details
    final curam.sample.sl.entity.intf.SimpleLiabilityProduct simpleLiabilityProductObj = curam.sample.sl.entity.fact.SimpleLiabilityProductFactory.newInstance();
    final SimpleLiabilityProductKey simpleLiabilityProductKey = new SimpleLiabilityProductKey();
    SimpleLiabilityProductDtls simpleLiabilityProductDtls;

    // set key to read simpleProduct - the first element in the list is used
    // as we know there can never be more than one on the Simple Liability
    // Product
    simpleLiabilityProductKey.simpleLiabilityProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

    // read simpleLiabilityProduct entity
    simpleLiabilityProductDtls = simpleLiabilityProductObj.read(
      simpleLiabilityProductKey);

    // set eligibleInd in return struct
    simpleLiabilityRulesEvidenceDetails.eligibleInd = simpleLiabilityProductDtls.eligibleInd;

    simpleLiabilityRulesEvidenceDetails.dailyRate = simpleLiabilityProductDtls.dailyRate;

    return simpleLiabilityRulesEvidenceDetails;
  }

}
