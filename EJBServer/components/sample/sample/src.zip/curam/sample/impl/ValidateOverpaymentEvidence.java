/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.entity.struct.OverpaymentEvidenceDetails;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.sample.struct.ValidateOverpaymentEvidenceDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class contains a method to validate the overpayment evidence details.
 */
public abstract class ValidateOverpaymentEvidence extends curam.sample.base.ValidateOverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * This method validates overpayment evidence details.
   *
   * @param dtls overpayment evidence details
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#validateOverpaymentDetails(OverpaymentEvidenceDetails)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity and associated processing has been moved into
   * core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void validate(ValidateOverpaymentEvidenceDetails dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final OverpaymentEvidenceDetails overpaymentEvidenceDetails = new OverpaymentEvidenceDetails();

    overpaymentEvidenceDetails.caseID = dtls.caseID;
    overpaymentEvidenceDetails.fromDate = dtls.fromDate;
    overpaymentEvidenceDetails.toDate = dtls.toDate;
    overpaymentEvidenceDetails.overpaymentAmount = dtls.overpaymentAmount;
    overpaymentEvidenceDetails.reassessmentDate = dtls.reassessmentDate;
    overpaymentEvidenceDetails.relatedCaseID = dtls.relatedCaseID;

    ReassessmentProductFactory.newInstance().validateOverpaymentDetails(
      overpaymentEvidenceDetails);
    // END, CR00192165
  }

}
