/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.impl;


import curam.codetable.CASESENSITIVITYEXCEPTIONS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.CaseUserRoleDtls;
import curam.core.sl.entity.struct.CaseUserRoleKey;
import curam.core.sl.entity.struct.CurrentUserDetails;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.ReadByCaseStatusTypeKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.fact.WorkQueueFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.intf.WorkQueue;
import curam.core.sl.struct.OrgObjectLinkDetails;
import curam.core.sl.struct.ReadWorkQueueDetails;
import curam.core.sl.struct.ReadWorkQueueKey;
import curam.core.sl.struct.SendNotificationDetails;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.SecurityResult;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringList;


public class SampleCaseUserRole implements
  curam.sample.intf.SampleCaseUserRole {

  /**
   * Method to create a case owner after canceling the "Temporary Owner
   * Assignment" work queue user role. This method will be called by sample
   * OOTB workflow to create a valid owner for the case.
   *
   * @param key
   * The case ID for the case being created.
   * @param ownerDtls
   * The details of the case organization object or user.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * <li>
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - If the user does
   * not have required privileges to access the data. <li>
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - If the user does not
   * have maintenance rights for the case.
   */
  @Override
  public void createOwnerAsConfiguredInWorkflow(final CaseID key,
    final OrgObjectLinkDetails ownerDtls) throws AppException,
      InformationalException {

    final CaseKey caseKey = new CaseKey();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();

    if (0 != key.caseID) {

      caseKey.caseID = key.caseID;
      final SecurityResult isSensitivityException = checkSensitivityExceptions(
        caseKey);

      if (!isSensitivityException.result) {
        // BEGIN, CR00227042, PM
        final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

        caseSecurityCheckKey.caseID = key.caseID;
        caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

        DataBasedSecurityResult dataBasedSecurityResult = new DataBasedSecurityResult();

        try {
          dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
            caseSecurityCheckKey);
        } catch (final RecordNotFoundException e) {// Databased security checks for case supervisor and as
          // one has yet to be created the exception is ignored.
        }
        if (!dataBasedSecurityResult.result) {
          if (dataBasedSecurityResult.restricted) {
            throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
          } else {
            throw new AppException(
              GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
          }
        }
        // END, CR00227042
      }
    }

    // Create a new owner using sample algorithm.
    caseHeaderKey.caseID = key.caseID;
    orgObjectLinkDtls.orgObjectLinkID = ownerDtls.orgObjectLinkID;
    orgObjectLinkDtls.orgObjectReference = ownerDtls.orgObjectReference;
    orgObjectLinkDtls.orgObjectType = ownerDtls.orgObjectType;
    orgObjectLinkDtls.userName = ownerDtls.userName;
    orgObjectLinkDtls.versionNo = ownerDtls.versionNo;
    // BEGIN, CR00208641, SS
    // Call the method to create a sample owner to be the sample owner
    // assignment work queue.
    createSampleOwner(caseHeaderKey, orgObjectLinkDtls);
    // END, CR00208641
  }

  // BEGIN, CR00208641, SS
  /**
   * Helper method to assign a case to "Sample Owner Assignment" work queue.
   * This method will be called by sample OOTB workflow to create a sample owner
   * for the case.
   *
   * @param key
   * The case ID for the case being created.
   * @param ownerDtls
   * The details of the "Sample Owner Assignment" work queue.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createSampleOwner(final CaseHeaderKey key,
    final OrgObjectLinkDtls ownerDtls) throws AppException,
      InformationalException {

    OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    final CaseUserRoleDtls caseUserRoleDtls = new CaseUserRoleDtls();

    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final SendNotificationDetails sendNotificationDetails = new SendNotificationDetails();

    final ReadWorkQueueKey readWorkQueueKey = new ReadWorkQueueKey();

    // Set the owner to be "Sample Owner Assignment" work queue.
    readWorkQueueKey.key.workQueueID = CuramConst.kSampleOwnerWorkQueueID;
    final WorkQueue workqueue = WorkQueueFactory.newInstance();

    // BEGIN, CR00227064, NS
    ReadWorkQueueDetails readWorkQueueDetails = new ReadWorkQueueDetails();

    try {
      readWorkQueueDetails = workqueue.read(readWorkQueueKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      readWorkQueueKey.key.workQueueID = CuramConst.kPendingOwnerWorkQueueID;

      try {
        readWorkQueueDetails = workqueue.read(readWorkQueueKey);
      } catch (final RecordNotFoundException exception) {

        // If the PENDING OWNER ASSIGNMENT work queue is not available then the
        // assignment should just remain with the TEMPORARY OWNER ASSIGNMENT
        // work queue.
        return;
      }
    }

    if (null == readWorkQueueDetails.dtls.name) {
      readWorkQueueKey.key.workQueueID = CuramConst.kPendingOwnerWorkQueueID;

      try {
        readWorkQueueDetails = workqueue.read(readWorkQueueKey);
      } catch (final RecordNotFoundException recordNotFoundException) {

        // If the PENDING OWNER ASSIGNMENT work queue is not available then
        // the assignment should just remain with the TEMPORARY OWNER
        // ASSIGNMENT work queue.
        return;
      }
    }
    // END, CR00227064

    // BEGIN, CR00235583, NS
    final ReadByCaseStatusTypeKey readByCaseStatusTypeKey = new ReadByCaseStatusTypeKey();

    readByCaseStatusTypeKey.caseID = key.caseID;
    readByCaseStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    readByCaseStatusTypeKey.typeCode = CASEUSERROLETYPE.OWNER;
    final curam.core.sl.entity.intf.CaseUserRole caseUserRole = curam.core.sl.entity.fact.CaseUserRoleFactory.newInstance();

    final CurrentUserDetails currentUserDetails = caseUserRole.readActiveUserDetails(
      readByCaseStatusTypeKey);

    final CaseUserRoleKey cancelCaseUserRoleKey = new CaseUserRoleKey();

    cancelCaseUserRoleKey.caseUserRoleID = currentUserDetails.caseUserRoleID;

    // Current user role needs to be canceled for the new user role to be
    // created.
    final CaseUserRole createCaseUserRoleObj = CaseUserRoleFactory.newInstance();

    createCaseUserRoleObj.cancelUserRole(cancelCaseUserRoleKey);
    // END, CR00235583

    ownerDtls.orgObjectType = ORGOBJECTTYPE.WORKQUEUE;
    ownerDtls.orgObjectReference = readWorkQueueDetails.dtls.workQueueID;
    ownerDtls.userName = readWorkQueueDetails.dtls.name;

    // Create OrgObjectLink.
    orgObjectLinkKey = caseUserRoleObj.createOrgObjectLink(ownerDtls);

    caseUserRoleDtls.caseID = key.caseID;
    caseUserRoleDtls.orgObjectLinkID = orgObjectLinkKey.orgObjectLinkID;

    // Create owner case user role.
    caseUserRoleObj.createOwnerCaseUserRole(caseUserRoleDtls);

    // Modify Case Header.
    caseUserRoleObj.modifyCaseHeader(key, orgObjectLinkKey);

    userRecentActionDetails.dtls.referenceNo = key.caseID;
    userRecentActionObj.createCaseActionAssign(userRecentActionDetails);

    // Retrieve environment variable.
    String genCaseOwnerCreate = Configuration.getProperty(
      EnvVars.ENV_GENCASEOWNERCREATEDTICKET);

    // Check that the variable has been populated, if not, use default variable.
    if (genCaseOwnerCreate == null) {

      genCaseOwnerCreate = EnvVars.ENV_GENCASEOWNERCREATEDTICKET_DEFAULT;
    }

    // Do we send notifications to the case owner(s)?
    if (genCaseOwnerCreate.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      // Set details for notification sending to the case owner.
      sendNotificationDetails.caseID = key.caseID;
      sendNotificationDetails.typeCode = CASEUSERROLETYPE.OWNER;
      sendNotificationDetails.userNameDtls.newOrgObjectLinkID = orgObjectLinkKey.orgObjectLinkID;

      // Send notification.
      caseUserRoleObj.sendNotification(sendNotificationDetails);
    }
  }

  // END, CR00208641

  /**
   * Checks if this case type exists in the CaseSensitivityExceptions codetable.
   *
   * @param caseKey
   * Containing the caseID.
   *
   * @return The boolean indicator for security result.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SecurityResult checkSensitivityExceptions(final CaseKey caseKey)
    throws AppException, InformationalException {

    final SecurityResult isSensitivityExceptionType = new SecurityResult();

    // read the case details to determine what the case type is
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    final StringList sensitivityExceptions = CodeTable.getAllCodesStringList(
      CASESENSITIVITYEXCEPTIONS.TABLENAME, TransactionInfo.getProgramLocale());

    // Ignore security checks if the case type is in the
    // CASESENSITIVITYEXCEPTIONS codetable as these have their own sensitivity
    // checking.
    if (sensitivityExceptions.contains(caseTypeCode.caseTypeCode)) {
      isSensitivityExceptionType.result = true;
    } else {
      isSensitivityExceptionType.result = false;
    }

    return isSensitivityExceptionType;
  }
}
