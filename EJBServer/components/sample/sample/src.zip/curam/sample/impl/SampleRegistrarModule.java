/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.PRODUCTTYPE;
import curam.core.impl.FactoryMethodHelper;
import curam.core.impl.Registrar.RegistrarType;
import curam.core.impl.RegistrarImpl;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.fact.SportingSponsorshipFactory;
import curam.sample.sl.fact.SampleSportingGrantEvidenceControllerHookFactory;
import java.lang.reflect.Method;


/**
 * A module class which registers all the hook implementations.
 */
public class SampleRegistrarModule extends AbstractModule {

  /**
   * Registers the hook implementations to a corresponding type. The type could
   * be evidence type, product type.
   */
  @Override
  public void configure() {

    // Register all hook implementations for the interface
    // EvidenceControllerHookRegistrar
    registerEvidenceControllerHookImplementations();

    // BEGIN, CR00206664, PB.
    // Register all hook implementations for the interface
    // ExternalEvidenceInterface
    registerExternalEvidenceHookImplementations();
    // END, CR00206664
  }

  /**
   * Registers all hook implementations which implement the interface
   * EvidenceControllerHookRegistrar.
   */
  protected void registerEvidenceControllerHookImplementations() {

    final MapBinder<String, Method> evidenceControllerMapBinder = MapBinder.newMapBinder(
      binder(), String.class, Method.class,
      new RegistrarImpl(RegistrarType.EVIDENCE_CONTROLLER_HOOK));

    evidenceControllerMapBinder.addBinding(PRODUCTTYPE.SPORTINGGRANTSAMPLE).toInstance(
      FactoryMethodHelper.getNewInstanceMethod(
        SampleSportingGrantEvidenceControllerHookFactory.class));
  }

  // BEGIN, CR00206664, PB.
  /**
   * Register all hook implementations for the interface
   * ExternalEvidenceInterface
   */
  protected void registerExternalEvidenceHookImplementations() {

    final MapBinder<String, Method> externalEvidenceInterfaceMapBinder = MapBinder.newMapBinder(
      binder(), String.class, Method.class,
      new RegistrarImpl(RegistrarType.EXTERNAL_EVIDENCE));

    externalEvidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.SAMPLESPORTINGACTIVITY).toInstance(
      FactoryMethodHelper.getNewInstanceMethod(
        SampleSportingActivityFactory.class));
    externalEvidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE).toInstance(
      FactoryMethodHelper.getNewInstanceMethod(
        SampleSportingActivityExpenseFactory.class));
    externalEvidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.SPORTINGSPONSORSHIP).toInstance(
      FactoryMethodHelper.getNewInstanceMethod(SportingSponsorshipFactory.class));
  }
  // END, CR00206664
}
