/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.CaseEvidenceTreeKey;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.struct.ActivateEvidenceTreeDetails;
import curam.core.sl.struct.CaseEvidenceGroupLinkDetails;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CreateEditableTreeDetails;
import curam.core.sl.struct.CreateEditableTreeKey;
import curam.core.sl.struct.CreateEditableTreeResult;
import curam.core.sl.struct.CreateEvidenceGroupDetails;
import curam.core.sl.struct.CreateEvidenceGroupResult;
import curam.core.sl.struct.CreateLinkDetails;
import curam.core.sl.struct.CreateNewTreeDetails;
import curam.core.sl.struct.CreateNewTreeResult;
import curam.core.sl.struct.FindEditableTreeOnDateKey;
import curam.core.sl.struct.FindEditableTreeOnDateResult;
import curam.core.sl.struct.GetCaseEvidenceTreeDetailsKey;
import curam.core.sl.struct.GetCaseEvidenceTreeDetailsResult;
import curam.core.sl.struct.GetCaseIDForTreeKey;
import curam.core.sl.struct.GetCaseIDForTreeResult;
import curam.core.sl.struct.GetLinkByTypeTreeAndRelatedIDKey;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupResult;
import curam.core.sl.struct.IsEvidenceEditableInTreeKey;
import curam.core.sl.struct.IsEvidenceEditableInTreeResult;
import curam.core.sl.struct.IsTreeInEditKey;
import curam.core.sl.struct.IsTreeInEditResult;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededResult;
import curam.core.sl.struct.UpdateLinkRelatedIDDetails;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.BPOCASEEVENTS;
import curam.message.GENERALCASE;
import curam.sample.sl.entity.struct.SimpleLiabilityProductDtls;
import curam.sample.sl.entity.struct.SimpleLiabilityProductKey;
import curam.sample.struct.CancelEvidenceDetails;
import curam.sample.struct.SimpleLiabilityEvidenceDateAndVersionKey;
import curam.sample.struct.SimpleLiabilityEvidenceDetails;
import curam.sample.struct.SimpleLiabilityEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import java.util.Calendar;


/**
 * Processes to maintain simple liability evidence.
 */
public abstract class MaintainSimpleLiabilityEvidence extends curam.sample.base.MaintainSimpleLiabilityEvidence {

  // BEGIN CR00110570, MR
  // Add injection for using the new CaseTransactionLog API
  public MaintainSimpleLiabilityEvidence() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  private Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00110570

  // ___________________________________________________________________________
  /**
   * Method to return Simple Liability Product evidence details
   *
   * @param key
   * Contains identifier for evidence to be returned
   *
   * @return Evidence details of the Simple Liability Product
   */
  @Override
  public SimpleLiabilityEvidenceDetails getEvidence(
    SimpleLiabilityEvidenceKey key) throws AppException,
      InformationalException {

    // simpleEvidenceDetails manipulation variable
    final SimpleLiabilityEvidenceDetails simpleLiabilityEvidenceDetails = new SimpleLiabilityEvidenceDetails();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    GetCaseEvidenceTreeDetailsResult getCaseEvidenceTreeDetailsResult;
    final GetCaseEvidenceTreeDetailsKey getCaseEvidenceTreeDetailsKey = new GetCaseEvidenceTreeDetailsKey();

    final GetNearestActiveEvidenceByGroupKey getNearestActiveEvidenceByGroupKey = new GetNearestActiveEvidenceByGroupKey();
    GetNearestActiveEvidenceByGroupResult getNearestActiveEvidenceByGroupResult;

    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails = new GetLinksAndGroupByTreeAndTypeDetails();

    // SimpleLiabilityProduct Object, Key and Details
    final curam.sample.sl.entity.intf.SimpleLiabilityProduct simpleLiabilityProductObj = curam.sample.sl.entity.fact.SimpleLiabilityProductFactory.newInstance();
    final SimpleLiabilityProductKey simpleLiabilityProductKey = new SimpleLiabilityProductKey();
    SimpleLiabilityProductDtls simpleLiabilityProductDtls;

    if (key.evidenceID != 0) {

      // Set key to get caseEvidenceTree details
      getCaseEvidenceTreeDetailsKey.key.caseEvidenceTreeID = key.evidenceID;

      getCaseEvidenceTreeDetailsResult = caseEvidenceAPIObj.getCaseEvidenceTreeDetails(
        getCaseEvidenceTreeDetailsKey);

      // If no record exists, exit here
      if (getCaseEvidenceTreeDetailsResult.recordExistsInd == false) {

        return simpleLiabilityEvidenceDetails;
      }

      simpleLiabilityEvidenceDetails.caseID = getCaseEvidenceTreeDetailsResult.details.caseID;

      simpleLiabilityEvidenceDetails.evidenceID = getCaseEvidenceTreeDetailsResult.details.caseEvidenceTreeID;
      simpleLiabilityEvidenceDetails.effectiveFrom = getCaseEvidenceTreeDetailsResult.details.effectiveFrom;
      simpleLiabilityEvidenceDetails.versionNo = getCaseEvidenceTreeDetailsResult.details.versionNo;
      simpleLiabilityEvidenceDetails.statusCode = getCaseEvidenceTreeDetailsResult.details.statusCode;

    } else {

      // set key to read nearest evidence by type
      getNearestActiveEvidenceByGroupKey.key.caseID = key.caseID;

      final Calendar calendar = key.effectiveFrom.getCalendar();

      getNearestActiveEvidenceByGroupKey.key.effectiveFrom = new Date(calendar);
      getNearestActiveEvidenceByGroupKey.key.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLELIABILITYPRODICT;

      // read nearest evidence by type
      getNearestActiveEvidenceByGroupResult = caseEvidenceAPIObj.getNearestActiveEvidenceByGroup(
        getNearestActiveEvidenceByGroupKey);

      // If no evidence exists, exit here
      if (getNearestActiveEvidenceByGroupResult.evidenceExistsInd == false) {

        return simpleLiabilityEvidenceDetails;
      }

      simpleLiabilityEvidenceDetails.evidenceID = getNearestActiveEvidenceByGroupResult.details.caseEvidenceTreeID;
      simpleLiabilityEvidenceDetails.effectiveFrom = getNearestActiveEvidenceByGroupResult.details.effectiveFrom;
      simpleLiabilityEvidenceDetails.versionNo = getNearestActiveEvidenceByGroupResult.details.versionNo;
      simpleLiabilityEvidenceDetails.caseID = getNearestActiveEvidenceByGroupResult.details.caseID;
      simpleLiabilityEvidenceDetails.statusCode = getNearestActiveEvidenceByGroupResult.details.statusCode;
    }

    // Set key to get links and group by tree and type
    getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = simpleLiabilityEvidenceDetails.evidenceID;
    getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

    // Get links and group by tree and type
    getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
      getLinksAndGroupByTreeAndTypeKey);

    // Check if any links exist; if they don't, exit here
    if (getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.isEmpty()) {

      return simpleLiabilityEvidenceDetails;
    }

    // set key to read simple liability product entity
    simpleLiabilityProductKey.simpleLiabilityProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

    // read simple liability product entity
    simpleLiabilityProductDtls = simpleLiabilityProductObj.read(
      simpleLiabilityProductKey);

    // set eligibleInd in return struct
    simpleLiabilityEvidenceDetails.eligibleInd = simpleLiabilityProductDtls.eligibleInd;

    simpleLiabilityEvidenceDetails.dailyRate = simpleLiabilityProductDtls.dailyRate;

    return simpleLiabilityEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to maintain evidence
   *
   * @param details
   * Structure containing Simple Liability Evidence details
   */
  @Override
  public void maintainEvidence(SimpleLiabilityEvidenceDetails details,
    SimpleLiabilityEvidenceDateAndVersionKey key) throws AppException,
      InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final CreateEditableTreeKey createEditableTreeKey = new CreateEditableTreeKey();
    CreateEditableTreeResult createEditableTreeResult;
    final CreateEditableTreeDetails createEditableTreeDetails = new CreateEditableTreeDetails();
    final UpdateLinkRelatedIDDetails updateLinkRelatedIDDetails = new UpdateLinkRelatedIDDetails();
    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;
    final GetLinkByTypeTreeAndRelatedIDKey getLinkByTypeTreeAndRelatedIDKey = new GetLinkByTypeTreeAndRelatedIDKey();
    CaseEvidenceGroupLinkDetails caseEvidenceGroupLinkDetails;
    final IsEvidenceEditableInTreeKey isEvidenceEditableInTreeKey = new IsEvidenceEditableInTreeKey();
    final IsTreeInEditKey isTreeInEditKey = new IsTreeInEditKey();

    // Simple Liability Entity Object and Dtls structure
    final curam.sample.sl.entity.intf.SimpleLiabilityProduct simpleLiabilityProductObj = curam.sample.sl.entity.fact.SimpleLiabilityProductFactory.newInstance();
    SimpleLiabilityProductDtls simpleLiabilityProductDtls = new SimpleLiabilityProductDtls();
    final SimpleLiabilityProductKey simpleLiabilityProductKey = new SimpleLiabilityProductKey();

    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    // check if evidence tree is 'Active' or 'In Edit'.
    IsTreeInEditResult isTreeInEditResult;

    // Set key to check if tree is editable
    isTreeInEditKey.key.caseEvidenceTreeID = key.evidenceID;

    // Call API method to check if the tree is editable
    isTreeInEditResult = caseEvidenceAPIObj.isTreeInEdit(isTreeInEditKey);

    // If evidence tree has a status of 'In Edit'.
    if (isTreeInEditResult.result == true) {

      // Must check if evidence is editable (in place) in our 'In Edit'
      // tree.
      // It always will be on an 'In Edit' tree for our sample benefit
      // product,
      // however, for demo purposes the test will be included here

      // Set key to get links and group by tree and type
      getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = key.evidenceID;
      getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

      // Call API method to get link(s) and group by tree and evidence
      // type.
      // There will be only be one link on our tree.
      getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
        getLinksAndGroupByTreeAndTypeKey);

      // As there can only be one link on the tree, set evidence link
      // identifier to relatedID of first element in the list
      isEvidenceEditableInTreeKey.key.caseEvidenceGroupLinkID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).caseEvidenceGroupLinkID;

      // Call API method to check if the evidence is editable in place
      final IsEvidenceEditableInTreeResult isEvidenceEditableInTreeResult = caseEvidenceAPIObj.isEvidenceEditableInTree(
        isEvidenceEditableInTreeKey);

      // If the evidence is not editable in place it needs to be replaced,
      // i.e. a new record inserted and its unique identifier replaced as
      // the relatedID on the link
      if (isEvidenceEditableInTreeResult.result.isEditableInTreeInd == false) {

        // Set key to get link and group by tree and type
        getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = key.evidenceID;
        getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

        // Call API method to get links and group by tree and type
        getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
          getLinksAndGroupByTreeAndTypeKey);

        // Set key to get link details by tree, type and relatedID
        getLinkByTypeTreeAndRelatedIDKey.key.relatedID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;
        getLinkByTypeTreeAndRelatedIDKey.key.caseEvidenceTreeID = key.evidenceID;
        getLinkByTypeTreeAndRelatedIDKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

        // Call API method to get link details by tree, type and
        // relatedID
        caseEvidenceGroupLinkDetails = caseEvidenceAPIObj.getLinkByTypeTreeAndRelatedID(
          getLinkByTypeTreeAndRelatedIDKey);

        // Set new details for simpleProduct
        simpleLiabilityProductDtls.simpleLiabilityProductID = uniqueIDObj.getNextID();
        simpleLiabilityProductDtls.dailyRate = details.dailyRate;
        simpleLiabilityProductDtls.eligibleInd = details.eligibleInd;

        // Insert simple liability product
        simpleLiabilityProductObj.insert(simpleLiabilityProductDtls);
        // BEGIN CR00110570, MR
        // Log Transaction Details
        if (details != null && details.caseID != 0) {
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);
          // Case Header Manipulation variable to get Case Reference Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ADDED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_ADDED, description, details.caseID,
            details.evidenceID);

        }
        // END CR00110570
        // Set details to update link with new relatedID
        updateLinkRelatedIDDetails.details.relatedID = simpleLiabilityProductDtls.simpleLiabilityProductID;
        updateLinkRelatedIDDetails.details.versionNo = caseEvidenceGroupLinkDetails.details.versionNo;
        updateLinkRelatedIDDetails.key.caseEvidenceGroupLinkID = caseEvidenceGroupLinkDetails.details.caseEvidenceGroupLinkID;

        // Call API method to update link with new relatedID
        caseEvidenceAPIObj.updateLinkRelatedID(updateLinkRelatedIDDetails);

      } else {

        // Set key to modify details
        simpleLiabilityProductKey.simpleLiabilityProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

        // Read for update
        simpleLiabilityProductDtls = simpleLiabilityProductObj.read(
          simpleLiabilityProductKey);

        // The evidence can be modified in place
        // Set new details for simpleLiabilityProduct
        simpleLiabilityProductDtls.dailyRate = details.dailyRate;
        simpleLiabilityProductDtls.eligibleInd = details.eligibleInd;
        simpleLiabilityProductDtls.simpleLiabilityProductID = simpleLiabilityProductKey.simpleLiabilityProductID;

        // Modify simple product details
        simpleLiabilityProductObj.modify(simpleLiabilityProductKey,
          simpleLiabilityProductDtls);

        // BEGIN CR00110570, MR
        // Log Transaction Details
        if (details != null && details.caseID != 0) {
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);
          // Case Header Manipulation variable to get Case Reference Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_MODIFIED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_MODIFIED, description,
            details.caseID, details.evidenceID);
        }
        // END CR00110570
      }

    } else { // if tree is active

      // Check if an editable tree already exists on the date specified
      final FindEditableTreeOnDateKey findEditableTreeOnDateKey = new FindEditableTreeOnDateKey();

      // Set key to search for editable tree on date specified
      findEditableTreeOnDateKey.caseEvidenceTreeID = key.evidenceID;
      findEditableTreeOnDateKey.effectiveFrom = key.effectiveDate;

      // Call API method to search for editable tree on date
      final FindEditableTreeOnDateResult findEditableTreeOnDateResult = caseEvidenceAPIObj.findEditableTreeOnDate(
        findEditableTreeOnDateKey);

      // If one exists, throw an exception informing the user
      if (findEditableTreeOnDateResult.editableTreeOnDateDtlsList.dtls.size()
        != 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINSIMPLEPRODUCTEVIDENCE.ERR_EVIDENCETREE_FV_EXISTS_EDITABLE_ON_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      } else {

        // Set key and details to create an editable tree
        createEditableTreeDetails.effectiveFrom = key.effectiveDate;
        createEditableTreeKey.key.caseEvidenceTreeID = details.evidenceID;

        // Create an editable tree
        createEditableTreeResult = caseEvidenceAPIObj.createEditableTree(
          createEditableTreeKey, createEditableTreeDetails);

        // Set details to insert simple liability product record - we
        // will
        // always be replacing the evidence on our evidence tree when we
        // clone
        simpleLiabilityProductDtls.simpleLiabilityProductID = uniqueIDObj.getNextID();
        simpleLiabilityProductDtls.eligibleInd = details.eligibleInd;
        simpleLiabilityProductDtls.dailyRate = details.dailyRate;

        // Insert simple liability product
        simpleLiabilityProductObj.insert(simpleLiabilityProductDtls);

        // BEGIN CR00110570, MR
        // Log Transaction Details
        if (details != null && details.caseID != 0) {
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);
          // Case Header Manipulation variable to get Case Reference Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ADDED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_ADDED, description, details.caseID,
            createEditableTreeResult.caseEvidenceTreeID);
        }
        // END CR00110570

        // Set key to get link and group by tree and type
        getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = createEditableTreeResult.caseEvidenceTreeID;
        getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

        // Get links and group by tree and type
        getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
          getLinksAndGroupByTreeAndTypeKey);

        // Set key to get link details by tree, type and relatedID
        getLinkByTypeTreeAndRelatedIDKey.key.relatedID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;
        getLinkByTypeTreeAndRelatedIDKey.key.caseEvidenceTreeID = createEditableTreeResult.caseEvidenceTreeID;
        getLinkByTypeTreeAndRelatedIDKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

        // Call API method to get link details by tree, type and
        // relatedID
        caseEvidenceGroupLinkDetails = caseEvidenceAPIObj.getLinkByTypeTreeAndRelatedID(
          getLinkByTypeTreeAndRelatedIDKey);

        // Set details to update link with new relatedID
        updateLinkRelatedIDDetails.details.relatedID = simpleLiabilityProductDtls.simpleLiabilityProductID;
        updateLinkRelatedIDDetails.details.versionNo = caseEvidenceGroupLinkDetails.details.versionNo;
        updateLinkRelatedIDDetails.key.caseEvidenceGroupLinkID = caseEvidenceGroupLinkDetails.details.caseEvidenceGroupLinkID;

        // Call API method to update link with new relatedID
        caseEvidenceAPIObj.updateLinkRelatedID(updateLinkRelatedIDDetails);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to create evidence.
   *
   * @param details
   * Structure containing Simple Liability Details for insertion
   */
  @Override
  public void createEvidence(SimpleLiabilityEvidenceDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final CreateNewTreeDetails createNewTreeDetails = new CreateNewTreeDetails();
    CreateNewTreeResult createNewTreeResult;
    final CreateEvidenceGroupDetails createEvidenceGroupDetails = new CreateEvidenceGroupDetails();
    CreateEvidenceGroupResult createEvidenceGroupResult;
    final CreateLinkDetails createLinkDetails = new CreateLinkDetails();

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    // Set details to create new (first) tree
    createNewTreeDetails.caseEvidenceTreeDtls.caseID = details.caseID;
    createNewTreeDetails.caseEvidenceTreeDtls.effectiveFrom = curam.util.type.Date.kZeroDate;

    // Call API method to create new (first) tree on case
    createNewTreeResult = caseEvidenceAPIObj.createNewTree(createNewTreeDetails);

    // Set details to create group on tree
    createEvidenceGroupDetails.caseEvidenceTreeID = createNewTreeResult.caseEvidenceTreeID;
    createEvidenceGroupDetails.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLELIABILITYPRODICT;

    // Call API method to create group on tree
    createEvidenceGroupResult = caseEvidenceAPIObj.createEvidenceGroup(
      createEvidenceGroupDetails);

    // SimpleLiabilityProduct manipulation variables
    final curam.sample.sl.entity.intf.SimpleLiabilityProduct simpleLiabilityProductObj = curam.sample.sl.entity.fact.SimpleLiabilityProductFactory.newInstance();
    final SimpleLiabilityProductDtls simpleLiabilityProductDtls = new SimpleLiabilityProductDtls();

    // Set simpleLiabilityProduct details
    simpleLiabilityProductDtls.eligibleInd = details.eligibleInd;
    simpleLiabilityProductDtls.dailyRate = details.dailyRate;

    // Declare a unique ID variable to get a unique ID
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    simpleLiabilityProductDtls.simpleLiabilityProductID = uniqueIDObj.getNextID();

    // Insert SimpleLiabilityProduct
    simpleLiabilityProductObj.insert(simpleLiabilityProductDtls);

    // Set details to create evidence link
    createLinkDetails.caseEvidenceGroupID = createEvidenceGroupResult.caseEvidenceGroupID;
    createLinkDetails.relatedID = simpleLiabilityProductDtls.simpleLiabilityProductID;
    createLinkDetails.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLELIABILITYPRODUCT;

    // Call API method to create evidence link
    caseEvidenceAPIObj.createLink(createLinkDetails);
  }

  // ___________________________________________________________________________
  /**
   * Activates an evidence tree.
   *
   * @param details
   * Details to activate an activate tree.
   */
  @Override
  public void activateEvidence(ActivateEvidenceTreeDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    // SubmitForDelayedReassessment manipulation variables
    final curam.core.intf.SubmitForDelayedReassessment submitForDelayedReassessmentObj = curam.core.fact.SubmitForDelayedReassessmentFactory.newInstance();
    final curam.core.struct.ReassessmentDetailsList reassessmentDetailsList = new curam.core.struct.ReassessmentDetailsList();

    // Call API method to activate evidence tree
    reassessmentDetailsList.reassessmentDetailsList = caseEvidenceAPIObj.activateTree(
      details);

    // Call reassess function
    submitForDelayedReassessmentObj.reassess(reassessmentDetailsList);

    // BEGIN, CR00053662, AK
    // Code to fetch the required CaseID
    final GetCaseIDForTreeKey getCaseIDForTreeKey = new GetCaseIDForTreeKey();

    final CaseEvidenceTreeKey caseEvidenceTreeKey = new CaseEvidenceTreeKey();

    caseEvidenceTreeKey.caseEvidenceTreeID = details.key.caseEvidenceTreeID;

    getCaseIDForTreeKey.key = caseEvidenceTreeKey;

    final GetCaseIDForTreeResult getCaseIDForTreeResult = caseEvidenceAPIObj.getCaseIDForTree(
      getCaseIDForTreeKey);

    if (getCaseIDForTreeResult != null
      && getCaseIDForTreeResult.details != null
      && getCaseIDForTreeResult.details.caseID != 0) {
      // Log Transaction Details
      // BEGIN CR00110570, MR
      // maintainCase manipulation variable to get product name and
      // primary client name
      final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = getCaseIDForTreeResult.details.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);
      // Case Header Manipulation variable to get Case Reference Number
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = getCaseIDForTreeResult.details.caseID;
      // create the description
      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ACTIVATED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.EVIDENCE_ACTIVATED, description,
        getCaseIDForTreeResult.details.caseID, details.key.caseEvidenceTreeID);
      // END CR00110570
    }
    // END, CR00053662

  }

  // ___________________________________________________________________________
  /**
   * Cancels an evidence tree.
   *
   * @param details
   * Contains details to cancel the evidence tree.
   */
  @Override
  public void cancelEvidence(CancelEvidenceDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    // SubmitForDelayedReassessment manipulation variables
    final curam.core.intf.SubmitForDelayedReassessment submitForDelayedReassessmentObj = curam.core.fact.SubmitForDelayedReassessmentFactory.newInstance();
    final curam.core.struct.ReassessmentDetailsList reassessmentDetailsList = new curam.core.struct.ReassessmentDetailsList();

    // Call API method to cancel evidence tree
    reassessmentDetailsList.reassessmentDetailsList = caseEvidenceAPIObj.cancelTree(
      details.details);

    // Call reassess function
    submitForDelayedReassessmentObj.reassess(reassessmentDetailsList);

    // BEGIN, CR00053662, AK

    // Code to fetch caseID
    final GetCaseIDForTreeKey getCaseIDForTreeKey = new GetCaseIDForTreeKey();

    getCaseIDForTreeKey.key.caseEvidenceTreeID = details.details.key.caseEvidenceTreeID;
    final GetCaseIDForTreeResult getCaseIDForTreeResult = caseEvidenceAPIObj.getCaseIDForTree(
      getCaseIDForTreeKey);
    // BEGIN, CR00053662, AK
    // CaseEvidenceAPI manipulation variables
    final ListEvidenceTreeLessCanceledAndSupersededKey listEvidenceTreeLessCanceledAndSupersededKey = new ListEvidenceTreeLessCanceledAndSupersededKey();
    ListEvidenceTreeLessCanceledAndSupersededResult listEvidenceTreeLessCanceledAndSupersededResult;

    // Set key to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededKey.key.caseID = getCaseIDForTreeResult.details.caseID;

    // Call API method to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededResult = caseEvidenceAPIObj.listEvidenceTreeLessCanceledAndSuperseded(
      listEvidenceTreeLessCanceledAndSupersededKey);

    if (listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSIMPLEPRODUCTEVIDENCE.ERR_CANNOT_CANCEL_LAST_EVIDENCE_TREE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // END, CR00053662
    if (getCaseIDForTreeResult != null
      && getCaseIDForTreeResult.details != null
      && getCaseIDForTreeResult.details.caseID != 0) {
      // Log Transaction Details
      // BEGIN CR00110570, MR
      // maintainCase manipulation variable to get product name and
      // primary client name
      final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = getCaseIDForTreeResult.details.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);
      // Case Header Manipulation variable to get Case Reference Number
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = getCaseIDForTreeResult.details.caseID;
      // create the description
      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_CANCELLED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.EVIDENCE_CANCELED, description,
        getCaseIDForTreeResult.details.caseID, CuramConst.kDefaultRelatedID);
      // END CR00110570
    }
    // END, CR00053662
  }

}
