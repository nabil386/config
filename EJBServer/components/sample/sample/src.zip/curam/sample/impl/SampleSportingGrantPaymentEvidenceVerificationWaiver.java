/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.sample.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.struct.VerificationRequirementDtls;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtls;
import curam.verification.sl.infrastructure.fact.MaintainVerificationWaiverFactory;
import curam.verification.sl.infrastructure.impl.EvidenceVerificationWaiver;
import curam.verification.sl.infrastructure.intf.MaintainVerificationWaiver;


/**
 * Implementation to process Sporting Grant Payment Evidence to set Waiver
 */
public class SampleSportingGrantPaymentEvidenceVerificationWaiver implements
  EvidenceVerificationWaiver {

  public static int kNumberOfDaysWaiveredFromCaseStart = 2;

  /**
   * Creates the Verification Waiver record
   *
   * @param key
   * ID of the case
   * @param evidenceKey
   * Evidence ID and Evidence Type
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void process(final VerificationDtls details,
    final EIEvidenceKey eiEvidenceKey) throws AppException,
      InformationalException {

    final VerificationRequirementKey requirementKey = new VerificationRequirementKey();

    requirementKey.verificationRequirementID = details.verificationRequirementID;

    // Read the verification details
    final VerificationRequirementDtls requirementDtls = VerificationRequirementFactory.newInstance().read(
      requirementKey);

    // process only if mandatory and in the current implementation only if its
    // case data
    if (requirementDtls.mandatory
      & !details.verificationLinkedType.equals(VERIFICATIONTYPE.NONCASEDATA)) {

      final MaintainVerificationWaiver verificationWaiverObj = MaintainVerificationWaiverFactory.newInstance();
      final VerificationWaiverDtls verificationWaiverDtls = new VerificationWaiverDtls();

      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // verificationLinkedID is the case ID when type case Data
      caseHeaderKey.caseID = details.verificationLinkedID;
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      if (!(caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        || caseHeaderDtls.statusCode.equals(CASESTATUS.OPEN))) {
        // only process if Case is active
        return;
      }

      // Populate Waiver details
      verificationWaiverDtls.startDate = caseHeaderDtls.startDate;
      verificationWaiverDtls.endDate = caseHeaderDtls.startDate.addDays(
        kNumberOfDaysWaiveredFromCaseStart);
      if (!caseHeaderDtls.endDate.isZero()
        && verificationWaiverDtls.endDate.after(caseHeaderDtls.endDate)) {
        verificationWaiverDtls.endDate = caseHeaderDtls.endDate;
      }
      // populate the Waiver with Verification ID
      verificationWaiverDtls.VDIEDLinkID = details.VDIEDLinkID;
      verificationWaiverDtls.verificationID = details.verificationID;
      verificationWaiverObj.create(verificationWaiverDtls);
    }
  }
}
