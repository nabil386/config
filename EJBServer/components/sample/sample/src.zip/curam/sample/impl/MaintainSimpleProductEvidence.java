/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.CaseEvidenceTreeKey;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.struct.ActivateEvidenceTreeDetails;
import curam.core.sl.struct.CaseEvidenceGroupLinkDetails;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CreateEditableTreeDetails;
import curam.core.sl.struct.CreateEditableTreeKey;
import curam.core.sl.struct.CreateEditableTreeResult;
import curam.core.sl.struct.CreateEvidenceGroupDetails;
import curam.core.sl.struct.CreateEvidenceGroupResult;
import curam.core.sl.struct.CreateLinkDetails;
import curam.core.sl.struct.CreateNewTreeDetails;
import curam.core.sl.struct.CreateNewTreeResult;
import curam.core.sl.struct.FindEditableTreeOnDateKey;
import curam.core.sl.struct.FindEditableTreeOnDateResult;
import curam.core.sl.struct.GetCaseEvidenceTreeDetailsKey;
import curam.core.sl.struct.GetCaseEvidenceTreeDetailsResult;
import curam.core.sl.struct.GetCaseIDForTreeKey;
import curam.core.sl.struct.GetCaseIDForTreeResult;
import curam.core.sl.struct.GetLinkByTypeTreeAndRelatedIDKey;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupResult;
import curam.core.sl.struct.IsEvidenceEditableInTreeKey;
import curam.core.sl.struct.IsEvidenceEditableInTreeResult;
import curam.core.sl.struct.IsTreeInEditKey;
import curam.core.sl.struct.IsTreeInEditResult;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededResult;
import curam.core.sl.struct.SuspendEvidenceTreeDetails;
import curam.core.sl.struct.UpdateLinkRelatedIDDetails;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.BPOCASEEVENTS;
import curam.message.GENERALCASE;
import curam.sample.sl.entity.struct.SimpleProductDtls;
import curam.sample.sl.entity.struct.SimpleProductKey;
import curam.sample.struct.CancelEvidenceDetails;
import curam.sample.struct.SimpleEvidenceDateAndVersionKey;
import curam.sample.struct.SimpleEvidenceDetails;
import curam.sample.struct.SimpleEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import java.util.Calendar;


/**
 * Code to get evidence, maintain evidence and create evidence for simple
 * products.
 */
public abstract class MaintainSimpleProductEvidence extends curam.sample.base.MaintainSimpleProductEvidence {

  // BEGIN CR00110570, MR
  // Add injection for using the new CaseTransactionLog API
  public MaintainSimpleProductEvidence() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00110570

  // ___________________________________________________________________________
  /**
   * Method to get return evidence.
   *
   * @param key
   * Key to identify the evidence to be returned
   *
   * @return Evidence details
   */
  @Override
  public SimpleEvidenceDetails getEvidence(SimpleEvidenceKey key)
    throws AppException, InformationalException {

    // SimpleEvidenceDetails object
    final SimpleEvidenceDetails simpleEvidenceDetails = new SimpleEvidenceDetails();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    final GetNearestActiveEvidenceByGroupKey getNearestActiveEvidenceByGroupKey = new GetNearestActiveEvidenceByGroupKey();
    GetNearestActiveEvidenceByGroupResult getNearestActiveEvidenceByGroupResult;

    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails = new GetLinksAndGroupByTreeAndTypeDetails();

    // SimpleProduct manipulation variables
    final curam.sample.sl.entity.intf.SimpleProduct simpleProductObj = curam.sample.sl.entity.fact.SimpleProductFactory.newInstance();
    final SimpleProductKey simpleProductKey = new SimpleProductKey();
    SimpleProductDtls simpleProductDtls = new SimpleProductDtls();

    if (key.evidenceID != 0) {

      GetCaseEvidenceTreeDetailsResult getCaseEvidenceTreeDetailsResult;
      final GetCaseEvidenceTreeDetailsKey getCaseEvidenceTreeDetailsKey = new GetCaseEvidenceTreeDetailsKey();

      // Set key to get caseEvidenceTree details
      getCaseEvidenceTreeDetailsKey.key.caseEvidenceTreeID = key.evidenceID;

      getCaseEvidenceTreeDetailsResult = caseEvidenceAPIObj.getCaseEvidenceTreeDetails(
        getCaseEvidenceTreeDetailsKey);

      // If no record exists, exit here
      if (getCaseEvidenceTreeDetailsResult.recordExistsInd == false) {
        return simpleEvidenceDetails;
      }

      simpleEvidenceDetails.caseID = getCaseEvidenceTreeDetailsResult.details.caseID;
      simpleEvidenceDetails.evidenceID = getCaseEvidenceTreeDetailsResult.details.caseEvidenceTreeID;
      simpleEvidenceDetails.effectiveFrom = getCaseEvidenceTreeDetailsResult.details.effectiveFrom;
      simpleEvidenceDetails.versionNo = getCaseEvidenceTreeDetailsResult.details.versionNo;
      // Status field should be displayed in view Evidence page
      simpleEvidenceDetails.statusCode = getCaseEvidenceTreeDetailsResult.details.statusCode;

    } else {

      // set key to get nearest evidence by group
      getNearestActiveEvidenceByGroupKey.key.caseID = key.caseID;

      final Calendar calendar = key.effectiveFrom.getCalendar();

      getNearestActiveEvidenceByGroupKey.key.effectiveFrom = new Date(calendar);
      getNearestActiveEvidenceByGroupKey.key.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLEPRODUCT;

      // read nearest evidence by type
      getNearestActiveEvidenceByGroupResult = caseEvidenceAPIObj.getNearestActiveEvidenceByGroup(
        getNearestActiveEvidenceByGroupKey);

      // If no evidence exists, exit here
      if (getNearestActiveEvidenceByGroupResult.evidenceExistsInd == false) {
        return simpleEvidenceDetails;
      }

      simpleEvidenceDetails.evidenceID = getNearestActiveEvidenceByGroupResult.details.caseEvidenceTreeID;
      simpleEvidenceDetails.effectiveFrom = getNearestActiveEvidenceByGroupResult.details.effectiveFrom;
      simpleEvidenceDetails.versionNo = getNearestActiveEvidenceByGroupResult.details.versionNo;
      simpleEvidenceDetails.caseID = getNearestActiveEvidenceByGroupResult.details.caseID;
      // Status field should be displayed in view Evidence page
      simpleEvidenceDetails.statusCode = getNearestActiveEvidenceByGroupResult.details.statusCode;
    }

    // Set key to get links and group by tree and type
    getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = simpleEvidenceDetails.evidenceID;
    getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

    // Get links and group by tree and type
    getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
      getLinksAndGroupByTreeAndTypeKey);

    // Check if any links exist; if they don't, exit here
    if (getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.isEmpty()) {
      return simpleEvidenceDetails;
    }

    simpleProductKey.simpleProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

    // read simpleProduct entity
    simpleProductDtls = simpleProductObj.read(simpleProductKey);

    // set eligibleInd in return struct
    simpleEvidenceDetails.eligibleInd = simpleProductDtls.eligibleInd;

    // set childIndicator in return struct
    simpleEvidenceDetails.childIndicator = simpleProductDtls.childIndicator;

    simpleEvidenceDetails.dailyRate = simpleProductDtls.dailyRate;

    return simpleEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to maintain evidence
   *
   * @param details
   * Evidence details to be maintained
   */
  @Override
  public void maintainEvidence(SimpleEvidenceDetails details,
    SimpleEvidenceDateAndVersionKey key) throws AppException,
      InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final CreateEditableTreeKey createEditableTreeKey = new CreateEditableTreeKey();
    CreateEditableTreeResult createEditableTreeResult;
    final CreateEditableTreeDetails createEditableTreeDetails = new CreateEditableTreeDetails();
    final UpdateLinkRelatedIDDetails updateLinkRelatedIDDetails = new UpdateLinkRelatedIDDetails();
    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;
    final GetLinkByTypeTreeAndRelatedIDKey getLinkByTypeTreeAndRelatedIDKey = new GetLinkByTypeTreeAndRelatedIDKey();
    CaseEvidenceGroupLinkDetails caseEvidenceGroupLinkDetails;
    final IsEvidenceEditableInTreeKey isEvidenceEditableInTreeKey = new IsEvidenceEditableInTreeKey();
    final IsTreeInEditKey isTreeInEditKey = new IsTreeInEditKey();

    // SimpleProduct manipulation variables
    final curam.sample.sl.entity.intf.SimpleProduct simpleProductObj = curam.sample.sl.entity.fact.SimpleProductFactory.newInstance();
    SimpleProductDtls simpleProductDtls = new SimpleProductDtls();
    final SimpleProductKey simpleProductKey = new SimpleProductKey();

    // UniqueID object
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    if (details.dailyRate.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSIMPLEPRODUCTEVIDENCE.ERR_DAILY_RATE_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check is evidence tree is 'Active' or 'In Edit'.
    // Set key to check if tree is editable
    isTreeInEditKey.key.caseEvidenceTreeID = key.evidenceID;

    // Call API method to check if tree is 'In Edit'.
    final IsTreeInEditResult isTreeInEditResult = caseEvidenceAPIObj.isTreeInEdit(
      isTreeInEditKey);

    // If evidence tree has a status of 'In Edit'.
    if (isTreeInEditResult.result == true) {

      // Must check if evidence is editable (in place) in our 'In Edit'
      // tree.
      // It always will be on an 'In Edit' tree for our sample benefit
      // product,
      // however, for demo purposes the test will be included here

      // Set key to get links and group by tree and type
      getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = key.evidenceID;
      getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

      // Call API method to get link(s) and group by tree and evidence
      // type.
      // There will be only be one link on our tree.
      getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
        getLinksAndGroupByTreeAndTypeKey);

      // As there can only be one link on the tree, set evidence link
      // identifier to relatedID of first element in the list
      isEvidenceEditableInTreeKey.key.caseEvidenceGroupLinkID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).caseEvidenceGroupLinkID;

      // Call API method to check if the evidence is editable in place
      final IsEvidenceEditableInTreeResult isEvidenceEditableInTreeResult = caseEvidenceAPIObj.isEvidenceEditableInTree(
        isEvidenceEditableInTreeKey);

      // If the evidence is not editable in place it needs to be replaced,
      // i.e. a new record inserted and its unique identifier replaced as
      // the relatedID on the link
      if (isEvidenceEditableInTreeResult.result.isEditableInTreeInd == false) {

        // Set key to get link and group by tree and type
        getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = key.evidenceID;
        getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

        // Call API method to get links and group by tree and type
        getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
          getLinksAndGroupByTreeAndTypeKey);

        // Set key to get link details by tree, type and relatedID
        getLinkByTypeTreeAndRelatedIDKey.key.relatedID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;
        getLinkByTypeTreeAndRelatedIDKey.key.caseEvidenceTreeID = key.evidenceID;
        getLinkByTypeTreeAndRelatedIDKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

        // Call API method to get link details by tree, type and
        // relatedID
        caseEvidenceGroupLinkDetails = caseEvidenceAPIObj.getLinkByTypeTreeAndRelatedID(
          getLinkByTypeTreeAndRelatedIDKey);

        // Set new details for simpleProduct
        simpleProductDtls.simpleProductID = uniqueIDObj.getNextID();
        simpleProductDtls.dailyRate = details.dailyRate;
        simpleProductDtls.eligibleInd = details.eligibleInd;
        simpleProductDtls.childIndicator = details.childIndicator;

        // Insert simple product
        simpleProductObj.insert(simpleProductDtls);

        // BEGIN, CR00057528, AK
        if (details != null && details.caseID != 0) {
          // Log Transaction Details
          // BEGIN CR00110570, MR
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);

          // Case Header Manipulation variable to get Case Reference Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ADDED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_ADDED, description, details.caseID,
            details.evidenceID);
          // END CR00110570
        }
        // END, CR00057528

        // Set details to update link with new relatedID
        updateLinkRelatedIDDetails.details.relatedID = simpleProductDtls.simpleProductID;
        updateLinkRelatedIDDetails.details.versionNo = caseEvidenceGroupLinkDetails.details.versionNo;
        updateLinkRelatedIDDetails.key.caseEvidenceGroupLinkID = caseEvidenceGroupLinkDetails.details.caseEvidenceGroupLinkID;

        // Call API method to update link with new relatedID
        caseEvidenceAPIObj.updateLinkRelatedID(updateLinkRelatedIDDetails);

      } else {

        // Set key to modify details
        simpleProductKey.simpleProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

        // Read for update
        simpleProductDtls = simpleProductObj.read(simpleProductKey);

        // The evidence can be modified in place
        // Set new details for simpleProduct
        simpleProductDtls.dailyRate = details.dailyRate;
        simpleProductDtls.eligibleInd = details.eligibleInd;
        simpleProductDtls.childIndicator = details.childIndicator;
        simpleProductDtls.simpleProductID = simpleProductKey.simpleProductID;

        // Modify simple product details
        simpleProductObj.modify(simpleProductKey, simpleProductDtls);

        // BEGIN, CR00057528, AK
        if (details != null && details.caseID != 0) {
          // Log Transaction Details
          // BEGIN CR00110570, MR
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);

          // Case Header Manipulation variable to get Case Reference Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_MODIFIED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_MODIFIED, description,
            details.caseID, details.evidenceID);
          // END CR00110570
        }
        // END, CR00057528
      }

    } else { // if tree is active

      // Check if an editable tree already exists on the date specified
      final FindEditableTreeOnDateKey findEditableTreeOnDateKey = new FindEditableTreeOnDateKey();

      // Set key to search for editable tree on date specified
      findEditableTreeOnDateKey.caseEvidenceTreeID = key.evidenceID;
      findEditableTreeOnDateKey.effectiveFrom = key.effectiveDate;

      // Call API method to search for editable tree on date
      final FindEditableTreeOnDateResult findEditableTreeOnDateResult = caseEvidenceAPIObj.findEditableTreeOnDate(
        findEditableTreeOnDateKey);

      // If one exists, throw an exception informing the user
      if (findEditableTreeOnDateResult.editableTreeOnDateDtlsList.dtls.size()
        != 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINSIMPLEPRODUCTEVIDENCE.ERR_EVIDENCETREE_FV_EXISTS_EDITABLE_ON_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);

      } else {

        // Set key and details to create an editable tree
        createEditableTreeDetails.effectiveFrom = key.effectiveDate;
        createEditableTreeKey.key.caseEvidenceTreeID = details.evidenceID;

        // Create an editable tree
        createEditableTreeResult = caseEvidenceAPIObj.createEditableTree(
          createEditableTreeKey, createEditableTreeDetails);

        // Set details to insert simple product record - we will always
        // be replacing the evidence on our evidence tree when we clone
        simpleProductDtls.simpleProductID = uniqueIDObj.getNextID();
        simpleProductDtls.eligibleInd = details.eligibleInd;
        simpleProductDtls.dailyRate = details.dailyRate;

        simpleProductDtls.childIndicator = details.childIndicator;

        // Insert simple product
        simpleProductObj.insert(simpleProductDtls);

        // BEGIN, CR00057528, AK
        if (details != null && details.caseID != 0) {
          // Log Transaction Details
          // BEGIN CR00110570, MR
          // maintainCase manipulation variable to get product name
          // and primary client name
          final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
          final CaseIDKey caseIDKey = new CaseIDKey();

          // set key to read maintainCase
          caseIDKey.caseID = details.caseID;
          final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
            caseIDKey);
          // Case Header Manipulation variable to get Case Reference
          // Number
          final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
          final CaseSearchKey caseSearchKey = new CaseSearchKey();

          // set caseId
          caseSearchKey.caseID = details.caseID;
          // create the description
          final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ADDED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
            caseReferenceProductNameConcernRoleName.concernRoleName);

          caseTransactionLogProvider.get().recordCaseTransaction(
            CASETRANSACTIONEVENTS.EVIDENCE_ADDED, description, details.caseID,
            createEditableTreeResult.caseEvidenceTreeID);
          // END CR00110570
        }
        // END, CR00057528

        // Set key to get link and group by tree and type
        getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = createEditableTreeResult.caseEvidenceTreeID;
        getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

        // Get links and group by tree and type
        getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
          getLinksAndGroupByTreeAndTypeKey);

        // Set key to get link details by tree, type and relatedID
        getLinkByTypeTreeAndRelatedIDKey.key.relatedID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;
        getLinkByTypeTreeAndRelatedIDKey.key.caseEvidenceTreeID = createEditableTreeResult.caseEvidenceTreeID;
        getLinkByTypeTreeAndRelatedIDKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

        // Call API method to get link details by tree, type and
        // relatedID
        caseEvidenceGroupLinkDetails = caseEvidenceAPIObj.getLinkByTypeTreeAndRelatedID(
          getLinkByTypeTreeAndRelatedIDKey);

        // Set details to update link with new relatedID
        updateLinkRelatedIDDetails.details.relatedID = simpleProductDtls.simpleProductID;
        updateLinkRelatedIDDetails.details.versionNo = caseEvidenceGroupLinkDetails.details.versionNo;
        updateLinkRelatedIDDetails.key.caseEvidenceGroupLinkID = caseEvidenceGroupLinkDetails.details.caseEvidenceGroupLinkID;

        // Call API method to update link with new relatedID
        caseEvidenceAPIObj.updateLinkRelatedID(updateLinkRelatedIDDetails);

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Method to create evidence.
   *
   * @param details
   * Evidence details to be created
   */
  @Override
  public void createEvidence(SimpleEvidenceDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final CreateNewTreeDetails createNewTreeDetails = new CreateNewTreeDetails();
    CreateNewTreeResult createNewTreeResult;

    final CreateEvidenceGroupDetails createEvidenceGroupDetails = new CreateEvidenceGroupDetails();
    CreateEvidenceGroupResult createEvidenceGroupResult;

    final CreateLinkDetails createLinkDetails = new CreateLinkDetails();

    // BEGIN, CR00227042, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    if (details.dailyRate.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSIMPLEPRODUCTEVIDENCE.ERR_DAILY_RATE_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Set details to create new tree
    createNewTreeDetails.caseEvidenceTreeDtls.caseID = details.caseID;
    createNewTreeDetails.caseEvidenceTreeDtls.effectiveFrom = curam.util.type.Date.kZeroDate;

    // Call API method to create new (first) tree on case
    createNewTreeResult = caseEvidenceAPIObj.createNewTree(createNewTreeDetails);

    // Set details to create group on tree
    createEvidenceGroupDetails.caseEvidenceTreeID = createNewTreeResult.caseEvidenceTreeID;
    createEvidenceGroupDetails.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLEPRODUCT;

    // Call API method to create group on tree
    createEvidenceGroupResult = caseEvidenceAPIObj.createEvidenceGroup(
      createEvidenceGroupDetails);

    // SimpleProduct manipulation variables
    final curam.sample.sl.entity.intf.SimpleProduct simpleProductObj = curam.sample.sl.entity.fact.SimpleProductFactory.newInstance();
    final SimpleProductDtls simpleProductDtls = new SimpleProductDtls();

    // Set simpleProduct details
    simpleProductDtls.eligibleInd = details.eligibleInd;
    simpleProductDtls.dailyRate = details.dailyRate;

    // set childIndicator in creation struct
    simpleProductDtls.childIndicator = details.childIndicator;

    // Declare a unique ID variable to get a unique ID
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    simpleProductDtls.simpleProductID = uniqueIDObj.getNextID();

    // Insert SimpleProduct
    simpleProductObj.insert(simpleProductDtls);

    // Set details to create evidence link
    createLinkDetails.caseEvidenceGroupID = createEvidenceGroupResult.caseEvidenceGroupID;
    createLinkDetails.relatedID = simpleProductDtls.simpleProductID;
    createLinkDetails.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

    // Call API method to create evidence link
    caseEvidenceAPIObj.createLink(createLinkDetails);

  }

  // ___________________________________________________________________________
  /**
   * Cancels an evidence tree.
   *
   * @param details
   * Contains details to cancel the evidence tree.
   */
  @Override
  public void cancelEvidence(CancelEvidenceDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    // Get the case id for this tree

    final GetCaseIDForTreeKey getCaseIDForTreeKey = new GetCaseIDForTreeKey();

    getCaseIDForTreeKey.key.caseEvidenceTreeID = details.details.key.caseEvidenceTreeID;
    final GetCaseIDForTreeResult getCaseIDForTreeResult = caseEvidenceAPIObj.getCaseIDForTree(
      getCaseIDForTreeKey);

    // CaseEvidenceAPI manipulation variables
    final ListEvidenceTreeLessCanceledAndSupersededKey listEvidenceTreeLessCanceledAndSupersededKey = new ListEvidenceTreeLessCanceledAndSupersededKey();
    ListEvidenceTreeLessCanceledAndSupersededResult listEvidenceTreeLessCanceledAndSupersededResult;

    // Set key to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededKey.key.caseID = getCaseIDForTreeResult.details.caseID;

    // Call API method to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededResult = caseEvidenceAPIObj.listEvidenceTreeLessCanceledAndSuperseded(
      listEvidenceTreeLessCanceledAndSupersededKey);

    if (listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size() == 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSIMPLEPRODUCTEVIDENCE.ERR_CANNOT_CANCEL_LAST_EVIDENCE_TREE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // SubmitForDelayedReassessment manipulation variables
    final curam.core.intf.SubmitForDelayedReassessment submitForDelayedReassessmentObj = curam.core.fact.SubmitForDelayedReassessmentFactory.newInstance();
    final curam.core.struct.ReassessmentDetailsList reassessmentDetailsList = new curam.core.struct.ReassessmentDetailsList();

    // Call API method to cancel evidence tree
    reassessmentDetailsList.reassessmentDetailsList = caseEvidenceAPIObj.cancelTree(
      details.details);

    // Call reassess function
    submitForDelayedReassessmentObj.reassess(reassessmentDetailsList);

    // BEGIN, CR00045872, AK
    // BEGIN, CR00022728, RR
    if (getCaseIDForTreeResult != null
      && getCaseIDForTreeResult.details != null
      && getCaseIDForTreeResult.details.caseID != 0) {
      // Log Transaction Details
      // BEGIN CR00110570, MR
      // maintainCase manipulation variable to get product name and
      // primary client name
      final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = getCaseIDForTreeResult.details.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);
      // Case Header Manipulation variable to get Case Reference Number
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = getCaseIDForTreeResult.details.caseID;
      // create the description
      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_CANCELLED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.EVIDENCE_CANCELED, description,
        getCaseIDForTreeResult.details.caseID, CuramConst.kDefaultRelatedID);
      // END CR00110570
    }
    // END, CR00022728
    // END, CR00045872, AK

  }

  // ___________________________________________________________________________
  /**
   * Activates an evidence tree.
   *
   * @param details
   * Details to activate an activate tree.
   */
  @Override
  public void activateEvidence(ActivateEvidenceTreeDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    // SubmitForDelayedReassessment manipulation variables
    final curam.core.intf.SubmitForDelayedReassessment submitForDelayedReassessmentObj = curam.core.fact.SubmitForDelayedReassessmentFactory.newInstance();
    final curam.core.struct.ReassessmentDetailsList reassessmentDetailsList = new curam.core.struct.ReassessmentDetailsList();

    // Call API method to activate evidence tree
    reassessmentDetailsList.reassessmentDetailsList = caseEvidenceAPIObj.activateTree(
      details);

    // Call reassess function
    submitForDelayedReassessmentObj.reassess(reassessmentDetailsList);

    // BEGIN, CR00045872, AK
    // Code to fetch the required CaseID
    final GetCaseIDForTreeKey getCaseIDForTreeKey = new GetCaseIDForTreeKey();

    final CaseEvidenceTreeKey caseEvidenceTreeKey = new CaseEvidenceTreeKey();

    caseEvidenceTreeKey.caseEvidenceTreeID = details.key.caseEvidenceTreeID;

    getCaseIDForTreeKey.key = caseEvidenceTreeKey;

    final GetCaseIDForTreeResult getCaseIDForTreeResult = caseEvidenceAPIObj.getCaseIDForTree(
      getCaseIDForTreeKey);

    // BEGIN, CR00022728, RR
    if (getCaseIDForTreeResult != null
      && getCaseIDForTreeResult.details != null
      && getCaseIDForTreeResult.details.caseID != 0) {
      // Log Transaction Details
      // BEGIN CR00110570, MR
      // maintainCase manipulation variable to get product name and
      // primary client name
      final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = getCaseIDForTreeResult.details.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);
      // Case Header Manipulation variable to get Case Reference Number
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = getCaseIDForTreeResult.details.caseID;
      // create the description
      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_ACTIVATED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.EVIDENCE_ACTIVATED, description,
        getCaseIDForTreeResult.details.caseID, details.key.caseEvidenceTreeID);
      // END CR00110570
    }
    // END, CR00022728
    // END, CR00045872, AK
  }

  // ___________________________________________________________________________
  /**
   * Suspends an evidence tree.
   *
   * @param details
   * Details to suspend an evidence tree.
   */
  @Override
  public void suspendEvidence(SuspendEvidenceTreeDetails details)
    throws AppException, InformationalException {

    // CaseEvidenceAPI object
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    // Call API method to suspend the evidence tree
    caseEvidenceAPIObj.suspendTree(details);

    // BEGIN, CR00045872, AK
    // Code to fetch the required CaseID
    final GetCaseIDForTreeKey getCaseIDForTreeKey = new GetCaseIDForTreeKey();

    final CaseEvidenceTreeKey caseEvidenceTreeKey = new CaseEvidenceTreeKey();

    caseEvidenceTreeKey.caseEvidenceTreeID = details.key.caseEvidenceTreeID;

    getCaseIDForTreeKey.key = caseEvidenceTreeKey;

    final GetCaseIDForTreeResult getCaseIDForTreeResult = caseEvidenceAPIObj.getCaseIDForTree(
      getCaseIDForTreeKey);

    // BEGIN, CR00022728, RR
    if (getCaseIDForTreeResult != null
      && getCaseIDForTreeResult.details != null
      && getCaseIDForTreeResult.details.caseID != 0) {
      // Log Transaction Details
      // BEGIN CR00110570, MR
      // maintainCase manipulation variable to get product name and
      // primary client name
      final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      final CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = getCaseIDForTreeResult.details.caseID;
      final CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);
      // Case Header Manipulation variable to get Case Reference Number
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = getCaseIDForTreeResult.details.caseID;
      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.EVIDENCE_SUSPENDED).arg(caseReferenceProductNameConcernRoleName.productName).arg(caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference).arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.EVIDENCE_SUSPENDED, description,
        getCaseIDForTreeResult.details.caseID, CuramConst.kDefaultRelatedID);
      // END CR00110570
    }
    // END, CR00022728
    // END, CR00045872, AK
  }

}
