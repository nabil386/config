/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeDetails;
import curam.core.sl.struct.GetLinksAndGroupByTreeAndTypeKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupKey;
import curam.core.sl.struct.GetNearestActiveEvidenceByGroupResult;
import curam.core.struct.ConcernRolePersonKeyStruct;
import curam.core.struct.ProductDeliveryCertDiaryCaseIDKey;
import curam.core.struct.ProductDeliveryCertDiaryDtlsList;
import curam.sample.sl.entity.struct.SimpleProductDtls;
import curam.sample.sl.entity.struct.SimpleProductKey;
import curam.sample.struct.SimpleProductRulesEvidenceDetails;
import curam.sample.struct.SimpleProductRulesEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to get the details of evidences associated with Simple Product Rules
 *
 */
public abstract class RulesSimpleProductEvidence extends curam.sample.base.RulesSimpleProductEvidence {

  // ___________________________________________________________________________
  /**
   * Method to return rules details for Simple Product
   *
   * @param key Contains details to identify evidence to be returned
   *
   * @return Simple Product Evidence for use in rules
   */
  @Override
  public SimpleProductRulesEvidenceDetails getEvidence(
    SimpleProductRulesEvidenceKey key) throws AppException,
      InformationalException {

    // SimpleProductRulesEvidenceDetails manipulation variable
    final SimpleProductRulesEvidenceDetails simpleProductRulesEvidenceDetails = new SimpleProductRulesEvidenceDetails();

    final curam.core.intf.ProductDeliveryCertDiary productDeliveryCertDiaryObj = curam.core.fact.ProductDeliveryCertDiaryFactory.newInstance();
    ProductDeliveryCertDiaryDtlsList productDeliveryCertDiaryDtlsList = new ProductDeliveryCertDiaryDtlsList();
    final ProductDeliveryCertDiaryCaseIDKey productDeliveryCertDiaryCaseIDKey = new ProductDeliveryCertDiaryCaseIDKey();

    final curam.core.intf.MaintainPersonAssistant maintainPersonAssistantObj = curam.core.fact.MaintainPersonAssistantFactory.newInstance();

    // Create and populate the key to read the person's age
    final ConcernRolePersonKeyStruct concernRolePersonKeyStruct = new ConcernRolePersonKeyStruct();

    concernRolePersonKeyStruct.personID = key.personID;
    concernRolePersonKeyStruct.dateOfCalculation = key.dateOfCalculation;

    // Read the person's age
    simpleProductRulesEvidenceDetails.clientAge = maintainPersonAssistantObj.readAgeDetails(concernRolePersonKeyStruct).clientAge;

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    final GetNearestActiveEvidenceByGroupKey getNearestActiveEvidenceByGroupKey = new GetNearestActiveEvidenceByGroupKey();
    GetNearestActiveEvidenceByGroupResult getNearestActiveEvidenceByGroupResult;

    final GetLinksAndGroupByTreeAndTypeKey getLinksAndGroupByTreeAndTypeKey = new GetLinksAndGroupByTreeAndTypeKey();
    GetLinksAndGroupByTreeAndTypeDetails getLinksAndGroupByTreeAndTypeDetails;

    // Set key to get nearest active evidence by group
    getNearestActiveEvidenceByGroupKey.key.caseID = key.caseID;
    getNearestActiveEvidenceByGroupKey.key.effectiveFrom = key.dateOfCalculation;
    getNearestActiveEvidenceByGroupKey.key.evidenceGroupNameCode = curam.codetable.EVIDENCEGROUPNAMECODE.SIMPLEPRODUCT;

    // Get nearest active evidence by group
    getNearestActiveEvidenceByGroupResult = caseEvidenceAPIObj.getNearestActiveEvidenceByGroup(
      getNearestActiveEvidenceByGroupKey);

    // If no evidence is recorded, exit here
    if (getNearestActiveEvidenceByGroupResult.evidenceExistsInd == false) {

      return simpleProductRulesEvidenceDetails;
    }

    // Set key to get links and group by tree and type
    getLinksAndGroupByTreeAndTypeKey.key.caseEvidenceTreeID = getNearestActiveEvidenceByGroupResult.details.caseEvidenceTreeID;
    getLinksAndGroupByTreeAndTypeKey.key.evidenceType = curam.codetable.CASEEVIDENCE.SIMPLEPRODUCT;

    // Get links and group by tree and type
    getLinksAndGroupByTreeAndTypeDetails = caseEvidenceAPIObj.getLinksAndGroupByTreeAndType(
      getLinksAndGroupByTreeAndTypeKey);

    // Check if any links exist; if they don't, exit here
    if (getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.isEmpty()) {

      return simpleProductRulesEvidenceDetails;
    }

    // SimpleProduct manipulation variables
    final curam.sample.sl.entity.intf.SimpleProduct simpleProductObj = curam.sample.sl.entity.fact.SimpleProductFactory.newInstance();
    final SimpleProductKey simpleProductKey = new SimpleProductKey();
    SimpleProductDtls simpleProductDtls;

    // set key to read simpleProduct - the first element in the list is used
    // as we know there can never be more than one on the Simple Product
    simpleProductKey.simpleProductID = getLinksAndGroupByTreeAndTypeDetails.listLinksByTreeAndType.dtls.item(0).relatedID;

    // read simpleProduct entity
    simpleProductDtls = simpleProductObj.read(simpleProductKey);

    // set eligibleInd in return struct
    simpleProductRulesEvidenceDetails.eligibleInd = simpleProductDtls.eligibleInd;
    simpleProductRulesEvidenceDetails.dailyRate = simpleProductDtls.dailyRate;

    simpleProductRulesEvidenceDetails.childIndicator = simpleProductDtls.childIndicator;

    productDeliveryCertDiaryCaseIDKey.caseID = key.caseID;

    productDeliveryCertDiaryDtlsList = productDeliveryCertDiaryObj.searchByCaseID(
      productDeliveryCertDiaryCaseIDKey);

    for (int i = 0; i < productDeliveryCertDiaryDtlsList.dtls.size(); i++) {

      if (!productDeliveryCertDiaryDtlsList.dtls.item(i).periodFromDate.after(
        key.dateOfCalculation)
          && !productDeliveryCertDiaryDtlsList.dtls.item(i).periodToDate.before(
            key.dateOfCalculation)
            && productDeliveryCertDiaryDtlsList.dtls.item(i).statusCode.equals(
              curam.codetable.RECORDSTATUS.NORMAL)) {

        simpleProductRulesEvidenceDetails.certificationFromDate = productDeliveryCertDiaryDtlsList.dtls.item(i).periodFromDate;

        simpleProductRulesEvidenceDetails.certificationToDate = productDeliveryCertDiaryDtlsList.dtls.item(i).periodToDate;
      }
    }

    return simpleProductRulesEvidenceDetails;
  }

}
