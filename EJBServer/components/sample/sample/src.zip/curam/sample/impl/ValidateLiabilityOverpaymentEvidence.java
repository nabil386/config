/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.entity.struct.LiabilityOverpaymentEvidenceDtls;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.sample.struct.ValidateLiabilityOverpaymentEvidenceDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Validation of Liability Overpayment Evidence.
 */
public abstract class ValidateLiabilityOverpaymentEvidence extends curam.sample.base.ValidateLiabilityOverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * Check if the amount is not zero or negative. Or if reassessmentDate is not
   * set properly.
   *
   * @param dtls liabilityOverpayment record to validate
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#validateLiabilityOverpaymentEvidence(LiabilityOverpaymentEvidenceDtls)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Liability Overpayment Evidence entity and associated processing has been
   * moved into core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public void validate(ValidateLiabilityOverpaymentEvidenceDetails dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    final LiabilityOverpaymentEvidenceDtls liabilityOverpaymentEvidenceDtls = new LiabilityOverpaymentEvidenceDtls();

    liabilityOverpaymentEvidenceDtls.caseID = dtls.caseID;
    liabilityOverpaymentEvidenceDtls.fromDate = dtls.fromDate;
    liabilityOverpaymentEvidenceDtls.toDate = dtls.toDate;
    liabilityOverpaymentEvidenceDtls.overpaymentAmount = dtls.overpaymentAmount;
    liabilityOverpaymentEvidenceDtls.reassessmentDate = dtls.reassessmentDate;
    liabilityOverpaymentEvidenceDtls.relatedCaseID = dtls.relatedCaseID;

    ReassessmentProductFactory.newInstance().validateLiabilityOverpaymentEvidence(
      liabilityOverpaymentEvidenceDtls);
    // END, CR00192165
  }

}
