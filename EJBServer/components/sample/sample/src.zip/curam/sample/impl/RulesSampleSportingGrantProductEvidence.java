/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2006,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.codetable.CASEEVIDENCE;
import curam.core.fact.ProductDeliveryCertDiaryFactory;
import curam.core.intf.ProductDeliveryCertDiary;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceInterface;
import curam.core.sl.infrastructure.struct.CalculateDatesDifferenceDetails;
import curam.core.sl.infrastructure.struct.CalculateDatesDifferenceKey;
import curam.core.sl.infrastructure.struct.ECRelatedIDList;
import curam.core.sl.infrastructure.struct.ECRetrieveEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.struct.PersonDtls;
import curam.core.struct.ProductDeliveryCertDiaryCaseIDKey;
import curam.core.struct.ProductDeliveryCertDiaryDtlsList;
import curam.sample.facade.struct.SampleViewSportingActivityDtls;
import curam.sample.facade.struct.SampleViewSportingActivityExpenseDtls;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseDtls;
import curam.sample.sl.entity.struct.SportingSponsorshipDtls;
import curam.sample.struct.SampleSportingGrantProductEvidenceDetails;
import curam.sample.struct.SampleSportingGrantProductEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Money;


/**
 * Code to get the details of evidence associated with Sample Sporting Grant
 * Product Rules
 */
public abstract class RulesSampleSportingGrantProductEvidence extends curam.sample.base.RulesSampleSportingGrantProductEvidence {

  // ___________________________________________________________________________
  /**
   * Method to return rules details for Sample Sporting Grant Product
   *
   * @param key Contains details to identify evidence to be returned
   *
   * @return Sample Sporting Grant Product Evidence for use in rules
   */
  @Override
  public SampleSportingGrantProductEvidenceDetails getEvidence(
    SampleSportingGrantProductEvidenceKey key) throws AppException,
      InformationalException {

    // Create return object
    final SampleSportingGrantProductEvidenceDetails sampleSportingGrantProductEvidenceDetails = new SampleSportingGrantProductEvidenceDetails();

    // EvidenceController business object
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // Read the Sample Sporting Activity evidence
    final ECRetrieveEvidenceKey ecRetrieveEvidenceKey = new ECRetrieveEvidenceKey();

    // variable to sum expense totals
    Money expenseTotal = Money.kZeroMoney;
    Money activityTotal = Money.kZeroMoney;
    Money sponsorshipTotal = Money.kZeroMoney;

    ecRetrieveEvidenceKey.caseID = key.caseID;
    ecRetrieveEvidenceKey.dateOfCalculation = key.dateOfCalculation;
    ecRetrieveEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    ECRelatedIDList ecRelatedIDList = evidenceControllerObj.retrieveEvidence(
      ecRetrieveEvidenceKey);

    // Read the Sporting Activity records for this date.
    for (int i = 0; i < ecRelatedIDList.evidenceDtls.size(); i++) {

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = ecRelatedIDList.evidenceDtls.item(i).relatedID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

      final EIEvidenceReadDtls eiEvidenceReadDtls = evidenceControllerObj.readEvidence(
        eiEvidenceKey);

      final SampleViewSportingActivityDtls sampleViewSportingActivityDtls = new SampleViewSportingActivityDtls();

      sampleViewSportingActivityDtls.assign(
        (SampleSportingActivityDtls) eiEvidenceReadDtls.evidenceObject);

      // Calculate the total Sporting Activity payment amounts for the current
      // day
      activityTotal = new Money(
        activityTotal.getValue()
          + sampleViewSportingActivityDtls.paymentAmount.getValue());

      // BEGIN, CR00102363 ,BD

      // Read all child records of the current Sporting Activity record
      final EIEvidenceKey parentKey = new EIEvidenceKey();

      parentKey.assign(eiEvidenceKey);

      final EIEvidenceKeyList childRecords = ((EvidenceInterface) SampleSportingActivityExpenseFactory.newInstance()).readAllByParentID(
        parentKey);

      // BEGIN, CR00104076 ,BD
      // Read all Sample Sporting Activity Expense evidence active for the
      // current date
      final ECRetrieveEvidenceKey ecRetrieveChildEvidenceKey = new ECRetrieveEvidenceKey();

      ecRetrieveChildEvidenceKey.caseID = key.caseID;
      ecRetrieveChildEvidenceKey.dateOfCalculation = key.dateOfCalculation;
      ecRetrieveChildEvidenceKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

      final ECRelatedIDList ecChildRelatedIDList = evidenceControllerObj.retrieveEvidence(
        ecRetrieveChildEvidenceKey);

      // 2 lists
      // a) List of Expense records of the current Sporting Activity
      // b) List of Expense records that were retrieved as active for the
      // current calculation date
      // Match the evidence ID of records in each loop to find the records to
      // consider...
      for (int j = 0; j < childRecords.dtls.size(); j++) {
        for (int k = 0; k < ecChildRelatedIDList.evidenceDtls.size(); k++) {

          if (childRecords.dtls.item(j).evidenceID
            == ecChildRelatedIDList.evidenceDtls.item(k).relatedID) {

            final EIEvidenceKey sportingActivityExpenseKey = new EIEvidenceKey();

            sportingActivityExpenseKey.evidenceID = childRecords.dtls.item(j).evidenceID;
            sportingActivityExpenseKey.evidenceType = CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE;

            final EIEvidenceReadDtls sportingActivityExpenseDtls = evidenceControllerObj.readEvidence(
              sportingActivityExpenseKey);

            // Filter by date.
            // Only evidence active for the current date should be considered.
            // sportingActivityExpenseDtls.evidenceObject

            final SampleViewSportingActivityExpenseDtls sampleViewSportingActivityExpenseDtls = new SampleViewSportingActivityExpenseDtls();

            sampleViewSportingActivityExpenseDtls.assign(
              (SampleSportingActivityExpenseDtls) sportingActivityExpenseDtls.evidenceObject);

            expenseTotal = new Money(
              expenseTotal.getValue()
                + sampleViewSportingActivityExpenseDtls.amount.getValue());

          }
        }
        // END, CR00104076
      }
    }
    // END, CR00102363

    sampleSportingGrantProductEvidenceDetails.sportingActivityAmount = activityTotal;

    sampleSportingGrantProductEvidenceDetails.sportingActivityExpenseAmount = new Money(
      expenseTotal);

    /**
     * Begin CR00049530 LP
     */
    // Read the Sample Sporting Sponsorship
    ecRetrieveEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    ecRelatedIDList = evidenceControllerObj.retrieveEvidence(
      ecRetrieveEvidenceKey);

    for (int i = 0; i < ecRelatedIDList.evidenceDtls.size(); i++) {

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = ecRelatedIDList.evidenceDtls.item(i).relatedID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

      final EIEvidenceReadDtls eiEvidenceReadDtls = evidenceControllerObj.readEvidence(
        eiEvidenceKey);

      final SportingSponsorshipDtls sportingSponsershipDtls = new SportingSponsorshipDtls();

      sportingSponsershipDtls.assign(
        (SportingSponsorshipDtls) eiEvidenceReadDtls.evidenceObject);

      sponsorshipTotal = new Money(
        sponsorshipTotal.getValue()
          + sportingSponsershipDtls.sponsorshipAmount.getValue());
    }

    sampleSportingGrantProductEvidenceDetails.sportingSponsorshipAmount = new Money(
      sponsorshipTotal);

    /**
     * End CR00049530 LP
     */

    // ProductDeliveryCertDiary entity objects
    final ProductDeliveryCertDiary productDeliveryCertDiaryObj = ProductDeliveryCertDiaryFactory.newInstance();
    ProductDeliveryCertDiaryDtlsList productDeliveryCertDiaryDtlsList = new ProductDeliveryCertDiaryDtlsList();
    final ProductDeliveryCertDiaryCaseIDKey productDeliveryCertDiaryCaseIDKey = new ProductDeliveryCertDiaryCaseIDKey();

    // Search certifications by caseID
    productDeliveryCertDiaryCaseIDKey.caseID = key.caseID;

    productDeliveryCertDiaryDtlsList = productDeliveryCertDiaryObj.searchByCaseID(
      productDeliveryCertDiaryCaseIDKey);

    for (int i = 0; i < productDeliveryCertDiaryDtlsList.dtls.size(); i++) {

      if (!productDeliveryCertDiaryDtlsList.dtls.item(i).periodFromDate.after(
        key.dateOfCalculation)
          && !productDeliveryCertDiaryDtlsList.dtls.item(i).periodToDate.before(
            key.dateOfCalculation)
            && productDeliveryCertDiaryDtlsList.dtls.item(i).statusCode.equals(
              curam.codetable.RECORDSTATUS.NORMAL)) {

        sampleSportingGrantProductEvidenceDetails.certificationFromDate = productDeliveryCertDiaryDtlsList.dtls.item(i).periodFromDate;

        sampleSportingGrantProductEvidenceDetails.certificationToDate = productDeliveryCertDiaryDtlsList.dtls.item(i).periodToDate;
      }
    }

    // BEGIN, CR00067844, SSK

    // Retrieve Person evidence. As this is person evidence only one piece of
    // active evidence will be returned. This evidence will contain the current
    // active age of the person.

    ecRetrieveEvidenceKey.evidenceType = CASEEVIDENCE.PERSON;
    ecRelatedIDList = evidenceControllerObj.retrieveEvidence(
      ecRetrieveEvidenceKey);

    for (int i = 0; i < ecRelatedIDList.evidenceDtls.size(); i++) {

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = ecRelatedIDList.evidenceDtls.item(i).relatedID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.PERSON;

      final EIEvidenceReadDtls eiEvidenceReadDtls = evidenceControllerObj.readEvidence(
        eiEvidenceKey);

      final PersonDtls personDtls = new PersonDtls();

      personDtls.assign((PersonDtls) eiEvidenceReadDtls.evidenceObject);

      // using the person's date of birth calculate their age
      final curam.core.sl.infrastructure.intf.GeneralUtility generalUtilityObj = curam.core.sl.infrastructure.fact.GeneralUtilityFactory.newInstance();

      final CalculateDatesDifferenceKey calculateDatesDifferenceKey = new CalculateDatesDifferenceKey();

      calculateDatesDifferenceKey.fromDate = personDtls.dateOfBirth;
      calculateDatesDifferenceKey.toDate = key.dateOfCalculation;

      final CalculateDatesDifferenceDetails calculateDatesDifferenceDetails = generalUtilityObj.calculateDatesDifference(
        calculateDatesDifferenceKey);

      // Set the age.
      sampleSportingGrantProductEvidenceDetails.clientAge = calculateDatesDifferenceDetails.datesDifference.diffYears;

    }

    // END, CR00067844

    return sampleSportingGrantProductEvidenceDetails;
  }

}
