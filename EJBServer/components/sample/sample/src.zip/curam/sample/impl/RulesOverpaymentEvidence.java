/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.entity.struct.GetBenefitOverpaymentEvidenceResult;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.GetCaseEvidenceResult;
import curam.core.sl.struct.GetEvidenceKey;
import curam.core.sl.struct.GetPersonEvidenceResult;
import curam.core.sl.struct.ReadEvidenceKey;
import curam.sample.struct.OverpaymentCaseEvidenceDetails;
import curam.sample.struct.OverpaymentPersonEvidenceDetails;
import curam.sample.struct.RulesOverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This module contains the access routines (used by the Rules) for the
 * evidence for the overpayment product.
 */
public abstract class RulesOverpaymentEvidence extends curam.sample.base.RulesOverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * This method retrieves person evidence for the Overpayment Product rules.
   *
   * @param key struct containing the caseID, employerID and dateOfCalculation
   *
   * @return clientAge, clientDeceasedInd and clientDateOfBirthVerifiedInd
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#getPersonEvidence(ReadEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity and associated processing has been moved into
   * core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public OverpaymentPersonEvidenceDetails getPersonEvidence(
    RulesOverpaymentEvidenceKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00192165, VM
    // overpaymentPersonEvidenceDetails variable
    final OverpaymentPersonEvidenceDetails details = new OverpaymentPersonEvidenceDetails();

    final ReadEvidenceKey readEvidenceKey = new ReadEvidenceKey();

    readEvidenceKey.concernRoleID = key.concernRoleID;
    readEvidenceKey.dateOfCalculation = key.dateOfCalculation;

    final GetPersonEvidenceResult getPersonEvidenceResult = ReassessmentProductFactory.newInstance().getPersonEvidence(
      readEvidenceKey);

    details.clientDeceasedInd = getPersonEvidenceResult.clientDeceasedInd;
    details.clientAge = getPersonEvidenceResult.clientAge;
    details.clientDateOfBirthVerifiedInd = getPersonEvidenceResult.clientDateOfBirthVerifiedInd;

    return details;
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves case evidence for the Overpayment Product rules.
   *
   * @param key struct containing the caseID, employerID and dateOfCalculation
   *
   * @return caseSuspendedInd, caseClosedInd, productAvailableInd,
   * locationAvailableInd and overpayment amount
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#getCaseEvidence(ReadEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity and associated processing has been moved into
   * core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public OverpaymentCaseEvidenceDetails getCaseEvidence(
    RulesOverpaymentEvidenceKey key) throws AppException,
      InformationalException {

    // overpaymentCaseEvidenceDetails variable
    final OverpaymentCaseEvidenceDetails details = new OverpaymentCaseEvidenceDetails();

    // BEGIN, CR00192165, VM
    final ReadEvidenceKey readEvidenceKey = new ReadEvidenceKey();

    readEvidenceKey.caseID = key.caseID;
    readEvidenceKey.dateOfCalculation = key.dateOfCalculation;

    final GetCaseEvidenceResult getCaseEvidenceResult = ReassessmentProductFactory.newInstance().getCaseEvidence(
      readEvidenceKey);

    final GetEvidenceKey getEvidenceKey = new GetEvidenceKey();

    getEvidenceKey.caseID = key.caseID;

    final GetBenefitOverpaymentEvidenceResult getBenefitOverpaymentEvidenceResult = ReassessmentProductFactory.newInstance().getBenefitOverpaymentEvidence(
      getEvidenceKey);

    details.caseClosedInd = getCaseEvidenceResult.caseClosedInd;
    details.caseSuspendedInd = getCaseEvidenceResult.caseSuspendedInd;
    details.locationAvailableInd = getCaseEvidenceResult.locationAvailableInd;
    details.productAvailableInd = getCaseEvidenceResult.productAvailableInd;
    details.overpaymentAmount = getBenefitOverpaymentEvidenceResult.details.overpaymentAmount;
    // END, CR00192165

    return details;
  }

}
