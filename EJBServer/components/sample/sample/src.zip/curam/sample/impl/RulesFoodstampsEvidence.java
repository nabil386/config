/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.sample.sl.entity.struct.FSNetIncomeDtls;
import curam.sample.sl.entity.struct.FamilySize;
import curam.sample.sl.entity.struct.GrossIncomeDtls;
import curam.sample.struct.FoodstampsHholdEvidenceDtls;
import curam.sample.struct.FoodstampsIncomeLimitDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Rules that govern food stamps assessments
 */
public abstract class RulesFoodstampsEvidence extends curam.sample.base.RulesFoodstampsEvidence {

  // ___________________________________________________________________________
  /**
   * To retrieve the gross and net income limits permitted for food stamps
   * eligibility
   *
   * @param fsHholdEvidenceDtls Food stamps Household Evidence Details
   * (householdSize, memberOver60ind)
   *
   * @return Food stamps Income Limit Dtls Details
   */
  @Override
  public FoodstampsIncomeLimitDtls getIncomeLimit(
    FoodstampsHholdEvidenceDtls fsHholdEvidenceDtls) throws AppException,
      InformationalException {

    // foodstampsIncomeLimitDtls variable
    final FoodstampsIncomeLimitDtls foodstampsIncomeLimitDtls = new FoodstampsIncomeLimitDtls();
    // grossIncome manipulation variables
    final curam.sample.sl.entity.intf.GrossIncome grossIncomeObj = curam.sample.sl.entity.fact.GrossIncomeFactory.newInstance();
    GrossIncomeDtls grossIncomeDtls;

    // netIncome manipulation variables
    final curam.sample.sl.entity.intf.FSNetIncome netIncomeObj = curam.sample.sl.entity.fact.FSNetIncomeFactory.newInstance();
    FSNetIncomeDtls fsNetIncomeDtls;

    // familySize variable
    FamilySize familySize = new FamilySize();

    // used to store amounts calculated
    double grossIncomeLimit = 0;
    double maxNetMonthlyIncome = 0;
    double maxAllotmentBenefit = 0;

    // set fsFamilySize.fsFamilySize
    familySize.familySize = fsHholdEvidenceDtls.numberOfHouseholdMembers;

    try {
      grossIncomeDtls = grossIncomeObj.readByFamilySize(familySize);

    } catch (final curam.util.exception.RecordNotFoundException e) {
      grossIncomeDtls = null;
    }

    if (grossIncomeDtls == null) {

      // get maximum family size
      familySize = grossIncomeObj.readMaximumFamilySize();

      // read grossIncome by familySize
      grossIncomeDtls = grossIncomeObj.readByFamilySize(familySize);

      familySize.familySize = fsHholdEvidenceDtls.numberOfHouseholdMembers
        - familySize.familySize;

      if (fsHholdEvidenceDtls.memberOver60Ind) {

        grossIncomeLimit = familySize.familySize
          * fsHholdEvidenceDtls.additionalNonStdMaxGrossIncomeAmt.getValue();

        grossIncomeLimit += grossIncomeDtls.grossIncomeLimit.getValue()
          * fsHholdEvidenceDtls.elderlyPovertyPercent;

      } else {

        grossIncomeLimit = familySize.familySize
          * fsHholdEvidenceDtls.additionalStdMaxGrossIncomeAmt.getValue();

        grossIncomeLimit += grossIncomeDtls.grossIncomeLimit.getValue()
          * fsHholdEvidenceDtls.standardPovertyPercent;
      }

    } else {

      if (fsHholdEvidenceDtls.memberOver60Ind) {

        grossIncomeLimit += grossIncomeDtls.grossIncomeLimit.getValue()
          * fsHholdEvidenceDtls.elderlyPovertyPercent;

      } else {

        grossIncomeLimit += grossIncomeDtls.grossIncomeLimit.getValue()
          * fsHholdEvidenceDtls.standardPovertyPercent;
      }

    }

    // read netIncome by familySize
    try {

      fsNetIncomeDtls = netIncomeObj.readByFamilySize(familySize);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      fsNetIncomeDtls = null;
    }

    if (fsNetIncomeDtls == null) {

      // get maximum family size
      familySize = netIncomeObj.getMaximumFamilySize();

      // read netIncome by family size
      fsNetIncomeDtls = netIncomeObj.readByFamilySize(familySize);

      familySize.familySize = fsHholdEvidenceDtls.numberOfHouseholdMembers
        - familySize.familySize;

      maxNetMonthlyIncome = fsNetIncomeDtls.maxNetMonthlyIncome.getValue();
      maxNetMonthlyIncome = familySize.familySize * maxNetMonthlyIncome;

      maxAllotmentBenefit = fsNetIncomeDtls.maxAllotmentBenefit.getValue();
      maxAllotmentBenefit = familySize.familySize * maxAllotmentBenefit;

    } else {

      maxNetMonthlyIncome = fsNetIncomeDtls.maxNetMonthlyIncome.getValue();
      maxAllotmentBenefit = fsNetIncomeDtls.maxAllotmentBenefit.getValue();
    }
    foodstampsIncomeLimitDtls.fsGrossIncomeLimit = new curam.util.type.Money(
      grossIncomeLimit);
    foodstampsIncomeLimitDtls.fsNetIncomeLimit = new curam.util.type.Money(
      maxNetMonthlyIncome);
    foodstampsIncomeLimitDtls.allotmentBenefitLimit = new curam.util.type.Money(
      maxAllotmentBenefit);

    return foodstampsIncomeLimitDtls;
  }

}
