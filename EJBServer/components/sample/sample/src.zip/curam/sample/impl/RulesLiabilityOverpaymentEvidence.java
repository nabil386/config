/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.GetCaseEvidenceResult;
import curam.core.sl.struct.GetEvidenceKey;
import curam.core.sl.struct.GetPersonEvidenceResult;
import curam.core.sl.struct.ReadEvidenceKey;
import curam.sample.struct.RulesLiabilityOverpaymentCaseEvidence;
import curam.sample.struct.RulesLiabilityOverpaymentEvidenceKey;
import curam.sample.struct.RulesLiabilityOverpaymentPersonEvidence;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to get the details of evidences associated with a
 * Rules LiabilityOverpayment
 */
public abstract class RulesLiabilityOverpaymentEvidence extends curam.sample.base.RulesLiabilityOverpaymentEvidence {

  // ___________________________________________________________________________
  /**
   * This method retrieves case evidence indicators, determining whether
   * the case is suspended or closed.
   *
   * @param key structure containing relevant case ID, person ID, and date of
   * calculation
   *
   * @return structure used for indicators returned
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#getCaseEvidence(ReadEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Overpayment Evidence entity and associated processing has been moved into
   * core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public RulesLiabilityOverpaymentCaseEvidence getCaseEvidence(
    RulesLiabilityOverpaymentEvidenceKey key) throws AppException,
      InformationalException {

    // rulesLiabilityOverpaymentCaseEvidence variable
    final RulesLiabilityOverpaymentCaseEvidence rulesLiabilityOverpaymentCaseEvidence = new RulesLiabilityOverpaymentCaseEvidence();

    // BEGIN, CR00192165, VM
    final ReadEvidenceKey readEvidenceKey = new ReadEvidenceKey();

    readEvidenceKey.caseID = key.caseID;
    readEvidenceKey.dateOfCalculation = key.dateOfCalculation;

    final GetCaseEvidenceResult getCaseEvidenceResult = ReassessmentProductFactory.newInstance().getCaseEvidence(
      readEvidenceKey);

    final GetEvidenceKey getEvidenceKey = new GetEvidenceKey();

    getEvidenceKey.caseID = key.caseID;

    final curam.core.sl.struct.GetLiabilityOverpaymentEvidenceResult result = ReassessmentProductFactory.newInstance().getLiabilityOverpaymentEvidence(
      getEvidenceKey);

    rulesLiabilityOverpaymentCaseEvidence.caseClosedInd = getCaseEvidenceResult.caseClosedInd;
    rulesLiabilityOverpaymentCaseEvidence.caseSuspendedInd = getCaseEvidenceResult.caseSuspendedInd;
    rulesLiabilityOverpaymentCaseEvidence.locationAvailableInd = getCaseEvidenceResult.locationAvailableInd;
    rulesLiabilityOverpaymentCaseEvidence.productAvailableInd = getCaseEvidenceResult.productAvailableInd;
    rulesLiabilityOverpaymentCaseEvidence.overpaymentAmount = result.details.overpaymentAmount;
    // END, CR00192165

    return rulesLiabilityOverpaymentCaseEvidence;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves person evidences, calculating the age of claimant.
   *
   * @param key structure containing relevant case ID, person ID, and date of
   * calculation
   *
   * @return structure used for returning information about client
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ReassessmentProduct#getPersonEvidence(ReadEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components, the
   * Liability Overpayment Evidence entity and associated processing has been
   * moved into core. See release note CR00192165.
   * </P>
   */
  @Deprecated
  @Override
  public RulesLiabilityOverpaymentPersonEvidence getPersonEvidence(
    RulesLiabilityOverpaymentEvidenceKey key) throws AppException,
      InformationalException {

    // RulesLiabilityOverpaymentPersonEvidence variable
    final RulesLiabilityOverpaymentPersonEvidence rulesLiabilityOverpaymentPersonEvidence = new RulesLiabilityOverpaymentPersonEvidence();

    // BEGIN, CR00192165, VM
    final ReadEvidenceKey readEvidenceKey = new ReadEvidenceKey();

    readEvidenceKey.concernRoleID = key.personID;
    readEvidenceKey.dateOfCalculation = key.dateOfCalculation;

    final GetPersonEvidenceResult getPersonEvidenceResult = ReassessmentProductFactory.newInstance().getPersonEvidence(
      readEvidenceKey);

    rulesLiabilityOverpaymentPersonEvidence.clientDeceasedInd = getPersonEvidenceResult.clientDeceasedInd;
    rulesLiabilityOverpaymentPersonEvidence.clientAge = getPersonEvidenceResult.clientAge;
    rulesLiabilityOverpaymentPersonEvidence.clientDateOfBirthInd = getPersonEvidenceResult.clientDateOfBirthVerifiedInd;
    // END, CR00192165

    return rulesLiabilityOverpaymentPersonEvidence;
  }

}
