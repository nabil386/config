/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012,2018. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.rules.loaders;

import curam.rules.rdo.SimpleProductRulesEvidenceGroup;
import curam.sample.fact.RulesSimpleProductEvidenceFactory;
import curam.sample.struct.SimpleProductRulesEvidenceDetails;
import curam.sample.struct.SimpleProductRulesEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.ItemGroupGlobals;
import java.util.Calendar;

/**
 * This module contains the Simple Product Evidence Loader implementation
 *
 */
public class SimpleProductEvidenceLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp rules parameters
   */
  @Override
  protected void load(final curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    // declare data tree used for rules execution
    final ItemGroupGlobals globals = ItemGroupGlobals.getCurrentInstance(rp);
    final SimpleProductRulesEvidenceGroup rdoSimpleProductRulesEvidence =
      SimpleProductRulesEvidenceGroup.getCurrentInstance(rp);

    // simpleProductRulesEvidence manipulation variables
    final SimpleProductRulesEvidenceKey simpleProductRulesEvidenceKey =
      new SimpleProductRulesEvidenceKey();
    SimpleProductRulesEvidenceDetails simpleProductRulesEvidenceDetails;
    final curam.sample.intf.RulesSimpleProductEvidence rulesSimpleProductEvidenceObj =
      RulesSimpleProductEvidenceFactory.newInstance();

    // RulesSimpleProductEvidenceFactory.newInstance();

    // map in data
    simpleProductRulesEvidenceKey.caseID =
      globals.getClaimReferenceNumber().getValueNoLoad();
    simpleProductRulesEvidenceKey.dateOfCalculation =
      globals.getDateOfCalculation().getValueNoLoad();
    simpleProductRulesEvidenceKey.personID =
      globals.getPersonReferenceNumber().getValueNoLoad();

    final Calendar cal =
      simpleProductRulesEvidenceKey.dateOfCalculation.getCalendar();
    cal.getActualMaximum(Calendar.MONTH);

    // execute
    simpleProductRulesEvidenceDetails = rulesSimpleProductEvidenceObj
      .getEvidence(simpleProductRulesEvidenceKey);

    // map out
    rdoSimpleProductRulesEvidence.getdaysInMonth()
      .setValue(cal.getActualMaximum(Calendar.DAY_OF_MONTH));

    rdoSimpleProductRulesEvidence.geteligibleInd()
      .setValue(simpleProductRulesEvidenceDetails.eligibleInd);

    rdoSimpleProductRulesEvidence.getdailyRate()
      .setValue(simpleProductRulesEvidenceDetails.dailyRate);

    rdoSimpleProductRulesEvidence.getchildIndicator()
      .setValue(simpleProductRulesEvidenceDetails.childIndicator);

    rdoSimpleProductRulesEvidence.getcertificationFromDate()
      .setValue(simpleProductRulesEvidenceDetails.certificationFromDate);

    rdoSimpleProductRulesEvidence.getcertificationToDate()
      .setValue(simpleProductRulesEvidenceDetails.certificationToDate);

    rdoSimpleProductRulesEvidence.getclientAge()
      .setValue(simpleProductRulesEvidenceDetails.clientAge);
  }

}
