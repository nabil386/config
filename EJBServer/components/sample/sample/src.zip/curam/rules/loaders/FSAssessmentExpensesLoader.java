/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.FSAssessmentConstantsGroup;
import curam.rules.rdo.FSAssessmentIncomeEvidenceGroup;
import curam.rules.rdo.FSAssessmentVariablesGroup;
import curam.sample.sl.struct.CalculateIncomeDtls;
import curam.sample.sl.struct.CalculateIncomeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class FSAssessmentExpensesLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp Rules Parameter
   */
  @Override
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    final FSAssessmentConstantsGroup fsAssessmentConstantsGroup = FSAssessmentConstantsGroup.getCurrentInstance(
      rp);

    final FSAssessmentVariablesGroup fsAssessmentVariablesGroup = FSAssessmentVariablesGroup.getCurrentInstance(
      rp);

    final FSAssessmentIncomeEvidenceGroup fsAssessmentIncomeEvidenceGroup = FSAssessmentIncomeEvidenceGroup.getCurrentInstance(
      rp);

    // RulesHealthGrantEvidenceKey variables
    final CalculateIncomeKey calculateIncomeKey = new CalculateIncomeKey();

    // IncomeLimitDetails variable
    CalculateIncomeDtls calculateIncomeDtls;

    // map in
    calculateIncomeKey.earnedIncomePercent = fsAssessmentConstantsGroup.getkFSEarnedIncomePercent().getValueNoLoad();
    calculateIncomeKey.shelterExpenseMaxAmount = fsAssessmentConstantsGroup.getkFSMaxShelterExpense().getValueNoLoad();
    calculateIncomeKey.shelterExpensePercent = fsAssessmentConstantsGroup.getkFSShelterExpensePercent().getValueNoLoad();
    calculateIncomeKey.earnedIncomeTotal = fsAssessmentVariablesGroup.getearnedIncomeTotalAmount().getValueNoLoad();
    calculateIncomeKey.unearnedIncomeTotal = fsAssessmentVariablesGroup.getunearnedIncomeTotalAmount().getValueNoLoad();
    calculateIncomeKey.medicalCostsTotal = fsAssessmentVariablesGroup.getmedicalExpenseTotalAmount().getValueNoLoad();
    calculateIncomeKey.medicalCostsExcessAmount = fsAssessmentConstantsGroup.getkFSMedicalExpenseExcessAmt().getValueNoLoad();
    calculateIncomeKey.shelterExpenseTotal = fsAssessmentVariablesGroup.getshelterExpenseTotalAmount().getValueNoLoad();
    calculateIncomeKey.standardDeductionAmt = fsAssessmentConstantsGroup.getkFSStandardDeduction4().getValueNoLoad();
    calculateIncomeKey.standard5DeductionAmt = fsAssessmentConstantsGroup.getkFSStandardDeduction5().getValueNoLoad();
    calculateIncomeKey.standard6DeductionAmt = fsAssessmentConstantsGroup.getkFSStandardDeduction6().getValueNoLoad();
    calculateIncomeKey.countableMembers = fsAssessmentVariablesGroup.getcountableMembers().getValueNoLoad();

    // execute
    final curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();

    calculateIncomeDtls = incomeScreeningObj.calculateNetIncome(
      calculateIncomeKey);

    // map out
    fsAssessmentIncomeEvidenceGroup.getnetIncomeAmount().setValue(
      calculateIncomeDtls.netIncomeAmount);

  }

}
