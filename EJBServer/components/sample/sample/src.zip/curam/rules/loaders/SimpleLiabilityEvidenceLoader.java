/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.SimpleLiabilityRulesEvidenceGroup;
import curam.sample.struct.SimpleLiabilityRulesEvidenceDetails;
import curam.sample.struct.SimpleLiabilityRulesEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.ItemGroupGlobals;


/**
 * This module contains the Simple Liability Evidence Loader implementation
 *
 */
public class SimpleLiabilityEvidenceLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp Rules parameters
   */
  @Override
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    // declare data tree used for rules execution
    final ItemGroupGlobals globals = ItemGroupGlobals.getCurrentInstance(rp);
    final SimpleLiabilityRulesEvidenceGroup rdoSimpleLiabilityRulesEvidence = SimpleLiabilityRulesEvidenceGroup.getCurrentInstance(
      rp);

    // simpleProductRulesEvidence manipulation variables
    final SimpleLiabilityRulesEvidenceKey simpleLiabilityRulesEvidenceKey = new SimpleLiabilityRulesEvidenceKey();
    SimpleLiabilityRulesEvidenceDetails simpleLiabilityRulesEvidenceDetails;
    final curam.sample.intf.RulesSimpleLiabilityEvidence rulesSimpleLiabilityEvidenceObj = curam.sample.fact.RulesSimpleLiabilityEvidenceFactory.newInstance();

    // map in data
    simpleLiabilityRulesEvidenceKey.caseID = globals.getClaimReferenceNumber().getValueNoLoad();
    simpleLiabilityRulesEvidenceKey.dateOfCalculation = globals.getDateOfCalculation().getValueNoLoad();
    simpleLiabilityRulesEvidenceKey.personID = globals.getPersonReferenceNumber().getValueNoLoad();

    // execute
    simpleLiabilityRulesEvidenceDetails = rulesSimpleLiabilityEvidenceObj.getEvidence(
      simpleLiabilityRulesEvidenceKey);

    // map out
    rdoSimpleLiabilityRulesEvidence.geteligibleInd().setValue(
      simpleLiabilityRulesEvidenceDetails.eligibleInd);

    rdoSimpleLiabilityRulesEvidence.getdailyRate().setValue(
      simpleLiabilityRulesEvidenceDetails.dailyRate);

  }

}
