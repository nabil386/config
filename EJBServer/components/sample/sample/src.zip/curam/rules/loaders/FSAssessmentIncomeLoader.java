/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.FSAssessmentConstantsGroup;
import curam.rules.rdo.FSAssessmentIncomeEvidenceGroup;
import curam.rules.rdo.FSAssessmentVariablesGroup;
import curam.sample.sl.struct.GetIncomeLimitsKey;
import curam.sample.sl.struct.IncomeLimitDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class FSAssessmentIncomeLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp Rules Parameter
   */
  @Override
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    // declare data structures

    final FSAssessmentConstantsGroup fsAssessmentConstantsGroup = FSAssessmentConstantsGroup.getCurrentInstance(
      rp);

    final FSAssessmentVariablesGroup fsAssessmentVariablesGroup = FSAssessmentVariablesGroup.getCurrentInstance(
      rp);

    final FSAssessmentIncomeEvidenceGroup fsAssessmentIncomeEvidenceGroup = FSAssessmentIncomeEvidenceGroup.getCurrentInstance(
      rp);

    // GetIncomeLimitsKey variables
    final GetIncomeLimitsKey getIncomeLimitsKey = new GetIncomeLimitsKey();

    // IncomeLimitDetails variable
    IncomeLimitDetails incomeLimitDetails;

    // map in
    getIncomeLimitsKey.householdSize = fsAssessmentVariablesGroup.getcountableMembers().getValueNoLoad();
    getIncomeLimitsKey.addGrossIncomeLimit = fsAssessmentConstantsGroup.getkFSAdditionalGrossIncomeAmt().getValueNoLoad();
    getIncomeLimitsKey.addNetIncomeLimit = fsAssessmentConstantsGroup.getkFSAdditionalNetIncomeAmt().getValueNoLoad();
    getIncomeLimitsKey.earnedIncomeAmount = fsAssessmentVariablesGroup.getearnedIncomeTotalAmount().getValueNoLoad();
    getIncomeLimitsKey.unearnedIncomeAmount = fsAssessmentVariablesGroup.getunearnedIncomeTotalAmount().getValueNoLoad();

    // execute
    final curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();

    incomeLimitDetails = incomeScreeningObj.getIncomeLimits(getIncomeLimitsKey);

    // map out

    fsAssessmentIncomeEvidenceGroup.getnetIncomeLimit().setValue(
      incomeLimitDetails.netIncomeLimit);
    fsAssessmentIncomeEvidenceGroup.getgrossIncomeLimit().setValue(
      incomeLimitDetails.grossIncomeLimit);
    fsAssessmentIncomeEvidenceGroup.getgrossIncomeAmount().setValue(
      incomeLimitDetails.grossIncomeAmount);

  }

}
