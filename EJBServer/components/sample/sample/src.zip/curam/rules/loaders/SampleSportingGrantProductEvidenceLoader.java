/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.SampleSportingGrantProductRulesEvidenceGroup;
import curam.sample.fact.RulesSampleSportingGrantProductEvidenceFactory;
import curam.sample.intf.RulesSampleSportingGrantProductEvidence;
import curam.sample.struct.SampleSportingGrantProductEvidenceDetails;
import curam.sample.struct.SampleSportingGrantProductEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.ItemGroupGlobals;


/**
 * This module contains the Sample Sporting Grant Loader implementation
 *
 */
public class SampleSportingGrantProductEvidenceLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp rules parameters
   */
  @Override
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    // declare data tree used for rules execution
    final ItemGroupGlobals globals = ItemGroupGlobals.getCurrentInstance(rp);
    final SampleSportingGrantProductRulesEvidenceGroup rdoSampleSportingGrantProductRulesEvidenceGroup = SampleSportingGrantProductRulesEvidenceGroup.getCurrentInstance(
      rp);

    // simpleProductRulesEvidence manipulation variables
    final SampleSportingGrantProductEvidenceKey sampleSportingGrantProductEvidenceKey = new SampleSportingGrantProductEvidenceKey();
    SampleSportingGrantProductEvidenceDetails sampleSportingGrantProductEvidenceDetails;
    final RulesSampleSportingGrantProductEvidence rulesSampleSportingGrantProductEvidenceObj = RulesSampleSportingGrantProductEvidenceFactory.newInstance();

    // map in data
    sampleSportingGrantProductEvidenceKey.caseID = globals.getClaimReferenceNumber().getValueNoLoad();
    sampleSportingGrantProductEvidenceKey.dateOfCalculation = globals.getDateOfCalculation().getValueNoLoad();
    sampleSportingGrantProductEvidenceKey.personID = globals.getPersonReferenceNumber().getValueNoLoad();

    // execute
    sampleSportingGrantProductEvidenceDetails = rulesSampleSportingGrantProductEvidenceObj.getEvidence(
      sampleSportingGrantProductEvidenceKey);

    rdoSampleSportingGrantProductRulesEvidenceGroup.getdailyRate().setValue(
      sampleSportingGrantProductEvidenceDetails.dailyRate);
    rdoSampleSportingGrantProductRulesEvidenceGroup.getcertificationFromDate().setValue(
      sampleSportingGrantProductEvidenceDetails.certificationFromDate);
    rdoSampleSportingGrantProductRulesEvidenceGroup.getcertificationToDate().setValue(
      sampleSportingGrantProductEvidenceDetails.certificationToDate);
    rdoSampleSportingGrantProductRulesEvidenceGroup.getsportingActivityAmount().setValue(
      sampleSportingGrantProductEvidenceDetails.sportingActivityAmount);
    rdoSampleSportingGrantProductRulesEvidenceGroup.getsportingActivityExpenseAmount().setValue(
      sampleSportingGrantProductEvidenceDetails.sportingActivityExpenseAmount);
    rdoSampleSportingGrantProductRulesEvidenceGroup.getvarNetSportingActivityAmount().setValue(
      0);

    // BEGIN, CR00022287, TV
    rdoSampleSportingGrantProductRulesEvidenceGroup.getsportingSponsorshipAmount().setValue(
      sampleSportingGrantProductEvidenceDetails.sportingSponsorshipAmount);
    // END, CR00022287

    // BEGIN, CR00067844, SSK
    rdoSampleSportingGrantProductRulesEvidenceGroup.getclientAge().setValue(
      sampleSportingGrantProductEvidenceDetails.clientAge);
    // END, CR00067844
  }

}
