/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.FSAssessmentVariablesGroup;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This module contains the FS Assessment Variable
 * Loader implementation
 *
 */
public class FSAssessmentVariableLoader extends curam.util.rules.Loader {

  // To initialize variables that are used for calculation within the
  // rules editor
  protected static short countableMembers = 0;

  protected static short nonHouseholdMembers = 0;

  protected static short excludedMembers = 0;

  // ___________________________________________________________________________
  /**
   * Used to initialize all variables that are used for calculation within the
   * rules editor. All these values are set to zero values.
   *
   * @param rp Rules Parameter
   */
  @Override
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    final FSAssessmentVariablesGroup fsAssessmentVariablesGroup = FSAssessmentVariablesGroup.getCurrentInstance(
      rp);

    final curam.util.type.Money resourceTotalAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money unearnedIncomeTotalAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money earnedIncomeTotalAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money shelterExpenseTotalAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money medicalExpenseTotalAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money excludedShelterExpenseAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money excludedEarnedIncomeAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money excludedUnearnedIncomeAmount = curam.util.type.Money.kZeroMoney;
    final curam.util.type.Money excludedMedicalExpenseAmount = curam.util.type.Money.kZeroMoney;

    // map out
    fsAssessmentVariablesGroup.getresourceTotalAmount().setValue(
      resourceTotalAmount);
    fsAssessmentVariablesGroup.getunearnedIncomeTotalAmount().setValue(
      unearnedIncomeTotalAmount);
    fsAssessmentVariablesGroup.getearnedIncomeTotalAmount().setValue(
      earnedIncomeTotalAmount);
    fsAssessmentVariablesGroup.getshelterExpenseTotalAmount().setValue(
      shelterExpenseTotalAmount);
    fsAssessmentVariablesGroup.getmedicalExpenseTotalAmount().setValue(
      medicalExpenseTotalAmount);
    fsAssessmentVariablesGroup.getcountableMembers().setValue(countableMembers);
    fsAssessmentVariablesGroup.getexcludedMembers().setValue(
      nonHouseholdMembers);
    fsAssessmentVariablesGroup.getnonHouseholdMembers().setValue(
      excludedMembers);
    fsAssessmentVariablesGroup.getexcludedShelterExpenses().setValue(
      excludedShelterExpenseAmount);
    fsAssessmentVariablesGroup.getexcludedMedicalExpenses().setValue(
      excludedMedicalExpenseAmount);
    fsAssessmentVariablesGroup.getexcludedEarnedIncome().setValue(
      excludedEarnedIncomeAmount);
    fsAssessmentVariablesGroup.getexcludedUnearnedIncome().setValue(
      excludedUnearnedIncomeAmount);

  }

}
