/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;

import curam.codetable.impl.CREDITDEBITEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.Money;

/**
 * Accessor interface for {@linkplain ObligationHistory}.
 */
public interface ObligationHistoryAccessor extends StandardEntity {

  /**
   * Gets the financial amount associated with the obligation.
   * 
   * @return The financial amount associated with the obligation.
   */
  public Money getAmount();

  /**
   * Gets the indicator if the obligation increases or decreases the fund fiscal
   * year Remaining Budgeted Balance, and the Obligated Total.
   * 
   * @return The indicator if the obligation increases or decreases the fund
   * fiscal year Remaining Budgeted Balance, and the Obligated Total.
   */
  public CREDITDEBITEntry getCreditDebitType();

  /**
   * Gets the immutable obligation for the obligation history.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   * 
   * @return The immutable obligation for the obligation history.
   */
  public ObligationAccessor getObligation();
}
