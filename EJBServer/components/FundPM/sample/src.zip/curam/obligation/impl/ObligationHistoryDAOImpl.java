/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;

import com.google.inject.Singleton;
import curam.fundpm.sl.entity.impl.ObligationHistoryAdapter;
import curam.fundpm.sl.entity.struct.ObligationHistoryDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.Set;

/**
 * Standard implementation of {@linkplain ObligationHistoryDAO}.
 */
@Singleton
public class ObligationHistoryDAOImpl extends
  StandardDAOImpl<ObligationHistory, ObligationHistoryDtls> implements
  ObligationHistoryDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  private static ObligationHistoryAdapter obligationHistoryAdapter =
    new ObligationHistoryAdapter();

  /**
   * Protected constructor of ObligationHistoryDAOImpl.
   */
  protected ObligationHistoryDAOImpl() {

    super(obligationHistoryAdapter, ObligationHistory.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Set<ObligationHistory> searchByObligationID(final long obligationID) {

    return this.newSet(obligationHistoryAdapter
      .searchByObligationID(obligationID));
  }

}
