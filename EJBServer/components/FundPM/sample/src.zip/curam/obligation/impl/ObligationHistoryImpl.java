/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;

import com.google.inject.Inject;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.fundpm.sl.entity.struct.ObligationHistoryDtls;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateRange;
import curam.util.type.Money;

/**
 * Standard implementation of {@linkplain ObligationHistory}.
 * 
 */
public class ObligationHistoryImpl extends
  SingleTableEntityImpl<ObligationHistoryDtls> implements ObligationHistory {

  /**
   * Reference to obligation DAO.
   */
  @Inject
  private ObligationDAO obligationDAO;

  /**
   * Protected constructor of ObligationHistoryImpl.
   */
  protected ObligationHistoryImpl() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Money getAmount() {

    return getDtls().amount;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CREDITDEBITEntry getCreditDebitType() {

    return CREDITDEBITEntry.get(this.getDtls().debitCreditType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateRange getDateRange() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Obligation getObligation() {

    return obligationDAO.get(getDtls().obligationID);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAmount(final Money amount) {

    getDtls().amount = amount;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setCreditDebitType(final CREDITDEBITEntry creditDebitType) {

    this.getDtls().debitCreditType = creditDebitType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateRange(final DateRange dateRange) {

    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setObligation(final Obligation obligation) {

    this.getDtls().obligationID = obligation.getID();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {// No implementation required

  }
}
