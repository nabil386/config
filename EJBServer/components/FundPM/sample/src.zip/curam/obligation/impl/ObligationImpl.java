/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;

import com.google.inject.Inject;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.FUNDEDITEMRULESETTYPEEntry;
import curam.codetable.impl.FUNDFISCALYEARSTATUSEntry;
import curam.codetable.impl.FUNDRELATIONTYPEEntry;
import curam.codetable.impl.OBLIGATIONRELATEDTYPEEntry;
import curam.codetable.impl.OBLIGATIONTRANSACTIONTYPEEntry;
import curam.codetable.impl.WAITLISTENTRYPRIORITYEntry;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.infrastructure.propagator.impl.PropagatorSession;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.struct.ProductDeliveryKey;
import curam.creole.database.fact.CREOLERuleSetFactory;
import curam.creole.database.intf.CREOLERuleSet;
import curam.creole.database.struct.CREOLERuleSetDtls;
import curam.creole.database.struct.CREOLERuleSetKey;
import curam.creole.execution.RuleObject;
import curam.creole.ruleitem.RuleClass;
import curam.creole.ruleitem.RuleSet;
import curam.creole.storage.database.RuleSetManager;
import curam.creole.value.CREOLENumber;
import curam.datastore.entity.struct.DatastoreSchemaKey;
import curam.datastore.facade.fact.DatastoreSchemaFactory;
import curam.datastore.facade.intf.DatastoreSchema;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.EntityType;
import curam.datastore.impl.NoSuchSchemaException;
import curam.fundpm.fundconfiguration.impl.FundConfiguration;
import curam.fundpm.impl.FundFiscalYear;
import curam.fundpm.impl.FundFiscalYearDAO;
import curam.fundpm.impl.FundPMDataStoreRuleObjectCreator;
import curam.fundpm.impl.ProgramFund;
import curam.fundpm.impl.ProgramFundDAO;
import curam.fundpm.sl.entity.fact.FundedItemRulesLinkFactory;
import curam.fundpm.sl.entity.intf.FundedItemRulesLink;
import curam.fundpm.sl.entity.struct.FundedItemRulesLinkDtls;
import curam.fundpm.sl.entity.struct.ObligationDtls;
import curam.fundpm.sl.entity.struct.SearchRulesLinkKey;
import curam.fundpm.util.impl.FundConfigurationDetermination;
import curam.fundpm.util.impl.FundPMConstants;
import curam.fundpm.waitlist.impl.ResourceObject;
import curam.message.FUNDEDITEMRULESET;
import curam.message.impl.FUNDEDITEMRULESETExceptionCreator;
import curam.message.impl.OBLIGATIONExceptionCreator;
import curam.message.impl.WAITLISTExceptionCreator;
import curam.rules.rdo.CaseIDRDOGroup;
import curam.rules.rdo.FundRelationRDOGroup;
import curam.serviceplans.sl.fact.PlannedItemFactory;
import curam.serviceplans.sl.intf.PlannedItem;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.rules.Interrule;
import curam.util.rules.ItemGroup;
import curam.util.rules.ItemGroupGlobals;
import curam.util.rules.RulesEngine;
import curam.util.rules.RulesObjectiveResult;
import curam.util.rules.RulesResult;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;
import curam.waitlist.impl.WaitList;
import curam.waitlist.impl.WaitListDAO;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

/**
 * Standard implementation of {@linkplain Obligation}.
 * 
 */
public class ObligationImpl extends SingleTableEntityImpl<ObligationDtls>
  implements Obligation {

  // BEGIN, CR00199055, AK
  /**
   * Event dispatcher for processObligation events.
   */
  @Inject
  private EventDispatcherFactory<ObligationProcessObligationEvents> processObligationEventDispatcher;

  /**
   * Event dispatcher for createObligation events.
   */
  @Inject
  private EventDispatcherFactory<ObligationCreateObligationEvents> createObligationEventDispatcher;

  /**
   * Event dispatcher for updateObligation events.
   */
  @Inject
  private EventDispatcherFactory<ObligationUpdateObligationEvents> updateObligationEventDispatcher;

  // END, CR00199055

  /**
   * Reference to program fund DAO.
   */
  @Inject
  private ProgramFundDAO programFundDAO;

  /**
   * Reference to fund fiscal year DAO.
   */
  @Inject
  private FundFiscalYearDAO fundFiscalYearDAO;

  /**
   * Reference to wait list DAO.
   */
  @Inject
  private WaitListDAO waitListDAO;

  /**
   * Reference to wait list entry DAO.
   */
  @Inject
  private WaitListEntryDAO waitListEntryDAO;

  /**
   * Reference to obligation DAO.
   */
  @Inject
  private ObligationDAO obligationDAO;

  // BEGIN, CR00197587, AS
  /**
   * Reference to active fund configuration utility class.
   */
  @Inject
  private FundConfigurationDetermination determineFundConfiguration;

  // END, CR00197587

  // BEGIN, CR00199055, AK
  /**
   * Reference to obligation history DAO.
   */
  @Inject
  private ObligationHistoryDAO obligationHistoryDAO;

  // END, CR00199055

  // BEGIN, CR00208753, AK
  /**
   * Reference to Rule Set Manager.
   */
  @Inject
  private RuleSetManager ruleSetManager;

  /**
   * Reference to Propagator Session.
   */
  @Inject
  private PropagatorSession propagatorSession;

  // END, CR00208753

  /**
   * Protected constructor of ObligationImpl.
   */
  protected ObligationImpl() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00188402, AK
  /**
   * Creates the obligation for a fund. System searches for the fund fiscal year
   * for the given fund and the obligation period. Then it creates the
   * obligation for the retrieved fund fiscal year and updates the total
   * obligated amount for the fund fiscal year.
   * 
   * @param programFundID
   * The program fund ID for which the obligation needs to be created.
   * @param requestedAmount
   * The amount requested by user to obligate the fund.
   * @param obligationPeriod
   * The period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * @param caseParticipantRoleID
   * The case participant role ID of the client.
   * @param waitListExpiryDays
   * The expiry days of the wait list.
   * 
   * @return The obligation result which contains the list of obligations or the
   * wait list.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_FUND_CANNOT_BE_OBLIGATED_FUND_FISCAL_YEAR_CLOSED}
   * - If the fund fiscal year is closed.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_CREATED_FFY_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED}
   * - If the fund fiscal year is not having sufficient funds and
   * cannot be over obligated.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ObligationResult createObligation(final Long programFundID,
    final Money requestedAmount, final DateRange obligationPeriod,
    final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final Long caseParticipantRoleID, Integer waitListExpiryDays)
    throws AppException, InformationalException {

    // BEGIN, CR00199055, AK
    createObligationEventDispatcher.get(
      ObligationCreateObligationEvents.class).preCreateObligation(this,
      programFundID, requestedAmount, obligationPeriod, obligationRelatedID,
      obligationRelatedType, caseParticipantRoleID, waitListExpiryDays);
    // END, CR00199055

    validateObligationDetails(requestedAmount, obligationPeriod,
      obligationRelatedID, obligationRelatedType, caseParticipantRoleID);

    // BEGIN, CR00198574, AK
    if (0 == programFundID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_FV_FUND_ID_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    } else {
      try {
        programFundDAO.get(programFundID).getName();
      } catch (final RecordNotFoundException recEx) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().addValidationHelperExceptionWithLookup(
            OBLIGATIONExceptionCreator.ERR_OBLIGATION_FV_INVALID_FUND_ID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            1);
      }
    }
    // END, CR00198574

    ValidationHelper.failIfErrorsExist();

    final Obligation obligation = obligationDAO.newInstance();
    final ObligationResult obligationResult = new ObligationResult();

    final Set<FundFiscalYear> fundFiscalYearList =
      fundFiscalYearDAO.searchByFundIDAndObligationPeriod(programFundID,
        obligationPeriod);

    // BEGIN, CR00198574, AK
    if (0 == fundFiscalYearList.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_DOES_NOT_EXIST_OBLIGATION_CANNOT_BE_CREATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }
    // END, CR00198574

    if (isFundFiscalYearClosed(fundFiscalYearList)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XRV_FUND_CANNOT_BE_OBLIGATED_FUND_FISCAL_YEAR_CLOSED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    // BEGIN, CR00198574, AK
    final Set<Obligation> obligationSet =
      obligationDAO.searchByRelatedIDAndRelatedType(obligationRelatedID,
        obligationRelatedType);

    if (obligationSet.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XRV_OBLIGATION_ALREADY_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00198574

    // If waitListExpiryDays is not entered, then read it from system properties
    if (0 == waitListExpiryDays.intValue()) {
      // BEGIN, CR00205682, AK
      waitListExpiryDays =
        Integer.parseInt(Configuration
          .getProperty(EnvVars.ENV_FUNDPM_WAIT_LIST_EXPIRY_DAYS));
      // END, CR00205682
    }

    // Get the active fund configuration
    final ProgramFund programFund = programFundDAO.get(programFundID);
    final FundConfiguration activeFundConfiguration =
      determineFundConfiguration.determineFundConfiguration(programFund);

    if (1 == fundFiscalYearList.size()) {
      // If obligation request falls within a single FFY
      for (final FundFiscalYear fundFiscalYear : fundFiscalYearList) {
        if (fundFiscalYear.canObligate(requestedAmount)
          || activeFundConfiguration
            .isOverObligationAllowedWhenCreatingObligation()) {
          obligation.setAmount(requestedAmount);
          obligation.setCreditDebitType(CREDITDEBITEntry.DEBIT);
          obligation.setDateRange(obligationPeriod);
          obligation.setRelatedID(obligationRelatedID);
          obligation.setRelatedType(obligationRelatedType);
          obligation
            .setTransactionType(OBLIGATIONTRANSACTIONTYPEEntry.OBLIGATION);
          obligation.setFundFiscalYearID(fundFiscalYear.getID());
          obligation.insert();
          final ArrayList<Obligation> obligations =
            new ArrayList<Obligation>();

          obligations.add(obligation);
          obligationResult.setObligations(obligations);
          // Set the total obligated amount of the fund fiscal year
          final Money existingTotalObligatedAmount =
            fundFiscalYear.getTotalObligatedAmount();
          final Money totalObligatedAmt =
            new Money(existingTotalObligatedAmount.getValue()
              + obligation.getAmount().getValue());

          fundFiscalYear.setTotalObligatedAmount(totalObligatedAmt);
          fundFiscalYear.modify(fundFiscalYear.getVersionNo());
          // BEGIN, CR00196961, AK
        } else if (activeFundConfiguration.isWaitListAllowed()) {
          final List<WaitList> waitLists = new ArrayList<WaitList>();
          final WaitList waitList =
            createWaitListForFundFiscalYear(fundFiscalYear,
              caseParticipantRoleID, waitListExpiryDays);

          waitLists.add(waitList);
          obligationResult.setWaitList(waitList);
          obligationResult.setWaitLists(waitLists);
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .addValidationHelperExceptionWithLookup(
              OBLIGATIONExceptionCreator
                .ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_CREATED_FFY_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
              1);
        }
        // END, CR00196961
      }
    }

    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00199055, AK
    createObligationEventDispatcher.get(
      ObligationCreateObligationEvents.class).postCreateObligation(this,
      programFundID, requestedAmount, obligationPeriod, obligationRelatedID,
      obligationRelatedType, caseParticipantRoleID, waitListExpiryDays,
      obligationResult);
    // END, CR00199055

    return obligationResult;
  }

  // END, CR00188402

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossFieldValidation() {// No validations required.

  }

  /**
   * Processes the obligation for the financial transaction. Retrieves the funds
   * for obligation. It then selects and evaluate each fund from the retrieved
   * funds to check whether the fund can be obligated or not. It then creates
   * the obligation for the selected fund that can be obligated.
   * 
   * @param fundRelatedID
   * The unique reference number of the funded item which caused the
   * obligation to be created, for e.g., Product, Service Offering,
   * etc..
   * @param fundRelatedType
   * The type of the funded item which caused the obligation to be
   * created, for e.g., Product, Service Offering, etc..
   * @param requestedAmount
   * The amount requested by user to obligate the fund.
   * @param obligationPeriod
   * The period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, for e.g., Product
   * Delivery, Planned Item, etc..
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, for e.g., Product Delivery, Planned Item, etc..
   * @param caseParticipantRoleID
   * The case participant role ID of the client.
   * @param waitListExpiryDays
   * The expiry days of the wait list.
   * 
   * @return The obligation result contains the list of obligations, if the
   * obligation process is succeeded or wait list, if the client is wait
   * listed.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ObligationResult processObligation(final Long fundRelatedID,
    final FUNDRELATIONTYPEEntry fundRelatedType, final Money requestedAmount,
    final DateRange obligationPeriod, final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final Long caseParticipantRoleID, Integer waitListExpiryDays)
    throws AppException, InformationalException {

    // BEGIN, CR00199055, AK
    processObligationEventDispatcher.get(
      ObligationProcessObligationEvents.class).preProcessObligation(this,
      fundRelatedID, fundRelatedType, requestedAmount, obligationPeriod,
      obligationRelatedID, obligationRelatedType, caseParticipantRoleID,
      waitListExpiryDays);
    // END, CR00199055

    Long caseID = 0L;

    // BEGIN, CR00188402, AK
    validateObligationDetails(requestedAmount, obligationPeriod,
      obligationRelatedID, obligationRelatedType, caseParticipantRoleID);

    ValidationHelper.failIfErrorsExist();
    // END, CR00188402, AK

    // BEGIN, CR00196961, AK
    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleID;
    caseID =
      caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey).caseID;
    // END, CR00196961

    final Set<Obligation> obligationSet =
      obligationDAO.searchByRelatedIDAndRelatedType(obligationRelatedID,
        obligationRelatedType);

    ObligationResult obligationResult = new ObligationResult();

    // BEGIN, CR00199055, AK
    // Check if there are no existing obligation for the originating case and
    // related type.
    if (obligationSet.size() > 0) {
      obligationResult =
        updateObligation(requestedAmount, obligationPeriod,
          obligationRelatedID, obligationRelatedType);
    } else {
      // END, CR00199055
      final List<ProgramFund> fundList =
        retrieveFundsForObligation(caseID, fundRelatedID, fundRelatedType,
          obligationRelatedID, obligationRelatedType, obligationPeriod);

      // If waitListExpiryDays is not entered, then read it from system
      // properties
      if (0 == waitListExpiryDays.intValue()) {
        // BEGIN, CR00205682, AK
        waitListExpiryDays =
          Integer.parseInt(Configuration
            .getProperty(EnvVars.ENV_FUNDPM_WAIT_LIST_EXPIRY_DAYS));
        // END, CR00205682
      }

      // BEGIN, CR00196961, AK
      final List<WaitList> waitLists = new ArrayList<WaitList>();

      final ProgramFund fund =
        selectAndEvaluateFundForObligation(fundList, requestedAmount,
          obligationPeriod, fundRelatedType, caseParticipantRoleID,
          waitListExpiryDays, waitLists);

      if (null == fund && waitLists.size() > 0) {
        obligationResult.setWaitLists(waitLists);
        return obligationResult;
      }
      // END, CR00196961

      // BEGIN, CR00188402, AK
      obligationResult =
        createObligation(fund.getID(), requestedAmount, obligationPeriod,
          obligationRelatedID, obligationRelatedType, caseParticipantRoleID,
          waitListExpiryDays);

      // END, CR00188402
    }

    // BEGIN, CR00199055, AK
    processObligationEventDispatcher.get(
      ObligationProcessObligationEvents.class).postProcessObligation(this,
      fundRelatedID, fundRelatedType, requestedAmount, obligationPeriod,
      obligationRelatedID, obligationRelatedType, caseParticipantRoleID,
      waitListExpiryDays, obligationResult);
    // END, CR00199055

    return obligationResult;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Money getAmount() {

    return getDtls().amount;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Date getCreationDate() {

    return this.getDtls().creationDate;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CREDITDEBITEntry getCreditDebitType() {

    return CREDITDEBITEntry.get(this.getDtls().debitCreditType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateRange getDateRange() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  // BEGIN, CR00199055, AK
  /**
   * {@inheritDoc}
   */
  @Override
  public FundFiscalYear getFundFiscalYear() {

    return getDtls().fundFiscalYearID != 0 ? fundFiscalYearDAO
      .get(getDtls().fundFiscalYearID) : null;
  }

  // END, CR00199055

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getRelatedID() {

    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OBLIGATIONRELATEDTYPEEntry getRelatedType() {

    return OBLIGATIONRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OBLIGATIONTRANSACTIONTYPEEntry getTransactionType() {

    return OBLIGATIONTRANSACTIONTYPEEntry.get(getDtls().transactionType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setAmount(final Money amount) {

    getDtls().amount = amount;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setCreditDebitType(final CREDITDEBITEntry creditDebitType) {

    this.getDtls().debitCreditType = creditDebitType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateRange(final DateRange dateRange) {

    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setFundFiscalYearID(final Long fundFiscalYearID) {

    getDtls().fundFiscalYearID = fundFiscalYearID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {

    getDtls().creationDate = Date.getCurrentDate();

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedID(final Long relatedID) {

    getDtls().relatedID = relatedID;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setRelatedType(final OBLIGATIONRELATEDTYPEEntry relatedType) {

    getDtls().relatedType = relatedType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setTransactionType(
    final OBLIGATIONTRANSACTIONTYPEEntry transactionType) {

    getDtls().transactionType = transactionType.getCode();
  }

  // BEGIN, CR00199055, AK
  /**
   * Updates the obligation for a fund fiscal year for the given related ID and
   * related type. System searches for the obligation for the given obligation
   * related ID and related type. If the obligation request falls in the same
   * fund fiscal year, then it updates the obligation amount and/or obligation
   * period to the new values supplied by the user. If the obligation request
   * falls in the new fund fiscal year, then it creates a new obligation and
   * updates the total obligated amount for the new fund fiscal year. It then
   * modifies the amount of the previous obligation to zero and subtracts this
   * amount from the total obligated amount of associated fund fiscal year.
   * 
   * @param requestedAmount
   * The amount requested by user to obligate the fund.
   * @param obligationPeriod
   * The period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * 
   * @return The obligation result which contains the list of obligations.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XFV_OBLIGATION_DOES_NOT_EXIST_FOR_RELATED_TYPE}
   * - If the previous obligation does not exist.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_OBLIGATION_ALREADY_EXISTS} -
   * If there is no change in the date range or amount to be updated.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public ObligationResult updateObligation(final Money requestedAmount,
    final DateRange obligationPeriod, final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType)
    throws AppException, InformationalException {

    // BEGIN, CR00199055, AK
    updateObligationEventDispatcher.get(
      ObligationUpdateObligationEvents.class).preUpdateObligation(this,
      requestedAmount, obligationPeriod, obligationRelatedID,
      obligationRelatedType);
    // END, CR00199055

    validateUpdateObligationObligationDetails(requestedAmount,
      obligationPeriod, obligationRelatedID, obligationRelatedType);

    ValidationHelper.failIfErrorsExist();

    final ObligationResult obligationResult = new ObligationResult();
    final ArrayList<Obligation> obligations = new ArrayList<Obligation>();

    final Set<Obligation> obligationSet =
      obligationDAO.searchByRelatedIDAndRelatedType(obligationRelatedID,
        obligationRelatedType);

    if (0 == obligationSet.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_XFV_OBLIGATION_DOES_NOT_EXIST_FOR_RELATED_TYPE(obligationRelatedType
            .getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    } else {
      Obligation oldObligation = obligationDAO.newInstance();
      Obligation newObligation = obligationDAO.newInstance();
      boolean existingObligationInd = false;
      boolean sameObligationInd = false;
      ProgramFund programFund = null;
      FundConfiguration activeFundConfiguration = null;

      // Identify the original and new obligation
      for (final Obligation obligation : obligationSet) {
        final FundFiscalYear fundFiscalYear = obligation.getFundFiscalYear();

        programFund = fundFiscalYear.getFund();
        activeFundConfiguration =
          determineFundConfiguration.determineFundConfiguration(programFund);

        if (obligationPeriod.overlapsWith(fundFiscalYear.getFiscalYear()
          .getDateRange()) && !existingObligationInd) {
          newObligation = obligation;
          existingObligationInd = true;
          if (!obligation.getAmount().isZero()) {
            sameObligationInd = true;
            oldObligation = newObligation;
            break;
          }
        } else if (!obligation.getAmount().isZero()) {
          oldObligation = obligation;
        }
      }

      // Check if the obligation amount and period are same or not as the
      // previous obligation.
      if (sameObligationInd
        && oldObligation.getAmount().equals(requestedAmount)
        && oldObligation.getDateRange().equals(obligationPeriod)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            OBLIGATIONExceptionCreator
              .ERR_OBLIGATION_XRV_OBLIGATION_ALREADY_EXISTS(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            1);
      }

      ValidationHelper.failIfErrorsExist();

      if (existingObligationInd) {
        updateDetailsForExistingObligation(requestedAmount, obligationPeriod,
          obligationResult, obligations, oldObligation, newObligation,
          sameObligationInd, activeFundConfiguration);
      } else {
        updateDetailsForNonExistingObligation(requestedAmount,
          obligationPeriod, obligationRelatedID, obligationRelatedType,
          obligationResult, obligations, oldObligation, programFund,
          activeFundConfiguration);
      }
    }

    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00199055, AK
    updateObligationEventDispatcher.get(
      ObligationUpdateObligationEvents.class).postUpdateObligation(this,
      requestedAmount, obligationPeriod, obligationRelatedID,
      obligationRelatedType, obligationResult);
    // END, CR00199055

    return obligationResult;
  }

  /**
   * Updates the details for the existing obligation.
   * 
   * @param requestedAmount
   * The obligation amount to be updated.
   * @param obligationPeriod
   * The obligation period to be updated.
   * @param obligationResult
   * The obligation result.
   * @param obligations
   * The list of obligations to be returned as part of the result.
   * @param oldObligation
   * The old obligation for which the amount to be removed.
   * @param newObligation
   * The new obligation for which the obligation period is applicable.
   * @param sameObligationInd
   * The indicator indicates whether the update is applicable to the
   * same obligation or the different obligation.
   * @param activeFundConfiguration
   * The active fund configuration of the associated fund of the
   * obligation.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_UPDATED_FUND_FISCAL_YEAR_CLOSED}
   * - If the fund fiscal year is closed.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED_OBLIGATION_CANNOT_BE_UPDATED}
   * - If the fund fiscal year does not have sufficient funds.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void updateDetailsForExistingObligation(
    final Money requestedAmount, final DateRange obligationPeriod,
    final ObligationResult obligationResult,
    final ArrayList<Obligation> obligations, final Obligation oldObligation,
    final Obligation newObligation, final boolean sameObligationInd,
    final FundConfiguration activeFundConfiguration) throws AppException,
    InformationalException {

    final FundFiscalYear newFundFiscalYear =
      newObligation.getFundFiscalYear();

    final Money existingTotalObligatedAmount =
      newFundFiscalYear.getTotalObligatedAmount();

    final Money totalObligatedAmt =
      new Money(existingTotalObligatedAmount.getValue()
        - newObligation.getAmount().getValue() + requestedAmount.getValue());

    if (FUNDFISCALYEARSTATUSEntry.CLOSED.equals(newFundFiscalYear
      .getFundFiscalYearStatus())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_UPDATED_FUND_FISCAL_YEAR_CLOSED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }

    if (totalObligatedAmt.getValue() > newFundFiscalYear
      .getTotalBudgetedAmount().getValue()
      && !activeFundConfiguration
        .isOverObligationAllowedWhenAdjustingObligation()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED_OBLIGATION_CANNOT_BE_UPDATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    ValidationHelper.failIfErrorsExist();

    if (!sameObligationInd && null != oldObligation
      && null != oldObligation.getID()) {
      final FundFiscalYear oldFundFiscalYear =
        oldObligation.getFundFiscalYear();
      final Money totalObligatedAmtForOldFFY =
        new Money(oldFundFiscalYear.getTotalObligatedAmount().getValue()
          - oldObligation.getAmount().getValue());

      oldFundFiscalYear.setTotalObligatedAmount(totalObligatedAmtForOldFFY);
      oldFundFiscalYear.modify(oldFundFiscalYear.getVersionNo());
    }

    newFundFiscalYear.setTotalObligatedAmount(totalObligatedAmt);
    newFundFiscalYear.modify(newFundFiscalYear.getVersionNo());

    // create obligation history before updating the obligation
    if (!oldObligation.getAmount().isZero()) {
      createObligationHistory(oldObligation);
    }

    if (!sameObligationInd && !oldObligation.getAmount().isZero()) {
      oldObligation.setAmount(Money.kZeroMoney);
      oldObligation.modify(oldObligation.getVersionNo());
    }

    if (requestedAmount.compareTo(newObligation.getAmount()) <= 0) {
      newObligation.setCreditDebitType(CREDITDEBITEntry.CREDIT);
    } else {
      newObligation.setCreditDebitType(CREDITDEBITEntry.DEBIT);
    }
    newObligation.setAmount(requestedAmount);
    newObligation.setDateRange(obligationPeriod);
    newObligation.modify(newObligation.getVersionNo());

    obligations.add(newObligation);
    obligationResult.setObligations(obligations);
  }

  /**
   * Updates the details for the non-existing obligation.
   * 
   * @param requestedAmount
   * The obligation amount to be updated.
   * @param obligationPeriod
   * The obligation period to be updated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * @param obligationResult
   * The obligation result.
   * @param obligations
   * The list of obligations to be returned as part of the result.
   * @param oldObligation
   * The old obligation for which the amount to be removed.
   * @param programFund
   * The program fund for which the obligation is to be updated.
   * @param activeFundConfiguration
   * The active fund configuration of the associated fund of the
   * obligation.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_DOES_NOT_EXIST_OBLIGATION_CANNOT_BE_UPDATED}
   * - If the fund fiscal year does not exist for the obligation date.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED_OBLIGATION_CANNOT_BE_UPDATED}
   * - If the fund fiscal year does not have sufficient funds.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_UPDATED_FUND_FISCAL_YEAR_CLOSED}
   * - If the fund fiscal year is closed.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void updateDetailsForNonExistingObligation(
    final Money requestedAmount, final DateRange obligationPeriod,
    final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final ObligationResult obligationResult,
    final ArrayList<Obligation> obligations, final Obligation oldObligation,
    final ProgramFund programFund,
    final FundConfiguration activeFundConfiguration)
    throws InformationalException, AppException {

    final Set<FundFiscalYear> fundFiscalYearList =
      fundFiscalYearDAO.searchByFundIDAndObligationPeriod(
        programFund.getID(), obligationPeriod);

    if (0 == fundFiscalYearList.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_DOES_NOT_EXIST_OBLIGATION_CANNOT_BE_UPDATED(obligationPeriod
            .start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    } else if (1 == fundFiscalYearList.size()) {

      for (final FundFiscalYear newFundFiscalYear : fundFiscalYearList) {
        if (isFundFiscalYearClosed(fundFiscalYearList)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .addValidationHelperExceptionWithLookup(
              OBLIGATIONExceptionCreator
                .ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_UPDATED_FUND_FISCAL_YEAR_CLOSED(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
              0);
        } else if (!newFundFiscalYear.canObligate(requestedAmount)
          && !activeFundConfiguration
            .isOverObligationAllowedWhenAdjustingObligation()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
            .addValidationHelperExceptionWithLookup(
              OBLIGATIONExceptionCreator
                .ERR_OBLIGATION_XRV_FUND_FISCAL_YEAR_HAS_INSUFFICIENT_FUNDS_CANNOT_BE_OVER_OBLIGATED_OBLIGATION_CANNOT_BE_UPDATED(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
              1);
        }

        ValidationHelper.failIfErrorsExist();

        final Money existingTotalObligatedAmount =
          newFundFiscalYear.getTotalObligatedAmount();
        final Money totalObligatedAmt =
          new Money(existingTotalObligatedAmount.getValue()
            + requestedAmount.getValue());

        final Obligation newObligation = obligationDAO.newInstance();

        newObligation.setAmount(requestedAmount);
        newObligation.setCreditDebitType(CREDITDEBITEntry.DEBIT);
        newObligation.setDateRange(obligationPeriod);
        newObligation.setFundFiscalYearID(newFundFiscalYear.getID());
        newObligation.setRelatedID(obligationRelatedID);
        newObligation.setRelatedType(obligationRelatedType);
        newObligation
          .setTransactionType(OBLIGATIONTRANSACTIONTYPEEntry.OBLIGATIONADJUSTMENT);
        newObligation.insert();

        // Update the total obligated amount for the new fund fiscal year
        newFundFiscalYear.setTotalObligatedAmount(totalObligatedAmt);
        newFundFiscalYear.modify(newFundFiscalYear.getVersionNo());

        obligations.add(newObligation);
        obligationResult.setObligations(obligations);
      }

      if (!oldObligation.getAmount().isZero()) {
        // Create obligation history before updating the obligation
        createObligationHistory(oldObligation);

        // Set the total obligated amount for the old fund fiscal year
        final FundFiscalYear oldFundFiscalYear =
          oldObligation.getFundFiscalYear();
        final Money totalObligatedAmtForOldFFY =
          new Money(oldFundFiscalYear.getTotalObligatedAmount().getValue()
            - oldObligation.getAmount().getValue());

        oldFundFiscalYear.setTotalObligatedAmount(totalObligatedAmtForOldFFY);
        oldFundFiscalYear.modify(oldFundFiscalYear.getVersionNo());

        oldObligation.setAmount(Money.kZeroMoney);
        oldObligation.modify(oldObligation.getVersionNo());
      }
    }
  }

  /**
   * Creates the history details for an obligation.
   * 
   * @param Obligation
   * The obligation for which the history details to be created.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void createObligationHistory(final Obligation Obligation)
    throws AppException, InformationalException {

    final ObligationHistory obligationHistory =
      obligationHistoryDAO.newInstance();

    obligationHistory.setObligation(Obligation);
    obligationHistory.setAmount(Obligation.getAmount());
    obligationHistory.setCreditDebitType(Obligation.getCreditDebitType());
    obligationHistory.setDateRange(Obligation.getDateRange());
    obligationHistory.insert();
  }

  // END, CR00199055

  // BEGIN, CR00188402, AK
  /**
   * Validates the obligation details.
   * 
   * @param requestedAmount
   * The amount requested by user to obligate the fund.
   * @param obligationPeriod
   * The period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * @param caseParticipantRoleID
   * The case participant role ID of the client.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_OBLIGATION_RELATED_TYPE_NOT_ENTERED} -
   * If the obligation related type is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_INVALID_CASE_PARTICIPANT_ROLE_ID} - If
   * the case participant role ID is invalid.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_OBLIGATION_RELATED_ID_NOT_ENTERED} - If
   * the obligation related ID is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_START_DATE_NOT_ENTERED} - If
   * the start date is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_CASE_PARTICIPANT_ROLE_ID_NOT_ENTERED} -
   * If the case participant role ID is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_INVALID_OBLIGATION_RELATED_ID} - If the
   * obligation related ID is invalid.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XFV_STARTDATE_SHOULD_NOT_BE_AFTER_ENDDATE}
   * - If the start date entered is after the end date.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_END_DATE_NOT_ENTERED} - If
   * the end date is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_AMOUNT_NOT_GREATER_THAN_ZERO} - If the
   * amount is not greater than zero.
   */
  protected void validateObligationDetails(final Money requestedAmount,
    final DateRange obligationPeriod, final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final Long caseParticipantRoleID) throws AppException,
    InformationalException {

    final CaseParticipantRole caseParticipantRoleObj =
      CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleKey caseParticipantRoleKey =
      new CaseParticipantRoleKey();

    if (Date.kZeroDate.equals(obligationPeriod.start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_START_DATE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }

    if (Date.kZeroDate.equals(obligationPeriod.end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_FV_END_DATE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }

    // BEGIN, CR00198574, AK
    if (obligationPeriod.start().after(obligationPeriod.end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XFV_STARTDATE_SHOULD_NOT_BE_AFTER_ENDDATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }
    // END, CR00198574

    if (0 == obligationRelatedID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_OBLIGATION_RELATED_ID_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    // BEGIN, CR00197894, AK
    if (OBLIGATIONRELATEDTYPEEntry.NOT_SPECIFIED
      .equals(obligationRelatedType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_OBLIGATION_RELATED_TYPE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (0 == caseParticipantRoleID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_CASE_PARTICIPANT_ROLE_ID_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    ValidationHelper.failIfErrorsExist();

    if (requestedAmount.isNegative() || requestedAmount.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_AMOUNT_NOT_GREATER_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    try {
      if (OBLIGATIONRELATEDTYPEEntry.PRODUCTDELIVERY
        .equals(obligationRelatedType)) {
        final ProductDelivery productDeliveryObj =
          ProductDeliveryFactory.newInstance();
        final ProductDeliveryKey productDeliveryKey =
          new ProductDeliveryKey();

        productDeliveryKey.caseID = obligationRelatedID;
        productDeliveryObj.read(productDeliveryKey);
      } else if (OBLIGATIONRELATEDTYPEEntry.PLANNEDITEM
        .equals(obligationRelatedType)) {
        final PlannedItem plannedItem = PlannedItemFactory.newInstance();
        final PlannedItemIDKey plannedItemKey = new PlannedItemIDKey();

        plannedItemKey.plannedItemIDKey.plannedItemID = obligationRelatedID;
        plannedItem.readCaseID(plannedItemKey);
      }
    } catch (final RecordNotFoundException ex) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_INVALID_OBLIGATION_RELATED_ID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleID;
    try {
      caseParticipantRoleObj
        .readCaseIDandParticipantID(caseParticipantRoleKey);
    } catch (final RecordNotFoundException ex) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_INVALID_CASE_PARTICIPANT_ROLE_ID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }
  }

  // END, CR00188402

  // BEGIN, CR00199055, AK
  /**
   * Validates the updated obligation details.
   * 
   * @param requestedAmount
   * The updated amount requested by user to obligate the fund.
   * @param obligationPeriod
   * The updated period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * 
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_OBLIGATION_RELATED_ID_NOT_ENTERED} - If
   * the obligation related ID is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_INVALID_OBLIGATION_RELATED_ID} - If the
   * obligation related ID is invalid.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_XFV_STARTDATE_SHOULD_NOT_BE_AFTER_ENDDATE}
   * - If the start date entered is after the end date.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_START_DATE_NOT_ENTERED} - If
   * the start date is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_OBLIGATION_RELATED_TYPE_NOT_ENTERED} -
   * If the obligation related type is not entered.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_AMOUNT_NOT_GREATER_THAN_OR_EQUAL_TO_ZERO}
   * - If the amount is not greater than or equal to zero.
   * @throws InformationalException
   * {@link OBLIGATION#ERR_OBLIGATION_FV_END_DATE_NOT_ENTERED} - If
   * the end date is not entered.
   */
  protected void validateUpdateObligationObligationDetails(
    final Money requestedAmount, final DateRange obligationPeriod,
    final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType)
    throws AppException, InformationalException {

    if (Date.kZeroDate.equals(obligationPeriod.start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_START_DATE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (Date.kZeroDate.equals(obligationPeriod.end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_FV_END_DATE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (obligationPeriod.start().after(obligationPeriod.end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_XFV_STARTDATE_SHOULD_NOT_BE_AFTER_ENDDATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (0 == obligationRelatedID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_OBLIGATION_RELATED_ID_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }

    if (OBLIGATIONRELATEDTYPEEntry.NOT_SPECIFIED
      .equals(obligationRelatedType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_OBLIGATION_RELATED_TYPE_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }

    ValidationHelper.failIfErrorsExist();

    if (requestedAmount.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_AMOUNT_NOT_GREATER_THAN_OR_EQUAL_TO_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    try {
      if (OBLIGATIONRELATEDTYPEEntry.PRODUCTDELIVERY
        .equals(obligationRelatedType)) {
        final ProductDelivery productDeliveryObj =
          ProductDeliveryFactory.newInstance();
        final ProductDeliveryKey productDeliveryKey =
          new ProductDeliveryKey();

        productDeliveryKey.caseID = obligationRelatedID;
        productDeliveryObj.read(productDeliveryKey);
      } else if (OBLIGATIONRELATEDTYPEEntry.PLANNEDITEM
        .equals(obligationRelatedType)) {
        final PlannedItem plannedItem = PlannedItemFactory.newInstance();
        final PlannedItemIDKey plannedItemKey = new PlannedItemIDKey();

        plannedItemKey.plannedItemIDKey.plannedItemID = obligationRelatedID;
        plannedItem.readCaseID(plannedItemKey);
      }
    } catch (final RecordNotFoundException ex) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator
            .ERR_OBLIGATION_FV_INVALID_OBLIGATION_RELATED_ID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
    }
  }

  // END, CR00199055

  /**
   * This method gets the rule set ID from FundedItemRulesLink.
   * 
   * @param fundRelatedID
   * Unique ID of the fund related item.
   * @param fundRelatedType
   * The type of the fund related item.
   * @param obligationPeriod
   * Period of the obligation.
   * 
   * @return Unique ID of the rule set, empty string if not found.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String getRulesetID(final Long fundRelatedID,
    final FUNDRELATIONTYPEEntry fundRelatedType,
    final DateRange obligationPeriod) throws AppException,
    InformationalException {

    final FundedItemRulesLink fundedItemRulesLinkObj =
      FundedItemRulesLinkFactory.newInstance();
    final SearchRulesLinkKey searchRulesLinkKey = new SearchRulesLinkKey();

    searchRulesLinkKey.relatedID = fundRelatedID;
    searchRulesLinkKey.relatedType = fundRelatedType.getCode();
    searchRulesLinkKey.recordStatus = RECORDSTATUS.NORMAL;
    searchRulesLinkKey.effectiveDate = obligationPeriod.start();

    String ruleSetID = CuramConst.gkEmpty;

    try {
      final FundedItemRulesLinkDtls fundedItemRulesLinkDtls =
        fundedItemRulesLinkObj
          .readByRelatedIDAndRelatedType(searchRulesLinkKey);

      ruleSetID = fundedItemRulesLinkDtls.ruleSetID;

    } catch (final RecordNotFoundException e) {
      return GeneralConstants.kEmpty;
    }

    return ruleSetID;
  }

  // BEGIN, CR00196961, AK
  /**
   * System evaluates if participant is already on the wait list and finds they
   * do not have an entry. System creates wait list entry for participant on
   * fund fiscal year, using the related Fund Fiscal Year ID as the wait list
   * reference ID.
   * 
   * @param fundFiscalYear
   * The fund fiscal year for which the wait list to be created.
   * @param caseParticipantRoleID
   * Contains case participant role id.
   * @param waitListExpiryDays
   * Contains the wait list expiry in days.
   * 
   * @return The wait list object.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link WAITLIST#ERR_WAITLIST_XRV_CLIENT_ALREADY_WAIT_LISTED_FOR_FUND_FISCAL_YEAR_CANNOT_BE_WAIT_LISTED_AGAIN}
   * - If the client is already wait listed for the obligation for the
   * fund fiscal year.
   */
  protected WaitList createWaitListForFundFiscalYear(
    final FundFiscalYear fundFiscalYear, final long caseParticipantRoleID,
    final int waitListExpiryDays) throws AppException, InformationalException {

    WaitList waitListObj = null;

    final long fundFiscalYearID = fundFiscalYear.getID();

    final ProgramFund programFund = fundFiscalYear.getFund();

    // BEGIN, CR00197587, AS
    final FundConfiguration activeFundConfigurationObj =
      determineFundConfiguration.determineFundConfiguration(programFund);

    // END, CR00197587

    if (activeFundConfigurationObj.isWaitListAllowed()) {

      waitListObj = waitListDAO.readByResourceID(fundFiscalYearID);

      // Check if the wait list already exist if not create a new one.
      if (null == waitListObj) {
        waitListObj = waitListDAO.newInstance();

        final ResourceObject resourceObject = new ResourceObject();

        resourceObject.setResourceID(fundFiscalYearID);
        resourceObject.setResourceType(WAITLISTTYPEEntry.FUNDFISCALYEAR);
        waitListObj.setResource(resourceObject);

        waitListObj.insert();
      }

      // If the client is already wait listed for this fund, do not add again.
      final Set<WaitListEntry> waitListEntries =
        waitListEntryDAO.searchByClientResourceAndStatus(fundFiscalYearID,
          caseParticipantRoleID, WAITLISTENTRYSTATUSEntry.OPEN);

      if (0 == waitListEntries.size()) {

        // If expiry days are specified, set the expiration date accordingly.
        Date expirationDate = Date.kZeroDate;

        if (waitListExpiryDays > 0) {
          expirationDate = Date.getCurrentDate().addDays(waitListExpiryDays);
        }

        waitListObj.addEntry(caseParticipantRoleID,
          WAITLISTENTRYPRIORITYEntry.MEDIUM, expirationDate);
      } else if (waitListEntries.size() > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            WAITLISTExceptionCreator
              .ERR_WAITLIST_XRV_CLIENT_ALREADY_WAIT_LISTED_FOR_FUND_FISCAL_YEAR_CANNOT_BE_WAIT_LISTED_AGAIN(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
        ValidationHelper.failIfErrorsExist();
      }
    }

    return waitListObj;
  }

  // END, CR00196961

  /**
   * Runs the fund selection rule set to identify potential funds for the
   * obligation. If the type of rule set is classic, then the frequency pattern
   * for the rule set is selected by default as daily.
   * 
   * @param caseID
   * The unique identifier of the case.
   * @param fundRelatedID
   * The unique reference number of the funded item which caused the
   * obligation to be created, for e.g., Product, Service Offering,
   * etc..
   * @param fundRelationType
   * The type of the funded item which caused the obligation to be
   * created, for e.g., Product, Service Offering, etc..
   * @param obligationRelatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param relatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * @param obligationPeriod
   * Period of the obligation.
   * 
   * @return List of funds that matches the input criteria.
   * 
   * @throws InformationalException
   * {@link curam.message.OBLIGATION#ERR_OBLIGATION_XRV_NO_RULESET_DEFINED} - If
   * the system does not find rules for specified Service or
   * Product.
   * @throws InformationalException
   * {@link curam.message.OBLIGATION#ERR_OBLIGATION_XRV_NO_FUNDS_AVAILABLE_FOR_FUND_RELATED_TYPE_FOR_PERIOD}
   * - If there are no fund fiscal years available for the Product or
   * Service.
   * @throws InformationalException
   * {@link curam.message.OBLIGATION#ERR_FUNDEDITEMRULESET_XRV_NO_SUCH_SCHEMA_EXCEPTION}
   * - If there is no data store schema specified for the CER rule set
   * type.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<ProgramFund> retrieveFundsForObligation(final Long caseID,
    final Long fundRelatedID, final FUNDRELATIONTYPEEntry fundRelationType,
    final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry relatedType,
    final DateRange obligationPeriod) throws AppException,
    InformationalException {

    // BEGIN, CR00208753, AK
    final FundedItemRulesLink fundedItemRulesLinkObj =
      FundedItemRulesLinkFactory.newInstance();
    final SearchRulesLinkKey searchRulesLinkKey = new SearchRulesLinkKey();
    FUNDEDITEMRULESETTYPEEntry ruleSetType = null;
    FundedItemRulesLinkDtls fundedItemRulesLinkDtls =
      new FundedItemRulesLinkDtls();
    long creoleRuleSetID;
    String dataStoreSchema;
    final List<ProgramFund> fundList = new ArrayList<ProgramFund>();

    searchRulesLinkKey.relatedID = fundRelatedID;
    searchRulesLinkKey.relatedType = fundRelationType.getCode();
    searchRulesLinkKey.recordStatus = RECORDSTATUS.NORMAL;
    searchRulesLinkKey.effectiveDate = obligationPeriod.start();

    try {
      fundedItemRulesLinkDtls =
        fundedItemRulesLinkObj
          .readByRelatedIDAndRelatedType(searchRulesLinkKey);
    } catch (final RecordNotFoundException recEx) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_NO_RULESET_DEFINED(fundRelationType
            .getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }
    ruleSetType =
      FUNDEDITEMRULESETTYPEEntry.get(fundedItemRulesLinkDtls.ruleSetType);

    if (FUNDEDITEMRULESETTYPEEntry.CERRULESET.equals(ruleSetType)) {
      creoleRuleSetID = fundedItemRulesLinkDtls.creoleRuleSetID;

      // If there are no rules associated to the service or product.
      if (0 == creoleRuleSetID) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_NO_RULESET_DEFINED(fundRelationType
              .getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            2);
        ValidationHelper.failIfErrorsExist();
      }

      dataStoreSchema = fundedItemRulesLinkDtls.dataStoreSchema;

      Datastore datastore = null;

      try {
        datastore =
          DatastoreFactory.newInstance().openDatastore(dataStoreSchema);
      } catch (final NoSuchSchemaException e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            FUNDEDITEMRULESETExceptionCreator
              .ERR_FUNDEDITEMRULESET_XRV_NO_SUCH_SCHEMA_EXCEPTION(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }

      final DatastoreSchema ds = DatastoreSchemaFactory.newInstance();
      final DatastoreSchemaKey datastoreSchemaKey = new DatastoreSchemaKey();

      datastoreSchemaKey.schemaName = dataStoreSchema;

      final String schemaText = ds.viewSchema(datastoreSchemaKey).schemaText;

      // parse schema text to get attributes and set the values to those
      // attributes..
      final Map<String, String> fundRuleSetXSDVal = parseXSD(schemaText);

      final String rootEntityType = getRootEntity(fundRuleSetXSDVal);

      final EntityType fundRuleSetType =
        datastore.getEntityType(rootEntityType);
      final Entity rootEntity = datastore.newEntity(fundRuleSetType);

      rootEntity.setTypedAttribute(FundPMConstants.kRelatedID, fundRelatedID);
      rootEntity.setTypedAttribute(FundPMConstants.kEffectiveDate,
        obligationPeriod.start());
      rootEntity.setTypedAttribute(FundPMConstants.kRecordStatus,
        RECORDSTATUS.NORMAL);

      datastore.addRootEntity(rootEntity);

      final CREOLERuleSet creoleRuleSet = CREOLERuleSetFactory.newInstance();
      final CREOLERuleSetKey creoleRuleSetKey = new CREOLERuleSetKey();

      creoleRuleSetKey.creoleRuleSetID = creoleRuleSetID;
      CREOLERuleSetDtls creoleRuleSetDtls = new CREOLERuleSetDtls();

      creoleRuleSetDtls = creoleRuleSet.read(creoleRuleSetKey);
      final RuleSet ruleSet =
        ruleSetManager.readRuleSet(creoleRuleSetDtls.name);

      final RuleClass ruleClass =
        ruleSet.findClass(FundPMConstants.kFundAssociation);

      if (!FundPMConstants.kFundAssociation.equals(rootEntityType)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            FUNDEDITEMRULESETExceptionCreator
              .ERR_FUNDEDITEMRULESET_XRV_RULESCLASSNAME_NOTEQUAL_TO_ENTITYCLASSNAME(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }

      final FundPMDataStoreRuleObjectCreator dataStoreRuleObjectCreator =
        new FundPMDataStoreRuleObjectCreator();

      dataStoreRuleObjectCreator.createRuleObjects(
        propagatorSession.getSession(), ruleSet, rootEntity);

      final Set<? extends RuleObject> ruleObjects =
        propagatorSession.getSession().readAllRuleObjects(ruleClass);

      final Iterator<? extends RuleObject> iterator = ruleObjects.iterator();
      List<CREOLENumber> programFundIDList = new ArrayList<CREOLENumber>();

      while (iterator.hasNext()) {
        final RuleObject ruleObject = iterator.next();
        final RuleClass ruleClassObject = ruleObject.getRuleClass();

        if (ruleClass.equals(ruleClassObject)) {
          programFundIDList =
            (List<CREOLENumber>) ruleObject.getAttributeValue(
              FundPMConstants.kProgramFundIDList).getValue();
          break;
        }
      }
      final Iterator<CREOLENumber> fundIDIterator =
        programFundIDList.iterator();

      while (fundIDIterator.hasNext()) {
        final long programFundID = fundIDIterator.next().longValue();

        fundList.add(programFundDAO.get(programFundID));
      }
    } else {
      // END, CR00208753
      final String ruleSetID =
        getRulesetID(fundRelatedID, fundRelationType, obligationPeriod);

      // If there are no rules associated to the service or product.
      if (StringUtil.isNullOrEmpty(ruleSetID)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_NO_RULESET_DEFINED(fundRelationType
              .getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            1);
        ValidationHelper.failIfErrorsExist();
      }

      // Invoke the identified funding rule set to get the list of potential
      // funds.
      final java.util.List<ItemGroup> itemList = new ArrayList<ItemGroup>();
      final CaseIDRDOGroup caseIDRDOGroup = new CaseIDRDOGroup();

      caseIDRDOGroup.getcaseID().setValue(caseID);
      itemList.add(caseIDRDOGroup);

      final ItemGroupGlobals globals = new ItemGroupGlobals();

      globals.dateOfCalculation.setValue(Date.getCurrentDate());
      globals.deliveryFrequency.setValue(FrequencyPattern.kDailyPattern);
      itemList.add(globals);

      final FundRelationRDOGroup fundRelationRDOGroup =
        new FundRelationRDOGroup();

      fundRelationRDOGroup.getfundRelatedID().setValue(fundRelatedID);
      fundRelationRDOGroup.getfundRelatedType().setValue(
        fundRelationType.getCode());
      itemList.add(fundRelationRDOGroup);

      final RulesResult rulesResult =
        Interrule.executeDynamicRules(ruleSetID, null, RulesEngine.kNormal,
          itemList);
      final List rulesObjectiveResultList =
        rulesResult.getRulesObjectiveResultList();

      if (null != rulesObjectiveResultList) {
        for (int i = 0; i < rulesObjectiveResultList.size(); i++) {
          final long fundID =
            ((RulesObjectiveResult) rulesObjectiveResultList.get(i))
              .getTargetID();

          fundList.add(programFundDAO.get(fundID));
        }
      }
    }
    if (fundList.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_NO_FUNDS_AVAILABLE_FOR_FUND_RELATED_TYPE_FOR_PERIOD(fundRelationType
            .getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }
    return fundList;
  }

  // END, CR00208753

  /**
   * Checks whether any of the fund fiscal years is closed or not.
   * 
   * @param fundFiscalYearList
   * The list of fund fiscal years.
   * 
   * @return The boolean value true if any of the fund fiscal years is closed.
   */
  protected boolean isFundFiscalYearClosed(
    final Set<FundFiscalYear> fundFiscalYearList) {

    if (0 == fundFiscalYearList.size()) {
      return false;
    }

    for (final FundFiscalYear fundFiscalYear : fundFiscalYearList) {
      // BEGIN, CR00197894, AK
      if (FUNDFISCALYEARSTATUSEntry.CLOSED.equals(fundFiscalYear
        .getFundFiscalYearStatus())) {
        // END, CR00197894
        return true;
      }
    }
    return false;
  }

  /**
   * Selects and evaluates the fund for obligation.
   * 
   * @param funds
   * The list of program funds.
   * @param requestedAmount
   * The requested amount.
   * @param obligationPeriod
   * The obligation period.
   * @param fundRelatedType
   * The fund related type.
   * @param caseParticipantRoleID
   * Contains case participant role id.
   * @param waitListExpiryDays
   * Contains the wait list expiry in days.
   * @param waitLists
   * List of wait list objects.
   * 
   * @return The selected program fund for obligation.
   * 
   * @throws InformationalException
   * {@link OBLIGATIONExceptionCreator#ERR_OBLIGATION_XRV_NO_FUNDS_AVAILABLE_FOR_FUND_RELATED_TYPE}
   * - If there are no funds available for the fund related type.
   * @throws InformationalException
   * {@link OBLIGATIONExceptionCreator#ERR_OBLIGATION_XRV_OBLIGATION_CANNOT_BE_CREATED_FFY_HAS_INSUFFICIENT_FUNDS}
   * - If there are no funds available for the fund related type.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProgramFund selectAndEvaluateFundForObligation(
    final List<ProgramFund> funds, final Money requestedAmount,
    final DateRange obligationPeriod,
    final FUNDRELATIONTYPEEntry fundRelatedType,
    final long caseParticipantRoleID, final int waitListExpiryDays,
    final List<WaitList> waitLists) throws AppException,
    InformationalException {

    final ProgramFund selectedFund = null;
    Set<FundFiscalYear> fundFiscalYearList = null;
    // BEGIN, CR00196961, AK
    final List<FundFiscalYear> fundFiscalYearsForWaitListing =
      new ArrayList<FundFiscalYear>();
    boolean isFFYAvailableForWaitListing = false;

    for (final ProgramFund fund : funds) {
      // check if the fund can be obligated or not
      fundFiscalYearList =
        fundFiscalYearDAO.searchByFundIDAndObligationPeriod(fund.getID(),
          obligationPeriod);

      if (null != fundFiscalYearList && fundFiscalYearList.size() > 0) {
        if (!isFundFiscalYearClosed(fundFiscalYearList)) {
          // Get the active fund configuration
          // BEGIN, CR00197587, AS
          final FundConfiguration activeFundConfigurationObj =
            determineFundConfiguration.determineFundConfiguration(fund);

          // END, CR00197587
          if (1 == fundFiscalYearList.size()) {
            for (final FundFiscalYear fundFiscalYear : fundFiscalYearList) {
              if (fundFiscalYear.canObligate(requestedAmount)
                || activeFundConfigurationObj
                  .isOverObligationAllowedWhenCreatingObligation()) {
                return fund;
              } else if (activeFundConfigurationObj.isWaitListAllowed()) {
                isFFYAvailableForWaitListing = true;
                fundFiscalYearsForWaitListing.add(fundFiscalYear);
              }
            }
          }
        }
      }
    }

    if (fundFiscalYearsForWaitListing.size() > 0) {
      for (final FundFiscalYear fundFiscalYear : fundFiscalYearsForWaitListing) {
        final WaitList waitList =
          createWaitListForFundFiscalYear(fundFiscalYear,
            caseParticipantRoleID, waitListExpiryDays);

        waitLists.add(waitList);
      }
    }
    // END, CR00196961

    if (null == selectedFund && !isFFYAvailableForWaitListing) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          OBLIGATIONExceptionCreator.ERR_OBLIGATION_XRV_NO_FUNDS_AVAILABLE_FOR_FUND_RELATED_TYPE(fundRelatedType
            .getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }

    return selectedFund;
  }

  // BEGIN, CR00208753, AK
  /**
   * Accepts the fund rule set xsd stored in data store and parses the xsd to
   * return the attribute values as a Map object.
   * 
   * @param schemaText
   * The XSD for fund rule set xml.
   * 
   * @return The parsed XML in string format.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ESTIMATEDCOST#ERR_ESTIMATEDCOST_JDOM_EXCEPTION} - If JDOM
   * exception occurs.
   * @throws InformationalException
   * {@link ESTIMATEDCOST#ERR_ESTIMATEDCOST_IO_EXCEPTION} - If IO
   * exception occurs.
   */
  private Map<String, String> parseXSD(final String schemaText)
    throws AppException, InformationalException {

    final Map<String, String> fundRuleSetAttributes =
      new HashMap<String, String>();

    try {
      final SAXBuilder saxBuilder = new SAXBuilder();
      final Document document =
        saxBuilder.build(new ByteArrayInputStream(schemaText.getBytes()));
      final Element root = document.getRootElement();
      final List<?> elementTagList =
        XPath.selectNodes(root, FundPMConstants.escapeCharacter
          + FundPMConstants.xsdElement);

      for (int i = 0; i < elementTagList.size(); i++) {
        final Element elementVal = (Element) elementTagList.get(i);
        final String name =
          elementVal.getAttribute(FundPMConstants.name).getValue();

        fundRuleSetAttributes.put(name, null);
      }
    } catch (final JDOMException jde) {
      final AppException jdomException =
        new AppException(
          FUNDEDITEMRULESET.ERR_FUNDEDITEMRULESET_JDOM_EXCEPTION, jde);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(jdomException,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    } catch (final IOException ioe) {
      final AppException ioException =
        new AppException(
          FUNDEDITEMRULESET.ERR_FUNDEDITEMRULESET_IO_EXCEPTION, ioe);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(ioException,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }
    return fundRuleSetAttributes;
  }

  /**
   * Returns the rootEntity name from the data store schemaText.
   * 
   * @param fundRuleSetXSDVal
   * Contains the fund rule set XSD values as a Collection Object.
   * 
   * @return The root entity name.
   * 
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  private String getRootEntity(final Map<String, String> fundRuleSetXSDVal)
    throws AppException, InformationalException {

    String rootEntityVal = null;
    final Set<Entry<String, String>> rootEntityValues =
      fundRuleSetXSDVal.entrySet();
    final Iterator<Entry<String, String>> rootEntityIterator =
      rootEntityValues.iterator();

    while (rootEntityIterator.hasNext()) {
      final Map.Entry<String, String> anEntry = rootEntityIterator.next();

      rootEntityVal = anEntry.getKey();
    }
    return rootEntityVal;
  }
  // END, CR00208753
}
