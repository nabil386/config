/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.fundfiscalyearlineitem.impl;

import com.google.inject.Inject;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.FUNDFISCALYEARLINEITEMTYPEEntry;
import curam.fundpm.impl.BudgetAdjustment;
import curam.fundpm.impl.BudgetAdjustmentDAO;
import curam.fundpm.impl.FundFiscalYear;
import curam.fundpm.impl.FundFiscalYearDAO;
import curam.fundpm.sl.entity.struct.FundFclYrLineItemDtls;
import curam.fundpm.util.impl.FundFiscalYearLineItemRefNum;
import curam.fundpm.util.impl.FundPMConstants;
import curam.message.impl.FUNDFISCALYEARLINEITEMExceptionCreator;
import curam.obligation.impl.Obligation;
import curam.obligation.impl.ObligationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateRange;
import curam.util.type.Money;
import java.util.List;

/**
 * Standard implementation of {@linkplain FundFiscalYearLineItem}.
 */
public class FundFiscalYearLineItemImpl extends
  SingleTableLogicallyDeleteableEntityImpl<FundFclYrLineItemDtls> implements
  FundFiscalYearLineItem {

  // BEGIN, CR00187494, AS
  /**
   * Reference to fund fiscal year line item.
   */
  @Inject
  private FundFiscalYearLineItem fundFiscalYearLineItem;

  // END, CR00187494

  /**
   * Reference to fund fiscal year DAO.
   */
  @Inject
  private FundFiscalYearDAO fundFiscalYearDAO;

  // BEGIN, CR00188291, AS
  /**
   * Reference to obligation DAO.
   */
  @Inject
  private ObligationDAO obligationDAO;

  // END, CR00188291

  /**
   * Reference to budget adjustment DAO.
   */
  @Inject
  private BudgetAdjustmentDAO budgetAdjustmentDAO;

  /**
   * Reference to reference number utility class.
   */
  @Inject
  private FundFiscalYearLineItemRefNum fiscalYearLineItemRefNum;

  /**
   * Constructor for the class.
   */
  protected FundFiscalYearLineItemImpl() {// Protected no-arg constructor for
                                          // use only by Guice

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setBudgetAllocatedTotal(final Money bugetAllocatedTotal) {

    // END, CR00199742
    getDtls().budgetAllocatedTotal = bugetAllocatedTotal;

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setPaymentTotal(final Money paymentTotal) {

    // END, CR00199742
    getDtls().paymentTotal = paymentTotal;

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setType(
    final FUNDFISCALYEARLINEITEMTYPEEntry fundFiscalYearLineItemType) {

    // END, CR00199742
    getDtls().type = fundFiscalYearLineItemType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Money getBudgetAllocatedTotal() {

    return getDtls().budgetAllocatedTotal;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getLineItemReferenceNumber() {

    return getDtls().lineItemRefNo;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Money getPaymentTotal() {

    return getDtls().paymentTotal;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public FUNDFISCALYEARLINEITEMTYPEEntry getType() {

    return FUNDFISCALYEARLINEITEMTYPEEntry.get(getDtls().type);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateRange getDateRange() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * Validates that changes made to fund fiscal year line item entity on the
   * database are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_STARTDATE_BEFORE_FUND_STARTDATE}
   * - If the fund fiscal year line item start date is before the start date of
   * the fund.</li>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_ENDDATE_AFTER_FUND_ENDDATE}
   * - If the fund fiscal year line item end date is after the end date of the
   * fund.</li>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_STARTDATE_BEFORE_FISCALYEAR_STARTDATE}
   * - If the fund fiscal year line item start date is before the start date of
   * the fiscal year.</li>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_ENDDATE_AFTER_FISCALYEAR_ENDDATE}
   * - If the fund fiscal year line item end date is after the end date of the
   * fiscal year.</li>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_FV_BUDGETALLOCALTEDAMOUNT_LESS_THAN_ZERO}
   * - If the budget allocated amount is less than zero.</li>
   * </ul>
   */
  @Override
  public void crossEntityValidation() {

    if (getDateRange().start().before(
      getFundFiscalYear().getFund().getDateRange().start())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_STARTDATE_BEFORE_FUND_STARTDATE(
            getDateRange().start(), getFundFiscalYear().getFund()
              .getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (!getFundFiscalYear().getFund().getDateRange().end().isZero()
      && getDateRange().end().after(
        getFundFiscalYear().getFund().getDateRange().end())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_ENDDATE_AFTER_FUND_ENDDATE(
            getDateRange().end(), getFundFiscalYear().getFund()
              .getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (getDateRange().start().before(
      getFundFiscalYear().getFiscalYear().getDateRange().start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_STARTDATE_BEFORE_FISCALYEAR_STARTDATE(
            getDateRange().start(), getFundFiscalYear().getFiscalYear()
              .getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (getDateRange().end().after(
      getFundFiscalYear().getFiscalYear().getDateRange().end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_ENDDATE_AFTER_FISCALYEAR_ENDDATE(
            getDateRange().end(), getFundFiscalYear().getFiscalYear()
              .getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

    if (getBudgetAllocatedTotal().isNegative()
      && !getBudgetAllocatedTotal().equals(
        FundPMConstants.kMoneySentinelValue)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator
            .ERR_FUNDFISCALYEARLINEITEM_FV_BUDGETALLOCALTEDAMOUNT_LESS_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XFV_STARTDATE_AFTER_ENDDATE}
   * -If the start date is after the end date.</li>
   * </ul>
   */
  @Override
  public void crossFieldValidation() {

    if (!getDateRange().end().isZero()
      && getDateRange().startsAfter(getDateRange().end())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator
            .ERR_FUNDFISCALYEARLINEITEM_XFV_STARTDATE_AFTER_ENDDATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);

    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void mandatoryFieldValidation() {// No validations required.

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setFundFiscalYear(final FundFiscalYear fundFiscalYear) {

    // END, CR00199742
    getDtls().fundFiscalYearID = fundFiscalYear.getID();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public FundFiscalYear getFundFiscalYear() {

    return fundFiscalYearDAO.get(getDtls().fundFiscalYearID);
  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setDateRange(final DateRange dateRange) {

    // END, CR00199742
    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getComments() {

    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  @Override
  public void setComments(final String comments) {

    // END, CR00199742
    getDtls().comments = comments;
  }

  // BEGIN, CR00176297, ABS
  /**
   * {@inheritDoc}
   */
  @Override
  public Money getAllocatedTotal() {

    final List<curam.fundpm.impl.BudgetAdjustment> budgetAdjustmentList =
      budgetAdjustmentDAO.listBudgetAdjustmentForRelatedID(getID());

    Money allocatedTotal = Money.kZeroMoney;

    for (final curam.fundpm.impl.BudgetAdjustment budgetAdjustmentObj : budgetAdjustmentList) {

      // Add the amount to the allocated total if the type is credit, otherwise
      // subtract it.
      // BEGIN, CR00199595, AK
      if (CREDITDEBITEntry.CREDIT.equals(budgetAdjustmentObj
        .getCreditDebitType())) {
        // END, CR00199595
        allocatedTotal =
          new Money(allocatedTotal.getValue()
            + budgetAdjustmentObj.getAmount().getValue());
      } else {
        allocatedTotal =
          new Money(allocatedTotal.getValue()
            - budgetAdjustmentObj.getAmount().getValue());
      }
    }
    return allocatedTotal;
  }

  /**
   * Sets the fund fiscal year line item reference number and inserts a fund
   * fiscal year line item record into database.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void insert() throws InformationalException {

    setLineItemReferenceNumber();
    super.insert();
  }

  // END, CR00176297

  /**
   * Cancels a fund fiscal year line item.
   * 
   * @param versionNo
   * The version number of the fund fiscal year line item.
   * 
   * @throws InformationalException
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_LINE_ITEM_CANNOT_BE_DELETED_AS_DEBIT_CREDIT_BALANCE}
   * - If the fund fiscal year line item has a credit or debit balance
   * for the related fund fiscal year.
   * @throws InformationalException
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_OBLIGATION_IS_ASSOCIATED_WITH_FUND_CANNOT_DELETE}
   * - If there exist an obligation for the related fund fiscal year
   * of the fund fiscal year line item.
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    if (getAllocatedTotal().getValue() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator
            .ERR_FUNDFISCALYEARLINEITEM_XRV_LINE_ITEM_CANNOT_BE_DELETED_AS_DEBIT_CREDIT_BALANCE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }
    // BEGIN, CR00188291, AS
    final List<Obligation> obligationList =
      obligationDAO.searchByFundFiscalYear(getFundFiscalYear().getID());

    if (obligationList.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
        .getManager()
        .addValidationHelperExceptionWithLookup(
          FUNDFISCALYEARLINEITEMExceptionCreator
            .ERR_FUNDFISCALYEARLINEITEM_XRV_OBLIGATION_IS_ASSOCIATED_WITH_FUND_CANNOT_DELETE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }
    // END, CR00188291
    super.cancel(versionNo);
  }

  // BEGIN, CR00187494, AS
  /**
   * Modifies a fund fiscal year line item.
   * 
   * @param versionNo
   * The version number of the fund fiscal year line item.
   * 
   * @throws InformationalException
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_BUDGETADJUSTMENT_EXIST_BETWEEN_ORIGINAL_STARTDATE_AND_PROPOSED_STARTDATE_CANNOT_MODIFY}
   * - If there exist a budget adjustment between the original start
   * date and the proposed start date for the fund fiscal year line
   * item.
   * @throws InformationalException
   * {@link FUNDFISCALYEARLINEITEM#ERR_FUNDFISCALYEARLINEITEM_XRV_BUDGETADJUSTMENT_EXIST_BETWEEN_ORIGINAL_ENDDATE_AND_PROPOSED_ENDDATE_CANNOT_MODIFY}
   * - If there exist a budget adjustment between the original end
   * date and the proposed end date for the fund fiscal year line
   * item.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    final List<BudgetAdjustment> budgetAdjustmentObj =
      budgetAdjustmentDAO
        .listBudgetAdjustmentForRelatedID(fundFiscalYearLineItem.getID());

    for (final BudgetAdjustment budgetAdjustment : budgetAdjustmentObj) {
      if (budgetAdjustment.getCreationDate().before(
        fundFiscalYearLineItem.getDateRange().start())
        && budgetAdjustment.getCreationDate().after(
          getRowManager().getOriginalDtls().startDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_BUDGETADJUSTMENT_EXIST_BETWEEN_ORIGINAL_STARTDATE_AND_PROPOSED_STARTDATE_CANNOT_MODIFY(
              getRowManager().getOriginalDtls().startDate,
              fundFiscalYearLineItem.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }
      // BEGIN, CR00188291, AS
      if (budgetAdjustment.getCreationDate().after(
        fundFiscalYearLineItem.getDateRange().end())
        && budgetAdjustment.getCreationDate().before(
          getRowManager().getOriginalDtls().endDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addValidationHelperExceptionWithLookup(
            FUNDFISCALYEARLINEITEMExceptionCreator.ERR_FUNDFISCALYEARLINEITEM_XRV_BUDGETADJUSTMENT_EXIST_BETWEEN_ORIGINAL_ENDDATE_AND_PROPOSED_ENDDATE_CANNOT_MODIFY(
              fundFiscalYearLineItem.getDateRange().end(), getRowManager()
                .getOriginalDtls().endDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);

      }
      // END, CR00188291
      ValidationHelper.failIfErrorsExist();
    }
    super.modify(versionNo);
  }

  // END, CR00187494

  /**
   * Sets the unique reference number for a fund fiscal year line item.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   */
  private void setLineItemReferenceNumber() throws InformationalException {

    try {
      getDtls().lineItemRefNo =
        fiscalYearLineItemRefNum.generateFFYLIReferenceNumber();
    } catch (final AppException appException) {
      ValidationHelper.addValidationError(appException);
    }
  }

}
