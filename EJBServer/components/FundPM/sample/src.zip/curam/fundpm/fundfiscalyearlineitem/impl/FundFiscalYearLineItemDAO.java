/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.fundfiscalyearlineitem.impl;

import com.google.inject.ImplementedBy;
import curam.fundpm.impl.FundFiscalYear;
import curam.util.persistence.StandardDAO;
import java.util.List;

/**
 * Data access for {@linkplain FundFiscalYearLineItem}.
 */
@ImplementedBy(FundFiscalYearLineItemDAOImpl.class)
public interface FundFiscalYearLineItemDAO extends
  StandardDAO<FundFiscalYearLineItem> {

  /**
   * Searches the list of fund fiscal year line items for a fund fiscal year.
   * 
   * @param fundFiscalYear
   * The fund fiscal year.
   * 
   * @return The list of fund fiscal year line items.
   */
  public List<FundFiscalYearLineItem> searchByFundFiscalYear(
    FundFiscalYear fundFiscalYear);

}
