/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.facade.impl;

import com.google.inject.Inject;
import curam.codetable.impl.BUDGETADJUSTMENTTYPEEntry;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.fundpm.facade.struct.BudgetAdjustmentDetails;
import curam.fundpm.facade.struct.BudgetAdjustmentDetailsList;
import curam.fundpm.facade.struct.BudgetAdjustmentKey;
import curam.fundpm.facade.struct.FundFiscalYearLineItemKey;
import curam.fundpm.impl.BudgetAdjustmentDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Money;
import java.util.List;

/**
 * This class manages the budget adjustments for a fund fiscal year line item.
 */
public abstract class MaintainBudgetAdjustment extends
  curam.fundpm.facade.base.MaintainBudgetAdjustment {

  /**
   * Reference to Budget Adjustment DAO.
   */
  @Inject
  private BudgetAdjustmentDAO budgetAdjustmentDAO;

  /**
   * Reference to denote negative value of Money.
   */
  private final Money kPositiveMoneySentinelValue = new Money(-1);

  /**
   * Constructor for the class.
   */
  public MaintainBudgetAdjustment() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a budget adjustment for a fund fiscal year line item.
   * 
   * @param budgetAdjustmentDetails
   * Budget adjustment details.
   * 
   * @return The budget adjustment key.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public curam.fundpm.sl.entity.struct.BudgetAdjustmentKey
    createBudgetAdjustment(
      final BudgetAdjustmentDetails budgetAdjustmentDetails)
      throws AppException, InformationalException {

    final curam.fundpm.impl.BudgetAdjustment budgetAdjustmentObj =
      budgetAdjustmentDAO.newInstance();

    budgetAdjustmentObj.setAmount(budgetAdjustmentDetails.dtls.amount);
    budgetAdjustmentObj.setComments(budgetAdjustmentDetails.dtls.comments);
    budgetAdjustmentObj.setCreditDebitType(CREDITDEBITEntry
      .get(budgetAdjustmentDetails.dtls.creditDebitType));
    budgetAdjustmentObj.setRelatedID(budgetAdjustmentDetails.dtls.relatedID);
    budgetAdjustmentObj.setRelatedType(BUDGETADJUSTMENTTYPEEntry
      .get(budgetAdjustmentDetails.dtls.relatedType));
    budgetAdjustmentObj.insert();

    final curam.fundpm.sl.entity.struct.BudgetAdjustmentKey budgetAdjustmentKey =
      new curam.fundpm.sl.entity.struct.BudgetAdjustmentKey();

    budgetAdjustmentKey.budgetAdjustmentID = budgetAdjustmentObj.getID();

    return budgetAdjustmentKey;

  }

  /**
   * Retrieves the budget adjustment details related to fund fiscal year line
   * item.
   * 
   * @param budgetAdjustmentKey
   * Contains the budget adjustment key details.
   * 
   * @return Budget adjustment details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BudgetAdjustmentDetails viewBudgetAdjustment(
    final BudgetAdjustmentKey budgetAdjustmentKey) throws AppException,
    InformationalException {

    final BudgetAdjustmentDetails budgetAdjustmentDetails =
      new BudgetAdjustmentDetails();

    final curam.fundpm.impl.BudgetAdjustment budgetAdjustmentObj =
      budgetAdjustmentDAO.get(budgetAdjustmentKey.budgetAdjustmentID);

    budgetAdjustmentDetails.dtls.amount = budgetAdjustmentObj.getAmount();
    budgetAdjustmentDetails.dtls.comments = budgetAdjustmentObj.getComments();
    budgetAdjustmentDetails.dtls.creationDate =
      budgetAdjustmentObj.getCreationDate();

    if (BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM.getCode().equals(
      budgetAdjustmentObj.getRelatedType().getCode())) {

      budgetAdjustmentDetails.allocationReferenceNoInd = true;
      budgetAdjustmentDetails.dtls.allocationRefNo =
        budgetAdjustmentObj.getAllocationReferenceNumber();
    }

    budgetAdjustmentDetails.dtls.creditDebitType =
      budgetAdjustmentObj.getCreditDebitType().getCode();
    budgetAdjustmentDetails.dtls.userFirstName =
      budgetAdjustmentObj.getUserFirstName();
    budgetAdjustmentDetails.dtls.userLastName =
      budgetAdjustmentObj.getUserSurname();

    return budgetAdjustmentDetails;
  }

  /**
   * Retrieves all the budget adjustments for a fund fiscal year line item.
   * 
   * @param fundFiscalYearLineItemKey
   * Contains fund fiscal year line item ID.
   * 
   * @return The list of budget adjustment details.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public BudgetAdjustmentDetailsList listBudgetAdjustment(
    final FundFiscalYearLineItemKey fundFiscalYearLineItemKey)
    throws AppException, InformationalException {

    final BudgetAdjustmentDetailsList budgetAdjustmentDetailsList =
      new BudgetAdjustmentDetailsList();

    final List<curam.fundpm.impl.BudgetAdjustment> budgetAdjustmentList =
      budgetAdjustmentDAO
        .listBudgetAdjustmentForRelatedID(fundFiscalYearLineItemKey.key.fundFclYrLineItemID);

    for (final curam.fundpm.impl.BudgetAdjustment budgetAdjustmentObj : budgetAdjustmentList) {

      final BudgetAdjustmentDetails budgetAdjustmentDetails =
        new BudgetAdjustmentDetails();

      budgetAdjustmentDetails.dtls.amount = budgetAdjustmentObj.getAmount();
      budgetAdjustmentDetails.dtls.comments =
        budgetAdjustmentObj.getComments();
      budgetAdjustmentDetails.dtls.budgetAdjustmentID =
        budgetAdjustmentObj.getID();
      budgetAdjustmentDetails.dtls.creationDate =
        budgetAdjustmentObj.getCreationDate();
      budgetAdjustmentDetails.dtls.allocationRefNo =
        budgetAdjustmentObj.getAllocationReferenceNumber();
      budgetAdjustmentDetails.dtls.userFirstName =
        budgetAdjustmentObj.getUserFirstName();

      if (budgetAdjustmentObj.getCreditDebitType().equals(
        CREDITDEBITEntry.CREDIT)) {

        budgetAdjustmentDetails.creditAmount =
          budgetAdjustmentObj.getAmount();
        budgetAdjustmentDetails.debitAmount = kPositiveMoneySentinelValue;
      } else {

        budgetAdjustmentDetails.debitAmount = budgetAdjustmentObj.getAmount();
        budgetAdjustmentDetails.creditAmount = kPositiveMoneySentinelValue;
      }

      budgetAdjustmentDetails.dtls.userLastName =
        budgetAdjustmentObj.getUserSurname();

      budgetAdjustmentDetailsList.detailsList.addRef(budgetAdjustmentDetails);

    }
    return budgetAdjustmentDetailsList;
  }

}
