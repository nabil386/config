/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.impl;

import curam.codetable.impl.BUDGETADJUSTMENTTYPEEntry;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.Money;

/**
 * Accessor interface for {@linkplain BudgetAdjustment}.
 */
public interface BudgetAdjustmentAccessor extends StandardEntity {

  /**
   * Gets the credit/debit type of the fund line item.
   * 
   * @return The credit/debit type of the fund line item.
   */
  CREDITDEBITEntry getCreditDebitType();

  /**
   * Gets the fund fiscal year line item/fund fiscal year set aside.
   * 
   * @return The fund fiscal year line item/fund fiscal year set aside ID.
   */
  Long getRelatedID();

  /**
   * Gets the amount of the budget adjustment.
   * 
   * @return The amount of the budget adjustment.
   */
  Money getAmount();

  /**
   * Gets the creation date of the budget adjustment.
   * 
   * @return The creation date of the budget adjustment.
   */
  Date getCreationDate();

  /**
   * Gets the allocation reference number assigned to the budget adjustment to
   * reference where the allocation originated.
   * 
   * @return The allocation reference number assigned to the budget adjustment
   * to reference where the allocation originated.
   */
  String getAllocationReferenceNumber();

  /**
   * Gets the user first name who created the record.
   * 
   * @return The user first name who created the record.
   */
  String getUserFirstName();

  /**
   * Gets the user surname who created the record.
   * 
   * @return The user surname who created the record.
   */
  String getUserSurname();

  /**
   * Gets the budget adjustment related type. It can be related to fund fiscal
   * year line item/fund fiscal year set aside.
   * 
   * @return The related type associated with the budget adjustment.
   */
  BUDGETADJUSTMENTTYPEEntry getRelatedType();

}
