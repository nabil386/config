/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.impl;

import com.google.inject.ImplementedBy;
import curam.codetable.impl.BUDGETADJUSTMENTTYPEEntry;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.type.Money;

/**
 * This represents a budget adjustment. For example, Federal Fund 2008-2009 is a
 * fiscal year fund with a total budgeted amount of 10000$ and a total obligated
 * amount of 100$. The total obligated amount of 100$ can be represented as a
 * budget adjustment with a transaction type of Obligation and under the
 * category of credit.
 * 
 */
@ImplementedBy(BudgetAdjustmentImpl.class)
public interface BudgetAdjustment extends BudgetAdjustmentAccessor,
  Insertable, OptimisticLockModifiable, Commented {

  /**
   * Sets the allocation reference number assigned to the budget adjustment to
   * reference where the allocation originated.
   * 
   * @param allocationReferenceNo
   * The allocation reference number assigned to budget adjustment, to
   * reference where the allocation originated.
   */
  void setAllocationReferenceNumber(final String allocationReferenceNo);

  /**
   * Sets the credit/debit type for the fund fiscal year line item. For example,
   * when
   * obligating money to a fiscal year fund, the credit/debit type will be
   * Credit.
   * 
   * @param creditDebitType
   * The credit debit type for the fund fiscal year line item.
   */
  void setCreditDebitType(final CREDITDEBITEntry creditDebitType);

  /**
   * Sets the amount for the budget adjustment.
   * 
   * @param amount
   * The amount of the budget adjustment.
   */
  void setAmount(final Money amount);

  /**
   * Sets the fund fiscal year line item/fund fiscal year set aside.
   * 
   * @param relatedID
   * Unique ID of the fund fiscal year line item/fund fiscal year set
   * aside.
   */
  void setRelatedID(final Long relatedID);

  /**
   * Sets the type for which budget adjustment is created.
   * 
   * @param relatedType
   * The type for which budget adjustment is created.
   */
  void setRelatedType(final BUDGETADJUSTMENTTYPEEntry relatedType);
}
