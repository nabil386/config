/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.util.impl;

import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateRange;
import curam.util.type.Money;

/**
 * A FundFiscalYearObligationAmtCalculation class is used for calculating an
 * obligation amount for each fund fiscal year, when the period for which the
 * obligation is to be created crosses more than one fiscal year. The default
 * implementation of this interface is provided by
 * FundFiscalYearObligationAmtCalculationImpl.
 * 
 * The default implementation of this interface can be replaced with a new
 * custom implementation by creating a new Guice module class and adding a
 * corresponding entry in the MODULE table. Chapter 5 - Creating a Guice Module
 * in the Persistence Cookbook explains this in detail.
 * 
 * A new implementation of this interface is required to change the mechanism
 * used to calculate an obligation amount for each fund fiscal year.
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
@ImplementedBy(FundFiscalYearObligationAmtCalculationImpl.class)
public interface FundFiscalYearObligationAmtCalculation {

  /**
   * Calculates the obligation amount for each fund fiscal year, when the
   * obligation period overlaps more than one fiscal year.
   * 
   * To determine the obligation amount, the default implementation splits the
   * obligation amount and the relevant amounts are applied to the respective
   * fund fiscal years. The calculation of obligation amounts for all
   * overlapping fund fiscal years is determined using the formula, OA = (CYD /
   * OD) * ROA, Where: OA = The obligation amount for each fund fiscal year, CYD
   * = The number of days in the obligation period that fall within the current
   * fiscal year, OD = The number of days in the obligation period, ROA = The
   * total requested obligation amount.
   * 
   * @param obligationAmount
   * The obligation amount.
   * @param obligationPeriod
   * The date range of an obligation.
   * @param fundFiscalYearDateRange
   * The date range of a fund fiscal year.
   * 
   * @return The obligation amount.
   * 
   * @see curam.fundpm.util.impl.FundFiscalYearObligationAmtCalculationImpl#
   * calculateObligationAmountForFFY(Money obligationAmount, DateRange
   * obligationPeriod,DateRange fundFiscalYearDateRange) The default
   * implementation -
   * curam.fundpm.util.impl.FundFiscalYearObligationAmtCalculation#
   * calculateObligationAmountForFFY(Money obligationAmount, DateRange
   * obligationPeriod,DateRange fundFiscalYearDateRange)
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  @curam.util.type.Implementable
  // BEGIN, CR00205389, AS
    public
    Money calculateObligationAmountForFFY(final Money obligationAmount,
      final DateRange obligationPeriod,
      final DateRange fundFiscalYearDateRange) throws AppException,
      InformationalException;
  // END, CR00205389
}
