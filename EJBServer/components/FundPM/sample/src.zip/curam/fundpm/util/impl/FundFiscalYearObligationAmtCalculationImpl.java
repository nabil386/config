/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.util.impl;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.Money;

/**
 * Standard implementation of
 * {@linkplain curam.fundpm.util.impl.FundFiscalYearObligationAmtCalculation}.
 */
public class FundFiscalYearObligationAmtCalculationImpl implements
  FundFiscalYearObligationAmtCalculation {

  /**
   * Protected constructor of FundFiscalYearObligationAmtCalculationImpl.
   */
  protected FundFiscalYearObligationAmtCalculationImpl() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Calculates Obligation Amount for each fund fiscal year which are
   * overlapped. When the obligation period overlaps more than one fiscal year,
   * the obligation amount is split and the relevant amounts are applied to the
   * respective fund fiscal years, then the calculation of obligation amounts
   * for all overlapping fund fiscal years is determined using the formula, OA =
   * (CYD / OD) * ROA Where: CYD = No. of days in obligation period that fall
   * within the current fiscal year, OD = No. of days in obligation period, ROA
   * =
   * Total requested obligation amount
   * 
   * @param obligationAmount
   * The obligation Amount.
   * @param obligationPeriod
   * Date Range of obligation.
   * @param fundFiscalYearDateRange
   * Date Range of fund fiscal year which are overlapped.
   * 
   * @return Obligation Amount for each fund fiscal year.
   * 
   * @throws InformationalException
   * Generic Exception Signature.
   * 
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public Money
    calculateObligationAmountForFFY(final Money obligationAmount,
      final DateRange obligationPeriod,
      final DateRange fundFiscalYearDateRange) throws AppException,
      InformationalException {

    final DateRange obligationDateRange =
      new DateRange(obligationPeriod.start(), obligationPeriod.end());
    final int totalObligationDays = obligationDateRange.length();

    // BEGIN, CR00205691, RD
    Date startDate = null;
    Date endDate = null;

    // END, CR00205691

    if (fundFiscalYearDateRange.start().before(obligationPeriod.start())) {
      startDate = obligationPeriod.start();
    } else if (fundFiscalYearDateRange.start().equals(
      obligationPeriod.start())) {
      startDate = obligationPeriod.start();
    } else if (fundFiscalYearDateRange.start()
      .after(obligationPeriod.start())) {
      startDate = fundFiscalYearDateRange.start();
    }

    if (fundFiscalYearDateRange.end().before(obligationPeriod.end())) {
      endDate = fundFiscalYearDateRange.end();
    } else if (fundFiscalYearDateRange.end().after(obligationPeriod.end())) {
      endDate = obligationPeriod.end();
    } else if (fundFiscalYearDateRange.end().equals(obligationPeriod.end())) {
      endDate = obligationPeriod.end();
    }

    final DateRange newDateRange = new DateRange(startDate, endDate);
    final int noOfOverlapDays = newDateRange.length();

    final double obligationAmountForFFY =
      (double) noOfOverlapDays / totalObligationDays
        * obligationAmount.getValue();

    final Money obligationAmountForEachFFY =
      new Money(obligationAmountForFFY);

    return obligationAmountForEachFFY;
  }
}
