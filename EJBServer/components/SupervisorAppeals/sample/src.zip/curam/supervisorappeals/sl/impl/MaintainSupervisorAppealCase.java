/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.supervisorappeals.sl.impl;

import curam.appeal.sl.entity.fact.AppealFactory;
import curam.appeal.sl.entity.intf.Appeal;
import curam.appeal.sl.entity.struct.CaseAppealDetails;
import curam.appeal.sl.entity.struct.CountAppeals;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.APPEALTYPE;
import curam.codetable.CASEAPPEALSOPTION;
import curam.codetable.CASESTATUS;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.TASKCHANGETYPE;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.EnvVars;
import curam.core.impl.Users;
import curam.core.intf.CaseHeader;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.struct.ReasonEndDateComments;
import curam.core.sl.struct.SendNotificationInd;
import curam.core.struct.CaseCount;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ReassignCasesByTypeCaseAndUserKey;
import curam.core.struct.UserCaseTaskStatus;
import curam.core.struct.UserNameTypeAndStatusCode;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORUSER;
import curam.supervisorappeals.sl.struct.CaseAppealDetailsList;
import curam.supervisorappeals.sl.struct.CaseIDAndAppealTypeKey;
import curam.supervisorappeals.sl.struct.ReassignCasesForUserKey;
import curam.supervisorappeals.sl.struct.SupervisorUserDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.type.CodeTable;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskFactory;
import curam.util.workflow.intf.Task;
import curam.util.workflow.struct.TaskStatusCount;
import curam.util.workflow.struct.TaskStatusCountList;
import curam.util.workflow.struct.TaskUsernameKey;

/**
 * Service layer class having API for operations related to case appeals.
 *
 */
public class MaintainSupervisorAppealCase
  extends curam.supervisorappeals.sl.base.MaintainSupervisorAppealCase {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kID = "ID";

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kBarChart = "BAR_CHART";

  /**
   * Identifier for holding the element type
   */
  protected static final String kUnit = "UNIT";

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = "CAPTION";

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kText = "TEXT";

  /**
   * Identifier for holding the element
   */
  protected static final String kBlock = "BLOCK";

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kType = "TYPE";

  /**
   * Identifier for holding the due date
   */
  protected static final String kDueDate = "DUE_DATE";

  /**
   * Identifier for holding the start date
   */
  protected static final String kStartDate = "START_DATE";

  /**
   * Identifier for holding the bar graph length
   */
  protected static final String kLength = "LENGTH";

  /**
   * Identifier for holding the Appeal Description
   */
  protected static final String kTypeDes = "APPEAL_DESC";

  /**
   * Identifier for holding the Appeal Option Code for navigating to different
   * pages.
   */
  protected static final String kAppealOptionCode = "APPEAL_OPTION_CODE";

  /**
   * Identifier for holding the Multiple Appellants
   */
  protected static final String MULTIPLE_APPELLANTS = "Multiple Appellants";

  // ____________________________________________________________________________
  /**
   * Service layer method for reading the Case Appeals details based on the case
   * ID and appeal type.
   *
   * @param arg0 - CaseIDAndAppealTypeKey
   * @return CaseAppealDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public CaseAppealDetailsList
    readCaseAppealsByType(final CaseIDAndAppealTypeKey arg0)
      throws AppException, InformationalException {

    // Case Header Object
    final Appeal appealObj = AppealFactory.newInstance();

    // Get the count of hearing cases for this case
    arg0.key.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    arg0.key.caseAppealType = APPEALTYPE.HEARING;
    CountAppeals count = appealObj.countCaseAppealsByType(arg0.key);
    final int numberofHearingCases = (int) count.numOfRecords;

    // Get the count of hearing review cases for this case
    arg0.key.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    arg0.key.caseAppealType = APPEALTYPE.HEARINGREVIEW;
    count = appealObj.countCaseAppealsByType(arg0.key);
    final int numberofHearingReviewCases = (int) count.numOfRecords;

    // Get the count of judicial review cases for this case
    arg0.key.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    arg0.key.caseAppealType = APPEALTYPE.JUDICIALREVIEW;
    count = appealObj.countCaseAppealsByType(arg0.key);
    final int numberofJudicialReviewCases = (int) count.numOfRecords;

    final Element barChartElement = new Element(kBarChart);
    final XMLOutputter outputter = new XMLOutputter();

    Element unitElement = new Element(kUnit);
    Element captionElement = new Element(kCaption);

    captionElement.setAttribute(kText, APPEALTYPE.HEARING);
    captionElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    captionElement.setAttribute(kType, APPEALTYPE.HEARING);
    captionElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.HEARING));
    unitElement.addContent(captionElement);

    Element blockElement = new Element(kBlock);

    blockElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    blockElement.setAttribute(kType, APPEALTYPE.HEARING);
    blockElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.HEARING));
    blockElement.setAttribute(kLength,
      Integer.toString(numberofHearingCases));
    blockElement.setAttribute(kAppealOptionCode, CASEAPPEALSOPTION.TYPE);
    unitElement.addContent(blockElement);
    barChartElement.addContent(unitElement);

    unitElement = new Element(kUnit);
    captionElement = new Element(kCaption);
    captionElement.setAttribute(kText, APPEALTYPE.HEARINGREVIEW);

    // BEGIN, CR00098650, SD
    captionElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    captionElement.setAttribute(kType, APPEALTYPE.HEARINGREVIEW);
    captionElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.HEARINGREVIEW));
    // END, CR00098650

    unitElement.addContent(captionElement);
    blockElement = new Element(kBlock);
    blockElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    blockElement.setAttribute(kType, APPEALTYPE.HEARINGREVIEW);
    blockElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.HEARINGREVIEW));
    blockElement.setAttribute(kLength,
      Integer.toString(numberofHearingReviewCases));
    blockElement.setAttribute(kAppealOptionCode, CASEAPPEALSOPTION.TYPE);
    unitElement.addContent(blockElement);
    barChartElement.addContent(unitElement);

    unitElement = new Element(kUnit);
    captionElement = new Element(kCaption);
    captionElement.setAttribute(kText, APPEALTYPE.JUDICIALREVIEW);

    // BEGIN, CR00098650, SD
    captionElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    captionElement.setAttribute(kType, APPEALTYPE.JUDICIALREVIEW);
    captionElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.JUDICIALREVIEW));
    // END, CR00098650

    unitElement.addContent(captionElement);
    blockElement = new Element(kBlock);
    blockElement.setAttribute(kID, Long.toString(arg0.key.caseID));
    blockElement.setAttribute(kType, APPEALTYPE.JUDICIALREVIEW);
    blockElement.setAttribute(kTypeDes,
      CodeTable.getOneItem(APPEALTYPE.TABLENAME, APPEALTYPE.JUDICIALREVIEW));
    blockElement.setAttribute(kLength,
      Integer.toString(numberofJudicialReviewCases));
    blockElement.setAttribute(kAppealOptionCode, CASEAPPEALSOPTION.TYPE);
    unitElement.addContent(blockElement);

    barChartElement.addContent(unitElement);
    final CaseAppealDetailsList caseAppealDetailsList =
      new CaseAppealDetailsList();

    if (barChartElement.getChildren().isEmpty()) {
      caseAppealDetailsList.chartXMLString = "";
    } else {
      caseAppealDetailsList.chartXMLString =
        outputter.outputString(barChartElement);
    }
    return caseAppealDetailsList;
  }

  // ______________________________________________________________________________
  /**
   * Service layer method for listing the Case Appeals details based on case ID
   * and appeal type.
   *
   * @param arg0 - CaseIDAndAppealTypeKey
   * @return CaseAppealDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public CaseAppealDetailsList
    listCaseAppealsByType(final CaseIDAndAppealTypeKey arg0)
      throws AppException, InformationalException {

    // Case Header Object
    final Appeal appealObj = AppealFactory.newInstance();
    final CaseAppealDetailsList caseAppealDetailsList =
      new CaseAppealDetailsList();

    CountAppeals countAppeals = new CountAppeals();
    final CaseReference caseReference = new CaseReference();

    arg0.key.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;

    // Populate the appeals details in struct
    caseAppealDetailsList.appealDtls =
      appealObj.searchCaseAppealsByType(arg0.key);

    for (int i = 0; i < caseAppealDetailsList.appealDtls.dtls.size(); i++) {

      final CaseAppealDetails caseAppealDetails =
        caseAppealDetailsList.appealDtls.dtls.item(i);

      caseReference.caseReference = caseAppealDetails.caseReference;
      countAppeals = appealObj.countAppellantsByCaseReference(caseReference);

      if (countAppeals.numOfRecords > 1) {
        caseAppealDetailsList.appealDtls.dtls.item(i).appelant =
          MULTIPLE_APPELLANTS;
      }
      if (ORGOBJECTTYPE.ORGUNIT.equals(caseAppealDetails.orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit organisationUnit =
          OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey =
          new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID =
          caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          organisationUnit.readOrgUnitName(organisationUnitKey).name;
      } else if (ORGOBJECTTYPE.POSITION
        .equals(caseAppealDetails.orgObjectType)) {
        final curam.core.sl.entity.intf.Position position_obj =
          PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          position_obj.readPositionName(positionKey).name;
      } else if (ORGOBJECTTYPE.WORKQUEUE
        .equals(caseAppealDetails.orgObjectType)) {
        final WorkQueue workqueue_obj =
          curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
        final curam.core.sl.entity.struct.WorkQueueKey workQueueKey =
          new curam.core.sl.entity.struct.WorkQueueKey();

        workQueueKey.workQueueID = caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          workqueue_obj.readWorkQueueName(workQueueKey).name;
      } else if (ORGOBJECTTYPE.USER.equals(caseAppealDetails.orgObjectType)) {
        final curam.core.intf.Users usersObj = UsersFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = caseAppealDetails.userName;
        caseAppealDetails.objectOwnerName =
          usersObj.readUserFullname(usersKey).fullname;
      }
    }
    return caseAppealDetailsList;
  }

  // ____________________________________________________________________________
  /**
   * Service layer method for listing the Case Appeals details based on Case ID
   * and Appeal type.
   *
   * @param arg0 - CaseIDAndAppealTypeKey
   * @return CaseAppealDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public CaseAppealDetailsList
    listCaseAppealsByDeadLine(final CaseIDAndAppealTypeKey arg0)
      throws AppException, InformationalException {

    final Appeal appealObj = AppealFactory.newInstance();
    final CaseAppealDetailsList caseAppealDetailsList =
      new CaseAppealDetailsList();

    CountAppeals countAppeals = new CountAppeals();
    final CaseReference caseReference = new CaseReference();

    arg0.key.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    // Populate the appeals details in struct
    caseAppealDetailsList.appealDtls =
      appealObj.searchCaseAppealsByDeadLine(arg0.key);

    for (int i = 0; i < caseAppealDetailsList.appealDtls.dtls.size(); i++) {
      final CaseAppealDetails caseAppealDetails =
        caseAppealDetailsList.appealDtls.dtls.item(i);

      caseReference.caseReference = caseAppealDetails.caseReference;
      countAppeals = appealObj.countAppellantsByCaseReference(caseReference);

      if (countAppeals.numOfRecords > 1) {
        caseAppealDetailsList.appealDtls.dtls.item(i).appelant =
          MULTIPLE_APPELLANTS;
      }
      if (ORGOBJECTTYPE.ORGUNIT.equals(caseAppealDetails.orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit organisationUnit =
          OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey =
          new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID =
          caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          organisationUnit.readOrgUnitName(organisationUnitKey).name;
      } else if (ORGOBJECTTYPE.POSITION
        .equals(caseAppealDetails.orgObjectType)) {
        final curam.core.sl.entity.intf.Position position_obj =
          PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          position_obj.readPositionName(positionKey).name;
      } else if (ORGOBJECTTYPE.WORKQUEUE
        .equals(caseAppealDetails.orgObjectType)) {
        final WorkQueue workqueue_obj =
          curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
        final curam.core.sl.entity.struct.WorkQueueKey workQueueKey =
          new curam.core.sl.entity.struct.WorkQueueKey();

        workQueueKey.workQueueID = caseAppealDetails.orgObjectReference;
        caseAppealDetails.objectOwnerName =
          workqueue_obj.readWorkQueueName(workQueueKey).name;
      } else if (ORGOBJECTTYPE.USER.equals(caseAppealDetails.orgObjectType)) {
        final curam.core.intf.Users usersObj = UsersFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName = caseAppealDetails.userName;
        caseAppealDetails.objectOwnerName =
          usersObj.readUserFullname(usersKey).fullname;
      }
    }
    return caseAppealDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This function parses the Tab-delimited string in to a list of Strings
   *
   * @param key
   * Tab-delimited string list of caseID's
   * @return StringList
   */

  // BEGIN, CR00177241, PM
  protected StringList parseCaseIDList(final ReassignCasesForUserKey key) {

    // END, CR00177241
    StringList stringList = new StringList();

    // Convert the tab delimited string to a list of strings
    stringList = StringUtil.tabText2StringList(key.reassignCaseList);
    return stringList;

  }

  @Override
  public void reassignCaseAppeals(final ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    // AdministrationCaseRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // parse the Tab-delimited String
    final StringList stringList = parseCaseIDList(key);

    SupervisorApplicationUtil.validateReassignCase(key, stringList);
    key.OrgObjLinkDtls.orgObjectType = key.organisationObject;

    // if Auto Reassign field is checked then it is redirected to a method
    // 'autoReassignForUsers'- where it reassigns the case to only Users and not
    // any other organization object

    if (key.autoReassign) {

      final CaseReassign.AutoReassign autoReassign =
        new CaseReassign.AutoReassign();

      // Passing a boolean parameter to display issue case specific messages.
      autoReassign.autoReassignForUsers(key, false); // autoReassignForUsers(key,
                                                     // false);
      return;

    } else if (!key.autoReassign) {
      if (ORGOBJECTTYPE.USER.equals(key.OrgObjLinkDtls.orgObjectType)) {
        SupervisorApplicationUtil.validateReassignCaseUser(key);
      } else {
        // validates the organization object expect Users.
        SupervisorApplicationUtil.validateReassignCaseOrgObject(key);
      }
    }
    final String reassignCaseFromNotificationEnabled =
      curam.util.resources.Configuration
        .getProperty(EnvVars.ENV_SUPERVISOR_REASSIGNCASESFROMNOTIFICATION);

    final SupervisorApplicationUtil supervisorApplicationUtil =
      new SupervisorApplicationUtil();

    // If notification to the current owner is enabled then send a notification.
    if (reassignCaseFromNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {

      supervisorApplicationUtil.sendFromNotificationForListOfCases(stringList,
        false);
    }
    for (int i = 0; i < stringList.size(); i++) {

      final ReassignCasesByTypeCaseAndUserKey reassignCasesByTypeCaseAndUserKey =
        new ReassignCasesByTypeCaseAndUserKey();

      reassignCasesByTypeCaseAndUserKey.currentUserID = key.currentUserID;
      reassignCasesByTypeCaseAndUserKey.newUserID = key.newUserID;

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = Long.parseLong(stringList.item(i));

      // Read case details that has to be reassigned
      // BEGIN, CR00303986, SG
      final CaseSearchKey caseSearchKey = new CaseSearchKey();

      caseSearchKey.caseID = Long.parseLong(stringList.item(i));
      final CaseReferenceAndStatusDetails caseReferenceAndStatusDetails =
        caseHeaderObj.readCaseReferenceAndStatusByCaseID(caseSearchKey);

      if (CASESTATUS.CLOSED
        .equals(caseReferenceAndStatusDetails.statusCode)) {
        final AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_CASESTATUS_CLOSED);

        ae.arg(caseReferenceAndStatusDetails.caseReference);
        // END, CR00303986

        curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager().throwWithLookup(ae,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }

      final ReasonEndDateComments reasonEndDateComments =
        new ReasonEndDateComments();

      if (key.OrgObjLinkDtls.orgObjectType.equals(ORGOBJECTTYPE.USER)) {
        key.OrgObjLinkDtls.userName = key.newUserID;
      } else {
        key.OrgObjLinkDtls.orgObjectReference = Long.parseLong(key.newUserID);
      }

      // Call CaseUserRole to create the new case owner
      final SendNotificationInd sendNotificationInd =
        new SendNotificationInd();

      sendNotificationInd.sendNotification = false;
      // Call CaseUserRole to create the new case owner
      caseUserRoleObj.modifyCaseOwner(caseHeaderKey, key.OrgObjLinkDtls,
        reasonEndDateComments, sendNotificationInd);
    }
    // Send a Notification to the new owner
    final String reassignCaseToNotificationEnabled =
      curam.util.resources.Configuration
        .getProperty(EnvVars.ENV_SUPERVISOR_REASSIGNCASESTONOTIFICATION);

    if (reassignCaseToNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
      // Send a Notification to new owner
      supervisorApplicationUtil.sendToNotificationForListOfCases(stringList,
        false);
    }
  }

  /**
   * Service layer method for listing the Supervisor Users.
   *
   * @return SupervisorUserDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  public SupervisorUserDetailsList listSupervisorUsers()
    throws AppException, InformationalException {

    final UserCaseTaskStatus userCaseTaskStatus = new UserCaseTaskStatus();

    // set the logged in username and the status to the UserCaseTaskStatus
    // object
    // Get the userName from the SystemUser
    final SystemUser systemUser = SystemUserFactory.newInstance();

    userCaseTaskStatus.userName = systemUser.getUserDetails().userName;
    userCaseTaskStatus.status = curam.codetable.RECORDSTATUS.CANCELLED;
    userCaseTaskStatus.taskStatus = TASKCHANGETYPE.RESERVED;

    // Users object
    final Users usersObj = (Users) UsersFactory.newInstance();
    final curam.core.struct.SupervisorUserDetailsList supervisorUserDetailsList =
      usersObj.searchUsersBySupervisorID(userCaseTaskStatus);

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final Task taskObj = TaskFactory.newInstance();
    final TaskUsernameKey taskUserNameKey = new TaskUsernameKey();
    CaseCount caseCount = new CaseCount();

    final UserNameTypeAndStatusCode ownerAndStatusCodeKey =
      new UserNameTypeAndStatusCode();

    for (int i = 0; i < supervisorUserDetailsList.dtls.size(); i++) {
      final curam.core.struct.SupervisorUserDetails details =
        supervisorUserDetailsList.dtls.item(i);

      ownerAndStatusCodeKey.userName = details.userName;
      ownerAndStatusCodeKey.statusCode = CASESTATUS.OPEN;
      ownerAndStatusCodeKey.typeCode = ORGOBJECTTYPE.USER;

      // BEGIN, CR00236076, AK
      caseCount = caseHeaderObj.countByOwnerAndStatus1(ownerAndStatusCodeKey);
      // END, CR00236076
      details.openCases = caseCount.value;

      // set username to get the count of reserved tasks
      taskUserNameKey.username = details.userName;
      final TaskStatusCountList countList =
        taskObj.countByUserAndStatus(taskUserNameKey);

      for (int j = 0; j < countList.dtls.size(); j++) {
        final TaskStatusCount taskStatusCount = countList.dtls.item(j);

        details.reservedCases += (int) taskStatusCount.count;
      }
    }
    // return object
    final SupervisorUserDetailsList userDetails =
      new SupervisorUserDetailsList();

    // assign the list to the return object
    userDetails.userdetails = supervisorUserDetailsList;
    // return the SupervisorUserDetails object
    return userDetails;
  }
}
