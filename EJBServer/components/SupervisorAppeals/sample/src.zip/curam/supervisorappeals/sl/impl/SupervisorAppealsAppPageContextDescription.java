/*
 * Licensed Materials - Property of IBM
 * 
 * PID 5725-H26
 * 
 * Copyright IBM Corporation 2012. All rights reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.supervisorappeals.sl.impl;

import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.impl.Users;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.supervisorappeals.sl.struct.SupervisorAppealsAppPageContextDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTable;

public class SupervisorAppealsAppPageContextDescription extends
  curam.supervisorappeals.sl.base.SupervisorAppealsAppPageContextDescription {

  /**
   * Identifier for separator
   */
  protected static final String kSeparator = " - ";

  /**
   * Identifier for space
   */
  protected static final String kSpace = " ";

  /**
   * Identifier for blank string
   */
  protected static final String kBlankString = "";

  /**
   * Service layer method for fetching the UserNamePageContext details.
   * This gets the full-name of the user taking username as the input parameter.
   * 
   * @param UserNameKey
   * @return SupervisorAppealsAppPageContextDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public SupervisorAppealsAppPageContextDetails
    readUserNamePageContextDescription(final UserNameKey arg0)
      throws AppException, InformationalException {

    // return object
    final SupervisorAppealsAppPageContextDetails pageContextDetails =
      new SupervisorAppealsAppPageContextDetails();
    // users object
    final Users usersObj = (Users) UsersFactory.newInstance();
    // users key object
    final UsersKey usersKey = new UsersKey();

    // set username to get the user full name
    usersKey.userName = arg0.userName;
    final UserFullname userFullName = usersObj.getFullName(usersKey);

    // set user full name to the page context description
    pageContextDetails.description = userFullName.fullname;
    // return page context details object
    return pageContextDetails;

  }

  /**
   * Service layer method for fetching the page context details of the
   * LoggedInUser.
   * The UserName is obtained from the TransactionInfo and this is
   * used to fetch the full-name of the user.
   * 
   * @return SupervisorAppealsAppPageContextDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public SupervisorAppealsAppPageContextDetails readLoggedInUserName()
    throws AppException, InformationalException {

    // return object
    final SupervisorAppealsAppPageContextDetails pageContextDetails =
      new SupervisorAppealsAppPageContextDetails();
    // users object
    final Users usersObj = (Users) UsersFactory.newInstance();
    // users key object
    final UsersKey usersKey = new UsersKey();
    // Get the userName from the SystemUser
    // and set username to get the user full name
    final SystemUser systemUser = SystemUserFactory.newInstance();

    usersKey.userName = systemUser.getUserDetails().userName;

    final UserFullname userFullName = usersObj.getFullName(usersKey);

    // set user full name to the page context description
    pageContextDetails.description = userFullName.fullname;
    // return page context details object
    return pageContextDetails;
  }

  /**
   * Service layer method for fetching the PageContext
   * details for a given caseID.
   * 
   * @param CaseID
   * @return SupervisorAppealsAppPageContextDetails
   * @throws InformationalException
   * @throws AppException
   */

  @Override
  public SupervisorAppealsAppPageContextDetails
    readCasePageContextDescription(final CaseID arg0) throws AppException,
      InformationalException {

    // return structure
    final SupervisorAppealsAppPageContextDetails caseContextDescription =
      new SupervisorAppealsAppPageContextDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    String productTypeDesc = "";
    final int kBufSize = 256;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read CaseHeader
    caseHeaderKey.caseID = arg0.caseID;

    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read ConcernRole
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if (caseHeaderDtls.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
      || caseHeaderDtls.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.LIABILITY)) {

      // ProductDelivery manipulation variables
      final curam.core.intf.ProductDelivery productDeliveryObj =
        curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      // Set key to read productDelivery
      productDeliveryKey.caseID = arg0.caseID;

      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      productTypeDesc =
        CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryDtls.productType);

    } else if (caseHeaderDtls.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.SCREENINGCASE)) {

      // ProductDelivery manipulation variables
      final curam.core.sl.entity.intf.Screening screeningObj =
        curam.core.sl.entity.fact.ScreeningFactory.newInstance();
      final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
      ScreeningName screeningName;

      // Set key to read Screening
      caseKeyStruct.caseID = arg0.caseID;

      // Read Screening
      screeningName = screeningObj.readName(caseKeyStruct);

      productTypeDesc = // BEGIN, HARP 44761, POH
        CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME, screeningName.name);

    } else if (caseHeaderDtls.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

      ICHomePageNameAndType icHomePageNameAndType;
      final curam.core.struct.CaseKey caseKey =
        new curam.core.struct.CaseKey();

      // Read caseHeader
      caseKey.caseID = arg0.caseID;
      icHomePageNameAndType =
        caseHeaderObj.readICHomePageNameAndType(caseKey);

      productTypeDesc =
        CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
          icHomePageNameAndType.integratedCaseType);
    }

    // Create and initialize StringBuffer
    final StringBuffer contextDescription = new StringBuffer(kBufSize);

    // If case type is integrated case there will be no product type in the
    // context description.
    if (caseHeaderDtls.caseTypeCode
      .equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
      || caseHeaderDtls.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.LIABILITY)
      || caseHeaderDtls.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.SCREENINGCASE)
      || caseHeaderDtls.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.SERVICEPLAN)
      || caseHeaderDtls.caseTypeCode
        .equals(curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {
      contextDescription.append(productTypeDesc).append(kSpace)
        .append(kSeparator).append(kSpace)
        .append(caseHeaderDtls.caseReference).append(kSpace)
        .append(kSeparator).append(kSpace)
        .append(concernRoleDtls.concernRoleName);

    }
    caseContextDescription.description = contextDescription.toString();

    return caseContextDescription;

  }

}
