/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012,2021. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.supervisorappeals.facade.impl;

import curam.appeal.sl.entity.struct.CasesWithAppealsDetailsList;
import curam.appeal.sl.entity.struct.CasesWithAppealsKey;
import curam.codetable.APPEALRELATIONSHIPSTATUS;
import curam.codetable.CASEAPPEALSOPTION;
import curam.codetable.CASESTATUS;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.common.util.xml.dom.Element;
import curam.common.util.xml.dom.output.XMLOutputter;
import curam.core.facade.struct.UserSearchKey;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.impl.Users;
import curam.core.intf.ProductDelivery;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserSearchDetailsRef;
import curam.core.struct.UserSearchDetailsReference;
import curam.core.struct.UserSearchResults;
import curam.core.struct.UserSearchResultsDetails;
import curam.core.struct.UsersKey;
import curam.supervisorappeals.facade.struct.CaseIDAndAppealOptionKey;
import curam.supervisorappeals.facade.struct.CaseIDAndAppealTypeKey;
import curam.supervisorappeals.facade.struct.CasesWithAppealsDetails;
import curam.supervisorappeals.facade.struct.ListCaseAppealsDetails;
import curam.supervisorappeals.facade.struct.ListSupervisorUserDetails;
import curam.supervisorappeals.facade.struct.ReassignCasesForUserKey;
import curam.supervisorappeals.facade.struct.SupervisorAppealsUserSearchDetails;
import curam.supervisorappeals.sl.fact.SupervisorAppealsAppPageContextDescriptionFactory;
import curam.supervisorappeals.sl.intf.SupervisorAppealsAppPageContextDescription;
import curam.supervisorappeals.sl.struct.SupervisorAppealsAppPageContextDetails;
import curam.supervisorappeals.sl.struct.SupervisorUserDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import java.math.BigDecimal;
import java.util.StringTokenizer;

/**
 * Facade layer class having API for operations related to case appeals.
 *
 */
public class MaintainSupervisorAppealCase
  extends curam.supervisorappeals.facade.base.MaintainSupervisorAppealCase {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kRegion = "REGION";

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kHeatMap = "HEATMAP";

  /**
   * Identifier for holding the element type
   */
  protected static final String kRegionId = "REGION_ID";

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = "CAPTION";

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaseId = "CASE_ID";

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kLabel = "LABEL";

  /**
   * Identifier for holding the element
   */
  protected static final String kItem = "ITEM";

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kItemId = "ITEM_ID";

  /**
   * Identifier for holding the Appeal Option Code for navigating to different
   * pages.
   */
  protected static final String kAppealOptionCode = "APPEAL_OPTION_CODE";

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode = "TASK_OPTION_CODE";

  /**
   * Identifier for greater than equal to
   */
  protected static final String kGreaterThanEqualTo = ">=";

  /**
   * Identifier for Dash
   */
  protected static final String kDash = "-";

  // _____________________________________________________________________________
  /**
   * This listCasesWithAppeals method lists details of all cases with appeals.
   *
   * @return CasesWithAppealsDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public CasesWithAppealsDetails listCasesWithAppeals()
    throws AppException, InformationalException {

    // Appeal object
    final curam.appeal.sl.entity.intf.Appeal appealObj =
      curam.appeal.sl.entity.fact.AppealFactory.newInstance();

    // Create objects to read the list of appeals
    final CasesWithAppealsKey casesWithAppealsKey = new CasesWithAppealsKey();
    final CasesWithAppealsDetails casesWithAppealsDetails =
      new CasesWithAppealsDetails();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    casesWithAppealsKey.appealStatusCode = APPEALRELATIONSHIPSTATUS.REJECTED;
    casesWithAppealsKey.caseStatusCode = CASESTATUS.CLOSED;
    casesWithAppealsKey.caseTypeCode = curam.codetable.CASETYPECODE.APPEAL;
    casesWithAppealsKey.recordStatus = RECORDSTATUS.CANCELLED;
    casesWithAppealsKey.supervisorUsername =
      systemUser.getUserDetails().userName;

    final CasesWithAppealsDetailsList casesWithAppealsDetailsList =
      appealObj.searchCasesWithAppeals(casesWithAppealsKey);

    casesWithAppealsDetails.appealsDetails = casesWithAppealsDetailsList;

    final SupervisorAppealsAppPageContextDescription contextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();
    final UserNameKey nameKey = new UserNameKey();

    nameKey.userName = systemUser.getUserDetails().userName;
    casesWithAppealsDetails.description =
      contextDescription.readUserNamePageContextDescription(nameKey);

    // Iterating through the list to get the value of owner based on the
    // value
    // stored in organization object
    for (int i = 0; i < casesWithAppealsDetails.appealsDetails.dtls
      .size(); i++) {

      final ProductDelivery productDeliveryObj =
        ProductDeliveryFactory.newInstance();

      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

      productDeliveryKey.caseID =
        casesWithAppealsDetails.appealsDetails.dtls.item(i).caseId;

      try {
        // Retrieves Product Type for a specified case ID
        final ProductDeliveryTypeDetails productDeliveryTypeDetails =
          productDeliveryObj.readProductType(productDeliveryKey);

        casesWithAppealsDetails.appealsDetails.dtls.item(i).productType =
          productDeliveryTypeDetails.productType;

      } catch (final RecordNotFoundException e) {

        // If the case is not a Product Delivery case then Exception is
        // caught
        // and the value of product type for that case will be set to
        // NULL.
        casesWithAppealsDetails.appealsDetails.dtls.item(i).productType = "";
      }

      // If the type of organization object is organization unit the owner
      // will have the value organization unit name.
      if (ORGOBJECTTYPE.ORGUNIT.equals(
        casesWithAppealsDetails.appealsDetails.dtls.item(i).orgObjectType)) {
        final curam.core.sl.entity.intf.OrganisationUnit orgUnit =
          OrganisationUnitFactory.newInstance();
        final OrganisationUnitKey organisationUnitKey =
          new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID =
          casesWithAppealsDetails.appealsDetails.dtls
            .item(i).orgObjectReference;
        casesWithAppealsDetails.appealsDetails.dtls.item(i).objectOwnerName =
          orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner
      // will have the value Position name.
      else if (ORGOBJECTTYPE.POSITION.equals(
        casesWithAppealsDetails.appealsDetails.dtls.item(i).orgObjectType)) {
        final Position posObj = PositionFactory.newInstance();
        final PositionKey positionKey = new PositionKey();

        positionKey.positionID = casesWithAppealsDetails.appealsDetails.dtls
          .item(i).orgObjectReference;
        casesWithAppealsDetails.appealsDetails.dtls.item(i).objectOwnerName =
          posObj.readPositionName(positionKey).name;
      } // If the type of organization object is WorkQueue the owner
      // will have the value WorkQueue name.
      else if (ORGOBJECTTYPE.WORKQUEUE.equals(
        casesWithAppealsDetails.appealsDetails.dtls.item(i).orgObjectType)) {
        final WorkQueue wq = WorkQueueFactory.newInstance();
        final WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = casesWithAppealsDetails.appealsDetails.dtls
          .item(i).orgObjectReference;
        casesWithAppealsDetails.appealsDetails.dtls.item(i).objectOwnerName =
          wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner
      // will have the value User name.
      else {
        final Users usersObj = (Users) UsersFactory.newInstance();
        final UsersKey usersKey = new UsersKey();

        usersKey.userName =
          casesWithAppealsDetails.appealsDetails.dtls.item(i).userName;
        casesWithAppealsDetails.appealsDetails.dtls.item(i).objectOwnerName =
          usersObj.readUserFullname(usersKey).fullname;
      }
    }
    return casesWithAppealsDetails;
  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for fetching the details of case appeals based on the
   * case ID and appeal option key.
   *
   * @param arg0
   * -CaseIDAndAppealOptionKey
   * @return ListCaseAppealsDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListCaseAppealsDetails
    readCaseAppeals(final CaseIDAndAppealOptionKey arg0)
      throws AppException, InformationalException {

    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();

    final CaseIDAndAppealTypeKey caseIDAndAppealTypeKey =
      new CaseIDAndAppealTypeKey();

    caseIDAndAppealTypeKey.key.key.caseID = arg0.caseID;
    final ListCaseAppealsDetails listCaseAppealsDetails =
      new ListCaseAppealsDetails();

    if (CASEAPPEALSOPTION.DEADLINEDATE.equals(arg0.appealOption)) {
      listCaseAppealsDetails.appealDetailsList = maintainSupervisorAppealCase
        .listCaseAppealsByDeadLine(caseIDAndAppealTypeKey.key);
    } else if (CASEAPPEALSOPTION.TYPE.equals(arg0.appealOption)) {
      listCaseAppealsDetails.appealDetailsList = maintainSupervisorAppealCase
        .readCaseAppealsByType(caseIDAndAppealTypeKey.key);
      // BEGIN, CR00405639, KRK
      listCaseAppealsDetails.appealTypeCodeInd = true;
      // END, CR00405639
    }

    // contextDescription object
    final SupervisorAppealsAppPageContextDescription contextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();

    // contextDescriptionKey object
    final curam.core.struct.CaseID caseIDobj = new curam.core.struct.CaseID();

    caseIDobj.caseID = arg0.caseID;
    listCaseAppealsDetails.description =
      contextDescription.readCasePageContextDescription(caseIDobj);

    return listCaseAppealsDetails;

  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for listing the details of Case Appeals based on case
   * id and appeal type
   *
   * @param arg0
   * -CaseIDAndAppealTypeKey
   * @return ListCaseAppealsDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListCaseAppealsDetails
    listCaseAppealsByType(final CaseIDAndAppealTypeKey arg0)
      throws AppException, InformationalException {

    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();

    final ListCaseAppealsDetails listCaseAppealsDetails =
      new ListCaseAppealsDetails();

    listCaseAppealsDetails.appealDetailsList =
      maintainSupervisorAppealCase.listCaseAppealsByType(arg0.key);

    // contextDescription object
    final SupervisorAppealsAppPageContextDescription contextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();

    // contextDescriptionKey object
    final curam.core.struct.CaseID caseIDobj = new curam.core.struct.CaseID();

    caseIDobj.caseID = arg0.key.key.caseID;

    listCaseAppealsDetails.description =
      contextDescription.readCasePageContextDescription(caseIDobj);

    return listCaseAppealsDetails;

  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for reassigning the Case Appeals by Type
   *
   * @param arg0
   * - ReassignCasesForUserKey
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public void reassignCaseAppealsByType(final ReassignCasesForUserKey arg0)
    throws AppException, InformationalException {

    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();

    maintainSupervisorAppealCase.reassignCaseAppeals(arg0.userKey);
  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for reassigning the Case Appeals by DeadLine
   *
   * @param arg0
   * -ReassignCasesForUserKey
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public void
    reassignCaseAppealsByDeadLine(final ReassignCasesForUserKey arg0)
      throws AppException, InformationalException {

    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();

    maintainSupervisorAppealCase.reassignCaseAppeals(arg0.userKey);

  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for listing the Case Appeals by DeadLine
   *
   * @param arg0
   * - CaseIDAndAppealOptionKey
   * @return ListCaseAppealsDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListCaseAppealsDetails
    listCaseAppealsByDeadLine(final CaseIDAndAppealOptionKey arg0)
      throws AppException, InformationalException {

    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();
    final CaseIDAndAppealTypeKey caseIDAndAppealTypeKey =
      new CaseIDAndAppealTypeKey();

    caseIDAndAppealTypeKey.key.key.caseID = arg0.caseID;
    final ListCaseAppealsDetails listCaseAppealsDetails =
      new ListCaseAppealsDetails();

    listCaseAppealsDetails.appealDetailsList = maintainSupervisorAppealCase
      .listCaseAppealsByDeadLine(caseIDAndAppealTypeKey.key);

    // contextDescription object
    final SupervisorAppealsAppPageContextDescription contextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();

    // contextDescriptionKey object
    final curam.core.struct.CaseID caseIDObj = new curam.core.struct.CaseID();

    caseIDObj.caseID = arg0.caseID;
    listCaseAppealsDetails.description =
      contextDescription.readCasePageContextDescription(caseIDObj);

    return listCaseAppealsDetails;

  }

  // ______________________________________________________________________________
  /**
   * Facade layer method for listing the Supervisor Users for search operation
   *
   * @return ListSupervisorUserDetails
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public ListSupervisorUserDetails listSupervisorUsers()
    throws AppException, InformationalException {

    SecurityImplementationFactory.register();

    final ListSupervisorUserDetails details = new ListSupervisorUserDetails();
    final curam.supervisorappeals.sl.intf.MaintainSupervisorAppealCase maintainSupervisorAppealCase =
      curam.supervisorappeals.sl.fact.MaintainSupervisorAppealCaseFactory
        .newInstance();
    final SupervisorUserDetailsList userDetails =
      maintainSupervisorAppealCase.listSupervisorUsers();

    details.dtls = userDetails;

    final SupervisorAppealsAppPageContextDescription pageContextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();

    // Get the userName from the SystemUser
    final SystemUser systemUser = SystemUserFactory.newInstance();

    userNameKey.userName = systemUser.getUserDetails().userName;

    final SupervisorAppealsAppPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(userNameKey);

    details.description = pageContextDetails;

    return details;

  }

  // ______________________________________________________________________________
  /**
   * This readCasesWithAppealsforHeatMap method is used to construct heat map
   * from the Appeals details list. created for CR00050647
   *
   * @return CasesWithIssuesDtlsList
   * @throws AppException
   * @throws InformationalException
   */

  @Override
  public CasesWithAppealsDetails readCasesWithAppealsforHeatMap()
    throws AppException, InformationalException {

    // Create the objects to get the list of Appeals
    CasesWithAppealsDetails casesWithAppealsDetails =
      new CasesWithAppealsDetails();

    casesWithAppealsDetails = listCasesWithAppeals();
    casesWithAppealsDetails.heatMapXMLString =
      constructHeatMap(casesWithAppealsDetails);

    final SupervisorAppealsAppPageContextDescription pageContextDescription =
      SupervisorAppealsAppPageContextDescriptionFactory.newInstance();

    final UserNameKey userNameKey = new UserNameKey();
    // Get the userName from the SystemUser
    final SystemUser systemUser = SystemUserFactory.newInstance();

    userNameKey.userName = systemUser.getUserDetails().userName;

    final SupervisorAppealsAppPageContextDetails pageContextDetails =
      pageContextDescription.readUserNamePageContextDescription(userNameKey);

    casesWithAppealsDetails.description = pageContextDetails;

    return casesWithAppealsDetails;
  }

  // ______________________________________________________________________________
  /**
   * This constructHeatMap method constructs the heat map xml string. created
   * for CR00050647
   *
   * @param array
   * - String[]
   * @param listDetails
   * - CasesWithAppealsDetails
   * @return String - of HeatMap xml values
   * @throws AppException
   * @throws InformationalException
   */

  // BEGIN, CR00177241, PM
  protected String
    constructHeatMap(final CasesWithAppealsDetails listDetails) {

    // END, CR00177241

    // Create Heat Map element and XML out putter
    final Element heatMapElement = new Element(kHeatMap);
    final XMLOutputter outputter = new XMLOutputter();

    // Using the user defined Array
    final String[] arr = getLegendArray();

    // Get the size of the list to be displayed
    final int listSize = listDetails.appealsDetails.dtls.size();
    int j = 0, count = 0;

    for (int i = arr.length; i > 0; i--) {
      final Element regionElement = new Element(kRegion);

      regionElement.setAttribute(kRegionId, "Region " + (i - 1));
      regionElement.setAttribute(kLabel, arr[i - 1] + "");

      try {
        if (i == arr.length) {
          for (j = count; j < listSize; j++) {
            final curam.appeal.sl.entity.struct.CasesWithAppealsDetails issueDetails =
              listDetails.appealsDetails.dtls.item(j);
            final String[] value = arr[i - 1].split(kGreaterThanEqualTo);
            final int startingRange = Integer.parseInt(value[1]);

            if (issueDetails.numberOfAppeals > startingRange) {
              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId,
                issueDetails.caseReference);
              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseId));
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.setAttribute(kAppealOptionCode,
                CASEAPPEALSOPTION.TYPE);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);
              count++;
            }
          }
        } else {
          final String[] result = arr[i - 1].split(kDash);
          final int startingRange = Integer.parseInt(result[0]);
          int endingRange;

          if (result[1] == null || result[1].equals("")) {
            endingRange = 0;
          } else {
            endingRange = Integer.parseInt(result[1]);
          }

          for (j = count; j < listSize; j++) {
            final curam.appeal.sl.entity.struct.CasesWithAppealsDetails issueDetails =
              listDetails.appealsDetails.dtls.item(j);

            if (issueDetails.numberOfAppeals >= startingRange
              && issueDetails.numberOfAppeals <= endingRange) {
              final Element captionElement = new Element(kCaption);

              captionElement.setAttribute(kCaseId,
                issueDetails.caseReference);
              final Element itemElement = new Element(kItem);

              itemElement.setAttribute(kItemId,
                Long.toString(issueDetails.caseId));
              itemElement.setAttribute(kAppealOptionCode,
                CASEAPPEALSOPTION.TYPE);
              itemElement.setAttribute(kTaskOptionCode,
                VIEWTASKSOPTION.DEFAULTCODE);
              itemElement.setAttribute(kLabel, issueDetails.caseReference);
              itemElement.addContent(captionElement);
              regionElement.addContent(itemElement);
            }
          }
        }
      } catch (final Exception e) {
        e.printStackTrace();
      }
      heatMapElement.addContent(regionElement);
    }
    if (heatMapElement.getChildren().isEmpty()) {
      return "";
    } else {
      return outputter.outputString(heatMapElement);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method allows the supervisor to search for a user
   *
   * @param key
   * - UserSearchKey
   * @return SupervisorUserSearchDetails
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public SupervisorAppealsUserSearchDetails userSearch(
    final UserSearchKey arg0) throws AppException, InformationalException {

    // details to be returned
    final SupervisorAppealsUserSearchDetails supervisorAppealsUserSearchDetails =
      new SupervisorAppealsUserSearchDetails();

    // user entity
    final curam.core.intf.AdminUser adminUserObj =
      curam.core.fact.AdminUserFactory.newInstance();

    final UserSearchResultsDetails userSearchResultsDetails =
      adminUserObj.searchUserDetails(arg0.userSearchCriteria);

    final UserSearchResults userSearchResults = new UserSearchResults();

    for (final UserSearchDetailsReference userSearchDetailsReference : userSearchResultsDetails.dtls.userSearchDetailsReferenceList
      .items()) {
      final UserSearchDetailsRef userSearchDetailsRef =
        new UserSearchDetailsRef();

      userSearchDetailsRef.firstname = userSearchDetailsReference.firstname;
      userSearchDetailsRef.fullName = userSearchDetailsReference.fullName;
      userSearchDetailsRef.organisationStructureID =
        userSearchDetailsReference.organisationStructureID;
      userSearchDetailsRef.organisationStructureName =
        userSearchDetailsReference.organisationStructureName;
      userSearchDetailsRef.organisationUnitID =
        userSearchDetailsReference.organisationUnitID;
      userSearchDetailsRef.organisationUnitName =
        userSearchDetailsReference.organisationUnitName;
      userSearchDetailsRef.positionID = userSearchDetailsReference.positionID;
      userSearchDetailsRef.positionName =
        userSearchDetailsReference.positionName;
      userSearchDetailsRef.recordStatus =
        userSearchDetailsReference.recordStatus;
      userSearchDetailsRef.statusCode = userSearchDetailsReference.statusCode;
      userSearchDetailsRef.surname = userSearchDetailsReference.surname;
      userSearchDetailsRef.toDate = userSearchDetailsReference.toDate;
      userSearchDetailsRef.username = userSearchDetailsReference.username;
      userSearchResults.userSearchDetailsRefList.dtls
        .addRef(userSearchDetailsRef);

    }

    // search for users
    supervisorAppealsUserSearchDetails.userSearchResultsList =
      userSearchResults;

    // Return user details
    return supervisorAppealsUserSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to fetch the configured properties for the legend
   * array which is required for heat map construction.
   *
   * @return String[]
   */

  // BEGIN, CR00177241, PM
  protected String[] getLegendArray() {

    // END, CR00177241

    String[] legendArray;
    // Fetch the lower limit
    int heatMapLowerLimit;

    final String heatMapLowerLimitStr =
      Configuration.getProperty(EnvVars.ENV_SUPERVISOR_APPEALS_LOWERLIMIT);

    try {
      heatMapLowerLimit = Integer.parseInt(heatMapLowerLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapLowerLimit = EnvVars.ENV_SUPERVISOR_APPEALS_LOWERLIMIT_DEFAULT;
    }

    // Fetch the upper limit
    int heatMapUpperLimit;
    final String heatMapUpperLimitStr = "";

    Configuration.getProperty(EnvVars.ENV_SUPERVISOR_APPEALS_UPPERLIMIT);

    try {
      heatMapUpperLimit = Integer.parseInt(heatMapUpperLimitStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapUpperLimit = EnvVars.ENV_SUPERVISOR_APPEALS_UPPERLIMIT_DEFAULT;
    }

    // Fetch the variable interval
    String heatMapVariableInterval;

    try {
      heatMapVariableInterval = Configuration
        .getProperty(EnvVars.ENV_SUPERVISOR_APPEALS_VARIABLEINTERVAL);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapVariableInterval =
        EnvVars.ENV_SUPERVISOR_APPEALS_VARIABLEINTERVAL_DEFAULT;
    }

    // Fetch the constant interval
    int heatMapConstantInterval;
    final String heatMapConstantIntervalStr = Configuration
      .getProperty(EnvVars.ENV_SUPERVISOR_APPEALS_CONSTANTINTERVAL);

    try {
      heatMapConstantInterval = Integer.parseInt(heatMapConstantIntervalStr);
    } catch (final NumberFormatException e) {
      // any problem, use the default.
      heatMapConstantInterval =
        EnvVars.ENV_SUPERVISOR_APPEALS_CONSTANTINTERVAL_DEFAULT;
    }

    // If Variable interval is not present only then use Constant interval
    if (heatMapVariableInterval.equals(CuramConst.gkDash)) {
      legendArray = constructLegArrWithConstantInterval(heatMapLowerLimit,
        heatMapUpperLimit, heatMapConstantInterval);
    } else {
      legendArray = constructLegArrWithVariableInterval(heatMapLowerLimit,
        heatMapVariableInterval);
    }
    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with constant interval
   * which is required for heat map construction.
   *
   * @param heatMapVariableInterval
   * - String
   * @param heatMapLowerLimit
   * - int
   * @param heatMapUpperLimit
   * - int
   * @return String[]
   */

  // BEGIN, CR00177241, PM
  protected String[] constructLegArrWithConstantInterval(
    final int heatMapLowerLimit, final int heatMapUpperLimit,
    final int heatMapConstantInterval) {

    // END, CR00177241
    // Variables required to construct the array
    final BigDecimal bigDecimal =
      new BigDecimal(heatMapUpperLimit - heatMapLowerLimit);
    int range;

    range = bigDecimal.divide(new BigDecimal(heatMapConstantInterval),
      BigDecimal.ROUND_HALF_UP).intValue();

    String[] legendArray;

    legendArray = new String[range + 1];

    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + heatMapConstantInterval - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += heatMapConstantInterval;
    }

    // Creating hyphen separated legend Array
    legendArray[0] =
      legendArrayTemp[0] + CuramConst.gkDash + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] =
        legendArrayTemp[i] + 1 + CuramConst.gkDash + legendArrayTemp[i + 1];
    }
    legendArray[range] = kGreaterThanEqualTo + (legendArrayTemp[range] + 1);

    return legendArray;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to construct the legend array with variable interval
   * which is required for heat map construction.
   *
   * @param heatMapLowerLimit
   * - int
   * @param heatMapVariableInterval
   * - String
   * @return String[]
   */

  // BEGIN, CR00177241, PM
  protected String[] constructLegArrWithVariableInterval(
    final int heatMapLowerLimit, final String heatMapVariableInterval) {

    // END, CR00177241

    // Variables required to construct the array
    int range;
    int[] intervalArr;

    // String Tokenizer is used to get the variable interval from the
    // heatMapVariableInterval String
    final StringTokenizer st =
      new StringTokenizer(heatMapVariableInterval, CuramConst.gkComma);

    range = st.countTokens();
    intervalArr = new int[range + 1];

    for (int i = 0; st.hasMoreTokens(); i++) {
      intervalArr[i] = Integer.parseInt(st.nextToken());
    }

    String[] legendArray;

    legendArray = new String[range + 1];
    int[] legendArrayTemp;

    legendArrayTemp = new int[range + 1];
    int temp = heatMapLowerLimit;

    legendArrayTemp[0] = temp;
    temp = temp + intervalArr[0] - 1;

    // Creating the legend array elements
    for (int i = 1; i <= range; i++) {
      legendArrayTemp[i] = temp;
      temp += intervalArr[i];
    }

    // Creating hyphen separated legend Array
    legendArray[0] =
      legendArrayTemp[0] + CuramConst.gkDash + legendArrayTemp[1];
    for (int i = 1; i < range; i++) {
      legendArray[i] =
        legendArrayTemp[i] + 1 + CuramConst.gkDash + legendArrayTemp[i + 1];
    }
    legendArray[range] = kGreaterThanEqualTo + (legendArrayTemp[range] + 1);

    return legendArray;
  }

}
