/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.samplepublicaccess.facade.impl;


import curam.core.facade.fact.WorkAllocationFactory;
import curam.core.fact.SystemUserFactory;
import curam.samplepublicaccess.facade.fact.ExternalUserAccessFactory;
import curam.samplepublicaccess.facade.struct.ExternalUserKey;
import curam.samplepublicaccess.facade.struct.ReadExternalHomeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class used to read the External User home page details
 */
public abstract class ExternalHome extends curam.samplepublicaccess.facade.base.ExternalHome {

  // __________________________________________________________________________
  /**
   * Reads the home page details for the current External User.
   *
   * @param key External User key
   *
   * @return the home page details
   */
  @Override
  public ReadExternalHomeDetails readApplicationHome(ExternalUserKey key)
    throws AppException, InformationalException {

    // Return object
    final ReadExternalHomeDetails readExternalHomeDetails = new ReadExternalHomeDetails();

    // Get the tasks list
    readExternalHomeDetails.workAllocationTaskAndActivityForUserDetails = WorkAllocationFactory.newInstance().listTaskAndActivitiesForCurrentUser();

    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    // Get context details
    readExternalHomeDetails.context = ExternalUserAccessFactory.newInstance().readUser(key).context;

    return readExternalHomeDetails;
  }

}
