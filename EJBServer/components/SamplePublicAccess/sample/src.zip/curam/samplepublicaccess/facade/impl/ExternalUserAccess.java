/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.facade.impl;


import com.google.inject.Inject;
import curam.codetable.LOCALE;
import curam.core.facade.struct.CancelUserKey;
import curam.core.facade.struct.ReactivateUserKey;
import curam.core.sl.fact.ExternalUserFactory;
import curam.core.sl.struct.ExternalUserSearchCriteria;
import curam.core.sl.struct.ExternalUserSearchResults;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.UsersKey;
import curam.samplepublicaccess.facade.struct.ExternalUserContext;
import curam.samplepublicaccess.facade.struct.ExternalUserDetails;
import curam.samplepublicaccess.facade.struct.ExternalUserKey;
import curam.samplepublicaccess.facade.struct.ExternalUserSearchKey;
import curam.samplepublicaccess.facade.struct.UserAccountStatusDetails;
import curam.samplepublicaccess.facade.struct.UserPasswordDetails;
import curam.samplepublicaccess.impl.AccountEvents;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides both the admin maintenance functionality for
 * External User access and the external application's External User read,
 * search and modify password functionality.
 */
public abstract class ExternalUserAccess extends curam.samplepublicaccess.facade.base.ExternalUserAccess {

  // BEGIN CR00290764
  @Inject
  private AccountEvents accountEvents;

  // END CR00290764

  /**
   * Used by Guice.
   */
  protected ExternalUserAccess() {

    // BEGIN CR00290764
    GuiceWrapper.getInjector().injectMembers(this);
    // END CR00290764
  }

  // ___________________________________________________________________________
  /**
   * Method to disable the current user's account.
   */
  @Override
  public void disableCurrentUser() throws AppException,
      InformationalException {

    final UserAccountStatusDetails userAccountStatusDetails = new UserAccountStatusDetails();

    userAccountStatusDetails.details.userName = TransactionInfo.getProgramUser();

    disableUser(userAccountStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to enable the current user's account.
   */
  @Override
  public void enableCurrentUser() throws AppException, InformationalException {

    final UserAccountStatusDetails userAccountStatusDetails = new UserAccountStatusDetails();

    userAccountStatusDetails.details.userName = TransactionInfo.getProgramUser();

    enableUser(userAccountStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to get the context description details for an External User.
   *
   * @param key
   * External User's username
   *
   * @return Context Details
   */
  public ExternalUserContext getContext(final ExternalUserKey key)
    throws AppException, InformationalException {

    // Return struct
    final ExternalUserContext externalUserContext = new ExternalUserContext();

    // read the external user table to get the user's full name
    final String fullName = readUser(key).details.userDtls.fullName;

    externalUserContext.userName = key.key.userName;
    externalUserContext.externalContext = fullName;
    externalUserContext.internalContext = fullName;

    return externalUserContext;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the current user's password.
   *
   * @param details
   * The old and new password details.
   */
  @Override
  public void modifyCurrentUserPassword(final UserPasswordDetails details)
    throws AppException, InformationalException {

    // Set the userName by the session info
    details.details.userName = TransactionInfo.getProgramUser();

    // Modify a user's password
    ExternalUserFactory.newInstance().modifyPassword(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Method to read the current user's account details.
   *
   * @return External User details
   */
  @Override
  public ExternalUserDetails readCurrentUser() throws AppException,
      InformationalException {

    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = TransactionInfo.getProgramUser();

    return readUser(externalUserKey);
  }

  // ___________________________________________________________________________
  /**
   * Presentation layer operation to search for an External User.
   *
   * @param key
   * External User Search Criteria
   *
   * @return details of the users
   */
  @Override
  public ExternalUserSearchResults searchExternalUsers(
    final ExternalUserSearchKey key) throws AppException,
      InformationalException {

    // Search for external users
    final ExternalUserSearchCriteria criteria = new ExternalUserSearchCriteria();

    criteria.userSearchCriteria = key.userSearchCriteria;

    return ExternalUserFactory.newInstance().searchExternalUsers(criteria);
  }

  // ___________________________________________________________________________
  /**
   * Method to create an External User.
   *
   * @param details
   * External User details
   */
  @Override
  public void createUser(final ExternalUserDetails details)
    throws AppException, InformationalException {

    details.details.userDtls.defaultLocale = LOCALE.ENGLISH_US;

    ExternalUserFactory.newInstance().insert(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Method to disable an External User's account.
   *
   * @param details
   * User account status details.
   */
  @Override
  public void disableUser(final UserAccountStatusDetails details)
    throws AppException, InformationalException {

    // Set the indicator to disable the account
    details.details.accStatusDetails.accountEnabled = false;

    ExternalUserFactory.newInstance().setUserAccountStatus(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Method to enable an External User's account.
   *
   * @param details
   * User account status details.
   */
  @Override
  public void enableUser(final UserAccountStatusDetails details)
    throws AppException, InformationalException {

    // Set the indicator to disable the account
    details.details.accStatusDetails.accountEnabled = true;

    // insert a user
    ExternalUserFactory.newInstance().setUserAccountStatus(details.details);

    // BEGIN CR00290764
    accountEvents.sendPostAccountEnabledEvent(details.details.userName);
    // END CR00290764
  }

  // ___________________________________________________________________________
  /**
   * Method to modify External User account information.
   *
   * @param details
   * Modified External User details.
   */
  @Override
  public void modifyUser(final ExternalUserDetails details)
    throws AppException, InformationalException {

    ExternalUserFactory.newInstance().modify(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify an External User's password.
   *
   * @param details
   * The old and new password details along with the userName.
   */
  @Override
  public void modifyUserPassword(final UserPasswordDetails details)
    throws AppException, InformationalException {

    ExternalUserFactory.newInstance().modifyPassword(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Method to read an External User's account details.
   *
   * @param key
   * The user's user name.
   *
   * @return The External User's account details.
   */
  @Override
  public ExternalUserDetails readUser(final ExternalUserKey key)
    throws AppException, InformationalException {

    // Return object
    final ExternalUserDetails externalUserDetails = new ExternalUserDetails();

    // Read the user's details
    final curam.core.sl.struct.ExternalUserKey externalUserKey = new curam.core.sl.struct.ExternalUserKey();

    externalUserKey.userKey.userName = key.key.userName;

    externalUserDetails.details = ExternalUserFactory.newInstance().read(
      externalUserKey);

    // Set the context
    externalUserDetails.context.userName = key.key.userName;
    externalUserDetails.context.externalContext = externalUserDetails.details.userDtls.fullName;
    externalUserDetails.context.internalContext = externalUserDetails.details.userDtls.fullName;

    return externalUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to get the context description details for an External User.
   *
   * @return Context Details
   */
  @Override
  public ExternalUserContext getCurrentUserContext() throws AppException,
      InformationalException {

    // Get the current user's userName
    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = TransactionInfo.getProgramUser();

    return getContext(externalUserKey);
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel an External User's account.
   *
   * @param key
   * The user's user name.
   */
  @Override
  public void cancelUser(final CancelUserKey key) throws AppException,
      InformationalException {

    ExternalUserFactory.newInstance().cancel(key.cancelUserKeyStruct);
  }

  // ___________________________________________________________________________
  /**
   * Method to get the context description details for an External User.
   *
   * @param key
   * The user's user name
   *
   * @return Context Details
   */
  @Override
  public ExternalUserContext getContext(final UsersKey key)
    throws AppException, InformationalException {

    // Return struct
    final ExternalUserContext externalUserContext = new ExternalUserContext();

    // Get the user's full name
    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = key.userName;

    final String fullName = readUser(externalUserKey).details.userDtls.fullName;

    externalUserContext.userName = key.userName;
    externalUserContext.externalContext = fullName;
    externalUserContext.internalContext = fullName;

    return externalUserContext;
  }

  // ___________________________________________________________________________
  /**
   * Reactivates users with a status NOT set to cancelled
   *
   * @param key
   * The unique identifier key holding the username and version number.
   * @return Any informational messages
   */
  @Override
  public InformationalMsgDtlsList reactivateUser(final ReactivateUserKey key)
    throws AppException, InformationalException {

    return null;
  }

}
