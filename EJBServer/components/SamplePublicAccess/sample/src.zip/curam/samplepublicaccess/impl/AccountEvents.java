/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.impl;


import com.google.inject.Inject;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;


/**
 * Created as part of CR00290764. Contains event definitions for the
 * {@link ExternalUserAccess} class. We need this to fire an event when a user
 * account is unlocked so that we in CSS can reset certain variables that are
 * in CSS but not in CEF.
 *
 * @curam .non-implementable
 * @since 6.0
 */
public class AccountEvents {

  /**
   * Event dispatcher for {@link PostAccountEnabledEvent}.
   */
  @Inject
  private EventDispatcherFactory<PostAccountEnabledEvent> postAccountEnabledEventDispatcher;

  /**
   * Constructor.
   */
  protected AccountEvents() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * This event is fired immediately after the enabling of a user account.
   *
   * @since 6.0
   */
  static public abstract class PostAccountEnabledEvent {

    /**
     * This method is called immediately after the enabling of a user account.
     *
     * @param username
     * The related username.
     */
    @SuppressWarnings("unused")
    public void postAccountEnabled(final String username)
      throws InformationalException {// empty public method can be overridden by
      // customer class
    }
  }

  /**
   * Dispatch the {@link PostAccountEnabledEvent}.
   *
   * @param username
   * The related username.
   */
  public void sendPostAccountEnabledEvent(final String username)
    throws InformationalException {

    this.postAccountEnabledEventDispatcher.get(PostAccountEnabledEvent.class).postAccountEnabled(
      username);
  }
}
