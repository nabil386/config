package curam.ca.gc.bdm.sl.integritycheck.impl;

import curam.ca.gc.bdm.impl.BDMConstants;
import curam.ca.gc.bdm.sl.integritycheck.struct.BDMIntegrityCheckKey;
import curam.ca.gc.bdm.sl.struct.BDMPersonKey;
import curam.ca.gc.bdm.util.integrity.impl.BDMIntegrityRulesUtil;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINFlagAndStatusReviewUtil;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINIntegrityCheckConstants;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINIntegrityCheckResult;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINIntegrityCheckUtil;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINIntegrityDateCheck;
import curam.ca.gc.bdm.util.integrity.impl.BDMSINIntegrityTaskCreationUtil;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONSTATUS;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EDPartIDEvTypeIdx;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.struct.ConcernRoleKey;
import curam.dynamicevidence.impl.DynamicEvidenceDataAttributeDetails;
import curam.dynamicevidence.impl.DynamicEvidenceDataDetails;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Trace;

import static curam.codetable.VERIFICATIONSTATUS.NOTVERIFIED;
import static curam.codetable.VERIFICATIONSTATUS.VERIFIED;

public class BDMIntegrityCheck
  extends curam.ca.gc.bdm.sl.integritycheck.base.BDMIntegrityCheck {

  @Override
  public void sinIntegrityCheck(final BDMIntegrityCheckKey key)
    throws AppException, InformationalException {

    if (!Configuration
      .getBooleanProperty(EnvVars.BDM_SININTEGRITYCHECK_ENABLED)) {

      Trace.kTopLevelLogger
        .info(BDMConstants.BDM_LOGS_PREFIX + "SIN Integrity Check disabled");

      return;
    }

    final CaseParticipantRole_eoCaseIDKey caseIDKey =
      new CaseParticipantRole_eoCaseIDKey();
    caseIDKey.caseID = key.caseID;

    final CaseParticipantRoleDtlsList cprList =
      CaseParticipantRoleFactory.newInstance().searchByCaseID(caseIDKey);

    final BDMIntegrityCheckKey checkOnPersonkey = new BDMIntegrityCheckKey();

    for (final CaseParticipantRoleDtls cpr : cprList.dtls) {

      if (!cpr.recordStatus.equals(RECORDSTATUS.NORMAL)
        || !(cpr.typeCode.equals(CASEPARTICIPANTROLETYPE.PRIMARY)
          || cpr.typeCode.equals(CASEPARTICIPANTROLETYPE.MEMBER)))
        continue;

      checkOnPersonkey.concernRoleID = cpr.participantRoleID;
      sinIntegrityCheckOnPerson(checkOnPersonkey);
    }

  }

  private CaseParticipantRoleDtls getCaseParticipantRolePC(
    final long concernRoleID) throws AppException, InformationalException {

    final ConcernRoleKey key = new ConcernRoleKey();
    key.concernRoleID = concernRoleID;

    final String sql = "SELECT "
      + "  c.CASEPARTICIPANTROLEID ,c.CASEID into :CASEPARTICIPANTROLEID, :CASEID "
      + "FROM " + "  CASEPARTICIPANTROLE c " + "JOIN CASEHEADER c2 ON "
      + "  c.CASEID = c2.CASEID " + "  AND c2.CASETYPECODE = 'CT2001' "
      + "  WHERE c.PARTICIPANTROLEID  = :concernRoleID "
      + "  AND c.TYPECODE = 'PRI'";

    final CaseParticipantRoleDtls caseParticipantRoleDtls =
      (CaseParticipantRoleDtls) DynamicDataAccess
        .executeNs(CaseParticipantRoleDtls.class, key, false, sql);

    caseParticipantRoleDtls.participantRoleID = concernRoleID;

    return caseParticipantRoleDtls;

  }

  @Override
  public void sinIntegrityCheckOnPerson(final BDMIntegrityCheckKey key)
    throws AppException, InformationalException {

    final BDMSINIntegrityCheckUtil bdmSINIntegrityCheckUtil =
      new BDMSINIntegrityCheckUtil();
    // Step 1: delete the existing SIR Response evidence if any
    final CaseParticipantRoleDtls cprPC = bdmSINIntegrityCheckUtil
      .removeExistingSINSIRResponceEvidence(key.concernRoleID);

    final BDMSINIntegrityCheckResult checkResult =
      bdmSINIntegrityCheckUtil.sinIntegrityCheck(key.concernRoleID);
    
    if (checkResult == null) {
      Trace.kTopLevelLogger.info(BDMConstants.BDM_LOGS_PREFIX
        + "SIR service not called as required evidence not found");
      return;
    }

    final String misMatchResult = checkResult.getMismatchCheckResult();
    if (misMatchResult
      .equals(BDMSINIntegrityCheckConstants.CHECK_RESULT_UNAVAILABLE)) {
      Trace.kTopLevelLogger
        .info(BDMConstants.BDM_LOGS_PREFIX + "SIR service not available");
      return;
    }

    if (misMatchResult
      .equals(BDMSINIntegrityCheckConstants.CHECK_RESULT_ERROR)) {
      Trace.kTopLevelLogger
        .info(BDMConstants.BDM_LOGS_PREFIX + "SIR service response error");

    }

    // create the SIR Response evidence
    BDMIntegrityRulesUtil.createSINSIRResponseEvidence(cprPC, checkResult);

    if (!misMatchResult
      .equals(BDMSINIntegrityCheckConstants.CHECK_RESULT_PASS)) {

      final EvidenceDescriptorKey evidenceDescriptorKey =
        new EvidenceDescriptorKey();
      evidenceDescriptorKey.evidenceDescriptorID =
        checkResult.getDetails().getSinEvidenceDescriptorID();
      bdmSINIntegrityCheckUtil.triggerVerifiction(evidenceDescriptorKey);

      //NameVerifications
      final EvidenceDescriptor evidenceDescriptorObj =
    	      EvidenceDescriptorFactory.newInstance();
      
      final EvidenceDescriptorKey ecDescKey =
    	        new EvidenceDescriptorKey();
      
      EDPartIDEvTypeIdx idEvKey=new EDPartIDEvTypeIdx();
      

      final EIEvidenceKey evidenceKey = new EIEvidenceKey();
//      evidenceKey.evidenceID = evDescDtls.relatedID;
//      evidenceKey.evidenceType = evDescDtls.evidenceType;
      
      idEvKey.participantID=checkResult.getDetails().getConcernRoleID();
      idEvKey.evidenceType="DETBDM8005";
      
      EvidenceDescriptorDtlsList evDescList=
      evidenceDescriptorObj.searchByParticipantIDEvidenceType(idEvKey);
      EvidenceDescriptorDtls evDescDtls= new EvidenceDescriptorDtls();
      for(EvidenceDescriptorDtls evDescDtls2:evDescList.dtls) {
    	  if(evDescDtls2.statusCode.equalsIgnoreCase("EDS1")) {
    		  evidenceKey.evidenceID=evDescDtls2.relatedID;
    		  evidenceKey.evidenceType=evDescDtls2.evidenceType;
    		  evDescDtls.assign(evDescDtls2);
    		  
    	  }
      }
      
      final EvidenceMap map =
              EvidenceController
                .getEvidenceMap();
            final StandardEvidenceInterface standardEvidenceInterface =
              map.getEvidenceType(evDescDtls.evidenceType);

      final DynamicEvidenceDataDetails evidenceData =
        (DynamicEvidenceDataDetails) standardEvidenceInterface
          .readEvidence(evidenceKey);

      final DynamicEvidenceDataAttributeDetails surnameMatch =
        evidenceData.getAttribute("resSurnameMatch");      
        
        final DynamicEvidenceDataAttributeDetails givenNameMatch =
        evidenceData.getAttribute("resGivenNameMatch");
        
        BDMPersonKey bdmPersonKey=new BDMPersonKey();
        bdmPersonKey.concernRoleID=idEvKey.participantID;
        
        if(!surnameMatch.getValue().equals(BDMConstants.kPASS)||!givenNameMatch.getValue().equals(BDMConstants.kPASS)) {
        	 new BDMSINIntegrityCheckUtil().changeVerificationStatus(bdmPersonKey, VERIFIED, NOTVERIFIED);
        }else {
        	 new BDMSINIntegrityCheckUtil().changeVerificationStatus(bdmPersonKey, NOTVERIFIED, VERIFIED);

        }
        
      //End NameVerifications
      
      BDMSINIntegrityTaskCreationUtil.createTaskForSINIntegrity(
        key.concernRoleID,
        BDMSINIntegrityCheckConstants.SIN_TASKTYPE_MISMATCH);

      // Bug 57918 Fixed to continue checking flag and date
      // return;
    } else {
      // Step 2: delete the existing verification on SIN evidence if any
      bdmSINIntegrityCheckUtil.removeExistingSINVerifiction(
        checkResult.getDetails().getSinEvidenceDescriptorID());
      
      //NamesVerification
      BDMPersonKey bdmPersonKey=new BDMPersonKey();
      
      bdmPersonKey.concernRoleID=checkResult.getDetails().getConcernRoleID();
      
      new BDMSINIntegrityCheckUtil().changeVerificationStatus(bdmPersonKey, NOTVERIFIED, VERIFIED);

    }

    // BEGIN TASK-22189 - Continue checking flag and dates if name matched.
    // Calling the SIN Flag and Status Review Process.
    final boolean isInvestigationTaskCreated =
      new BDMSINFlagAndStatusReviewUtil()
        .processSINFlagAndStatusReview(checkResult);
    // END TASK-22189

    // BEGIN Task - 22190 - SIN Date Verification
    if (!isInvestigationTaskCreated) {
      new BDMSINIntegrityDateCheck().getSINDateVerificationCheck(checkResult);
    }

    // END Task - 22190 - SIN Date Verification

  }

}
